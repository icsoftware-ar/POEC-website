-- MySQL dump 10.13  Distrib 5.5.33, for Linux (x86_64)
--
-- Host: localhost    Database: poec_db
-- ------------------------------------------------------
-- Server version	5.5.33-31.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `jom_assets`
--

DROP TABLE IF EXISTS `jom_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_assets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `parent_id` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set parent.',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `level` int(10) unsigned NOT NULL COMMENT 'The cached level in the nested tree.',
  `name` varchar(50) NOT NULL COMMENT 'The unique name for the asset.\n',
  `title` varchar(100) NOT NULL COMMENT 'The descriptive title for the asset.',
  `rules` varchar(5120) NOT NULL COMMENT 'JSON encoded access control.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_asset_name` (`name`),
  KEY `idx_lft_rgt` (`lft`,`rgt`),
  KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=177 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_assets`
--

LOCK TABLES `jom_assets` WRITE;
/*!40000 ALTER TABLE `jom_assets` DISABLE KEYS */;
INSERT INTO `jom_assets` (`id`, `parent_id`, `lft`, `rgt`, `level`, `name`, `title`, `rules`) VALUES (1,0,0,109,0,'root.1','Root Asset','{\"core.login.site\":{\"6\":1,\"2\":1},\"core.login.admin\":{\"6\":1},\"core.login.offline\":{\"6\":1},\"core.admin\":{\"8\":1},\"core.manage\":{\"7\":1},\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"core.edit.own\":{\"6\":1,\"3\":1}}'),(2,1,1,2,1,'com_admin','com_admin','{}'),(3,1,3,6,1,'com_banners','com_banners','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(4,1,7,8,1,'com_cache','com_cache','{\"core.admin\":{\"7\":1},\"core.manage\":{\"7\":1}}'),(5,1,9,10,1,'com_checkin','com_checkin','{\"core.admin\":{\"7\":1},\"core.manage\":{\"7\":1}}'),(6,1,11,12,1,'com_config','com_config','{}'),(7,1,13,16,1,'com_contact','com_contact','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(8,1,17,40,1,'com_content','com_content','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(9,1,41,42,1,'com_cpanel','com_cpanel','{}'),(10,1,43,44,1,'com_installer','com_installer','{\"core.admin\":{\"7\":1},\"core.manage\":{\"7\":1},\"core.delete\":[],\"core.edit.state\":[]}'),(11,1,45,46,1,'com_languages','com_languages','{\"core.admin\":{\"7\":1},\"core.manage\":[],\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(12,1,47,48,1,'com_login','com_login','{}'),(13,1,49,50,1,'com_mailto','com_mailto','{}'),(14,1,51,52,1,'com_massmail','com_massmail','{}'),(15,1,53,54,1,'com_media','com_media','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":{\"5\":1}}'),(16,1,55,56,1,'com_menus','com_menus','{\"core.admin\":{\"7\":1},\"core.manage\":[],\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(17,1,57,58,1,'com_messages','com_messages','{\"core.admin\":{\"7\":1},\"core.manage\":{\"7\":1}}'),(18,1,59,70,1,'com_modules','com_modules','{\"core.admin\":{\"7\":1},\"core.manage\":[],\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(19,1,71,74,1,'com_newsfeeds','com_newsfeeds','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(20,1,75,76,1,'com_plugins','com_plugins','{\"core.admin\":{\"7\":1},\"core.manage\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(21,1,77,78,1,'com_redirect','com_redirect','{\"core.admin\":{\"7\":1},\"core.manage\":[]}'),(22,1,79,80,1,'com_search','com_search','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1}}'),(23,1,81,82,1,'com_templates','com_templates','{\"core.admin\":{\"7\":1},\"core.manage\":[],\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(24,1,83,84,1,'com_users','com_users','{\"core.admin\":{\"7\":1},\"core.manage\":[],\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(25,1,85,110,1,'com_weblinks','com_weblinks','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(26,1,111,112,1,'com_wrapper','com_wrapper','{}'),(27,8,18,21,2,'com_content.category.2','Uncategorised','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(28,3,4,5,2,'com_banners.category.3','Uncategorised','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(29,7,14,15,2,'com_contact.category.4','Uncategorised','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(30,19,72,73,2,'com_newsfeeds.category.5','Uncategorised','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(31,25,86,109,2,'com_weblinks.category.6','Uncategorised','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(32,1,467,468,0,'com_content.category.7','News','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(33,1,469,528,0,'com_content.category.8','Latest','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(45,1,529,532,0,'com_content.category.20','Frontpage','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(49,33,524,525,1,'com_content.article.12','Typography Options','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(50,33,508,509,1,'com_content.article.13','S5 Flex Menu - Menu System','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(51,33,496,497,1,'com_content.article.14','Module Positions and Styles','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(52,164,37,38,3,'com_content.article.17','Greater opportunities knock once','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(53,33,520,521,1,'com_content.article.18','The Template\'s Settings','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(54,33,502,503,1,'com_content.article.24','Page, Column and Row Widths','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(55,33,484,485,1,'com_content.article.36','How To Setup the Search Box and Menus','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(56,33,522,523,1,'com_content.article.37','Tool Tips','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(57,33,516,517,1,'com_content.article.39','Site Shapers','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(59,33,512,513,1,'com_content.article.110','S5 Tab Show','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(60,33,504,505,1,'com_content.article.143','S5 Accordion Menu','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(61,33,492,493,1,'com_content.article.146','Login and Register Setup','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(62,33,514,515,1,'com_content.article.173','Search Engine Optimized ','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(63,33,498,499,1,'com_content.article.195','Multibox','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(64,33,518,519,1,'com_content.article.197','Template Specific Options','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(65,33,478,479,1,'com_content.article.204','Google Fonts Enabled','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(68,33,474,475,1,'com_content.article.212','CSS Tableless Overrides','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(69,33,476,477,1,'com_content.article.214','Fixed Side Tabs','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(70,33,494,495,1,'com_content.article.227','Menu Scroll To Section','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(71,33,486,487,1,'com_content.article.228','IE7 and 8 CSS3 Support','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(72,33,490,491,1,'com_content.article.230','Lazy Load Images','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(73,33,480,481,1,'com_content.article.231','Hide Article Component Area','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(74,33,506,507,1,'com_content.article.233','S5 Drop Down Panel','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(90,1,533,534,0,'com_content.article.253','Cyan Template','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(92,33,470,471,1,'com_content.article.255','3rd Party Component Compatibility','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(93,33,510,511,1,'com_content.article.256','S5 Image and Content Fader','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(95,1,535,536,0,'com_banners.category.24','Joomla','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(96,1,537,538,0,'com_banners.category.25','Text Ads','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(97,1,539,540,0,'com_banners.category.26','Joomla! Promo','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(98,1,541,542,0,'com_banners.category.27','Demo Banner','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(99,1,543,544,0,'com_contact.category.28','Contacts','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(100,1,545,546,0,'com_newsfeeds.category.29','Joomla!','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(101,1,547,548,0,'com_newsfeeds.category.30','Free and Open Source Software','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(102,1,549,550,0,'com_newsfeeds.category.31','Related Projects','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(103,1,551,552,0,'com_weblinks.category.32','Joomla! Specific Links','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(104,1,553,554,0,'com_weblinks.category.33','Other Resources','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(127,27,19,20,3,'com_content.article.276','Sample Content','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(128,8,22,29,2,'com_content.category.38','Sample Content','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(129,128,27,28,3,'com_content.article.277','Sample Content','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(130,128,23,24,3,'com_content.article.278','Sample Content','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(131,128,25,26,3,'com_content.article.279','Sample Content','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(140,33,500,501,1,'com_content.article.287','Optional Responsive Layout','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(141,33,488,489,1,'com_content.article.288','Info Slide','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(142,33,482,483,1,'com_content.article.289','Hide Divs, Content, and Modules','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(143,33,472,473,1,'com_content.article.290','Built In File Compression','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(150,33,526,527,1,'com_content.article.291','Stock Photography','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(156,45,530,531,1,'com_content.article.296','Reach your dream jobs now','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(157,1,87,88,1,'com_jsjobs','com_jsjobs','{}'),(158,1,89,90,1,'com_extplorer','extplorer','{}'),(159,1,91,92,1,'com_foxcontact','com_foxcontact','{}'),(160,1,93,94,1,'com_jce','jce','{}'),(161,8,30,35,2,'com_content.category.47','Site Info','{\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"core.edit.own\":{\"6\":1,\"3\":1}}'),(162,161,31,32,3,'com_content.article.297','About Us','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(163,161,33,34,3,'com_content.article.298','Frequenty Asked Questions by Employers','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(164,8,36,39,2,'com_content.category.48','Blog','{\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"core.edit.own\":{\"6\":1,\"3\":1}}'),(165,1,95,96,1,'com_finder','com_finder','{}'),(166,1,97,98,1,'com_joomlaupdate','com_joomlaupdate','{}'),(167,1,99,100,1,'com_tags','com_tags','{}'),(168,1,101,102,1,'com_contenthistory','com_contenthistory','{}'),(169,1,103,104,1,'com_ajax','com_ajax','{}'),(170,1,105,106,1,'com_postinstall','com_postinstall','{}'),(171,18,60,61,2,'com_modules.module.194','Register','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(172,18,62,63,2,'com_modules.module.195','Login','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(173,18,64,65,2,'com_modules.module.187','JS Jobs Login','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(174,18,66,67,2,'com_modules.module.196','Login','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(175,1,107,108,1,'com_kunena','com_kunena','{}'),(176,18,68,69,2,'com_modules.module.197','JS Jobs BY State','');
/*!40000 ALTER TABLE `jom_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_associations`
--

DROP TABLE IF EXISTS `jom_associations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_associations` (
  `id` int(11) NOT NULL COMMENT 'A reference to the associated item.',
  `context` varchar(50) NOT NULL COMMENT 'The context of the associated item.',
  `key` char(32) NOT NULL COMMENT 'The key for the association computed from an md5 on associated ids.',
  PRIMARY KEY (`context`,`id`),
  KEY `idx_key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_associations`
--

LOCK TABLES `jom_associations` WRITE;
/*!40000 ALTER TABLE `jom_associations` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_associations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_banner_clients`
--

DROP TABLE IF EXISTS `jom_banner_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_banner_clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `contact` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `extrainfo` text NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `metakey` text NOT NULL,
  `own_prefix` tinyint(4) NOT NULL DEFAULT '0',
  `metakey_prefix` varchar(255) NOT NULL DEFAULT '',
  `purchase_type` tinyint(4) NOT NULL DEFAULT '-1',
  `track_clicks` tinyint(4) NOT NULL DEFAULT '-1',
  `track_impressions` tinyint(4) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`id`),
  KEY `idx_own_prefix` (`own_prefix`),
  KEY `idx_metakey_prefix` (`metakey_prefix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_banner_clients`
--

LOCK TABLES `jom_banner_clients` WRITE;
/*!40000 ALTER TABLE `jom_banner_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_banner_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_banner_tracks`
--

DROP TABLE IF EXISTS `jom_banner_tracks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_banner_tracks` (
  `track_date` datetime NOT NULL,
  `track_type` int(10) unsigned NOT NULL,
  `banner_id` int(10) unsigned NOT NULL,
  `count` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`track_date`,`track_type`,`banner_id`),
  KEY `idx_track_date` (`track_date`),
  KEY `idx_track_type` (`track_type`),
  KEY `idx_banner_id` (`banner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_banner_tracks`
--

LOCK TABLES `jom_banner_tracks` WRITE;
/*!40000 ALTER TABLE `jom_banner_tracks` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_banner_tracks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_banners`
--

DROP TABLE IF EXISTS `jom_banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_banners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `imptotal` int(11) NOT NULL DEFAULT '0',
  `impmade` int(11) NOT NULL DEFAULT '0',
  `clicks` int(11) NOT NULL DEFAULT '0',
  `clickurl` varchar(200) NOT NULL DEFAULT '',
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `custombannercode` varchar(2048) NOT NULL,
  `sticky` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `params` text NOT NULL,
  `own_prefix` tinyint(1) NOT NULL DEFAULT '0',
  `metakey_prefix` varchar(255) NOT NULL DEFAULT '',
  `purchase_type` tinyint(4) NOT NULL DEFAULT '-1',
  `track_clicks` tinyint(4) NOT NULL DEFAULT '-1',
  `track_impressions` tinyint(4) NOT NULL DEFAULT '-1',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `reset` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `language` char(7) NOT NULL DEFAULT '',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`state`),
  KEY `idx_own_prefix` (`own_prefix`),
  KEY `idx_metakey_prefix` (`metakey_prefix`),
  KEY `idx_banner_catid` (`catid`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_banners`
--

LOCK TABLES `jom_banners` WRITE;
/*!40000 ALTER TABLE `jom_banners` DISABLE KEYS */;
INSERT INTO `jom_banners` (`id`, `cid`, `type`, `name`, `alias`, `imptotal`, `impmade`, `clicks`, `clickurl`, `state`, `catid`, `description`, `custombannercode`, `sticky`, `ordering`, `metakey`, `params`, `own_prefix`, `metakey_prefix`, `purchase_type`, `track_clicks`, `track_impressions`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `reset`, `created`, `language`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `version`) VALUES (1,1,0,'OSM 1','osm-1',0,1919,0,'http://www.opensourcematters.org',1,24,'','',0,1,'','{}',0,'',-1,-1,-1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','*',0,'','0000-00-00 00:00:00',0,1),(2,1,0,'OSM 2','osm-2',0,2021,1,'http://www.opensourcematters.org',1,24,'','',0,2,'','{}',0,'',-1,-1,-1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','*',0,'','0000-00-00 00:00:00',0,1),(3,1,0,'Joomla!','joomla',0,504,0,'http://www.joomla.org',1,25,'','<a href=\"{CLICKURL}\" target=\"_blank\">{NAME}</a>\r\n<br/>\r\nJoomla! The most popular and widely used Open Source CMS Project in the world.',0,1,'','{}',0,'',-1,-1,-1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','*',0,'','0000-00-00 00:00:00',0,1),(4,1,0,'JoomlaCode','joomlacode',0,504,0,'http://joomlacode.org',1,25,'','<a href=\"{CLICKURL}\" target=\"_blank\">{NAME}</a>\r\n<br/>\r\nJoomlaCode, development and distribution made easy.',0,2,'','{}',0,'',-1,-1,-1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','*',0,'','0000-00-00 00:00:00',0,1),(5,1,0,'Joomla! Extensions','joomla-extensions',0,499,0,'http://extensions.joomla.org',1,25,'','<a href=\"{CLICKURL}\" target=\"_blank\">{NAME}</a>\r\n<br/>\r\nJoomla! Components, Modules, Plugins and Languages by the bucket load.',0,3,'','{}',0,'',-1,-1,-1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','*',0,'','0000-00-00 00:00:00',0,1),(6,1,0,'Joomla! Shop','joomla-shop',0,499,0,'http://shop.joomla.org',1,25,'','<a href=\"{CLICKURL}\" target=\"_blank\">{NAME}</a>\r\n<br/>\r\nFor all your Joomla! merchandise.',0,4,'','{}',0,'',-1,-1,-1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','*',0,'','0000-00-00 00:00:00',0,1),(7,1,0,'Joomla! Promo Shop','joomla-promo-shop',0,8,1,'http://shop.joomla.org',1,26,'','',0,3,'','{}',0,'',-1,-1,-1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','*',0,'','0000-00-00 00:00:00',0,1),(8,1,0,'Joomla! Promo Books','joomla-promo-books',0,10,0,'http://shop.joomla.org/amazoncom-bookstores.html',1,26,'','',0,4,'','{}',0,'',-1,-1,-1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','*',0,'','0000-00-00 00:00:00',0,1),(9,1,0,'Demo Banner','demo-banner',0,2634,0,'',1,27,'','',0,1,'','{\"width\":0,\"height\":0}',0,'',-1,-1,-1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00','*',0,'','0000-00-00 00:00:00',0,1);
/*!40000 ALTER TABLE `jom_banners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_categories`
--

DROP TABLE IF EXISTS `jom_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0',
  `level` int(10) unsigned NOT NULL DEFAULT '0',
  `path` varchar(255) NOT NULL DEFAULT '',
  `extension` varchar(50) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `description` mediumtext,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access` int(10) unsigned DEFAULT NULL,
  `params` text NOT NULL,
  `metadesc` varchar(1024) NOT NULL COMMENT 'The meta description for the page.',
  `metakey` varchar(1024) NOT NULL COMMENT 'The meta keywords for the page.',
  `metadata` varchar(2048) NOT NULL COMMENT 'JSON encoded metadata properties.',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `cat_idx` (`extension`,`published`,`access`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_path` (`path`),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_alias` (`alias`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_categories`
--

LOCK TABLES `jom_categories` WRITE;
/*!40000 ALTER TABLE `jom_categories` DISABLE KEYS */;
INSERT INTO `jom_categories` (`id`, `asset_id`, `parent_id`, `lft`, `rgt`, `level`, `path`, `extension`, `title`, `alias`, `note`, `description`, `published`, `checked_out`, `checked_out_time`, `access`, `params`, `metadesc`, `metakey`, `metadata`, `created_user_id`, `created_time`, `modified_user_id`, `modified_time`, `hits`, `language`, `version`) VALUES (1,0,0,0,43,0,'','system','ROOT','root','','',1,0,'0000-00-00 00:00:00',1,'{}','','','',335,'2009-10-18 16:07:09',0,'0000-00-00 00:00:00',0,'*',1),(2,27,1,27,28,1,'uncategorised','com_content','Uncategorised','uncategorised','','',1,0,'0000-00-00 00:00:00',1,'{\"target\":\"\",\"image\":\"\"}','','','{\"page_title\":\"\",\"author\":\"\",\"robots\":\"\"}',335,'2010-06-28 13:26:37',0,'0000-00-00 00:00:00',58,'*',1),(3,28,1,29,30,1,'uncategorised','com_banners','Uncategorised','uncategorised','','',1,0,'0000-00-00 00:00:00',1,'{\"target\":\"\",\"image\":\"\",\"foobar\":\"\"}','','','{\"page_title\":\"\",\"author\":\"\",\"robots\":\"\"}',335,'2010-06-28 13:27:35',0,'0000-00-00 00:00:00',0,'*',1),(4,29,1,31,32,1,'uncategorised','com_contact','Uncategorised','uncategorised','','',1,0,'0000-00-00 00:00:00',1,'{\"target\":\"\",\"image\":\"\"}','','','{\"page_title\":\"\",\"author\":\"\",\"robots\":\"\"}',335,'2010-06-28 13:27:57',0,'0000-00-00 00:00:00',0,'*',1),(5,30,1,33,34,1,'uncategorised','com_newsfeeds','Uncategorised','uncategorised','','',1,0,'0000-00-00 00:00:00',1,'{\"target\":\"\",\"image\":\"\"}','','','{\"page_title\":\"\",\"author\":\"\",\"robots\":\"\"}',335,'2010-06-28 13:28:15',0,'0000-00-00 00:00:00',0,'*',1),(6,31,1,35,36,1,'uncategorised','com_weblinks','Uncategorised','uncategorised','','',1,0,'0000-00-00 00:00:00',1,'{\"target\":\"\",\"image\":\"\"}','','','{\"page_title\":\"\",\"author\":\"\",\"robots\":\"\"}',335,'2010-06-28 13:28:33',0,'0000-00-00 00:00:00',0,'*',1),(7,32,1,23,26,1,'news','com_content','News','news','','Select a news topic from the list below, then select a news article to read.',1,0,'0000-00-00 00:00:00',1,'{}','','','',335,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00',31,'*',1),(8,33,7,24,25,2,'news/latest-news','com_content','Latest','latest-news','','The latest news from the Joomla! Team',1,0,'0000-00-00 00:00:00',1,'{}','','','',335,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00',44,'*',1),(20,45,1,21,22,1,'frontpage','com_content','Frontpage','frontpage','','',1,0,'0000-00-00 00:00:00',1,'{}','','','',335,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00',45,'*',1),(24,95,1,19,20,1,'joomla','com_banners','Joomla','joomla','','',1,0,'0000-00-00 00:00:00',1,'{}','','','',335,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00',0,'*',1),(25,96,1,17,18,1,'text-ads','com_banners','Text Ads','text-ads','','',1,0,'0000-00-00 00:00:00',1,'{}','','','',335,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00',0,'*',1),(26,97,1,15,16,1,'joomla-promo','com_banners','Joomla! Promo','joomla-promo','','',1,0,'0000-00-00 00:00:00',1,'{}','','','',335,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00',0,'*',1),(27,98,1,13,14,1,'demo-banner','com_banners','Demo Banner','demo-banner','','',1,0,'0000-00-00 00:00:00',1,'{}','','','',335,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00',0,'*',1),(28,99,1,11,12,1,'contacts','com_contact_details','Contacts','contacts','','Contact Details for this Web site',1,0,'0000-00-00 00:00:00',1,'{}','','','',335,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00',0,'*',1),(29,100,1,9,10,1,'joomla','com_newsfeeds','Joomla!','joomla','','',1,0,'0000-00-00 00:00:00',1,'{}','','','',335,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00',0,'*',1),(30,101,1,7,8,1,'free-and-open-source-software','com_newsfeeds','Free and Open Source Software','free-and-open-source-software','','Read the latest news about free and open source software from some of its leading advocates.',1,0,'0000-00-00 00:00:00',1,'{}','','','',335,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00',0,'*',1),(31,102,1,5,6,1,'related-projects','com_newsfeeds','Related Projects','related-projects','','Joomla builds on and collaborates with many other free and open source projects. Keep up with the latest news from some of them.',1,0,'0000-00-00 00:00:00',1,'{}','','','',335,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00',0,'*',1),(32,103,1,3,4,1,'joomla-specific-links','com_weblinks','Joomla! Specific Links','joomla-specific-links','','A selection of links that are all related to the Joomla! Project.',1,0,'0000-00-00 00:00:00',1,'{}','','','',335,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00',0,'*',1),(33,104,1,1,2,1,'other-resources','com_weblinks','Other Resources','other-resources','','',1,62,'2009-04-07 19:56:18',1,'{}','','','',335,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00',0,'*',1),(38,128,1,37,38,1,'sample-content','com_content','Sample Content','sample-content','','',1,0,'0000-00-00 00:00:00',1,'{\"category_layout\":\"\",\"image\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',335,'2012-04-10 19:38:43',0,'0000-00-00 00:00:00',30,'*',1),(47,161,1,39,40,1,'site-info','com_content','Site Info','site-info','','',1,0,'0000-00-00 00:00:00',1,'{\"category_layout\":\"\",\"image\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',335,'2013-10-29 11:52:38',0,'0000-00-00 00:00:00',53,'*',1),(48,164,1,41,42,1,'blog','com_content','Blog','blog','','',1,0,'0000-00-00 00:00:00',1,'{\"category_layout\":\"\",\"image\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',335,'2013-10-29 15:06:19',0,'0000-00-00 00:00:00',47,'*',1);
/*!40000 ALTER TABLE `jom_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_contact_details`
--

DROP TABLE IF EXISTS `jom_contact_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_contact_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `con_position` varchar(255) DEFAULT NULL,
  `address` text,
  `suburb` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `postcode` varchar(100) DEFAULT NULL,
  `telephone` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `misc` mediumtext,
  `image` varchar(255) DEFAULT NULL,
  `email_to` varchar(255) DEFAULT NULL,
  `default_con` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `access` int(10) unsigned DEFAULT NULL,
  `mobile` varchar(255) NOT NULL DEFAULT '',
  `webpage` varchar(255) NOT NULL DEFAULT '',
  `sortname1` varchar(255) NOT NULL,
  `sortname2` varchar(255) NOT NULL,
  `sortname3` varchar(255) NOT NULL,
  `language` char(7) NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `metadata` text NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if article is featured.',
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`published`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_featured_catid` (`featured`,`catid`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_contact_details`
--

LOCK TABLES `jom_contact_details` WRITE;
/*!40000 ALTER TABLE `jom_contact_details` DISABLE KEYS */;
INSERT INTO `jom_contact_details` (`id`, `name`, `alias`, `con_position`, `address`, `suburb`, `state`, `country`, `postcode`, `telephone`, `fax`, `misc`, `image`, `email_to`, `default_con`, `published`, `checked_out`, `checked_out_time`, `ordering`, `params`, `user_id`, `catid`, `access`, `mobile`, `webpage`, `sortname1`, `sortname2`, `sortname3`, `language`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `metakey`, `metadesc`, `metadata`, `featured`, `xreference`, `publish_up`, `publish_down`, `version`, `hits`) VALUES (1,'Name','name','Position','Street','Suburb','State','Country','Zip Code','Telephone','Fax','Miscellanous info','powered_by.png','email@email.com',1,-2,0,'0000-00-00 00:00:00',1,'{\"show_name\":1,\"show_position\":1,\"show_email\":0,\"show_street_address\":1,\"show_suburb\":1,\"show_state\":1,\"show_postcode\":1,\"show_country\":1,\"show_telephone\":1,\"show_mobile\":1,\"show_fax\":1,\"show_webpage\":1,\"show_misc\":1,\"show_image\":1,\"allow_vcard\":0,\"contact_icons\":0,\"icon_address\":\"\",\"icon_email\":\"\",\"icon_telephone\":\"\",\"icon_fax\":\"\",\"icon_misc\":\"\",\"show_email_form\":1,\"email_description\":1,\"show_email_copy\":1,\"banned_email\":\"\",\"banned_subject\":\"\",\"banned_text\":\"\"}',0,12,1,'','','','','','','0000-00-00 00:00:00',335,'','0000-00-00 00:00:00',0,'','','',0,'','0000-00-00 00:00:00','0000-00-00 00:00:00',1,0),(2,'Name','name','','Street','Suburb','State','Country','Zip Code','Telephone','Fax','Miscellaneous info','','email@email.com',0,1,0,'0000-00-00 00:00:00',2,'{\"show_contact_category\":\"\",\"show_contact_list\":\"\",\"presentation_style\":\"plain\",\"show_name\":\"1\",\"show_position\":\"\",\"show_email\":\"1\",\"show_street_address\":\"1\",\"show_suburb\":\"1\",\"show_state\":\"1\",\"show_postcode\":\"1\",\"show_country\":\"1\",\"show_telephone\":\"1\",\"show_mobile\":\"\",\"show_fax\":\"1\",\"show_webpage\":\"\",\"show_misc\":\"\",\"show_image\":\"\",\"allow_vcard\":\"\",\"show_articles\":\"\",\"show_profile\":\"\",\"show_links\":\"\",\"linka_name\":\"\",\"linka\":null,\"linkb_name\":\"\",\"linkb\":null,\"linkc_name\":\"\",\"linkc\":null,\"linkd_name\":\"\",\"linkd\":null,\"linke_name\":\"\",\"linke\":\"\",\"contact_layout\":\"\",\"show_email_form\":\"1\",\"show_email_copy\":\"1\",\"banned_email\":\"\",\"banned_subject\":\"\",\"banned_text\":\"\",\"validate_session\":\"\",\"custom_reply\":\"\",\"redirect\":\"\"}',0,4,1,'','','','','','*','2012-08-08 13:48:06',335,'','2012-08-08 14:01:34',42,'','','{\"robots\":\"\",\"rights\":\"\"}',0,'','0000-00-00 00:00:00','0000-00-00 00:00:00',1,0);
/*!40000 ALTER TABLE `jom_contact_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_content`
--

DROP TABLE IF EXISTS `jom_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `introtext` mediumtext NOT NULL,
  `fulltext` mediumtext NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `images` text NOT NULL,
  `urls` text NOT NULL,
  `attribs` varchar(5120) NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `metadata` text NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if article is featured.',
  `language` char(7) NOT NULL COMMENT 'The language code for the article.',
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`state`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_featured_catid` (`featured`,`catid`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB AUTO_INCREMENT=299 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_content`
--

LOCK TABLES `jom_content` WRITE;
/*!40000 ALTER TABLE `jom_content` DISABLE KEYS */;
INSERT INTO `jom_content` (`id`, `asset_id`, `title`, `alias`, `introtext`, `fulltext`, `state`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`, `featured`, `language`, `xreference`) VALUES (12,49,'Typography Options','typography-options','<blockquote><p>This is a sample blockquote. Use <strong>&lt;blockquote&gt;&lt;p&gt;Your content goes \r\nhere!&lt;/p&gt;&lt;/blockquote&gt;</strong> to create a blockquote.</p></blockquote>\r\n\r\n\r\n\r\n\r\n<div class=\"s5_greenbox\">\r\n<div class=\"point\">\r\n\r\n\r\n&lt;div class=\"s5_greenbox\"&gt;\r\n&lt;div class=\"point\"&gt;\r\nYour text here\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n\r\n\r\n</div>\r\n</div>\r\n\r\n<br />\r\n\r\n\r\n<div class=\"s5_redbox\">\r\n<div class=\"point\">\r\n\r\n\r\n&lt;div class=\"s5_redbox\"&gt;\r\n&lt;div class=\"point\"&gt;\r\nYour text here\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n\r\n\r\n</div>\r\n</div>\r\n\r\n\r\n\r\n\r\n<br />\r\n\r\n<div class=\"s5_bluebox\">\r\n<div class=\"point\">\r\n\r\n\r\n&lt;div class=\"s5_bluebox\"&gt;\r\n&lt;div class=\"point\"&gt;\r\nYour text here\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n\r\n\r\n</div>\r\n</div>\r\n\r\n\r\n\r\n<br />\r\n\r\n\r\n<div class=\"s5_graybox\">\r\n<div class=\"point\">\r\n\r\n\r\n&lt;div class=\"s5_graybox\"&gt;\r\n&lt;div class=\"point\"&gt;\r\nYour text here\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n\r\n\r\n</div>\r\n</div>\r\n\r\n\r\n\r\n\r\n<br />\r\n\r\n<div class=\"black_box\">This is a styled box. Use <strong>&lt;div class=&quot;black_box&quot;&gt;Your content \r\ngoes here!&lt;/div&gt;</strong></div>\r\n\r\n<br />\r\n\r\n<div class=\"gray_box\">This is a styled box. Use <strong>&lt;div class=&quot;gray_box&quot;&gt;Your content \r\ngoes here!&lt;/div&gt;</strong></div>\r\n\r\n<br />\r\n\r\n<div class=\"red_box\">This is a styled box. Use <strong>&lt;div class=&quot;red_box&quot;&gt;Your content \r\ngoes here!&lt;/div&gt;</strong></div>\r\n\r\n<br />\r\n\r\n<div class=\"blue_box\">This is a styled box. Use <strong>&lt;div class=&quot;blue_box&quot;&gt;Your content \r\ngoes here!&lt;/div&gt;</strong></div>\r\n\r\n<br />\r\n\r\n<div class=\"green_box\">This is a styled box. Use <strong>&lt;div class=&quot;green_box&quot;&gt;Your content \r\ngoes here!&lt;/div&gt;</strong></div>\r\n\r\n<br />\r\n\r\n<div class=\"yellow_box\">This is a styled box. Use <strong>&lt;div class=&quot;yellow_box&quot;&gt;Your content \r\ngoes here!&lt;/div&gt;</strong></div>\r\n\r\n<br />\r\n\r\n<div class=\"orange_box\">This is a styled box. Use <strong>&lt;div class=&quot;orange_box&quot;&gt;Your content \r\ngoes here!&lt;/div&gt;</strong></div>\r\n\r\n<br />\r\n\r\n\r\n\r\nThis is an image with the \"boxed\" class applied:<br /><br />\r\n\r\n<img class=\"boxed\" src=\"http://www.shape5.com/demo/images/small1.jpg\" alt=\"\"></img>\r\n<br /><br /><br /><br />\r\n<br />\r\n\r\n\r\n\r\n\r\nThis is an image with the \"boxed_black\" class applied:<br /><br />\r\n\r\n<img class=\"boxed_black\" src=\"http://www.shape5.com/demo/images/small1.jpg\" alt=\"\"></img>\r\n<br /><br />\r\n\r\n\r\n\r\n\r\nThis is an image with the \"padded\" class applied:<br /><br />\r\n\r\n<img class=\"padded\" src=\"http://www.shape5.com/demo/images/small1.jpg\" alt=\"\"></img>\r\n<br /><br />\r\n\r\n\r\n\r\nThis is an image with the \"full_width\" class applied. This can also be done automatically in the template configuration. Be sure to review our Vertex Guide <a href=\"http://www.shape5.com/joomla_tutorials.html\" target=\"_blank\">here</a> for other full width image options.<br /><br />\r\n\r\n<img class=\"full_width\" src=\"http://www.shape5.com/demo/images/general/typography_full_width.jpg\" alt=\"\"></img>\r\n<br /><br />\r\n\r\n\r\n\r\n\r\n<h1>Heading 1</h1>\r\n<h2>Heading 2</h2>\r\n<h3>Heading 3</h3>\r\n<h4>Heading 4</h4>\r\n<h5>Heading 5</h5>\r\n<br />\r\n\r\n\r\n&lt;a&gt; With s5_readon class applied:<br /><br />\r\n<a href=\"\" class=\"s5_readon\">s5_readon</a>\r\n<br /><br />\r\n&lt;h3&gt; With font_highlight class applied:<br /><br />\r\n<h3 class=\"font_highlight\">font_highlight</h3>\r\n\r\n<br />\r\n\r\n<div class=\"code\">This is a sample code div. Use <strong>&lt;div \r\n  class=&quot;code&quot;&gt;Your content goes here!&lt;/div&gt;</strong> to create a code div.<br /><br />#s5_code { width: 30px; color: #fff; line-height: 45px; } </div>\r\n\r\n<br />\r\n\r\n<ol>\r\n<li>This is an <strong>Ordered List</strong></li>\r\n<li>Congue Quisque augue elit dolor nibh.</li>\r\n<li>Condimentum elte quis.</li>\r\n<li>Opsum dolor sit amet consectetuer.</li>\r\n</ol>\r\n\r\n<br />\r\n\r\n<ul>\r\n<li>This is an <strong>Unordered List</strong></li>\r\n<li>Congue Quisque augue elit dolor nibh.</li>\r\n<li>Condimentum elte quis.</li>\r\n<li>Opsum dolor sit amet consectetuer.</li>\r\n</ul>\r\n\r\n<br />\r\n\r\n<ul class=\"ul_arrow\">\r\n<li>This is an <strong>Unordered List with class ul_arrow</strong></li>\r\n<li>Congue Quisque augue elit dolor nibh.</li>\r\n<li>Condimentum elte quis.</li>\r\n<li>Opsum dolor sit amet consectetuer.</li>\r\n</ul>\r\n\r\n\r\n<br />\r\n\r\n<ul class=\"ul_star\">\r\n<li>This is an <strong>Unordered List with class ul_star</strong></li>\r\n<li>Congue Quisque augue elit dolor nibh.</li>\r\n<li>Condimentum elte quis.</li>\r\n<li>Opsum dolor sit amet consectetuer.</li>\r\n</ul>\r\n\r\n<br />\r\n\r\n<ul class=\"ul_bullet\">\r\n<li>This is an <strong>Unordered List with class ul_bullet</strong></li>\r\n<li>Congue Quisque augue elit dolor nibh.</li>\r\n<li>Condimentum elte quis.</li>\r\n<li>Opsum dolor sit amet consectetuer.</li>\r\n</ul>\r\n\r\n\r\n<br />\r\n\r\n<ul class=\"s5_features_list\">\r\n<li>This is an <strong>Unordered List with class s5_features_list</strong></li>\r\n<li>Lorem ipsum dolor sit amet, consectetur es \r\nelit. In rhoncus lobortis orci, sed vestibulum \r\net. Fusce in dolor velit, sit amet vehicul.</li>\r\n<li>Lorem ipsum dolor sit amet, consectetur es \r\nelit. In rhoncus lobortis orci, sed vestibulum \r\net. Fusce in dolor velit, sit amet vehicul.</li>\r\n<li>Lorem ipsum dolor sit amet, consectetur es \r\nelit. In rhoncus lobortis orci, sed vestibulum \r\net. Fusce in dolor velit, sit amet vehicul.</li>\r\n</ul>\r\n\r\n\r\n<br />\r\n\r\nThe following list will support lists up to number 9, add the following class to the UL wrapping the below LI elements, class=\"ul_numbers\":\r\n<br /><br />\r\n\r\n<ul class=\"ul_numbers\">\r\n\r\n<li class=\"li_number1\">This is a sample styled number list <strong>&lt;li class=&quot;li_number1&quot;&gt;Your content \r\ngoes here!&lt;/li&gt;</strong></li>\r\n\r\n<li class=\"li_number2\">This is a sample styled number list <strong>&lt;li class=&quot;li_number2&quot;&gt;Your content \r\ngoes here!&lt;/li&gt;</strong></li>\r\n\r\n<li class=\"li_number3\">This is a sample styled number list <strong>&lt;li class=&quot;li_number3&quot;&gt;Your content \r\ngoes here!&lt;/li&gt;</strong></li>\r\n\r\n<li class=\"li_number4\">This is a sample styled number list <strong>&lt;li class=&quot;li_number4&quot;&gt;Your content \r\ngoes here!&lt;/li&gt;</strong></li>\r\n\r\n</ul>\r\n\r\n\r\n\r\n<br />','',1,8,'2007-12-05 11:25:14',335,'','2012-10-13 19:05:54',42,0,'0000-00-00 00:00:00','2007-12-05 11:24:52','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"1\",\"link_author\":\"\",\"show_create_date\":\"0\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',66,21,'','',1,25495,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(13,50,'S5 Flex Menu - Menu System','s5-flex-menu-menu-system','The S5 Flex Menu system is a very powerful plugin that provides functionality \r\nfar beyond what the standard Joomla menu system can provide. This plugin \r\nis intended to be as an extension of the existing menu system in Joomla to add many new features! Please see the full list of features below. \r\n\r\n<br /><br />\r\n\r\nThis menu system works off of the core Joomla mootools script so no extra javascript library is needed and keep download sizes to a minimum. Also, if you do not want to use this menu you can simply turn it it off from the template configuration page.\r\n<br /><br />\r\n\r\nTake your website to  the next design level by using the robust and feature\r\nrich S5 Flex Menu System. Organize your links with ease and show content \r\nin places you never could before!\r\n<br /><br />\r\n\r\nPlease note - this template does not support sub text on the first level links. However, all sub menus do.\r\n\r\n<br /><br />\r\n<h3>Menu Features:</h3>\r\n\r\n\r\n\r\n<ul class=\"ul_star\">\r\n<li>Multiple javascript effects with core mootools</li>\r\n<li>Multiple columns for menu items or modules</li>\r\n<li>Modules load directly into the menu</li>\r\n<li>Group sub menu items into the same column or fly out</li>\r\n<li>Optional sub texts for each menu item</li>\r\n<li>Optional menu icon images for each menu item</li>\r\n<li>And much more!</li>\r\n</ul>\r\n\r\n\r\n<br /><br />\r\n<h3>Menu Screenshot:</h3>\r\n\r\n<img class=\"padded\" src=\"images/flexmenu.jpg\" alt=\"\"></img>\r\n\r\n<div style=\"clear:both;height:0px\"></div>\r\n\r\n<br /><br />\r\n\r\n\r\n\r\n<div class=\"blue_box\"><strong>I like what I see! I want to <a href=\"http://www.shape5.com/join-now.html\" target=\"_top\">JOIN TODAY</a>.</strong></div><br /></ul>','',1,8,'2007-12-05 11:32:41',335,'','2012-06-25 19:54:14',42,0,'0000-00-00 00:00:00','2007-12-05 11:32:07','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',86,22,'','',1,31543,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(14,51,'Module Positions and Styles','module-positions-and-styles','<br />\r\n<div class=\"blue_box\">\r\n<a style=\"text-decoration:underline\" href=\"index.php/features-mainmenu-47/template-features/responsive-layout\">\r\nBe sure to check out the responsive layout page to see how the layout below is constructed on multiple screen sizes</a>\r\n</div>\r\n<br />\r\n<br />\r\n<h3>All modules are fully collapsible</h3>\r\n<br />\r\nWhat exactly is a collapsing module? It&#39;s quite simple, whenever a module is not published to a postion that position does not appear on the frontend of the template. Consider the example below:\r\n<br /><br />\r\n<img class=\"padded\" src=\"http://www.shape5.com/demo/images/general/modules_6.png\"></img>\r\n<br /><br />\r\nThis particular row has 6 module positions available to publish to. Let&#39;s say you only want to publish to 4 of these positions. The template will automatically collapse the modules you do not want to use and adjust the size of the modules accordingly:\r\n<br /><br />\r\n<img class=\"padded\" src=\"http://www.shape5.com/demo/images/general/modules_4.png\"></img>\r\n<br /><br />\r\nIf no modules are published to the row the entire row itself will not show. The best feature of this is every module can be published to its own unique pages so the layout of your site can change on every page!\r\n<br /><br /><br />\r\n<h3>Infinite Layouts</h3>\r\n<br />\r\nBecause there are so many module positions available in so many different areas, the number of layouts you can create are limitless! For example, if you would like to show your main content area on the right side of your site but still have a column of modules, simply published your modules to the right or right_inset positions or both. The same would be true for the opposite, if you want a column on the left simply publish modules to left or left_inset. Of course you can always choose to not have a column at all. Remember, any module not published to will automatically collapse and the remaining area will automatically adjust. There is no need to choose a pre-defined layout for your entire site, simply use the power of collpasing module positions and take advantage of the numerous amount of module positions to create any layout you can dream of! Be sure to checkout the layout of modules below.\r\n<br /><br /><br />\r\n<h3>Dozens of Modules</h3>\r\n<br />\r\nBelow is a complete list of all the module positions available for this template.\r\n<br /><br />\r\n<img class=\"padded\" src=\"http://www.shape5.com/images/products/2012/new_vision/new_vision_layout.png\"></img>\r\n<br /><br /><br />\r\n\r\n<h3>How to install and setup module styles:</h3></p> <ol> <li>   Download any module you wish to publish to your site.</li> <li>In the backend of Joomla    navigate to the menu item Extensions/Install Uninstall</li> <br />   <img class=\"padded\" style=\"margin-bottom:14px\" src=\"http://www.shape5.com/demo/images/general/install_menu.png\" border=\"0\" width=\"199\" height=\"172\" /><br /> <li>Browse for the module&#39;s install file and click Upload File & Install.</li>  <li>   Once the module has be installed navigate to the menu item Extensions/Module    Manager (same menu as above)</li>  <li>Find the Module just installed and click on it&#39;s title.</li>  <li>   Change any parameters that you wish and be sure to set it to published and    publish it to your desired module position.</li><li>To apply a module style simply fill in the module class suffix field with any of this template&#39;s included module styles. This parameter setting is found under Module Parameters on the right side of the screen. </li> <br />   <img class=\"padded\" style=\"margin-bottom:14px\" src=\"http://www.shape5.com/demo/images/general/module_suffix.png\" border=\"0\" width=\"200\" height=\"72\" /><br /> <li>Assign what pages you would like the module to appear on and finally click Save.</li><br />   <img class=\"padded\" src=\"http://www.shape5.com/demo/images/general/page_assignment.png\" border=\"0\" width=\"200\" height=\"144\" /><br />   </ol>            <p>&nbsp;</p>','',1,8,'2007-12-05 13:16:18',335,'','2012-10-13 19:46:20',42,0,'0000-00-00 00:00:00','2007-12-05 13:16:05','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',74,23,'','',1,26983,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(17,52,'Greater opportunities knock once','installing-the-template','<p><img style=\"margin-right: 10px; margin-bottom: 10px; float: left;\" src=\"images/website-development.jpg\" alt=\"website-development\" />Hearing of \'opportunities\' is truly inviting and interesting. There is a popular saying that says, \'opportinity knows once, so grab it\'. Though people may have different outlook towards opportunities, yet I believe that the common denominator is - \'what is the cost-benefit impact that an opportunity can yield to the seeker. In other words, the bottom-line is - how much take-home earning the seeker may have.</p>\r\n<p>&nbsp;</p>\r\n<p>To some, getting jobs locally maybe already be considered as opportunity, this is true. However, as days go by, the employee may want for more proportionate to the increasing scale of the cost of living, and the gross economy as well. This is the moment when the employee may wander mentally and dream for something greater - greater if not greatest opportunity that will knock once in his life.</p>\r\n<p>&nbsp;</p>\r\n<p>Amidst some claim that opportunities are already well available locally in the country, I will still impress that the greater opportunities are where you earn much, and simply that is working abroad. However, to land a good job abroad is not easy. First, it needs reputable and credible jobs sources and secondly, it needs high and global competencies in part of the job seeker.&nbsp; &nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>This is exactly what this website of the Philippine Overeas Employment Center (POEC) offers. It brings together employers and employee-candidates. It shortens the process of human resource pooling and recruitment in part of the companies, while bringing closer to the job seekers the opportunities they dream of.&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>To give a brief summary of this website\'s features: It has a separate user management and access level for Job Seekers and Employers. The Job Seeker has a private profile and can view job listing by various filter categories, apply for a job, create his Curriculum Vitae (Resume), upload or link a short self-introduction video, be notified of job postings, and many more.</p>\r\n<p>&nbsp;</p>\r\n<p>On the other hand, employers can create a company profile, post job vacancies, view job seekers profile and CV/resume, communicate with job seekrs either for setting-up interviews, upload or link video, and much more.&nbsp; The website\'s online jobs and recruitment module has been tailored fit for a simple and friendly use, moderation and maintenance.</p>\r\n<p>&nbsp;</p>','',1,48,'2013-10-28 19:38:00',335,'','2013-10-29 15:48:38',335,0,'0000-00-00 00:00:00','2013-10-28 19:37:00','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',29,17,'','',1,11230,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(18,53,'The Template\'s Settings','the-templates-settings','<p>This template comes loaded with options that you can use to customize your site exactly how you want it. Here&#39;s how to get to these custom settings:</p>\r\n<ol>\r\n<li>In the backend of Joomla go menu item Extensions/Template Manager.</li>\r\n<li>Click on the title of the template.</li>\r\n<li>This will bring you to the template manager screen where you can edit the template&#39;s parameters.</li>\r\n<li>Click save when you are done</li>\r\n</ol>\r\n<p><img src=\"http://www.shape5.com/demo/images/general/template_edit15.jpg\" border=\"0\" alt=\" \" width=\"500\" height=\"156\" /> <br /><br /><br /></p>\r\n<div class=\"blue_box\"><strong>I like what I see! I want to <a href=\"http://www.shape5.com/join-now.html\" target=\"_top\" style=\"color:#1B6FC2; text-decoration:underline\">JOIN TODAY</a>.</strong></div>\r\n<p> </p>','',1,8,'2007-12-11 19:46:04',335,'','2012-06-25 19:54:14',42,0,'0000-00-00 00:00:00','2007-12-11 19:45:45','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\"}',9,18,'','',1,11417,'',0,'*',''),(24,54,'Page, Column and Row Widths','page-column-and-row-widths','<br />\r\n<h3>Fixed or Fluid Width</h3><br />\r\nThis template has the ability to set the entire width of your set to either a \r\nfixed pixel width or a fluid percentage width. You can set the width to any size \r\nyou want.\r\n\r\n<br /><br />\r\n\r\n\r\n<div class=\"blue_box\">\r\n<a style=\"text-decoration:underline\" href=\"index.php/features-mainmenu-47/template-features/responsive-layout\">\r\nBe sure to check out the responsive layout page to see how the layout below is constructed on multiple screen sizes. The responsive layout will work with both fixed or fluid settings. Responsive layouts are completely optional.</a>\r\n</div>\r\n\r\n\r\n<br /><h3>Column Widths</h3><br />\r\nYou may also set the widths of the following positions to any width that you \r\nneed to: left, left_inset, right, and right_inset. You may set them to any width \r\nyou need to.\r\n<br /><br /><h3>Row Widths</h3><br />\r\nThis template comes loaded with module positions, many of which appear in rows \r\nof 6 module positions. Any row that contains 6 module positions can have it&#39;s \r\nrow columns set to automatic widths or manual. For example, in the picture below \r\nthe first row shows 4 modules published and since it&#39;s set to automatic each is \r\nset to 25% width. The second row shows a manual calculation for each module in \r\nthe row. Again, you may do this for any row that contains 6 modules. If you \r\nsetup a manual calculation they must total to 100%. Not all 6 modules need to be \r\nused, as shown below.<p>\r\n</p>\r\n<p>All of this is done very easily in the template configuration.</p>\r\n<p align=\"center\">\r\n<img style=\"border:solid 1px #333333\" src=\"http://www.shape5.com/demo/images/general/custom_widths.png\" width=\"600\" height=\"432\" /></p>\r\n<br />','',1,8,'2007-12-11 21:25:09',335,'','2012-06-25 19:54:14',42,0,'0000-00-00 00:00:00','2007-12-11 21:24:39','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',49,19,'','',1,10842,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(36,55,'How To Setup the Search Box and Menus','how-to-setup-the-search-box-and-menus','<p> <h3>1. Search Setup</h3></p>\r\n<p><span style=\"font-size: medium;\"><strong> <img src=\"images/search.png\" class=\"padded\" /></strong></span></p>\r\n<ul class=\"ul_arrow\">\r\n<li>Simply publish the default Joomla search module to any main body position The demo shown is using the module class -highlight.</li>\r\n</ul>\r\n\r\n<br />\r\n\r\n<p><h3>2. Column Menu Setup</h3></p>\r\n<p><span style=\"font-size: medium;\"><strong> <img src=\"images/column_menu.png\" class=\"padded\" /></strong></span></p>\r\n<ul class=\"ul_arrow\">\r\n<li>Publish any menu module to the main body module positions on your site. </li>\r\n<li>There should be no menu style suffixes applied under advanced parameters.</li>\r\n<li> The menu style should be set to list.</li>\r\n</ul>\r\n\r\n\r\n\r\n<br />\r\n<p><h3>3. Bottom and Top Menu Setup</h3></p>\r\n<p><img src=\"images/bottom_menu.png\" class=\"padded\" /></p>\r\n<ul class=\"ul_arrow\">\r\n<li>Publish any menu to the &#39;bottom_menu&#39; or &#39;top_menu&#39; position.</li>\r\n<li> There are no menu style suffixes applied under advanced parameters.</li>\r\n<li> The menu style should be set to list</li>\r\n</ul>\r\n<p> </p>','',1,8,'2008-02-14 15:10:56',335,'','2012-10-13 19:12:03',42,0,'0000-00-00 00:00:00','2008-02-14 15:10:36','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',68,24,'','',1,8266,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(37,56,'Tool Tips','tool-tips','<br /><div class=\"blue_box\"><strong>Note - The tool tips script is by default disabled. If you wish to use it you must enable this script in the template&#39;s configuration area. This also includes site shaper installations.</strong></div>\r\n<br/>\r\n<div class=\"blue_box\">\r\n<a style=\"text-decoration:underline\" target=\"_blank\" href=\"http://www.shape5.com/joomla_tutorials.html\">\r\nFor a tutorial on how to setup this script be sure to view the Vertex Guide on our Tutorials page.</a>\r\n</div>\r\n\r\n<br/>\r\n<br/>\r\n<strong>\r\nDemo 1:\r\n</strong>\r\n<br />\r\n\r\n\r\n\r\n\r\n<a onmouseover=\"Tip(&#39;This is a sample tooltip.&#39;, WIDTH, 140, OPACITY, 80, ABOVE, true, OFFSETX, 1, FADEIN, 200, FADEOUT, 300,SHADOW, true, SHADOWCOLOR, &#39;#000000&#39;,SHADOWWIDTH, 2, BGCOLOR, &#39;#000000&#39;,BORDERCOLOR, &#39;#000000&#39;,FONTCOLOR, &#39;#FFFFFF&#39;, PADDING, 9)\" href=\"http://www.shape5.com/demo/etensity/\">\r\n\r\n<img class=\"boxed2\" alt=\"\" src=\"http://www.shape5.com/demo/smart_blogger/images/tooltip.jpg\"/>\r\n\r\n</a>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<br/><br />\r\n<strong>\r\nDemo 2:\r\n</strong>\r\n<br />\r\n\r\n\r\n\r\n<a href=\"index.htm\" onmouseover=\"Tip(&#39;Image Demo<br /> <br /><img src=http://www.shape5.com/demo/smart_blogger/images/tooltip.jpg width=220 height=147>&#39;)\"><strong>Demo 2 Image Tool Tip</strong></a><br/><br/> \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<strong>\r\nDemo 3:\r\n</strong>\r\n<br />\r\n\r\n\r\n\r\n\r\n<a href=\"#\" onmouseover=\"Tip(&#39;Image Demo<br /> <br /><img src=http://www.shape5.com/demo/smart_blogger/images/tooltip.jpg width=220 height=147>&#39;,SHADOW, true,  BGCOLOR, &#39;#000000&#39;, FADEIN, 400, FADEOUT, 400, SHADOWCOLOR, &#39;#000000&#39;, BORDERCOLOR, &#39;#000000&#39;, OPACITY, 90,FONTCOLOR, &#39;#FFFFFF&#39;)\"><strong>Demo 3 Image Tool Tip</strong></a>\r\n<br/><br/>','',1,8,'2008-08-13 18:09:50',335,'','2012-06-25 19:54:14',42,0,'0000-00-00 00:00:00','2008-08-13 18:09:37','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',18,25,'','',1,4900,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(39,57,'Site Shapers','site-shapers','<p><br />So what are Site Shapers? They are quick installs of Joomla combined with all the modules, content, etc used on our demo, excluding stock photography. Within a few minutes you can have your site up, running and looking just like our demo. No more importing SQL dumps and installing modules.  Just head on over to the download section of this template and grab a Site Shaper.  Simply install the Site Shaper like any other Joomla installation, it&#39;s that easy!<br /><br /></p>\r\n\r\n\r\n<div class=\"blue_box\">\r\n<a style=\"text-decoration:underline\" target=\"_blank\" href=\"http://www.shape5.com/joomla_tutorials.html\">\r\nPlease also visit our tutorials download page for a more in depth site shaper tutorial.</a>\r\n</div>\r\n\r\n<br />\r\n\r\n<h3>How to setup a Site Shaper</h3>\r\n\r\n<br />\r\n<ul class=\"ul_bullet\">\r\n<li>Login to your cpanel or your server admin panel.</li>\r\n<li>Locate the area where your databases are    (usually labeled Mysql Databases)</li>\r\n<li>Create a new database</li>\r\n<li>Next create a new database user and assign    it to this newly created database in the previous step</li>\r\n<li>You will then    need to extract the site shaper to either a folder on your server or the root    directory such as WWW. NOTE: if you already have a website in the root of your    WWW folder, we suggest creating a new folder and extract the site shaper    there. If your cpanel does not have an extract option or you cannot find it,    you may also extract the contents of your site shaper in to a folder on your    desktop and upload all the files via an ftp client to your server.</li>\r\n<li>Next, navigate to the url where you extracted the site shaper via your web browser.</li>\r\n<li>Continue through each screen until you reach the below screenshot:</li>\r\n<br /> <img src=\"http://www.shape5.com/demo/images/general/siteshaper.png\" border=\"0\" /> <br /><br />\r\n<li>At the above screen be sure to enter localhost as shown, continue to fill in the following text fields with your newly created database and username information</li>\r\n<li>Follow through the rest of the site shaper setup and click the install sample data at the last screen and the installation is complete! (be sure to rename/remove the installation directory after finishing the install)</li>\r\n</ul>\r\n<p><br /><br /></p>','',1,8,'2008-08-13 18:43:32',335,'','2012-06-25 19:54:14',42,0,'0000-00-00 00:00:00','2008-08-13 18:42:56','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',39,20,'','',1,9012,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(110,59,'S5 Tab Show','s5-tab-show','The S5 Tab Show can be demo\'d at the bottom of this page. This version of the module is customized specifically for this template and cannot be used with any other templates. We do have another version that can be used on any Joomla template.\r\n<br /><br />\r\nThe module holds up to 10 actual module positions so you can publish any of your favorite modules to one of the slides and keep your site clean and consolidated while giving it some eye candy. So simply publish the s5 tab show module to your desired module position and pages. Then start publishing modules to the positions in the tab show (s5_tab1, s5_tab2, etc); these modules will become the slides.','',1,8,'2009-08-13 18:44:06',335,'','2012-10-13 18:45:33',42,0,'0000-00-00 00:00:00','2009-08-13 18:44:06','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',19,26,'','',1,101,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(143,60,'S5 Accordion Menu','s5-accordion-menu','<br />The S5 Accordion menu is demo&#39;d on the right of this page. This version was built specifically for this template and cannot be transferred to another template. We do have another version that can be used on any Joomla template.<br /><br />   \r\n\r\nThis module is based off the Joomla main menu system module so you can still specify which Joomla menu you want to use with the S5 Accordion menu. The menu is powered off of the Mootools Javascript library but detects to see if the library is already initialized, if so then it doesn&#39;t load its own library to stop any conflicts from arising.\r\n\r\n<br /><br />   <div class=\"blue_box\"><strong>I like what I see! I want to <a href=\"http://www.shape5.com/join-now.html\" target=\"_top\">JOIN TODAY</a>.</strong></div>','',1,8,'2009-10-12 22:29:01',335,'','2012-06-25 19:54:14',42,0,'0000-00-00 00:00:00','2009-10-12 22:29:01','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\"}',10,27,'','',1,250,'',0,'*',''),(146,61,'Login and Register Setup','login-and-register-setup','<p>The S5 Box can be demo&#39;d by clicking on either the Login or Register buttons found towards the top of this page.  <br /> <br /> The module allows for up to 10 different S5 Box&#39;s on one page all via 10 module  positions. You simply add a class to any HTML element on your site and enable  the corresponding box and you are good to go!<br /><br /></p>\r\n<p><h3>To enable the login and register modules:</h3></p>\r\n<p>1. Install the S5 Box module and publish it to all pages on your site. Try  to publish it to a position where a module already exists on all pages, but  don&#39;t worry it won&#39;t change the layout of your site, the script is automatically  hidden on your site.</p>\r\n<p>2. Install and publish the S5 Register module to the &#39;register&#39; module  position</p>\r\n<p>3. Publish the default Joomla login module to the &#39;login&#39; module position.</p>\r\n<p>4. In your template parameters area of Joomla you can change the text for login, register and logout.</p>\r\n<p>5. That&#39;s it, you&#39;re all done!</p>\r\n<br />\r\n\r\n<strong>\r\nIf you do not wish to use the S5 Box but would still like to use the Login and Register links then simply complete step 4 above and also fill out your own custom urls just below those fields in the template configuration. Filling out the custom url fields will disable the S5 Box.\r\n</strong>\r\n\r\n<br /><br />\r\n\r\n<p>The S5 Box runs  off of the jQuery Javascript library in a no conflictions mode so you should not receive any problems with other third party extensions you may be running on your site. Alternatively you can also the core Joomla mootools script. <br /> <br /> <h3>Features:</h3></p>\r\n<ul class=\"ul_star\">\r\n<li>Powered by no conflict mode jQuery Javascript or mootools</li>\r\n<li>Choose, elastic, fade or none for the popup effect</li>\r\n<li>Up to 10 S5 Box&#39;s throughout your site or on any one page!</li>\r\n<li>Set the percentage of width of each box according to overall screen size</li>\r\n</ul>\r\n<p> </p>\r\n<p><br /></p>\r\n<div class=\"gray_box\">\r\nTutorial on how to get the s5 box working and use all 10 module positions it includes\r\n</div><br /><br />\r\n<p> <strong>1. Adding the S5 Box positions:</strong></p>\r\n<ul class=\"ul_bullet_small\">\r\n<li>Open up the templateDetails.xml file included with the template you are using.</li>\r\n<li>Locate the positions area.</li>\r\n<li>Start adding new positions s5_box1, s5_box2, s5_box3, etc all the way up to s5_box10.</li>\r\n</ul>\r\n<p><strong>2. Adding the S5 Box classes:</strong></p>\r\n<ul class=\"ul_bullet_small\">\r\n<li>The S5 Box class name of the corresponding position must be added to the link that will open the box. For example the following code will display a link that says Click Here and will open the S5 Box and display whatever module is published to the s5_box3 module position: <br /><br /> <img src=\"http://www.shape5.com/demo/get_reserved/images/box_link.png\" border=\"0\" /> <br /><br /> </li>\r\n<li>These classes can be added to any element, ie: divs, spans, etc., but the common use will be to add this into content with a link similar to the one shown in the picture above. To enter this link you must do so from the HTML edit screen on your content editor:  <br /><br /> Once you have clicked the HTML button the HTML code window will appear much like the first image. </li>\r\n<li>You can continue adding these classes throughout your site just be sure to have published a module to the corresponding position or the box will not work correctly. So if you add the class s5box_two you will also have to publish a module to the s5_box2 position.</li>\r\n<li> Module positions and their corresponding classes:<br /><br /> s5_box1 = s5box_one<br /> s5_box2 = s5box_two<br /> s5_box3 = s5box_three<br /> s5_box4 = s5box_four<br /> s5_box5 = s5box_five<br /> s5_box6 = s5box_six<br /> s5_box7 = s5box_seven<br /> s5_box8 = s5box_eight<br /> s5_box9 = s5box_nine<br /> s5_box10 = s5box_ten</li>\r\n</ul>\r\n<p><strong>3. Lastly, publish your modules to the S5 Box positions:</strong></p>\r\n<ul class=\"ul_bullet_small\">\r\n<li>Now that you have added the s5 box positions just go to your site modules area and publish modules to those positions</li>\r\n<li>Make sure that you have added a class to an HTML element as described above or the s5 box will have no activation button </li>\r\n<li>Also make sure to publish the actual s5 box to a non s5 box position, perhaps publish it to the \"debug\" position or a similar one in your template.</li>\r\n</ul>\r\n<p><br /><br /> <h3>Main S5 Box Module Settings:</h3></p>\r\n<ul class=\"ul_bullet_small\">\r\n<li>In the backend of the S5 Box module you can adjust the width of each box independent of each other. </li>\r\n<li>Make sure that the S5 Box module is published to all pages, it can be published to any template position. Also make sure that the module opening in the box is published to the page the link is on. </li>\r\n</ul>','',1,8,'2009-10-12 22:44:23',335,'','2012-06-25 19:54:14',42,0,'0000-00-00 00:00:00','2009-10-12 22:44:23','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',35,28,'','',1,128,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(173,62,'Search Engine Optimized ','search-engine-optimized','<br/>\r\n<h3>SEO - Get your site noticed!</h3>\r\n<p><br /> Not only is this template beautifully designed but it is great for search engine optimization as well! What is SEO? It is simple the act of altering a web site so that it does well in the organic, crawler-based listings of search engines such as google.com. How does this template accomplish this? It&#39;s simple, the majority of your most valuable content is found in the main body of your site, through css we are able to alter the layout of the site and call the main content before the left and right columns are called. This allows for your content to be found first by search engines before it reaches your other content, which is vital in search engine optimization. This is a common feature this can be done with almost all of Shape 5 templates as well.</p>\r\n<p> </p>\r\n<div class=\"blue_box\"><strong>I like what I see! I want to <a href=\"http://www.shape5.com/join-now.html\" target=\"_top\">JOIN TODAY</a>.</strong></div>','',1,8,'2010-02-11 17:28:55',335,'','2012-06-25 19:54:14',42,0,'0000-00-00 00:00:00','2010-02-11 17:28:55','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\"}',12,16,'','',1,110,'',0,'*',''),(195,63,'Multibox','multibox','<br/>\r\n\r\n<div class=\"blue_box\">\r\n<a style=\"text-decoration:underline\" target=\"_blank\" href=\"http://www.shape5.com/joomla_tutorials.html\">\r\nFor a tutorial on how to setup this script be sure to view the Vertex Guide on our Tutorials page.</a>\r\n</div>\r\n\r\n\r\n<br/><h3>Features:</h3>\r\n\r\n<ul class=\"ul_bullet_small\">\r\n<li>Supports a range of multimedia formats: images, flash, video, mp3s, html!</li>\r\n<li>Auto detects formats or you can specify the format</li>\r\n<li>Html descriptions</li>\r\n<li>Enable/Disable page overlay when multibox pops up (via template parameters)</li>\r\n<li>Enable/Disable controls (via template parameters)</li>\r\n\r\n\r\n\r\n\r\n<br/>\r\n\r\n\r\n\r\n<p><strong><font size=\"2\">Images Example</font></strong></p>          \r\n\r\n<a href=\"http://www.shape5.com/demo/images/multibox1_lrg.jpg\" id=\"mb1\" class=\"s5mb\" title=\"Image #1:\">\r\n<img src=\"http://www.shape5.com/demo/images/multibox1.jpg\" style=\"margin-right:20px\" class=\"boxed\" alt=\"\" />\r\n</a>\r\n<div class=\"s5_multibox mb1\">Image #1. It can support <strong>html</strong>.</div>\r\n&nbsp;&nbsp;\r\n<a href=\"http://www.shape5.com/demo/images/multibox2_lrg.jpg\" id=\"mb2\" class=\"s5mb\" title=\"Image #2:\">\r\n<img src=\"http://www.shape5.com/demo/images/multibox2.jpg\" style=\"margin-right:20px\" class=\"boxed\" alt=\"\" />\r\n</a>\r\n<div class=\"s5_multibox mb2\">Image #2. It can support <strong>html</strong>.</div>\r\n&nbsp;&nbsp;\r\n<a href=\"http://www.shape5.com/demo/images/multibox3_lrg.jpg\" id=\"mb3\" class=\"s5mb\" title=\"Image #3:\">\r\n<img src=\"http://www.shape5.com/demo/images/multibox3.jpg\" class=\"boxed\" alt=\"\" />\r\n</a>\r\n<div class=\"s5_multibox mb3\">Image #3. It can support <strong>html</strong>.</div>\r\n\r\n\r\n\r\n<div style=\"clear:both\"></div>\r\n\r\n\r\n<p><strong><font size=\"2\">Separeate Group Images Example</font></strong></p>          \r\n\r\n<a href=\"http://www.shape5.com/demo/images/multibox1_lrg.jpg\" rel=\"[group1]\" id=\"mb9\" class=\"s5mb\" title=\"Image #1:\">\r\n<img src=\"http://www.shape5.com/demo/images/multibox1.jpg\" style=\"margin-right:20px\" class=\"boxed\" alt=\"\" />\r\n</a>\r\n<div class=\"s5_multibox mb9\">Image #1. It can support <strong>html</strong>.</div>\r\n&nbsp;&nbsp;\r\n<a href=\"http://www.shape5.com/demo/images/multibox2_lrg.jpg\" rel=\"[group1]\" id=\"mb10\" class=\"s5mb\" title=\"Image #2:\">\r\n<img src=\"http://www.shape5.com/demo/images/multibox2.jpg\" style=\"margin-right:20px\" class=\"boxed\" alt=\"\" />\r\n</a>\r\n<div class=\"s5_multibox mb10\">Image #2. It can support <strong>html</strong>.</div>\r\n&nbsp;&nbsp;\r\n<a href=\"http://www.shape5.com/demo/images/multibox3_lrg.jpg\" rel=\"[group1]\" id=\"mb11\" class=\"s5mb\" title=\"Image #3:\">\r\n<img src=\"http://www.shape5.com/demo/images/multibox3.jpg\" class=\"boxed\" alt=\"\" />\r\n</a>\r\n<div class=\"s5_multibox mb11\">Image #3. It can support <strong>html</strong>.</div>\r\n\r\n\r\n\r\n<div style=\"clear:both\"></div>\r\n\r\n\r\n\r\n\r\n\r\n<p><strong><font size=\"2\">Video Example:</font></strong></p>   \r\n\r\n<a href=\"http://www.youtube.com/v/VGiGHQeOqII\" id=\"youtube\" class=\"s5mb\" title=\"Youtube.com Video\">\r\nYoutube.com Video - CLICK ME\r\n</a>\r\n<div class=\"s5_multibox youtube\">UP: Carl and Ellie </div>\r\n\r\n<br/>\r\n<br/>\r\nYou can use the following video formats: flv, mov, wmv, real and swf.  Just insert the URL to the videos in the href of the hyperlink, here is an example of how we did this for a Youtube video:<br/>\r\n\r\n\r\n\r\n<br/>\r\nYouTube Tutorial:  Simply right click on a youtube video and copy the embed code, then paste into a text editor and look for the embed src and use that URL in your hyperlink.\r\n\r\n\r\n\r\n\r\n<br/><br/>\r\n\r\n\r\n<p><strong><font size=\"2\">MP3 Example:</font></strong></p>   \r\n\r\n<a href=\"http://www.shape5.com/demo/images/music.mp3\"  id=\"mb8\" class=\"s5mb\" title=\"Music\">MP3 example - CLICK ME</a>\r\n<div class=\"s5_multibox mb8\">mp3 example</div><br />\r\n\r\n\r\n\r\n\r\n<br/>\r\n\r\n\r\n<p><strong><font size=\"2\">iFrame:</font></strong></p>   \r\n\r\n<a href=\"http://www.getfirebug.com\" rel=\"width:790,height:600\" id=\"mb28\" class=\"s5mb\" title=\"getfirebug.com\">iFrame/HTML Example - CLICK ME</a>\r\n<div class=\"s5_multibox mb28\">getfirebug.com</div><br />\r\n\r\n\r\n\r\n\r\n<br/><br/>\r\n\r\n\r\n\r\n\r\n\r\n \r\n\r\n\r\n<div class=\"blue_box\">\r\nI like what I see! I want to <a href=\"http://www.shape5.com/join-now.html\" target=\"_top\"><strong>JOIN TODAY</strong></a>. </div>\r\n <br />','',1,8,'2010-08-13 18:18:32',335,'','2012-06-25 19:54:14',42,0,'0000-00-00 00:00:00','2010-08-13 18:18:32','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',33,15,'','',1,254,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(197,64,'Template Specific Options','template-specific-options','This template is built on the very powerful S5 Vertex Framework, which comes packed with amazing features! <a href=\"http://www.shape5.com/joomla/framework/vertex_framework.html\" target=\"blank\">Learn More About Vertex...</a> \r\n<br /><br />\r\nEvery template built on Vertex also comes with it&#39;s own unique template specific options applicable to that particular template such as highlight colors, social icons, and much more. These features are in addition to the standard functions of Vertex, and are still controlled through the very user friendly interface of Vertex. This page will document the features specific to this template.\r\n\r\n<br /><br /><br />\r\n<h2>Template Specific Configuration Interface of Vertex</h2><br />\r\nBelow is a screenshot that shows all the template specific features available in the user friendly Vertex admin:<br /><br />\r\n<img class=\"padded\" src=\"images/template_specific.png\"></img>\r\n\r\n\r\n<br /><br /><br />\r\n<h2>Optional Floating Header</h2><br />\r\nThe header area of this template that contains the logo and main menu has an optional floating optional. You can have the header stay static at the top of your browser as the user scrolls down the page (as this demo shows), or you can disable this option and have it stay at the top of the page only, and not scroll with the page. Note - this feature will disable at 750px for tablets and phones.\r\n<br /><br />\r\n<img class=\"padded\" src=\"images/header.jpg\"></img><br />\r\n\r\n\r\n\r\n<br /><br /><br />\r\n<h2>Optional Background For Component/Article Are</h2><br />\r\nThe main component and article area of this template has an optional white background. It can either have no background as shown throughout this demo, or you can apply a white background as shown below.\r\n<br /><br />\r\n<img class=\"padded\" src=\"images/background1.jpg\"></img><br /><br />\r\n<img class=\"padded\" src=\"images/background2.jpg\"></img><br />\r\n\r\n\r\n\r\n<br /><br /><br />\r\n<h2>Custom Highlight Colors</h2><br />\r\nNeed your own custom color scheme? Not a problem, this template comes with ultimate color control! With four highlight colors of your choice you can set titles, hyperlinks, buttons, backgrounds, and much more to any color you wish! This color can easily be set in the template configuration area. Below are some examples of custom color schemes created through the highlight color options. Below is a screenshot of this effect and some of the areas that you can alter.\r\n<br /><br />\r\n<img class=\"padded\" src=\"images/example1.jpg\"></img><br />\r\n\r\n\r\n\r\n\r\n<br /><br /><br />\r\n<h2>Social Icons</h2><br />\r\nEasily link to a social media site with the built in social icons found in the header of this template. Simply enter the url of your social site in the configuration and the icon will automatically appear. To disable an icon simply leave the url blank for that particular icon. \r\n<br /><br />\r\n<img class=\"padded\" src=\"images/social.jpg\"></img><br />\r\n\r\n\r\n\r\n<br /><br /><br />\r\n<h2>Small Menu</h2><br />\r\nOn this demo you can subtext on the first level parent items. If you choose not to use subtext on these links simply choose a small menu option and the menu will automatically down size.\r\n<br /><br />\r\n<img class=\"padded\" src=\"images/small_menu1.jpg\"></img><br />\r\n<br />\r\n<img class=\"padded\" src=\"images/small_menu2.jpg\"></img><br />\r\n\r\n\r\n\r\n\r\n<br /><br /><br />\r\n<h2>Custom Highlight Fonts</h2><br />\r\nChoose a custom highlight font powered by Google fonts. You can set a custom font for the S5 Flex Menu main level items and another custom font for most module titles. You can also change the default font under the General tab of Vertex.\r\n<br /><br />\r\n<img class=\"padded\" src=\"images/highlight_font.jpg\"></img><br />','',1,8,'2010-08-13 18:57:50',335,'','2012-10-13 20:43:58',42,0,'0000-00-00 00:00:00','2010-08-13 18:57:50','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',73,14,'','',1,237,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(204,65,'Google Fonts Enabled','google-fonts-enabled','Do you want your own custom font? Not a problem, this template comes with Google Fonts enabled, allowing you to pick from over a dozen font families for your website. In the template parameters area of the template you can choose your own custom font, and preview it from the Vertex interface. Below are some examples of the fonts available.<br/><br/>\r\n\r\n<img alt=\"\" src=\"http://www.shape5.com/demo/images/general/google_fonts.png\"></img>\r\n\r\n<br />\r\n<br /><br />\r\n\r\n<div class=\"blue_box\"><strong>I like what I see! I want to <a href=\"http://www.shape5.com/join-now.html\" target=\"_top\">JOIN TODAY</a>.</strong></div><br /></ul>','',1,8,'2010-10-08 19:08:51',335,'','2012-06-25 19:54:14',42,0,'0000-00-00 00:00:00','2010-10-08 19:08:51','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\"}',7,13,'','',1,42,'',0,'*',''),(212,68,'CSS Tableless Overrides','css-tableless-overrides','This template comes with CSS tabless overrides for the main Joomla content, overriding the default table layout. This makes your content much more accessible to search engines.\r\n<br /><br />\r\n<div class=\"blue_box\"><strong>I like what I see! I want to <a href=\"http://www.shape5.com/join-now.html\" target=\"_top\">JOIN TODAY</a>.</strong></div>','',1,8,'2010-12-13 23:29:23',335,'','2012-06-25 19:54:14',42,0,'0000-00-00 00:00:00','2010-12-13 23:29:23','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\"}',4,29,'','',1,32,'',0,'*',''),(214,69,'Fixed Side Tabs','fixed-side-tabs','This template includes a \"Fixed Tab\" option that you can enable and publish on your site and will show in a fixed position on either the left or right side of the screen. The great feature about the fixed tabs is that you can enter any text you desire and the text is automatically flipped vertically! This is great for search engines to read your text and also saves the hassle of creating an image with vertical text and placing it on the side of your site. The tabs are published site wide and can have the following options that can be changed via the template parameters area and can link to any URL that you desire.\r\n\r\n\r\n<br /><br /><h3>The following is a quick list of features: </h3></p>\r\n<ul class=\"ul_star\">\r\n<li>Change background to any hex color </li>\r\n<li>Change the border to any hex color</li>\r\n<li>Change the font to any hex color</li>\r\n<li>Set vertical position of each tab</li>\r\n<li>Set the height of each tab</li>\r\n<li>Set each tab to either the left or right of the screen</li>\r\n<li>Add a class to each fixed tab to enable s5 box or perhaps a lightbox or other 3rd party extension</li>\r\n<li>Add a URL to each fixed tab so onclick the URL loads</li>\r\n<li>Enter any text you desire</li>\r\n</ul>\r\n\r\n<br /><br />   <div class=\"blue_box\"><strong>I like what I see! I want to <a href=\"http://www.shape5.com/join-now.html\" target=\"_top\">JOIN TODAY</a>.</strong></div>','',1,8,'2010-12-13 23:40:43',335,'','2012-06-25 19:54:14',42,0,'0000-00-00 00:00:00','2010-12-13 23:40:43','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\"}',5,12,'','',1,26,'',0,'*',''),(227,70,'Menu Scroll To Section','menu-scroll-to-section','This template includes a scroll to feature that will scroll your page to a specified section of your site. All you have to do is create an external link in your menu manager and then in the URL area enter in any ID on your page. You can reference any of the following IDs in order:<br /><br />\r\n\r\n<ul class=\"ul_bullet_small\">\r\n<li>#s5_header_area1</li>\r\n<li>#s5_top_row1_area1</li>\r\n<li>#s5_top_row2_area1</li>\r\n<li>#s5_top_row3_area1</li>\r\n<li>#s5_center_area1</li>\r\n<li>#s5_bottom_row1_area1</li>\r\n<li>#s5_bottom_row2_area1</li>\r\n<li>#s5_bottom_row3_area1</li>\r\n<li>#s5_footer_area1</li>\r\n\r\n</ul>\r\n<br />\r\nScreenshot of admin area of an external menu item with DIV reference entered:<br /><br />\r\n\r\n<img border=\"0\" src=\"http://www.shape5.com/demo/images/general/scrollto.jpg\" style=\"\">','',1,8,'2011-06-10 21:35:45',335,'','2012-06-25 19:54:14',42,0,'0000-00-00 00:00:00','2011-06-10 21:35:45','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\"}',4,11,'','',1,26,'',0,'*',''),(228,71,'IE7 and 8 CSS3 Support','ie7-and-8-css3-support','This template includes limited support of CSS3 for IE7 and IE8. With the power of css3, websites can now be built much faster and with far \r\nless code. Design features such as gradients or shadows that used to be \r\ncreated and then called as images on the page are now simply called \r\nby css code. Transition effects that used to require full javascript libraries can \r\nnow be called with less than 1kb of text. Rounded corners that used to \r\nrequire upwards of eight wrapping div elements can now be done with a \r\nsingle element. What does this mean for you? Simple, a lightning fast website, \r\nthat becomes even more search engine friendly. \r\n\r\n<br /><br />Many modern browsers such as Firefox4 of IE9 already support CSS3 natively, but where does that leave IE7 and IE8? Thankfully a great solution called CSS PIE (Progressive Internet Explorer) has been introduced and is integrated into this template. Simply put, CSS PIE a script that upgrades IE7 and 8 to support most CSS3 formatting.  There are slight variations and some CSS3 formatting isn&#39;t supported, but overall it does a great job and allows us to extend CSS3 support to IE7 and 8.','',1,8,'2011-06-10 21:37:19',335,'','2012-06-25 19:54:14',42,0,'0000-00-00 00:00:00','2011-06-10 21:37:19','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\"}',2,10,'','',1,58,'',0,'*',''),(230,72,'Lazy Load Images','lazy-load-images','The lazy load script is a great way to save bandwidth and load your pages much faster. Images that are not visible on the initial page load are not loaded or downloaded until they come into the main viewing area. Once an image comes into view it is then downloaded and faded into visibility. Scroll down this page to see the script in action.\r\n\r\n<br /><br />\r\n\r\nSetup is very easy! By default this script is disabled, in order to enable it simply choose All Images or Individual Images from the drop down, as shown below from inside the template configuration page.\r\n\r\n<br /><br />\r\n\r\n<img class=\"padded\" src=\"http://www.shape5.com/demo/images/general/lazy_load.png\" alt=\"\"></img>\r\n\r\n<br /><br />\r\n\r\nAll images will load every standard image on the page with lazy load. There is no extra configuration or extra code to add with this configuration, it will just happen automatically. Individual images would be used if you want only certain images to load with this script and not all of them. To do this simply add class=\"s5_lazyload\" to the image like so:\r\n\r\n<br />\r\n\r\n<div class=\"code\">\r\n\r\n&lt;img class=&quot;s5_lazyload&quot; src=&quot;http://www.yoursite.com/image.jpg&quot;&gt;&lt;/img&gt;\r\n\r\n</div>\r\n\r\n<br /><br />\r\nThis script is compatible with Firefox3+, IE8+, Chrome14+, Safari5.05+, Opera 11.11+\r\n<br /><br />\r\n<h3>See the script in action:</h3>\r\n<br />\r\n\r\n<img src=\"http://www.shape5.com/demo/images/general/lazyload/lazy_load1.jpg\" alt=\"\" class=\"s5_lazyload padded\"></img>\r\n<img src=\"http://www.shape5.com/demo/images/general/lazyload/lazy_load2.jpg\" alt=\"\" class=\"s5_lazyload padded\"></img>\r\n<img src=\"http://www.shape5.com/demo/images/general/lazyload/lazy_load3.jpg\" alt=\"\" class=\"s5_lazyload padded\"></img>\r\n<img src=\"http://www.shape5.com/demo/images/general/lazyload/lazy_load4.jpg\" alt=\"\" class=\"s5_lazyload padded\"></img>\r\n<img src=\"http://www.shape5.com/demo/images/general/lazyload/lazy_load5.jpg\" alt=\"\" class=\"s5_lazyload padded\"></img>\r\n<img src=\"http://www.shape5.com/demo/images/general/lazyload/lazy_load6.jpg\" alt=\"\" class=\"s5_lazyload padded\"></img>\r\n<img src=\"http://www.shape5.com/demo/images/general/lazyload/lazy_load7.jpg\" alt=\"\" class=\"s5_lazyload padded\"></img>\r\n<img src=\"http://www.shape5.com/demo/images/general/lazyload/lazy_load8.jpg\" alt=\"\" class=\"s5_lazyload padded\"></img>\r\n<img src=\"http://www.shape5.com/demo/images/general/lazyload/lazy_load9.jpg\" alt=\"\" class=\"s5_lazyload padded\"></img>\r\n<img src=\"http://www.shape5.com/demo/images/general/lazyload/lazy_load10.jpg\" alt=\"\" class=\"s5_lazyload padded\"></img>','',1,8,'2011-08-12 18:35:45',335,'','2012-06-25 19:54:14',42,0,'0000-00-00 00:00:00','2011-08-12 18:35:45','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',17,9,'','',1,110,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(231,73,'Hide Article Component Area','hide-article-component-area','Did you ever need to create a page where this is no article present or no component to be shown, and only load modules? This template makes it all possible! From the template configuration page you can hide the main content area on any page on the site. \r\n\r\n<br /><br />\r\n\r\nBelow is a screenshot of this function from the configuration page, found under the General tab:\r\n\r\n<br /><br />\r\n\r\n<img class=\"padded\" src=\"http://www.shape5.com/demo/images/general/hide_articles.png\" alt=\"\"></img>\r\n\r\n<div style=\"clear:both; height:0px\"></div>','',1,8,'2011-08-12 18:37:35',335,'','2012-06-25 19:54:14',42,0,'0000-00-00 00:00:00','2011-08-12 18:37:35','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',8,8,'','',1,88,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(233,74,'S5 Drop Down Panel','s5-drop-down-panel','The S5 Drop Down Panel is a slide down panel that can be demo&#39;d at the top of this page. The panel itself contains six module positions. You may publish any module that you wish into these positions. It comes packed with features so be sure to check out the list and screenshot below.\r\n<br />\r\n<br />\r\nNote - If the responsive layout is enabled the drop down will disable when the screen size reaches 750px so that it does not interfere with the mobile menu bar\r\n\r\n<br />\r\n<br />\r\n<img alt=\"\" style=\"border:1px solid #CCCCCC\" class=\"padded\" src=\"http://www.shape5.com/demo/images/general/dropdown_tab.png\" />\r\n<div style=\"clear:both\"></div>\r\n<br />\r\n<ul class=\"ul_star\"> \r\n<li>Customize almost everything! Shadows, borders, gradient, opacity</li> \r\n<li>Contains 6 module positions drop_down_1, drop_down_2, drop_down_3, drop_down_4, drop_down_5 and drop_down_6</li>\r\n<li>Auto adjust to the height of your content</li> \r\n<li>Set your own open and close text</li> \r\n<li>Auto collapse if no modules are published to it</li>\r\n<li>And many more features!</li>\r\n</ul>\r\n<br />\r\n<br />\r\n<h3>Screenshot of Drop Down admin in template configuration area:</h3><br />\r\n<img alt=\"\" style=\"border:1px solid #CCCCCC\" class=\"padded\" src=\"http://www.shape5.com/demo/images/general/dropdown.png\" />\r\n\r\n<div style=\"clear:both; height:0px\"></div>','',1,8,'2011-08-13 14:54:51',335,'','2012-06-25 19:54:14',42,0,'0000-00-00 00:00:00','2011-08-13 14:54:51','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',16,7,'','',1,177,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(255,92,'3rd Party Component Compatibility','3rd-party-component-compatibility','This template is compatible with all the major 3rd party components available for Joomla. The following are just some of the ones available that work great with any Shape 5 template. A template itself should in no way hinder the functionality of a component. Although we haven&#39;t tested every single Joomla component available we can say quite confidently that this template will be compatible with any Joomla extension you use with it.</p>\r\n<p> </p>\r\n<p><img src=\"http://www.shape5.com/demo/images/general/3rdparty.png\" border=\"0\" /><br />And many more!','',1,8,'2012-02-09 19:24:02',335,'','2012-06-25 19:54:14',42,0,'0000-00-00 00:00:00','2012-02-09 19:24:02','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\"}',3,6,'','',1,79,'',0,'*',''),(256,93,'S5 Image and Content Fader','s5-image-and-content-fader','<p>This module can be viewed at the top of this page. This specific style of the module can only be used with this template. Publish your own content into each slide transition and for multiple slide transition effects, navigation arrows and also a drop down gallery tab that allows you to select a slide via a thumbnail. This module is fully responsive as well. The S5 Image and Content Fader v3 is powered by Mootools by default but still includes the S5 Effects library and allows you to use it in a \"legacy module\" if you are experiencing script conflicts. Best of all it&#39;s free!  <br /><br />NOTE: Legacy mode will display all your images, titles and slide text but includes limited functionality thus it does not include navigation arrows or the new drop down gallery tab.</p>\r\n\r\n<br />\r\n<br />\r\nThis module was designed only to work with the custom_1 position with this template.\r\n\r\n<br />\r\n<br />\r\n\r\n<p> </p>\r\n<p> </p>\r\n<h3>Features at a glance:</h3>\r\n<p> </p>\r\n<ul class=\"ul_star\">\r\n<li>Responsive layout compatible</li>\r\n<li>horizontal sliding transition</li>\r\n<li>Choose between 4 slide transitions: Fade, Contiuous Horiztonal, Fade Slide Left, Continuous Vertical</li>\r\n<li>Specify height and width of module</li>\r\n<li>Includes a gallery tab drop down to show all images</li>\r\n<li>Each image slide can have its own hyperlink</li>\r\n<li>Show up to 10 images at once</li>\r\n<li>Publish your own content to each picture slide</li>\r\n<li>Navigation arrows</li>\r\n<li>Not all slides require titles</li>\r\n<li>Change delay time</li>\r\n<li>Hide or show: Navigation arrows, thumbnail carousel and popup text</li>\r\n</ul>\r\n<p><br /><br /></p>\r\n<h3>Admin side of the module:</h3>\r\n<p><br /> <img src=\"images/imageadmin.png\" border=\"0\" /> <br /> <br /><br /></p>\r\n<div class=\"blue_box\">\r\nI like what I see! I want to <a href=\"../../join-now.html\" target=\"_top\"><strong>JOIN TODAY</strong></a>.</div>','',1,8,'2008-02-14 15:10:56',335,'','2012-10-13 19:25:04',42,0,'0000-00-00 00:00:00','2008-02-14 15:10:36','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"1\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',16,5,'','',1,47,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(276,127,'Sample Content','sample-content','<p style=\"text-align: center;\">This page is under development. Please check back soon.</p>\r\n<p style=\"text-align: center;\">&nbsp;</p>\r\n<p style=\"text-align: center;\"><img src=\"images/under_construction.png\" alt=\"under construction\" /></p>','',1,2,'2012-04-10 18:24:03',335,'','2013-10-29 09:18:18',335,0,'0000-00-00 00:00:00','2012-04-10 18:24:03','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',3,0,'','',1,153,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(277,129,'Sample Content','sample-content','<p style=\"text-align: center;\">This page is under development. Please check back soon.</p>\r\n<p style=\"text-align: center;\"><img src=\"images/under_construction.png\" alt=\"under construction\" /></p>','',1,38,'2012-04-10 18:24:03',335,'','2013-10-29 09:18:37',335,0,'0000-00-00 00:00:00','2012-04-10 18:24:03','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',3,0,'','',1,154,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(278,130,'Sample Content','sample-content-2','<p style=\"text-align: center;\">This page is under development. Please check back soon.</p>\r\n<p style=\"text-align: center;\"><img src=\"images/under_construction.png\" alt=\"under construction\" /></p>','',1,38,'2012-04-10 18:24:03',335,'','2013-10-29 09:18:55',335,0,'0000-00-00 00:00:00','2012-04-10 18:24:03','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',4,0,'','',1,75,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(279,131,'Sample Content','sample-content-3','<p style=\"text-align: center;\">This page is under development. Please check back soon.</p>\r\n<p style=\"text-align: center;\"><img src=\"images/under_construction.png\" alt=\"under construction\" /></p>','',1,38,'2012-04-10 18:24:03',335,'','2013-10-29 09:19:09',335,0,'0000-00-00 00:00:00','2012-04-10 18:24:03','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',3,0,'','',1,72,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(287,140,'Optional Responsive Layout','responsive-layout','Responsive design at its most elementary definition is simply the use of css media queries and some javascript to rearrange a website\'s layout to fit multiple screen sizes. This can range from a wide screen monitor down to the smallest of smart phones. It is done all through the same site, same installation, sharing the same files, and no extra layouts needed as in the past. Unlike many pixel grid based templates, Shape5 Vertex templates are already built on a fluid width layout based on percentages, with an optional pixel width wrapper, which is what responsive layouts require. Because of this Vertex templates do not require a responsive layout, instead it is completely optional! That\'s right, if you\'re uncomfortable with responsive layouts or it won\'t work with your site, then simply turn it off and use the standard fixed or fluid width layout instead!\r\n<br /><br />\r\n<div class=\"blue_box\">\r\n<a style=\"text-decoration:underline\" target=\"_blank\" href=\"http://www.shape5.com/joomla_tutorials.html\">\r\nBe sure to visit our Tutorials page and download our Responsive Best Practices guide for useful responsive layout tips.</a>\r\n</div>\r\n<br />\r\n\r\n\r\n<h3>See It Live On Responsinator.com</h3>\r\n<a target=\"_blank\" href=\"http://responsinator.com/?url=http%3A%2F%2Fwww.shape5.com%2Fdemo%2Fnew_vision\">Open this website on responsinator.com to see its layout on multiple devices.</a>\r\n<br /><br />\r\n\r\n\r\n\r\n<h3>What Makes The Vertex Responsive Layout The Best and Most Flexible?</h3>\r\n<ul>\r\n<li>The responsive layout is completely optional, don\'t use it if you don\'t want it!</li>\r\n<li>Virtually no javascript. The only javascript used is for the mobile bar effects and to add responsive capabilites to IE7. We believe that javascript should only be used as a last resort.</li>\r\n<li>Start with a fixed or fluid layout.</li>\r\n<li>Optional IE7/8 responsive layout.</li>\r\n<li>Very easy to understand layout, which allows you to setup your site with very little effort.</li>\r\n<li>Fully customizable mobile bar styling.</li>\r\n<li>Hide divs, modules and content easily with hide classes at specified screen sizes.</li>\r\n<li>Wide screen support options.</li>\r\n<li>Multiple options for fluid width images.</li>\r\n<li>And much more!</li>\r\n</ul>\r\n<br />\r\n\r\n\r\n\r\n<h3>Easy To Understand Layout</h3>\r\nOne of the biggest advantages to the Vertex Responsive Layout is that we start the layout as if it were designed for a desktop viewer, and then simply reduce, modify, or remove certain sections or font sizes based on the size of the user\'s screen. This is all done through css media queries, and is all done automatically for you! \r\n<br /><br />\r\nThe best way to see this approach, is simply resize your browser to see it all take effect.\r\n<br /><br />\r\nSome responsive designs simply use a series of floating divs that re-arrange themselves on the page and add columns as the screen width increases or decreases. The biggest con to this approach is it can become very confusing as to where your content will actually exist on any given screen; making it very hard to create a specific layout and confusing for a client; especially those with specific product and content placement needs. \r\n<br /><br />\r\nOur approach is much easier to understand. The site will always keep its core layout shown <a href=\"index.php/features-mainmenu-47/template-features/95-module-positions\">here</a>. When the screen changes it will adjust as described below. The majority of rows and columns will not change their basic styling or positions until they reach the mobile version. Again, only minor adjustments are made on varying screen sizes so that you always know what your site will look like and where content will be placed!<br /><br />\r\n<ul>\r\n<li>If the column width option is enabled, the body is set to fluid, and the body width reaches 1300px the column sizes will increase by 30%. If it reaches 1900px they will increase by 60%. If it reaches 2500px they will increase by 90%. If you are using the max-body width calculations the column widths will be based off of this setting instead of screen width.</li>\r\n<li>Between 971px and 1300px no changes will occur to the layout. This is the standard desktop view of the template.</li>\r\n<li>At 970px (a standard 10 inch tablet screen) the body width will become fluid and will fill most of the viewing area. If the inset columns are used on the page they will be combined into their adjacent columns to create one column to increase the center column\'s available width.</li>\r\n<li>At 750px (a standard 7 inch tablet screen) the mobile navigation bar will appear for easier navigation. If the column width option for small tablets is enabled you can set the center column to stay their original sizes, reduce the width by 20%, or stack into one column.</li>\r\n<li>At 580px (a standard mobile device size) the entire body will become one single column and module stack on top of each other. Some adjustments to the header and footer will occur.</li>\r\n</ul>\r\n<br />\r\n\r\nBelow are illustrations of the center columns only in the scenarios described above.\r\n<br /><br />\r\n\r\n\r\n<img class=\"padded\" alt=\"\" src=\"http://www.shape5.com/demo/images/general/responsive_columns.png\"></img>\r\n\r\n<br /><br />\r\n\r\n\r\n\r\n\r\nBelow you will find a screenshot of the responsive options available in the Vertex framework. Below that you will find documentation for each feature shown.\r\n<br /><br />\r\n<img class=\"padded\" alt=\"\" src=\"http://www.shape5.com/demo/images/general/responsive1.png\"></img>\r\n<br /><br />\r\n\r\n\r\n<h3>General Layout</h3>\r\nThe general layout options are the ones starting with Enable Font Resizer? and ending with Right Inset Width. These parameters are the core layout options that apply to all templates, whether responsive is enabled or not. Configuring this area is the first step in configuring a responsive layout. You can choose to set the site to either a fixed pixel width or fluid percentage width, the responsive layout will work with either option. If you are using the fluid width option we recommend enabling the Max Body Width option so that that your site does not go above the set pixels; this helps keep your site looking proportionate across very wide screen.\r\n<br /><br />\r\n\r\n\r\n\r\n<h3>Enable The Responsive Layout</h3>\r\nIf you wish to use the responsive layout simply turn on the switch and the Vertex framework will take care of the rest! It\'s really that simple! Notice there is a separate switch for IE7 and IE8. This browser does not support css media queries natively, which is what makes responsive layouts possible. In order to add this functionality the template must use javascript, which can affect the performance of a website. With this added javascript IE7 and IE8 will support the responsive layout, but we highly recommend leaving it turned off. Keep in mind that the primary target for responsive websites is tablet and mobile devices, where IE7 and IE8 do not exist.\r\n<br /><br />\r\n\r\n\r\n\r\n<h3>Hide Tablet and Mobile Divs</h3>\r\nOne of the biggest obstacles to overcome when designing a responsive layout site is that not all content, images and extensions were designed to work with responsive layouts. That means that sometimes you need the ability to hide a specific element on only certain sized screens, so that something doesn\'t break the site\'s layout and everything looks proportionate. We\'ve made that all possible and very easy to do for you with hiding classes! There are three main ways to hide content on different size screens, and they are documented <a href=\"index.php/features-mainmenu-47/template-features/hide-divs-and-modules\">here</a>.\r\n<br /><br />\r\n\r\n\r\n\r\n<h3>Column Widths</h3>\r\nIf you are designing your site for very wide screens as well as standard desktop screens, then consider enabling this feature. If the body width is set to fluid then the left, left_inset, left_top, left_bottom, right, right_inset, right_top, and right_bottom positions will increase their widths for larger screens to keep everything proportionate. If the body width reaches 1300px this size will increase by 30%. If it reaches 1900px it will increase by 60%. If it reaches 2500px it will increase by 90%. If you are using the max-body width calculations will be based off of this setting instead of screen width. The original widths are calculated in the general layout area.\r\n<br /><br />\r\nFor smaller screens it is often hard to make all of your content fit in the main center columns. If the screen size reaches 750px you have the option to keep the widths of the center columns how they are, reduce them by 20%, or stack them on top of each other in a single column. This option is meant for 7 inch tablets and effects the main center columns only. At 580px all positions will become a single column for mobile devices.\r\n<br /><br />\r\n\r\n\r\n<h3>Mobile Bars</h3>\r\nWhen the screen size reaches 750px wide (anything smaller than a standard 10 inch tablet), a navigation bar will appear across the top of the site and the bottom. This bar replaces the main menu, login, register, and search, for easier user on mobile devices. In the configuration you can choose what to enable on these bars as well as change the colors and style however you would like.\r\n<br /><br />\r\n<img class=\"padded\" alt=\"\" src=\"http://www.shape5.com/demo/images/general/responsive2.jpg\"></img>\r\n<br /><br />\r\n<img class=\"padded\" alt=\"\" src=\"http://www.shape5.com/demo/images/general/responsive3.jpg\"></img>\r\n<br /><br />\r\n\r\n\r\n\r\n<h3>Mobile Links</h3>\r\nEven though this is a responsive layout and there is no separate layout page for mobile devices, that does not mean that your site\'s viewers will understand this or even know what a responsive layout is. It has become a standard for websites that use a mobile layout to have a link to view the desktop view of the website, and this is what your site viewers will expect to see. This link simply turns off the responsive configuration using a cookie and calls the website like a standard desktop would when viewing in mobile. There is then a link to return back to the mobile view of the site presented.\r\n<br /><br />\r\n\r\n\r\n<div class=\"blue_box\">\r\nI like what I see! I want to <a href=\"http://www.shape5.com/join-now.html\" target=\"_top\"><strong>JOIN TODAY</strong></a>. </div>','',1,8,'2012-06-11 21:25:00',335,'','2012-10-13 18:29:42',42,0,'0000-00-00 00:00:00','2012-06-11 21:25:00','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',31,4,'','',1,124,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(288,141,'Info Slide','info-slide','The info slide script is a great way to display your content to your customers! It will place a sliding text box over any image on the page. It can be placed inside of content or modules. It will also automatically adjust to any size screen size on window resize. See below for a demonstration.\r\n\r\n\r\n<br /><br />\r\n<div class=\"blue_box\">\r\n<a style=\"text-decoration:underline\" target=\"_blank\" href=\"http://www.shape5.com/joomla_tutorials.html\">\r\nFor a tutorial on how to setup this script be sure to view the Vertex Guide on our Tutorials page.</a>\r\n</div>\r\n\r\n<br />\r\n\r\n<div class=\"s5_is\" style=\"float:left; width:31%; margin-right:15px; margin-bottom:15px\">\r\n	<img alt=\"\" src=\"http://www.shape5.com/demo/images/general/lazyload/lazy_load1.jpg\"></img>\r\n	<div class=\"s5_is_slide\">\r\n	<h3>Example Slide</h3>\r\n	This is dummy text. You can add any text or html markup here.\r\n	</div>\r\n</div>\r\n\r\n<div class=\"s5_is\" style=\"float:left; width:31%; margin-right:15px; margin-bottom:15px\">\r\n	<img alt=\"\" src=\"http://www.shape5.com/demo/images/general/lazyload/lazy_load2.jpg\"></img>\r\n	<div class=\"s5_is_slide\">\r\n	<h3>Example Slide</h3>\r\n	This is dummy text. You can add any text or html markup here.\r\n	</div>\r\n</div>\r\n\r\n<div class=\"s5_is\" style=\"float:left; width:31%; margin-right:15px; margin-bottom:15px\">\r\n	<img alt=\"\" src=\"http://www.shape5.com/demo/images/general/lazyload/lazy_load3.jpg\"></img>\r\n	<div class=\"s5_is_slide\">\r\n	<h3>Example Slide</h3>\r\n	This is dummy text. You can add any text or html markup here.\r\n	</div>\r\n</div>\r\n\r\n<div class=\"s5_is\" style=\"float:left; width:31%; margin-right:15px; margin-bottom:15px\">\r\n	<img alt=\"\" src=\"http://www.shape5.com/demo/images/general/lazyload/lazy_load4.jpg\"></img>\r\n	<div class=\"s5_is_slide\">\r\n	<h3>Example Slide</h3>\r\n	This is dummy text. You can add any text or html markup here.\r\n	</div>\r\n</div>\r\n\r\n<div class=\"s5_is\" style=\"float:left; width:31%; margin-right:15px; margin-bottom:15px\">\r\n	<img alt=\"\" src=\"http://www.shape5.com/demo/images/general/lazyload/lazy_load5.jpg\"></img>\r\n	<div class=\"s5_is_slide\">\r\n	<h3>Example Slide</h3>\r\n	This is dummy text. You can add any text or html markup here.\r\n	</div>\r\n</div>\r\n\r\n<div class=\"s5_is\" style=\"float:left; width:31%; margin-right:15px; margin-bottom:15px\">\r\n	<img alt=\"\" src=\"http://www.shape5.com/demo/images/general/lazyload/lazy_load6.jpg\"></img>\r\n	<div class=\"s5_is_slide\">\r\n	<h3>Example Slide</h3>\r\n	This is dummy text. You can add any text or html markup here.\r\n	</div>\r\n</div>\r\n\r\n<div class=\"s5_is\" style=\"float:left; width:31%; margin-right:15px; margin-bottom:15px\">\r\n	<img alt=\"\" src=\"http://www.shape5.com/demo/images/general/lazyload/lazy_load7.jpg\"></img>\r\n	<div class=\"s5_is_slide\">\r\n	<h3>Example Slide</h3>\r\n	This is dummy text. You can add any text or html markup here.\r\n	</div>\r\n</div>\r\n\r\n<div class=\"s5_is\" style=\"float:left; width:31%; margin-right:15px; margin-bottom:15px\">\r\n	<img alt=\"\" src=\"http://www.shape5.com/demo/images/general/lazyload/lazy_load8.jpg\"></img>\r\n	<div class=\"s5_is_slide\">\r\n	<h3>Example Slide</h3>\r\n	This is dummy text. You can add any text or html markup here.\r\n	</div>\r\n</div>\r\n\r\n<div class=\"s5_is\" style=\"float:left; width:31%; margin-right:15px; margin-bottom:15px\">\r\n	<img alt=\"\" src=\"http://www.shape5.com/demo/images/general/lazyload/lazy_load9.jpg\"></img>\r\n	<div class=\"s5_is_slide\">\r\n	<h3>Example Slide</h3>\r\n	This is dummy text. You can add any text or html markup here.\r\n	</div>\r\n</div>\r\n\r\n\r\n\r\n\r\n\r\n<div style=\"clear:both\"></div>\r\n\r\n<br/>\r\n\r\n\r\n\r\n\r\n\r\n \r\n\r\n\r\n<div class=\"blue_box\">\r\nI like what I see! I want to <a href=\"http://www.shape5.com/join-now.html\" target=\"_top\"><strong>JOIN TODAY</strong></a>. </div>\r\n','',1,8,'2012-06-11 21:25:29',335,'','2012-06-25 19:54:14',42,335,'2013-10-29 14:57:16','2012-06-11 21:25:29','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',15,3,'','',1,93,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(289,142,'Hide Divs, Content, and Modules','hide-divs-and-modules','One of the biggest obstacles to overcome when designing a responsive layout site is that not all content, images and extensions were designed to work with responsive layouts. That means that sometimes you need the ability to hide a specific element on only certain sized screens, so that something doesn\'t break the site\'s layout and everything looks proportionate. We\'ve made that all possible and very easy to do for you with hiding classes! There are three main ways to hide content on different size screens, and they are documented below. Please note that these classes are only enabled when the responsive layout is enabled.\r\n<br /><br />\r\n<div class=\"blue_box\">\r\n<a style=\"text-decoration:underline\" target=\"_blank\" href=\"http://www.shape5.com/joomla_tutorials.html\">\r\nBe sure to visit our Tutorials page and download our Responsive Best Practices guide for useful responsive layout tips.</a>\r\n</div>\r\n<br /><br />\r\n<h3>Hide Sections of the Template via the Template Configuration</h3>\r\nThis is the simplest way to hide an area of the template is to use the template interface to easily select areas of the template that you want to hide on tablet sized screens (970px and less) or mobile screens (580px or less). Simply select the area that you want to hide and the Vertex framework takes care of the rest! These fields do work independent of each other, so if you want to hide something on both tablet and mobile sized screens you must select the same area on both fields.\r\n<br /><br />\r\n<img class=\"padded\" src=\"http://www.shape5.com/demo/images/general/hide_divs1.png\"></img>\r\n<br /><br />\r\nIMPORTANT - If you turn off a column position such as right or right_inset something else must be in the same column or the layout will not work. For example you can turn off right_inset and keep right, but you cannot turn off both unless something is publihsed to right_top or right_bottom as well.\r\n\r\n\r\n<br /><br />\r\n<h3>Hide Specific Modules via the Hide Classes</h3>\r\nIf you have only a specific module that you would like to hide at certain screen sizes, and not an entire section of the template, this is the best approach. A hide class is a class that can be applied to any element on the page and hides that particular element at certain screen sizes. Classes range in 100px increments for large screens and 50px increments for small screens. <strong>Below are some examples, and at the very bottom of this page there is a list of all the available hide classes.</strong> Use these sparingly if you can. As a recommendation, the primary target of these classes should focus on tablet and mobile sized screens. Wide screen monitors vary in size so it\'s much harder to use these classes correctly for large monitors. Tablet and mobile devices are much more consistent in size so it is much easier to apply the smaller hide classes.\r\n<br /><br />\r\nFor example, say you want to hide a specific module when the screen sizes reaches 900px wide, and remain hidden for any screen below 900px. Simply add class=hide_900 to the title of the module like this:\r\n<br /><br />\r\n<img class=\"padded\" src=\"http://www.shape5.com/demo/images/general/hide_divs2.png\"></img>\r\n<br /><br />\r\nThe class is simply put into the title of the module. There must be a space just before class= , and don\'t worry, the class area of the title won\'t actually show on the live site, it\'s only shown in the backend. It must be entered exactly as shown above. The title can be published or unpublished, it does not matter which. Simply adding the classes to the title will apply the classes to the entire module.\r\n<br /><br />\r\nWhat if you want it to hide the module only for a certain range? That\'s easy just add _only to the end of the class name. hide_900_only will only hide that element from 900px to the next increment in the hide classes, which is 850px. So it will only be hidden from 850px to 900px. You can also add multiple classes to the title like this class=hide_900_only hide_850_only which will apply both classes to the module.\r\n<br /><br />\r\nWhat if you want to hide the module and then show it again later? That\'s simple, use show_ in the class instead of hide_. This will make the module show for the specified size no matter what other settings are on the module. So if you want to hide the module from 1000px and below, but you want to show it again later then do something like the following class=hide_1000 show_600. This will hide the module from 600px to 1000px.\r\n<br /><br />\r\nIs there a more simple way? Yes, of course, the above directions are for experienced users who want to tweak their content for every available screen size. If you don\'t want to mess around with specific window sizes simply use the following classes instead, which have preset screen sizes applied to them:\r\n<br /><br />\r\nhide_wide_screen<br />\r\nhide_standard_screen<br />\r\nhide_large_tablet<br />\r\nhide_small_tablet<br />\r\nhide_mobile<br />\r\nshow_wide_screen<br />\r\nshow_standard_screen<br />\r\nshow_large_tablet<br />\r\nshow_small_tablet<br />\r\nshow_mobile<br />\r\n\r\n\r\n<br />\r\n<h3>Hide Specific Content via the Hide Classes</h3>\r\nIf you have only specific content or images within an article or module that you want to hide then use the same hide classes described above, but wrap that specific content inside of the class instead of applying it to the entire module. For example, in the image below, the third paragraph will hide at 900px and then show again at 700px.\r\n\r\n<br /><br />\r\n<img class=\"padded\" src=\"http://www.shape5.com/demo/images/general/hide_divs3.png\"></img>\r\n<br /><br />\r\n\r\n\r\n\r\n\r\n<h3>Available Hide Classes</h3>\r\nAll the available hide classes are listed below. Note there is a break at 970px and 580px to accommodate tablet and mobile sized screens.\r\n\r\n<br /><br />@media screen and (max-width: 1600px){<br />    .hide_1600 {<br />    display:none;<br />    }<br />}    <br /><br />@media screen and (min-width:1500px) and (max-width: 1600px){<br />    .hide_1600_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 1600px){<br />    .show_1600 {<br />    display:inline;<br />    }<br />}    <br /><br />@media screen and (min-width:1500px) and (max-width: 1600px){<br />    .show_1600_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (max-width: 1500px){<br />    .hide_1500 {<br />    display:none;<br />    }<br />}    <br /><br />@media screen and (min-width:1400px) and (max-width: 1500px){<br />    .hide_1500_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 1500px){<br />    .show_1500 {<br />    display:inline;<br />    }<br />}    <br /><br />@media screen and (min-width:1400px) and (max-width: 1500px){<br />    .show_1500_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (max-width: 1400px){<br />    .hide_1400 {<br />    display:none;<br />    }<br />}    <br /><br />@media screen and (min-width:1300px) and (max-width: 1400px){<br />    .hide_1400_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 1400px){<br />    .show_1400 {<br />    display:inline;<br />    }<br />}    <br /><br />@media screen and (min-width:1300px) and (max-width: 1400px){<br />    .show_1400_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (max-width: 1300px){<br />    .hide_1300 {<br />    display:none;<br />    }<br />}    <br /><br />@media screen and (min-width:1200px) and (max-width: 1300px){<br />    .hide_1300_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 1300px){<br />    .show_1300 {<br />    display:inline;<br />    }<br />}    <br /><br />@media screen and (min-width:1200px) and (max-width: 1300px){<br />    .show_1300_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (max-width: 1200px){<br />    .hide_1200 {<br />    display:none;<br />    }<br />}    <br /><br />@media screen and (min-width:1100px) and (max-width: 1200px){<br />    .hide_1200_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 1200px){<br />    .show_1200 {<br />    display:inline;<br />    }<br />}    <br /><br />@media screen and (min-width:1100px) and (max-width: 1200px){<br />    .show_1200_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (max-width: 1100px){<br />    .hide_1100 {<br />    display:none;<br />    }<br />}    <br /><br />@media screen and (min-width:1000px) and (max-width: 1100px){<br />    .hide_1100_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 1100px){<br />    .show_1100 {<br />    display:inline;<br />    }<br />}    <br /><br />@media screen and (min-width:1000px) and (max-width: 1100px){<br />    .show_1100_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (max-width: 1000px){<br />    .hide_1000 {<br />    display:none;<br />    }<br />}    <br /><br />@media screen and (min-width:900px) and (max-width: 1000px){<br />    .hide_1000_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 1000px){<br />    .show_1000 {<br />    display:inline;<br />    }<br />}    <br /><br />@media screen and (min-width:900px) and (max-width: 1000px){<br />    .show_1000_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (max-width: 970px){<br />    .hide_970 {<br />    display:none;<br />    }<br />}    <br /><br />@media screen and (min-width:900px) and (max-width: 970px){<br />    .hide_970_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 970px){<br />    .show_970 {<br />    display:inline;<br />    }<br />}    <br /><br />@media screen and (min-width:900px) and (max-width: 970px){<br />    .show_970_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (max-width: 900px){<br />    .hide_900 {<br />    display:none;<br />    }<br />}    <br /><br />@media screen and (min-width:850px) and (max-width: 900px){<br />    .hide_900_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 900px){<br />    .show_900 {<br />    display:inline;<br />    }<br />}    <br /><br />@media screen and (min-width:850px) and (max-width: 900px){<br />    .show_900_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (max-width: 850px){<br />    .hide_850 {<br />    display:none;<br />    }<br />}    <br /><br />@media screen and (min-width:800px) and (max-width: 850px){<br />    .hide_850_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 850px){<br />    .show_850 {<br />    display:inline;<br />    }<br />}    <br /><br />@media screen and (min-width:800px) and (max-width: 850px){<br />    .show_850_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (max-width: 800px){<br />    .hide_800 {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (min-width:750px) and (max-width: 800px){<br />    .hide_800_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 800px){<br />    .show_800 {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (min-width:750px) and (max-width: 800px){<br />    .show_800_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (max-width: 750px){<br />    .hide_750 {<br />    display:none;<br />    }<br />}    <br /><br />@media screen and (min-width:700px) and (max-width: 750px){<br />    .hide_750_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 750px){<br />    .show_750 {<br />    display:inline;<br />    }<br />}    <br /><br />@media screen and (min-width:700px) and (max-width: 750px){<br />    .show_750_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (max-width: 700px){<br />    .hide_700 {<br />    display:none;<br />    }<br />}    <br /><br />@media screen and (min-width:650px) and (max-width: 700px){<br />    .hide_700_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 700px){<br />    .show_700 {<br />    display:inline;<br />    }<br />}    <br /><br />@media screen and (min-width:650px) and (max-width: 700px){<br />    .show_700_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (max-width: 650px){<br />    .hide_650 {<br />    display:none;<br />    }<br />}    <br /><br />@media screen and (min-width:600px) and (max-width: 650px){<br />    .hide_650_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 650px){<br />    .show_650 {<br />    display:inline;<br />    }<br />}    <br /><br />@media screen and (min-width:600px) and (max-width: 650px){<br />    .show_650_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (max-width: 600px){<br />    .hide_600 {<br />    display:none;<br />    }<br />}    <br /><br />@media screen and (min-width:580px) and (max-width: 600px){<br />    .hide_600_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 600px){<br />    .show_600 {<br />    display:inline;<br />    }<br />}    <br /><br />@media screen and (min-width:580px) and (max-width: 600px){<br />    .show_600_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (max-width: 579px){<br />    .hide_580 {<br />    display:none;<br />    }<br />}    <br /><br />@media screen and (min-width:550px) and (max-width: 579px){<br />    .hide_580_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 579px){<br />    .show_580 {<br />    display:inline;<br />    }<br />}    <br /><br />@media screen and (min-width:550px) and (max-width: 579px){<br />    .show_580_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (min-width:1300px) and (max-width: 50000px){<br />    .hide_wide_screen {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (min-width:971px) and (max-width: 1299px){<br />    .hide_standard_screen {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (min-width:750px) and (max-width: 970px){<br />    .hide_large_tablet {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (min-width:580px) and (max-width: 750px){<br />    .hide_small_tablet {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (min-width:580px) and (max-width: 750px){<br />    .hide_small_tablet {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 579px){<br />    .hide_mobile {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (min-width:1300px) and (max-width: 50000px){<br />    .show_wide_screen {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (min-width:971px) and (max-width: 1299px){<br />    .show_standard_screen {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (min-width:750px) and (max-width: 970px){<br />    .show_large_tablet {<br />    display:inline !important;<br />    }<br />}<br /><br />@media screen and (min-width:580px) and (max-width: 750px){<br />    .show_small_tablet {<br />    display:inline !important;<br />    }<br />}<br /><br />@media screen and (max-width: 579px){<br />    .show_mobile {<br />    display:inline !important;<br />    }<br />}\r\n\r\n<br /><br />\r\n\r\n\r\n\r\n<p><br /></p>\r\n<div class=\"blue_box\"><strong>I like what I see! I want to <a href=\"http://www.shape5.com/join-now.html\" target=\"_top\">JOIN TODAY</a>.</strong></div>\r\n<br />','',1,8,'2012-06-11 21:26:08',335,'','2012-06-25 19:54:14',42,0,'0000-00-00 00:00:00','2012-06-11 21:26:08','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',23,2,'','',1,90,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(290,143,'Built In File Compression','built-in-file-compression','<p>Increase speed and performance by compressing core template CSS and Javascript files to much smaller sizes than the original! Enabling compression is a great way to boost your site\'s performance. It simply combines css and js into consolidated files. This reduces the downloads sizes and reduces the numbers of calls to your server, to dramatically help your site\'s overall performance. No data is lost during this process, just simply made smaller. Please note that this compression will only compress core template files, not third party files or files from extensions.</p>\r\n<p><br /> <img class=\"padded\" src=\"http://www.shape5.com/demo/images/general/file_compression.jpg\" border=\"0\" alt=\"\" /></p>\r\n<div style=\"clear: both;\"> </div>\r\n<p><br /><br /></p>\r\n<div class=\"red_box\"><span class=\"alert\">Note: Because this feature uses cached versions of your javascript and css this plugin should not be used while developing your site and should only be enabled after you have completed your site. <br /><br /> Gzip must be installed on your server and enabled in PHP in order to function.</span></div>\r\n<p> </p>\r\n<p><strong><span style=\"font-size: large;\">See It In Action!</span></strong></p>\r\n<p>Without Compression Enabled:</p>\r\n<p><img class=\"padded\" src=\"http://www.shape5.com/demo/images/general/compression_without.png\" border=\"0\" /></p>\r\n<p>With Compression nabled:</p>\r\n<p><img class=\"padded\" src=\"http://www.shape5.com/demo/images/general/compression_with.png\" border=\"0\" /></p>\r\n<p> </p>\r\n<div class=\"blue_box\"><strong>I like what I see! I want to <a href=\"http://www.shape5.com/join-now.html\" target=\"_top\">JOIN TODAY</a>.</strong></div>\r\n<p> </p>','',1,8,'2012-06-11 21:26:24',335,'','2012-06-25 19:54:14',42,0,'0000-00-00 00:00:00','2012-06-11 21:26:24','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',12,1,'','',1,90,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(291,150,'Stock Photography','stock-photography','All content and images shown on this site is for demo, presentation purposes only. This site is intended to exemplify a live website and does not make any claim of any kind to the validity of non-Shape5 content, images or posts published. Stock photography and icons were purchased from <a href=\"http://www.shutterstock.com\" target=\"_blank\">shutterstock.com</a> for this demo only, and is not included with this template. You may not use these items for your own use without first purchasing them from their copyright owner. Links will be provided for some images if you wish to purchase them from their copyright owners. ','',1,8,'2012-06-30 12:33:15',335,'','2012-08-13 20:13:04',42,0,'0000-00-00 00:00:00','2012-06-30 12:33:15','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',3,0,'','',1,83,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(296,156,'Reach your dream jobs now','beautiful-design-and-flexbile-features','<p><img class=\"padded\" style=\"width: 200px; margin-bottom: 10px; margin-right: 10px; float: left;\" src=\"images/article.jpg\" alt=\"article\" width=\"200px\" /> Philippine Overseas Employment Center (POEC) envisions to be the leading contributor in the economic development of Filipino families in the Philippines by providing job opportunities abroad among Filipinos. Guided by its vision and determined by its principle, POEC links job seekers and employers.</p>\r\n','\r\n<p>.</p>',1,20,'2013-10-28 19:34:00',335,'','2013-10-29 08:43:35',335,0,'0000-00-00 00:00:00','2013-10-28 19:34:00','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',37,0,'','',1,159,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',1,'*',''),(297,162,'About Us','about-us','<p><strong>Philippine Overseas Employment Center (POEC)</strong></p>\r\n<p>&nbsp;</p>\r\n<p><strong>Vision:</strong></p>\r\n<p>We envision to harmoniously link the employers and employees effectively by stretching the avenue for jobs and business opportunities for the people in the Philippines and around the globe.</p>\r\n<p>&nbsp;</p>\r\n<p><strong>Mission:</strong></p>\r\n<p>Guided by this vision, we commit ourselves to provide avenue for job and business opportunities, both for the competent, deserving and trustworthy Filipino employees/workers and reliable employers/companies worldwide.</p>\r\n<p>&nbsp;</p>\r\n<p><strong>Objective:</strong></p>\r\n<p>Anchored upon our vision and mission, the Philippine Overseas Employment Center (POEC) seek to equip our stakeholders with the technological knowledge for effective and efficient delivery of quality employees/employers through website linkages services, thus; we provide data bank for the Filipino Applicants/Jobseekers and also for employers/recruiters.</p>\r\n<p>&nbsp;</p>','',1,47,'2013-10-29 12:00:01',335,'','0000-00-00 00:00:00',0,0,'0000-00-00 00:00:00','2013-10-29 12:00:01','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,1,'','',1,115,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(298,163,'Frequenty Asked Questions by Employers','frequenty-asked-questions-by-employers','<p><strong>Q: <em>Why should I register?</em></strong></p>\r\n<p><strong>A:</strong> You need to register your Company to be able to access any of the restircted services we provide: job posting, resume search, and many more including the listing of your Company Profile page in our directory. Most companies spend out a lot of money for their manpower recruitment and with our services, you can outsource your manpower requirement.</p>\r\n<p>&nbsp;</p>\r\n<p><strong>Q. <em>How much does registration cost?</em></strong></p>\r\n<p><strong>A. </strong>Registration&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p><strong>Q. <em>How long does it take for my new account to activate?</em></strong></p>\r\n<p>A. Your account will be fully operational immediately after you finished fillling-up the online registration form and activated your account through the self-activation link that will be sent to you after a successful registration.</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>','',1,47,'2013-10-29 12:14:38',335,'','2013-10-29 12:25:50',335,0,'0000-00-00 00:00:00','2013-10-29 12:14:38','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',3,0,'','',1,119,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*','');
/*!40000 ALTER TABLE `jom_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_content_frontpage`
--

DROP TABLE IF EXISTS `jom_content_frontpage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_content_frontpage` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_content_frontpage`
--

LOCK TABLES `jom_content_frontpage` WRITE;
/*!40000 ALTER TABLE `jom_content_frontpage` DISABLE KEYS */;
INSERT INTO `jom_content_frontpage` (`content_id`, `ordering`) VALUES (6,13),(9,15),(30,16),(44,14),(45,12),(246,11),(247,10),(248,9),(249,8),(250,7),(251,6),(253,5),(254,4),(285,3),(286,2),(296,1);
/*!40000 ALTER TABLE `jom_content_frontpage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_content_rating`
--

DROP TABLE IF EXISTS `jom_content_rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_content_rating` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `rating_sum` int(10) unsigned NOT NULL DEFAULT '0',
  `rating_count` int(10) unsigned NOT NULL DEFAULT '0',
  `lastip` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_content_rating`
--

LOCK TABLES `jom_content_rating` WRITE;
/*!40000 ALTER TABLE `jom_content_rating` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_content_rating` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_content_types`
--

DROP TABLE IF EXISTS `jom_content_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_content_types` (
  `type_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_title` varchar(255) NOT NULL DEFAULT '',
  `type_alias` varchar(255) NOT NULL DEFAULT '',
  `table` varchar(255) NOT NULL DEFAULT '',
  `rules` text NOT NULL,
  `field_mappings` text NOT NULL,
  `router` varchar(255) NOT NULL DEFAULT '',
  `content_history_options` varchar(5120) NOT NULL COMMENT 'JSON string for com_contenthistory options',
  PRIMARY KEY (`type_id`),
  KEY `idx_alias` (`type_alias`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_content_types`
--

LOCK TABLES `jom_content_types` WRITE;
/*!40000 ALTER TABLE `jom_content_types` DISABLE KEYS */;
INSERT INTO `jom_content_types` (`type_id`, `type_title`, `type_alias`, `table`, `rules`, `field_mappings`, `router`, `content_history_options`) VALUES (1,'Article','com_content.article','{\"special\":{\"dbtable\":\"#__content\",\"key\":\"id\",\"type\":\"Content\",\"prefix\":\"JTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}','','{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"title\",\"core_state\":\"state\",\"core_alias\":\"alias\",\"core_created_time\":\"created\",\"core_modified_time\":\"modified\",\"core_body\":\"introtext\", \"core_hits\":\"hits\",\"core_publish_up\":\"publish_up\",\"core_publish_down\":\"publish_down\",\"core_access\":\"access\", \"core_params\":\"attribs\", \"core_featured\":\"featured\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"images\", \"core_urls\":\"urls\", \"core_version\":\"version\", \"core_ordering\":\"ordering\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"catid\", \"core_xreference\":\"xreference\", \"asset_id\":\"asset_id\"}, \"special\": {\"fulltext\":\"fulltext\"}}','ContentHelperRoute::getArticleRoute','{\"formFile\":\"administrator\\/components\\/com_content\\/models\\/forms\\/article.xml\", \"hideFields\":[\"asset_id\",\"checked_out\",\"checked_out_time\",\"version\"],\"ignoreChanges\":[\"modified_by\", \"modified\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\"],\"convertToInt\":[\"publish_up\", \"publish_down\", \"featured\", \"ordering\"],\"displayLookup\":[{\"sourceColumn\":\"catid\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"created_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"} ]}'),(2,'Weblink','com_weblinks.weblink','{\"special\":{\"dbtable\":\"#__weblinks\",\"key\":\"id\",\"type\":\"Weblink\",\"prefix\":\"WeblinksTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}','','{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"title\",\"core_state\":\"state\",\"core_alias\":\"alias\",\"core_created_time\":\"created\",\"core_modified_time\":\"modified\",\"core_body\":\"description\", \"core_hits\":\"hits\",\"core_publish_up\":\"publish_up\",\"core_publish_down\":\"publish_down\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"featured\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"images\", \"core_urls\":\"url\", \"core_version\":\"version\", \"core_ordering\":\"ordering\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"catid\", \"core_xreference\":\"xreference\", \"asset_id\":\"null\"}, \"special\": {}}','WeblinksHelperRoute::getWeblinkRoute','{\"formFile\":\"administrator\\/components\\/com_weblinks\\/models\\/forms\\/weblink.xml\", \"hideFields\":[\"asset_id\",\"checked_out\",\"checked_out_time\",\"version\",\"featured\",\"images\"], \"ignoreChanges\":[\"modified_by\", \"modified\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\"], \"convertToInt\":[\"publish_up\", \"publish_down\", \"featured\", \"ordering\"], \"displayLookup\":[{\"sourceColumn\":\"catid\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"created_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"} ]}'),(3,'Contact','com_contact.contact','{\"special\":{\"dbtable\":\"#__contact_details\",\"key\":\"id\",\"type\":\"Contact\",\"prefix\":\"ContactTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}','','{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"name\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created\",\"core_modified_time\":\"modified\",\"core_body\":\"address\", \"core_hits\":\"hits\",\"core_publish_up\":\"publish_up\",\"core_publish_down\":\"publish_down\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"featured\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"image\", \"core_urls\":\"webpage\", \"core_version\":\"version\", \"core_ordering\":\"ordering\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"catid\", \"core_xreference\":\"xreference\", \"asset_id\":\"null\"}, \"special\": {\"con_position\":\"con_position\",\"suburb\":\"suburb\",\"state\":\"state\",\"country\":\"country\",\"postcode\":\"postcode\",\"telephone\":\"telephone\",\"fax\":\"fax\",\"misc\":\"misc\",\"email_to\":\"email_to\",\"default_con\":\"default_con\",\"user_id\":\"user_id\",\"mobile\":\"mobile\",\"sortname1\":\"sortname1\",\"sortname2\":\"sortname2\",\"sortname3\":\"sortname3\"}}','ContactHelperRoute::getContactRoute','{\"formFile\":\"administrator\\/components\\/com_contact\\/models\\/forms\\/contact.xml\",\"hideFields\":[\"default_con\",\"checked_out\",\"checked_out_time\",\"version\",\"xreference\"],\"ignoreChanges\":[\"modified_by\", \"modified\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\"],\"convertToInt\":[\"publish_up\", \"publish_down\", \"featured\", \"ordering\"], \"displayLookup\":[ {\"sourceColumn\":\"created_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"catid\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"} ] }'),(4,'Newsfeed','com_newsfeeds.newsfeed','{\"special\":{\"dbtable\":\"#__newsfeeds\",\"key\":\"id\",\"type\":\"Newsfeed\",\"prefix\":\"NewsfeedsTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}','','{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"name\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created\",\"core_modified_time\":\"modified\",\"core_body\":\"description\", \"core_hits\":\"hits\",\"core_publish_up\":\"publish_up\",\"core_publish_down\":\"publish_down\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"featured\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"images\", \"core_urls\":\"link\", \"core_version\":\"version\", \"core_ordering\":\"ordering\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"catid\", \"core_xreference\":\"xreference\", \"asset_id\":\"null\"}, \"special\": {\"numarticles\":\"numarticles\",\"cache_time\":\"cache_time\",\"rtl\":\"rtl\"}}','NewsfeedsHelperRoute::getNewsfeedRoute','{\"formFile\":\"administrator\\/components\\/com_newsfeeds\\/models\\/forms\\/newsfeed.xml\",\"hideFields\":[\"asset_id\",\"checked_out\",\"checked_out_time\",\"version\"],\"ignoreChanges\":[\"modified_by\", \"modified\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\"],\"convertToInt\":[\"publish_up\", \"publish_down\", \"featured\", \"ordering\"],\"displayLookup\":[{\"sourceColumn\":\"catid\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"created_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"}]}'),(5,'User','com_users.user','{\"special\":{\"dbtable\":\"#__users\",\"key\":\"id\",\"type\":\"User\",\"prefix\":\"JTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}','','{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"name\",\"core_state\":\"null\",\"core_alias\":\"username\",\"core_created_time\":\"registerdate\",\"core_modified_time\":\"lastvisitDate\",\"core_body\":\"null\", \"core_hits\":\"null\",\"core_publish_up\":\"null\",\"core_publish_down\":\"null\",\"access\":\"null\", \"core_params\":\"params\", \"core_featured\":\"null\", \"core_metadata\":\"null\", \"core_language\":\"null\", \"core_images\":\"null\", \"core_urls\":\"null\", \"core_version\":\"null\", \"core_ordering\":\"null\", \"core_metakey\":\"null\", \"core_metadesc\":\"null\", \"core_catid\":\"null\", \"core_xreference\":\"null\", \"asset_id\":\"null\"}, \"special\": {}}','UsersHelperRoute::getUserRoute',''),(6,'Article Category','com_content.category','{\"special\":{\"dbtable\":\"#__categories\",\"key\":\"id\",\"type\":\"Category\",\"prefix\":\"JTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}','','{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"title\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created_time\",\"core_modified_time\":\"modified_time\",\"core_body\":\"description\", \"core_hits\":\"hits\",\"core_publish_up\":\"null\",\"core_publish_down\":\"null\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"null\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"null\", \"core_urls\":\"null\", \"core_version\":\"version\", \"core_ordering\":\"null\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"parent_id\", \"core_xreference\":\"null\", \"asset_id\":\"asset_id\"}, \"special\": {\"parent_id\":\"parent_id\",\"lft\":\"lft\",\"rgt\":\"rgt\",\"level\":\"level\",\"path\":\"path\",\"extension\":\"extension\",\"note\":\"note\"}}','ContentHelperRoute::getCategoryRoute','{\"formFile\":\"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml\", \"hideFields\":[\"asset_id\",\"checked_out\",\"checked_out_time\",\"version\",\"lft\",\"rgt\",\"level\",\"path\",\"extension\"], \"ignoreChanges\":[\"modified_user_id\", \"modified_time\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\", \"path\"],\"convertToInt\":[\"publish_up\", \"publish_down\"], \"displayLookup\":[{\"sourceColumn\":\"created_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"parent_id\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}]}'),(7,'Contact Category','com_contact.category','{\"special\":{\"dbtable\":\"#__categories\",\"key\":\"id\",\"type\":\"Category\",\"prefix\":\"JTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}','','{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"title\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created_time\",\"core_modified_time\":\"modified_time\",\"core_body\":\"description\", \"core_hits\":\"hits\",\"core_publish_up\":\"null\",\"core_publish_down\":\"null\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"null\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"null\", \"core_urls\":\"null\", \"core_version\":\"version\", \"core_ordering\":\"null\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"parent_id\", \"core_xreference\":\"null\", \"asset_id\":\"asset_id\"}, \"special\": {\"parent_id\":\"parent_id\",\"lft\":\"lft\",\"rgt\":\"rgt\",\"level\":\"level\",\"path\":\"path\",\"extension\":\"extension\",\"note\":\"note\"}}','ContactHelperRoute::getCategoryRoute','{\"formFile\":\"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml\", \"hideFields\":[\"asset_id\",\"checked_out\",\"checked_out_time\",\"version\",\"lft\",\"rgt\",\"level\",\"path\",\"extension\"], \"ignoreChanges\":[\"modified_user_id\", \"modified_time\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\", \"path\"],\"convertToInt\":[\"publish_up\", \"publish_down\"], \"displayLookup\":[{\"sourceColumn\":\"created_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"parent_id\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}]}'),(8,'Newsfeeds Category','com_newsfeeds.category','{\"special\":{\"dbtable\":\"#__categories\",\"key\":\"id\",\"type\":\"Category\",\"prefix\":\"JTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}','','{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"title\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created_time\",\"core_modified_time\":\"modified_time\",\"core_body\":\"description\", \"core_hits\":\"hits\",\"core_publish_up\":\"null\",\"core_publish_down\":\"null\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"null\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"null\", \"core_urls\":\"null\", \"core_version\":\"version\", \"core_ordering\":\"null\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"parent_id\", \"core_xreference\":\"null\", \"asset_id\":\"asset_id\"}, \"special\": {\"parent_id\":\"parent_id\",\"lft\":\"lft\",\"rgt\":\"rgt\",\"level\":\"level\",\"path\":\"path\",\"extension\":\"extension\",\"note\":\"note\"}}','NewsfeedsHelperRoute::getCategoryRoute','{\"formFile\":\"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml\", \"hideFields\":[\"asset_id\",\"checked_out\",\"checked_out_time\",\"version\",\"lft\",\"rgt\",\"level\",\"path\",\"extension\"], \"ignoreChanges\":[\"modified_user_id\", \"modified_time\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\", \"path\"],\"convertToInt\":[\"publish_up\", \"publish_down\"], \"displayLookup\":[{\"sourceColumn\":\"created_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"parent_id\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}]}'),(9,'Weblinks Category','com_weblinks.category','{\"special\":{\"dbtable\":\"#__categories\",\"key\":\"id\",\"type\":\"Category\",\"prefix\":\"JTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}','','{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"title\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created_time\",\"core_modified_time\":\"modified_time\",\"core_body\":\"description\", \"core_hits\":\"hits\",\"core_publish_up\":\"null\",\"core_publish_down\":\"null\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"null\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"null\", \"core_urls\":\"null\", \"core_version\":\"version\", \"core_ordering\":\"null\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"parent_id\", \"core_xreference\":\"null\", \"asset_id\":\"asset_id\"}, \"special\": {\"parent_id\":\"parent_id\",\"lft\":\"lft\",\"rgt\":\"rgt\",\"level\":\"level\",\"path\":\"path\",\"extension\":\"extension\",\"note\":\"note\"}}','WeblinksHelperRoute::getCategoryRoute','{\"formFile\":\"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml\", \"hideFields\":[\"asset_id\",\"checked_out\",\"checked_out_time\",\"version\",\"lft\",\"rgt\",\"level\",\"path\",\"extension\"], \"ignoreChanges\":[\"modified_user_id\", \"modified_time\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\", \"path\"],\"convertToInt\":[\"publish_up\", \"publish_down\"], \"displayLookup\":[{\"sourceColumn\":\"created_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"parent_id\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}]}'),(10,'Tag','com_tags.tag','{\"special\":{\"dbtable\":\"#__tags\",\"key\":\"tag_id\",\"type\":\"Tag\",\"prefix\":\"TagsTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}','','{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"title\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created_time\",\"core_modified_time\":\"modified_time\",\"core_body\":\"description\", \"core_hits\":\"hits\",\"core_publish_up\":\"null\",\"core_publish_down\":\"null\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"featured\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"images\", \"core_urls\":\"urls\", \"core_version\":\"version\", \"core_ordering\":\"null\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"null\", \"core_xreference\":\"null\", \"asset_id\":\"null\"}, \"special\": {\"parent_id\":\"parent_id\",\"lft\":\"lft\",\"rgt\":\"rgt\",\"level\":\"level\",\"path\":\"path\"}}','TagsHelperRoute::getTagRoute','{\"formFile\":\"administrator\\/components\\/com_tags\\/models\\/forms\\/tag.xml\", \"hideFields\":[\"checked_out\",\"checked_out_time\",\"version\", \"lft\", \"rgt\", \"level\", \"path\", \"urls\", \"publish_up\", \"publish_down\"],\"ignoreChanges\":[\"modified_user_id\", \"modified_time\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\", \"path\"],\"convertToInt\":[\"publish_up\", \"publish_down\"], \"displayLookup\":[{\"sourceColumn\":\"created_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"}, {\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}, {\"sourceColumn\":\"modified_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"}]}'),(11,'Banner','com_banners.banner','{\"special\":{\"dbtable\":\"#__banners\",\"key\":\"id\",\"type\":\"Banner\",\"prefix\":\"BannersTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}','','{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"name\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created\",\"core_modified_time\":\"modified\",\"core_body\":\"description\", \"core_hits\":\"null\",\"core_publish_up\":\"publish_up\",\"core_publish_down\":\"publish_down\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"null\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"images\", \"core_urls\":\"link\", \"core_version\":\"version\", \"core_ordering\":\"ordering\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"catid\", \"core_xreference\":\"null\", \"asset_id\":\"null\"}, \"special\":{\"imptotal\":\"imptotal\", \"impmade\":\"impmade\", \"clicks\":\"clicks\", \"clickurl\":\"clickurl\", \"custombannercode\":\"custombannercode\", \"cid\":\"cid\", \"purchase_type\":\"purchase_type\", \"track_impressions\":\"track_impressions\", \"track_clicks\":\"track_clicks\"}}','','{\"formFile\":\"administrator\\/components\\/com_banners\\/models\\/forms\\/banner.xml\", \"hideFields\":[\"checked_out\",\"checked_out_time\",\"version\", \"reset\"],\"ignoreChanges\":[\"modified_by\", \"modified\", \"checked_out\", \"checked_out_time\", \"version\", \"imptotal\", \"impmade\", \"reset\"], \"convertToInt\":[\"publish_up\", \"publish_down\", \"ordering\"], \"displayLookup\":[{\"sourceColumn\":\"catid\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}, {\"sourceColumn\":\"cid\",\"targetTable\":\"#__banner_clients\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"}, {\"sourceColumn\":\"created_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"modified_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"}]}'),(12,'Banners Category','com_banners.category','{\"special\":{\"dbtable\":\"#__categories\",\"key\":\"id\",\"type\":\"Category\",\"prefix\":\"JTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}','','{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"title\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created_time\",\"core_modified_time\":\"modified_time\",\"core_body\":\"description\", \"core_hits\":\"hits\",\"core_publish_up\":\"null\",\"core_publish_down\":\"null\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"null\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"null\", \"core_urls\":\"null\", \"core_version\":\"version\", \"core_ordering\":\"null\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"parent_id\", \"core_xreference\":\"null\", \"asset_id\":\"asset_id\"}, \"special\": {\"parent_id\":\"parent_id\",\"lft\":\"lft\",\"rgt\":\"rgt\",\"level\":\"level\",\"path\":\"path\",\"extension\":\"extension\",\"note\":\"note\"}}','','{\"formFile\":\"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml\", \"hideFields\":[\"asset_id\",\"checked_out\",\"checked_out_time\",\"version\",\"lft\",\"rgt\",\"level\",\"path\",\"extension\"], \"ignoreChanges\":[\"modified_user_id\", \"modified_time\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\", \"path\"], \"convertToInt\":[\"publish_up\", \"publish_down\"], \"displayLookup\":[{\"sourceColumn\":\"created_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"parent_id\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}]}'),(13,'Banner Client','com_banners.client','{\"special\":{\"dbtable\":\"#__banner_clients\",\"key\":\"id\",\"type\":\"Client\",\"prefix\":\"BannersTable\"}}','','','','{\"formFile\":\"administrator\\/components\\/com_banners\\/models\\/forms\\/client.xml\", \"hideFields\":[\"checked_out\",\"checked_out_time\"], \"ignoreChanges\":[\"checked_out\", \"checked_out_time\"], \"convertToInt\":[], \"displayLookup\":[]}'),(14,'User Notes','com_users.note','{\"special\":{\"dbtable\":\"#__user_notes\",\"key\":\"id\",\"type\":\"Note\",\"prefix\":\"UsersTable\"}}','','','','{\"formFile\":\"administrator\\/components\\/com_users\\/models\\/forms\\/note.xml\", \"hideFields\":[\"checked_out\",\"checked_out_time\", \"publish_up\", \"publish_down\"],\"ignoreChanges\":[\"modified_user_id\", \"modified_time\", \"checked_out\", \"checked_out_time\"], \"convertToInt\":[\"publish_up\", \"publish_down\"],\"displayLookup\":[{\"sourceColumn\":\"catid\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}, {\"sourceColumn\":\"created_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"}, {\"sourceColumn\":\"user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"}, {\"sourceColumn\":\"modified_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"}]}'),(15,'User Notes Category','com_users.category','{\"special\":{\"dbtable\":\"#__categories\",\"key\":\"id\",\"type\":\"Category\",\"prefix\":\"JTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}','','{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"title\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created_time\",\"core_modified_time\":\"modified_time\",\"core_body\":\"description\", \"core_hits\":\"hits\",\"core_publish_up\":\"null\",\"core_publish_down\":\"null\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"null\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"null\", \"core_urls\":\"null\", \"core_version\":\"version\", \"core_ordering\":\"null\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"parent_id\", \"core_xreference\":\"null\", \"asset_id\":\"asset_id\"}, \"special\":{\"parent_id\":\"parent_id\",\"lft\":\"lft\",\"rgt\":\"rgt\",\"level\":\"level\",\"path\":\"path\",\"extension\":\"extension\",\"note\":\"note\"}}','','{\"formFile\":\"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml\", \"hideFields\":[\"checked_out\",\"checked_out_time\",\"version\",\"lft\",\"rgt\",\"level\",\"path\",\"extension\"], \"ignoreChanges\":[\"modified_user_id\", \"modified_time\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\", \"path\"], \"convertToInt\":[\"publish_up\", \"publish_down\"], \"displayLookup\":[{\"sourceColumn\":\"created_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"}, {\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"parent_id\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}]}');
/*!40000 ALTER TABLE `jom_content_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_contentitem_tag_map`
--

DROP TABLE IF EXISTS `jom_contentitem_tag_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_contentitem_tag_map` (
  `type_alias` varchar(255) NOT NULL DEFAULT '',
  `core_content_id` int(10) unsigned NOT NULL COMMENT 'PK from the core content table',
  `content_item_id` int(11) NOT NULL COMMENT 'PK from the content type table',
  `tag_id` int(10) unsigned NOT NULL COMMENT 'PK from the tag table',
  `tag_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Date of most recent save for this tag-item',
  `type_id` mediumint(8) NOT NULL COMMENT 'PK from the content_type table',
  UNIQUE KEY `uc_ItemnameTagid` (`type_id`,`content_item_id`,`tag_id`),
  KEY `idx_tag_type` (`tag_id`,`type_id`),
  KEY `idx_date_id` (`tag_date`,`tag_id`),
  KEY `idx_tag` (`tag_id`),
  KEY `idx_type` (`type_id`),
  KEY `idx_core_content_id` (`core_content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Maps items from content tables to tags';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_contentitem_tag_map`
--

LOCK TABLES `jom_contentitem_tag_map` WRITE;
/*!40000 ALTER TABLE `jom_contentitem_tag_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_contentitem_tag_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_core_log_searches`
--

DROP TABLE IF EXISTS `jom_core_log_searches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_core_log_searches` (
  `search_term` varchar(128) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_core_log_searches`
--

LOCK TABLES `jom_core_log_searches` WRITE;
/*!40000 ALTER TABLE `jom_core_log_searches` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_core_log_searches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_extensions`
--

DROP TABLE IF EXISTS `jom_extensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_extensions` (
  `extension_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `type` varchar(20) NOT NULL,
  `element` varchar(100) NOT NULL,
  `folder` varchar(100) NOT NULL,
  `client_id` tinyint(3) NOT NULL,
  `enabled` tinyint(3) NOT NULL DEFAULT '1',
  `access` int(10) unsigned DEFAULT NULL,
  `protected` tinyint(3) NOT NULL DEFAULT '0',
  `manifest_cache` text NOT NULL,
  `params` text NOT NULL,
  `custom_data` text NOT NULL,
  `system_data` text NOT NULL,
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) DEFAULT '0',
  `state` int(11) DEFAULT '0',
  PRIMARY KEY (`extension_id`),
  KEY `element_clientid` (`element`,`client_id`),
  KEY `element_folder_clientid` (`element`,`folder`,`client_id`),
  KEY `extension` (`type`,`element`,`folder`,`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10112 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_extensions`
--

LOCK TABLES `jom_extensions` WRITE;
/*!40000 ALTER TABLE `jom_extensions` DISABLE KEYS */;
INSERT INTO `jom_extensions` (`extension_id`, `name`, `type`, `element`, `folder`, `client_id`, `enabled`, `access`, `protected`, `manifest_cache`, `params`, `custom_data`, `system_data`, `checked_out`, `checked_out_time`, `ordering`, `state`) VALUES (1,'com_mailto','component','com_mailto','',0,1,1,1,'{\"name\":\"com_mailto\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_MAILTO_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(2,'com_wrapper','component','com_wrapper','',0,1,1,1,'{\"name\":\"com_wrapper\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\n\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_WRAPPER_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(3,'com_admin','component','com_admin','',1,1,1,1,'{\"name\":\"com_admin\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\n\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_ADMIN_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(4,'com_banners','component','com_banners','',1,1,1,0,'{\"name\":\"com_banners\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\n\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_BANNERS_XML_DESCRIPTION\",\"group\":\"\"}','{\"purchase_type\":\"3\",\"track_impressions\":\"0\",\"track_clicks\":\"0\",\"metakey_prefix\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(5,'com_cache','component','com_cache','',1,1,1,1,'{\"name\":\"com_cache\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CACHE_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(6,'com_categories','component','com_categories','',1,1,1,1,'{\"name\":\"com_categories\",\"type\":\"component\",\"creationDate\":\"December 2007\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CATEGORIES_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(7,'com_checkin','component','com_checkin','',1,1,1,1,'{\"name\":\"com_checkin\",\"type\":\"component\",\"creationDate\":\"Unknown\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2008 Open Source Matters. All rights reserved.\\n\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CHECKIN_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(8,'com_contact','component','com_contact','',1,1,1,0,'{\"name\":\"com_contact\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\n\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CONTACT_XML_DESCRIPTION\",\"group\":\"\"}','{\"contact_layout\":\"_:default\",\"show_contact_category\":\"hide\",\"show_contact_list\":\"0\",\"presentation_style\":\"plain\",\"show_name\":\"1\",\"show_position\":\"1\",\"show_email\":\"0\",\"show_street_address\":\"1\",\"show_suburb\":\"1\",\"show_state\":\"1\",\"show_postcode\":\"1\",\"show_country\":\"1\",\"show_telephone\":\"1\",\"show_mobile\":\"1\",\"show_fax\":\"1\",\"show_webpage\":\"1\",\"show_misc\":\"1\",\"show_image\":\"1\",\"image\":\"\",\"allow_vcard\":\"0\",\"show_articles\":\"0\",\"show_profile\":\"0\",\"show_links\":\"0\",\"linka_name\":\"\",\"linkb_name\":\"\",\"linkc_name\":\"\",\"linkd_name\":\"\",\"linke_name\":\"\",\"contact_icons\":\"0\",\"icon_address\":\"\",\"icon_email\":\"\",\"icon_telephone\":\"\",\"icon_mobile\":\"\",\"icon_fax\":\"\",\"icon_misc\":\"\",\"category_layout\":\"_:default\",\"show_category_title\":\"1\",\"show_description\":\"1\",\"show_description_image\":\"0\",\"maxLevel\":\"-1\",\"show_empty_categories\":\"0\",\"show_subcat_desc\":\"1\",\"show_cat_items\":\"1\",\"show_base_description\":\"1\",\"maxLevelcat\":\"-1\",\"show_empty_categories_cat\":\"0\",\"show_subcat_desc_cat\":\"1\",\"show_cat_items_cat\":\"1\",\"show_pagination_limit\":\"1\",\"show_headings\":\"1\",\"show_position_headings\":\"1\",\"show_email_headings\":\"0\",\"show_telephone_headings\":\"1\",\"show_mobile_headings\":\"0\",\"show_fax_headings\":\"0\",\"show_suburb_headings\":\"1\",\"show_state_headings\":\"1\",\"show_country_headings\":\"1\",\"show_pagination\":\"2\",\"show_pagination_results\":\"1\",\"initial_sort\":\"ordering\",\"captcha\":\"\",\"show_email_form\":\"1\",\"show_email_copy\":\"1\",\"banned_email\":\"\",\"banned_subject\":\"\",\"banned_text\":\"\",\"validate_session\":\"1\",\"custom_reply\":\"0\",\"redirect\":\"\",\"show_feed_link\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(9,'com_cpanel','component','com_cpanel','',1,1,1,1,'{\"name\":\"com_cpanel\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CPANEL_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(10,'com_installer','component','com_installer','',1,1,1,1,'{\"name\":\"com_installer\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_INSTALLER_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(11,'com_languages','component','com_languages','',1,1,1,1,'{\"name\":\"com_languages\",\"type\":\"component\",\"creationDate\":\"2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\n\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_LANGUAGES_XML_DESCRIPTION\",\"group\":\"\"}','{\"administrator\":\"en-GB\",\"site\":\"en-GB\"}','','',0,'0000-00-00 00:00:00',0,0),(12,'com_login','component','com_login','',1,1,1,1,'{\"name\":\"com_login\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_LOGIN_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(13,'com_media','component','com_media','',1,1,0,1,'{\"name\":\"com_media\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_MEDIA_XML_DESCRIPTION\",\"group\":\"\"}','{\"upload_extensions\":\"bmp,csv,doc,gif,ico,jpg,jpeg,odg,odp,ods,odt,pdf,png,ppt,swf,txt,xcf,xls,BMP,CSV,DOC,GIF,ICO,JPG,JPEG,ODG,ODP,ODS,ODT,PDF,PNG,PPT,SWF,TXT,XCF,XLS\",\"upload_maxsize\":\"10\",\"file_path\":\"images\",\"image_path\":\"images\",\"restrict_uploads\":\"1\",\"allowed_media_usergroup\":\"3\",\"check_mime\":\"1\",\"image_extensions\":\"bmp,gif,jpg,png\",\"ignore_extensions\":\"\",\"upload_mime\":\"image\\/jpeg,image\\/gif,image\\/png,image\\/bmp,application\\/x-shockwave-flash,application\\/msword,application\\/excel,application\\/pdf,application\\/powerpoint,text\\/plain,application\\/x-zip\",\"upload_mime_illegal\":\"text\\/html\",\"enable_flash\":\"0\"}','','',0,'0000-00-00 00:00:00',0,0),(14,'com_menus','component','com_menus','',1,1,1,1,'{\"name\":\"com_menus\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_MENUS_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(15,'com_messages','component','com_messages','',1,1,1,1,'{\"name\":\"com_messages\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_MESSAGES_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(16,'com_modules','component','com_modules','',1,1,1,1,'{\"name\":\"com_modules\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_MODULES_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(17,'com_newsfeeds','component','com_newsfeeds','',1,1,1,0,'{\"name\":\"com_newsfeeds\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_NEWSFEEDS_XML_DESCRIPTION\",\"group\":\"\"}','{\"show_feed_image\":\"1\",\"show_feed_description\":\"1\",\"show_item_description\":\"1\",\"feed_word_count\":\"0\",\"show_headings\":\"1\",\"show_name\":\"1\",\"show_articles\":\"0\",\"show_link\":\"1\",\"show_description\":\"1\",\"show_description_image\":\"1\",\"display_num\":\"\",\"show_pagination_limit\":\"1\",\"show_pagination\":\"1\",\"show_pagination_results\":\"1\",\"show_cat_items\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(18,'com_plugins','component','com_plugins','',1,1,1,1,'{\"name\":\"com_plugins\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_PLUGINS_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(19,'com_search','component','com_search','',1,1,1,0,'{\"name\":\"com_search\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\n\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_SEARCH_XML_DESCRIPTION\",\"group\":\"\"}','{\"enabled\":\"0\",\"show_date\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(20,'com_templates','component','com_templates','',1,1,1,1,'{\"name\":\"com_templates\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_TEMPLATES_XML_DESCRIPTION\",\"group\":\"\"}','{\"template_positions_display\":\"1\",\"upload_limit\":\"10\",\"image_formats\":\"gif,bmp,jpg,jpeg,png\",\"source_formats\":\"txt,less,ini,xml,js,php,css\",\"font_formats\":\"woff,ttf,otf\",\"compressed_formats\":\"zip\"}','','',0,'0000-00-00 00:00:00',0,0),(21,'com_weblinks','component','com_weblinks','',1,1,1,0,'{\"name\":\"com_weblinks\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\n\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_WEBLINKS_XML_DESCRIPTION\",\"group\":\"\"}','{\"show_comp_description\":\"1\",\"comp_description\":\"\",\"show_link_hits\":\"1\",\"show_link_description\":\"1\",\"show_other_cats\":\"0\",\"show_headings\":\"0\",\"show_numbers\":\"0\",\"show_report\":\"1\",\"count_clicks\":\"1\",\"target\":\"0\",\"link_icons\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(22,'com_content','component','com_content','',1,1,0,1,'{\"name\":\"com_content\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CONTENT_XML_DESCRIPTION\",\"group\":\"\"}','{\"article_layout\":\"_:default\",\"show_title\":\"1\",\"link_titles\":\"1\",\"show_intro\":\"1\",\"show_category\":\"1\",\"link_category\":\"1\",\"show_parent_category\":\"0\",\"link_parent_category\":\"0\",\"show_author\":\"1\",\"link_author\":\"0\",\"show_create_date\":\"0\",\"show_modify_date\":\"0\",\"show_publish_date\":\"1\",\"show_item_navigation\":\"1\",\"show_vote\":\"0\",\"show_readmore\":\"1\",\"show_readmore_title\":\"1\",\"readmore_limit\":\"100\",\"show_icons\":\"1\",\"show_print_icon\":\"1\",\"show_email_icon\":\"1\",\"show_hits\":\"1\",\"show_noauth\":\"0\",\"category_layout\":\"_:blog\",\"show_category_title\":\"0\",\"show_description\":\"0\",\"show_description_image\":\"0\",\"maxLevel\":\"1\",\"show_empty_categories\":\"0\",\"show_no_articles\":\"1\",\"show_subcat_desc\":\"1\",\"show_cat_num_articles\":\"0\",\"show_base_description\":\"1\",\"maxLevelcat\":\"-1\",\"show_empty_categories_cat\":\"0\",\"show_subcat_desc_cat\":\"1\",\"show_cat_num_articles_cat\":\"1\",\"num_leading_articles\":\"1\",\"num_intro_articles\":\"4\",\"num_columns\":\"2\",\"num_links\":\"4\",\"multi_column_order\":\"0\",\"orderby_pri\":\"order\",\"orderby_sec\":\"rdate\",\"order_date\":\"published\",\"show_pagination_limit\":\"1\",\"filter_field\":\"hide\",\"show_headings\":\"1\",\"list_show_date\":\"0\",\"date_format\":\"\",\"list_show_hits\":\"1\",\"list_show_author\":\"1\",\"show_pagination\":\"2\",\"show_pagination_results\":\"1\",\"show_feed_link\":\"1\",\"feed_summary\":\"0\",\"filters\":{\"1\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"6\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"7\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"2\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"3\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"4\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"5\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"10\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"12\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"8\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"}}}','','',0,'0000-00-00 00:00:00',0,0),(23,'com_config','component','com_config','',1,1,0,1,'{\"name\":\"com_config\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CONFIG_XML_DESCRIPTION\",\"group\":\"\"}','{\"filters\":{\"1\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"6\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"7\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"2\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"3\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"4\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"5\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"8\":{\"filter_type\":\"NONE\",\"filter_tags\":\"\",\"filter_attributes\":\"\"}}}','','',0,'0000-00-00 00:00:00',0,0),(24,'com_redirect','component','com_redirect','',1,1,0,1,'{\"name\":\"com_redirect\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_REDIRECT_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(25,'com_users','component','com_users','',1,1,0,1,'{\"name\":\"com_users\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_USERS_XML_DESCRIPTION\",\"group\":\"\"}','{\"allowUserRegistration\":\"1\",\"new_usertype\":\"2\",\"guest_usergroup\":\"1\",\"sendpassword\":\"1\",\"useractivation\":\"1\",\"mail_to_admin\":\"1\",\"captcha\":\"recaptcha\",\"frontend_userparams\":\"1\",\"site_language\":\"0\",\"change_login_name\":\"0\",\"reset_count\":\"10\",\"reset_time\":\"1\",\"minimum_length\":\"4\",\"minimum_integers\":\"0\",\"minimum_symbols\":\"0\",\"minimum_uppercase\":\"0\",\"save_history\":\"1\",\"history_limit\":5,\"mailSubjectPrefix\":\"\",\"mailBodySuffix\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(27,'com_finder','component','com_finder','',1,1,0,0,'','{\"show_description\":\"1\",\"description_length\":255,\"allow_empty_query\":\"0\",\"show_url\":\"1\",\"show_advanced\":\"1\",\"expand_advanced\":\"0\",\"show_date_filters\":\"0\",\"highlight_terms\":\"1\",\"opensearch_name\":\"\",\"opensearch_description\":\"\",\"batch_size\":\"50\",\"memory_table_limit\":30000,\"title_multiplier\":\"1.7\",\"text_multiplier\":\"0.7\",\"meta_multiplier\":\"1.2\",\"path_multiplier\":\"2.0\",\"misc_multiplier\":\"0.3\",\"stemmer\":\"porter_en\"}','','',0,'0000-00-00 00:00:00',0,0),(28,'com_joomlaupdate','component','com_joomlaupdate','',1,1,0,1,'{\"legacy\":false,\"name\":\"com_joomlaupdate\",\"type\":\"component\",\"creationDate\":\"February 2012\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.2\",\"description\":\"COM_JOOMLAUPDATE_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(29,'com_tags','component','com_tags','',1,1,1,1,'{\"name\":\"com_tags\",\"type\":\"component\",\"creationDate\":\"December 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.1.0\",\"description\":\"COM_TAGS_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(30,'com_contenthistory','component','com_contenthistory','',1,1,1,0,'{\"name\":\"com_contenthistory\",\"type\":\"component\",\"creationDate\":\"May 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.0\",\"description\":\"COM_CONTENTHISTORY_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(31,'com_ajax','component','com_ajax','',1,1,1,0,'{\"name\":\"com_ajax\",\"type\":\"component\",\"creationDate\":\"August 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.0\",\"description\":\"COM_AJAX_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(32,'com_postinstall','component','com_postinstall','',1,1,1,1,'{\"name\":\"com_postinstall\",\"type\":\"component\",\"creationDate\":\"September 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.0\",\"description\":\"COM_POSTINSTALL_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(100,'PHPMailer','library','phpmailer','',0,1,1,1,'{\"name\":\"PHPMailer\",\"type\":\"library\",\"creationDate\":\"2001\",\"author\":\"PHPMailer\",\"copyright\":\"(c) 2001-2003, Brent R. Matzelle, (c) 2004-2009, Andy Prevost. All Rights Reserved., (c) 2010-2013, Jim Jagielski. All Rights Reserved.\",\"authorEmail\":\"jimjag@gmail.com\",\"authorUrl\":\"https:\\/\\/github.com\\/PHPMailer\\/PHPMailer\",\"version\":\"5.2.6\",\"description\":\"LIB_PHPMAILER_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(101,'SimplePie','library','simplepie','',0,1,1,1,'{\"name\":\"SimplePie\",\"type\":\"library\",\"creationDate\":\"2004\",\"author\":\"SimplePie\",\"copyright\":\"Copyright (c) 2004-2009, Ryan Parman and Geoffrey Sneddon\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/simplepie.org\\/\",\"version\":\"1.2\",\"description\":\"LIB_SIMPLEPIE_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(102,'phputf8','library','phputf8','',0,1,1,1,'{\"name\":\"phputf8\",\"type\":\"library\",\"creationDate\":\"2006\",\"author\":\"Harry Fuecks\",\"copyright\":\"Copyright various authors\",\"authorEmail\":\"hfuecks@gmail.com\",\"authorUrl\":\"http:\\/\\/sourceforge.net\\/projects\\/phputf8\",\"version\":\"0.5\",\"description\":\"LIB_PHPUTF8_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(103,'Joomla! Platform','library','joomla','',0,1,1,1,'{\"name\":\"Joomla! Platform\",\"type\":\"library\",\"creationDate\":\"2008\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"http:\\/\\/www.joomla.org\",\"version\":\"13.1\",\"description\":\"LIB_JOOMLA_XML_DESCRIPTION\",\"group\":\"\"}','{\"mediaversion\":\"526f8a0c1c2a1b05b06c3cef8a87a58c\"}','','',0,'0000-00-00 00:00:00',0,0),(104,'IDNA Convert','library','idna_convert','',0,1,1,1,'{\"name\":\"IDNA Convert\",\"type\":\"library\",\"creationDate\":\"2004\",\"author\":\"phlyLabs\",\"copyright\":\"2004-2011 phlyLabs Berlin, http:\\/\\/phlylabs.de\",\"authorEmail\":\"phlymail@phlylabs.de\",\"authorUrl\":\"http:\\/\\/phlylabs.de\",\"version\":\"0.8.0\",\"description\":\"LIB_IDNA_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(105,'FOF','library','fof','',0,1,1,1,'{\"name\":\"FOF\",\"type\":\"library\",\"creationDate\":\"2013-10-22\",\"author\":\"Nicholas K. Dionysopoulos \\/ Akeeba Ltd\",\"copyright\":\"(C)2011-2013 Nicholas K. Dionysopoulos\",\"authorEmail\":\"nicholas@akeebabackup.com\",\"authorUrl\":\"https:\\/\\/www.akeebabackup.com\",\"version\":\"2.1.rc4\",\"description\":\"LIB_FOF_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(200,'mod_articles_archive','module','mod_articles_archive','',0,1,1,0,'{\"name\":\"mod_articles_archive\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters.\\n\\t\\tAll rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_ARTICLES_ARCHIVE_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(201,'mod_articles_latest','module','mod_articles_latest','',0,1,1,0,'{\"name\":\"mod_articles_latest\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_LATEST_NEWS_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(202,'mod_articles_popular','module','mod_articles_popular','',0,1,1,0,'{\"name\":\"mod_articles_popular\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_POPULAR_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(203,'mod_banners','module','mod_banners','',0,1,1,0,'{\"name\":\"mod_banners\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_BANNERS_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(204,'mod_breadcrumbs','module','mod_breadcrumbs','',0,1,1,1,'{\"name\":\"mod_breadcrumbs\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_BREADCRUMBS_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(205,'mod_custom','module','mod_custom','',0,1,1,1,'{\"name\":\"mod_custom\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_CUSTOM_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(206,'mod_feed','module','mod_feed','',0,1,1,0,'{\"name\":\"mod_feed\",\"type\":\"module\",\"creationDate\":\"July 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_FEED_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(207,'mod_footer','module','mod_footer','',0,1,1,0,'{\"name\":\"mod_footer\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_FOOTER_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(208,'mod_login','module','mod_login','',0,1,1,1,'{\"name\":\"mod_login\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_LOGIN_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(209,'mod_menu','module','mod_menu','',0,1,1,1,'{\"name\":\"mod_menu\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_MENU_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(210,'mod_articles_news','module','mod_articles_news','',0,1,1,0,'{\"name\":\"mod_articles_news\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_ARTICLES_NEWS_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(211,'mod_random_image','module','mod_random_image','',0,1,1,0,'{\"name\":\"mod_random_image\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_RANDOM_IMAGE_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(212,'mod_related_items','module','mod_related_items','',0,1,1,0,'{\"name\":\"mod_related_items\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_RELATED_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(213,'mod_search','module','mod_search','',0,1,1,0,'{\"name\":\"mod_search\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_SEARCH_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(214,'mod_stats','module','mod_stats','',0,1,1,0,'{\"name\":\"mod_stats\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_STATS_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(215,'mod_syndicate','module','mod_syndicate','',0,1,1,1,'{\"name\":\"mod_syndicate\",\"type\":\"module\",\"creationDate\":\"May 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_SYNDICATE_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(216,'mod_users_latest','module','mod_users_latest','',0,1,1,0,'{\"name\":\"mod_users_latest\",\"type\":\"module\",\"creationDate\":\"December 2009\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_USERS_LATEST_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(217,'mod_weblinks','module','mod_weblinks','',0,1,1,0,'{\"name\":\"mod_weblinks\",\"type\":\"module\",\"creationDate\":\"July 2009\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_WEBLINKS_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(218,'mod_whosonline','module','mod_whosonline','',0,1,1,0,'{\"name\":\"mod_whosonline\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_WHOSONLINE_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(219,'mod_wrapper','module','mod_wrapper','',0,1,1,0,'{\"name\":\"mod_wrapper\",\"type\":\"module\",\"creationDate\":\"October 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_WRAPPER_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(220,'mod_articles_category','module','mod_articles_category','',0,1,1,0,'{\"name\":\"mod_articles_category\",\"type\":\"module\",\"creationDate\":\"February 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_ARTICLES_CATEGORY_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(221,'mod_articles_categories','module','mod_articles_categories','',0,1,1,0,'{\"name\":\"mod_articles_categories\",\"type\":\"module\",\"creationDate\":\"February 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_ARTICLES_CATEGORIES_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(222,'mod_languages','module','mod_languages','',0,1,1,1,'{\"name\":\"mod_languages\",\"type\":\"module\",\"creationDate\":\"February 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_LANGUAGES_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(223,'mod_finder','module','mod_finder','',0,1,0,0,'','','','',0,'0000-00-00 00:00:00',0,0),(300,'mod_custom','module','mod_custom','',1,1,1,1,'{\"name\":\"mod_custom\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_CUSTOM_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(301,'mod_feed','module','mod_feed','',1,1,1,0,'{\"name\":\"mod_feed\",\"type\":\"module\",\"creationDate\":\"July 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_FEED_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(302,'mod_latest','module','mod_latest','',1,1,1,0,'{\"name\":\"mod_latest\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_LATEST_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(303,'mod_logged','module','mod_logged','',1,1,1,0,'{\"name\":\"mod_logged\",\"type\":\"module\",\"creationDate\":\"January 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_LOGGED_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(304,'mod_login','module','mod_login','',1,1,1,1,'{\"name\":\"mod_login\",\"type\":\"module\",\"creationDate\":\"March 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_LOGIN_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(305,'mod_menu','module','mod_menu','',1,1,1,0,'{\"name\":\"mod_menu\",\"type\":\"module\",\"creationDate\":\"March 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_MENU_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(306,'mod_online','module','mod_online','',1,1,1,0,'','','','',0,'0000-00-00 00:00:00',0,0),(307,'mod_popular','module','mod_popular','',1,1,1,0,'{\"name\":\"mod_popular\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_POPULAR_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(308,'mod_quickicon','module','mod_quickicon','',1,1,1,1,'{\"name\":\"mod_quickicon\",\"type\":\"module\",\"creationDate\":\"Nov 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_QUICKICON_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(309,'mod_status','module','mod_status','',1,1,1,0,'{\"name\":\"mod_status\",\"type\":\"module\",\"creationDate\":\"Feb 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_STATUS_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(310,'mod_submenu','module','mod_submenu','',1,1,1,0,'{\"name\":\"mod_submenu\",\"type\":\"module\",\"creationDate\":\"Feb 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_SUBMENU_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(311,'mod_title','module','mod_title','',1,1,1,0,'{\"name\":\"mod_title\",\"type\":\"module\",\"creationDate\":\"Nov 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_TITLE_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(312,'mod_toolbar','module','mod_toolbar','',1,1,1,1,'{\"name\":\"mod_toolbar\",\"type\":\"module\",\"creationDate\":\"Nov 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_TOOLBAR_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(313,'mod_multilangstatus','module','mod_multilangstatus','',1,1,1,0,'{\"name\":\"mod_multilangstatus\",\"type\":\"module\",\"creationDate\":\"September 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_MULTILANGSTATUS_XML_DESCRIPTION\",\"group\":\"\"}','{\"cache\":\"0\"}','','',0,'0000-00-00 00:00:00',0,0),(314,'mod_version','module','mod_version','',1,1,1,0,'{\"legacy\":false,\"name\":\"mod_version\",\"type\":\"module\",\"creationDate\":\"January 2012\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_VERSION_XML_DESCRIPTION\",\"group\":\"\"}','{\"format\":\"short\",\"product\":\"1\",\"cache\":\"0\"}','','',0,'0000-00-00 00:00:00',0,0),(315,'mod_stats_admin','module','mod_stats_admin','',1,1,1,0,'{\"name\":\"mod_stats_admin\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_STATS_XML_DESCRIPTION\",\"group\":\"\"}','{\"serverinfo\":\"0\",\"siteinfo\":\"0\",\"counter\":\"0\",\"increase\":\"0\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}','','',0,'0000-00-00 00:00:00',0,0),(316,'mod_tags_popular','module','mod_tags_popular','',0,1,1,0,'{\"name\":\"mod_tags_popular\",\"type\":\"module\",\"creationDate\":\"January 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.1.0\",\"description\":\"MOD_TAGS_POPULAR_XML_DESCRIPTION\",\"group\":\"\"}','{\"maximum\":\"5\",\"timeframe\":\"alltime\",\"owncache\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(317,'mod_tags_similar','module','mod_tags_similar','',0,1,1,0,'{\"name\":\"mod_tags_similar\",\"type\":\"module\",\"creationDate\":\"January 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.1.0\",\"description\":\"MOD_TAGS_SIMILAR_XML_DESCRIPTION\",\"group\":\"\"}','{\"maximum\":\"5\",\"matchtype\":\"any\",\"owncache\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(400,'plg_authentication_gmail','plugin','gmail','authentication',0,0,1,0,'{\"name\":\"plg_authentication_gmail\",\"type\":\"plugin\",\"creationDate\":\"February 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_GMAIL_XML_DESCRIPTION\",\"group\":\"\"}','{\"applysuffix\":\"0\",\"suffix\":\"\",\"verifypeer\":\"1\",\"user_blacklist\":\"\"}','','',0,'0000-00-00 00:00:00',1,0),(401,'plg_authentication_joomla','plugin','joomla','authentication',0,1,1,1,'{\"name\":\"plg_authentication_joomla\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_AUTH_JOOMLA_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(402,'plg_authentication_ldap','plugin','ldap','authentication',0,0,1,0,'{\"name\":\"plg_authentication_ldap\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_LDAP_XML_DESCRIPTION\",\"group\":\"\"}','{\"host\":\"\",\"port\":\"389\",\"use_ldapV3\":\"0\",\"negotiate_tls\":\"0\",\"no_referrals\":\"0\",\"auth_method\":\"bind\",\"base_dn\":\"\",\"search_string\":\"\",\"users_dn\":\"\",\"username\":\"admin\",\"password\":\"bobby7\",\"ldap_fullname\":\"fullName\",\"ldap_email\":\"mail\",\"ldap_uid\":\"uid\"}','','',0,'0000-00-00 00:00:00',3,0),(404,'plg_content_emailcloak','plugin','emailcloak','content',0,1,1,0,'{\"name\":\"plg_content_emailcloak\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_CONTENT_EMAILCLOAK_XML_DESCRIPTION\",\"group\":\"\"}','{\"mode\":\"1\"}','','',0,'0000-00-00 00:00:00',1,0),(405,'plg_content_geshi','plugin','geshi','content',0,0,1,0,'{\"legacy\":false,\"name\":\"plg_content_geshi\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"\",\"authorUrl\":\"qbnz.com\\/highlighter\",\"version\":\"3.0.0\",\"description\":\"PLG_CONTENT_GESHI_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',2,0),(406,'plg_content_loadmodule','plugin','loadmodule','content',0,1,1,0,'{\"name\":\"plg_content_loadmodule\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_LOADMODULE_XML_DESCRIPTION\",\"group\":\"\"}','{\"style\":\"none\"}','','',0,'0000-00-00 00:00:00',0,0),(407,'plg_content_pagebreak','plugin','pagebreak','content',0,1,1,0,'{\"name\":\"plg_content_pagebreak\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_CONTENT_PAGEBREAK_XML_DESCRIPTION\",\"group\":\"\"}','{\"title\":\"1\",\"multipage_toc\":\"1\",\"showall\":\"1\"}','','',0,'0000-00-00 00:00:00',4,0),(408,'plg_content_pagenavigation','plugin','pagenavigation','content',0,1,1,0,'{\"name\":\"plg_content_pagenavigation\",\"type\":\"plugin\",\"creationDate\":\"January 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_PAGENAVIGATION_XML_DESCRIPTION\",\"group\":\"\"}','{\"position\":\"1\"}','','',0,'0000-00-00 00:00:00',5,0),(409,'plg_content_vote','plugin','vote','content',0,1,1,0,'{\"name\":\"plg_content_vote\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_VOTE_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',6,0),(410,'plg_editors_codemirror','plugin','codemirror','editors',0,1,1,1,'{\"name\":\"plg_editors_codemirror\",\"type\":\"plugin\",\"creationDate\":\"28 March 2011\",\"author\":\"Marijn Haverbeke\",\"copyright\":\"\",\"authorEmail\":\"N\\/A\",\"authorUrl\":\"\",\"version\":\"3.15\",\"description\":\"PLG_CODEMIRROR_XML_DESCRIPTION\",\"group\":\"\"}','{\"lineNumbers\":\"1\",\"lineWrapping\":\"1\",\"matchTags\":\"1\",\"matchBrackets\":\"1\",\"marker-gutter\":\"1\",\"autoCloseTags\":\"1\",\"autoCloseBrackets\":\"1\",\"autoFocus\":\"1\",\"theme\":\"default\",\"tabmode\":\"indent\"}','','',0,'0000-00-00 00:00:00',1,0),(411,'plg_editors_none','plugin','none','editors',0,1,1,1,'{\"name\":\"plg_editors_none\",\"type\":\"plugin\",\"creationDate\":\"August 2004\",\"author\":\"Unknown\",\"copyright\":\"\",\"authorEmail\":\"N\\/A\",\"authorUrl\":\"\",\"version\":\"3.0.0\",\"description\":\"PLG_NONE_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',2,0),(412,'plg_editors_tinymce','plugin','tinymce','editors',0,1,1,0,'{\"name\":\"plg_editors_tinymce\",\"type\":\"plugin\",\"creationDate\":\"2005-2013\",\"author\":\"Moxiecode Systems AB\",\"copyright\":\"Moxiecode Systems AB\",\"authorEmail\":\"N\\/A\",\"authorUrl\":\"tinymce.moxiecode.com\",\"version\":\"4.0.10\",\"description\":\"PLG_TINY_XML_DESCRIPTION\",\"group\":\"\"}','{\"mode\":\"1\",\"skin\":\"0\",\"compressed\":\"0\",\"cleanup_startup\":\"0\",\"cleanup_save\":\"2\",\"entity_encoding\":\"raw\",\"lang_mode\":\"0\",\"lang_code\":\"en\",\"text_direction\":\"ltr\",\"content_css\":\"1\",\"content_css_custom\":\"\",\"relative_urls\":\"1\",\"newlines\":\"0\",\"invalid_elements\":\"script,applet,iframe\",\"extended_elements\":\"\",\"toolbar\":\"top\",\"toolbar_align\":\"left\",\"html_height\":\"550\",\"html_width\":\"750\",\"element_path\":\"1\",\"fonts\":\"1\",\"paste\":\"1\",\"searchreplace\":\"1\",\"insertdate\":\"1\",\"format_date\":\"%Y-%m-%d\",\"inserttime\":\"1\",\"format_time\":\"%H:%M:%S\",\"colors\":\"1\",\"table\":\"1\",\"smilies\":\"1\",\"media\":\"1\",\"hr\":\"1\",\"directionality\":\"1\",\"fullscreen\":\"1\",\"style\":\"1\",\"layer\":\"1\",\"xhtmlxtras\":\"1\",\"visualchars\":\"1\",\"nonbreaking\":\"1\",\"template\":\"1\",\"blockquote\":\"1\",\"wordcount\":\"1\",\"advimage\":\"1\",\"advlink\":\"1\",\"autosave\":\"1\",\"contextmenu\":\"1\",\"inlinepopups\":\"1\",\"safari\":\"0\",\"custom_plugin\":\"\",\"custom_button\":\"\"}','','',0,'0000-00-00 00:00:00',3,0),(413,'plg_editors-xtd_article','plugin','article','editors-xtd',0,1,1,1,'{\"name\":\"plg_editors-xtd_article\",\"type\":\"plugin\",\"creationDate\":\"October 2009\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_ARTICLE_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',1,0),(414,'plg_editors-xtd_image','plugin','image','editors-xtd',0,1,1,0,'{\"name\":\"plg_editors-xtd_image\",\"type\":\"plugin\",\"creationDate\":\"August 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_IMAGE_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',2,0),(415,'plg_editors-xtd_pagebreak','plugin','pagebreak','editors-xtd',0,1,1,0,'{\"name\":\"plg_editors-xtd_pagebreak\",\"type\":\"plugin\",\"creationDate\":\"August 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_EDITORSXTD_PAGEBREAK_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',3,0),(416,'plg_editors-xtd_readmore','plugin','readmore','editors-xtd',0,1,1,0,'{\"name\":\"plg_editors-xtd_readmore\",\"type\":\"plugin\",\"creationDate\":\"March 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_READMORE_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',4,0),(417,'plg_search_categories','plugin','categories','search',0,1,1,0,'{\"name\":\"plg_search_categories\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SEARCH_CATEGORIES_XML_DESCRIPTION\",\"group\":\"\"}','{\"search_limit\":\"50\",\"search_content\":\"1\",\"search_archived\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(418,'plg_search_contacts','plugin','contacts','search',0,1,1,0,'{\"name\":\"plg_search_contacts\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SEARCH_CONTACTS_XML_DESCRIPTION\",\"group\":\"\"}','{\"search_limit\":\"50\",\"search_content\":\"1\",\"search_archived\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(419,'plg_search_content','plugin','content','search',0,1,1,0,'{\"name\":\"plg_search_content\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SEARCH_CONTENT_XML_DESCRIPTION\",\"group\":\"\"}','{\"search_limit\":\"50\",\"search_content\":\"1\",\"search_archived\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(420,'plg_search_newsfeeds','plugin','newsfeeds','search',0,1,1,0,'{\"name\":\"plg_search_newsfeeds\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SEARCH_NEWSFEEDS_XML_DESCRIPTION\",\"group\":\"\"}','{\"search_limit\":\"50\",\"search_content\":\"1\",\"search_archived\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(421,'plg_search_weblinks','plugin','weblinks','search',0,1,1,0,'{\"name\":\"plg_search_weblinks\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SEARCH_WEBLINKS_XML_DESCRIPTION\",\"group\":\"\"}','{\"search_limit\":\"50\",\"search_content\":\"1\",\"search_archived\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(422,'plg_system_languagefilter','plugin','languagefilter','system',0,0,1,1,'{\"name\":\"plg_system_languagefilter\",\"type\":\"plugin\",\"creationDate\":\"July 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SYSTEM_LANGUAGEFILTER_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',1,0),(423,'plg_system_p3p','plugin','p3p','system',0,1,1,0,'{\"name\":\"plg_system_p3p\",\"type\":\"plugin\",\"creationDate\":\"September 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_P3P_XML_DESCRIPTION\",\"group\":\"\"}','{\"headers\":\"NOI ADM DEV PSAi COM NAV OUR OTRo STP IND DEM\"}','','',0,'0000-00-00 00:00:00',2,0),(424,'plg_system_cache','plugin','cache','system',0,0,1,1,'{\"name\":\"plg_system_cache\",\"type\":\"plugin\",\"creationDate\":\"February 2007\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_CACHE_XML_DESCRIPTION\",\"group\":\"\"}','{\"browsercache\":\"0\",\"cachetime\":\"15\"}','','',0,'0000-00-00 00:00:00',9,0),(425,'plg_system_debug','plugin','debug','system',0,1,1,0,'{\"name\":\"plg_system_debug\",\"type\":\"plugin\",\"creationDate\":\"December 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_DEBUG_XML_DESCRIPTION\",\"group\":\"\"}','{\"profile\":\"1\",\"queries\":\"1\",\"memory\":\"1\",\"language_files\":\"1\",\"language_strings\":\"1\",\"strip-first\":\"1\",\"strip-prefix\":\"\",\"strip-suffix\":\"\"}','','',0,'0000-00-00 00:00:00',4,0),(426,'plg_system_log','plugin','log','system',0,1,1,1,'{\"name\":\"plg_system_log\",\"type\":\"plugin\",\"creationDate\":\"April 2007\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_LOG_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',5,0),(427,'plg_system_redirect','plugin','redirect','system',0,1,1,1,'{\"name\":\"plg_system_redirect\",\"type\":\"plugin\",\"creationDate\":\"April 2009\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_REDIRECT_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',6,0),(428,'plg_system_remember','plugin','remember','system',0,1,1,1,'{\"name\":\"plg_system_remember\",\"type\":\"plugin\",\"creationDate\":\"April 2007\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_REMEMBER_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',7,0),(429,'plg_system_sef','plugin','sef','system',0,1,1,0,'{\"name\":\"plg_system_sef\",\"type\":\"plugin\",\"creationDate\":\"December 2007\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SEF_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',8,0),(430,'plg_system_logout','plugin','logout','system',0,1,1,1,'{\"name\":\"plg_system_logout\",\"type\":\"plugin\",\"creationDate\":\"April 2009\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SYSTEM_LOGOUT_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',3,0),(431,'plg_user_contactcreator','plugin','contactcreator','user',0,0,1,0,'{\"name\":\"plg_user_contactcreator\",\"type\":\"plugin\",\"creationDate\":\"August 2009\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_CONTACTCREATOR_XML_DESCRIPTION\",\"group\":\"\"}','{\"autowebpage\":\"\",\"category\":\"34\",\"autopublish\":\"0\"}','','',0,'0000-00-00 00:00:00',1,0),(432,'plg_user_joomla','plugin','joomla','user',0,1,1,0,'{\"name\":\"plg_user_joomla\",\"type\":\"plugin\",\"creationDate\":\"December 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2009 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_USER_JOOMLA_XML_DESCRIPTION\",\"group\":\"\"}','{\"autoregister\":\"1\",\"strong_passwords\":1}','','',0,'0000-00-00 00:00:00',2,0),(433,'plg_user_profile','plugin','profile','user',0,0,1,0,'{\"name\":\"plg_user_profile\",\"type\":\"plugin\",\"creationDate\":\"January 2008\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_USER_PROFILE_XML_DESCRIPTION\",\"group\":\"\"}','{\"register-require_address1\":\"1\",\"register-require_address2\":\"1\",\"register-require_city\":\"1\",\"register-require_region\":\"1\",\"register-require_country\":\"1\",\"register-require_postal_code\":\"1\",\"register-require_phone\":\"1\",\"register-require_website\":\"1\",\"register-require_favoritebook\":\"1\",\"register-require_aboutme\":\"1\",\"register-require_tos\":\"1\",\"register-require_dob\":\"1\",\"profile-require_address1\":\"1\",\"profile-require_address2\":\"1\",\"profile-require_city\":\"1\",\"profile-require_region\":\"1\",\"profile-require_country\":\"1\",\"profile-require_postal_code\":\"1\",\"profile-require_phone\":\"1\",\"profile-require_website\":\"1\",\"profile-require_favoritebook\":\"1\",\"profile-require_aboutme\":\"1\",\"profile-require_tos\":\"1\",\"profile-require_dob\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(434,'plg_extension_joomla','plugin','joomla','extension',0,1,1,1,'{\"name\":\"plg_extension_joomla\",\"type\":\"plugin\",\"creationDate\":\"May 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_EXTENSION_JOOMLA_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',1,0),(435,'plg_content_joomla','plugin','joomla','content',0,1,1,0,'{\"name\":\"plg_content_joomla\",\"type\":\"plugin\",\"creationDate\":\"November 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_CONTENT_JOOMLA_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(436,'plg_system_languagecode','plugin','languagecode','system',0,0,1,0,'{\"name\":\"plg_system_languagecode\",\"type\":\"plugin\",\"creationDate\":\"November 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SYSTEM_LANGUAGECODE_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',10,0),(437,'plg_quickicon_joomlaupdate','plugin','joomlaupdate','quickicon',0,1,1,1,'{\"name\":\"plg_quickicon_joomlaupdate\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_QUICKICON_JOOMLAUPDATE_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(438,'plg_quickicon_extensionupdate','plugin','extensionupdate','quickicon',0,1,1,1,'{\"name\":\"plg_quickicon_extensionupdate\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_QUICKICON_EXTENSIONUPDATE_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(439,'plg_captcha_recaptcha','plugin','recaptcha','captcha',0,1,1,0,'{\"name\":\"plg_captcha_recaptcha\",\"type\":\"plugin\",\"creationDate\":\"December 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_CAPTCHA_RECAPTCHA_XML_DESCRIPTION\",\"group\":\"\"}','{\"public_key\":\"6Ld4bekSAAAAAIAwfcWsrVhtScnMXMfFBbaxM3Ls \",\"private_key\":\"6Ld4bekSAAAAALVBkDwbfwpCaNq8ZOW26RAqmOND \",\"theme\":\"clean\"}','','',335,'2013-12-09 06:47:51',0,0),(440,'plg_system_highlight','plugin','highlight','system',0,1,1,0,'','{}','','',0,'0000-00-00 00:00:00',7,0),(441,'plg_content_finder','plugin','finder','content',0,0,1,0,'{\"legacy\":false,\"name\":\"plg_content_finder\",\"type\":\"plugin\",\"creationDate\":\"December 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"1.7.0\",\"description\":\"PLG_CONTENT_FINDER_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(442,'plg_finder_categories','plugin','categories','finder',0,1,1,0,'{\"name\":\"plg_finder_categories\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_FINDER_CATEGORIES_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',1,0),(443,'plg_finder_contacts','plugin','contacts','finder',0,1,1,0,'{\"name\":\"plg_finder_contacts\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_FINDER_CONTACTS_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',2,0),(444,'plg_finder_content','plugin','content','finder',0,1,1,0,'{\"name\":\"plg_finder_content\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_FINDER_CONTENT_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',3,0),(445,'plg_finder_newsfeeds','plugin','newsfeeds','finder',0,1,1,0,'{\"name\":\"plg_finder_newsfeeds\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_FINDER_NEWSFEEDS_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',4,0),(446,'plg_finder_weblinks','plugin','weblinks','finder',0,1,1,0,'{\"name\":\"plg_finder_weblinks\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_FINDER_WEBLINKS_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',5,0),(447,'plg_finder_tags','plugin','tags','finder',0,1,1,0,'{\"name\":\"plg_finder_tags\",\"type\":\"plugin\",\"creationDate\":\"February 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_FINDER_TAGS_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(448,'plg_twofactorauth_totp','plugin','totp','twofactorauth',0,1,1,0,'{\"name\":\"plg_twofactorauth_totp\",\"type\":\"plugin\",\"creationDate\":\"August 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.0\",\"description\":\"PLG_TWOFACTORAUTH_TOTP_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(449,'plg_authentication_cookie','plugin','cookie','authentication',0,1,1,0,'{\"name\":\"plg_authentication_cookie\",\"type\":\"plugin\",\"creationDate\":\"July 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_AUTH_COOKIE_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(450,'plg_twofactorauth_yubikey','plugin','yubikey','twofactorauth',0,1,1,0,'{\"name\":\"plg_twofactorauth_yubikey\",\"type\":\"plugin\",\"creationDate\":\"Se[ptember 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.0\",\"description\":\"PLG_TWOFACTORAUTH_YUBIKEY_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(500,'atomic','template','atomic','',0,1,1,0,'{\"legacy\":false,\"name\":\"atomic\",\"type\":\"template\",\"creationDate\":\"10\\/10\\/09\",\"author\":\"Ron Severdia\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.\",\"authorEmail\":\"contact@kontentdesign.com\",\"authorUrl\":\"http:\\/\\/www.kontentdesign.com\",\"version\":\"2.5.0\",\"description\":\"TPL_ATOMIC_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(502,'bluestork','template','bluestork','',1,1,1,0,'{\"legacy\":false,\"name\":\"bluestork\",\"type\":\"template\",\"creationDate\":\"07\\/02\\/09\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"TPL_BLUESTORK_XML_DESCRIPTION\",\"group\":\"\"}','{\"useRoundedCorners\":\"1\",\"showSiteName\":\"0\",\"textBig\":\"0\",\"highContrast\":\"0\"}','','',0,'0000-00-00 00:00:00',0,0),(503,'beez_20','template','beez_20','',0,1,1,0,'{\"legacy\":false,\"name\":\"beez_20\",\"type\":\"template\",\"creationDate\":\"25 November 2009\",\"author\":\"Angie Radtke\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.\",\"authorEmail\":\"a.radtke@derauftritt.de\",\"authorUrl\":\"http:\\/\\/www.der-auftritt.de\",\"version\":\"2.5.0\",\"description\":\"TPL_BEEZ2_XML_DESCRIPTION\",\"group\":\"\"}','{\"wrapperSmall\":\"53\",\"wrapperLarge\":\"72\",\"sitetitle\":\"\",\"sitedescription\":\"\",\"navposition\":\"center\",\"templatecolor\":\"nature\"}','','',0,'0000-00-00 00:00:00',0,0),(504,'hathor','template','hathor','',1,1,1,0,'{\"name\":\"hathor\",\"type\":\"template\",\"creationDate\":\"May 2010\",\"author\":\"Andrea Tarr\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters, Inc. All rights reserved.\",\"authorEmail\":\"hathor@tarrconsulting.com\",\"authorUrl\":\"http:\\/\\/www.tarrconsulting.com\",\"version\":\"3.0.0\",\"description\":\"TPL_HATHOR_XML_DESCRIPTION\",\"group\":\"\"}','{\"showSiteName\":\"0\",\"colourChoice\":\"0\",\"boldText\":\"0\"}','','',0,'0000-00-00 00:00:00',0,0),(505,'beez5','template','beez5','',0,1,1,0,'{\"legacy\":false,\"name\":\"beez5\",\"type\":\"template\",\"creationDate\":\"21 May 2010\",\"author\":\"Angie Radtke\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.\",\"authorEmail\":\"a.radtke@derauftritt.de\",\"authorUrl\":\"http:\\/\\/www.der-auftritt.de\",\"version\":\"2.5.0\",\"description\":\"TPL_BEEZ5_XML_DESCRIPTION\",\"group\":\"\"}','{\"wrapperSmall\":\"53\",\"wrapperLarge\":\"72\",\"sitetitle\":\"\",\"sitedescription\":\"\",\"navposition\":\"center\",\"html5\":\"0\"}','','',0,'0000-00-00 00:00:00',0,0),(600,'English (United Kingdom)','language','en-GB','',0,1,1,1,'{\"name\":\"English (United Kingdom)\",\"type\":\"language\",\"creationDate\":\"2013-03-07\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.0\",\"description\":\"en-GB site language\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(601,'English (United Kingdom)','language','en-GB','',1,1,1,1,'{\"name\":\"English (United Kingdom)\",\"type\":\"language\",\"creationDate\":\"2013-03-07\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.0\",\"description\":\"en-GB administrator language\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(700,'files_joomla','file','joomla','',0,1,1,1,'{\"name\":\"files_joomla\",\"type\":\"file\",\"creationDate\":\"November 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2013 Open Source Matters. All rights reserved\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.0\",\"description\":\"FILES_JOOMLA_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(10000,'Our Poll','module','mod_poll','',0,1,1,0,'','','','',0,'0000-00-00 00:00:00',0,0),(10002,'Popular Articles','module','mod_mostread','',0,1,1,0,'','','','',0,'0000-00-00 00:00:00',0,0),(10003,'Archive','module','mod_archive','',0,1,1,0,'','','','',0,'0000-00-00 00:00:00',0,0),(10004,'Sections','module','mod_sections','',0,1,1,0,'','','','',0,'0000-00-00 00:00:00',0,0),(10014,'Our Latest News','module','mod_latestnews','',0,1,1,0,'','','','',0,'0000-00-00 00:00:00',0,0),(10015,'S5 Accordion Menu','module','mod_s5_accordion_menu','',0,1,1,0,'','','','',0,'0000-00-00 00:00:00',0,0),(10016,'Register','module','mod_s5_register','',0,1,1,0,'','','','',0,'0000-00-00 00:00:00',0,0),(10017,'Featured News','module','mod_newsflash','',0,1,1,0,'','','','',0,'0000-00-00 00:00:00',0,0),(10021,'VirtueMart Product Snapshot','plugin','vmproductsnapshots','',0,1,1,0,'','','','',0,'0000-00-00 00:00:00',0,0),(10022,'Virtuemart Extended Search Plugin','plugin','vmxsearch.plugin','',0,1,1,0,'','','','',0,'0000-00-00 00:00:00',0,0),(10029,'System - S5 Flex Menu','plugin','S5FlexMenu','system',0,1,1,0,'{\"legacy\":false,\"name\":\"System - S5 Flex Menu\",\"type\":\"plugin\",\"creationDate\":\"June 2011\",\"author\":\"Shape5.com\",\"copyright\":\"This Plugin is released under the GNU\\/GPL License\",\"authorEmail\":\"contact@shape5.com\",\"authorUrl\":\"www.shape5.com\",\"version\":\"1.0\",\"description\":\"The S5 Flex Menu system is a very powerful plugin that provides functionality far beyond the standard Joomla menu system.\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10031,'PKG_JOOMLA','package','pkg_joomla','',0,1,1,1,'{\"legacy\":false,\"name\":\"PKG_JOOMLA\",\"type\":\"package\",\"creationDate\":\"2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"http:\\/\\/www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PKG_JOOMLA_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(10039,'S5 Box','module','mod_s5_box','',0,1,0,0,'{\"legacy\":false,\"name\":\"S5 Box\",\"type\":\"module\",\"creationDate\":\"September 2009\",\"author\":\"Shape5.com\",\"copyright\":\"Copyright (C) 2005 - 2008 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"The S5 Box allows you to display any module in lightbox style popup activated by a class name.  Choose either Mootools or Javascript library.  It can display up to 10 S5 Box\'s by simply adding a class name to any HTML element and a module position to your template XML file. Check out the tutorial on http:\\/\\/www.shape5.com\\/demo\\/elegance\\/s5_box\\/ for more information.\",\"group\":\"\"}','{\"\":\"Use the settings below to alter the width of the S5 Box\'s be sure to publish a module to each corresponding position for the box to be enabled. Please visit the following url for a tutorial http:\\/\\/www.shape5.com\\/demo\\/elegance\\/s5_box\\/\",\"@spacer\":\"\",\"s5_jsversion\":\"mootools\",\"s5_boxeffect\":\"elastic\",\"s5boxwidth1\":\"35\",\"s5boxwidth2\":\"35\",\"s5boxwidth3\":\"35\",\"s5boxwidth4\":\"35\",\"s5boxwidth5\":\"35\",\"s5boxwidth6\":\"35\",\"s5boxwidth7\":\"35\",\"s5boxwidth8\":\"35\",\"s5boxwidth9\":\"35\",\"s5boxwidth10\":\"35\",\"moduleclass_sfx\":\"-s5_box\"}','','',0,'0000-00-00 00:00:00',0,0),(10040,'S5 Image and Content Fader v3','module','mod_s5_image_and_content_fader','',0,1,0,0,'{\"legacy\":false,\"name\":\"S5 Image and Content Fader v3\",\"type\":\"module\",\"creationDate\":\"July 2010\",\"author\":\"Shape5.com\",\"copyright\":\"\",\"authorEmail\":\"contact@shape5.com\",\"authorUrl\":\"www.shape5.com\",\"version\":\"3.0.0\",\"description\":\"This module is responsive ready!  It will display images of any url and user defined conent in one of 4 effect transitions.  Choose between actual size and stretch for your images and enter in pixels or percentages for your width, great for responsive\\/fluid websites!  Powered by Mootools but if you experience conflicts you can enable legacy S5 Effects mode (contains less features than Mootools version).  \",\"group\":\"\"}','{\"pretext\":\"\",\"moduleclass_sfx\":\"\",\"height\":\"183px\",\"width\":\"482px\",\"s5stretchimage\":\"actualsize\",\"s5pixelwidth\":\"0px\",\"background\":\"\",\"jslibrary\":\"mootools\",\"jseffect\":\"fade\",\"s5_dropdowntext\":\"Open Gallery\",\"s5_delay\":\"9000\",\"s5_hidecar\":\"truee\",\"s5_hidebut\":\"truee\",\"s5_hidetext\":\"truee\",\"title1\":\"\",\"title2\":\"\",\"title3\":\"\",\"title4\":\"\",\"title5\":\"\",\"title6\":\"\",\"title7\":\"\",\"title8\":\"\",\"title9\":\"\",\"title10\":\"\",\"picture1\":\"\",\"picture1link\":\"\",\"picture1text\":\"\",\"picture2\":\"\",\"picture2link\":\"\",\"picture2text\":\"\",\"picture3\":\"\",\"picture3link\":\"\",\"picture3text\":\"\",\"picture4\":\"\",\"picture4link\":\"\",\"picture4text\":\"\",\"picture5\":\"\",\"picture5link\":\"\",\"picture5text\":\"\",\"picture6\":\"\",\"picture6link\":\"\",\"picture6text\":\"\",\"picture7\":\"\",\"picture7link\":\"\",\"picture7text\":\"\",\"picture8\":\"\",\"picture8link\":\"\",\"picture8text\":\"\",\"picture9\":\"\",\"picture9link\":\"\",\"picture9text\":\"\",\"picture10\":\"\",\"picture10link\":\"\",\"picture10text\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10044,'S5 Tab Show','module','mod_s5_tabshow','',0,1,0,0,'{\"legacy\":false,\"name\":\"S5 Tab Show\",\"type\":\"module\",\"creationDate\":\"November 2008\",\"author\":\"Shape5.com\",\"copyright\":\"\",\"authorEmail\":\"contact@shape5.com\",\"authorUrl\":\"www.shape5.com\",\"version\":\"1.6.0\",\"description\":\"This module will display up to 10 Joomla modules in various styles with tabs.\",\"group\":\"\"}','{\"s5_width\":\"310\",\"s5_buttonheight\":\"27px\",\"s5_lineheight\":\"2.2em\",\"s5_buttoncolor\":\"transparent\",\"s5_buttonimage\":\"..\\/modules\\/mod_s5_tabshow\\/s5_tabshow\\/s5_tab_show_nonactive.png\",\"s5_hovercolor\":\"#FFFFFF\",\"s5_hoverimage\":\"..\\/modules\\/mod_s5_tabshow\\/s5_tabshow\\/s5_tab_show_active.png\",\"s5_fontcolor\":\"#000000\",\"s5_javascript\":\"mootools\",\"s5_mootoolsmouse\":\"mouse\",\"s5_effectsani\":\"fade\",\"s5_effectmouse\":\"mouse\",\"text1line\":\"Tab 1\"}','','',0,'0000-00-00 00:00:00',0,0),(10045,'new_vision','template','new_vision','',0,1,1,0,'{\"legacy\":false,\"name\":\"new_vision\",\"type\":\"template\",\"creationDate\":\"October 2012\",\"author\":\"Shape5.com\",\"copyright\":\"Shape5\",\"authorEmail\":\"contact@shape5.com\",\"authorUrl\":\"http:\\/\\/www.shape5.com\",\"version\":\"1.0\",\"description\":\"\\n\\t\\n\\t<h1>Shape 5 - New Vision<\\/h1>\\n\\n\\t<br\\/>\\n\\t<img src=\\\"..\\/templates\\/new_vision\\/template_thumbnail.png\\\" align=\\\"left\\\" hspace=\\\"10\\\" style=\\\"padding-right:10px;\\\"\\/>\\n\\tThis template is for members of the Shape 5 Joomla Template Club only, it is not free or open to the public domain.  <br \\/><br \\/>\\n\\tFor tutorials pertaining to this template and additional information check out:<br \\/> <a href=\\\"http:\\/\\/www.shape5.com\\/demo\\/new_vision\\\">New Vision Demo<\\/a>\\n\\t<br \\/>\\n\\t<a href=\\\"http:\\/\\/www.shape5.com\\/joomla_tutorials.html\\\">Joomla and Vertex Tutorials<\\/a>\\n\\t<br \\/>\\n\\t<br \\/><a target=\\\"_blank\\\" href=\\\"http:\\/\\/www.shape5.com\\\">Click here<\\/a> to visit Shape5.com\\n\\t<br \\/><br \\/>\\n\\t<div class=\\\"vertex-admin-logoback\\\"><div class=\\\"vertex-admin-logo\\\"><\\/div><\\/div>\\n\\t<br \\/><br \\/>\\n\\tPowered by a comprehensive template blue print<br\\/><br\\/>\\n\\t<a target=\\\"_blank\\\" href=\\\"http:\\/\\/www.shape5.com\\/joomla\\/framework\\/vertex_framework.html\\\">Read more about Vertex here<\\/a> \\n\\t\\n\\t\\n\\t\\n\\t\",\"group\":\"\"}','{\"settings\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10047,'isis','template','isis','',1,1,1,0,'{\"name\":\"isis\",\"type\":\"template\",\"creationDate\":\"3\\/30\\/2012\",\"author\":\"Kyle Ledbetter\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters, Inc. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"\",\"version\":\"1.0\",\"description\":\"TPL_ISIS_XML_DESCRIPTION\",\"group\":\"\"}','{\"templateColor\":\"\",\"logoFile\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10048,'protostar','template','protostar','',0,1,1,0,'{\"name\":\"protostar\",\"type\":\"template\",\"creationDate\":\"4\\/30\\/2012\",\"author\":\"Kyle Ledbetter\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters, Inc. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"\",\"version\":\"1.0\",\"description\":\"TPL_PROTOSTAR_XML_DESCRIPTION\",\"group\":\"\"}','{\"templateColor\":\"\",\"logoFile\":\"\",\"googleFont\":\"1\",\"googleFontName\":\"Open+Sans\",\"fluidContainer\":\"0\"}','','',0,'0000-00-00 00:00:00',0,0),(10049,'beez3','template','beez3','',0,1,1,0,'{\"name\":\"beez3\",\"type\":\"template\",\"creationDate\":\"25 November 2009\",\"author\":\"Angie Radtke\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters, Inc. All rights reserved.\",\"authorEmail\":\"a.radtke@derauftritt.de\",\"authorUrl\":\"http:\\/\\/www.der-auftritt.de\",\"version\":\"3.1.0\",\"description\":\"TPL_BEEZ3_XML_DESCRIPTION\",\"group\":\"\"}','{\"wrapperSmall\":\"53\",\"wrapperLarge\":\"72\",\"sitetitle\":\"\",\"sitedescription\":\"\",\"navposition\":\"center\",\"templatecolor\":\"nature\"}','','',0,'0000-00-00 00:00:00',0,0),(10050,'com_jsjobs','component','com_jsjobs','',1,1,0,0,'{\"name\":\"COM_JSJOBS\",\"type\":\"component\",\"creationDate\":\"Nov 15th, 2013\",\"author\":\"Joom Sky\",\"copyright\":\"Copyright (c) 2014. All rights reserved.\",\"authorEmail\":\"ahmad@burujsolutions.com\",\"authorUrl\":\"\",\"version\":\"1.0.9.0\",\"description\":\"Jobs Board Component.\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10051,'JS Featured Companies','module','mod_jsfeaturedcompanies','',0,1,0,0,'{\"name\":\"JS Featured Companies\",\"type\":\"module\",\"creationDate\":\"Nov 29, 2010\",\"author\":\"Joom Sky\",\"copyright\":\"(C) 2009 - 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0.0\",\"description\":\"Show featured companies from JS Jobs database. \",\"group\":\"\"}','{\"noofcompanies\":\"7\",\"theme\":\"1\",\"title\":\"Featured Companies\",\"listingstyle\":\"1\",\"shtitle\":\"1\",\"category\":\"1\",\"location\":\"1\",\"posteddate\":\"1\",\"noofcols\":\"3\",\"companyname\":\"1\",\"logo\":\"1\",\"logowidth\":\"130\",\"logoheight\":\"70\",\"separator\":\"1\",\"sliding\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10052,'JS Featured Jobs','module','mod_jsfeaturedjobs','',0,1,0,0,'{\"name\":\"JS Featured Jobs\",\"type\":\"module\",\"creationDate\":\"Nov 29, 2010\",\"author\":\"Joom Sky\",\"copyright\":\"(C) 2009 - 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0.0\",\"description\":\"Show featured jobs from JS Jobs database. \",\"group\":\"\"}','{\"noofjobs\":\"7\",\"theme\":\"1\",\"title\":\"Featured Jobs\",\"listingstyle\":\"1\",\"shtitle\":\"1\",\"company\":\"1\",\"category\":\"1\",\"subcategory\":\"0\",\"jobtype\":\"1\",\"location\":\"1\",\"posteddate\":\"1\",\"noofcols\":\"3\",\"logo\":\"1\",\"logowidth\":\"130\",\"logoheight\":\"70\",\"separator\":\"1\",\"sliding\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10053,'JS Featured Resumes','module','mod_jsfeaturedresumes','',0,1,0,0,'{\"name\":\"JS Featured Resumes\",\"type\":\"module\",\"creationDate\":\"Nov 29, 2010\",\"author\":\"Joom Sky\",\"copyright\":\"(C) 2009 - 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0.0\",\"description\":\"Show featured resumes from JS Jobs database. \",\"group\":\"\"}','{\"noofresumes\":\"7\",\"theme\":\"2\",\"title\":\"Featured Resumes\",\"listingstyle\":\"1\",\"shtitle\":\"1\",\"applicationtitle\":\"1\",\"name\":\"1\",\"category\":\"1\",\"subcategory\":\"0\",\"jobtype\":\"1\",\"experience\":\"1\",\"available\":\"1\",\"gender\":\"1\",\"nationality\":\"1\",\"location\":\"1\",\"posteddate\":\"1\",\"noofcols\":\"3\",\"photo\":\"1\",\"photowidth\":\"130\",\"photoheight\":\"70\",\"separator\":\"1\",\"sliding\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10054,'JS Gold Companies','module','mod_jsgoldcompanies','',0,1,0,0,'{\"name\":\"JS Gold Companies\",\"type\":\"module\",\"creationDate\":\"Nov 29, 2010\",\"author\":\"Joom Sky\",\"copyright\":\"(C) 2009 - 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0.0\",\"description\":\"Show gold companies from JS Jobs database. \",\"group\":\"\"}','{\"noofcompanies\":\"7\",\"theme\":\"1\",\"title\":\"Gold Companies\",\"listingstyle\":\"1\",\"shtitle\":\"1\",\"category\":\"1\",\"location\":\"1\",\"posteddate\":\"1\",\"noofcols\":\"3\",\"companyname\":\"1\",\"logo\":\"1\",\"logowidth\":\"130\",\"logoheight\":\"70\",\"separator\":\"1\",\"sliding\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10055,'JS Gold Jobs','module','mod_jsgoldjobs','',0,1,0,0,'{\"name\":\"JS Gold Jobs\",\"type\":\"module\",\"creationDate\":\"Nov 28, 2010\",\"author\":\"Joom Sky\",\"copyright\":\"(C) 2009 - 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0.0\",\"description\":\"Show gold jobs from JS Jobs database. \",\"group\":\"\"}','{\"noofjobs\":\"7\",\"theme\":\"1\",\"title\":\"Gold Jobs\",\"listingstyle\":\"1\",\"shtitle\":\"1\",\"company\":\"1\",\"category\":\"1\",\"subcategory\":\"0\",\"jobtype\":\"1\",\"location\":\"1\",\"posteddate\":\"1\",\"noofcols\":\"3\",\"logo\":\"1\",\"logowidth\":\"130\",\"logoheight\":\"70\",\"separator\":\"1\",\"sliding\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10056,'JS Gold Resumes','module','mod_jsgoldresumes','',0,1,0,0,'{\"name\":\"JS Gold Resumes\",\"type\":\"module\",\"creationDate\":\"Nov 29, 2010\",\"author\":\"Joom Sky\",\"copyright\":\"(C) 2009 - 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0.0\",\"description\":\"Show gold resumes from JS Jobs database. \",\"group\":\"\"}','{\"noofresumes\":\"7\",\"theme\":\"2\",\"title\":\"Gold Resumes\",\"listingstyle\":\"1\",\"shtitle\":\"1\",\"applicationtitle\":\"1\",\"name\":\"1\",\"category\":\"1\",\"subcategory\":\"0\",\"jobtype\":\"1\",\"experience\":\"1\",\"available\":\"1\",\"gender\":\"1\",\"nationality\":\"1\",\"location\":\"1\",\"posteddate\":\"1\",\"noofcols\":\"3\",\"photo\":\"1\",\"photowidth\":\"130\",\"photoheight\":\"70\",\"separator\":\"1\",\"sliding\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10057,'JS Hot Jobs','module','mod_hotjsjobs','',0,1,0,0,'{\"name\":\"JS Hot Jobs\",\"type\":\"module\",\"creationDate\":\"Nov 27, 2010\",\"author\":\"Joom Sky\",\"copyright\":\"(C) 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0.2\",\"description\":\"Show most applied jobs from JS Jobs database. \",\"group\":\"\"}','{\"noofjobs\":\"7\",\"theme\":\"1\",\"company\":\"1\",\"category\":\"1\",\"subcategory\":\"0\",\"jobtype\":\"1\",\"posteddate\":\"1\",\"separator\":\"1\",\"sliding\":\"1\",\"slidingdirection\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10058,'Search JS Jobs','module','mod_jsjobssearch','',0,1,0,0,'{\"name\":\"Search JS Jobs\",\"type\":\"module\",\"creationDate\":\"Nov 27th, 2010\",\"author\":\"Joom Sky\",\"copyright\":\"(C) 2009 - 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0.3\",\"description\":\"Job Search form for JS Jobs. \",\"group\":\"\"}','{\"category\":\"1\",\"subcategory\":\"1\",\"jobtype\":\"1\",\"jobstatus\":\"1\",\"salaryrange\":\"1\",\"shift\":\"1\",\"durration\":\"1\",\"startpublishing\":\"1\",\"stoppublishing\":\"1\",\"company\":\"1\",\"addresses\":\"1\",\"colperrow\":\"\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10059,'JS Resume Search','module','mod_jsresumesearch','',0,1,0,0,'{\"name\":\"JS Resume Search\",\"type\":\"module\",\"creationDate\":\"Oct 29th, 2009\",\"author\":\"Joom Sky\",\"copyright\":\"(C) 2009. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0\",\"description\":\"Resume Search form for JS Jobs. \",\"group\":\"\"}','{\"title\":\"1\",\"name\":\"1\",\"natinality\":\"1\",\"gender\":\"1\",\"iamavailable\":\"1\",\"category\":\"1\",\"subcategory\":\"1\",\"jobtype\":\"1\",\"salaryrange\":\"1\",\"heighesteducation\":\"1\",\"experience\":\"1\",\"colperrow\":\"\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10060,'JS Top Resume','module','mod_jstopresume','',0,1,0,0,'{\"name\":\"JS Top Resume\",\"type\":\"module\",\"creationDate\":\"Nov 27, 2010\",\"author\":\"Joom Sky\",\"copyright\":\"(C) 2009 - 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0.1\",\"description\":\"Show most viewed resume from JS Jobs database. \",\"group\":\"\"}','{\"noofresumes\":\"7\",\"theme\":\"1\",\"title\":\"1\",\"category\":\"1\",\"subcategory\":\"0\",\"jobtype\":\"1\",\"highesteducation\":\"1\",\"salaryrange\":\"1\",\"experience\":\"1\",\"available\":\"1\",\"gender\":\"1\",\"nationality\":\"1\",\"posteddate\":\"1\",\"separator\":\"1\",\"sliding\":\"1\",\"slidingdirection\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10061,'JS Job Categories','module','mod_jsjobcategories','',0,1,0,0,'{\"name\":\"JS Job Categories\",\"type\":\"module\",\"creationDate\":\"Dec 30, 2010\",\"author\":\"Joom Sky\",\"copyright\":\"(C) 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0.0\",\"description\":\"Show job categories from js jobs database. \",\"group\":\"\"}','{\"noofcategories\":\"-1\",\"theme\":\"1\",\"jobsincategory\":\"1\",\"allcategories\":\"0\",\"sliding\":\"1\",\"slidingdirection\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10062,'JS Jobs BY City','module','mod_jsjobscity','',0,1,0,0,'{\"name\":\"JS Jobs BY City\",\"type\":\"module\",\"creationDate\":\"jun 23, 2011\",\"author\":\"Joom Sky\",\"copyright\":\"(C) 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0.0\",\"description\":\"Show job by City from js jobs database. \",\"group\":\"\"}','{\"noofjobs\":\"-1\",\"theme\":\"1\",\"jobsincity\":\"1\",\"defaultcountry\":\"0\",\"allcity\":\"0\",\"sliding\":\"1\",\"slidingdirection\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10063,'JS Jobs BY Country','module','mod_jsjobscountry','',0,1,0,0,'{\"name\":\"JS Jobs BY Country\",\"type\":\"module\",\"creationDate\":\"jun 22, 2011\",\"author\":\"Joom Sky\",\"copyright\":\"(C) 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0.0\",\"description\":\"Show job by Couontry from js jobs database. \",\"group\":\"\"}','{\"noofjobs\":\"-1\",\"theme\":\"1\",\"jobsincountry\":\"1\",\"allcountries\":\"0\",\"sliding\":\"1\",\"slidingdirection\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10064,'JS Jobs Login','module','mod_jsjobslogin','',0,1,0,0,'{\"name\":\"JS Jobs Login\",\"type\":\"module\",\"creationDate\":\"Nov 22, 2010\",\"author\":\"Joom Sky\",\"copyright\":\"(C) 2009. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0\",\"description\":\"DESCLOGINFORM\",\"group\":\"\"}','{\"cache\":\"1\",\"@spacer\":\"\",\"moduleclass_sfx\":\"\",\"pretext\":\"\",\"login\":\"jsjobs\",\"logout\":\"\",\"greeting\":\"1\",\"name\":\"0\",\"usesecure\":\"0\"}','','',0,'0000-00-00 00:00:00',0,0),(10065,'JS Jobs Stats','module','mod_jsjobsstats','',0,1,0,0,'{\"name\":\"JS Jobs Stats\",\"type\":\"module\",\"creationDate\":\"Oct 31, 2011\",\"author\":\"Joom Sky\",\"copyright\":\"(C) 2009 - 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0.0\",\"description\":\"Show Jsjobs Stats  from JS Jobs database. \",\"group\":\"\"}','{\"title\":\"Jsjobs Stats\",\"shtitle\":\"1\",\"employer\":\"1\",\"jobseeker\":\"1\",\"jobs\":\"1\",\"companies\":\"1\",\"activejobs\":\"1\",\"resumes\":\"1\",\"todaystats\":\"1\",\"separator\":\"1\",\"sliding\":\"1\",\"slidingdirection\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10066,'Newest JS Jobs','module','mod_newestjsjobs','',0,1,0,0,'{\"name\":\"Newest JS Jobs\",\"type\":\"module\",\"creationDate\":\"Nov 27, 2010\",\"author\":\"Joom Sky\",\"copyright\":\"(C) 2009 - 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0.2\",\"description\":\"Show newest jobs from JS Jobs database. \",\"group\":\"\"}','{\"noofjobs\":\"7\",\"theme\":\"1\",\"company\":\"1\",\"category\":\"1\",\"subcategory\":\"0\",\"jobtype\":\"1\",\"posteddate\":\"1\",\"separator\":\"1\",\"colperrow\":\"\",\"sliding\":\"1\",\"slidingdirection\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10067,'JS Newest Resumes','module','mod_newestjsresume','',0,1,0,0,'{\"name\":\"JS Newest Resumes\",\"type\":\"module\",\"creationDate\":\"Nov 27th, 2010\",\"author\":\"Joom Sky\",\"copyright\":\"(C) 2009 - 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0.1\",\"description\":\"Show newest resumes from JS Jobs database. \",\"group\":\"\"}','{\"noofresumes\":\"7\",\"theme\":\"1\",\"title\":\"1\",\"category\":\"1\",\"subcategory\":\"0\",\"jobtype\":\"1\",\"highesteducation\":\"1\",\"salaryrange\":\"1\",\"experience\":\"1\",\"available\":\"1\",\"gender\":\"1\",\"nationality\":\"1\",\"posteddate\":\"1\",\"separator\":\"1\",\"sliding\":\"1\",\"slidingdirection\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10068,'Top JS Jobs','module','mod_topjsjobs','',0,1,0,0,'{\"name\":\"Top JS Jobs\",\"type\":\"module\",\"creationDate\":\"Nov 27, 2010\",\"author\":\"Joom Sky\",\"copyright\":\"(C) 2009 - 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0.2\",\"description\":\"Show top jobs from JS Jobs database. \",\"group\":\"\"}','{\"noofjobs\":\"7\",\"theme\":\"1\",\"company\":\"1\",\"category\":\"1\",\"subcategory\":\"0\",\"jobtype\":\"1\",\"posteddate\":\"1\",\"separator\":\"1\",\"sliding\":\"1\",\"slidingdirection\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10069,'JS Featured Companies','plugin','jsfeaturedcompanies','content',0,1,1,0,'{\"name\":\"JS Featured Companies\",\"type\":\"plugin\",\"creationDate\":\"Aug 25, 2010\",\"author\":\"Joom Sky\",\"copyright\":\"Copyright (C) 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0\",\"description\":\"Usage {jsfeaturedcompanies}. Show featured companies from JS Jobs database. \",\"group\":\"\"}','{\"noofcompanies\":\"7\",\"theme\":\"2\",\"title\":\"Featured Companies\",\"listingstyle\":\"1\",\"shtitle\":\"1\",\"category\":\"1\",\"location\":\"1\",\"posteddate\":\"1\",\"noofcols\":\"3\",\"companyname\":\"1\",\"logo\":\"1\",\"logowidth\":\"130\",\"logoheight\":\"70\",\"separator\":\"1\",\"sliding\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10070,'JS Featured Jobs','plugin','jsfeaturedjobs','content',0,1,1,0,'{\"name\":\"JS Featured Jobs\",\"type\":\"plugin\",\"creationDate\":\"Aug 25, 2010\",\"author\":\"Joom Sky\",\"copyright\":\"Copyright (C) 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0\",\"description\":\"Usage {jsfeaturedjobs}. Show featured jobs from JS Jobs database. \",\"group\":\"\"}','{\"noofjobs\":\"7\",\"theme\":\"2\",\"title\":\"Featured Jobs\",\"listingstyle\":\"1\",\"shtitle\":\"1\",\"category\":\"1\",\"subcategory\":\"0\",\"company\":\"1\",\"location\":\"1\",\"posteddate\":\"1\",\"noofcols\":\"3\",\"logo\":\"1\",\"logowidth\":\"130\",\"logoheight\":\"70\",\"separator\":\"1\",\"sliding\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10071,'JS Featured Resumes','plugin','jsfeaturedresumes','content',0,1,1,0,'{\"name\":\"JS Featured Resumes\",\"type\":\"plugin\",\"creationDate\":\"Nov 11, 2010\",\"author\":\"Joom Sky\",\"copyright\":\"Copyright (C) 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0\",\"description\":\"Usage {jsfeaturedresumes}. Show featured resumes from JS Jobs database. \",\"group\":\"\"}','{\"noofresumes\":\"7\",\"theme\":\"2\",\"title\":\"Featured Resumes\",\"listingstyle\":\"1\",\"shtitle\":\"1\",\"applicationtitle\":\"1\",\"name\":\"1\",\"category\":\"1\",\"subcategory\":\"0\",\"jobtype\":\"1\",\"experience\":\"1\",\"available\":\"1\",\"gender\":\"1\",\"nationality\":\"1\",\"location\":\"1\",\"posteddate\":\"1\",\"noofcols\":\"3\",\"photo\":\"1\",\"photowidth\":\"130\",\"photoheight\":\"70\",\"separator\":\"1\",\"sliding\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10072,'JS Gold Companies','plugin','jsgoldcompanies','content',0,1,1,0,'{\"name\":\"JS Gold Companies\",\"type\":\"plugin\",\"creationDate\":\"Aug 25, 2010\",\"author\":\"Joom Sky\",\"copyright\":\"Copyright (C) 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0\",\"description\":\"Usage {jsgoldcompanies}. Show gold companies from JS Jobs database. \",\"group\":\"\"}','{\"noofcompanies\":\"7\",\"theme\":\"2\",\"title\":\"Gold Companies\",\"listingstyle\":\"1\",\"shtitle\":\"1\",\"category\":\"1\",\"location\":\"1\",\"posteddate\":\"1\",\"noofcols\":\"3\",\"companyname\":\"1\",\"logo\":\"1\",\"logowidth\":\"130\",\"logoheight\":\"70\",\"separator\":\"1\",\"sliding\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10073,'JS Gold Jobs','plugin','jsgoldjobs','content',0,1,1,0,'{\"name\":\"JS Gold Jobs\",\"type\":\"plugin\",\"creationDate\":\"Aug 25, 2010\",\"author\":\"Joom Sky\",\"copyright\":\"Copyright (C) 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0\",\"description\":\"Usage {jsgoldjobs}. Show gold jobs from JS Jobs database. \",\"group\":\"\"}','{\"noofjobs\":\"7\",\"theme\":\"2\",\"title\":\"Gold Jobs\",\"listingstyle\":\"1\",\"shtitle\":\"1\",\"category\":\"1\",\"subcategory\":\"0\",\"company\":\"1\",\"location\":\"1\",\"posteddate\":\"1\",\"noofcols\":\"3\",\"logo\":\"1\",\"logowidth\":\"130\",\"logoheight\":\"70\",\"separator\":\"1\",\"sliding\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10074,'JS Gold Resumes','plugin','jsgoldresumes','content',0,1,1,0,'{\"name\":\"JS Gold Resumes\",\"type\":\"plugin\",\"creationDate\":\"Nov 11, 2010\",\"author\":\"Joom Sky\",\"copyright\":\"Copyright (C) 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0\",\"description\":\"Usage {jsgoldresumes}. Show gold resumes from JS Jobs database. \",\"group\":\"\"}','{\"noofresumes\":\"7\",\"theme\":\"2\",\"title\":\"Gold Resumes\",\"listingstyle\":\"1\",\"shtitle\":\"1\",\"applicationtitle\":\"1\",\"name\":\"1\",\"category\":\"1\",\"subcategory\":\"0\",\"jobtype\":\"1\",\"experience\":\"1\",\"available\":\"1\",\"gender\":\"1\",\"nationality\":\"1\",\"location\":\"1\",\"posteddate\":\"1\",\"noofcols\":\"3\",\"photo\":\"1\",\"photowidth\":\"130\",\"photoheight\":\"70\",\"separator\":\"1\",\"sliding\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10075,'JS Hot Jobs','plugin','jshotjobs','content',0,1,1,0,'{\"name\":\"JS Hot Jobs\",\"type\":\"plugin\",\"creationDate\":\"Nov 27, 2010\",\"author\":\"Joom Sky\",\"copyright\":\"Copyright (C) 2009 - 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0.1\",\"description\":\"Usage {jshotjobs}. Show most applied jobs from JS Jobs database. \",\"group\":\"\"}','{\"noofjobs\":\"7\",\"noofcols\":\"3\",\"theme\":\"2\",\"title\":\"Hot Jobs\",\"shtitle\":\"1\",\"company\":\"1\",\"category\":\"1\",\"subcategory\":\"0\",\"jobtype\":\"1\",\"posteddate\":\"1\",\"separator\":\"1\",\"sliding\":\"1\",\"slidingdirection\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10076,'JS Search Jobs','plugin','jssearchjobs','content',0,1,1,0,'{\"name\":\"JS Search Jobs\",\"type\":\"plugin\",\"creationDate\":\"Nov 28, 2010\",\"author\":\"Joom Sky\",\"copyright\":\"Copyright (C) 2009 - 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0.1\",\"description\":\"Usage {jssearchjobs}. Jobs search from JS Jobs database. \",\"group\":\"\"}','{\"title\":\"Search Jobs\",\"shtitle\":\"1\",\"category\":\"1\",\"subcategory\":\"1\",\"jobtype\":\"1\",\"jobstatus\":\"1\",\"salaryrange\":\"1\",\"shift\":\"1\",\"durration\":\"1\",\"startpublishing\":\"1\",\"stoppublishing\":\"1\",\"company\":\"1\",\"colperrow\":\"\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10077,'JS Search Resumes','plugin','jssearchresumes','content',0,1,1,0,'{\"name\":\"JS Search Resumes\",\"type\":\"plugin\",\"creationDate\":\"Dec 11, 2009\",\"author\":\"Joom Sky\",\"copyright\":\"Copyright (C) 2009. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0\",\"description\":\"Usage {jssearchresumes}. Show newest jobs from JS Jobs database. \",\"group\":\"\"}','{\"title\":\"Search Resume\",\"shtitle\":\"1\",\"name\":\"1\",\"natinality\":\"1\",\"gender\":\"1\",\"iamavailable\":\"1\",\"category\":\"1\",\"subcategory\":\"1\",\"jobtype\":\"1\",\"salaryrange\":\"1\",\"heighesteducation\":\"1\",\"experience\":\"1\",\"colperrow\":\"\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10078,'JS Top Resumes','plugin','jstopresume','content',0,1,1,0,'{\"name\":\"JS Top Resumes\",\"type\":\"plugin\",\"creationDate\":\"Nov 27, 2010\",\"author\":\"Joom Sky\",\"copyright\":\"Copyright (C) 2009 - 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0.1\",\"description\":\"Usage {jstopresume}. Show most viewed jobs from JS Jobs database. \",\"group\":\"\"}','{\"noofresumes\":\"7\",\"noofcols\":\"3\",\"theme\":\"2\",\"title\":\"Top Resume\",\"shtitle\":\"1\",\"applicationtitle\":\"1\",\"category\":\"1\",\"subcategory\":\"0\",\"jobtype\":\"1\",\"highesteducation\":\"1\",\"salaryrange\":\"1\",\"experience\":\"1\",\"available\":\"1\",\"gender\":\"1\",\"nationality\":\"1\",\"posteddate\":\"1\",\"separator\":\"1\",\"sliding\":\"1\",\"slidingdirection\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10079,'JS Job Categories','plugin','jsjobcategories','content',0,1,1,0,'{\"name\":\"JS Job Categories\",\"type\":\"plugin\",\"creationDate\":\"Dec 30, 2010\",\"author\":\"Joom Sky\",\"copyright\":\"(C) 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0.0\",\"description\":\"Usage {jsjobcategories}. Show  jobs Categories  from JS Jobs database. \",\"group\":\"\"}','{\"noofcategories\":\"-1\",\"theme\":\"1\",\"title\":\"Jobs By Categories \",\"shtitle\":\"1\",\"jobsincategory\":\"1\",\"allcategories\":\"0\",\"separator\":\"1\",\"sliding\":\"1\",\"slidingdirection\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10080,'JS Jobs BY City','plugin','jsjobscities','content',0,1,1,0,'{\"name\":\"JS Jobs BY City\",\"type\":\"plugin\",\"creationDate\":\"jun 23, 2011\",\"author\":\"Joom Sky\",\"copyright\":\"(C) 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0.0\",\"description\":\"Usage {jsjobscities} Show job by City from js jobs database. \",\"group\":\"\"}','{\"noofjobs\":\"-1\",\"theme\":\"1\",\"title\":\"Jobs By Cities \",\"shtitle\":\"1\",\"jobsincity\":\"1\",\"defaultcountry\":\"0\",\"allcity\":\"0\",\"separator\":\"1\",\"sliding\":\"1\",\"slidingdirection\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10081,'JS Jobs BY Country','plugin','jsjobscountries','content',0,1,1,0,'{\"name\":\"JS Jobs BY Country\",\"type\":\"plugin\",\"creationDate\":\"jun 22, 2011\",\"author\":\"Joom Sky\",\"copyright\":\"(C) 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0.0\",\"description\":\" Usage {jsjobscountries}. Show job by Couontry from js jobs database. \",\"group\":\"\"}','{\"noofjobs\":\"-1\",\"theme\":\"1\",\"title\":\"Jobs By Countries\",\"shtitle\":\"1\",\"jobsincountry\":\"1\",\"allcountries\":\"0\",\"separator\":\"1\",\"sliding\":\"1\",\"slidingdirection\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10082,'JSJobs Register','plugin','jsjobsregister','system',0,1,1,0,'{\"name\":\"JSJobs Register\",\"type\":\"plugin\",\"creationDate\":\"Dec 19, 2010\",\"author\":\"Joom Sky\",\"copyright\":\"Copyright (C) 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0\",\"description\":\"Ask user role at register form. \",\"group\":\"\"}','{\"userregisterinrole\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(10083,'JS Jobs BY State','plugin','jsjobsstates','content',0,1,1,0,'{\"name\":\"JS Jobs BY State\",\"type\":\"plugin\",\"creationDate\":\"jun 23, 2011\",\"author\":\"Joom Sky\",\"copyright\":\"(C) 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0.0\",\"description\":\"Usage {jsjobsstates}.Show job by States from js jobs database. \",\"group\":\"\"}','{\"noofjobs\":\"-1\",\"theme\":\"1\",\"title\":\"Jobs By States \",\"shtitle\":\"1\",\"jobsinstate\":\"1\",\"defaultcountry\":\"0\",\"allstates\":\"0\",\"sliding\":\"1\",\"slidingdirection\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10084,'JS Newest Jobs','plugin','jsnewestjobs','content',0,1,1,0,'{\"name\":\"JS Newest Jobs\",\"type\":\"plugin\",\"creationDate\":\"Nov 27, 2010\",\"author\":\"Joom Sky\",\"copyright\":\"Copyright (C) 2009 - 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0.1\",\"description\":\"Usage {jsnewestjobs}. Show newest jobs from JS Jobs database. \",\"group\":\"\"}','{\"noofjobs\":\"7\",\"noofcols\":\"3\",\"theme\":\"2\",\"title\":\"Newest Jobs\",\"shtitle\":\"1\",\"company\":\"1\",\"category\":\"1\",\"subcategory\":\"0\",\"jobtype\":\"1\",\"posteddate\":\"1\",\"separator\":\"1\",\"sliding\":\"1\",\"slidingdirection\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10085,'JS Newest Resumes','plugin','jsnewestresume','content',0,1,1,0,'{\"name\":\"JS Newest Resumes\",\"type\":\"plugin\",\"creationDate\":\"Nov 27, 2010\",\"author\":\"Joom Sky\",\"copyright\":\"Copyright (C) 2009 - 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0.1\",\"description\":\"Usage {jsnewestresume}. Show newest jobs from JS Jobs database. \",\"group\":\"\"}','{\"noofresumes\":\"7\",\"noofcols\":\"3\",\"theme\":\"2\",\"title\":\"Newest Resume\",\"shtitle\":\"1\",\"applicationtitle\":\"1\",\"category\":\"1\",\"subcategory\":\"0\",\"jobtype\":\"1\",\"highesteducation\":\"1\",\"salaryrange\":\"1\",\"experience\":\"1\",\"available\":\"1\",\"gender\":\"1\",\"nationality\":\"1\",\"posteddate\":\"1\",\"separator\":\"1\",\"sliding\":\"1\",\"slidingdirection\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10086,'JS Top Jobs','plugin','jstopjobs','content',0,1,1,0,'{\"name\":\"JS Top Jobs\",\"type\":\"plugin\",\"creationDate\":\"Nov 27, 2010\",\"author\":\"Joom Sky\",\"copyright\":\"Copyright (C) 2009 - 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0.1\",\"description\":\"Usage {jstopjobs}. Show most viewed jobs from JS Jobs database. \",\"group\":\"\"}','{\"noofjobs\":\"7\",\"noofcols\":\"3\",\"theme\":\"2\",\"title\":\"Top Jobs\",\"shtitle\":\"1\",\"company\":\"1\",\"category\":\"1\",\"subcategory\":\"0\",\"jobtype\":\"1\",\"posteddate\":\"1\",\"separator\":\"1\",\"sliding\":\"1\",\"slidingdirection\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10087,'extplorer','component','com_extplorer','',1,1,0,0,'{\"name\":\"eXtplorer\",\"type\":\"component\",\"creationDate\":\"04.09.2013\",\"author\":\"soeren, QuiX Project\",\"copyright\":\"Soeren Eberhardt-Biermann, QuiX Project\",\"authorEmail\":\"info|-at|-extplorer.net\",\"authorUrl\":\"http:\\/\\/extplorer.net\\/\",\"version\":\"2.1.4\",\"description\":\"\\n\\t<div align=\\\"left\\\"><img src=\\\"components\\/com_extplorer\\/images\\/eXtplorer_logo.png\\\" alt=\\\"eXtplorer Logo\\\" \\/><\\/div>\\n\\t<h2>Successfully installed eXtplorer&nbsp;<\\/h2>\\n\\teXtplorer is a powerful File- and FTP\\/WebDAV Manager script. \\n\\t<br\\/>It allows \\n\\t  <ul><li>Browsing Directories & Files,<\\/li>\\n\\t  <li>Editing, Copying, Moving and Deleting files,<\\/li>\\n\\t  <li>Searching, Uploading and Downloading files,<\\/li>\\n\\t  <li>Creating new Files and Directories,<\\/li>\\n\\t  <li>Creating and Extracting Archives with Files and Directories,<\\/li>\\n\\t  <li>Changing file permissions (chmod)<\\/li><\\/ul><br\\/>and much more.<br\\/><br\\/>\\n\\t  <strong>By default restricted to Superadministrators!<\\/strong>\\n\\t\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10088,'Fox Contact','library','foxcontact','',0,1,1,0,'{\"name\":\"Fox Contact\",\"type\":\"library\",\"creationDate\":\"Oct 2013\",\"author\":\"Demis Palma\",\"copyright\":\"Demis Palma\",\"authorEmail\":\"demis@fox.ra.it\",\"authorUrl\":\"http:\\/\\/www.fox.ra.it\\/\",\"version\":\"3.1.3\",\"description\":\"\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10089,'MOD_FOXCONTACT','module','mod_foxcontact','',0,1,0,0,'{\"name\":\"MOD_FOXCONTACT\",\"type\":\"module\",\"creationDate\":\"Oct 2013\",\"author\":\"Demis Palma\",\"copyright\":\"Demis Palma\",\"authorEmail\":\"demis@fox.ra.it\",\"authorUrl\":\"http:\\/\\/www.fox.ra.it\\/\",\"version\":\"3.1.3\",\"description\":\"MOD_FOXCONTACT_DESCRIPTION\",\"group\":\"\"}','{\"form__width\":\"|auto\",\"customhtml0display\":\"1\",\"customhtml0order\":\"-1000\",\"customhtml1display\":\"1\",\"customhtml1order\":\"1000\",\"labelsdisplay\":\"0\",\"form_layout\":\"stacked\",\"labels__width\":\"230|px\",\"sender0display\":\"2\",\"sender0order\":\"5\",\"sender1display\":\"2\",\"sender1order\":\"10\",\"sender1isemail\":\"1\",\"text0display\":\"1\",\"text0order\":\"15\",\"text1display\":\"0\",\"text1order\":\"20\",\"text2display\":\"0\",\"text2order\":\"25\",\"text3display\":\"0\",\"text3order\":\"30\",\"text4display\":\"0\",\"text4order\":\"35\",\"text5display\":\"0\",\"text5order\":\"40\",\"text6display\":\"0\",\"text6order\":\"45\",\"text7display\":\"0\",\"text7order\":\"50\",\"text8display\":\"0\",\"text8order\":\"55\",\"text9display\":\"0\",\"text9order\":\"60\",\"text__width\":\"85|%\",\"dropdown0display\":\"1\",\"dropdown0order\":\"65\",\"dropdown1display\":\"0\",\"dropdown1order\":\"70\",\"dropdown2display\":\"0\",\"dropdown2order\":\"75\",\"dropdown__width\":\"85|%\",\"textarea0display\":\"1\",\"textarea0order\":\"80\",\"textarea1display\":\"0\",\"textarea1order\":\"85\",\"textarea2display\":\"0\",\"textarea2order\":\"90\",\"textarea__width\":\"85|%\",\"textarea__height\":\"180|px\",\"checkbox0display\":\"1\",\"checkbox0order\":\"95\",\"checkbox1display\":\"0\",\"checkbox1order\":\"100\",\"checkbox2display\":\"0\",\"checkbox2order\":\"105\",\"checkbox3display\":\"0\",\"checkbox3order\":\"110\",\"checkbox4display\":\"0\",\"checkbox4order\":\"115\",\"uploaddisplay\":\"0\",\"uploadmethod\":\"1\",\"uploadmax_file_size\":\"102400\",\"upload_filter\":\"1\",\"upload_audio\":\"0\",\"upload_video\":\"0\",\"upload_images\":\"1\",\"upload_documents\":\"1\",\"upload_archives\":\"1\",\"submittype\":\"0\",\"submiticon\":\"\",\"submitimage\":\"\",\"resetbutton\":\"0\",\"resettype\":\"0\",\"reseticon\":\"\",\"resetimage\":\"\",\"email_sent_action\":\"0\",\"email_sent_textdisplay\":\"1\",\"copy_to_submitter\":\"1\",\"email_copy_summary\":\"0\",\"spam_check\":\"1\",\"spam_detected_textdisplay\":\"1\",\"stdcaptchadisplay\":\"0\",\"stdcaptchatype\":\"0\",\"stdcaptcha_length\":\"5\",\"stdcaptchawidth\":\"150\",\"stdcaptchaheight\":\"75\",\"stdcaptchafont\":\"\",\"stdcaptchafontmin\":\"14\",\"stdcaptchafontmax\":\"20\",\"stdcaptchaangle\":\"20\",\"stdcaptcha_backgroundcolor\":\"#ffffff\",\"stdcaptcha_textcolor\":\"#191919\",\"stdcaptcha_disturbcolor\":\"#c8c8c8\",\"css\":\"bootstrap.css\",\"acymailing\":\"0\",\"acymailing_checkboxes\":\"hidden|hidden\",\"acymailing_auto_checked\":\"0\",\"jnews\":\"0\",\"jnews_checkboxes\":\"hidden|hidden\",\"jnews_auto_checked\":\"0\",\"othernewsletters\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(10090,'com_foxcontact','component','com_foxcontact','',1,1,0,0,'{\"name\":\"COM_FOXCONTACT\",\"type\":\"component\",\"creationDate\":\"Oct 2013\",\"author\":\"Demis Palma\",\"copyright\":\"Demis Palma\",\"authorEmail\":\"demis@fox.ra.it\",\"authorUrl\":\"http:\\/\\/www.fox.ra.it\\/\",\"version\":\"3.1.3\",\"description\":\"COM_FOXCONTACT_DESCRIPTION\",\"group\":\"\"}','{\"adminemailfrom\":{\"select\":\"admin\"},\"adminemailreplyto\":{\"select\":\"submitter\"},\"submitteremailfrom\":{\"select\":\"admin\"},\"submitteremailreplyto\":{\"select\":\"admin\"},\"use_dns\":\"dns_check\"}','','',0,'0000-00-00 00:00:00',0,0),(10091,'PLG_SYS_ADMINEXILE','plugin','adminexile','system',0,1,1,0,'{\"name\":\"PLG_SYS_ADMINEXILE\",\"type\":\"plugin\",\"creationDate\":\"Jan 2011\",\"author\":\"Michael Richey\",\"copyright\":\"Copyright (C) 2011 Michael Richey. All rights reserved.\",\"authorEmail\":\"adminexile@richeyweb.com\",\"authorUrl\":\"http:\\/\\/www.richeyweb.com\",\"version\":\"2.1.3\",\"description\":\"PLG_SYS_ADMINEXILE_XML_DESC\",\"group\":\"\"}','{\"key\":\"pixxelsis\",\"twofactor\":\"0\",\"keyvalue\":\"ROCKS\",\"redirect\":\"{HOME}\",\"fourofour\":\"<!DOCTYPE HTML PUBLIC \\\"-\\/\\/IETF\\/\\/DTD HTML 2.0\\/\\/EN\\\">\\r\\n<html><head>\\r\\n<title>404 Not Found<\\/title>\\r\\n<\\/head><body>\\r\\n<h1>Not Found<\\/h1>\\r\\n<p>The requested URL {url} was not found on this server.<\\/p>\\r\\n<hr>\\r\\n{serversignature}\\r\\n<\\/body><\\/html>\",\"frontrestrict\":\"0\",\"maillink\":\"1\",\"maillinkgroup\":[\"8\"],\"ipsecurity\":\"0\",\"whitelist\":\"127.0.0.1\",\"blacklist\":\"PLG_SYS_ADMINEXILE_DEFAULT_BLACKLIST\",\"bruteforce\":\"0\",\"bfmax\":\"3\",\"bfpenalty\":\"5\",\"bfpenaltymultiplier\":\"1\",\"bfemail\":\"1\",\"bfemailuser\":\"0\"}','','',0,'0000-00-00 00:00:00',0,0),(10092,'plg_editors_jce','plugin','jce','editors',0,1,1,0,'{\"name\":\"plg_editors_jce\",\"type\":\"plugin\",\"creationDate\":\"09 December 2013\",\"author\":\"Ryan Demmer\",\"copyright\":\"2006-2010 Ryan Demmer\",\"authorEmail\":\"info@joomlacontenteditor.net\",\"authorUrl\":\"http:\\/\\/www.joomlacontenteditor.net\",\"version\":\"2.3.4.2\",\"description\":\"WF_EDITOR_PLUGIN_DESC\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10093,'plg_quickicon_jcefilebrowser','plugin','jcefilebrowser','quickicon',0,1,1,0,'{\"name\":\"plg_quickicon_jcefilebrowser\",\"type\":\"plugin\",\"creationDate\":\"09 December 2013\",\"author\":\"Ryan Demmer\",\"copyright\":\"Copyright (C) 2006 - 2013 Ryan Demmer. All rights reserved\",\"authorEmail\":\"@@email@@\",\"authorUrl\":\"www.joomalcontenteditor.net\",\"version\":\"2.3.4.2\",\"description\":\"PLG_QUICKICON_JCEFILEBROWSER_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10094,'jce','component','com_jce','',1,1,0,0,'{\"name\":\"JCE\",\"type\":\"component\",\"creationDate\":\"09 December 2013\",\"author\":\"Ryan Demmer\",\"copyright\":\"Copyright (C) 2006 - 2013 Ryan Demmer. All rights reserved\",\"authorEmail\":\"info@joomlacontenteditor.net\",\"authorUrl\":\"www.joomlacontenteditor.net\",\"version\":\"2.3.4.2\",\"description\":\"WF_ADMIN_DESC\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10095,'Content - BT Social Share','plugin','bt_socialshare','content',0,1,1,0,'{\"name\":\"Content - BT Social Share\",\"type\":\"plugin\",\"creationDate\":\"Oct 2011\",\"author\":\"BowThemes.com\",\"copyright\":\"Copyright (C) 2012 BowThemes.com. All rights reserved.\",\"authorEmail\":\"support@BowThemes.com\",\"authorUrl\":\"http:\\/\\/www.BowThemes.com\\/\",\"version\":\"2.3.2\",\"description\":\"\\n\\t\\t<style>\\n\\t\\t\\t.bt_description{\\n\\t\\t\\t\\ttext-align: left;\\n\\t\\t\\t}\\n\\t\\t\\t.bt_description h3{\\n\\t\\t\\t\\ttext-transform: uppercase;\\n\\t\\t\\t\\tmargin: 20px 0px 10px 0px;\\n\\t\\t\\t}\\n\\t\\t\\t.bt_description img{\\n\\t\\t\\t\\tfloat:left;\\n\\t\\t\\t\\tmargin:5px 10px 5px 0px;\\n\\t\\t\\t}\\n\\t\\t\\t.bt_description p,.bt_description li{\\n\\t\\t\\t\\tpadding: 5px 5px 5px 30px;\\t\\n\\t\\t\\t\\tlist-style: none outside none;\\t\\t\\n\\t\\t\\t}\\n\\t\\t\\t\\n\\t\\t\\t.bt_description ul.list-style li{\\n\\t\\t\\t\\tbackground:url(..\\/plugins\\/content\\/bt_socialshare\\/admin\\/images\\/tick.png) 0px 6px no-repeat;\\n\\t\\t\\t\\tpadding-left:30px;\\n\\t\\t\\t\\tline-height:15px;\\n\\t\\t\\t}\\n\\t\\t<\\/style>\\n\\t\\t<div class=\\\"bt_description\\\">\\n\\t\\t\\t<h3>BT Social Share Plugin Version 2.3.2<\\/h3>\\t\\t\\t\\n\\t\\t\\t<a href=\\\"http:\\/\\/bowthemes.com\\\" target=\\\"_blank\\\"><img src=\\\"..\\/plugins\\/content\\/bt_socialshare\\/admin\\/images\\/bt-social-share.png\\\"><\\/a>\\n\\t\\t\\t<p>BT Social Share plugin adds all major Social Networks into your Joomla articles. Plugin can be published at various locations in content, with 2 options display top or bottom of article. Plugin has backend settings where you can customise it. You can enable\\/disable each social network individually or show or hide them on specific sections, categories, individual articles or specific menus. \\n\\t\\t\\t<\\/p>\\n\\t\\t\\t<br clear=\\\"both\\\" \\/>\\n\\t\\t\\t<h3>Integrating External Code<\\/h3>\\n\\t\\t\\t<textarea readonly=\\\"readonly\\\" style=\\\"width:500px;height:130px;\\\">&lt;?php \\n\\tJPluginHelper::importPlugin(\'content\');\\n\\t$share = plgContentBt_socialshare::socialButtons();\\n\\techo $share[\'script\']; \\/\\/ Required\\n\\techo $share[\'buttons\']; \\/\\/ Social button\\n\\techo $share[\'recommend\']; \\/\\/ Recommendation bar\\n\\techo $share[\'comment\']; \\/\\/ facebook comment box\\n?&gt;<\\/textarea>\\n\\t\\t\\t<br clear=\\\"both\\\" \\/>\\n\\t\\n\\t\\t\\t<h3>Features<\\/h3>\\n\\t\\t\\t<ul class=\\\"list-style\\\">\\n\\t\\t\\t\\t<li>Facebook Share<\\/li>\\n\\t\\t\\t\\t<li>Facebook Recommendations Bar<\\/li>\\n\\t\\t\\t\\t<li>Facebook Like (Send button)<\\/li>\\n\\t\\t\\t\\t<li>Facebook Comment(Auto width)<\\/li>\\n\\t\\t\\t\\t<li>Twitter Oficial Button<\\/li>\\n\\t\\t\\t\\t<li>TweetMe<\\/li>\\n\\t\\t\\t\\t<li>LinkedIn Share<\\/li>\\n\\t\\t\\t\\t<li>Google +1<\\/li>\\n\\t\\t\\t\\t<li>StumbleUpon<\\/li>\\n\\t\\t\\t\\t<li>Digg<\\/li>\\n\\t\\t\\t\\t<li>Position display in content options (Top\\/bottom\\/left\\/right)<\\/li>\\n\\t\\t\\t\\t<li>Option to display different for the various Joomla layouts (Archived Articles, Single Article, Category Blog and Featured Articles)<\\/li>\\n\\t\\t\\t\\t<li>Support K2 Component<\\/li>\\n\\t\\t\\t\\n\\t\\t\\t<\\/ul>\\n\\t\\t\\t<h3>UPgrade versions<\\/h3>\\n\\t\\t\\t<p>\\n\\t\\t\\t\\tYour current versions is 2.3.2. <a target=\\\"_blank\\\" href=\\\"http:\\/\\/bowthemes.com\\/bt-social-plugin.html\\\">Find our latest versions now<\\/a>\\n\\t\\t\\t<\\/p>\\n\\t\\t\\t<h3>Userful links<\\/h3>\\n\\t\\t\\t<ul>\\n\\t\\t\\t\\t<li><a target=\\\"_blank\\\" href=\\\"http:\\/\\/bowthemes.com\\/bt-social-plugin.html\\\">Video tutorials<\\/a><\\/li>\\n\\t\\t\\t\\t<li><a target=\\\"_blank\\\" href=\\\"http:\\/\\/bowthemes.com\\/forums\\/12-bt-social-sharing-plugin\\/\\\">Report bug<\\/a><\\/li>\\n\\t\\t\\t\\t<li><a target=\\\"_blank\\\" href=\\\"http:\\/\\/bowthemes.com\\/forums\\/12-bt-social-sharing-plugin\\/\\\">Forum support<\\/a><\\/li>\\n\\t\\t\\t<\\/ul>\\n\\t\\t\\t<h3>About bow themes & copyright<\\/h3>\\t\\n\\t\\t\\t<p>\\n\\t\\t\\t\\tBow Themes is Professional Joomla template provider. We are focused on creating unique, attractive and clean templates without loosing flexibility and simplicity of customization\\n\\t\\t\\t<\\/p>\\n\\t\\t\\tCopyright (C) 2012 BowThemes\\t\\n\\n\\t\\t<\\/div>\\n\\t\\t\",\"group\":\"\"}','{\"facebook_share_button\":\"1\",\"facebook_share_button_type\":\"\",\"facebook_like\":\"1\",\"facebook_sendbutton\":\"1\",\"facebook_like_type\":\"button_count\",\"facebook_like_width\":\"70\",\"facebook_showface\":\"1\",\"facebook_like_font\":\"arial\",\"facebook_like_color\":\"light\",\"facebook_like_action\":\"like\",\"facebook_comment\":\"0\",\"facebook_comment_numberpost\":\"5\",\"facebook_comment_width\":\"auto\",\"facebook_comment_color_schema\":\"light\",\"facebook_recommendation\":\"1\",\"facebook_trigger\":\"onvisible\",\"facebook_recommendation_time\":\"30\",\"num_recommendations\":\"2\",\"facebook_recommendation_side\":\"right\",\"facebook_html5\":\"0\",\"facebook_api_id\":\"\",\"facebook_admins\":\"\",\"twitter\":\"1\",\"twitter_name\":\"BowThemes\",\"twitter_counter\":\"horizontal\",\"twitter_size\":\"medium\",\"twitter_width\":\"80\",\"linkedin\":\"1\",\"linkedIn_type\":\"right\",\"linkedIn_showzero\":\"0\",\"google_plus\":\"1\",\"google_plus_annotation\":\"bubble\",\"google_plus_width\":\"\",\"google_plus_type\":\"20\",\"google_plus_use_html5\":\"0\",\"google_plus_asynchronous\":\"0\",\"google_plus_parse_tags\":\"onload\",\"stumble\":\"1\",\"stumble_type\":\"1\",\"digg\":\"1\",\"digg_type\":\"DiggCompact\",\"button-pretext\":\"\",\"comment-pretext\":\"\",\"show_plugin_in\":[\"all\"],\"positions\":[\"above\"],\"k2-positions\":[\"after-title\"],\"og_meta\":\"1\",\"og_title\":\"1\",\"excluding_article\":\"\",\"excluding_k2_article\":\"\",\"fb_excluding_article\":\"\",\"fb_excluding_k2_article\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10096,'plg_installer_webinstaller','plugin','webinstaller','installer',0,1,1,0,'{\"name\":\"plg_installer_webinstaller\",\"type\":\"plugin\",\"creationDate\":\"22 November 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"1.0.4\",\"description\":\"PLG_INSTALLER_WEBINSTALLER_XML_DESCRIPTION\",\"group\":\"\"}','{\"tab_position\":\"0\"}','','',0,'0000-00-00 00:00:00',0,0),(10097,'plg_system_kunena','plugin','kunena','system',0,1,1,0,'{\"name\":\"plg_system_kunena\",\"type\":\"plugin\",\"creationDate\":\"2013-10-20\",\"author\":\"Kunena Team\",\"copyright\":\"www.kunena.org\",\"authorEmail\":\"Kunena@kunena.org\",\"authorUrl\":\"http:\\/\\/www.kunena.org\",\"version\":\"3.0.3\",\"description\":\"PLG_SYSTEM_KUNENA_DESC\",\"group\":\"\"}','{\"jcontentevents\":\"0\",\"jcontentevent_target\":\"body\"}','','',0,'0000-00-00 00:00:00',0,0),(10098,'plg_quickicon_kunena','plugin','kunena','quickicon',0,1,1,0,'{\"name\":\"plg_quickicon_kunena\",\"type\":\"plugin\",\"creationDate\":\"2013-10-20\",\"author\":\"Kunena Team\",\"copyright\":\"www.kunena.org\",\"authorEmail\":\"Kunena@kunena.org\",\"authorUrl\":\"http:\\/\\/www.kunena.org\",\"version\":\"3.0.3\",\"description\":\"PLG_QUICKICON_KUNENA_DESC\",\"group\":\"\"}','{\"context\":\"mod_quickicon\"}','','',0,'0000-00-00 00:00:00',0,0),(10099,'Kunena Framework','library','kunena','',0,1,1,0,'{\"name\":\"Kunena Framework\",\"type\":\"library\",\"creationDate\":\"2013-10-20\",\"author\":\"Kunena Team\",\"copyright\":\"(C) 2008 - 2013 Kunena Team. All rights reserved.\",\"authorEmail\":\"kunena@kunena.org\",\"authorUrl\":\"http:\\/\\/www.kunena.org\",\"version\":\"3.0.3\",\"description\":\"Kunena Framework.\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10100,'Kunena Media Files','file','kunena_media','',0,1,0,0,'{\"name\":\"Kunena Media Files\",\"type\":\"file\",\"creationDate\":\"2013-10-20\",\"author\":\"Kunena Team\",\"copyright\":\"(C) 2008 - 2013 Kunena Team. All rights reserved.\",\"authorEmail\":\"kunena@kunena.org\",\"authorUrl\":\"http:\\/\\/www.kunena.org\",\"version\":\"3.0.3\",\"description\":\"Kunena media files.\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(10101,'com_kunena','component','com_kunena','',1,1,0,0,'{\"name\":\"com_kunena\",\"type\":\"component\",\"creationDate\":\"2013-10-20\",\"author\":\"Kunena Team\",\"copyright\":\"(C) 2008 - 2013 Kunena Team. All rights reserved.\",\"authorEmail\":\"kunena@kunena.org\",\"authorUrl\":\"http:\\/\\/www.kunena.org\",\"version\":\"3.0.3\",\"description\":\"COM_KUNENA_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10102,'kunena','package','pkg_kunena','',0,1,1,0,'{\"name\":\"Kunena Forum Package\",\"type\":\"package\",\"creationDate\":\"2013-10-20\",\"author\":\"Kunena Team\",\"copyright\":\"(C) 2008 - 2013 Kunena Team. All rights reserved.\",\"authorEmail\":\"kunena@kunena.org\",\"authorUrl\":\"http:\\/\\/www.kunena.org\",\"version\":\"3.0.3\",\"description\":\"Kunena Forum Package.\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10103,'plg_kunena_alphauserpoints','plugin','alphauserpoints','kunena',0,0,1,0,'{\"name\":\"plg_kunena_alphauserpoints\",\"type\":\"plugin\",\"creationDate\":\"2013-10-20\",\"author\":\"Kunena Team\",\"copyright\":\"www.kunena.org\",\"authorEmail\":\"Kunena@kunena.org\",\"authorUrl\":\"http:\\/\\/www.kunena.org\",\"version\":\"3.0.3\",\"description\":\"PLG_KUNENA_ALPHAUSERPOINTS_DESCRIPTION\",\"group\":\"\"}','{\"activity\":\"1\",\"avatar\":\"1\",\"profile\":\"1\",\"activity_points_limit\":\"0\"}','','',0,'0000-00-00 00:00:00',1,0),(10104,'plg_kunena_community','plugin','community','kunena',0,0,1,0,'{\"name\":\"plg_kunena_community\",\"type\":\"plugin\",\"creationDate\":\"2013-10-20\",\"author\":\"Kunena Team\",\"copyright\":\"www.kunena.org\",\"authorEmail\":\"Kunena@kunena.org\",\"authorUrl\":\"http:\\/\\/www.kunena.org\",\"version\":\"3.0.3\",\"description\":\"PLG_KUNENA_COMMUNITY_DESCRIPTION\",\"group\":\"\"}','{\"access\":\"1\",\"login\":\"1\",\"activity\":\"1\",\"avatar\":\"1\",\"profile\":\"1\",\"private\":\"1\",\"activity_points_limit\":\"0\",\"activity_stream_limit\":\"0\"}','','',0,'0000-00-00 00:00:00',2,0),(10105,'plg_kunena_comprofiler','plugin','comprofiler','kunena',0,0,1,0,'{\"name\":\"plg_kunena_comprofiler\",\"type\":\"plugin\",\"creationDate\":\"2013-10-20\",\"author\":\"Kunena Team\",\"copyright\":\"www.kunena.org\",\"authorEmail\":\"Kunena@kunena.org\",\"authorUrl\":\"http:\\/\\/www.kunena.org\",\"version\":\"3.0.3\",\"description\":\"PLG_KUNENA_COMPROFILER_DESCRIPTION\",\"group\":\"\"}','{\"access\":\"1\",\"login\":\"1\",\"activity\":\"1\",\"avatar\":\"1\",\"profile\":\"1\",\"private\":\"1\"}','','',0,'0000-00-00 00:00:00',3,0),(10106,'plg_kunena_gravatar','plugin','gravatar','kunena',0,0,1,0,'{\"name\":\"plg_kunena_gravatar\",\"type\":\"plugin\",\"creationDate\":\"2013-10-20\",\"author\":\"Kunena Team\",\"copyright\":\"www.kunena.org\",\"authorEmail\":\"Kunena@kunena.org\",\"authorUrl\":\"http:\\/\\/www.kunena.org\",\"version\":\"3.0.3\",\"description\":\"PLG_KUNENA_GRAVATAR_DESCRIPTION\",\"group\":\"\"}','{\"avatar\":\"1\"}','','',0,'0000-00-00 00:00:00',4,0),(10107,'plg_kunena_uddeim','plugin','uddeim','kunena',0,0,1,0,'{\"name\":\"plg_kunena_uddeim\",\"type\":\"plugin\",\"creationDate\":\"2013-10-20\",\"author\":\"Kunena Team\",\"copyright\":\"www.kunena.org\",\"authorEmail\":\"Kunena@kunena.org\",\"authorUrl\":\"http:\\/\\/www.kunena.org\",\"version\":\"3.0.3\",\"description\":\"PLG_KUNENA_UDDEIM_DESCRIPTION\",\"group\":\"\"}','{\"private\":\"1\"}','','',0,'0000-00-00 00:00:00',5,0),(10108,'plg_kunena_kunena','plugin','kunena','kunena',0,1,1,0,'{\"name\":\"plg_kunena_kunena\",\"type\":\"plugin\",\"creationDate\":\"2013-10-20\",\"author\":\"Kunena Team\",\"copyright\":\"www.kunena.org\",\"authorEmail\":\"Kunena@kunena.org\",\"authorUrl\":\"http:\\/\\/www.kunena.org\",\"version\":\"3.0.3\",\"description\":\"PLG_KUNENA_KUNENA_DESCRIPTION\",\"group\":\"\"}','{\"avatar\":\"1\",\"profile\":\"1\"}','','',0,'0000-00-00 00:00:00',6,0),(10109,'plg_kunena_joomla','plugin','joomla','kunena',0,1,1,0,'{\"name\":\"plg_kunena_joomla\",\"type\":\"plugin\",\"creationDate\":\"2013-10-20\",\"author\":\"Kunena Team\",\"copyright\":\"www.kunena.org\",\"authorEmail\":\"Kunena@kunena.org\",\"authorUrl\":\"http:\\/\\/www.kunena.org\",\"version\":\"3.0.3\",\"description\":\"PLG_KUNENA_JOOMLA_25_30_DESCRIPTION\",\"group\":\"\"}','{\"access\":\"1\",\"login\":\"1\"}','','',0,'0000-00-00 00:00:00',7,0),(10110,'JS Jobs BY State','module','mod_jsjobsstates','',0,0,0,0,'{\"name\":\"JS Jobs BY State\",\"type\":\"module\",\"creationDate\":\"jun 23, 2011\",\"author\":\"Joom Sky\",\"copyright\":\"(C) 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0.0\",\"description\":\"Show job by States from js jobs database. \",\"group\":\"\"}','{\"noofjobs\":\"10\",\"theme\":\"1\",\"ssthj\":\"1\",\"sliding\":\"1\",\"slidingdirection\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10111,'JSJobs Login Redirect','plugin','jsjobsloginredirect','user',0,0,1,0,'{\"name\":\"JSJobs Login Redirect\",\"type\":\"plugin\",\"creationDate\":\"July 30, 2013\",\"author\":\"Joom Sky\",\"copyright\":\"Copyright (C) 2010. All rights reserved.\",\"authorEmail\":\"ahmad@joomsky.com\",\"authorUrl\":\"www.joomsky.com\",\"version\":\"1.0\",\"description\":\"Custom login redirect. \",\"group\":\"\"}','{\"isredirect\":\"1\",\"jb_default_login_redirect\":\"\",\"em_default_login_redirect\":\"\"}','','',0,'0000-00-00 00:00:00',0,0);
/*!40000 ALTER TABLE `jom_extensions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_finder_filters`
--

DROP TABLE IF EXISTS `jom_finder_filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_finder_filters` (
  `filter_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT '1',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL,
  `created_by_alias` varchar(255) NOT NULL,
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `map_count` int(10) unsigned NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  `params` mediumtext,
  PRIMARY KEY (`filter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_finder_filters`
--

LOCK TABLES `jom_finder_filters` WRITE;
/*!40000 ALTER TABLE `jom_finder_filters` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_finder_filters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_finder_links`
--

DROP TABLE IF EXISTS `jom_finder_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_finder_links` (
  `link_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `route` varchar(255) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `indexdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `md5sum` varchar(32) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `state` int(5) DEFAULT '1',
  `access` int(5) DEFAULT '0',
  `language` varchar(8) NOT NULL,
  `publish_start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `list_price` double unsigned NOT NULL DEFAULT '0',
  `sale_price` double unsigned NOT NULL DEFAULT '0',
  `type_id` int(11) NOT NULL,
  `object` mediumblob NOT NULL,
  PRIMARY KEY (`link_id`),
  KEY `idx_type` (`type_id`),
  KEY `idx_title` (`title`),
  KEY `idx_md5` (`md5sum`),
  KEY `idx_url` (`url`(75)),
  KEY `idx_published_list` (`published`,`state`,`access`,`publish_start_date`,`publish_end_date`,`list_price`),
  KEY `idx_published_sale` (`published`,`state`,`access`,`publish_start_date`,`publish_end_date`,`sale_price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_finder_links`
--

LOCK TABLES `jom_finder_links` WRITE;
/*!40000 ALTER TABLE `jom_finder_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_finder_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_finder_links_terms0`
--

DROP TABLE IF EXISTS `jom_finder_links_terms0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_finder_links_terms0` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_finder_links_terms0`
--

LOCK TABLES `jom_finder_links_terms0` WRITE;
/*!40000 ALTER TABLE `jom_finder_links_terms0` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_finder_links_terms0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_finder_links_terms1`
--

DROP TABLE IF EXISTS `jom_finder_links_terms1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_finder_links_terms1` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_finder_links_terms1`
--

LOCK TABLES `jom_finder_links_terms1` WRITE;
/*!40000 ALTER TABLE `jom_finder_links_terms1` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_finder_links_terms1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_finder_links_terms2`
--

DROP TABLE IF EXISTS `jom_finder_links_terms2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_finder_links_terms2` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_finder_links_terms2`
--

LOCK TABLES `jom_finder_links_terms2` WRITE;
/*!40000 ALTER TABLE `jom_finder_links_terms2` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_finder_links_terms2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_finder_links_terms3`
--

DROP TABLE IF EXISTS `jom_finder_links_terms3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_finder_links_terms3` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_finder_links_terms3`
--

LOCK TABLES `jom_finder_links_terms3` WRITE;
/*!40000 ALTER TABLE `jom_finder_links_terms3` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_finder_links_terms3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_finder_links_terms4`
--

DROP TABLE IF EXISTS `jom_finder_links_terms4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_finder_links_terms4` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_finder_links_terms4`
--

LOCK TABLES `jom_finder_links_terms4` WRITE;
/*!40000 ALTER TABLE `jom_finder_links_terms4` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_finder_links_terms4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_finder_links_terms5`
--

DROP TABLE IF EXISTS `jom_finder_links_terms5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_finder_links_terms5` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_finder_links_terms5`
--

LOCK TABLES `jom_finder_links_terms5` WRITE;
/*!40000 ALTER TABLE `jom_finder_links_terms5` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_finder_links_terms5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_finder_links_terms6`
--

DROP TABLE IF EXISTS `jom_finder_links_terms6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_finder_links_terms6` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_finder_links_terms6`
--

LOCK TABLES `jom_finder_links_terms6` WRITE;
/*!40000 ALTER TABLE `jom_finder_links_terms6` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_finder_links_terms6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_finder_links_terms7`
--

DROP TABLE IF EXISTS `jom_finder_links_terms7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_finder_links_terms7` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_finder_links_terms7`
--

LOCK TABLES `jom_finder_links_terms7` WRITE;
/*!40000 ALTER TABLE `jom_finder_links_terms7` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_finder_links_terms7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_finder_links_terms8`
--

DROP TABLE IF EXISTS `jom_finder_links_terms8`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_finder_links_terms8` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_finder_links_terms8`
--

LOCK TABLES `jom_finder_links_terms8` WRITE;
/*!40000 ALTER TABLE `jom_finder_links_terms8` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_finder_links_terms8` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_finder_links_terms9`
--

DROP TABLE IF EXISTS `jom_finder_links_terms9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_finder_links_terms9` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_finder_links_terms9`
--

LOCK TABLES `jom_finder_links_terms9` WRITE;
/*!40000 ALTER TABLE `jom_finder_links_terms9` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_finder_links_terms9` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_finder_links_termsa`
--

DROP TABLE IF EXISTS `jom_finder_links_termsa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_finder_links_termsa` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_finder_links_termsa`
--

LOCK TABLES `jom_finder_links_termsa` WRITE;
/*!40000 ALTER TABLE `jom_finder_links_termsa` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_finder_links_termsa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_finder_links_termsb`
--

DROP TABLE IF EXISTS `jom_finder_links_termsb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_finder_links_termsb` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_finder_links_termsb`
--

LOCK TABLES `jom_finder_links_termsb` WRITE;
/*!40000 ALTER TABLE `jom_finder_links_termsb` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_finder_links_termsb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_finder_links_termsc`
--

DROP TABLE IF EXISTS `jom_finder_links_termsc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_finder_links_termsc` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_finder_links_termsc`
--

LOCK TABLES `jom_finder_links_termsc` WRITE;
/*!40000 ALTER TABLE `jom_finder_links_termsc` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_finder_links_termsc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_finder_links_termsd`
--

DROP TABLE IF EXISTS `jom_finder_links_termsd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_finder_links_termsd` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_finder_links_termsd`
--

LOCK TABLES `jom_finder_links_termsd` WRITE;
/*!40000 ALTER TABLE `jom_finder_links_termsd` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_finder_links_termsd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_finder_links_termse`
--

DROP TABLE IF EXISTS `jom_finder_links_termse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_finder_links_termse` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_finder_links_termse`
--

LOCK TABLES `jom_finder_links_termse` WRITE;
/*!40000 ALTER TABLE `jom_finder_links_termse` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_finder_links_termse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_finder_links_termsf`
--

DROP TABLE IF EXISTS `jom_finder_links_termsf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_finder_links_termsf` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_finder_links_termsf`
--

LOCK TABLES `jom_finder_links_termsf` WRITE;
/*!40000 ALTER TABLE `jom_finder_links_termsf` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_finder_links_termsf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_finder_taxonomy`
--

DROP TABLE IF EXISTS `jom_finder_taxonomy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_finder_taxonomy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `state` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `access` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ordering` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `state` (`state`),
  KEY `ordering` (`ordering`),
  KEY `access` (`access`),
  KEY `idx_parent_published` (`parent_id`,`state`,`access`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_finder_taxonomy`
--

LOCK TABLES `jom_finder_taxonomy` WRITE;
/*!40000 ALTER TABLE `jom_finder_taxonomy` DISABLE KEYS */;
INSERT INTO `jom_finder_taxonomy` (`id`, `parent_id`, `title`, `state`, `access`, `ordering`) VALUES (1,0,'ROOT',0,0,0);
/*!40000 ALTER TABLE `jom_finder_taxonomy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_finder_taxonomy_map`
--

DROP TABLE IF EXISTS `jom_finder_taxonomy_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_finder_taxonomy_map` (
  `link_id` int(10) unsigned NOT NULL,
  `node_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`node_id`),
  KEY `link_id` (`link_id`),
  KEY `node_id` (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_finder_taxonomy_map`
--

LOCK TABLES `jom_finder_taxonomy_map` WRITE;
/*!40000 ALTER TABLE `jom_finder_taxonomy_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_finder_taxonomy_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_finder_terms`
--

DROP TABLE IF EXISTS `jom_finder_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_finder_terms` (
  `term_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` float unsigned NOT NULL DEFAULT '0',
  `soundex` varchar(75) NOT NULL,
  `links` int(10) NOT NULL DEFAULT '0',
  `language` char(3) NOT NULL DEFAULT '',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `idx_term` (`term`),
  KEY `idx_term_phrase` (`term`,`phrase`),
  KEY `idx_stem_phrase` (`stem`,`phrase`),
  KEY `idx_soundex_phrase` (`soundex`,`phrase`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_finder_terms`
--

LOCK TABLES `jom_finder_terms` WRITE;
/*!40000 ALTER TABLE `jom_finder_terms` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_finder_terms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_finder_terms_common`
--

DROP TABLE IF EXISTS `jom_finder_terms_common`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_finder_terms_common` (
  `term` varchar(75) NOT NULL,
  `language` varchar(3) NOT NULL,
  KEY `idx_word_lang` (`term`,`language`),
  KEY `idx_lang` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_finder_terms_common`
--

LOCK TABLES `jom_finder_terms_common` WRITE;
/*!40000 ALTER TABLE `jom_finder_terms_common` DISABLE KEYS */;
INSERT INTO `jom_finder_terms_common` (`term`, `language`) VALUES ('a','en'),('about','en'),('after','en'),('ago','en'),('all','en'),('am','en'),('an','en'),('and','en'),('ani','en'),('any','en'),('are','en'),('aren\'t','en'),('as','en'),('at','en'),('be','en'),('but','en'),('by','en'),('for','en'),('from','en'),('get','en'),('go','en'),('how','en'),('if','en'),('in','en'),('into','en'),('is','en'),('isn\'t','en'),('it','en'),('its','en'),('me','en'),('more','en'),('most','en'),('must','en'),('my','en'),('new','en'),('no','en'),('none','en'),('not','en'),('noth','en'),('nothing','en'),('of','en'),('off','en'),('often','en'),('old','en'),('on','en'),('onc','en'),('once','en'),('onli','en'),('only','en'),('or','en'),('other','en'),('our','en'),('ours','en'),('out','en'),('over','en'),('page','en'),('she','en'),('should','en'),('small','en'),('so','en'),('some','en'),('than','en'),('thank','en'),('that','en'),('the','en'),('their','en'),('theirs','en'),('them','en'),('then','en'),('there','en'),('these','en'),('they','en'),('this','en'),('those','en'),('thus','en'),('time','en'),('times','en'),('to','en'),('too','en'),('true','en'),('under','en'),('until','en'),('up','en'),('upon','en'),('use','en'),('user','en'),('users','en'),('veri','en'),('version','en'),('very','en'),('via','en'),('want','en'),('was','en'),('way','en'),('were','en'),('what','en'),('when','en'),('where','en'),('whi','en'),('which','en'),('who','en'),('whom','en'),('whose','en'),('why','en'),('wide','en'),('will','en'),('with','en'),('within','en'),('without','en'),('would','en'),('yes','en'),('yet','en'),('you','en'),('your','en'),('yours','en');
/*!40000 ALTER TABLE `jom_finder_terms_common` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_finder_tokens`
--

DROP TABLE IF EXISTS `jom_finder_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_finder_tokens` (
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` float unsigned NOT NULL DEFAULT '1',
  `context` tinyint(1) unsigned NOT NULL DEFAULT '2',
  `language` char(3) NOT NULL DEFAULT '',
  KEY `idx_word` (`term`),
  KEY `idx_context` (`context`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_finder_tokens`
--

LOCK TABLES `jom_finder_tokens` WRITE;
/*!40000 ALTER TABLE `jom_finder_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_finder_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_finder_tokens_aggregate`
--

DROP TABLE IF EXISTS `jom_finder_tokens_aggregate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_finder_tokens_aggregate` (
  `term_id` int(10) unsigned NOT NULL,
  `map_suffix` char(1) NOT NULL,
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `term_weight` float unsigned NOT NULL,
  `context` tinyint(1) unsigned NOT NULL DEFAULT '2',
  `context_weight` float unsigned NOT NULL,
  `total_weight` float unsigned NOT NULL,
  `language` char(3) NOT NULL DEFAULT '',
  KEY `token` (`term`),
  KEY `keyword_id` (`term_id`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_finder_tokens_aggregate`
--

LOCK TABLES `jom_finder_tokens_aggregate` WRITE;
/*!40000 ALTER TABLE `jom_finder_tokens_aggregate` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_finder_tokens_aggregate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_finder_types`
--

DROP TABLE IF EXISTS `jom_finder_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_finder_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `mime` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_finder_types`
--

LOCK TABLES `jom_finder_types` WRITE;
/*!40000 ALTER TABLE `jom_finder_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_finder_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_foxcontact_sessions`
--

DROP TABLE IF EXISTS `jom_foxcontact_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_foxcontact_sessions` (
  `id` varchar(32) NOT NULL,
  `cid` int(11) NOT NULL,
  `mid` int(11) NOT NULL,
  `keyword` varchar(32) NOT NULL,
  `birth` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data` text,
  UNIQUE KEY `index` (`id`,`cid`,`mid`,`keyword`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_foxcontact_sessions`
--

LOCK TABLES `jom_foxcontact_sessions` WRITE;
/*!40000 ALTER TABLE `jom_foxcontact_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_foxcontact_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_foxcontact_settings`
--

DROP TABLE IF EXISTS `jom_foxcontact_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_foxcontact_settings` (
  `name` varchar(32) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_foxcontact_settings`
--

LOCK TABLES `jom_foxcontact_settings` WRITE;
/*!40000 ALTER TABLE `jom_foxcontact_settings` DISABLE KEYS */;
INSERT INTO `jom_foxcontact_settings` (`name`, `value`) VALUES ('captchadrawer','use_gd'),('mimefilter','use_fileinfo');
/*!40000 ALTER TABLE `jom_foxcontact_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_ages`
--

DROP TABLE IF EXISTS `jom_js_job_ages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_ages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_ages`
--

LOCK TABLES `jom_js_job_ages` WRITE;
/*!40000 ALTER TABLE `jom_js_job_ages` DISABLE KEYS */;
INSERT INTO `jom_js_job_ages` (`id`, `title`, `status`) VALUES (1,'10 Years',1),(2,'15 Years',1),(3,'20 Years',1),(4,'25 Years',1),(5,'30 Years',1),(6,'35 Years',1),(7,'40 Years',1),(8,'45 Years',1),(9,'50 Years',1),(10,'55 Years',1);
/*!40000 ALTER TABLE `jom_js_job_ages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_careerlevels`
--

DROP TABLE IF EXISTS `jom_js_job_careerlevels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_careerlevels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_careerlevels`
--

LOCK TABLES `jom_js_job_careerlevels` WRITE;
/*!40000 ALTER TABLE `jom_js_job_careerlevels` DISABLE KEYS */;
INSERT INTO `jom_js_job_careerlevels` (`id`, `title`, `status`) VALUES (1,'Student (Undergraduate)',1),(2,'Student (Graduate)',1),(3,'Entry Level',1),(4,'Experienced (Non-Manager)',1),(5,'Manager',1),(6,'Executive (Department Head, SVP, VP etc)',1),(7,'Senior Executive (President, CEO, etc)',1);
/*!40000 ALTER TABLE `jom_js_job_careerlevels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_categories`
--

DROP TABLE IF EXISTS `jom_js_job_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cat_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `alias` varchar(225) COLLATE utf8_unicode_ci NOT NULL,
  `isactive` smallint(1) DEFAULT '1',
  `serverid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=57 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_categories`
--

LOCK TABLES `jom_js_job_categories` WRITE;
/*!40000 ALTER TABLE `jom_js_job_categories` DISABLE KEYS */;
INSERT INTO `jom_js_job_categories` (`id`, `cat_value`, `cat_title`, `alias`, `isactive`, `serverid`) VALUES (1,NULL,'Accounting/Finance','accounting-finance',1,NULL),(2,NULL,'Administrative','administrative',1,NULL),(3,NULL,'Advertising','advertising',1,NULL),(4,NULL,'Airlines/Avionics/Aerospace','airlines-avionics-aerospace',1,NULL),(5,NULL,'Architectural','architectural',1,NULL),(6,NULL,'Automotive','automotive',1,NULL),(7,NULL,'Banking/Finance','banking-finance',1,NULL),(8,NULL,'Biotechnology','biotechnology',1,NULL),(9,NULL,'Civil/Construction','civil-construction',1,NULL),(10,NULL,'Engineering','engineering',1,NULL),(11,NULL,'Cleared Jobs','cleared-jobs',1,NULL),(12,NULL,'Communications','communications',1,NULL),(13,NULL,'Computer/IT','computer-it',1,NULL),(14,NULL,'Construction','construction',1,NULL),(15,NULL,'Consultant/Contractual','consultant-contractual',1,NULL),(16,NULL,'Customer Service','customer-service',1,NULL),(17,NULL,'Defense','defense',1,NULL),(18,NULL,'Design','design',1,NULL),(19,NULL,'Education','education',1,NULL),(20,NULL,'Electrical Engineering','electrical-engineering',1,NULL),(21,NULL,'Electronics Engineering','electronics-engineering',1,NULL),(22,NULL,'Energy','energy',1,NULL),(23,NULL,'Engineering','engineering',1,NULL),(24,NULL,'Environmental/Safety','environmental-safety',1,NULL),(25,NULL,'Fundraising','fundraising',1,NULL),(26,NULL,'Health/Medicine','health-medicine',1,NULL),(27,NULL,'Homeland Security','homeland-security',1,NULL),(28,NULL,'Human Resources','human-resources',1,NULL),(29,NULL,'Insurance','insurance',1,NULL),(30,NULL,'Intelligence Jobs','intelligence-jobs',1,NULL),(31,NULL,'Internships/Trainees','internships-trainees',1,NULL),(32,NULL,'Legal','legal',1,NULL),(33,NULL,'Logistics/Transportation','logistics-transportation',1,NULL),(34,NULL,'Maintenance','maintenance',1,NULL),(35,NULL,'Management','management',1,NULL),(36,NULL,'Manufacturing/Warehouse','manufacturing-warehouse',1,NULL),(37,NULL,'Marketing','marketing',1,NULL),(38,NULL,'Materials Management','materials-management',1,NULL),(39,NULL,'Mechanical Engineering','mechanical-engineering',1,NULL),(40,NULL,'Mortgage/Real Estate','mortgage-real-estate',1,NULL),(41,NULL,'National Security','national-security',1,NULL),(42,NULL,'Part-time/Freelance','part-time-freelance',1,NULL),(43,NULL,'Printing','printing',1,NULL),(44,NULL,'Product Design','product-design',1,NULL),(45,NULL,'Public Relations','public-relations',1,NULL),(46,NULL,'Public Safety','public-safety',1,NULL),(47,NULL,'Research','research',1,NULL),(48,NULL,'Retail','retail',1,NULL),(49,NULL,'Sales','sales',1,NULL),(50,NULL,'Scientific','scientific',1,NULL),(51,NULL,'Shipping/Distribution','shipping-distribution',1,NULL),(52,NULL,'Technicians','technicians',1,NULL),(53,NULL,'Trades','trades',1,NULL),(54,NULL,'Transportation','transportation',1,NULL),(55,NULL,'Transportation Engineering','transportation-engineering',1,NULL),(56,NULL,'Web Site Development','web-site-development',1,NULL);
/*!40000 ALTER TABLE `jom_js_job_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_cities`
--

DROP TABLE IF EXISTS `jom_js_job_cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_cities` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `countrycode` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'US',
  `statecode` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `countycode` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `code` (`code`),
  KEY `countrystate` (`countrycode`,`statecode`),
  KEY `countrystatecounty` (`countrycode`,`statecode`,`countycode`)
) ENGINE=MyISAM AUTO_INCREMENT=152 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_cities`
--

LOCK TABLES `jom_js_job_cities` WRITE;
/*!40000 ALTER TABLE `jom_js_job_cities` DISABLE KEYS */;
INSERT INTO `jom_js_job_cities` (`id`, `code`, `name`, `enabled`, `countrycode`, `statecode`, `countycode`) VALUES (1,'Chitral','Chitral','Y','PK','NWFP','Chitral'),(2,'Dir','Dir','Y','PK','NWFP','UpperDir'),(3,'Kohistan','Kohistan','Y','PK','NWFP','UpperDir'),(4,'Swat','Swat','Y','PK','NWFP','Swat'),(5,'Peshawar','Peshawar','Y','PK','NWFP','Peshawar'),(6,'Nowshera','Nowshera','Y','PK','NWFP','Nowshera'),(7,'Kohat','Kohat','Y','PK','NWFP','Kohat'),(8,'Hangu','Hangu','Y','PK','NWFP','Hangu'),(9,'Karak','Karak','Y','PK','NWFP','Karak'),(10,'Hassanabda','Hassanabdal','Y','PK','Punjab','Attock'),(11,'FatehJang','Fateh Jang','Y','PK','Punjab','Attock'),(12,'PindiGheb','Pindi Gheb','Y','PK','Punjab','Attock'),(13,'Rawalpindi','Rawalpindi','Y','PK','Punjab','Rawalpindi'),(14,'Taxila','Taxila','Y','PK','Punjab','Rawalpindi'),(15,'Kahuta','Kahuta','Y','PK','Punjab','Rawalpindi'),(16,'Murree','Murree','Y','PK','Punjab','Rawalpindi'),(17,'GujarKhan','Gujar Khan','Y','PK','Punjab','Rawalpindi'),(18,'Jhelum','Jhelum','Y','PK','Punjab','Jhelum'),(19,'Sohawa','Sohawa','Y','PK','Punjab','Jhelum'),(20,'PindDadan','Pind Dadan Khan','Y','PK','Punjab','Jhelum'),(21,'Dina','Dina','Y','PK','Punjab','Jhelum'),(22,'Chakwal','Chakwal','Y','PK','Punjab','Chakwal'),(23,'Talagang','Talagang','Y','PK','Punjab','Chakwal'),(24,'Sargodha','Sargodha','Y','PK','Punjab','Sargodha'),(25,'Bhalwal','Bhalwal','Y','PK','Punjab','Sargodha'),(26,'KotMomin','Kot Momin','Y','PK','Punjab','Sargodha'),(27,'Bhakkar','Bhakkar','Y','PK','Punjab','Bhakkar'),(28,'Khushab','Khushab','Y','PK','Punjab','Khushab'),(29,'Faisalabad','Faisalabad City','Y','PK','Punjab','Faisalabad'),(30,'Faisalabad','Faisalabad Saddar','Y','PK','Punjab','Faisalabad'),(31,'Sammundri','Sammundri','Y','PK','Punjab','Faisalabad'),(32,'Jaranwala','Jaranwala','Y','PK','Punjab','Faisalabad'),(33,'Tandlianwa','Tandlianwala','Y','PK','Punjab','Faisalabad'),(34,'Chiniot','Chiniot','Y','PK','Punjab','Jhang'),(35,'Jhang','Jhang','Y','PK','Punjab','Jhang'),(36,'TobaTekS','Toba Tek Singh','Y','PK','Punjab','TTSingh'),(37,'Gojra','Gojra','Y','PK','Punjab','TTSingh'),(38,'Wazirabad','Wazirabad','Y','PK','Punjab','Gujranwala'),(39,'Gujranwalacity','Gujranwala City','Y','PK','Punjab','Gujranwala'),(40,'Gujranwalasaddar','Gujranwala Saddar','Y','PK','Punjab','Gujranwala'),(41,'NowsheraVirkan','Nowshera Virkan','Y','PK','Punjab','Gujranwala'),(42,'Kamoki','Kamoki','Y','PK','Punjab','Gujranwala'),(43,'Hafizabad','Hafizabad','Y','PK','Punjab','Hafizabad'),(44,'Gujrat','Gujrat','Y','PK','Punjab','Gujrat'),(45,'Kharian','Kharian','Y','PK','Punjab','Gujrat'),(46,'MandiBaha','Mandi Bahauddin','Y','PK','Punjab','MandiBaha'),(47,'Sialkot','Sialkot','Y','PK','Punjab','Sialkot'),(48,'Narowal','Narowal','Y','PK','Punjab','Narowal'),(49,'LahoreCity','Lahore City','Y','PK','Punjab','Lahore'),(50,'Lahore Cantt','Lahore Cantt.','Y','PK','Punjab','Lahore'),(51,'Kasur','Kasur','Y','PK','Punjab','Kasur'),(52,'Okara','Okara','Y','PK','Punjab','Okara'),(53,'NankanaSa','Nankana Sahib','Y','PK','Punjab','Sheikhupur'),(54,'Sheikhupur','Sheikhupura','Y','PK','Punjab','Sheikhupur'),(55,'Vehari','Vehari','Y','PK','Punjab','Vehari'),(56,'Burewala','Burewala','Y','PK','Punjab','Vehari'),(57,'Sahiwal','Sahiwal','Y','PK','Punjab','Sahiwal'),(58,'MultanCit','Multan City','Y','PK','Punjab','Multan'),(59,'MultanSad','Multan Saddar','Y','PK','Punjab','Multan'),(60,'DGKhan','Dera Ghazi Khan','Y','PK','Punjab','DGKhan'),(61,'Taunsa','Taunsa','Y','PK','Punjab','DGKhan'),(62,'Rajanpur','Rajanpur','Y','PK','Punjab','Rajanpur'),(63,'Muzaffarga','Muzaffargarh','Y','PK','Punjab','Muzaffarga'),(64,'Bahawalpur','Bahawalpur','Y','PK','Punjab','Hasilpur'),(65,'Bahawalnag','Bahawalnagar','Y','PK','Punjab','Bahawalnag'),(66,'Liaquatpur','Liaquatpur','Y','PK','Punjab','RYKhan'),(67,'Sadiqabad','Sadiqabad','Y','PK','Punjab','RYKhan'),(68,'Attock','Attock','Y','PK','Punjab','Attock'),(69,'Islamabad','Islamabad City','Y','PK','Capital','Islamabad'),(70,'Jacobabad','Jacobabad','Y','PK','Sind','Jacobabad'),(71,'Thul','Thul','Y','PK','Sind','Jacobabad'),(72,'Kashmor','Kashmor','Y','PK','Sind','Jacobabad'),(73,'Shikarpur','Shikarpur','Y','PK','Sind','Shikarpur'),(74,'Shahdadkot','Shahdadkot','Y','PK','Sind','Larkana'),(75,'Larkana','Larkana','Y','PK','Sind','Larkana'),(76,'Sukkur','Sukkur','Y','PK','Sind','Sukkur'),(77,'Ghotki','Ghotki','Y','PK','Sind','Ghotki'),(78,'Khairpur','Khairpur','Y','PK','Sind','Khairpur'),(79,'Naushahro','Naushahro Feroze','Y','PK','Sind','Naushahro'),(80,'NawabShah','Nawab Shah','Y','PK','Sind','NawabShah'),(81,'Dadu','Dadu','Y','PK','Sind','Dadu'),(82,'Johi','Johi','Y','PK','Sind','Dadu'),(83,'TandoAlla','Tando Allahyar','Y','PK','Sind','Hyderabad'),(84,'Hyderabad','Hyderabad City','Y','PK','Sind','Hyderabad'),(85,'Latifabad','Latifabad','Y','PK','Sind','Hyderabad'),(86,'Hyderabad','Hyderabad','Y','PK','Sind','Hyderabad'),(87,'Qasimabad','Qasimabad','Y','PK','Sind','Hyderabad'),(88,'TandoMoha','Tando Mohammad Khan','Y','PK','Sind','Hyderabad'),(89,'Golarchi','Golarchi','Y','PK','Sind','Badin'),(90,'Badin','Badin','Y','PK','Sind','Badin'),(91,'Thatta','Thatta','Y','PK','Sind','Thatta'),(92,'TandoAdam','Tando Adam','Y','PK','Sind','Sanghar'),(93,'MirpurKha','Mirpur Khas','Y','PK','Sind','MirpurKha'),(94,'EntireEa','Entire  East','Y','PK','Sind','Karachi'),(95,'KarachiWest','Karachi West','Y','PK','Sind','Karachi'),(96,'KarachiSouth','Karachi South','Y','PK','Sind','Karachi'),(97,'EntireUrban','Entire Urban','Y','PK','Sind','Karachi'),(98,'KarachiCental','Karachi Central','Y','PK','Sind','Karachi'),(99,'Mali','Mali','Y','PK','Sind','Karachi'),(100,'Quetta','Quetta','Y','PK','Balochstan','Quetta'),(101,'Panjpai','Panjpai','Y','PK','Balochstan','Quetta'),(102,'Pishin','Pishin','Y','PK','Balochstan','Pishin'),(103,'KillaAbdu','Killa Abdullah','Y','PK','Balochstan','KillaAbdu'),(104,'Nushki','Nushki','Y','PK','Balochstan','Chagai'),(105,'Dalbandin','Dalbandin','Y','PK','Balochstan','Chagai'),(106,'Chagai','Chagai','Y','PK','Balochstan','Chagai'),(107,'Nokundi','Nokundi','Y','PK','Balochstan','Chagai'),(108,'Dak','Dak','Y','PK','Balochstan','Chagai'),(109,'Taftan','Taftan','Y','PK','Balochstan','Chagai'),(110,'LoralaiBo','Loralai/Bori','Y','PK','Balochstan','Loralai'),(111,'Barkhan','Barkhan','Y','PK','Balochstan','Barkhan'),(112,'Musakhel','Musakhel','Y','PK','Balochstan','Musakhel'),(113,'KillaSaif','Killa Saifullah','Y','PK','Balochstan','KillaSaif'),(114,'Zhob','Zhob','Y','PK','Balochstan','Zhob'),(115,'Sibi','Sibi','Y','PK','Balochstan','Sibi'),(116,'Ziarat','Ziarat','Y','PK','Balochstan','Ziarat'),(117,'Kohlu','Kohlu','Y','PK','Balochstan','Kohlu'),(118,'DeraBugti','Dera Bugti','Y','PK','Balochstan','DeraBugti'),(119,'Sui','Sui','Y','PK','Balochstan','DeraBugti'),(120,'Bhag','Bhag','Y','PK','Balochstan','Bolan'),(121,'Balanari','Balanari','Y','PK','Balochstan','Bolan'),(122,'Sani','Sani','Y','PK','Balochstan','Bolan'),(123,'Mirpur','Mirpur','Y','PK','Balochstan','Kachhi'),(124,'Kalat','Kalat','Y','PK','Balochstan','Kalat'),(125,'Mangochar','Mangochar','Y','PK','Balochstan','Kalat'),(126,'Johan','Johan','Y','PK','Balochstan','Kalat'),(127,'Dasht','Dasht','Y','PK','Balochstan','Mastung'),(128,'JhalJao','Jhal Jao','Y','PK','Balochstan','Awaran'),(129,'Kharan','Kharan','Y','PK','Balochstan','Kharan'),(130,'Besima','Besima','Y','PK','Balochstan','Kharan'),(131,'Hub','Hub','Y','PK','Balochstan','Lasbela'),(132,'Kech','Kech','Y','PK','Balochstan','Kech'),(133,'Hoshab','Hoshab','Y','PK','Balochstan','Kech'),(134,'Gwadar','Gwadar','Y','PK','Balochstan','Gwadar'),(135,'Pasni','Pasni','Y','PK','Balochstan','Gwadar'),(136,'Gichk','Gichk','Y','PK','Balochstan','Panjgur'),(137,'Bara','Bara','Y','PK','FATA','Khyber'),(138,'Jamrud','Jamrud','Y','PK','FATA','Khyber'),(139,'LandiKota','Landi Kotal','Y','PK','FATA','Khyber'),(140,'Ladha','Ladha','Y','PK','FATA','SouthWazi'),(141,'Sararogha','Sararogha','Y','PK','FATA','SouthWazi'),(142,'Wana','Wana','Y','PK','FATA','SouthWazi'),(143,'DattaKhel','Datta Khel','Y','PK','FATA','NorthWazi'),(144,'Dossali','Dossali','Y','PK','FATA','NorthWazi'),(145,'Garyum','Garyum','Y','PK','FATA','NorthWazi'),(146,'GhulamKha','Ghulam Khan','Y','PK','FATA','NorthWazi'),(147,'MirAli','Mir Ali','Y','PK','FATA','NorthWazi'),(148,'MiranShah','Miran Shah','Y','PK','FATA','NorthWazi'),(149,'Razmak','Razmak','Y','PK','FATA','NorthWazi'),(150,'Spinwam','Spinwam','Y','PK','FATA','NorthWazi'),(151,'Shewa','Shewa','Y','PK','FATA','NorthWazi');
/*!40000 ALTER TABLE `jom_js_job_cities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_companies`
--

DROP TABLE IF EXISTS `jom_js_job_companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_companies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `category` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `logofilename` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `logoisfile` tinyint(1) DEFAULT '-1',
  `logo` blob,
  `smalllogofilename` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `smalllogoisfile` tinyint(1) DEFAULT '-1',
  `smalllogo` tinyblob,
  `aboutcompanyfilename` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `aboutcompanyisfile` tinyint(1) DEFAULT '-1',
  `aboutcompanyfilesize` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `aboutcompany` mediumblob,
  `contactname` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `contactphone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `companyfax` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contactemail` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `since` datetime DEFAULT NULL,
  `companysize` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `income` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `country` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `county` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zipcode` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime DEFAULT NULL,
  `hits` int(11) DEFAULT NULL,
  `metadescription` text COLLATE utf8_unicode_ci,
  `metakeywords` text COLLATE utf8_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `packageid` int(11) DEFAULT NULL,
  `paymenthistoryid` int(11) DEFAULT NULL,
  `isgoldcompany` tinyint(1) DEFAULT NULL,
  `isfeaturedcompany` tinyint(1) DEFAULT NULL,
  `serverstatus` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serverid` int(11) DEFAULT NULL,
  `startfeatureddate` datetime DEFAULT NULL,
  `startgolddate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `companies_uid` (`uid`),
  KEY `companies_category` (`category`),
  KEY `companies_packageid` (`packageid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_companies`
--

LOCK TABLES `jom_js_job_companies` WRITE;
/*!40000 ALTER TABLE `jom_js_job_companies` DISABLE KEYS */;
INSERT INTO `jom_js_job_companies` (`id`, `uid`, `category`, `name`, `alias`, `url`, `logofilename`, `logoisfile`, `logo`, `smalllogofilename`, `smalllogoisfile`, `smalllogo`, `aboutcompanyfilename`, `aboutcompanyisfile`, `aboutcompanyfilesize`, `aboutcompany`, `contactname`, `contactphone`, `companyfax`, `contactemail`, `since`, `companysize`, `income`, `description`, `country`, `state`, `county`, `city`, `zipcode`, `address1`, `address2`, `created`, `modified`, `hits`, `metadescription`, `metakeywords`, `status`, `packageid`, `paymenthistoryid`, `isgoldcompany`, `isfeaturedcompany`, `serverstatus`, `serverid`, `startfeatureddate`, `startgolddate`) VALUES (1,707,13,'Pixxelsis Digital Media','pixxelsis-digital-media','www.pixxelsis.com','pixxelsis.jpg',1,NULL,NULL,-1,NULL,NULL,-1,NULL,NULL,'Pixxelsis','66769313',NULL,'info@pixxelsis.com','2012-10-01 00:00:00',NULL,'1000000','<p>Pixxelsis Digital Media is a professional and specialized provider for Information Technology services, project management and consultancy services in the entire Middle East regions.</p>','QA','Qatar','Doha','Doha','7286','Al Mansoura','','2013-10-28 15:33:13',NULL,NULL,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL,NULL,NULL),(3,720,28,'Ferrand Human Resource','ferrand-human-resource','www.fhrqatar.com',NULL,-1,NULL,NULL,-1,NULL,NULL,-1,NULL,NULL,'Aezel Macalindong','',NULL,'gm@fhrqatar.com','2013-12-09 00:00:00',NULL,'','<p>Ferrand Human Resources (FHR) is an international company specialized in human resources placement for jobs worldwide.</p>','QA','',NULL,'Doha','','','','2013-12-09 07:57:52',NULL,NULL,NULL,NULL,1,1,7,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `jom_js_job_companies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_config`
--

DROP TABLE IF EXISTS `jom_js_job_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_config` (
  `configname` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `configvalue` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `configfor` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`configname`),
  KEY `config_name` (`configname`),
  KEY `config_for` (`configfor`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_config`
--

LOCK TABLES `jom_js_job_config` WRITE;
/*!40000 ALTER TABLE `jom_js_job_config` DISABLE KEYS */;
INSERT INTO `jom_js_job_config` (`configname`, `configvalue`, `configfor`) VALUES ('companyautoapprove','1','default'),('comp_city','1','default'),('comp_county','0','default'),('comp_editor','1','default'),('comp_state','1','default'),('comp_zipcode','1','default'),('currency','$','default'),('cur_location','0','default'),('defaultcountry','PH','default'),('defaultempallow','1','defaultallow'),('defaultjoballow','0','defaultallow'),('empautoapprove','1','default'),('employerdefaultrole','1','notuse'),('jobautoapprove','1','default'),('jobseekerdefaultrole','2','notuse'),('job_editor','1','default'),('mailfromaddress','info@poec.org','email'),('mailfromname','POEC Career and Recruitment','email'),('newdays','7','default'),('resumeaddress','1','resume'),('resumeeducation','1','resume'),('resumeedu_gradeschool','1','resume'),('resumeedu_highschool','1','resume'),('resumeedu_otherchool','1','resume'),('resumeedu_university','1','resume'),('resumeemployer','1','resume'),('resumeem_1','1','resume'),('resumeem_2','1','resume'),('resumeem_3','1','resume'),('resumeem_recent','1','resume'),('resumereference','1','resume'),('resumereference1','1','resume'),('resumereference2','1','resume'),('resumereference3','1','resume'),('resumeskill','1','resume'),('search_job_durration','0','searchjob'),('search_job_experience','1','searchjob'),('search_job_heighesteducation','1','searchjob'),('search_job_salaryrange','1','searchjob'),('search_job_shift','0','searchjob'),('search_job_showsave','1','searchjob'),('search_job_startpublishing','1','searchjob'),('search_job_stoppublishing','1','searchjob'),('search_job_companysite','1','searchjob'),('search_resume_available','1','searchresume'),('search_resume_experience','1','searchresume'),('actk','22f0f8fe1d252a8e6cda','default'),('search_resume_gender','1','searchresume'),('search_resume_heighesteducation','1','searchresume'),('search_resume_name','1','searchresume'),('search_resume_nationality','1','searchresume'),('search_resume_salaryrange','1','searchresume'),('search_resume_showsave','1','searchresume'),('search_resume_title','1','searchresume'),('showemployerlink','1','default'),('theme','graywhite/css/jsjobsgraywhite.css','default'),('title','POEC Jobs Abroad','default'),('data_directory','jsjobsdata','default'),('version','1.0.8.7',NULL),('versioncode','1087',NULL),('versiontype','business',NULL),('filter_address','1','default'),('refercode','05f0f53e1d352a8fa9','default'),('filter_address_fields_width','130','default'),('filter_category','1','default'),('filter_jobtype','1','default'),('filter_heighesteducation','1','default'),('filter_salaryrange','1','default'),('filter','1','default'),('fr_cr_txa','<img src=\"components/com_jsjobs/images/jsjobs_logo_small.png\" width=\"65\">&nbsp;&nbsp;&nbsp;Powered by <a href=\"http://www.joomsky.com\" target=\"_blank\">Joom Sky</a>','default'),('fr_cr_txsh','0','default'),('fr_cr_txb','<br>&copy;Copyright 2008 - 2011, <a href=\"http://www.burujsolutions.com\" target=\"_blank\">Buruj Solutions </a> ','default'),('backuponuninstall','1',NULL),('company_logofilezize','1000','default'),('resume_photofilesize','100','default'),('offline','0','default'),('offline_text','Our website is down for maintenance. Please check back again soon.','default'),('payment_multicompanies','0','payment'),('lj_title','1','listjob'),('lj_category','1','listjob'),('lj_jobtype','1','listjob'),('lj_jobstatus','0','listjob'),('lj_company','1','listjob'),('lj_companysite','1','listjob'),('lj_country','1','listjob'),('lj_state','1','listjob'),('lj_county','0','listjob'),('lj_city','1','listjob'),('lj_salary','1','listjob'),('lj_created','1','listjob'),('lj_noofjobs','1','listjob'),('visitor_lj_title','1','listjob'),('visitor_lj_category','1','listjob'),('visitor_lj_jobtype','1','listjob'),('visitor_lj_jobstatus','1','listjob'),('visitor_lj_company','1','listjob'),('visitor_lj_companysite','1','listjob'),('visitor_lj_country','1','listjob'),('visitor_lj_state','1','listjob'),('visitor_lj_county','0','listjob'),('visitor_lj_city','1','listjob'),('visitor_lj_salary','1','listjob'),('visitor_lj_created','1','listjob'),('visitor_lj_noofjobs','1','listjob'),('visitorview_js_controlpanel','0','default'),('visitorview_js_packages','1','default'),('visitorview_js_viewpackage','1','default'),('visitorview_js_jobcat','1','default'),('visitorview_js_listjob','1','default'),('visitorview_js_newestjobs','1','default'),('visitorview_js_jobsearch','1','default'),('visitorview_js_jobsearchresult','1','default'),('visitorview_js_viewresume','1','default'),('visitorview_emp_conrolpanel','0','default'),('visitorview_emp_packages','0','default'),('visitorview_emp_viewpackage','0','default'),('visitorview_emp_resumesearch','1','default'),('visitorview_emp_resumesearchresult','1','default'),('visitorview_emp_viewcompany','0','default'),('visitorview_emp_viewjob','1','default'),('search_job_title','1','searchjob'),('search_job_category','1','searchjob'),('search_job_type','1','searchjob'),('search_job_status','1','searchjob'),('search_job_company','1','searchjob'),('search_job_country','1','searchjob'),('search_job_state','1','searchjob'),('search_job_county','0','searchjob'),('search_job_city','1','searchjob'),('search_job_zipcode','0','searchjob'),('search_resume_category','1','searchresume'),('search_resume_type','1','searchresume'),('featuredjob_autoapprove','1','featuredjob'),('goldjob_autoapprove','1','goldjob'),('featuredcompany_autoapprove','1','featuredcompany'),('goldcompany_autoapprove','1','goldcompany'),('featuredresume_autoapprove','1','featuredresume'),('goldresume_autoapprove','1','goldresume'),('payment_method','paypal','payment'),('payment_shopingurl','','payment'),('payment_successefulurl','','payment'),('payment_cancelurl','','payment'),('payment_paypalaccount','ressfos@gmail.com','payment'),('payment_showdescription','1','payment'),('payment_description','Description','payment'),('payment_showfooter','1','payment'),('payment_currency','USD','payment'),('payment_authtoken','','payment'),('payment_test_mode','0','payment'),('employer_defaultpackage','1','package'),('jobseeker_defaultpackage','1','package'),('date_format','d-m-Y','default'),('adminemailaddress','admin@poec.org','email'),('email_admin_new_company','1','email'),('email_admin_new_job','1','email'),('email_admin_new_resume','1','email'),('email_admin_job_apply','1','email'),('email_admin_new_department','1','email'),('email_admin_employer_package_purchase','1','email'),('email_admin_jobseeker_package_purchase','1','email'),('onlyonce_employer_getfreepackage','0','package'),('onlyonce_jobseeker_getfreepackage','0','package'),('employer_freepackage_autoapprove','1','package'),('jobseeker_freepackage_autoapprove','1','package'),('subcategories','0','listjob'),('subcategories_all','1','listjob'),('subcategories_colsperrow','3','listjob'),('subcategoeis_max_hight','250','listjob'),('categories_colsperrow','3','default'),('message_auto_approve','0','messages'),('conflict_message_auto_approve','0','messages'),('overwrite_jobalert_settings','1','default'),('visitor_can_apply_to_job','0','default'),('visitor_show_login_message','1','default'),('folder_auto_approve','1','folder'),('department_auto_approve','1','department'),('formcompany','1','emcontrolpanel'),('mycompanies','1','emcontrolpanel'),('formjob','1','emcontrolpanel'),('myjobs','1','emcontrolpanel'),('formdepartment','1','emcontrolpanel'),('mydepartment','1','emcontrolpanel'),('empmessages','1','emcontrolpanel'),('alljobsappliedapplications','1','emcontrolpanel'),('resumesearch','1','emcontrolpanel'),('my_resumesearches','1','emcontrolpanel'),('packages','1','emcontrolpanel'),('purchasehistory','1','emcontrolpanel'),('my_stats','1','emcontrolpanel'),('myfolders','1','emcontrolpanel'),('formresume','1','jscontrolpanel'),('myresumes','1','jscontrolpanel'),('formcoverletter','1','jscontrolpanel'),('mycoverletters','1','jscontrolpanel'),('jspackages','1','jscontrolpanel'),('jspurchasehistory','1','jscontrolpanel'),('jobalertsetting','1','jscontrolpanel'),('jobcat','1','jscontrolpanel'),('listnewestjobs','1','jscontrolpanel'),('myappliedjobs','1','jscontrolpanel'),('jobsearch','1','jscontrolpanel'),('my_jobsearches','1','jscontrolpanel'),('jsmy_stats','1','jscontrolpanel'),('jsmessages','1','jscontrolpanel'),('tmenu_emcontrolpanel','1','default'),('tmenu_emnewcompany','1','default'),('tmenu_emnewjob','1','default'),('tmenu_emmyjobs','1','default'),('tmenu_emmycompanies','1','default'),('tmenu_emappliedresume','1','default'),('tmenu_emnewdepartment','1','default'),('tmenu_emnewfolder','1','default'),('tmenu_jscontrolpanel','1','default'),('tmenu_jsjobcategory','1','default'),('tmenu_jssearchjob','1','default'),('tmenu_jsnewestjob','1','default'),('tmenu_jsmyresume','1','default'),('tmenu_jsaddresume','1','default'),('login_redirect','','default'),('tmenu_jsaddcoverletter','1','default'),('hidecountry','0','default'),('jobalert_auto_approve','1','jobalert'),('pagseguro_email','1','payment'),('lj_description','1','listjob'),('visitor_lj_description','1','listjob'),('lj_shortdescriptionlenght','200','listjob'),('lj_joblistingstyle','july2011','listjob'),('search_resume_style','july2011','searchresume'),('filter_address_country','1','default'),('filter_address_state','1','default'),('filter_address_county','0','default'),('filter_address_city','1','default'),('testing_mode','0','default'),('resume_style','tabular','default'),('api_primary','','api'),('api_secondary','','api'),('search_job_subcategory','0','searchjob'),('search_resume_subcategory','1','searchresume'),('comp_show_url','1','default'),('employerview_js_controlpanel','0','default'),('search_job_keywords','1','searchjob'),('vis_emformjob','1','default'),('vis_emresumesearch','1','default'),('vis_emmycompanies','1','default'),('vis_emalljobsappliedapplications','1','default'),('vis_emformcompany','1','default'),('tmenu_vis_emappliedresume','1','default'),('tmenu_vis_emmycompanies','1','default'),('tmenu_vis_emmyjobs','1','default'),('tmenu_vis_emnewjob','1','default'),('tmenu_vis_emcontrolpanel','1','default'),('vis_emmy_resumesearches','1','default'),('vis_emmyjobs','1','default'),('vis_empackages','1','default'),('vis_emformdepartment','1','default'),('vis_empurchasehistory','1','default'),('vis_emmydepartment','1','default'),('vis_emmy_stats','1','default'),('vis_emmessages','1','default'),('vis_emmyfolders','1','default'),('tmenu_vis_jscontrolpanel','1','default'),('tmenu_vis_jsjobcategory','1','default'),('tmenu_vis_jsnewestjob','1','default'),('tmenu_vis_jsmyresume','0','default'),('vis_jsformresume','1','default'),('vis_jsjobcat','1','default'),('vis_jsmyresumes','1','default'),('vis_jslistnewestjobs','1','default'),('vis_jsformcoverletter','1','default'),('vis_jsmyappliedjobs','1','default'),('vis_jsmycoverletters','1','default'),('vis_jspackages','1','default'),('vis_jsmy_jobsearches','1','default'),('vis_jspurchasehistory','1','default'),('vis_jsjobsearch','1','default'),('vis_jsmy_stats','1','default'),('vis_jsjobalertsetting','1','default'),('vis_jsmessages','1','default'),('tmenu_vis_jssearchjob','1','default'),('rss_job_title','Jobs RSS','rss'),('rss_job_description','Job RSS Show the Latest Jobs On Our Sites','rss'),('rss_job_categories','1','rss'),('rss_job_image','1','rss'),('rss_resume_categories','1','rss'),('rss_resume_image','1','rss'),('rss_resume_title','Resume RSS','rss'),('rss_resume_description','Resume RSS Show the Latest Resume On Our Sites','rss'),('rss_job_ttl','12','rss'),('rss_job_copyright','Copyright 2013-2014','rss'),('rss_job_webmaster','admin@poec.org','rss'),('rss_job_editor','admin@poec.org','rss'),('rss_resume_copyright','','rss'),('rss_resume_webmaster','','rss'),('rss_resume_editor','','rss'),('rss_resume_ttl','','rss'),('rss_resume_file','1','rss'),('visitor_can_post_job','0','default'),('visitor_can_edit_job','0','default'),('job_captcha','1','default'),('resume_captcha','1','default'),('job_rss','1','default'),('resume_rss','1','default'),('empresume_rss','1','default'),('jsjob_rss','1','default'),('vis_resume_rss','1','default'),('vis_job_rss','1','default'),('default_longitude','14.568714','default'),('default_latitude','120.991309','default'),('search_job_coordinates','0','searchjob'),('vis_emresumebycategory','1','default'),('noofgoldjobsinlisting','10','default'),('nooffeaturedjobsinlisting','10','default'),('showgoldjobsinnewestjobs','1','default'),('showfeaturedjobsinnewestjobs','1','default'),('showgoldjobsinlistjobs','1','default'),('showfeaturedjobsinlistjobs','1','default'),('googleadsenseclient','','default'),('googleadsenseslot','','default'),('googleadsensewidth','717','default'),('googleadsenseheight','90','default'),('googleadsensecustomcss','','default'),('googleadsenseshowafter','4','default'),('googleadsenseshowinnewestjobs','0','default'),('googleadsenseshowinlistjobs','0','default'),('cron_job_alert_key','4584ca349e0920f4436a3c2f36158b85','default'),('empexpire_package_message','1','emcontrolpanel'),('jsexpire_package_message','1','jscontrolpanel'),('filter_map','0','default'),('defaultradius','2','default'),('filter_map_fields_width','140','default'),('filter_cat_jobtype_fields_width','140','default'),('mapwidth','0','default'),('mapheight','0','default'),('comp_name','1','default'),('comp_email_address','1','default'),('filter_sub_category','0','default'),('topimage','1','default'),('labelinlisting','1','default'),('jsregister','1','jscontrolpanel'),('vis_jsregister','1','default'),('empregister','1','emcontrolpanel'),('vis_emempregister','1','default');
/*!40000 ALTER TABLE `jom_js_job_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_counties`
--

DROP TABLE IF EXISTS `jom_js_job_counties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_counties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `countrycode` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'PK',
  `statecode` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `code` (`code`),
  KEY `countrystate` (`countrycode`,`statecode`)
) ENGINE=MyISAM AUTO_INCREMENT=108 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_counties`
--

LOCK TABLES `jom_js_job_counties` WRITE;
/*!40000 ALTER TABLE `jom_js_job_counties` DISABLE KEYS */;
INSERT INTO `jom_js_job_counties` (`id`, `code`, `name`, `enabled`, `countrycode`, `statecode`) VALUES (1,'Chitral','Chitral','Y','PK','NWFP'),(2,'UpperDir','Upper Dir','Y','PK','NWFP'),(3,'LowerDir','Lower Dir','Y','PK','NWFP'),(4,'Swat','Swat','Y','PK','NWFP'),(5,'Shangla','Shangla','Y','PK','NWFP'),(6,'Buner','Buner','Y','PK','NWFP'),(7,'Malakand','Malakand P.A.','Y','PK','NWFP'),(8,'Kohistan','Kohistan','Y','PK','NWFP'),(9,'Mansehra','Mansehra','Y','PK','NWFP'),(10,'Batagram','Batagram','Y','PK','NWFP'),(11,'Abbottabad','Abbottabad','Y','PK','NWFP'),(12,'Haripur','Haripur','Y','PK','NWFP'),(13,'Mardan','Mardan','Y','PK','NWFP'),(14,'Swabi','Swabi','Y','PK','NWFP'),(15,'Charsadda','Charsadda','Y','PK','NWFP'),(16,'Peshawar','Peshawar','Y','PK','NWFP'),(17,'Nowshera','Nowshera','Y','PK','NWFP'),(18,'Kohat','Kohat','Y','PK','NWFP'),(19,'Hangu','Hangu','Y','PK','NWFP'),(20,'Karak','Karak','Y','PK','NWFP'),(21,'Bannu','Bannu','Y','PK','NWFP'),(22,'DIKhan','Dera Ismail Khan','Y','PK','NWFP'),(23,'Tank','Tank','Y','PK','NWFP'),(24,'LakkiMarw','Lakki Marwat','Y','PK','NWFP'),(25,'Rawalpindi','Rawalpindi','Y','PK','Punjab'),(26,'Jhelum','Jhelum','Y','PK','Punjab'),(27,'Chakwal','Chakwal','Y','PK','Punjab'),(28,'Sargodha','Sargodha','Y','PK','Punjab'),(29,'Bhakkar','Bhakkar','Y','PK','Punjab'),(30,'Khushab','Khushab','Y','PK','Punjab'),(31,'Mianwali','Mianwali','Y','PK','Punjab'),(32,'Faisalabad','Faisalabad','Y','PK','Punjab'),(33,'Jhang','Jhang','Y','PK','Punjab'),(34,'TTSingh','Toba Tek Singh','Y','PK','Punjab'),(35,'Gujranwala','Gujranwala','Y','PK','Punjab'),(36,'Hafizabad','Hafizabad','Y','PK','Punjab'),(37,'Gujrat','Gujrat','Y','PK','Punjab'),(38,'MandiBaha','Mandi Bahauddin','Y','PK','Punjab'),(39,'Sialkot','Sialkot','Y','PK','Punjab'),(40,'Narowal','Narowal','Y','PK','Punjab'),(41,'Lahore','Lahore','Y','PK','Punjab'),(42,'Kasur','Kasur','Y','PK','Punjab'),(43,'Okara','Okara','Y','PK','Punjab'),(44,'Sheikhupur','Sheikhupura','Y','PK','Punjab'),(45,'Vehari','Vehari','Y','PK','Punjab'),(46,'Sahiwal','Sahiwal','Y','PK','Punjab'),(47,'Pakpattan','Pakpattan','Y','PK','Punjab'),(48,'Multan','Multan','Y','PK','Punjab'),(49,'Lodhran','Lodhran','Y','PK','Punjab'),(50,'Khanewal','Khanewal','Y','PK','Punjab'),(51,'DGKhan','Dera Ghazi Khan','Y','PK','Punjab'),(52,'Rajanpur','Rajanpur','Y','PK','Punjab'),(53,'Layyah','Layyah','Y','PK','Punjab'),(54,'Muzaffarga','Muzaffargarh','Y','PK','Punjab'),(55,'Bahawalpur','Bahawalpur','Y','PK','Punjab'),(56,'Bahawalnag','Bahawalnagar','Y','PK','Punjab'),(57,'RYKhan','Rahim Yar Khan','Y','PK','Punjab'),(58,'Attock','Attock','Y','PK','Punjab'),(59,'Islamabad','Islamabad','Y','PK','Capital'),(60,'Shikarpur','Shikarpur','Y','PK','Sind'),(61,'Larkana','Larkana','Y','PK','Sind'),(62,'Sukkur','Sukkur','Y','PK','Sind'),(63,'Ghotki','Ghotki','Y','PK','Sind'),(64,'Khairpur','Khairpur','Y','PK','Sind'),(65,'Naushahro','Naushahro Feroze','Y','PK','Sind'),(66,'NawabShah','Nawab Shah','Y','PK','Sind'),(67,'Dadu','Dadu','Y','PK','Sind'),(68,'Hyderabad','Hyderabad','Y','PK','Sind'),(69,'Badin','Badin','Y','PK','Sind'),(70,'Thatta','Thatta','Y','PK','Sind'),(71,'Sanghar','Sanghar','Y','PK','Sind'),(72,'MirpurKha','Mirpur Khas','Y','PK','Sind'),(73,'Umerkot','Umerkot','Y','PK','Sind'),(74,'Tharparkar','Tharparkar','Y','PK','Sind'),(75,'Karachi','Karachi','Y','PK','Sind'),(76,'Quetta','Quetta','Y','PK','Balochstan'),(77,'Pishin','Pishin','Y','PK','Balochstan'),(78,'KillaAbdu','Killa Abdullah','Y','PK','Balochstan'),(79,'Chagai','Chagai','Y','PK','Balochstan'),(80,'Loralai','Loralai','Y','PK','Balochstan'),(81,'Musakhel','Musakhel','Y','PK','Balochstan'),(82,'KillaSaif','Killa Saifullah','Y','PK','Balochstan'),(83,'Zhob','Zhob','Y','PK','Balochstan'),(84,'Sibi','Sibi','Y','PK','Balochstan'),(85,'Ziarat','Ziarat','Y','PK','Balochstan'),(86,'Kohlu','Kohlu','Y','PK','Balochstan'),(87,'DeraBugti','Dera Bugti','Y','PK','Balochstan'),(88,'Jaffarabad','Jaffarabad','Y','PK','Balochstan'),(89,'Nasirabad','Nasirabad','Y','PK','Balochstan'),(90,'Bolan','Bolan','Y','PK','Balochstan'),(91,'Kachhi','Kachhi','Y','PK','Balochstan'),(92,'Kalat','Kalat','Y','PK','Balochstan'),(93,'Mastung','Mastung','Y','PK','Balochstan'),(94,'Khuzdar','Khuzdar','Y','PK','Balochstan'),(95,'Awaran','Awaran','Y','PK','Balochstan'),(96,'Kharan','Kharan','Y','PK','Balochstan'),(97,'Lasbela','Lasbela','Y','PK','Balochstan'),(98,'Kech','Kech','Y','PK','Balochstan'),(99,'Gwadar','Gwadar','Y','PK','Balochstan'),(100,'Panjgur','Panjgur','Y','PK','Balochstan'),(101,'Bajaur','Bajaur','Y','PK','FATA'),(102,'Mohmand','Mohmand','Y','PK','FATA'),(103,'Khyber','Khyber','Y','PK','FATA'),(104,'Kurram','Kurram','Y','PK','FATA'),(105,'Orakzai','Orakzai','Y','PK','FATA'),(106,'SouthWazi','South Waziristan','Y','PK','FATA'),(107,'NorthWazi','North Waziristan','Y','PK','FATA');
/*!40000 ALTER TABLE `jom_js_job_counties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_countries`
--

DROP TABLE IF EXISTS `jom_js_job_countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loc` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `code` (`code`)
) ENGINE=MyISAM AUTO_INCREMENT=220 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_countries`
--

LOCK TABLES `jom_js_job_countries` WRITE;
/*!40000 ALTER TABLE `jom_js_job_countries` DISABLE KEYS */;
INSERT INTO `jom_js_job_countries` (`id`, `loc`, `code`, `name`, `enabled`) VALUES (3,'AF','BF','Burkina Faso','Y'),(5,'AF','CM','Cameroon','Y'),(6,'AF','CV','Cape Verde','Y'),(7,'AF','CF','Central African Republic','Y'),(8,'AF','TD','Chad','Y'),(9,'AF','KM','Comoros','Y'),(10,'AF','CG','Congo','Y'),(12,'AF','BJ','Benin','Y'),(14,'AF','BI','Burundi','Y'),(21,'AF','CI','Cote DIvorie','Y'),(22,'AF','DJ','Djibouti','Y'),(23,'AF','GQ','Equatorial Guinea','Y'),(24,'AF','ER','Eritrea','Y'),(25,'AF','ET','Ethiopia','Y'),(26,'AF','EG','Egypt','Y'),(27,'AF','GA','Gabon','Y'),(28,'AF','GH','Ghana','Y'),(29,'AF','GN','Guinea','Y'),(30,'AF','GM','Gambia','Y'),(31,'AF','GW','Guinea-Bissau','Y'),(32,'AF','KE','Kenya','Y'),(33,'AF','LS','Lesotho','Y'),(34,'AF','LR','Liberia','Y'),(35,'AF','MG','Madagascar','Y'),(36,'AF','ML','Mali','Y'),(37,'AF','MR','Mauritania','Y'),(38,'AF','YT','Mayotte','Y'),(39,'AF','MA','Morocco','Y'),(40,'AF','MZ','Mozambique','Y'),(41,'AF','MW','Malawi','Y'),(42,'AF','NA','Namibia','Y'),(43,'AF','NE','Niger','Y'),(44,'AF','NG','Nigeria','Y'),(45,'AF','RE','Reunion','Y'),(46,'AF','SH','St. Helena','Y'),(47,'AF','ST','Sao Tome and Principe','Y'),(48,'AF','SN','Senegal','Y'),(49,'AF','SL','Sierra Leone','Y'),(50,'AF','SO','Somalia','Y'),(51,'AF','ZA','South Africa','Y'),(52,'AF','SD','Sudan','Y'),(53,'AF','SZ','Swaziland','Y'),(54,'AF','TZ','Tanzania','Y'),(55,'AF','TG','Togo','Y'),(56,'AF','UG','Uganda','Y'),(57,'AF','EH','Western Sahara','Y'),(58,'AF','ZR','Zaire','Y'),(59,'AF','ZM','Zambia','Y'),(60,'AF','ZW','Zimbabwe','Y'),(62,'AS','AF','Afghanistan','Y'),(63,'AS','BD','Bangladesh','Y'),(64,'AS','BT','Bhutan','Y'),(65,'AS','BN','Brunei','Y'),(66,'AS','KH','Cambodia','Y'),(67,'AS','CN','China','Y'),(68,'AS','HK','Hong Kong','Y'),(69,'AS','IN','India','Y'),(70,'AS','ID','Indonesia','Y'),(71,'AS','JP','Japan','Y'),(72,'AS','KZ','Kazakhstan','Y'),(73,'AS','KG','Kyrgyzstan','Y'),(74,'AS','LA','Laos','Y'),(75,'AS','MO','Macau','Y'),(76,'AS','MY','Malaysia','Y'),(77,'AS','MV','Maldives','Y'),(78,'AS','MN','Mongolia','Y'),(79,'AS','NP','Nepal','Y'),(80,'AS','PK','Pakistan','Y'),(81,'AS','PH','Philippines','Y'),(82,'AS','KR','Republic of Korea','Y'),(83,'AS','RU','Russia','Y'),(84,'AS','SC','Seychelles','Y'),(85,'AS','SG','Singapore','Y'),(86,'AS','LK','Sri Lanka','Y'),(87,'AS','TW','Taiwan','Y'),(88,'AS','TJ','Tajikistan','Y'),(89,'AS','TH','Thailand','Y'),(90,'AS','TM','Turkmenistan','Y'),(91,'AS','UZ','Uzbekistan','Y'),(92,'AS','VN','Vietnam','Y'),(94,'AU','AU','Australia','Y'),(95,'AU','FM','Federated States of Micronesia','Y'),(96,'AU','FJ','Fiji','Y'),(97,'AU','PF','French Polynesia','Y'),(98,'AU','GU','Guam','Y'),(99,'AU','KI','Kiribati','Y'),(100,'AU','MH','Marshall Islands','Y'),(101,'AU','NR','Nauru','Y'),(102,'AU','NC','New Caledonia','Y'),(103,'AU','NZ','New Zealand','Y'),(104,'AU','MP','Northern Mariana Islands','Y'),(105,'AU','PW','Palau','Y'),(106,'AU','PG','Papua New Guinea','Y'),(107,'AU','PN','Pitcairn','Y'),(108,'AU','SB','Solomon Islands','Y'),(109,'AU','TO','Tonga','Y'),(110,'AU','TV','Tuvalu','Y'),(111,'AU','VU','Vanuatu','Y'),(112,'CA','AI','Anguilla','Y'),(114,'CA','AW','Aruba','Y'),(115,'CA','BS','Bahamas','Y'),(116,'CA','BB','Barbados','Y'),(117,'CA','BM','Bermuda','Y'),(118,'CA','VI','British Virgin Islands','Y'),(119,'CA','KY','Cayman Islands','Y'),(120,'CA','DM','Dominica','Y'),(121,'CA','DO','Dominican Republic','Y'),(122,'CA','GD','Grenada','Y'),(123,'CA','GP','Guadeloupe','Y'),(124,'CA','HT','Haiti','Y'),(125,'CA','JM','Jamaica','Y'),(126,'CA','MQ','Martinique','Y'),(127,'CA','AN','Neterlands Antilles','Y'),(128,'CA','PR','Puerto Rico','Y'),(129,'CA','KN','St. Kitts and Nevis','Y'),(130,'CA','LC','St. Lucia','Y'),(131,'CA','VC','St. Vincent and the Grenadines','Y'),(132,'CA','TT','Trinidad and Tobago','Y'),(133,'CA','TC','Turks and Caicos Islands','Y'),(134,'CE','BZ','Belize','Y'),(135,'CE','CR','Costa Rica','Y'),(136,'CE','SV','El Salvador','Y'),(137,'CE','GT','Guatemala','Y'),(138,'CE','HN','Honduras','Y'),(139,'CE','NI','Nicaragua','Y'),(140,'CE','PA','Panama','Y'),(143,'CE','AM','Armenia','Y'),(144,'CE','AT','Austria','Y'),(145,'CE','AZ','Azerbaijan','Y'),(146,'CE','BY','Belarus','Y'),(147,'CE','BE','Belgium','Y'),(148,'CE','BG','Bulgaria','Y'),(149,'CE','HR','Croatia','Y'),(150,'CE','CY','Cyprus','Y'),(151,'CE','CZ','Czech Republic','Y'),(152,'CE','DK','Denmark','Y'),(153,'CE','EE','Estonia','Y'),(154,'CE','FO','Faroe Islands','Y'),(155,'CE','FI','Finland','Y'),(156,'CE','FR','France','Y'),(157,'CE','GE','Georgia','Y'),(158,'CE','DE','Germany','Y'),(159,'CE','GI','Gibraltar','Y'),(160,'CE','GR','Greece','Y'),(161,'CE','GL','Greenland','Y'),(162,'CE','HU','Hungary','Y'),(163,'CE','IS','Iceland','Y'),(164,'CE','IE','Ireland','Y'),(165,'CE','IT','Italy','Y'),(166,'CE','LV','Latvia','Y'),(167,'CE','LI','Liechtenstein','Y'),(168,'CE','LT','Lithuania','Y'),(169,'CE','LU','Luxembourg','Y'),(170,'CE','MT','Malta','Y'),(171,'CE','FX','Metropolitan France','Y'),(172,'CE','MD','Moldova','Y'),(173,'CE','NL','Netherlands','Y'),(174,'CE','NO','Norway','Y'),(175,'CE','PL','Poland','Y'),(176,'CE','PT','Portugal','Y'),(177,'CE','RO','Romania','Y'),(178,'CE','SK','Slovakia','Y'),(179,'CE','SI','Slovenia','Y'),(180,'CE','ES','Spain','Y'),(181,'CE','SJ','Svalbard and Jan Mayen Islands','Y'),(182,'CE','SE','Sweden','Y'),(183,'CE','CH','Switzerland','Y'),(184,'CE','MK','Republic of Macedonia','Y'),(185,'CE','TR','Turkey','Y'),(186,'CE','UA','Ukraine','Y'),(187,'CE','GB','United Kingdom','Y'),(188,'CE','VA','Vatican City','Y'),(189,'CE','YU','Yugoslavia','Y'),(190,'ME','IL','Israel','Y'),(191,'ME','JO','Jordan','Y'),(192,'ME','KW','Kuwait','Y'),(193,'ME','LB','Lebanon','Y'),(194,'ME','OM','Oman','Y'),(195,'ME','QA','Qatar','Y'),(196,'ME','SA','Saudi Arabia','Y'),(197,'ME','SY','Syria','Y'),(198,'ME','AE','United Arab Emirates','Y'),(199,'ME','YE','Yemen','Y'),(200,'NA','CA','Canada','Y'),(201,'NA','MX','Mexico','Y'),(202,'NA','US','United States','Y'),(204,'SA','BO','Bolivia','Y'),(205,'SA','BR','Brazil','Y'),(206,'SA','CL','Chile','Y'),(207,'SA','CO','Colombia','Y'),(208,'SA','EC','Equador','Y'),(209,'SA','FK','Falkland Islands','Y'),(210,'SA','GF','French Guiana','Y'),(211,'SA','GY','Guyana','Y'),(212,'SA','PY','Paraguay','Y'),(213,'SA','PE','Peru','Y'),(214,'SA','SR','Suriname','Y'),(215,'SA','UY','Uruguay','Y'),(216,'SA','VE','Venezuela','Y'),(217,'OT','BH','Bahrain','Y'),(218,'OT','BV','Bouvet Islands','Y'),(219,'OT','IO','British Indian Ocean Territory','Y');
/*!40000 ALTER TABLE `jom_js_job_countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_coverletters`
--

DROP TABLE IF EXISTS `jom_js_job_coverletters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_coverletters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `title` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `hits` int(11) DEFAULT NULL,
  `published` tinyint(1) NOT NULL,
  `searchable` tinyint(1) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `packageid` int(11) DEFAULT NULL,
  `paymenthistoryid` int(11) DEFAULT NULL,
  `serverstatus` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serverid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `coverletter_uid` (`uid`),
  KEY `coverletter_packgeid` (`packageid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_coverletters`
--

LOCK TABLES `jom_js_job_coverletters` WRITE;
/*!40000 ALTER TABLE `jom_js_job_coverletters` DISABLE KEYS */;
INSERT INTO `jom_js_job_coverletters` (`id`, `uid`, `title`, `alias`, `description`, `hits`, `published`, `searchable`, `status`, `created`, `packageid`, `paymenthistoryid`, `serverstatus`, `serverid`) VALUES (1,705,'My Job Application','my-job-application','Dear Sir/Madam,\r\n\r\nPlease consider job application, refer to my resume and video self-introduction. Thanks a lot. ',NULL,0,NULL,NULL,'2013-10-30 02:44:54',1,1,NULL,NULL);
/*!40000 ALTER TABLE `jom_js_job_coverletters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_currencies`
--

DROP TABLE IF EXISTS `jom_js_job_currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_currencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `symbol` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `default` tinyint(1) DEFAULT NULL,
  `serverid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_currencies`
--

LOCK TABLES `jom_js_job_currencies` WRITE;
/*!40000 ALTER TABLE `jom_js_job_currencies` DISABLE KEYS */;
INSERT INTO `jom_js_job_currencies` (`id`, `title`, `symbol`, `status`, `default`, `serverid`) VALUES (1,'Philippine Peso','PHP',1,0,NULL),(2,'US Dollar','USD',1,1,NULL),(3,'Australian Dollar','AUD',1,NULL,NULL),(4,'Saudi Riyal','SAR',1,NULL,NULL),(5,'Qatar Riyal','QAR',1,NULL,NULL),(6,'Japanese Yen','JPY',1,NULL,NULL),(7,'Euro','EUR',1,NULL,NULL);
/*!40000 ALTER TABLE `jom_js_job_currencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_departments`
--

DROP TABLE IF EXISTS `jom_js_job_departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_departments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `companyid` int(11) NOT NULL,
  `name` varchar(70) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  `serverstatus` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serverid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`,`companyid`),
  KEY `departments` (`companyid`),
  KEY `departments_uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_departments`
--

LOCK TABLES `jom_js_job_departments` WRITE;
/*!40000 ALTER TABLE `jom_js_job_departments` DISABLE KEYS */;
INSERT INTO `jom_js_job_departments` (`id`, `uid`, `companyid`, `name`, `alias`, `description`, `status`, `created`, `serverstatus`, `serverid`) VALUES (1,707,1,'IT Department','it-department','Information Technology Deparment, in charge of all IT-related works in the company.',1,'2013-10-28 15:45:43',NULL,NULL);
/*!40000 ALTER TABLE `jom_js_job_departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_emailtemplates`
--

DROP TABLE IF EXISTS `jom_js_job_emailtemplates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_emailtemplates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `templatefor` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subject` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8_unicode_ci,
  `status` tinyint(1) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_emailtemplates`
--

LOCK TABLES `jom_js_job_emailtemplates` WRITE;
/*!40000 ALTER TABLE `jom_js_job_emailtemplates` DISABLE KEYS */;
INSERT INTO `jom_js_job_emailtemplates` (`id`, `uid`, `templatefor`, `title`, `subject`, `body`, `status`, `created`) VALUES (1,0,'company-approval',NULL,'Company {COMPANY_NAME} has been approved','<p>Dear {EMPLOYER_NAME} , <br /><br />Your company <strong>{COMPANY_NAME}</strong> has been approved.</p>\r\n<p>Login and view detail at www.poec.org <br /><br />Please do not respond to this message. It is automatically generated and is for information purposes only.</p>',1,'2009-08-17 18:08:41'),(2,0,'company-rejecting',NULL,'Your Company {COMPANY_NAME} has been rejected','<p>Dear {EMPLOYER_NAME} ,</p>\r\n<p>&nbsp;</p>\r\n<p>Your company<strong> {COMPANY_NAME}</strong> has been rejected.</p>\r\n<p>&nbsp;</p>\r\n<p>Login and view detail at www.poec.org</p>\r\n<p>&nbsp;</p>\r\n<p>Please do not respond to this message. It is automatically generated and is for information purposes only.</p>',NULL,'2009-08-17 17:54:48'),(4,0,'job-approval',NULL,'Your job {JOB_TITLE} has been approved.','<p>Dear {EMPLOYER_NAME} ,</p>\r\n<p>&nbsp;</p>\r\n<p>Your job <strong>{JOB_TITLE}</strong> has been approved.</p>\r\n<p>&nbsp;</p>\r\n<p>Login and view detail at $siteAddress</p>\r\n<p>&nbsp;</p>\r\n<p>Please do not respond to this message. It is automatically generated and is for information purposes only.</p>',NULL,'2009-08-17 22:10:27'),(5,0,'job-rejecting',NULL,'Your job {JOB_TITLE} has been rejected.','<p>Dear {EMPLOYER_NAME} ,</p>\r\n<p>&nbsp;</p>\r\n<p>Your job <strong>{JOB_TITLE}</strong> has been rejected.</p>\r\n<p>&nbsp;</p>\r\n<p>Login and view detail at $siteAddress</p>\r\n<p>&nbsp;</p>\r\n<p>Please do not respond to this message. It is automatically generated and is for information purposes only.</p>',NULL,'2009-08-17 22:12:43'),(6,0,'resume-approval',NULL,'Your resume {RESUME_TITLE} has been approval.','<p>Dear {JOBSEEKER_NAME}  , </p><p> Your resume <strong>{RESUME_TITLE}</strong>  has been approval.</p><p> Login and view detail at $siteAddress </p><p>Please do not respond to this message. It is automatically generated and is for information purposes only.</p>',NULL,'2009-08-17 22:15:12'),(7,0,'resume-rejecting',NULL,'Your company {RESUME_TITLE} has been rejected. ','<p>Dear {JOBSEEKER_NAME}  , </p><p> Your resume <strong>{RESUME_TITLE}</strong>  has been rejected.</p><p> Login and view detail at $siteAddress </p><p>Please do not respond to this message. It is automatically generated and is for information purposes only.</p>',NULL,'2009-08-17 22:14:52'),(8,0,'jobapply-jobapply',NULL,'JS Jobs :  {JOBSEEKER_NAME} apply for {JOB_TITLE}','<p>Hello {EMPLOYER_NAME} , </p><p> Mr/Mrs {JOBSEEKER_NAME} apply for {JOB_TITLE}.</p><p> Login and view detail at $siteAddress \\n\\nPlease do not respond to this message. It is automatically generated and is for information purposes only.</p>',NULL,'2009-08-18 16:46:16'),(9,0,'company-new',NULL,'JS Jobs : New Company {COMPANY_NAME} has beed received','<p>Hello Admin ,</p>\r\n<p>&nbsp;</p>\r\n<p>We receive new company.</p>\r\n<p>&nbsp;</p>\r\n<p>Login and view detail at $siteAddress \\n\\nPlease do not respond to this message. It is automatically generated and is for information purposes only.</p>',NULL,'2009-08-18 16:46:16'),(10,0,'job-new',NULL,'JS Jobs : New Job {JOB_TITLE} has beed received','<p>Hello Admin ,</p>\r\n<p>&nbsp;</p>\r\n<p>We receive new job.</p>\r\n<p>&nbsp;</p>\r\n<p>Login and view detail at $siteAddress \\n\\nPlease do not respond to this message. It is automatically generated and is for information purposes only.</p>',NULL,'2009-08-18 16:46:16'),(11,0,'resume-new',NULL,'JS Jobs :  New resume {RESUME_TITLE} has beed received','<p>Hello Admin ,</p>\r\n<p>&nbsp;</p>\r\n<p>We receive new resume.</p>\r\n<p>&nbsp;</p>\r\n<p>Login and view detail at $siteAddress \\n\\nPlease do not respond to this message. It is automatically generated and is for information purposes only.</p>',NULL,'2009-08-18 16:46:16'),(12,0,'department-new',NULL,'JS Jobs : New Department {DEPARTMENT_NAME} {COMPANY_NAME} has beed received','<p>Hello Admin , </p><p> We receive new department.</p><p> Login and view detail at $siteAddress \\n\\nPlease do not respond to this message. It is automatically generated and is for information purposes only.</p>',NULL,'2009-08-18 16:46:16'),(13,0,'employer-buypackage',NULL,'JS Jobs : Employer Buy Package {PACKAGE_NAME}','<p>Hello Admin , </p><p> Employer buy a package.</p><p> Login and view detail at $siteAddress \\n\\nPlease do not respond to this message. It is automatically generated and is for information purposes only.</p>',NULL,'2009-08-18 16:46:16'),(14,0,'jobseeker-buypackage',NULL,'JS Jobs : Jobseeker Buy Package {PACKAGE_NAME}','<p>Hello Admin , </p><p> Job Seeker buy package.</p><p> Login and view detail at $siteAddress \\n\\nPlease do not respond to this message. It is automatically generated and is for information purposes only.</p>',NULL,'2009-08-18 16:46:16'),(15,0,'message-email',NULL,'JS Jobs: New Message Alert','<p>Dear {NAME},</p>\r\n<p>{SENDER_NAME}: send you new message.</p>\r\n<p><strong><span style=\"text-decoration: underline;\">Summary</span></strong></p>\r\n<p>Company Name: {COMPANY_NAME}</p>\r\n<p>Job Title: {JOB_TITLE}</p>\r\n<p>Resume Title: {RESUME_TITLE}</p>',1,'2009-08-18 16:46:16'),(16,0,'job-alert',NULL,'JS Jobs: New Job','<p>Dear {JOBSEEKER_NAME} ,</p>\r\n<p>We receive new job.</p>\r\n<p>{JOBS_INFO}</p>\r\n<p>Login and view detail at Please do not respond to this message. It is automatically generated and is for information purposes only.</p>',NULL,'2011-03-31 16:46:16'),(17,0,'job-alert-visitor',NULL,'JS Jobs: New Job By Visitor','<p>Dear {CONTACT_NAME} ,</p>\r\n<p>We receive new job.</p>\r\n<p>Title: {JOB_TITLE}</p>\r\n<p>Job Category: {JOB_CATEGORY}</p>\r\n<p>Company Name: {COMPANY_NAME}</p>\r\n<p>Status: {JOB_STATUS}</p>\r\n<p>Login and view detail at Please do not respond to this message. It is automatically generated and is for information purposes only.</p>',NULL,'2011-03-31 16:46:16'),(18,0,'job-to-friend',NULL,'JS Jobs: Job To Friend','<p>Dear Mr/Miss,</p>\r\n<p>Your Friend {SENDER_NAME} will send you this mail through our site {SITE_NAME} to inform you for a job.</p>\r\n<p>Title: {JOB_TITLE}</p>\r\n<p>Job Category: {JOB_CATEGORY}</p>\r\n<p>Company Name: {COMPANY_NAME}</p>\r\n<p>{CLICK_HERE_TO_VISIT} the job detail.</p>\r\n<p>Thank you.</p>\r\n<p>{SENDER_MESSAGE}</p>',NULL,'2011-03-31 16:46:16');
/*!40000 ALTER TABLE `jom_js_job_emailtemplates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_employerpackages`
--

DROP TABLE IF EXISTS `jom_js_job_employerpackages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_employerpackages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `currencyid` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `discount` int(11) DEFAULT NULL,
  `discounttype` tinyint(4) DEFAULT NULL,
  `discountmessage` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `discountstartdate` datetime DEFAULT NULL,
  `discountenddate` datetime DEFAULT NULL,
  `companiesallow` int(11) NOT NULL,
  `jobsallow` int(11) NOT NULL,
  `viewresumeindetails` int(11) NOT NULL,
  `resumesearch` int(11) NOT NULL,
  `saveresumesearch` int(11) NOT NULL,
  `featuredcompaines` int(11) NOT NULL,
  `goldcompanies` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `featuredjobs` int(11) NOT NULL,
  `goldjobs` int(11) NOT NULL,
  `jobseekershortlist` tinyint(4) DEFAULT NULL,
  `shortdetails` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `status` tinyint(4) NOT NULL,
  `video` tinyint(4) DEFAULT NULL,
  `map` tinyint(4) DEFAULT NULL,
  `packageexpireindays` int(11) NOT NULL,
  `featuredcompaniesexpireindays` int(11) DEFAULT NULL,
  `goldcompaniesexpireindays` int(11) DEFAULT NULL,
  `featuredjobsexpireindays` int(11) DEFAULT NULL,
  `goldjobsexpireindays` int(11) DEFAULT NULL,
  `enforcestoppublishjob` tinyint(1) DEFAULT '0',
  `enforcestoppublishjobvalue` int(11) DEFAULT NULL,
  `enforcestoppublishjobtype` tinyint(4) DEFAULT NULL,
  `fastspringlink` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherpaymentlink` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `messageallow` tinyint(1) DEFAULT NULL,
  `folders` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_employerpackages`
--

LOCK TABLES `jom_js_job_employerpackages` WRITE;
/*!40000 ALTER TABLE `jom_js_job_employerpackages` DISABLE KEYS */;
INSERT INTO `jom_js_job_employerpackages` (`id`, `currencyid`, `title`, `price`, `discount`, `discounttype`, `discountmessage`, `discountstartdate`, `discountenddate`, `companiesallow`, `jobsallow`, `viewresumeindetails`, `resumesearch`, `saveresumesearch`, `featuredcompaines`, `goldcompanies`, `created`, `featuredjobs`, `goldjobs`, `jobseekershortlist`, `shortdetails`, `description`, `status`, `video`, `map`, `packageexpireindays`, `featuredcompaniesexpireindays`, `goldcompaniesexpireindays`, `featuredjobsexpireindays`, `goldjobsexpireindays`, `enforcestoppublishjob`, `enforcestoppublishjobvalue`, `enforcestoppublishjobtype`, `fastspringlink`, `otherpaymentlink`, `messageallow`, `folders`) VALUES (1,0,'Free Package',0,0,1,'','2010-06-01 00:00:00','2010-08-24 00:00:00',1,3,3,1,0,0,0,'2013-10-28 00:00:00',0,0,1,'Free Package for single company','Free Package for single company',1,1,1,60,0,0,0,0,0,0,1,'','',1,1),(2,0,'Beginner Package',2000,0,1,'','1969-12-31 00:00:00','1969-12-31 00:00:00',10,100,100,1,1,10,10,'0000-00-00 00:00:00',25,25,NULL,NULL,'Premium Package for Employers provides mostly unlimited privileges.',1,NULL,NULL,365,365,365,365,365,0,0,1,NULL,NULL,1,25);
/*!40000 ALTER TABLE `jom_js_job_employerpackages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_employerpaymenthistory`
--

DROP TABLE IF EXISTS `jom_js_job_employerpaymenthistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_employerpaymenthistory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `companyid` int(11) DEFAULT NULL,
  `packageid` int(11) NOT NULL,
  `packagetitle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `packageprice` int(11) NOT NULL,
  `discountamount` int(11) DEFAULT NULL,
  `paidamount` int(11) DEFAULT NULL,
  `discountmessage` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `packagediscountstartdate` datetime DEFAULT NULL,
  `packagediscountenddate` datetime DEFAULT NULL,
  `companiesallow` int(11) NOT NULL,
  `jobsallow` int(11) DEFAULT NULL,
  `viewresumeindetails` int(11) NOT NULL,
  `resumesearch` int(11) NOT NULL,
  `saveresumesearch` int(11) NOT NULL,
  `featuredcompanies` int(11) DEFAULT NULL,
  `goldcompanies` int(11) DEFAULT NULL,
  `featuredjobs` int(11) DEFAULT NULL,
  `goldjobs` int(11) DEFAULT NULL,
  `candidateshortlist` tinyint(4) DEFAULT NULL,
  `video` tinyint(4) DEFAULT NULL,
  `map` tinyint(4) DEFAULT NULL,
  `packageexpireindays` int(11) NOT NULL,
  `packageshortdetails` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `packagedescription` text COLLATE utf8_unicode_ci,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  `transactionverified` tinyint(4) DEFAULT NULL,
  `transactionautoverified` tinyint(4) DEFAULT NULL,
  `verifieddate` datetime DEFAULT NULL,
  `referenceid` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payer_firstname` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payer_lastname` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payer_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payer_amount` float DEFAULT NULL,
  `payer_itemname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payer_itemname2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payer_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payer_tx_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employerpayment_uid` (`uid`),
  KEY `employerpayment_packageid` (`packageid`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_employerpaymenthistory`
--

LOCK TABLES `jom_js_job_employerpaymenthistory` WRITE;
/*!40000 ALTER TABLE `jom_js_job_employerpaymenthistory` DISABLE KEYS */;
INSERT INTO `jom_js_job_employerpaymenthistory` (`id`, `uid`, `companyid`, `packageid`, `packagetitle`, `packageprice`, `discountamount`, `paidamount`, `discountmessage`, `packagediscountstartdate`, `packagediscountenddate`, `companiesallow`, `jobsallow`, `viewresumeindetails`, `resumesearch`, `saveresumesearch`, `featuredcompanies`, `goldcompanies`, `featuredjobs`, `goldjobs`, `candidateshortlist`, `video`, `map`, `packageexpireindays`, `packageshortdetails`, `packagedescription`, `status`, `created`, `transactionverified`, `transactionautoverified`, `verifieddate`, `referenceid`, `payer_firstname`, `payer_lastname`, `payer_email`, `payer_amount`, `payer_itemname`, `payer_itemname2`, `payer_status`, `payer_tx_token`) VALUES (1,707,NULL,1,'Free Package',0,0,0,'','2010-06-01 11:53:05','2010-08-24 00:00:00',1,3,5,0,0,0,0,0,0,NULL,1,1,60,'Free Package for single company','Free Package for single company',1,'2013-10-28 15:33:04',1,1,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,335,NULL,1,'Free Package',0,0,0,'','2010-06-01 11:53:05','2010-08-24 00:00:00',1,3,5,0,0,0,0,0,0,NULL,1,1,60,'Free Package for single company','Free Package for single company',1,'2013-10-29 12:42:32',1,1,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,708,NULL,1,'Free Package',0,0,0,'','2010-06-01 11:53:05','2010-08-24 00:00:00',1,3,5,0,0,0,0,0,0,NULL,1,1,60,'Free Package for single company','Free Package for single company',1,'2013-10-30 01:39:50',1,1,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,715,NULL,1,'Free Package',0,0,0,'','2010-06-01 00:00:00','2010-08-24 00:00:00',1,3,5,1,1,0,0,0,0,NULL,1,1,60,'Free Package for single company','Free Package for single company',1,'2013-12-03 23:57:17',1,1,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(5,718,NULL,1,'Free Package',0,0,0,NULL,NULL,NULL,0,NULL,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,1,'2013-12-04 19:01:12',1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(6,707,NULL,2,'Beginner Package',2000,0,2000,'','1969-12-31 00:00:00','1969-12-31 00:00:00',10,100,100,1,1,10,10,25,25,NULL,NULL,NULL,365,NULL,'Premium Package for Employers provides mostly unlimited privileges.',1,'2013-12-04 20:23:06',0,0,NULL,'dd75f8a161fb1d89164011e',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(7,720,NULL,1,'Free Package',0,0,0,'','2010-06-01 00:00:00','2010-08-24 00:00:00',1,3,3,1,0,0,0,0,0,NULL,1,1,60,'Free Package for single company','Free Package for single company',1,'2013-12-09 07:57:42',1,1,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `jom_js_job_employerpaymenthistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_experiences`
--

DROP TABLE IF EXISTS `jom_js_job_experiences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_experiences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL,
  `serverid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_experiences`
--

LOCK TABLES `jom_js_job_experiences` WRITE;
/*!40000 ALTER TABLE `jom_js_job_experiences` DISABLE KEYS */;
INSERT INTO `jom_js_job_experiences` (`id`, `title`, `status`, `serverid`) VALUES (1,'Fresh',1,NULL),(2,'Less then 1 Year',1,NULL),(3,'1 Year',1,NULL),(4,'2 Year',1,NULL),(5,'3 Year',1,NULL),(6,'4 Year',1,NULL),(7,'5 Year',1,NULL),(8,'6 Year',1,NULL),(9,'7 Year',1,NULL),(10,'8 Year',1,NULL),(11,'9 Year',1,NULL),(12,'10 Year',1,NULL),(13,'11 Year',1,NULL),(14,'12 Year',1,NULL),(15,'13 Year',1,NULL),(16,'14 Year',1,NULL),(17,'15 Year',1,NULL),(18,'16 Year',1,NULL),(19,'17 Year',1,NULL),(20,'18 Year',1,NULL),(21,'19 Year',1,NULL),(22,'20 Year',1,NULL),(23,'21 Year',1,NULL),(24,'22 Year',1,NULL),(25,'23 Year',1,NULL),(26,'24 Year',1,NULL),(27,'25 Year',1,NULL);
/*!40000 ALTER TABLE `jom_js_job_experiences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_featuredcompanies`
--

DROP TABLE IF EXISTS `jom_js_job_featuredcompanies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_featuredcompanies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `packageid` int(11) DEFAULT NULL,
  `companyid` int(11) NOT NULL,
  `startdate` datetime NOT NULL,
  `enddate` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `featuredcompanies_uid` (`uid`),
  KEY `featuredcompanies_packageid` (`packageid`),
  KEY `featuredcompanies_companyid` (`companyid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_featuredcompanies`
--

LOCK TABLES `jom_js_job_featuredcompanies` WRITE;
/*!40000 ALTER TABLE `jom_js_job_featuredcompanies` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_js_job_featuredcompanies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_featuredjobs`
--

DROP TABLE IF EXISTS `jom_js_job_featuredjobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_featuredjobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `packageid` int(11) DEFAULT NULL,
  `jobid` int(11) NOT NULL,
  `startdate` datetime NOT NULL,
  `enddate` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `featuredjobs_uid` (`uid`),
  KEY `featuredjobs_packageid` (`packageid`),
  KEY `featuredjobs_jobid` (`jobid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_featuredjobs`
--

LOCK TABLES `jom_js_job_featuredjobs` WRITE;
/*!40000 ALTER TABLE `jom_js_job_featuredjobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_js_job_featuredjobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_featuredresumes`
--

DROP TABLE IF EXISTS `jom_js_job_featuredresumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_featuredresumes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `packageid` int(11) DEFAULT NULL,
  `resumeid` int(11) DEFAULT NULL,
  `startdate` datetime NOT NULL,
  `enddate` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `featuredjobs_uid` (`uid`),
  KEY `featuredjobs_packageid` (`packageid`),
  KEY `featuredjobs_resumeid` (`resumeid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_featuredresumes`
--

LOCK TABLES `jom_js_job_featuredresumes` WRITE;
/*!40000 ALTER TABLE `jom_js_job_featuredresumes` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_js_job_featuredresumes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_fieldsordering`
--

DROP TABLE IF EXISTS `jom_js_job_fieldsordering`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_fieldsordering` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `fieldtitle` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ordering` int(11) DEFAULT NULL,
  `section` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fieldfor` tinyint(2) DEFAULT NULL,
  `published` tinyint(1) DEFAULT NULL,
  `sys` tinyint(1) NOT NULL,
  `cannotunpublish` tinyint(1) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fieldordering_filedfor` (`fieldfor`)
) ENGINE=MyISAM AUTO_INCREMENT=792 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_fieldsordering`
--

LOCK TABLES `jom_js_job_fieldsordering` WRITE;
/*!40000 ALTER TABLE `jom_js_job_fieldsordering` DISABLE KEYS */;
INSERT INTO `jom_js_job_fieldsordering` (`id`, `field`, `fieldtitle`, `ordering`, `section`, `fieldfor`, `published`, `sys`, `cannotunpublish`, `required`) VALUES (1,'jobcategory','Job Category',2,NULL,1,1,1,1,1),(2,'name','Name',1,NULL,1,1,1,1,0),(3,'url','URL',3,NULL,1,1,1,0,0),(4,'contactname','Contact Name',4,NULL,1,1,1,1,0),(5,'contactphone','Contact Phone',5,NULL,1,1,1,0,0),(6,'contactemail','Contact Email',6,NULL,1,1,1,1,0),(7,'since','Since',8,NULL,1,1,1,0,0),(8,'companysize','Company Size',9,NULL,1,0,1,0,0),(9,'income','Income',10,NULL,1,1,1,0,0),(10,'description','Description',11,NULL,1,1,1,0,0),(11,'address1','Address1',17,NULL,1,1,1,0,0),(12,'logo','Logo',19,NULL,1,1,1,0,0),(20,'contactfax','Contact Fax',7,NULL,1,0,1,0,0),(21,'country','Country',12,NULL,1,1,1,1,0),(22,'state','State',13,NULL,1,1,1,0,0),(23,'county','County',14,'',1,1,1,0,0),(24,'city','City',15,NULL,1,1,1,0,0),(25,'zipcode','Zipcode',16,NULL,1,1,1,0,0),(26,'address2','Address2',18,NULL,1,1,1,0,0),(101,'jobtitle','Job Title',1,NULL,2,1,1,1,1),(102,'company','Company',2,NULL,2,1,1,1,1),(103,'department','Department',3,NULL,2,1,1,0,1),(104,'jobcategory','Job Category',4,NULL,2,1,1,1,1),(105,'subcategory','Sub Category',5,NULL,2,0,1,0,0),(106,'jobtype','Job Type',6,NULL,2,1,1,1,1),(107,'jobstatus','Job Status',7,NULL,2,1,1,1,1),(108,'gender','Gender',8,NULL,2,1,1,0,0),(109,'age','Age',9,NULL,2,1,1,0,0),(110,'jobsalaryrange','Job Salary Range',10,NULL,2,1,1,0,0),(111,'jobshift','Job Shift',11,NULL,2,0,1,0,0),(112,'heighesteducation','Heighest Education',12,NULL,2,1,1,1,0),(113,'experience','Experience',13,NULL,2,1,1,1,0),(114,'noofjobs','No of Jobs',14,NULL,2,1,1,0,0),(115,'duration','Duration',15,NULL,2,0,1,0,0),(116,'careerlevel','Career Level',16,NULL,2,1,1,0,0),(117,'workpermit','Work Permit',17,NULL,2,1,1,0,0),(118,'requiredtravel','Required Travel',18,NULL,2,1,1,0,0),(119,'video','Video',19,NULL,2,1,1,0,0),(120,'map','Map',20,NULL,2,0,1,0,1),(121,'startpublishing','Start Publishing',21,NULL,2,1,1,1,1),(122,'stoppublishing','Stop Publishing',22,NULL,2,1,1,1,1),(123,'country','Country',23,NULL,2,1,1,0,0),(124,'state','State',24,NULL,2,1,1,0,0),(125,'county','County',25,NULL,2,0,1,0,0),(126,'city','City',26,NULL,2,1,1,0,0),(130,'sendemail','Send Email',27,NULL,2,1,1,0,0),(131,'sendmeresume','Send me Resume',28,NULL,2,1,1,0,0),(132,'description','Description',29,NULL,2,1,1,0,0),(133,'qualifications','Qualifications',30,NULL,2,1,1,0,0),(134,'prefferdskills','Prefered Skills',31,NULL,2,1,1,0,0),(135,'agreement','Agreement',32,NULL,2,1,1,0,1),(136,'metadescription','Meta Description',33,NULL,2,1,1,0,1),(137,'metakeywords','Meta Keywords',34,NULL,2,1,1,0,1),(127,'zipcode','Zipcode',26,NULL,2,1,1,0,0),(301,'section_personal','Personal Information',0,'10',3,1,1,1,0),(302,'applicationtitle','Application Title',1,'10',3,1,1,1,0),(303,'firstname','First Name',2,'10',3,1,1,1,0),(304,'middlename','Middle Name',3,'10',3,1,1,0,0),(305,'lastname','Last Name',4,'10',3,1,1,1,0),(306,'emailaddress','Email Address',5,'10',3,1,1,1,0),(307,'homephone','Home Phone',6,'10',3,1,1,0,0),(308,'workphone','Work Phone',7,'10',3,1,1,0,0),(309,'cell','Cell',8,'10',3,1,1,0,0),(310,'nationality','Nationality',9,'10',3,1,1,0,0),(311,'gender','Gender',10,'10',3,1,1,0,0),(312,'photo','Photo',12,'10',3,1,1,0,0),(453,'fileupload','File Upload',13,'10',3,1,1,0,0),(313,'section_basic','Basic Information',15,'20',3,1,1,1,0),(314,'category','Category',16,'20',3,1,1,1,0),(315,'salary','Salary ',17,'20',3,1,1,1,0),(316,'jobtype','Job Type',18,'20',3,1,1,1,0),(317,'heighesteducation','Heighest Education',19,'20',3,1,1,1,0),(318,'totalexperience','Total Experience',20,'20',3,1,1,1,0),(319,'startdate','Date you can start',21,'20',3,1,1,1,0),(320,'section_addresses','Addresses',42,'30',3,1,1,0,0),(321,'section_sub_address','Current Address',43,'31',3,1,1,0,0),(322,'address_country','Country',44,'31',3,1,1,0,0),(323,'address_state','State',45,'31',3,1,1,0,0),(324,'address_county','County',46,'31',3,1,1,0,0),(325,'address_city','City',47,'31',3,1,1,0,0),(326,'address_zipcode','Zip Code',48,'31',3,1,1,0,0),(327,'address_address','Address',49,'31',3,1,1,0,0),(328,'section_sub_address1','Address1',51,'32',3,1,1,0,0),(329,'address1_country','Country',52,'32',3,1,1,0,0),(330,'address1_state','State',53,'32',3,1,1,0,0),(331,'address1_county','County',54,'32',3,1,1,0,0),(332,'address1_city','City',55,'32',3,1,1,0,0),(333,'address1_zipcode','Zip Code',56,'32',3,1,1,0,0),(334,'address1_address','Address',57,'32',3,1,1,0,0),(335,'section_sub_address2','Address1',61,'33',3,1,1,0,0),(336,'address2_country','Country',62,'33',3,1,1,0,0),(337,'address2_state','State',63,'33',3,1,1,0,0),(338,'address2_county','County',64,'33',3,1,1,0,0),(339,'address2_city','City',65,'33',3,1,1,0,0),(340,'address2_zipcode','Zip Code',66,'33',3,1,1,0,0),(341,'address2_address','Address',67,'33',3,1,1,0,0),(342,'section_education','Education',71,'40',3,1,1,0,0),(343,'section_sub_institute','High School',72,'41',3,1,1,0,0),(344,'institute_institute','Institute',73,'41',3,1,1,0,0),(345,'institute_country','Country',74,'41',3,1,1,0,0),(346,'institute_state','State',75,'41',3,1,1,0,0),(347,'institute_county','County',76,'41',3,1,1,0,0),(348,'institute_city','City',77,'41',3,1,1,0,0),(349,'institute_address','Address',78,'41',3,1,1,0,0),(350,'institute_certificate','Certificate Name',79,'41',3,1,1,0,0),(351,'institute_study_area','Study Area',80,'41',3,1,1,0,0),(352,'section_sub_institute1','University',82,'42',3,1,1,0,0),(353,'institute1_institute','Institute',83,'42',3,1,1,0,0),(354,'institute1_country','Country',84,'42',3,1,1,0,0),(355,'institute1_state','State',85,'42',3,1,1,0,0),(356,'institute1_county','County',86,'42',3,1,1,0,0),(357,'institute1_city','City',87,'42',3,1,1,0,0),(358,'institute1_address','Address',88,'42',3,1,1,0,0),(359,'institute1_certificate','Certificate Name',89,'42',3,1,1,0,0),(360,'institute1_study_area','Study Area',90,'42',3,1,1,0,0),(361,'section_sub_institute2','Grade School',92,'43',3,1,1,0,0),(362,'institute2_institute','Institute',93,'43',3,1,1,0,0),(363,'institute2_country','Country',94,'43',3,1,1,0,0),(364,'institute2_state','State',95,'43',3,1,1,0,0),(365,'institute2_county','County',96,'43',3,1,1,0,0),(366,'institute2_city','City',97,'43',3,1,1,0,0),(367,'institute2_address','Address',98,'43',3,1,1,0,0),(368,'institute2_certificate','Certificate Name',99,'43',3,1,1,0,0),(369,'institute2_study_area','Study Area',100,'43',3,1,1,0,0),(370,'section_sub_institute3','Other School',102,'44',3,1,1,0,0),(371,'institute3_institute','Institute',103,'44',3,1,1,0,0),(372,'institute3_country','Country',104,'44',3,1,1,0,0),(373,'institute3_state','State',105,'44',3,1,1,0,0),(374,'institute3_county','County',106,'44',3,1,1,0,0),(375,'institute3_city','City',107,'44',3,1,1,0,0),(376,'institute3_address','Address',108,'44',3,1,1,0,0),(377,'institute3_certificate','Certificate Name',109,'44',3,1,1,0,0),(378,'institute3_study_area','Study Area',110,'44',3,1,1,0,0),(379,'section_employer','Employer',112,'50',3,1,1,0,0),(380,'section_sub_employer','Recent Employer',113,'51',3,1,1,0,0),(381,'employer_employer','Employer',114,'51',3,1,1,0,0),(382,'employer_position','Position',114,'51',3,1,1,0,0),(383,'employer_resp','Responsibilities',115,'51',3,1,1,0,0),(384,'employer_pay_upon_leaving','Pay Upon Leaving',116,'51',3,1,1,0,0),(385,'employer_supervisor','Supervisor',117,'51',3,1,1,0,0),(386,'employer_from_date','From Date',118,'51',3,1,1,0,0),(387,'employer_to_date','To Date',119,'51',3,1,1,0,0),(388,'employer_leave_reason','Leave Reason',120,'51',3,1,1,0,0),(389,'employer_country','Country',121,'51',3,1,1,0,0),(390,'employer_state','State',122,'51',3,1,1,0,0),(391,'employer_county','County',123,'51',3,1,1,0,0),(392,'employer_city','City',124,'51',3,1,1,0,0),(393,'employer_zip','Zip Code',125,'51',3,1,1,0,0),(394,'employer_phone','Phone',126,'51',3,1,1,0,0),(395,'employer_address','Address',127,'51',3,1,1,0,0),(396,'section_sub_employer1','Prior Employer 1',128,'52',3,1,1,0,0),(397,'employer1_employer','Employer',129,'52',3,1,1,0,0),(398,'employer1_position','Position',130,'52',3,1,1,0,0),(399,'employer1_resp','Responsibilities',131,'52',3,1,1,0,0),(400,'employer1_pay_upon_leaving','Pay Upon Leaving',132,'52',3,1,1,0,0),(401,'employer1_supervisor','Supervisor',133,'52',3,1,1,0,0),(402,'employer1_from_date','From Date',134,'52',3,1,1,0,0),(403,'employer1_to_date','To Date',135,'52',3,1,1,0,0),(404,'employer1_leave_reason','Leave Reason',136,'52',3,1,1,0,0),(405,'employer1_country','Country',137,'52',3,1,1,0,0),(406,'employer1_state','State',138,'52',3,1,1,0,0),(407,'employer1_county','County',139,'52',3,1,1,0,0),(408,'employer1_city','City',140,'52',3,1,1,0,0),(409,'employer1_zip','Zip Code',141,'52',3,1,1,0,0),(410,'employer1_phone','Phone',142,'52',3,1,1,0,0),(412,'employer1_address','Address',143,'52',3,1,1,0,0),(413,'section_sub_employer2','Prior Employer 2',146,'53',3,1,1,0,0),(414,'employer2_employer','Employer',147,'53',3,1,1,0,0),(415,'employer2_position','Position',148,'53',3,1,1,0,0),(416,'employer2_resp','Responsibilities',149,'53',3,1,1,0,0),(417,'employer2_pay_upon_leaving','Pay Upon Leaving',150,'53',3,1,1,0,0),(418,'employer2_supervisor','Supervisor',151,'53',3,1,1,0,0),(419,'employer2_from_date','From Date',152,'53',3,1,1,0,0),(420,'employer2_to_date','To Date',153,'53',3,1,1,0,0),(421,'employer2_leave_reason','Leave Reason',154,'53',3,1,1,0,0),(423,'employer2_country','Country',155,'53',3,1,1,0,0),(424,'employer2_state','State',156,'53',3,1,1,0,0),(425,'employer2_county','County',157,'53',3,1,1,0,0),(426,'employer2_city','City',158,'53',3,1,1,0,0),(427,'employer2_zip','Zip Code',159,'53',3,1,1,0,0),(428,'employer2_phone','Phone',160,'53',3,1,1,0,0),(429,'employer2_address','Address',161,'53',3,1,1,0,0),(430,'section_sub_employer3','Prior Employer 3',166,'54',3,1,1,0,0),(431,'employer3_employer','Employer',167,'54',3,1,1,0,0),(432,'employer3_position','Position',168,'54',3,1,1,0,0),(433,'employer3_resp','Responsibilities',169,'54',3,1,1,0,0),(434,'employer3_pay_upon_leaving','Pay Upon Leaving',170,'54',3,1,1,0,0),(435,'employer3_supervisor','Supervisor',171,'54',3,1,1,0,0),(436,'employer3_from_date','From Date',172,'54',3,1,1,0,0),(437,'employer3_to_date','To Date',173,'54',3,1,1,0,0),(438,'employer3_leave_reason','Leave Reason',174,'54',3,1,1,0,0),(439,'employer3_country','Country',175,'54',3,1,1,0,0),(440,'employer3_state','State',176,'54',3,1,1,0,0),(441,'employer3_county','County',177,'54',3,1,1,0,0),(442,'employer3_city','City',178,'54',3,1,1,0,0),(443,'employer3_zip','Zip Code',179,'54',3,1,1,0,0),(444,'employer3_phone','Phone',180,'54',3,1,1,0,0),(445,'employer3_address','Address',181,'54',3,1,1,0,0),(446,'section_skills','Skills',186,'60',3,1,1,0,0),(447,'driving_license','Driving License',187,'60',3,1,1,0,0),(448,'license_no','License No',188,'60',3,1,1,0,0),(449,'license_country','License Country',189,'60',3,1,1,0,0),(450,'skills','Skills',190,'60',3,1,1,0,0),(451,'section_resumeeditor','Resume Editor',196,'70',3,1,1,0,0),(452,'editor','Editor',197,'70',3,1,1,0,0),(454,'section_references','References',206,'80',3,1,1,0,0),(455,'section_sub_reference','Reference 1',207,'81',3,1,1,0,0),(456,'reference_reference','Reference',208,'81',3,1,1,0,0),(457,'reference_name','Name',209,'81',3,1,1,0,0),(458,'reference_country','Country',210,'81',3,1,1,0,0),(459,'reference_state','State',211,'81',3,1,1,0,0),(460,'reference_county','County',212,'81',3,1,1,0,0),(471,'reference_city','City',213,'81',3,1,1,0,0),(472,'reference_zipcode','Zip Code',214,'81',3,1,1,0,0),(473,'reference_phone','Phone',215,'81',3,1,1,0,0),(474,'reference_relation','Relation',216,'81',3,1,1,0,0),(475,'reference_years','Years',217,'81',3,1,1,0,0),(476,'section_sub_reference1','Reference 2',221,'82',3,1,1,0,0),(477,'reference1_reference','Reference',222,'82',3,1,1,0,0),(478,'reference1_name','Name',223,'82',3,1,1,0,0),(479,'reference1_country','Country',224,'82',3,1,1,0,0),(480,'reference1_state','State',225,'82',3,1,1,0,0),(481,'reference1_county','County',226,'82',3,1,1,0,0),(482,'reference1_city','City',227,'82',3,1,1,0,0),(483,'reference1_zipcode','Zip Code',228,'82',3,1,1,0,0),(484,'reference1_phone','Phone',229,'82',3,1,1,0,0),(485,'reference1_relation','Relation',230,'82',3,1,1,0,0),(486,'reference1_years','Years',231,'82',3,1,1,0,0),(487,'section_sub_reference2','Reference 3',232,'83',3,1,1,0,0),(488,'reference2_reference','Reference',233,'83',3,1,1,0,0),(489,'reference2_name','Name',234,'83',3,1,1,0,0),(490,'reference2_country','Country',235,'83',3,1,1,0,0),(491,'reference2_state','State',236,'83',3,1,1,0,0),(492,'reference2_county','County',237,'83',3,1,1,0,0),(493,'reference2_city','City',238,'83',3,1,1,0,0),(494,'reference2_zipcode','Zip Code',239,'83',3,1,1,0,0),(495,'reference2_phone','Phone',240,'83',3,1,1,0,0),(496,'reference2_relation','Relation',241,'83',3,1,1,0,0),(497,'reference2_years','Years',242,'83',3,1,1,0,0),(498,'section_sub_reference3','Reference 4',243,'84',3,1,1,0,0),(499,'reference3_reference','Reference',244,'84',3,1,1,0,0),(500,'reference3_name','Name',245,'84',3,1,1,0,0),(501,'reference3_country','Country',246,'84',3,1,1,0,0),(502,'reference3_state','State',247,'84',3,1,1,0,0),(503,'reference3_county','County',248,'84',3,1,1,0,0),(504,'reference3_city','City',249,'84',3,1,1,0,0),(505,'reference3_zipcode','Zip Code',250,'84',3,1,1,0,0),(506,'reference3_phone','Phone',251,'84',3,1,1,0,0),(507,'reference3_relation','Relation',252,'84',3,1,1,0,0),(508,'reference3_years','Years',253,'84',3,1,1,0,0),(510,'Iamavailable','I am Available',11,'10',3,1,1,0,0),(511,'searchable','Searchable',12,'10',3,1,1,0,0),(512,'section_userfields','User Fields',21,'1000',3,0,0,0,0),(513,'userfield1','Civil Status',22,'1000',3,1,0,0,1),(514,'userfield2','User Field 2',23,'1000',3,0,0,0,0),(515,'userfield3','User Field 3',24,'1000',3,0,0,0,0),(516,'userfield4','User Field 4',25,'1000',3,0,0,0,0),(517,'userfield5','User Field 5',26,'1000',3,0,0,0,0),(518,'userfield6','User Field 6',27,'1000',3,0,0,0,0),(519,'userfield7','User Field 7',28,'1000',3,0,0,0,0),(520,'userfield8','User Field 8',29,'1000',3,0,0,0,0),(521,'userfield9','User Field 9',30,'1000',3,0,0,0,0),(522,'userfield10','User Field 10',32,'1000',3,0,0,0,0),(523,'jobcategory','Job Category',1,NULL,11,1,1,1,1),(524,'name','Name',2,NULL,11,1,1,1,0),(525,'url','URL',3,NULL,11,0,1,0,0),(526,'contactname','Contact Name',4,NULL,11,1,1,1,0),(527,'contactphone','Contact Phone',5,NULL,11,0,1,0,0),(528,'contactemail','Contact Email',6,NULL,11,1,1,1,0),(529,'since','Since',8,NULL,11,0,1,0,0),(530,'companysize','Company Size',9,NULL,11,0,1,0,0),(531,'income','Income',10,NULL,11,1,1,0,0),(532,'description','Description',11,NULL,11,1,1,0,0),(533,'address1','Address1',17,NULL,11,1,1,0,0),(534,'logo','Logo',19,NULL,11,1,1,0,0),(535,'contactfax','Contact Fax',7,NULL,11,0,1,0,0),(536,'country','Country',12,NULL,11,1,1,1,0),(537,'state','State',13,NULL,11,1,1,0,0),(538,'county','County',14,'',11,1,1,0,0),(539,'city','City',15,NULL,11,1,1,0,0),(540,'zipcode','Zipcode',16,NULL,11,1,1,0,0),(541,'address2','Address2',18,NULL,11,1,1,0,0),(542,'jobtitle','Job Title',1,NULL,12,1,1,1,1),(543,'company','Company',2,NULL,12,1,1,1,1),(544,'department','Department',3,NULL,12,1,1,0,1),(545,'jobcategory','Job Category',4,NULL,12,1,1,1,1),(546,'subcategory','Sub Category',5,NULL,12,1,1,0,0),(547,'jobtype','Job Type',6,NULL,12,1,1,1,1),(548,'jobstatus','Job Status',7,NULL,12,1,1,1,1),(549,'gender','Gender',8,NULL,12,1,1,0,0),(550,'age','Age',9,NULL,12,1,1,0,0),(551,'jobsalaryrange','Job Salary Range',10,NULL,12,1,1,0,0),(552,'jobshift','Job Shift',11,NULL,12,1,1,0,0),(553,'heighesteducation','Heighest Education',12,NULL,12,1,1,1,0),(554,'experience','Experience',13,NULL,12,1,1,1,0),(555,'noofjobs','No of Jobs',14,NULL,12,1,1,0,0),(556,'duration','Duration',15,NULL,12,1,1,0,0),(557,'careerlevel','Career Level',16,NULL,12,1,1,0,0),(558,'workpermit','Work Permit',17,NULL,12,1,1,0,0),(559,'requiredtravel','Required Travel',18,NULL,12,1,1,0,0),(560,'video','Video',19,NULL,12,1,1,0,0),(561,'map','Map',20,NULL,12,1,1,0,1),(562,'startpublishing','Start Publishing',21,NULL,12,1,1,1,1),(563,'stoppublishing','Stop Publishing',22,NULL,12,1,1,1,1),(564,'country','Country',23,NULL,12,1,1,0,0),(565,'state','State',24,NULL,12,1,1,0,0),(566,'county','County',25,NULL,12,1,1,0,0),(567,'city','City',26,NULL,12,1,1,0,0),(568,'sendemail','Send Email',27,NULL,12,1,1,0,0),(569,'sendmeresume','Send me Resume',28,NULL,12,1,1,0,0),(570,'description','Description',29,NULL,12,1,1,0,0),(571,'qualifications','Qualifications',30,NULL,12,1,1,0,0),(572,'prefferdskills','Prefered Skills',31,NULL,12,1,1,0,0),(573,'agreement','Agreement',32,NULL,12,1,1,0,1),(574,'metadescription','Meta Description',33,NULL,12,1,1,0,1),(575,'metakeywords','Meta Keywords',34,NULL,12,1,1,0,1),(576,'zipcode','Zipcode',26,NULL,12,1,1,0,0),(577,'section_personal','Personal Information',0,'10',13,1,1,1,0),(578,'applicationtitle','Application Title',1,'10',13,1,1,1,0),(579,'firstname','First Name',2,'10',13,1,1,1,0),(580,'middlename','Middle Name',3,'10',13,0,1,0,0),(581,'lastname','Last Name',4,'10',13,1,1,1,0),(582,'emailaddress','Email Address',5,'10',13,1,1,1,0),(583,'homephone','Home Phone',6,'10',13,1,1,0,0),(584,'workphone','Work Phone',7,'10',13,1,1,0,0),(585,'cell','Cell',8,'10',13,1,1,0,0),(586,'nationality','Nationality',9,'10',13,1,1,0,0),(587,'gender','Gender',10,'10',13,1,1,0,0),(588,'photo','Photo',12,'10',13,1,1,0,0),(589,'fileupload','File Upload',13,'10',13,1,1,0,0),(590,'section_basic','Basic Information',15,'20',13,1,1,1,0),(591,'category','Category',16,'20',13,1,1,1,0),(592,'salary','Salary ',17,'20',13,1,1,1,0),(593,'jobtype','Job Type',18,'20',13,1,1,1,0),(594,'heighesteducation','Heighest Education',19,'20',13,1,1,1,0),(595,'totalexperience','Total Experience',20,'20',13,1,1,1,0),(596,'startdate','Date you can start',21,'20',13,1,1,1,0),(597,'section_addresses','Addresses',42,'30',13,1,1,0,0),(598,'section_sub_address','Current Address',43,'31',13,1,1,0,0),(599,'address_country','Country',44,'31',13,1,1,0,0),(600,'address_state','State',45,'31',13,1,1,0,0),(601,'address_county','County',46,'31',13,1,1,0,0),(602,'address_city','City',47,'31',13,1,1,0,0),(603,'address_zipcode','Zip Code',48,'31',13,1,1,0,0),(604,'address_address','Address',49,'31',13,1,1,0,0),(605,'section_sub_address1','Address1',51,'32',13,1,1,0,0),(606,'address1_country','Country',52,'32',13,1,1,0,0),(607,'address1_state','State',53,'32',13,1,1,0,0),(608,'address1_county','County',54,'32',13,1,1,0,0),(609,'address1_city','City',55,'32',13,1,1,0,0),(610,'address1_zipcode','Zip Code',56,'32',13,1,1,0,0),(611,'address1_address','Address',57,'32',13,1,1,0,0),(612,'section_sub_address2','Address1',61,'33',13,1,1,0,0),(613,'address2_country','Country',62,'33',13,1,1,0,0),(614,'address2_state','State',63,'33',13,1,1,0,0),(615,'address2_county','County',64,'33',13,1,1,0,0),(616,'address2_city','City',65,'33',13,1,1,0,0),(617,'address2_zipcode','Zip Code',66,'33',13,1,1,0,0),(618,'address2_address','Address',67,'33',13,1,1,0,0),(619,'section_education','Education',71,'40',13,1,1,0,0),(620,'section_sub_institute','High School',72,'41',13,1,1,0,0),(621,'institute_institute','Institute',73,'41',13,1,1,0,0),(622,'institute_country','Country',74,'41',13,1,1,0,0),(623,'institute_state','State',75,'41',13,1,1,0,0),(624,'institute_county','County',76,'41',13,1,1,0,0),(625,'institute_city','City',77,'41',13,1,1,0,0),(626,'institute_address','Address',78,'41',13,1,1,0,0),(627,'institute_certificate','Certificate Name',79,'41',13,1,1,0,0),(628,'institute_study_area','Study Area',80,'41',13,1,1,0,0),(629,'section_sub_institute1','University',82,'42',13,1,1,0,0),(630,'institute1_institute','Institute',83,'42',13,1,1,0,0),(631,'institute1_country','Country',84,'42',13,1,1,0,0),(632,'institute1_state','State',85,'42',13,1,1,0,0),(633,'institute1_county','County',86,'42',13,1,1,0,0),(634,'institute1_city','City',87,'42',13,1,1,0,0),(635,'institute1_address','Address',88,'42',13,1,1,0,0),(636,'institute1_certificate','Certificate Name',89,'42',13,1,1,0,0),(637,'institute1_study_area','Study Area',90,'42',13,1,1,0,0),(638,'section_sub_institute2','Grade School',92,'43',13,1,1,0,0),(639,'institute2_institute','Institute',93,'43',13,1,1,0,0),(640,'institute2_country','Country',94,'43',13,1,1,0,0),(641,'institute2_state','State',95,'43',13,1,1,0,0),(642,'institute2_county','County',96,'43',13,1,1,0,0),(643,'institute2_city','City',97,'43',13,1,1,0,0),(644,'institute2_address','Address',98,'43',13,1,1,0,0),(645,'institute2_certificate','Certificate Name',99,'43',13,1,1,0,0),(646,'institute2_study_area','Study Area',100,'43',13,1,1,0,0),(647,'section_sub_institute3','Other School',102,'44',13,1,1,0,0),(648,'institute3_institute','Institute',103,'44',13,1,1,0,0),(649,'institute3_country','Country',104,'44',13,1,1,0,0),(650,'institute3_state','State',105,'44',13,1,1,0,0),(651,'institute3_county','County',106,'44',13,1,1,0,0),(652,'institute3_city','City',107,'44',13,1,1,0,0),(653,'institute3_address','Address',108,'44',13,1,1,0,0),(654,'institute3_certificate','Certificate Name',109,'44',13,1,1,0,0),(655,'institute3_study_area','Study Area',110,'44',13,1,1,0,0),(656,'section_employer','Employer',112,'50',13,1,1,0,0),(657,'section_sub_employer','Recent Employer',113,'51',13,1,1,0,0),(658,'employer_employer','Employer',114,'51',13,1,1,0,0),(659,'employer_position','Position',114,'51',13,1,1,0,0),(660,'employer_resp','Responsibilities',115,'51',13,1,1,0,0),(661,'employer_pay_upon_leaving','Pay Upon Leaving',116,'51',13,1,1,0,0),(662,'employer_supervisor','Supervisor',117,'51',13,1,1,0,0),(663,'employer_from_date','From Date',118,'51',13,1,1,0,0),(664,'employer_to_date','To Date',119,'51',13,1,1,0,0),(665,'employer_leave_reason','Leave Reason',120,'51',13,1,1,0,0),(666,'employer_country','Country',121,'51',13,1,1,0,0),(667,'employer_state','State',122,'51',13,1,1,0,0),(668,'employer_county','County',123,'51',13,1,1,0,0),(669,'employer_city','City',124,'51',13,1,1,0,0),(670,'employer_zip','Zip Code',125,'51',13,1,1,0,0),(671,'employer_phone','Phone',126,'51',13,1,1,0,0),(672,'employer_address','Address',127,'51',13,1,1,0,0),(673,'section_sub_employer1','Prior Employer 1',128,'52',13,1,1,0,0),(674,'employer1_employer','Employer',129,'52',13,1,1,0,0),(675,'employer1_position','Position',130,'52',13,1,1,0,0),(676,'employer1_resp','Responsibilities',131,'52',13,1,1,0,0),(677,'employer1_pay_upon_leaving','Pay Upon Leaving',132,'52',13,1,1,0,0),(678,'employer1_supervisor','Supervisor',133,'52',13,1,1,0,0),(679,'employer1_from_date','From Date',134,'52',13,1,1,0,0),(680,'employer1_to_date','To Date',135,'52',13,1,1,0,0),(681,'employer1_leave_reason','Leave Reason',136,'52',13,1,1,0,0),(682,'employer1_country','Country',137,'52',13,1,1,0,0),(683,'employer1_state','State',138,'52',13,1,1,0,0),(684,'employer1_county','County',139,'52',13,1,1,0,0),(685,'employer1_city','City',140,'52',13,1,1,0,0),(686,'employer1_zip','Zip Code',141,'52',13,1,1,0,0),(687,'employer1_phone','Phone',142,'52',13,1,1,0,0),(688,'employer1_address','Address',143,'52',13,1,1,0,0),(689,'section_sub_employer2','Prior Employer 2',146,'53',13,1,1,0,0),(690,'employer2_employer','Employer',147,'53',13,1,1,0,0),(691,'employer2_position','Position',148,'53',13,1,1,0,0),(692,'employer2_resp','Responsibilities',149,'53',13,1,1,0,0),(693,'employer2_pay_upon_leaving','Pay Upon Leaving',150,'53',13,1,1,0,0),(694,'employer2_supervisor','Supervisor',151,'53',13,1,1,0,0),(695,'employer2_from_date','From Date',152,'53',13,1,1,0,0),(696,'employer2_to_date','To Date',153,'53',13,1,1,0,0),(697,'employer2_leave_reason','Leave Reason',154,'53',13,1,1,0,0),(698,'employer2_country','Country',155,'53',13,1,1,0,0),(699,'employer2_state','State',156,'53',13,1,1,0,0),(700,'employer2_county','County',157,'53',13,1,1,0,0),(701,'employer2_city','City',158,'53',13,1,1,0,0),(702,'employer2_zip','Zip Code',159,'53',13,1,1,0,0),(703,'employer2_phone','Phone',160,'53',13,1,1,0,0),(704,'employer2_address','Address',161,'53',13,1,1,0,0),(705,'section_sub_employer3','Prior Employer 3',166,'54',13,1,1,0,0),(706,'employer3_employer','Employer',167,'54',13,1,1,0,0),(707,'employer3_position','Position',168,'54',13,1,1,0,0),(708,'employer3_resp','Responsibilities',169,'54',13,1,1,0,0),(709,'employer3_pay_upon_leaving','Pay Upon Leaving',170,'54',13,1,1,0,0),(710,'employer3_supervisor','Supervisor',171,'54',13,1,1,0,0),(711,'employer3_from_date','From Date',172,'54',13,1,1,0,0),(712,'employer3_to_date','To Date',173,'54',13,1,1,0,0),(713,'employer3_leave_reason','Leave Reason',174,'54',13,1,1,0,0),(714,'employer3_country','Country',175,'54',13,1,1,0,0),(715,'employer3_state','State',176,'54',13,1,1,0,0),(716,'employer3_county','County',177,'54',13,1,1,0,0),(717,'employer3_city','City',178,'54',13,1,1,0,0),(718,'employer3_zip','Zip Code',179,'54',13,1,1,0,0),(719,'employer3_phone','Phone',180,'54',13,1,1,0,0),(720,'employer3_address','Address',181,'54',13,1,1,0,0),(721,'section_skills','Skills',186,'60',13,1,1,0,0),(722,'driving_license','Driving License',187,'60',13,1,1,0,0),(723,'license_no','License No',188,'60',13,1,1,0,0),(724,'license_country','License Country',189,'60',13,1,1,0,0),(725,'skills','Skills',190,'60',13,1,1,0,0),(726,'section_resumeeditor','Resume Editor',196,'70',13,1,1,0,0),(727,'editor','Editor',197,'70',13,1,1,0,0),(728,'section_references','References',206,'80',13,1,1,0,0),(729,'section_sub_reference','Reference 1',207,'81',13,1,1,0,0),(730,'reference_reference','Reference',208,'81',13,1,1,0,0),(731,'reference_name','Name',209,'81',13,1,1,0,0),(732,'reference_country','Country',210,'81',13,1,1,0,0),(733,'reference_state','State',211,'81',13,1,1,0,0),(734,'reference_county','County',212,'81',13,1,1,0,0),(735,'reference_city','City',213,'81',13,1,1,0,0),(736,'reference_zipcode','Zip Code',214,'81',13,1,1,0,0),(737,'reference_phone','Phone',215,'81',13,1,1,0,0),(738,'reference_relation','Relation',216,'81',13,1,1,0,0),(739,'reference_years','Years',217,'81',13,1,1,0,0),(740,'section_sub_reference1','Reference 2',221,'82',13,1,1,0,0),(741,'reference1_reference','Reference',222,'82',13,1,1,0,0),(742,'reference1_name','Name',223,'82',13,1,1,0,0),(743,'reference1_country','Country',224,'82',13,1,1,0,0),(744,'reference1_state','State',225,'82',13,1,1,0,0),(745,'reference1_county','County',226,'82',13,1,1,0,0),(746,'reference1_city','City',227,'82',13,1,1,0,0),(747,'reference1_zipcode','Zip Code',228,'82',13,1,1,0,0),(748,'reference1_phone','Phone',229,'82',13,1,1,0,0),(749,'reference1_relation','Relation',230,'82',13,1,1,0,0),(750,'reference1_years','Years',231,'82',13,1,1,0,0),(751,'section_sub_reference2','Reference 3',232,'83',13,1,1,0,0),(752,'reference2_reference','Reference',233,'83',13,1,1,0,0),(753,'reference2_name','Name',234,'83',13,1,1,0,0),(754,'reference2_country','Country',235,'83',13,1,1,0,0),(755,'reference2_state','State',236,'83',13,1,1,0,0),(756,'reference2_county','County',237,'83',13,1,1,0,0),(757,'reference2_city','City',238,'83',13,1,1,0,0),(758,'reference2_zipcode','Zip Code',239,'83',13,1,1,0,0),(759,'reference2_phone','Phone',240,'83',13,1,1,0,0),(760,'reference2_relation','Relation',241,'83',13,1,1,0,0),(761,'reference2_years','Years',242,'83',13,1,1,0,0),(762,'section_sub_reference3','Reference 4',243,'84',13,1,1,0,0),(763,'reference3_reference','Reference',244,'84',13,1,1,0,0),(764,'reference3_name','Name',245,'84',13,1,1,0,0),(765,'reference3_country','Country',246,'84',13,1,1,0,0),(766,'reference3_state','State',247,'84',13,1,1,0,0),(767,'reference3_county','County',248,'84',13,1,1,0,0),(768,'reference3_city','City',249,'84',13,1,1,0,0),(769,'reference3_zipcode','Zip Code',250,'84',13,1,1,0,0),(770,'reference3_phone','Phone',251,'84',13,1,1,0,0),(771,'reference3_relation','Relation',252,'84',13,1,1,0,0),(772,'reference3_years','Years',253,'84',13,1,1,0,0),(773,'Iamavailable','I am Available',11,'10',13,1,1,0,0),(774,'searchable','Searchable',12,'10',13,1,1,0,0),(775,'section_userfields','Visitor User Fields',22,'1000',13,0,0,0,1),(776,'userfield1','User Field 1',23,'1000',13,0,0,0,0),(777,'userfield2','User Field 2',24,'1000',13,0,0,0,0),(778,'userfield3','User Field 3',25,'1000',13,0,0,0,0),(779,'userfield4','User Field 4',26,'1000',13,0,0,0,0),(780,'userfield5','User Field 5',27,'1000',13,0,0,0,0),(781,'userfield6','User Field 6',28,'1000',13,0,0,0,0),(782,'userfield7','User Field 7',29,'1000',13,0,0,0,0),(783,'userfield8','User Field 8',30,'1000',13,0,0,0,0),(784,'userfield9','User Field 9',31,'1000',13,0,0,0,0),(785,'userfield10','User Field 10',32,'1000',13,0,0,0,0),(786,'date_of_birth','Date of Birth',14,'10',3,1,0,0,0),(787,'date_of_birth','Date of Birth',14,'10',13,1,0,0,0),(788,'video','Youtube Video Id',22,'20',3,1,1,0,0),(789,'video','Youtube Video Id',22,'20',13,1,1,0,0),(790,'address_location','Longitude And Latitude',50,'31',3,1,1,0,0),(791,'address_location','Longitude And Latitude',50,'31',13,1,1,0,0);
/*!40000 ALTER TABLE `jom_js_job_fieldsordering` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_filters`
--

DROP TABLE IF EXISTS `jom_js_job_filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_filters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `country_istext` tinyint(1) DEFAULT NULL,
  `country` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state_istext` tinyint(1) DEFAULT NULL,
  `state` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `county_istext` tinyint(1) DEFAULT NULL,
  `county` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city_istext` tinyint(1) DEFAULT NULL,
  `city` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zipcode` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category` int(11) DEFAULT NULL,
  `jobtype` int(11) DEFAULT NULL,
  `jobstatus` int(11) DEFAULT NULL,
  `heighesteducation` int(11) DEFAULT NULL,
  `salaryrange` int(11) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_filters`
--

LOCK TABLES `jom_js_job_filters` WRITE;
/*!40000 ALTER TABLE `jom_js_job_filters` DISABLE KEYS */;
INSERT INTO `jom_js_job_filters` (`id`, `uid`, `country_istext`, `country`, `state_istext`, `state`, `county_istext`, `county`, `city_istext`, `city`, `zipcode`, `category`, `jobtype`, `jobstatus`, `heighesteducation`, `salaryrange`, `created`, `status`) VALUES (1,709,0,'PH',NULL,NULL,NULL,NULL,NULL,NULL,NULL,14,1,NULL,NULL,NULL,NULL,1);
/*!40000 ALTER TABLE `jom_js_job_filters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_folderresumes`
--

DROP TABLE IF EXISTS `jom_js_job_folderresumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_folderresumes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `jobid` int(11) NOT NULL,
  `resumeid` int(11) NOT NULL,
  `folderid` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `serverstatus` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serverid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_folderresumes`
--

LOCK TABLES `jom_js_job_folderresumes` WRITE;
/*!40000 ALTER TABLE `jom_js_job_folderresumes` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_js_job_folderresumes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_folders`
--

DROP TABLE IF EXISTS `jom_js_job_folders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_folders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `global` tinyint(1) NOT NULL,
  `jobid` int(11) DEFAULT NULL,
  `packageid` int(11) NOT NULL,
  `paymenthistoryid` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `decription` text COLLATE utf8_unicode_ci,
  `status` tinyint(1) NOT NULL,
  `created` datetime DEFAULT NULL,
  `serverstatus` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serverid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_folders`
--

LOCK TABLES `jom_js_job_folders` WRITE;
/*!40000 ALTER TABLE `jom_js_job_folders` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_js_job_folders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_goldcompanies`
--

DROP TABLE IF EXISTS `jom_js_job_goldcompanies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_goldcompanies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `packageid` int(11) DEFAULT NULL,
  `companyid` int(11) NOT NULL,
  `startdate` datetime NOT NULL,
  `enddate` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `goldcompanies_uid` (`uid`),
  KEY `goldcompanies_packageid` (`packageid`),
  KEY `goldcompanies_companyid` (`companyid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_goldcompanies`
--

LOCK TABLES `jom_js_job_goldcompanies` WRITE;
/*!40000 ALTER TABLE `jom_js_job_goldcompanies` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_js_job_goldcompanies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_goldjobs`
--

DROP TABLE IF EXISTS `jom_js_job_goldjobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_goldjobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `packageid` int(11) DEFAULT NULL,
  `jobid` int(11) NOT NULL,
  `startdate` datetime NOT NULL,
  `enddate` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `goldjobs_uid` (`uid`),
  KEY `goldjobs_packageid` (`packageid`),
  KEY `goldjobs_jobid` (`jobid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_goldjobs`
--

LOCK TABLES `jom_js_job_goldjobs` WRITE;
/*!40000 ALTER TABLE `jom_js_job_goldjobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_js_job_goldjobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_goldresumes`
--

DROP TABLE IF EXISTS `jom_js_job_goldresumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_goldresumes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `packageid` int(11) DEFAULT NULL,
  `resumeid` int(11) DEFAULT NULL,
  `startdate` datetime NOT NULL,
  `enddate` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `goldresumes_uid` (`uid`),
  KEY `goldresumes_packageid` (`packageid`),
  KEY `goldresumes_resumeid` (`resumeid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_goldresumes`
--

LOCK TABLES `jom_js_job_goldresumes` WRITE;
/*!40000 ALTER TABLE `jom_js_job_goldresumes` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_js_job_goldresumes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_heighesteducation`
--

DROP TABLE IF EXISTS `jom_js_job_heighesteducation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_heighesteducation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `isactive` tinyint(1) DEFAULT '1',
  `serverid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_heighesteducation`
--

LOCK TABLES `jom_js_job_heighesteducation` WRITE;
/*!40000 ALTER TABLE `jom_js_job_heighesteducation` DISABLE KEYS */;
INSERT INTO `jom_js_job_heighesteducation` (`id`, `title`, `isactive`, `serverid`) VALUES (1,'University',1,NULL),(2,'College',1,NULL),(3,'High School',1,NULL),(4,'No School',1,NULL);
/*!40000 ALTER TABLE `jom_js_job_heighesteducation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_jobalertsetting`
--

DROP TABLE IF EXISTS `jom_js_job_jobalertsetting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_jobalertsetting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `categoryid` int(11) NOT NULL,
  `subcategoryid` int(11) NOT NULL,
  `contactemail` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `state` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `county` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zipcode` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sendtime` datetime NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `keywords` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `alerttype` tinyint(1) DEFAULT NULL,
  `longitude` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitude` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `coordinatesradius` int(11) NOT NULL,
  `lastmailsend` datetime NOT NULL,
  `serverstatus` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serverid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_jobalertsetting`
--

LOCK TABLES `jom_js_job_jobalertsetting` WRITE;
/*!40000 ALTER TABLE `jom_js_job_jobalertsetting` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_js_job_jobalertsetting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_jobapply`
--

DROP TABLE IF EXISTS `jom_js_job_jobapply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_jobapply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jobid` int(11) NOT NULL DEFAULT '0',
  `uid` int(11) NOT NULL DEFAULT '0',
  `cvid` int(11) DEFAULT NULL,
  `apply_date` datetime DEFAULT NULL,
  `resumeview` tinyint(1) NOT NULL DEFAULT '0',
  `comments` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `coverletterid` int(11) DEFAULT NULL,
  `action_status` int(11) DEFAULT '1',
  `serverstatus` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serverid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `jobapply_uid` (`uid`),
  KEY `jobapply_jobid` (`jobid`),
  KEY `jobapply_cvid` (`cvid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_jobapply`
--

LOCK TABLES `jom_js_job_jobapply` WRITE;
/*!40000 ALTER TABLE `jom_js_job_jobapply` DISABLE KEYS */;
INSERT INTO `jom_js_job_jobapply` (`id`, `jobid`, `uid`, `cvid`, `apply_date`, `resumeview`, `comments`, `coverletterid`, `action_status`, `serverstatus`, `serverid`) VALUES (1,1,705,1,'2013-10-30 02:45:57',1,NULL,1,1,NULL,NULL);
/*!40000 ALTER TABLE `jom_js_job_jobapply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_jobs`
--

DROP TABLE IF EXISTS `jom_js_job_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_jobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `companyid` int(11) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `jobcategory` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `jobtype` tinyint(1) unsigned DEFAULT '0',
  `jobstatus` tinyint(3) NOT NULL DEFAULT '1',
  `jobsalaryrange` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `salaryrangetype` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hidesalaryrange` tinyint(1) DEFAULT '1',
  `description` text COLLATE utf8_unicode_ci,
  `qualifications` text COLLATE utf8_unicode_ci,
  `prefferdskills` text COLLATE utf8_unicode_ci,
  `applyinfo` text COLLATE utf8_unicode_ci,
  `company` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `county` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `city` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `zipcode` varchar(10) COLLATE utf8_unicode_ci DEFAULT '',
  `address1` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `address2` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `companyurl` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `contactname` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `contactphone` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `contactemail` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `showcontact` tinyint(1) unsigned DEFAULT '0',
  `noofjobs` int(11) unsigned NOT NULL DEFAULT '1',
  `reference` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `duration` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `heighestfinisheducation` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) unsigned NOT NULL DEFAULT '0',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(11) unsigned NOT NULL DEFAULT '0',
  `hits` int(11) unsigned NOT NULL DEFAULT '0',
  `experience` int(11) DEFAULT '0',
  `startpublishing` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `stoppublishing` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `departmentid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `shift` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sendemail` tinyint(1) NOT NULL DEFAULT '0',
  `metadescription` text COLLATE utf8_unicode_ci,
  `metakeywords` text COLLATE utf8_unicode_ci,
  `agreement` text COLLATE utf8_unicode_ci,
  `ordering` tinyint(3) NOT NULL DEFAULT '0',
  `aboutjobfile` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `educationminimax` tinyint(1) DEFAULT NULL,
  `educationid` int(11) DEFAULT NULL,
  `mineducationrange` int(11) DEFAULT NULL,
  `maxeducationrange` int(11) DEFAULT NULL,
  `iseducationminimax` tinyint(1) DEFAULT NULL,
  `degreetitle` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `careerlevel` int(11) DEFAULT NULL,
  `experienceminimax` tinyint(1) DEFAULT NULL,
  `experienceid` int(11) DEFAULT NULL,
  `minexperiencerange` int(11) DEFAULT NULL,
  `maxexperiencerange` int(11) DEFAULT NULL,
  `isexperienceminimax` tinyint(1) DEFAULT NULL,
  `experiencetext` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `workpermit` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `requiredtravel` int(11) DEFAULT NULL,
  `agefrom` int(11) DEFAULT NULL,
  `ageto` int(11) DEFAULT NULL,
  `salaryrangefrom` int(11) DEFAULT NULL,
  `salaryrangeto` int(11) DEFAULT NULL,
  `gender` int(5) DEFAULT NULL,
  `video` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `map` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `packageid` int(11) DEFAULT NULL,
  `paymenthistoryid` int(11) DEFAULT NULL,
  `subcategoryid` int(11) DEFAULT NULL,
  `currencyid` int(11) DEFAULT NULL,
  `jobid` varchar(25) COLLATE utf8_unicode_ci DEFAULT '',
  `longitude` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitude` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isgoldjob` tinyint(1) DEFAULT NULL,
  `isfeaturedjob` tinyint(1) DEFAULT NULL,
  `raf_gender` tinyint(1) DEFAULT NULL,
  `raf_degreelevel` tinyint(1) DEFAULT NULL,
  `raf_experience` tinyint(1) DEFAULT NULL,
  `raf_age` tinyint(1) DEFAULT NULL,
  `raf_education` tinyint(1) DEFAULT NULL,
  `raf_category` tinyint(1) DEFAULT NULL,
  `raf_subcategory` tinyint(1) DEFAULT NULL,
  `raf_location` tinyint(1) DEFAULT NULL,
  `serverstatus` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serverid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `jobcategory` (`jobcategory`),
  KEY `jobs_companyid` (`companyid`),
  KEY `jobsalaryrange` (`jobsalaryrange`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_jobs`
--

LOCK TABLES `jom_js_job_jobs` WRITE;
/*!40000 ALTER TABLE `jom_js_job_jobs` DISABLE KEYS */;
INSERT INTO `jom_js_job_jobs` (`id`, `uid`, `companyid`, `title`, `alias`, `jobcategory`, `jobtype`, `jobstatus`, `jobsalaryrange`, `salaryrangetype`, `hidesalaryrange`, `description`, `qualifications`, `prefferdskills`, `applyinfo`, `company`, `country`, `state`, `county`, `city`, `zipcode`, `address1`, `address2`, `companyurl`, `contactname`, `contactphone`, `contactemail`, `showcontact`, `noofjobs`, `reference`, `duration`, `heighestfinisheducation`, `created`, `created_by`, `modified`, `modified_by`, `hits`, `experience`, `startpublishing`, `stoppublishing`, `departmentid`, `shift`, `sendemail`, `metadescription`, `metakeywords`, `agreement`, `ordering`, `aboutjobfile`, `status`, `educationminimax`, `educationid`, `mineducationrange`, `maxeducationrange`, `iseducationminimax`, `degreetitle`, `careerlevel`, `experienceminimax`, `experienceid`, `minexperiencerange`, `maxexperiencerange`, `isexperienceminimax`, `experiencetext`, `workpermit`, `requiredtravel`, `agefrom`, `ageto`, `salaryrangefrom`, `salaryrangeto`, `gender`, `video`, `map`, `packageid`, `paymenthistoryid`, `subcategoryid`, `currencyid`, `jobid`, `longitude`, `latitude`, `isgoldjob`, `isfeaturedjob`, `raf_gender`, `raf_degreelevel`, `raf_experience`, `raf_age`, `raf_education`, `raf_category`, `raf_subcategory`, `raf_location`, `serverstatus`, `serverid`) VALUES (1,707,1,'Web Developer & Designer','web-developer-&-designer','13',1,1,'','2',0,'<p>The Web Developer and Designer will develop and design a web :)</p>','','',NULL,'','PH','NCR','','','','','','','','','',0,2,'','','','2013-10-28 15:46:28',0,'0000-00-00 00:00:00',0,25,0,'2013-10-27 15:52:21','2013-11-26 00:00:00','1','1',1,'','','',0,NULL,1,1,1,0,0,1,'',4,1,7,0,0,1,'','QA',2,3,6,8,9,0,'',NULL,1,1,50,2,'FkmQ@6pWD','120.991309','14.568714',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `jom_js_job_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_jobsearches`
--

DROP TABLE IF EXISTS `jom_js_job_jobsearches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_jobsearches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `searchname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `jobtitle` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category` int(11) DEFAULT NULL,
  `jobtype` int(11) DEFAULT NULL,
  `jobstatus` int(11) DEFAULT NULL,
  `salaryrange` int(11) DEFAULT NULL,
  `heighesteducation` int(11) DEFAULT NULL,
  `shift` int(11) DEFAULT NULL,
  `experience` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `durration` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `startpublishing` datetime DEFAULT NULL,
  `stoppublishing` datetime DEFAULT NULL,
  `company` int(11) DEFAULT NULL,
  `country_istext` tinyint(1) DEFAULT NULL,
  `country` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state_istext` tinyint(1) DEFAULT NULL,
  `state` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `county_istext` tinyint(1) DEFAULT NULL,
  `county` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city_istext` tinyint(1) DEFAULT NULL,
  `city` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zipcode_istext` tinyint(1) DEFAULT NULL,
  `zipcode` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `jobsearches_uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_jobsearches`
--

LOCK TABLES `jom_js_job_jobsearches` WRITE;
/*!40000 ALTER TABLE `jom_js_job_jobsearches` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_js_job_jobsearches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_jobseekerpackages`
--

DROP TABLE IF EXISTS `jom_js_job_jobseekerpackages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_jobseekerpackages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `currencyid` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `discount` int(11) DEFAULT NULL,
  `discounttype` tinyint(4) DEFAULT NULL,
  `discountmessage` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `discountstartdate` datetime DEFAULT NULL,
  `discountenddate` datetime DEFAULT NULL,
  `resumeallow` int(11) NOT NULL,
  `coverlettersallow` int(11) NOT NULL,
  `applyjobs` int(11) NOT NULL,
  `jobsearch` int(11) NOT NULL,
  `savejobsearch` int(11) NOT NULL,
  `featuredresume` int(11) NOT NULL,
  `goldresume` int(11) NOT NULL,
  `video` tinyint(4) DEFAULT NULL,
  `packageexpireindays` int(11) NOT NULL,
  `shortdetails` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  `freaturedresumeexpireindays` int(11) DEFAULT NULL,
  `goldresumeexpireindays` int(11) DEFAULT NULL,
  `fastspringlink` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherpaymentlink` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `jobalertsetting` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_jobseekerpackages`
--

LOCK TABLES `jom_js_job_jobseekerpackages` WRITE;
/*!40000 ALTER TABLE `jom_js_job_jobseekerpackages` DISABLE KEYS */;
INSERT INTO `jom_js_job_jobseekerpackages` (`id`, `currencyid`, `title`, `price`, `discount`, `discounttype`, `discountmessage`, `discountstartdate`, `discountenddate`, `resumeallow`, `coverlettersallow`, `applyjobs`, `jobsearch`, `savejobsearch`, `featuredresume`, `goldresume`, `video`, `packageexpireindays`, `shortdetails`, `description`, `status`, `created`, `freaturedresumeexpireindays`, `goldresumeexpireindays`, `fastspringlink`, `otherpaymentlink`, `jobalertsetting`) VALUES (1,0,'Free Package',0,0,1,'','2013-10-29 00:00:00','2014-10-29 00:00:00',1,0,1,1,0,0,0,0,90,'Free Package','Free Package',1,'2013-10-28 00:00:00',0,0,'','',0),(2,0,'Beginner Package',500,0,1,'','2013-10-29 00:00:00','2014-10-29 00:00:00',5,25,25,1,1,5,5,NULL,365,'Beginner Package','Premium Package, 365 days renewable.',1,'0000-00-00 00:00:00',365,365,NULL,NULL,1);
/*!40000 ALTER TABLE `jom_js_job_jobseekerpackages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_jobseekerpaymenthistory`
--

DROP TABLE IF EXISTS `jom_js_job_jobseekerpaymenthistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_jobseekerpaymenthistory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `packageprice` int(11) NOT NULL,
  `discountamount` int(11) DEFAULT NULL,
  `paidamount` int(11) DEFAULT NULL,
  `discountmessage` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `packagestartdate` datetime DEFAULT NULL,
  `packageenddate` datetime DEFAULT NULL,
  `resumeallow` int(11) NOT NULL,
  `coverlettersallow` int(11) DEFAULT NULL,
  `applyjobs` int(11) DEFAULT NULL,
  `jobsearch` int(11) NOT NULL,
  `savejobsearch` int(11) NOT NULL,
  `featuredresume` int(11) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created` datetime NOT NULL,
  `transactionverified` tinyint(4) DEFAULT NULL,
  `transactionautoverified` tinyint(4) DEFAULT NULL,
  `verifieddate` datetime DEFAULT NULL,
  `packageid` int(11) DEFAULT NULL,
  `packagetitle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `video` tinyint(4) DEFAULT NULL,
  `goldresume` int(11) DEFAULT NULL,
  `packageexpireindays` int(11) NOT NULL,
  `packageshortdetails` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `packagedescription` text COLLATE utf8_unicode_ci,
  `referenceid` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payer_firstname` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payer_lastname` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payer_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payer_amount` float DEFAULT NULL,
  `payer_itemname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payer_itemname1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payer_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payer_tx_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employerpayment_uid` (`uid`),
  KEY `employerpayment_packageid` (`packageid`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_jobseekerpaymenthistory`
--

LOCK TABLES `jom_js_job_jobseekerpaymenthistory` WRITE;
/*!40000 ALTER TABLE `jom_js_job_jobseekerpaymenthistory` DISABLE KEYS */;
INSERT INTO `jom_js_job_jobseekerpaymenthistory` (`id`, `uid`, `packageprice`, `discountamount`, `paidamount`, `discountmessage`, `packagestartdate`, `packageenddate`, `resumeallow`, `coverlettersallow`, `applyjobs`, `jobsearch`, `savejobsearch`, `featuredresume`, `status`, `created`, `transactionverified`, `transactionautoverified`, `verifieddate`, `packageid`, `packagetitle`, `video`, `goldresume`, `packageexpireindays`, `packageshortdetails`, `packagedescription`, `referenceid`, `payer_firstname`, `payer_lastname`, `payer_email`, `payer_amount`, `payer_itemname`, `payer_itemname1`, `payer_status`, `payer_tx_token`) VALUES (1,705,0,0,0,'','2010-06-01 11:53:05','2010-08-24 00:00:00',1,3,-1,1,1,0,1,'2013-10-28 14:50:59',1,1,NULL,1,'Free Package',0,0,60,'Free Package','Free Package','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,706,0,0,0,'','2010-06-01 11:53:05','2010-08-24 00:00:00',1,3,-1,1,1,0,1,'2013-10-28 15:24:51',1,1,NULL,1,'Free Package',0,0,60,'Free Package','Free Package','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,705,50,0,50,'','2013-10-29 00:00:00','2014-10-29 00:00:00',50,50,-1,1,1,50,-1,'2013-10-29 08:07:52',-1,0,NULL,2,'Premium Package',NULL,50,365,'Premium Package','Premium Package, 365 days renewable.','5eed9e63ab9a8a3573f53d3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,705,0,0,0,'','2013-10-29 00:00:00','2014-10-29 00:00:00',50,50,-1,1,1,50,1,'2013-10-30 10:18:24',1,1,NULL,2,'Premium Package',NULL,50,365,'Premium Package','Premium Package, 365 days renewable.','27ce5bbda7f6fcfad68d1e1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(5,709,0,0,0,'','2013-10-29 00:00:00','2014-10-29 00:00:00',1,1,5,1,0,0,1,'2013-11-03 03:28:05',1,1,NULL,1,'Free Package',0,0,90,'Free Package','Free Package','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(6,711,0,0,0,'','2013-10-29 00:00:00','2014-10-29 00:00:00',1,1,5,1,0,0,1,'2013-11-04 00:35:28',1,1,NULL,1,'Free Package',0,0,90,'Free Package','Free Package','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(7,712,0,0,0,'','2013-10-29 00:00:00','2014-10-29 00:00:00',1,1,5,1,0,0,1,'2013-11-04 01:27:53',1,1,NULL,1,'Free Package',0,0,90,'Free Package','Free Package','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(8,713,0,0,0,'','2013-10-29 00:00:00','2014-10-29 00:00:00',1,1,5,1,0,0,1,'2013-12-03 23:16:17',1,1,NULL,1,'Free Package',0,0,90,'Free Package','Free Package','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(9,714,0,0,0,'','2013-10-29 00:00:00','2014-10-29 00:00:00',1,1,5,1,0,0,1,'2013-12-03 23:42:53',1,1,NULL,1,'Free Package',0,0,90,'Free Package','Free Package','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(10,716,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,0,NULL,1,'2013-12-04 00:21:51',1,1,NULL,1,'Free Package',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(11,709,500,0,500,'','2013-10-29 00:00:00','2014-10-29 00:00:00',5,25,25,1,1,5,1,'2013-12-04 18:51:00',0,0,NULL,2,'Beginner Package',NULL,5,365,'Beginner Package','Premium Package, 365 days renewable.','20c28e6e2d2e044fe141ee9',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `jom_js_job_jobseekerpaymenthistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_jobstatus`
--

DROP TABLE IF EXISTS `jom_js_job_jobstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_jobstatus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `isactive` tinyint(1) DEFAULT '1',
  `serverid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_jobstatus`
--

LOCK TABLES `jom_js_job_jobstatus` WRITE;
/*!40000 ALTER TABLE `jom_js_job_jobstatus` DISABLE KEYS */;
INSERT INTO `jom_js_job_jobstatus` (`id`, `title`, `isactive`, `serverid`) VALUES (1,'Sourcing',1,NULL),(2,'Interviewing',1,NULL),(3,'Closed to New Applicants',1,NULL),(4,'Finalists Identified',1,NULL),(5,'Pending Approval',1,NULL),(6,'Hold',1,NULL);
/*!40000 ALTER TABLE `jom_js_job_jobstatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_jobtypes`
--

DROP TABLE IF EXISTS `jom_js_job_jobtypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_jobtypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `isactive` tinyint(1) DEFAULT '1',
  `status` tinyint(1) DEFAULT NULL,
  `serverid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_jobtypes`
--

LOCK TABLES `jom_js_job_jobtypes` WRITE;
/*!40000 ALTER TABLE `jom_js_job_jobtypes` DISABLE KEYS */;
INSERT INTO `jom_js_job_jobtypes` (`id`, `title`, `isactive`, `status`, `serverid`) VALUES (1,'Full-Time',1,1,NULL),(2,'Part-Time',1,1,NULL),(3,'Internship',1,1,NULL);
/*!40000 ALTER TABLE `jom_js_job_jobtypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_messages`
--

DROP TABLE IF EXISTS `jom_js_job_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employerid` int(11) NOT NULL,
  `jobseekerid` int(11) DEFAULT NULL,
  `sendby` int(11) NOT NULL,
  `jobid` int(11) NOT NULL,
  `replytoid` int(11) NOT NULL,
  `resumeid` int(11) NOT NULL,
  `subject` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `isread` tinyint(1) NOT NULL,
  `isconflict` tinyint(1) DEFAULT NULL,
  `conflictvalue` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `created` datetime NOT NULL,
  `serverstatus` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serverid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_messages`
--

LOCK TABLES `jom_js_job_messages` WRITE;
/*!40000 ALTER TABLE `jom_js_job_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_js_job_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_resume`
--

DROP TABLE IF EXISTS `jom_js_job_resume`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_resume` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `create_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` datetime DEFAULT NULL,
  `published` tinyint(1) DEFAULT '1',
  `hits` int(11) DEFAULT NULL,
  `application_title` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `keywords` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `middle_name` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_address` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `home_phone` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `work_phone` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cell` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nationality` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `iamavailable` tinyint(1) DEFAULT NULL,
  `searchable` tinyint(1) DEFAULT '1',
  `photo` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `job_category` int(11) DEFAULT NULL,
  `jobsalaryrange` int(11) DEFAULT NULL,
  `jobtype` int(11) DEFAULT NULL,
  `heighestfinisheducation` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_country` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_state` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_county` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_city` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_zipcode` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8_unicode_ci,
  `institute` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `institute_country` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `institute_state` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `institute_county` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `institute_city` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `institute_address` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `institute_certificate_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `institute_study_area` text COLLATE utf8_unicode_ci,
  `employer` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer_position` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer_resp` text COLLATE utf8_unicode_ci,
  `employer_pay_upon_leaving` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer_supervisor` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer_from_date` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer_to_date` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer_leave_reason` text COLLATE utf8_unicode_ci,
  `employer_country` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer_state` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer_county` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer_city` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer_zip` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer_phone` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer_address` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filename` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filetype` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filesize` int(11) DEFAULT NULL,
  `filecontent` mediumblob,
  `field1` text COLLATE utf8_unicode_ci,
  `field2` text COLLATE utf8_unicode_ci,
  `field3` text COLLATE utf8_unicode_ci,
  `status` int(11) NOT NULL DEFAULT '1',
  `resume` text COLLATE utf8_unicode_ci,
  `institute1` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `institute1_country` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `institute1_state` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `institute1_county` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `institute1_city` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `institute1_address` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `institute1_study_area` text COLLATE utf8_unicode_ci,
  `institute1_certificate_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `institute2` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `institute2_country` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `institute2_state` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `institute2_county` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `institute2_city` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `institute2_address` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `institute2_certificate_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `institute2_study_area` text COLLATE utf8_unicode_ci,
  `institute3` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `institute3_country` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `institute3_state` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `institute3_county` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `institute3_city` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `institute3_address` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `institute3_study_area` text COLLATE utf8_unicode_ci,
  `institute3_certificate_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer1` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer1_position` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer1_resp` text COLLATE utf8_unicode_ci,
  `employer1_pay_upon_leaving` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer1_supervisor` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer1_from_date` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer1_to_date` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer1_leave_reason` text COLLATE utf8_unicode_ci,
  `employer1_country` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer1_state` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer1_county` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer1_city` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer1_zip` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer1_phone` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer1_address` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer2` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer2_position` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer2_resp` text COLLATE utf8_unicode_ci,
  `employer2_pay_upon_leaving` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer2_supervisor` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer2_from_date` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer2_to_date` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer2_leave_reason` text COLLATE utf8_unicode_ci,
  `employer2_country` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer2_state` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer2_county` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer2_city` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer2_zip` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer2_address` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer2_phone` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer3` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer3_position` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer3_resp` text COLLATE utf8_unicode_ci,
  `employer3_pay_upon_leaving` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer3_supervisor` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer3_from_date` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer3_to_date` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer3_leave_reason` text COLLATE utf8_unicode_ci,
  `employer3_country` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer3_state` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer3_county` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer3_city` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer3_zip` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer3_address` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer3_phone` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language_reading` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language_writing` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language_understanding` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language_where_learned` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language1` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language1_reading` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language1_writing` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language1_understanding` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language1_where_learned` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language2` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language2_reading` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language2_writing` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language2_understanding` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language2_where_learned` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language3` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language3_reading` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language3_writing` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language3_understanding` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language3_where_learned` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_start` datetime DEFAULT NULL,
  `desired_salary` int(11) DEFAULT NULL,
  `dcurrencyid` int(11) DEFAULT NULL,
  `can_work` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `available` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unalailable` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total_experience` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `skills` text COLLATE utf8_unicode_ci,
  `driving_license` tinyint(1) DEFAULT NULL,
  `license_no` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `license_country` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference_country` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference_state` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference_county` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference_city` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference_zipcode` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference_address` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference_phone` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference_relation` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference_years` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference1` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference1_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference1_country` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference1_state` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference1_county` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference1_city` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference1_address` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference1_phone` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference1_relation` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference1_years` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference2` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference2_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference2_country` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference2_state` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference2_county` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference2_city` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference2_address` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference2_phone` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference2_relation` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference2_years` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference3` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference3_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference3_country` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference3_state` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference3_county` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference3_city` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference3_address` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference3_phone` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference3_relation` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference3_years` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address1_country` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address1_state` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address1_county` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address1_city` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address1_zipcode` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address1` text COLLATE utf8_unicode_ci,
  `address2_country` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address2_state` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address2_county` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address2_city` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address2_zipcode` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address2` text COLLATE utf8_unicode_ci,
  `reference1_zipcode` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference2_zipcode` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference3_zipcode` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `packageid` int(11) DEFAULT NULL,
  `paymenthistoryid` int(11) DEFAULT NULL,
  `userfield1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `userfield2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `userfield3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `userfield4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `userfield5` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `userfield6` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `userfield7` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `userfield8` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `userfield9` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `userfield10` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `currencyid` int(11) DEFAULT NULL,
  `job_subcategory` int(11) DEFAULT NULL,
  `date_of_birth` datetime DEFAULT NULL,
  `longitude` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitude` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `video` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isgoldresume` tinyint(1) DEFAULT NULL,
  `isfeaturedresume` tinyint(1) DEFAULT NULL,
  `serverstatus` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serverid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `resume_uid` (`uid`),
  KEY `resume_packageid` (`packageid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_resume`
--

LOCK TABLES `jom_js_job_resume` WRITE;
/*!40000 ALTER TABLE `jom_js_job_resume` DISABLE KEYS */;
INSERT INTO `jom_js_job_resume` (`id`, `uid`, `create_date`, `modified_date`, `published`, `hits`, `application_title`, `keywords`, `alias`, `first_name`, `last_name`, `middle_name`, `gender`, `email_address`, `home_phone`, `work_phone`, `cell`, `nationality`, `iamavailable`, `searchable`, `photo`, `job_category`, `jobsalaryrange`, `jobtype`, `heighestfinisheducation`, `address_country`, `address_state`, `address_county`, `address_city`, `address_zipcode`, `address`, `institute`, `institute_country`, `institute_state`, `institute_county`, `institute_city`, `institute_address`, `institute_certificate_name`, `institute_study_area`, `employer`, `employer_position`, `employer_resp`, `employer_pay_upon_leaving`, `employer_supervisor`, `employer_from_date`, `employer_to_date`, `employer_leave_reason`, `employer_country`, `employer_state`, `employer_county`, `employer_city`, `employer_zip`, `employer_phone`, `employer_address`, `filename`, `filetype`, `filesize`, `filecontent`, `field1`, `field2`, `field3`, `status`, `resume`, `institute1`, `institute1_country`, `institute1_state`, `institute1_county`, `institute1_city`, `institute1_address`, `institute1_study_area`, `institute1_certificate_name`, `institute2`, `institute2_country`, `institute2_state`, `institute2_county`, `institute2_city`, `institute2_address`, `institute2_certificate_name`, `institute2_study_area`, `institute3`, `institute3_country`, `institute3_state`, `institute3_county`, `institute3_city`, `institute3_address`, `institute3_study_area`, `institute3_certificate_name`, `employer1`, `employer1_position`, `employer1_resp`, `employer1_pay_upon_leaving`, `employer1_supervisor`, `employer1_from_date`, `employer1_to_date`, `employer1_leave_reason`, `employer1_country`, `employer1_state`, `employer1_county`, `employer1_city`, `employer1_zip`, `employer1_phone`, `employer1_address`, `employer2`, `employer2_position`, `employer2_resp`, `employer2_pay_upon_leaving`, `employer2_supervisor`, `employer2_from_date`, `employer2_to_date`, `employer2_leave_reason`, `employer2_country`, `employer2_state`, `employer2_county`, `employer2_city`, `employer2_zip`, `employer2_address`, `employer2_phone`, `employer3`, `employer3_position`, `employer3_resp`, `employer3_pay_upon_leaving`, `employer3_supervisor`, `employer3_from_date`, `employer3_to_date`, `employer3_leave_reason`, `employer3_country`, `employer3_state`, `employer3_county`, `employer3_city`, `employer3_zip`, `employer3_address`, `employer3_phone`, `language`, `language_reading`, `language_writing`, `language_understanding`, `language_where_learned`, `language1`, `language1_reading`, `language1_writing`, `language1_understanding`, `language1_where_learned`, `language2`, `language2_reading`, `language2_writing`, `language2_understanding`, `language2_where_learned`, `language3`, `language3_reading`, `language3_writing`, `language3_understanding`, `language3_where_learned`, `date_start`, `desired_salary`, `dcurrencyid`, `can_work`, `available`, `unalailable`, `total_experience`, `skills`, `driving_license`, `license_no`, `license_country`, `reference`, `reference_name`, `reference_country`, `reference_state`, `reference_county`, `reference_city`, `reference_zipcode`, `reference_address`, `reference_phone`, `reference_relation`, `reference_years`, `reference1`, `reference1_name`, `reference1_country`, `reference1_state`, `reference1_county`, `reference1_city`, `reference1_address`, `reference1_phone`, `reference1_relation`, `reference1_years`, `reference2`, `reference2_name`, `reference2_country`, `reference2_state`, `reference2_county`, `reference2_city`, `reference2_address`, `reference2_phone`, `reference2_relation`, `reference2_years`, `reference3`, `reference3_name`, `reference3_country`, `reference3_state`, `reference3_county`, `reference3_city`, `reference3_address`, `reference3_phone`, `reference3_relation`, `reference3_years`, `address1_country`, `address1_state`, `address1_county`, `address1_city`, `address1_zipcode`, `address1`, `address2_country`, `address2_state`, `address2_county`, `address2_city`, `address2_zipcode`, `address2`, `reference1_zipcode`, `reference2_zipcode`, `reference3_zipcode`, `packageid`, `paymenthistoryid`, `userfield1`, `userfield2`, `userfield3`, `userfield4`, `userfield5`, `userfield6`, `userfield7`, `userfield8`, `userfield9`, `userfield10`, `currencyid`, `job_subcategory`, `date_of_birth`, `longitude`, `latitude`, `video`, `isgoldresume`, `isfeaturedresume`, `serverstatus`, `serverid`) VALUES (1,705,'2013-10-28 14:53:26',NULL,1,NULL,'Project Manager',NULL,'','Ressie','Fos','S','1','ressfos@gmail.com','44419724','','66769313','QA',1,1,'ressie.jpg',14,15,1,'1','','','','','','','','','','','',NULL,'','','','','','','','','','','','','','','','','','resume.pdf','application/pdf',757219,'',NULL,NULL,NULL,1,'','','','','','',NULL,'','','','','','','',NULL,'','','','','','','',NULL,'','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,'20','',0,'','',NULL,'','','','','','',NULL,'','','',NULL,'','','','','',NULL,'','','',NULL,'','','','','',NULL,'','','',NULL,'','','','','',NULL,'','','','','','','','','','','','','','','','','','',1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,'0000-00-00 00:00:00','','','udLpyNXf1FI',NULL,NULL,NULL,NULL),(2,709,'2013-11-03 03:30:16',NULL,1,NULL,'Customer Service',NULL,'','Faust Edward','Damaso','Sadiasa','2','r_text@yahoo.com','4569871','4564331','09185088681','PH',1,1,'faust.jpg',13,15,1,'1','','','','','','','','','','','',NULL,'','','','','','','','','','','','','','','','','','Resume (1).docx','application/vnd.openxmlformats-officedocument.word',677520,'',NULL,NULL,NULL,1,'','','','','','',NULL,'','','','','','','',NULL,'','','','','','','',NULL,'','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,'','',0,'','',NULL,'','','','','','',NULL,'','','',NULL,'','','','','',NULL,'','','',NULL,'','','','','',NULL,'','','',NULL,'','','','','',NULL,'','','','','','','','','','','','','','','','','','',1,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,'0000-00-00 00:00:00','','','yrFviAVwvvg',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `jom_js_job_resume` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_resumerating`
--

DROP TABLE IF EXISTS `jom_js_job_resumerating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_resumerating` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `jobid` int(11) NOT NULL,
  `resumeid` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `votes` float DEFAULT NULL,
  `meonly` tinyint(1) DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_resumerating`
--

LOCK TABLES `jom_js_job_resumerating` WRITE;
/*!40000 ALTER TABLE `jom_js_job_resumerating` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_js_job_resumerating` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_resumesearches`
--

DROP TABLE IF EXISTS `jom_js_job_resumesearches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_resumesearches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `searchname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `application_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nationality` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` tinyint(2) DEFAULT NULL,
  `iamavailable` tinyint(1) DEFAULT '0',
  `category` int(11) DEFAULT NULL,
  `jobtype` int(11) DEFAULT NULL,
  `salaryrange` int(11) DEFAULT NULL,
  `education` int(11) DEFAULT NULL,
  `experience` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_resumesearches`
--

LOCK TABLES `jom_js_job_resumesearches` WRITE;
/*!40000 ALTER TABLE `jom_js_job_resumesearches` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_js_job_resumesearches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_roles`
--

DROP TABLE IF EXISTS `jom_js_job_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rolefor` tinyint(4) DEFAULT NULL,
  `companies` int(11) DEFAULT NULL,
  `jobs` int(11) DEFAULT NULL,
  `resumes` int(11) DEFAULT NULL,
  `coverletters` int(11) DEFAULT NULL,
  `searchjob` int(11) DEFAULT NULL,
  `searchresume` int(11) DEFAULT NULL,
  `savesearchresume` int(11) DEFAULT NULL,
  `savesearchjob` int(11) DEFAULT NULL,
  `published` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_roles`
--

LOCK TABLES `jom_js_job_roles` WRITE;
/*!40000 ALTER TABLE `jom_js_job_roles` DISABLE KEYS */;
INSERT INTO `jom_js_job_roles` (`id`, `title`, `rolefor`, `companies`, `jobs`, `resumes`, `coverletters`, `searchjob`, `searchresume`, `savesearchresume`, `savesearchjob`, `published`) VALUES (1,'Employer',1,-1,-1,-1,-1,-1,-1,-1,-1,1),(2,'Job Seeker',2,-1,-1,-1,-1,-1,-1,-1,-1,1);
/*!40000 ALTER TABLE `jom_js_job_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_salaryrange`
--

DROP TABLE IF EXISTS `jom_js_job_salaryrange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_salaryrange` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rangevalue` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rangestart` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rangeend` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_salaryrange`
--

LOCK TABLES `jom_js_job_salaryrange` WRITE;
/*!40000 ALTER TABLE `jom_js_job_salaryrange` DISABLE KEYS */;
INSERT INTO `jom_js_job_salaryrange` (`id`, `rangevalue`, `rangestart`, `rangeend`) VALUES (1,NULL,'1000','1500'),(2,NULL,'1500','2000'),(3,NULL,'2000','2500'),(4,NULL,'2500','3000'),(5,NULL,'3000','3500'),(6,NULL,'3500','4000'),(7,NULL,'4000','4500'),(8,NULL,'4500','5000'),(9,NULL,'5000','5500'),(10,NULL,'5500','6000'),(11,NULL,'6000','7000'),(12,NULL,'7000','8000'),(13,NULL,'8000','9000'),(14,NULL,'9000','10000'),(15,NULL,'10000','10000+');
/*!40000 ALTER TABLE `jom_js_job_salaryrange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_salaryrangetypes`
--

DROP TABLE IF EXISTS `jom_js_job_salaryrangetypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_salaryrangetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_salaryrangetypes`
--

LOCK TABLES `jom_js_job_salaryrangetypes` WRITE;
/*!40000 ALTER TABLE `jom_js_job_salaryrangetypes` DISABLE KEYS */;
INSERT INTO `jom_js_job_salaryrangetypes` (`id`, `title`, `status`) VALUES (1,'Per Year',1),(2,'Per Month',1),(3,'Per Week',1),(4,'Per Date',1);
/*!40000 ALTER TABLE `jom_js_job_salaryrangetypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_shifts`
--

DROP TABLE IF EXISTS `jom_js_job_shifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_shifts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `isactive` tinyint(1) DEFAULT '1',
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_shifts`
--

LOCK TABLES `jom_js_job_shifts` WRITE;
/*!40000 ALTER TABLE `jom_js_job_shifts` DISABLE KEYS */;
INSERT INTO `jom_js_job_shifts` (`id`, `title`, `isactive`, `status`) VALUES (1,'Morning',1,0),(2,'Evening',1,0),(3,'8 PM to 4 AM',1,0);
/*!40000 ALTER TABLE `jom_js_job_shifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_shortlistcandidates`
--

DROP TABLE IF EXISTS `jom_js_job_shortlistcandidates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_shortlistcandidates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `jobid` int(11) NOT NULL,
  `jobseekerid` int(11) DEFAULT NULL,
  `cvid` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shortlistcandidates_uid` (`uid`),
  KEY `shortlistcandidates_jobid` (`jobid`),
  KEY `shortlistcandidates_cvid` (`cvid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_shortlistcandidates`
--

LOCK TABLES `jom_js_job_shortlistcandidates` WRITE;
/*!40000 ALTER TABLE `jom_js_job_shortlistcandidates` DISABLE KEYS */;
INSERT INTO `jom_js_job_shortlistcandidates` (`id`, `uid`, `jobid`, `jobseekerid`, `cvid`, `status`, `created`) VALUES (1,707,1,NULL,1,0,'2013-10-30 02:46:56');
/*!40000 ALTER TABLE `jom_js_job_shortlistcandidates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_states`
--

DROP TABLE IF EXISTS `jom_js_job_states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_states` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `countrycode` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'US',
  PRIMARY KEY (`id`),
  KEY `code` (`code`),
  KEY `enabled` (`enabled`),
  KEY `countrycode` (`countrycode`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_states`
--

LOCK TABLES `jom_js_job_states` WRITE;
/*!40000 ALTER TABLE `jom_js_job_states` DISABLE KEYS */;
INSERT INTO `jom_js_job_states` (`id`, `code`, `name`, `enabled`, `countrycode`) VALUES (1,'Capital','Capital','Y','PK'),(2,'Punjab','Punjab','Y','PK'),(3,'Sind','Sind','Y','PK'),(4,'NWFP','NWFP','Y','PK'),(5,'Balochstan','Balochistan','Y','PK'),(6,'AJK','Azad Jammu Kashmir','Y','PK');
/*!40000 ALTER TABLE `jom_js_job_states` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_subcategories`
--

DROP TABLE IF EXISTS `jom_js_job_subcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_subcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categoryid` int(11) NOT NULL,
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(225) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `serverid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_category_id` (`categoryid`)
) ENGINE=MyISAM AUTO_INCREMENT=184 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_subcategories`
--

LOCK TABLES `jom_js_job_subcategories` WRITE;
/*!40000 ALTER TABLE `jom_js_job_subcategories` DISABLE KEYS */;
INSERT INTO `jom_js_job_subcategories` (`id`, `categoryid`, `title`, `alias`, `status`, `serverid`) VALUES (1,1,'Cast Accounting ','cast-accounting-',1,NULL),(2,1,'Controllership & Accounting Managment','controllership---accounting-managment',1,NULL),(3,1,'Payroll ','payroll-',1,NULL),(4,1,'Corporate Finance','corporate-finance',1,NULL),(5,2,'Administrative Division','administrative-division',1,NULL),(6,2,'Autonomous Territories','autonomous-territories',1,NULL),(7,2,'Administrative County','administrative-county',1,NULL),(8,2,'Administrative Communes','administrative-communes',1,NULL),(9,3,'Finance Advertising ','finance-advertising-',1,NULL),(10,3,'Advertising-Tourism','advertising-tourism',1,NULL),(11,3,'Advertising Social Net','advertising-social-net',1,NULL),(12,3,'Distributor Marketing','distributor-marketing',1,NULL),(13,3,'Facebook Advertising','facebook-advertising',1,NULL),(14,4,'Quality Engineer ','quality-engineer-',1,NULL),(15,4,'Office Assistant ','office-assistant-',1,NULL),(16,4,'Air Host/hostess','air-host-hostess',1,NULL),(17,4,'Ticketing/reservation','ticketing-reservation',1,NULL),(18,5,'Architectural Drafting','architectural-drafting',1,NULL),(19,5,'Enterprize Architecture','enterprize-architecture',1,NULL),(20,5,'Architecture Frameworks','architecture-frameworks',1,NULL),(21,6,'Automotive Design','automotive-design',1,NULL),(22,6,'Autmotive Paints','autmotive-paints',1,NULL),(23,6,'Automotive Equipment/Parts','automotive-equipment-parts',1,NULL),(24,6,'Automotive Search Engine','automotive-search-engine',1,NULL),(25,7,'Private Banking','private-banking',1,NULL),(26,7,'Stock Brocker','stock-brocker',1,NULL),(27,7,'Fractional-reserve Banking','fractional-reserve-banking',1,NULL),(28,7,'Mobile Banking','mobile-banking',1,NULL),(29,8,'Plant Biotechnology','plant-biotechnology',1,NULL),(30,8,'Animal Biotechnology','animal-biotechnology',1,NULL),(31,8,'Biotechnology & Medicine','biotechnology---medicine',1,NULL),(32,8,'Biotechnology & Society','biotechnology---society',1,NULL),(33,8,'Industrail & Microbial Biotechnonogy','industrail---microbial-biotechnonogy',1,NULL),(34,9,'Construction (Design & Managment)','construction-(design---managment)',1,NULL),(35,9,'Construction Engineering ','construction-engineering-',1,NULL),(36,9,'Composite Construction','composite-construction',1,NULL),(37,10,'Civil Engineering','civil-engineering',1,NULL),(38,10,'Software Engineering','software-engineering',1,NULL),(39,10,'Nuclear Engineering','nuclear-engineering',1,NULL),(40,10,'Ocean Engingeering','ocean-engingeering',1,NULL),(41,10,'Transpotation Engineering','transpotation-engineering',1,NULL),(42,11,'Security Cleared Jobs','security-cleared-jobs',1,NULL),(43,11,'Security Cleared IT Jobs','security-cleared-it-jobs',1,NULL),(44,11,'Confidential & Secret Security Clearance Job','confidential---secret-security-clearance-job',1,NULL),(45,12,'Verbal','verbal',1,NULL),(46,12,'E-mail','e-mail',1,NULL),(47,12,'Non-verbal','non-verbal',1,NULL),(48,13,'Computer Consulting Services ','computer-consulting-services-',1,NULL),(49,13,'Computer Installations Services','computer-installations-services',1,NULL),(50,13,'Software Vendors','software-vendors',1,NULL),(51,14,'Renovaiton','renovaiton',1,NULL),(52,14,'Addition','addition',1,NULL),(53,14,'New Construction','new-construction',1,NULL),(54,15,'Organization Development','organization-development',1,NULL),(55,15,'Construction Management','construction-management',1,NULL),(56,15,'Managment Consulting ','managment-consulting-',1,NULL),(57,16,'High Touch Customer Service ','high-touch-customer-service-',1,NULL),(58,16,'Low Touch Customer Service','low-touch-customer-service',1,NULL),(59,16,'Bad Touch Customer Service','bad-touch-customer-service',1,NULL),(60,17,'By Using legal services for the poor','by-using-legal-services-for-the-poor',1,NULL),(61,17,'By Using Retained Counsel','by-using-retained-counsel',1,NULL),(62,17,'By Self-representation','by-self-representation',1,NULL),(63,18,'Project Subtype Design','project-subtype-design',1,NULL),(64,18,'Graphic Design','graphic-design',1,NULL),(65,18,'Interior Desing','interior-desing',1,NULL),(66,19,'IT or Engineering Education','it-or-engineering-education',1,NULL),(67,19,'Commerce & Managment','commerce---managment',1,NULL),(68,19,'Medical Education','medical-education',1,NULL),(69,20,'Power Engineering','power-engineering',1,NULL),(70,20,'Instrumentation','instrumentation',1,NULL),(71,20,'Telecommunication','telecommunication',1,NULL),(72,20,'Signal Processing','signal-processing',1,NULL),(73,21,'Electromagnetics','electromagnetics',1,NULL),(74,21,'Network Analysis','network-analysis',1,NULL),(75,21,'Control Systems','control-systems',1,NULL),(76,22,'Thermal Energy','thermal-energy',1,NULL),(77,22,'Chemical Energy','chemical-energy',1,NULL),(78,22,'Electrical Energy','electrical-energy',1,NULL),(79,22,'Nuclear Energy','nuclear-energy',1,NULL),(80,23,'Software Engineering ','software-engineering-',1,NULL),(81,23,'Civil Engineering ','civil-engineering-',1,NULL),(82,23,'Nuclear Engineering','nuclear-engineering',1,NULL),(83,24,'Nuclear Safety','nuclear-safety',1,NULL),(84,24,'Agriculture Safety','agriculture-safety',1,NULL),(85,24,'Occupational Health Safety','occupational-health-safety',1,NULL),(86,25,'Unique Fundraisers','unique-fundraisers',1,NULL),(87,25,'Sports Fundraiserse','sports-fundraiserse',1,NULL),(88,25,'Fundraisers','fundraisers',1,NULL),(89,26,'Staying Informed','staying-informed',1,NULL),(90,26,'Medical Edcuation ','medical-edcuation-',1,NULL),(91,26,'Managing a partucular disease','managing-a-partucular-disease',1,NULL),(92,27,'Customs & Border Protection','customs---border-protection',1,NULL),(93,27,'Federal Law & Enforcement','federal-law---enforcement',1,NULL),(94,27,'Nation Protection','nation-protection',1,NULL),(95,28,'Benefits Administrators','benefits-administrators',1,NULL),(96,28,'Executive Compensation Analysts','executive-compensation-analysts',1,NULL),(97,28,'Managment Analysts','managment-analysts',1,NULL),(98,29,'Health Insurance ','health-insurance-',1,NULL),(99,29,'Life Insurance','life-insurance',1,NULL),(100,29,'Vehicle Insurance','vehicle-insurance',1,NULL),(101,30,'Artificial Intelligence ','artificial-intelligence-',1,NULL),(102,30,'Predictive Analytics ','predictive-analytics-',1,NULL),(103,30,'Science & Technology','science---technology',1,NULL),(104,31,'Work Experience internship','work-experience-internship',1,NULL),(105,31,'Research internship','research-internship',1,NULL),(106,31,'Sales & Marketing Intern','sales---marketing-intern',1,NULL),(107,32,'According To Law','according-to-law',1,NULL),(108,32,'Defined Rule','defined-rule',1,NULL),(109,33,'Shipping ','shipping-',1,NULL),(110,33,'Transpotation Managment','transpotation-managment',1,NULL),(111,33,'Third-party Logistics Provider','third-party-logistics-provider',1,NULL),(112,34,'General Maintenance','general-maintenance',1,NULL),(113,34,'Automobile Maintenance ','automobile-maintenance-',1,NULL),(114,34,'Equipment Manitenance','equipment-manitenance',1,NULL),(115,35,'Project Managment','project-managment',1,NULL),(116,35,'Planning ','planning-',1,NULL),(117,35,'Risk Managment','risk-managment',1,NULL),(118,36,'Quality Assurance ','quality-assurance-',1,NULL),(119,36,'Product Manager','product-manager',1,NULL),(120,36,'Planning Supervisor ','planning-supervisor-',1,NULL),(121,37,'Networking ','networking-',1,NULL),(122,37,'Direct Mail Marketing','direct-mail-marketing',1,NULL),(123,37,'Media Advertising ','media-advertising-',1,NULL),(124,38,'Supply Chain ','supply-chain-',1,NULL),(125,38,'Hazardous Materials Management','hazardous-materials-management',1,NULL),(126,38,'Materials Inventory Managment','materials-inventory-managment',1,NULL),(127,39,'Aerospace ','aerospace-',1,NULL),(128,39,'Automotive ','automotive-',1,NULL),(129,39,'Biomedical','biomedical',1,NULL),(130,39,'Mechanical','mechanical',1,NULL),(131,39,'Naval','naval',1,NULL),(132,40,'Conventional Mortgage','conventional-mortgage',1,NULL),(133,40,'Adjustable Rate Mortgage','adjustable-rate-mortgage',1,NULL),(134,40,'Commercial Mortgages','commercial-mortgages',1,NULL),(135,41,'Economic Security','economic-security',1,NULL),(136,41,'Environmental Security','environmental-security',1,NULL),(137,41,'Military Security','military-security',1,NULL),(138,42,'Freelance Portfolios','freelance-portfolios',1,NULL),(139,42,'Freelance Freedom ','freelance-freedom-',1,NULL),(140,42,'Freelance Jobs','freelance-jobs',1,NULL),(141,43,'Offset Lithographp ','offset-lithographp-',1,NULL),(142,43,'Themography Raised Printing','themography-raised-printing',1,NULL),(143,43,'Digital Printing ','digital-printing-',1,NULL),(144,44,'idea Generation','idea-generation',1,NULL),(145,44,'Need Based Generation','need-based-generation',1,NULL),(146,44,'Design Solution','design-solution',1,NULL),(147,45,'Media Relations','media-relations',1,NULL),(148,45,'Media Tours ','media-tours-',1,NULL),(149,45,'Newsletters ','newsletters-',1,NULL),(150,46,'Automised Security','automised-security',1,NULL),(151,46,'Environmental & Social Safety','environmental---social-safety',1,NULL),(152,47,'Basic Research','basic-research',1,NULL),(153,47,'Applied Research','applied-research',1,NULL),(154,47,'Methods & Appraches ','methods---appraches-',1,NULL),(155,48,'Department Stores','department-stores',1,NULL),(156,48,'Discount Stores','discount-stores',1,NULL),(157,48,'Supermarkets','supermarkets',1,NULL),(158,49,'Sales Contracts ','sales-contracts-',1,NULL),(159,49,'Sales Forecasts ','sales-forecasts-',1,NULL),(160,49,'Sales Managment','sales-managment',1,NULL),(161,50,'Scientific Managment','scientific-managment',1,NULL),(162,50,'Scientific Research','scientific-research',1,NULL),(163,50,'Scientific invenctions ','scientific-invenctions-',1,NULL),(164,51,'Shppping/Distrubution Companies','shppping-distrubution-companies',1,NULL),(165,51,'Services ','services-',1,NULL),(166,51,'Channels & Softwares','channels---softwares',1,NULL),(167,52,'Medical Technicians ','medical-technicians-',1,NULL),(168,52,'Electrical Technicians','electrical-technicians',1,NULL),(169,52,'Accounting Technicians ','accounting-technicians-',1,NULL),(170,53,'Construction Trade ','construction-trade-',1,NULL),(171,53,'Stock Trade','stock-trade',1,NULL),(172,53,'skilled Trade ','skilled-trade-',1,NULL),(173,53,'Option Trade ','option-trade-',1,NULL),(174,54,'Transpotation System','transpotation-system',1,NULL),(175,54,'Human-Powered ','human-powered-',1,NULL),(176,54,'Airline,Train,bus,car','airline,train,bus,car',1,NULL),(177,55,'Subway & Civil','subway---civil',1,NULL),(178,55,'Traffic Highway Transpotation','traffic-highway-transpotation',1,NULL),(179,56,'Small Business ','small-business-',1,NULL),(180,56,'E-Commerce Sites ','e-commerce-sites-',1,NULL),(181,56,'Portals ','portals-',1,NULL),(182,56,'Search Engines ','search-engines-',1,NULL),(183,56,'Personal,Commercial,Govt','personal,commercial,govt',1,NULL);
/*!40000 ALTER TABLE `jom_js_job_subcategories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_userfield_data`
--

DROP TABLE IF EXISTS `jom_js_job_userfield_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_userfield_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `referenceid` int(11) NOT NULL,
  `field` int(10) unsigned DEFAULT NULL,
  `data` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_userfield_data`
--

LOCK TABLES `jom_js_job_userfield_data` WRITE;
/*!40000 ALTER TABLE `jom_js_job_userfield_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_js_job_userfield_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_userfields`
--

DROP TABLE IF EXISTS `jom_js_job_userfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_userfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` mediumtext COLLATE utf8_unicode_ci,
  `type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `maxlength` int(11) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `required` tinyint(4) DEFAULT '0',
  `ordering` int(11) DEFAULT NULL,
  `cols` int(11) DEFAULT NULL,
  `rows` int(11) DEFAULT NULL,
  `value` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `default` int(11) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `fieldfor` tinyint(2) NOT NULL DEFAULT '0',
  `readonly` tinyint(1) NOT NULL DEFAULT '0',
  `calculated` tinyint(1) NOT NULL DEFAULT '0',
  `sys` tinyint(4) NOT NULL DEFAULT '0',
  `params` mediumtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_userfields`
--

LOCK TABLES `jom_js_job_userfields` WRITE;
/*!40000 ALTER TABLE `jom_js_job_userfields` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_js_job_userfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_userfieldvalues`
--

DROP TABLE IF EXISTS `jom_js_job_userfieldvalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_userfieldvalues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field` int(11) NOT NULL DEFAULT '0',
  `fieldtitle` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fieldvalue` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `sys` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_userfieldvalues`
--

LOCK TABLES `jom_js_job_userfieldvalues` WRITE;
/*!40000 ALTER TABLE `jom_js_job_userfieldvalues` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_js_job_userfieldvalues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_userroles`
--

DROP TABLE IF EXISTS `jom_js_job_userroles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_userroles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `role` int(11) NOT NULL,
  `dated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_userroles`
--

LOCK TABLES `jom_js_job_userroles` WRITE;
/*!40000 ALTER TABLE `jom_js_job_userroles` DISABLE KEYS */;
INSERT INTO `jom_js_job_userroles` (`id`, `uid`, `role`, `dated`) VALUES (1,705,2,NULL),(2,706,2,NULL),(3,707,1,NULL),(4,335,1,NULL),(5,708,1,NULL),(6,709,2,NULL),(7,711,2,NULL),(8,712,2,NULL),(9,713,2,NULL),(10,714,2,NULL),(11,715,1,NULL),(12,716,2,'2013-12-04 00:21:51'),(13,718,1,'2013-12-04 19:01:12'),(14,720,1,NULL);
/*!40000 ALTER TABLE `jom_js_job_userroles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_js_job_zips`
--

DROP TABLE IF EXISTS `jom_js_job_zips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_js_job_zips` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `code` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `countrycode` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'US',
  `statecode` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `countycode` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `citycode` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitude` float DEFAULT NULL,
  `longitude` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `code` (`code`),
  KEY `countrystatecountycity` (`countrycode`,`statecode`,`countycode`,`citycode`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_js_job_zips`
--

LOCK TABLES `jom_js_job_zips` WRITE;
/*!40000 ALTER TABLE `jom_js_job_zips` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_js_job_zips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_kunena_aliases`
--

DROP TABLE IF EXISTS `jom_kunena_aliases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_kunena_aliases` (
  `alias` varchar(255) NOT NULL,
  `type` varchar(10) NOT NULL,
  `item` varchar(32) NOT NULL,
  `state` tinyint(4) NOT NULL DEFAULT '0',
  UNIQUE KEY `alias` (`alias`),
  KEY `state` (`state`),
  KEY `item` (`item`),
  KEY `type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_kunena_aliases`
--

LOCK TABLES `jom_kunena_aliases` WRITE;
/*!40000 ALTER TABLE `jom_kunena_aliases` DISABLE KEYS */;
INSERT INTO `jom_kunena_aliases` (`alias`, `type`, `item`, `state`) VALUES ('announcement','view','announcement',1),('category','view','category',1),('common','view','common',1),('credits','view','credits',1),('home','view','home',1),('misc','view','misc',1),('search','view','search',1),('statistics','view','statistics',1),('topic','view','topic',1),('topics','view','topics',1),('user','view','user',1),('category/create','layout','category.create',1),('create','layout','category.create',0),('category/default','layout','category.default',1),('default','layout','category.default',0),('category/edit','layout','category.edit',1),('edit','layout','category.edit',0),('category/manage','layout','category.manage',1),('manage','layout','category.manage',0),('category/moderate','layout','category.moderate',1),('moderate','layout','category.moderate',0),('category/user','layout','category.user',1),('main-forum','catid','1',0),('ofw-forum','catid','4',0),('suggestion-box','catid','3',1);
/*!40000 ALTER TABLE `jom_kunena_aliases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_kunena_announcement`
--

DROP TABLE IF EXISTS `jom_kunena_announcement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_kunena_announcement` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `title` tinytext NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  `sdescription` text NOT NULL,
  `description` text NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `ordering` tinyint(4) NOT NULL DEFAULT '0',
  `showdate` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_kunena_announcement`
--

LOCK TABLES `jom_kunena_announcement` WRITE;
/*!40000 ALTER TABLE `jom_kunena_announcement` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_kunena_announcement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_kunena_attachments`
--

DROP TABLE IF EXISTS `jom_kunena_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_kunena_attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mesid` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `hash` char(32) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `folder` varchar(255) NOT NULL,
  `filetype` varchar(20) NOT NULL,
  `filename` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mesid` (`mesid`),
  KEY `userid` (`userid`),
  KEY `hash` (`hash`),
  KEY `filename` (`filename`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_kunena_attachments`
--

LOCK TABLES `jom_kunena_attachments` WRITE;
/*!40000 ALTER TABLE `jom_kunena_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_kunena_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_kunena_categories`
--

DROP TABLE IF EXISTS `jom_kunena_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_kunena_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT '0',
  `name` tinytext,
  `alias` varchar(255) NOT NULL,
  `icon_id` tinyint(4) NOT NULL DEFAULT '0',
  `locked` tinyint(4) NOT NULL DEFAULT '0',
  `accesstype` varchar(20) NOT NULL DEFAULT 'joomla.level',
  `access` int(11) NOT NULL DEFAULT '0',
  `pub_access` int(11) NOT NULL DEFAULT '1',
  `pub_recurse` tinyint(4) DEFAULT '1',
  `admin_access` int(11) NOT NULL DEFAULT '0',
  `admin_recurse` tinyint(4) DEFAULT '1',
  `ordering` smallint(6) NOT NULL DEFAULT '0',
  `published` tinyint(4) NOT NULL DEFAULT '0',
  `channels` text,
  `checked_out` tinyint(4) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `review` tinyint(4) NOT NULL DEFAULT '0',
  `allow_anonymous` tinyint(4) NOT NULL DEFAULT '0',
  `post_anonymous` tinyint(4) NOT NULL DEFAULT '0',
  `hits` int(11) NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `headerdesc` text NOT NULL,
  `class_sfx` varchar(20) NOT NULL,
  `allow_polls` tinyint(4) NOT NULL DEFAULT '0',
  `topic_ordering` varchar(16) NOT NULL DEFAULT 'lastpost',
  `numTopics` mediumint(8) NOT NULL DEFAULT '0',
  `numPosts` mediumint(8) NOT NULL DEFAULT '0',
  `last_topic_id` int(11) NOT NULL DEFAULT '0',
  `last_post_id` int(11) NOT NULL DEFAULT '0',
  `last_post_time` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `category_access` (`accesstype`,`access`),
  KEY `published_pubaccess_id` (`published`,`pub_access`,`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_kunena_categories`
--

LOCK TABLES `jom_kunena_categories` WRITE;
/*!40000 ALTER TABLE `jom_kunena_categories` DISABLE KEYS */;
INSERT INTO `jom_kunena_categories` (`id`, `parent_id`, `name`, `alias`, `icon_id`, `locked`, `accesstype`, `access`, `pub_access`, `pub_recurse`, `admin_access`, `admin_recurse`, `ordering`, `published`, `channels`, `checked_out`, `checked_out_time`, `review`, `allow_anonymous`, `post_anonymous`, `hits`, `description`, `headerdesc`, `class_sfx`, `allow_polls`, `topic_ordering`, `numTopics`, `numPosts`, `last_topic_id`, `last_post_id`, `last_post_time`, `params`) VALUES (1,0,'Main Forum','main-forum',0,0,'joomla.group',1,1,1,0,1,1,1,NULL,0,'0000-00-00 00:00:00',0,0,0,0,'','','',0,'lastpost',0,0,0,0,0,'{}'),(4,1,'OFW Forum','ofw-forum',0,0,'joomla.level',1,1,1,8,1,2,1,NULL,0,'0000-00-00 00:00:00',0,0,0,0,'','','',0,'lastpost',0,0,0,0,0,'{}'),(3,1,'Suggestion Box','suggestion-box',0,0,'joomla.group',0,1,1,0,1,1,1,NULL,0,'0000-00-00 00:00:00',0,0,0,0,'Have some feedback and input to share? \n Don\'t be shy and drop us a note. We want to hear from you and strive to make our site better and more user friendly for our guests and members a like.','This is the optional category header for the Suggestion Box.','',1,'lastpost',0,0,0,0,0,'');
/*!40000 ALTER TABLE `jom_kunena_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_kunena_configuration`
--

DROP TABLE IF EXISTS `jom_kunena_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_kunena_configuration` (
  `id` int(11) NOT NULL DEFAULT '0',
  `params` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_kunena_configuration`
--

LOCK TABLES `jom_kunena_configuration` WRITE;
/*!40000 ALTER TABLE `jom_kunena_configuration` DISABLE KEYS */;
INSERT INTO `jom_kunena_configuration` (`id`, `params`) VALUES (1,'{\"board_title\":\"POEC Community Forum\",\"email\":\"info@poec.org\",\"board_offline\":\"0\",\"offline_message\":\"<h2>The Forum is currently offline for maintenance.<\\/h2>\\r\\n<div>Check back soon!<\\/div>\",\"enablerss\":\"1\",\"threads_per_page\":\"20\",\"messages_per_page\":\"6\",\"messages_per_page_search\":\"15\",\"showhistory\":\"1\",\"historylimit\":\"6\",\"shownew\":\"1\",\"disemoticons\":\"0\",\"template\":\"blue_eagle\",\"showannouncement\":\"1\",\"avataroncat\":\"0\",\"catimagepath\":\"category_images\",\"showchildcaticon\":\"1\",\"rtewidth\":\"450\",\"rteheight\":\"300\",\"enableforumjump\":\"1\",\"reportmsg\":\"1\",\"username\":\"1\",\"askemail\":\"0\",\"showemail\":\"0\",\"showuserstats\":\"0\",\"showkarma\":\"1\",\"useredit\":\"1\",\"useredittime\":\"0\",\"useredittimegrace\":\"600\",\"editmarkup\":\"1\",\"allowsubscriptions\":\"1\",\"subscriptionschecked\":\"1\",\"allowfavorites\":\"1\",\"maxsubject\":\"50\",\"maxsig\":\"300\",\"regonly\":\"0\",\"pubwrite\":\"0\",\"floodprotection\":\"0\",\"mailmod\":\"0\",\"mailadmin\":\"0\",\"captcha\":\"0\",\"mailfull\":\"1\",\"allowavatarupload\":\"1\",\"allowavatargallery\":\"1\",\"avatarquality\":\"75\",\"avatarsize\":\"2048\",\"imageheight\":\"800\",\"imagewidth\":\"800\",\"imagesize\":\"150\",\"filetypes\":\"txt,rtf,pdf,zip,tar.gz,tgz,tar.bz2,doc,docx,xls,xlsx,ppt,pptx\",\"filesize\":\"10000\",\"showranking\":\"1\",\"rankimages\":\"1\",\"userlist_rows\":\"30\",\"userlist_online\":\"1\",\"userlist_avatar\":\"1\",\"userlist_name\":\"1\",\"userlist_posts\":\"1\",\"userlist_karma\":\"1\",\"userlist_email\":\"0\",\"userlist_joindate\":\"1\",\"userlist_lastvisitdate\":\"1\",\"userlist_userhits\":\"1\",\"latestcategory\":\"\",\"showstats\":\"1\",\"showwhoisonline\":\"1\",\"showgenstats\":\"1\",\"showpopuserstats\":\"1\",\"popusercount\":\"5\",\"showpopsubjectstats\":\"1\",\"popsubjectcount\":\"5\",\"usernamechange\":\"0\",\"showspoilertag\":\"1\",\"showvideotag\":\"1\",\"showebaytag\":\"1\",\"trimlongurls\":\"1\",\"trimlongurlsfront\":\"40\",\"trimlongurlsback\":\"20\",\"autoembedyoutube\":\"1\",\"autoembedebay\":\"1\",\"ebaylanguagecode\":\"en-us\",\"sessiontimeout\":\"1800\",\"highlightcode\":\"0\",\"rss_type\":\"topic\",\"rss_timelimit\":\"month\",\"rss_limit\":\"100\",\"rss_included_categories\":\"\",\"rss_excluded_categories\":\"\",\"rss_specification\":\"rss2.0\",\"rss_allow_html\":\"1\",\"rss_author_format\":\"name\",\"rss_author_in_title\":\"1\",\"rss_word_count\":\"0\",\"rss_old_titles\":\"1\",\"rss_cache\":\"900\",\"defaultpage\":\"recent\",\"default_sort\":\"asc\",\"sef\":\"1\",\"showimgforguest\":\"1\",\"showfileforguest\":\"1\",\"pollnboptions\":\"4\",\"pollallowvoteone\":\"1\",\"pollenabled\":\"1\",\"poppollscount\":\"5\",\"showpoppollstats\":\"1\",\"polltimebtvotes\":\"00:15:00\",\"pollnbvotesbyuser\":\"100\",\"pollresultsuserslist\":\"1\",\"maxpersotext\":\"50\",\"ordering_system\":\"mesid\",\"post_dateformat\":\"ago\",\"post_dateformat_hover\":\"datetime\",\"hide_ip\":\"1\",\"imagetypes\":\"jpg,jpeg,gif,png\",\"checkmimetypes\":\"1\",\"imagemimetypes\":\"image\\/jpeg,image\\/jpg,image\\/gif,image\\/png\",\"imagequality\":\"50\",\"thumbheight\":\"32\",\"thumbwidth\":\"32\",\"hideuserprofileinfo\":\"put_empty\",\"boxghostmessage\":\"0\",\"userdeletetmessage\":\"0\",\"latestcategory_in\":\"1\",\"topicicons\":\"1\",\"debug\":\"0\",\"catsautosubscribed\":0,\"showbannedreason\":\"0\",\"version_check\":\"1\",\"showthankyou\":\"1\",\"showpopthankyoustats\":\"1\",\"popthankscount\":\"5\",\"mod_see_deleted\":\"0\",\"bbcode_img_secure\":\"text\",\"listcat_show_moderators\":\"1\",\"lightbox\":\"1\",\"show_list_time\":\"720\",\"show_session_type\":\"0\",\"show_session_starttime\":\"0\",\"userlist_allowed\":\"1\",\"userlist_count_users\":\"1\",\"enable_threaded_layouts\":\"0\",\"category_subscriptions\":\"post\",\"topic_subscriptions\":\"every\",\"pubprofile\":\"0\",\"thankyou_max\":\"10\",\"email_recipient_count\":\"0\",\"email_recipient_privacy\":\"bcc\",\"email_visible_address\":\"\",\"captcha_post_limit\":\"0\",\"recaptcha_publickey\":\"\",\"recaptcha_privatekey\":\"\",\"recaptcha_theme\":\"white\",\"keywords\":0,\"userkeywords\":0,\"image_upload\":\"registered\",\"file_upload\":\"registered\",\"topic_layout\":\"flat\",\"time_to_create_page\":\"1\",\"show_imgfiles_manage_profile\":\"1\",\"hold_newusers_posts\":\"0\",\"hold_guest_posts\":\"0\",\"attachment_limit\":\"8\",\"pickup_category\":\"0\",\"article_display\":\"intro\",\"send_emails\":\"1\",\"stopforumspam_key\":\"\",\"fallback_english\":\"1\",\"cache\":\"1\",\"cache_time\":\"60\",\"ebay_affiliate_id\":\"5337089937\",\"iptracking\":\"1\",\"rss_feedburner_url\":\"\",\"autolink\":\"1\",\"access_component\":\"1\",\"plugins\":{\"plg_system_kunena\":{}}}');
/*!40000 ALTER TABLE `jom_kunena_configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_kunena_keywords`
--

DROP TABLE IF EXISTS `jom_kunena_keywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_kunena_keywords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL,
  `public_count` int(11) NOT NULL,
  `total_count` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `public_count` (`public_count`),
  KEY `total_count` (`total_count`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_kunena_keywords`
--

LOCK TABLES `jom_kunena_keywords` WRITE;
/*!40000 ALTER TABLE `jom_kunena_keywords` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_kunena_keywords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_kunena_keywords_map`
--

DROP TABLE IF EXISTS `jom_kunena_keywords_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_kunena_keywords_map` (
  `keyword_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  UNIQUE KEY `keyword_user_topic` (`keyword_id`,`user_id`,`topic_id`),
  KEY `user_id` (`user_id`),
  KEY `topic_user` (`topic_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_kunena_keywords_map`
--

LOCK TABLES `jom_kunena_keywords_map` WRITE;
/*!40000 ALTER TABLE `jom_kunena_keywords_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_kunena_keywords_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_kunena_messages`
--

DROP TABLE IF EXISTS `jom_kunena_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_kunena_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) DEFAULT '0',
  `thread` int(11) DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `name` tinytext,
  `userid` int(11) NOT NULL DEFAULT '0',
  `email` tinytext,
  `subject` tinytext,
  `time` int(11) NOT NULL DEFAULT '0',
  `ip` varchar(128) DEFAULT NULL,
  `topic_emoticon` int(11) NOT NULL DEFAULT '0',
  `locked` tinyint(4) NOT NULL DEFAULT '0',
  `hold` tinyint(4) NOT NULL DEFAULT '0',
  `ordering` int(11) DEFAULT '0',
  `hits` int(11) DEFAULT '0',
  `moved` tinyint(4) DEFAULT '0',
  `modified_by` int(7) DEFAULT NULL,
  `modified_time` int(11) DEFAULT NULL,
  `modified_reason` tinytext,
  PRIMARY KEY (`id`),
  KEY `thread` (`thread`),
  KEY `ip` (`ip`),
  KEY `userid` (`userid`),
  KEY `time` (`time`),
  KEY `locked` (`locked`),
  KEY `hold_time` (`hold`,`time`),
  KEY `parent_hits` (`parent`,`hits`),
  KEY `catid_parent` (`catid`,`parent`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_kunena_messages`
--

LOCK TABLES `jom_kunena_messages` WRITE;
/*!40000 ALTER TABLE `jom_kunena_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_kunena_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_kunena_messages_text`
--

DROP TABLE IF EXISTS `jom_kunena_messages_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_kunena_messages_text` (
  `mesid` int(11) NOT NULL DEFAULT '0',
  `message` text NOT NULL,
  PRIMARY KEY (`mesid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_kunena_messages_text`
--

LOCK TABLES `jom_kunena_messages_text` WRITE;
/*!40000 ALTER TABLE `jom_kunena_messages_text` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_kunena_messages_text` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_kunena_polls`
--

DROP TABLE IF EXISTS `jom_kunena_polls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_kunena_polls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `threadid` int(11) NOT NULL,
  `polltimetolive` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `threadid` (`threadid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_kunena_polls`
--

LOCK TABLES `jom_kunena_polls` WRITE;
/*!40000 ALTER TABLE `jom_kunena_polls` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_kunena_polls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_kunena_polls_options`
--

DROP TABLE IF EXISTS `jom_kunena_polls_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_kunena_polls_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pollid` int(11) DEFAULT NULL,
  `text` varchar(100) DEFAULT NULL,
  `votes` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pollid` (`pollid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_kunena_polls_options`
--

LOCK TABLES `jom_kunena_polls_options` WRITE;
/*!40000 ALTER TABLE `jom_kunena_polls_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_kunena_polls_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_kunena_polls_users`
--

DROP TABLE IF EXISTS `jom_kunena_polls_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_kunena_polls_users` (
  `pollid` int(11) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `votes` int(11) DEFAULT NULL,
  `lasttime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastvote` int(11) DEFAULT NULL,
  UNIQUE KEY `pollid` (`pollid`,`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_kunena_polls_users`
--

LOCK TABLES `jom_kunena_polls_users` WRITE;
/*!40000 ALTER TABLE `jom_kunena_polls_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_kunena_polls_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_kunena_ranks`
--

DROP TABLE IF EXISTS `jom_kunena_ranks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_kunena_ranks` (
  `rank_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `rank_title` varchar(255) NOT NULL DEFAULT '',
  `rank_min` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `rank_special` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `rank_image` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`rank_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_kunena_ranks`
--

LOCK TABLES `jom_kunena_ranks` WRITE;
/*!40000 ALTER TABLE `jom_kunena_ranks` DISABLE KEYS */;
INSERT INTO `jom_kunena_ranks` (`rank_id`, `rank_title`, `rank_min`, `rank_special`, `rank_image`) VALUES (1,'New Member',0,0,'rank1.gif'),(2,'Junior Member',20,0,'rank2.gif'),(3,'Senior Member',40,0,'rank3.gif'),(4,'Premium Member',80,0,'rank4.gif'),(5,'Elite Member',160,0,'rank5.gif'),(6,'Platinum Member',320,0,'rank6.gif'),(7,'Administrator',0,1,'rankadmin.gif'),(8,'Moderator',0,1,'rankmod.gif'),(9,'Spammer',0,1,'rankspammer.gif'),(10,'Banned',0,1,'rankbanned.gif');
/*!40000 ALTER TABLE `jom_kunena_ranks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_kunena_sessions`
--

DROP TABLE IF EXISTS `jom_kunena_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_kunena_sessions` (
  `userid` int(11) NOT NULL DEFAULT '0',
  `allowed` text,
  `lasttime` int(11) NOT NULL DEFAULT '0',
  `readtopics` text,
  `currvisit` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`userid`),
  KEY `currvisit` (`currvisit`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_kunena_sessions`
--

LOCK TABLES `jom_kunena_sessions` WRITE;
/*!40000 ALTER TABLE `jom_kunena_sessions` DISABLE KEYS */;
INSERT INTO `jom_kunena_sessions` (`userid`, `allowed`, `lasttime`, `readtopics`, `currvisit`) VALUES (705,'na',1385376389,'0',1386587699),(707,'na',1385382184,'0',1386591784);
/*!40000 ALTER TABLE `jom_kunena_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_kunena_smileys`
--

DROP TABLE IF EXISTS `jom_kunena_smileys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_kunena_smileys` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `code` varchar(12) NOT NULL DEFAULT '',
  `location` varchar(50) NOT NULL DEFAULT '',
  `greylocation` varchar(60) NOT NULL DEFAULT '',
  `emoticonbar` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=67 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_kunena_smileys`
--

LOCK TABLES `jom_kunena_smileys` WRITE;
/*!40000 ALTER TABLE `jom_kunena_smileys` DISABLE KEYS */;
INSERT INTO `jom_kunena_smileys` (`id`, `code`, `location`, `greylocation`, `emoticonbar`) VALUES (1,'B)','cool.png','cool-grey.png',1),(2,'8)','cool.png','cool-grey.png',0),(3,'8-)','cool.png','cool-grey.png',0),(4,':-(','sad.png','sad-grey.png',0),(5,':(','sad.png','sad-grey.png',1),(6,':sad:','sad.png','sad-grey.png',0),(7,':cry:','sad.png','sad-grey.png',0),(8,':)','smile.png','smile-grey.png',1),(9,':-)','smile.png','smile-grey.png',0),(10,':cheer:','cheerful.png','cheerful-grey.png',1),(11,';)','wink.png','wink-grey.png',1),(12,';-)','wink.png','wink-grey.png',0),(13,':wink:','wink.png','wink-grey.png',0),(14,';-)','wink.png','wink-grey.png',0),(15,':P','tongue.png','tongue-grey.png',1),(16,':p','tongue.png','tongue-grey.png',0),(17,':-p','tongue.png','tongue-grey.png',0),(18,':-P','tongue.png','tongue-grey.png',0),(19,':razz:','tongue.png','tongue-grey.png',0),(20,':angry:','angry.png','angry-grey.png',1),(21,':mad:','angry.png','angry-grey.png',0),(22,':unsure:','unsure.png','unsure-grey.png',1),(23,':o','shocked.png','shocked-grey.png',0),(24,':-o','shocked.png','shocked-grey.png',0),(25,':O','shocked.png','shocked-grey.png',0),(26,':-O','shocked.png','shocked-grey.png',0),(27,':eek:','shocked.png','shocked-grey.png',0),(28,':ohmy:','shocked.png','shocked-grey.png',1),(29,':huh:','wassat.png','wassat-grey.png',1),(30,':?','confused.png','confused-grey.png',0),(31,':-?','confused.png','confused-grey.png',0),(32,':???','confused.png','confused-grey.png',0),(33,':dry:','ermm.png','ermm-grey.png',1),(34,':ermm:','ermm.png','ermm-grey.png',0),(35,':lol:','grin.png','grin-grey.png',1),(36,':X','sick.png','sick-grey.png',0),(37,':x','sick.png','sick-grey.png',0),(38,':sick:','sick.png','sick-grey.png',1),(39,':silly:','silly.png','silly-grey.png',1),(40,':y32b4:','silly.png','silly-grey.png',0),(41,':blink:','blink.png','blink-grey.png',1),(42,':blush:','blush.png','blush-grey.png',1),(43,':oops:','blush.png','blush-grey.png',1),(44,':kiss:','kissing.png','kissing-grey.png',1),(45,':rolleyes:','blink.png','blink-grey.png',0),(46,':roll:','blink.png','blink-grey.png',0),(47,':woohoo:','w00t.png','w00t-grey.png',1),(48,':side:','sideways.png','sideways-grey.png',1),(49,':S','dizzy.png','dizzy-grey.png',1),(50,':s','dizzy.png','dizzy-grey.png',0),(51,':evil:','devil.png','devil-grey.png',1),(52,':twisted:','devil.png','devil-grey.png',0),(53,':whistle:','whistling.png','whistling-grey.png',1),(54,':pinch:','pinch.png','pinch-grey.png',1),(55,':D','laughing.png','laughing-grey.png',0),(56,':-D','laughing.png','laughing-grey.png',0),(57,':grin:','laughing.png','laughing-grey.png',0),(58,':laugh:','laughing.png','laughing-grey.png',0),(59,':|','neutral.png','neutral-grey.png',0),(60,':-|','neutral.png','neutral-grey.png',0),(61,':neutral:','neutral.png','neutral-grey.png',0),(62,':mrgreen:','mrgreen.png','mrgreen-grey.png',0),(63,':?:','question.png','question-grey.png',0),(64,':!:','exclamation.png','exclamation-grey.png',0),(65,':arrow:','arrow.png','arrow-grey.png',0),(66,':idea:','idea.png','idea-grey.png',0);
/*!40000 ALTER TABLE `jom_kunena_smileys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_kunena_thankyou`
--

DROP TABLE IF EXISTS `jom_kunena_thankyou`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_kunena_thankyou` (
  `postid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `targetuserid` int(11) NOT NULL,
  `time` datetime NOT NULL,
  UNIQUE KEY `postid` (`postid`,`userid`),
  KEY `userid` (`userid`),
  KEY `targetuserid` (`targetuserid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_kunena_thankyou`
--

LOCK TABLES `jom_kunena_thankyou` WRITE;
/*!40000 ALTER TABLE `jom_kunena_thankyou` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_kunena_thankyou` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_kunena_topics`
--

DROP TABLE IF EXISTS `jom_kunena_topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_kunena_topics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL DEFAULT '0',
  `subject` tinytext,
  `icon_id` int(11) NOT NULL DEFAULT '0',
  `locked` tinyint(4) NOT NULL DEFAULT '0',
  `hold` tinyint(4) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `posts` int(11) NOT NULL DEFAULT '0',
  `hits` int(11) NOT NULL DEFAULT '0',
  `attachments` int(11) NOT NULL DEFAULT '0',
  `poll_id` int(11) NOT NULL DEFAULT '0',
  `moved_id` int(11) NOT NULL DEFAULT '0',
  `first_post_id` int(11) NOT NULL DEFAULT '0',
  `first_post_time` int(11) NOT NULL DEFAULT '0',
  `first_post_userid` int(11) NOT NULL DEFAULT '0',
  `first_post_message` text,
  `first_post_guest_name` tinytext,
  `last_post_id` int(11) NOT NULL DEFAULT '0',
  `last_post_time` int(11) NOT NULL DEFAULT '0',
  `last_post_userid` int(11) NOT NULL DEFAULT '0',
  `last_post_message` text,
  `last_post_guest_name` tinytext,
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  KEY `locked` (`locked`),
  KEY `hold` (`hold`),
  KEY `posts` (`posts`),
  KEY `hits` (`hits`),
  KEY `first_post_userid` (`first_post_userid`),
  KEY `last_post_userid` (`last_post_userid`),
  KEY `first_post_time` (`first_post_time`),
  KEY `last_post_time` (`last_post_time`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_kunena_topics`
--

LOCK TABLES `jom_kunena_topics` WRITE;
/*!40000 ALTER TABLE `jom_kunena_topics` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_kunena_topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_kunena_user_categories`
--

DROP TABLE IF EXISTS `jom_kunena_user_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_kunena_user_categories` (
  `user_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `role` tinyint(4) NOT NULL DEFAULT '0',
  `allreadtime` datetime DEFAULT NULL,
  `subscribed` tinyint(4) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  PRIMARY KEY (`user_id`,`category_id`),
  KEY `category_subscribed` (`category_id`,`subscribed`),
  KEY `role` (`role`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_kunena_user_categories`
--

LOCK TABLES `jom_kunena_user_categories` WRITE;
/*!40000 ALTER TABLE `jom_kunena_user_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_kunena_user_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_kunena_user_read`
--

DROP TABLE IF EXISTS `jom_kunena_user_read`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_kunena_user_read` (
  `user_id` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `message_id` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  UNIQUE KEY `user_topic_id` (`user_id`,`topic_id`),
  KEY `category_user_id` (`category_id`,`user_id`),
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_kunena_user_read`
--

LOCK TABLES `jom_kunena_user_read` WRITE;
/*!40000 ALTER TABLE `jom_kunena_user_read` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_kunena_user_read` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_kunena_user_topics`
--

DROP TABLE IF EXISTS `jom_kunena_user_topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_kunena_user_topics` (
  `user_id` int(11) NOT NULL DEFAULT '0',
  `topic_id` int(11) NOT NULL DEFAULT '0',
  `category_id` int(11) NOT NULL,
  `posts` mediumint(8) NOT NULL DEFAULT '0',
  `last_post_id` int(11) NOT NULL DEFAULT '0',
  `owner` tinyint(4) NOT NULL DEFAULT '0',
  `favorite` tinyint(4) NOT NULL DEFAULT '0',
  `subscribed` tinyint(4) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  UNIQUE KEY `user_topic_id` (`user_id`,`topic_id`),
  KEY `topic_id` (`topic_id`),
  KEY `posts` (`posts`),
  KEY `owner` (`owner`),
  KEY `favorite` (`favorite`),
  KEY `subscribed` (`subscribed`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_kunena_user_topics`
--

LOCK TABLES `jom_kunena_user_topics` WRITE;
/*!40000 ALTER TABLE `jom_kunena_user_topics` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_kunena_user_topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_kunena_users`
--

DROP TABLE IF EXISTS `jom_kunena_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_kunena_users` (
  `userid` int(11) NOT NULL DEFAULT '0',
  `view` varchar(8) NOT NULL DEFAULT '',
  `signature` text,
  `moderator` int(11) DEFAULT '0',
  `banned` datetime DEFAULT NULL,
  `ordering` int(11) DEFAULT '0',
  `posts` int(11) DEFAULT '0',
  `avatar` varchar(255) DEFAULT NULL,
  `karma` int(11) DEFAULT '0',
  `karma_time` int(11) DEFAULT '0',
  `group_id` int(4) DEFAULT '1',
  `uhits` int(11) DEFAULT '0',
  `personalText` tinytext,
  `gender` tinyint(4) NOT NULL DEFAULT '0',
  `birthdate` date NOT NULL DEFAULT '0001-01-01',
  `location` varchar(50) DEFAULT NULL,
  `icq` varchar(50) DEFAULT NULL,
  `aim` varchar(50) DEFAULT NULL,
  `yim` varchar(50) DEFAULT NULL,
  `msn` varchar(50) DEFAULT NULL,
  `skype` varchar(50) DEFAULT NULL,
  `twitter` varchar(50) DEFAULT NULL,
  `facebook` varchar(50) DEFAULT NULL,
  `gtalk` varchar(50) DEFAULT NULL,
  `myspace` varchar(50) DEFAULT NULL,
  `linkedin` varchar(50) DEFAULT NULL,
  `delicious` varchar(50) DEFAULT NULL,
  `friendfeed` varchar(50) DEFAULT NULL,
  `digg` varchar(50) DEFAULT NULL,
  `blogspot` varchar(50) DEFAULT NULL,
  `flickr` varchar(50) DEFAULT NULL,
  `bebo` varchar(50) DEFAULT NULL,
  `websitename` varchar(50) DEFAULT NULL,
  `websiteurl` varchar(50) DEFAULT NULL,
  `rank` tinyint(4) NOT NULL DEFAULT '0',
  `hideEmail` tinyint(1) NOT NULL DEFAULT '1',
  `showOnline` tinyint(1) NOT NULL DEFAULT '1',
  `thankyou` int(11) DEFAULT '0',
  PRIMARY KEY (`userid`),
  KEY `group_id` (`group_id`),
  KEY `posts` (`posts`),
  KEY `uhits` (`uhits`),
  KEY `banned` (`banned`),
  KEY `moderator` (`moderator`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_kunena_users`
--

LOCK TABLES `jom_kunena_users` WRITE;
/*!40000 ALTER TABLE `jom_kunena_users` DISABLE KEYS */;
INSERT INTO `jom_kunena_users` (`userid`, `view`, `signature`, `moderator`, `banned`, `ordering`, `posts`, `avatar`, `karma`, `karma_time`, `group_id`, `uhits`, `personalText`, `gender`, `birthdate`, `location`, `icq`, `aim`, `yim`, `msn`, `skype`, `twitter`, `facebook`, `gtalk`, `myspace`, `linkedin`, `delicious`, `friendfeed`, `digg`, `blogspot`, `flickr`, `bebo`, `websitename`, `websiteurl`, `rank`, `hideEmail`, `showOnline`, `thankyou`) VALUES (335,'',NULL,0,NULL,0,0,NULL,0,0,1,0,NULL,0,'0001-01-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,0),(705,'','\"Fear of the Lord is the beginning of all wisdom\"',0,NULL,0,0,NULL,0,0,1,0,'',1,'1973-12-03','Qatar','','','','','','','','','','','','','','','','','Pixxelsis Digital Media','www.pixxelsis.com',0,1,1,0),(706,'',NULL,0,NULL,0,0,NULL,0,0,1,0,NULL,0,'0001-01-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,0),(707,'',NULL,0,NULL,0,0,NULL,0,0,1,0,NULL,0,'0001-01-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,0),(708,'',NULL,0,NULL,0,0,NULL,0,0,1,0,NULL,0,'0001-01-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,0),(709,'',NULL,0,NULL,0,0,NULL,0,0,1,0,NULL,0,'0001-01-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,0),(711,'',NULL,0,NULL,0,0,NULL,0,0,1,0,NULL,0,'0001-01-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,0),(712,'',NULL,0,NULL,0,0,NULL,0,0,1,0,NULL,0,'0001-01-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,0),(713,'',NULL,0,NULL,0,0,NULL,0,0,1,0,NULL,0,'0001-01-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,0),(714,'',NULL,0,NULL,0,0,NULL,0,0,1,0,NULL,0,'0001-01-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,0),(715,'',NULL,0,NULL,0,0,NULL,0,0,1,0,NULL,0,'0001-01-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,0),(716,'',NULL,0,NULL,0,0,NULL,0,0,1,0,NULL,0,'0001-01-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,0),(717,'',NULL,0,NULL,0,0,NULL,0,0,1,0,NULL,0,'0001-01-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,0),(719,'',NULL,0,NULL,0,0,NULL,0,0,1,0,NULL,0,'0001-01-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,0),(720,'',NULL,0,NULL,0,0,NULL,0,0,1,0,NULL,0,'0001-01-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,0),(710,'',NULL,0,NULL,0,0,NULL,0,0,1,0,NULL,0,'0001-01-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,0),(718,'',NULL,0,NULL,0,0,NULL,0,0,1,0,NULL,0,'0001-01-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,0);
/*!40000 ALTER TABLE `jom_kunena_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_kunena_users_banned`
--

DROP TABLE IF EXISTS `jom_kunena_users_banned`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_kunena_users_banned` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `ip` varchar(128) DEFAULT NULL,
  `blocked` tinyint(4) NOT NULL DEFAULT '0',
  `expiration` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_time` datetime NOT NULL,
  `reason_private` text,
  `reason_public` text,
  `modified_by` int(11) DEFAULT NULL,
  `modified_time` datetime DEFAULT NULL,
  `comments` text,
  `params` text,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `ip` (`ip`),
  KEY `expiration` (`expiration`),
  KEY `created_time` (`created_time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_kunena_users_banned`
--

LOCK TABLES `jom_kunena_users_banned` WRITE;
/*!40000 ALTER TABLE `jom_kunena_users_banned` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_kunena_users_banned` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_kunena_version`
--

DROP TABLE IF EXISTS `jom_kunena_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_kunena_version` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(20) NOT NULL,
  `versiondate` date NOT NULL,
  `installdate` date NOT NULL,
  `build` varchar(20) NOT NULL,
  `versionname` varchar(40) DEFAULT NULL,
  `state` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_kunena_version`
--

LOCK TABLES `jom_kunena_version` WRITE;
/*!40000 ALTER TABLE `jom_kunena_version` DISABLE KEYS */;
INSERT INTO `jom_kunena_version` (`id`, `version`, `versiondate`, `installdate`, `build`, `versionname`, `state`) VALUES (1,'3.0.3','2013-10-20','2013-12-09','','Bifrost','');
/*!40000 ALTER TABLE `jom_kunena_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_languages`
--

DROP TABLE IF EXISTS `jom_languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_languages` (
  `lang_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `lang_code` char(7) NOT NULL,
  `title` varchar(50) NOT NULL,
  `title_native` varchar(50) NOT NULL,
  `sef` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `description` varchar(512) NOT NULL,
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `sitename` varchar(1024) NOT NULL DEFAULT '',
  `published` int(11) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lang_id`),
  UNIQUE KEY `idx_sef` (`sef`),
  UNIQUE KEY `idx_image` (`image`),
  UNIQUE KEY `idx_langcode` (`lang_code`),
  KEY `idx_ordering` (`ordering`),
  KEY `idx_access` (`access`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_languages`
--

LOCK TABLES `jom_languages` WRITE;
/*!40000 ALTER TABLE `jom_languages` DISABLE KEYS */;
INSERT INTO `jom_languages` (`lang_id`, `lang_code`, `title`, `title_native`, `sef`, `image`, `description`, `metakey`, `metadesc`, `sitename`, `published`, `access`, `ordering`) VALUES (1,'en-GB','English (UK)','English (UK)','en','en','','','','',1,0,0);
/*!40000 ALTER TABLE `jom_languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_menu`
--

DROP TABLE IF EXISTS `jom_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menutype` varchar(24) NOT NULL COMMENT 'The type of menu this item belongs to. FK to #__menu_types.menutype',
  `title` varchar(255) NOT NULL COMMENT 'The display title of the menu item.',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT 'The SEF alias of the menu item.',
  `note` varchar(255) NOT NULL DEFAULT '',
  `path` varchar(1024) NOT NULL COMMENT 'The computed path of the menu item based on the alias field.',
  `link` varchar(1024) NOT NULL COMMENT 'The actually link the menu item refers to.',
  `type` varchar(16) NOT NULL COMMENT 'The type of link: Component, URL, Alias, Separator',
  `published` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'The published state of the menu link.',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '1' COMMENT 'The parent menu item in the menu tree.',
  `level` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The relative level in the tree.',
  `component_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to #__extensions.id',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to #__users.id',
  `checked_out_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'The time the menu item was checked out.',
  `browserNav` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'The click behaviour of the link.',
  `access` int(10) unsigned DEFAULT NULL,
  `img` varchar(255) NOT NULL COMMENT 'The image of the menu item.',
  `template_style_id` int(10) unsigned NOT NULL DEFAULT '0',
  `params` text NOT NULL COMMENT 'JSON encoded data for the menu item.',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `home` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Indicates if this menu item is the home or default page.',
  `language` char(7) NOT NULL DEFAULT '',
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_client_id_parent_id_alias_language` (`client_id`,`parent_id`,`alias`,`language`),
  KEY `idx_componentid` (`component_id`,`menutype`,`published`,`access`),
  KEY `idx_menutype` (`menutype`),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_alias` (`alias`),
  KEY `idx_path` (`path`(255)),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB AUTO_INCREMENT=318 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_menu`
--

LOCK TABLES `jom_menu` WRITE;
/*!40000 ALTER TABLE `jom_menu` DISABLE KEYS */;
INSERT INTO `jom_menu` (`id`, `menutype`, `title`, `alias`, `note`, `path`, `link`, `type`, `published`, `parent_id`, `level`, `component_id`, `checked_out`, `checked_out_time`, `browserNav`, `access`, `img`, `template_style_id`, `params`, `lft`, `rgt`, `home`, `language`, `client_id`) VALUES (1,'','Menu_Item_Root','root','','','','',1,0,0,0,0,'0000-00-00 00:00:00',0,0,'',0,'',0,363,0,'*',0),(2,'menu','com_banners','Banners','','Banners','index.php?option=com_banners','component',0,1,1,4,0,'0000-00-00 00:00:00',0,0,'class:banners',0,'',1,10,0,'*',1),(3,'menu','com_banners','Banners','','Banners/Banners','index.php?option=com_banners','component',0,2,2,4,0,'0000-00-00 00:00:00',0,0,'class:banners',0,'',2,3,0,'*',1),(4,'menu','com_banners_categories','Categories','','Banners/Categories','index.php?option=com_categories&extension=com_banners','component',0,2,2,6,0,'0000-00-00 00:00:00',0,0,'class:banners-cat',0,'',4,5,0,'*',1),(5,'menu','com_banners_clients','Clients','','Banners/Clients','index.php?option=com_banners&view=clients','component',0,2,2,4,0,'0000-00-00 00:00:00',0,0,'class:banners-clients',0,'',6,7,0,'*',1),(6,'menu','com_banners_tracks','Tracks','','Banners/Tracks','index.php?option=com_banners&view=tracks','component',0,2,2,4,0,'0000-00-00 00:00:00',0,0,'class:banners-tracks',0,'',8,9,0,'*',1),(7,'menu','com_contact','Contacts','','Contacts','index.php?option=com_contact','component',0,1,1,8,0,'0000-00-00 00:00:00',0,0,'class:contact',0,'',27,32,0,'*',1),(8,'menu','com_contact','Contacts','','Contacts/Contacts','index.php?option=com_contact','component',0,7,2,8,0,'0000-00-00 00:00:00',0,0,'class:contact',0,'',28,29,0,'*',1),(9,'menu','com_contact_categories','Categories','','Contacts/Categories','index.php?option=com_categories&extension=com_contact','component',0,7,2,6,0,'0000-00-00 00:00:00',0,0,'class:contact-cat',0,'',30,31,0,'*',1),(10,'menu','com_messages','Messaging','','Messaging','index.php?option=com_messages','component',0,1,1,15,0,'0000-00-00 00:00:00',0,0,'class:messages',0,'',33,38,0,'*',1),(11,'menu','com_messages_add','New Private Message','','Messaging/New Private Message','index.php?option=com_messages&task=message.add','component',0,10,2,15,0,'0000-00-00 00:00:00',0,0,'class:messages-add',0,'',34,35,0,'*',1),(12,'menu','com_messages_read','Read Private Message','','Messaging/Read Private Message','index.php?option=com_messages','component',0,10,2,15,0,'0000-00-00 00:00:00',0,0,'class:messages-read',0,'',36,37,0,'*',1),(13,'menu','com_newsfeeds','News Feeds','','News Feeds','index.php?option=com_newsfeeds','component',0,1,1,17,0,'0000-00-00 00:00:00',0,0,'class:newsfeeds',0,'',39,44,0,'*',1),(14,'menu','com_newsfeeds_feeds','Feeds','','News Feeds/Feeds','index.php?option=com_newsfeeds','component',0,13,2,17,0,'0000-00-00 00:00:00',0,0,'class:newsfeeds',0,'',40,41,0,'*',1),(15,'menu','com_newsfeeds_categories','Categories','','News Feeds/Categories','index.php?option=com_categories&extension=com_newsfeeds','component',0,13,2,6,0,'0000-00-00 00:00:00',0,0,'class:newsfeeds-cat',0,'',42,43,0,'*',1),(16,'menu','com_redirect','Redirect','','Redirect','index.php?option=com_redirect','component',0,1,1,24,0,'0000-00-00 00:00:00',0,0,'class:redirect',0,'',55,56,0,'*',1),(17,'menu','com_search','Search','','Search','index.php?option=com_search','component',0,1,1,19,0,'0000-00-00 00:00:00',0,0,'class:search',0,'',45,46,0,'*',1),(18,'menu','com_weblinks','Weblinks','','Weblinks','index.php?option=com_weblinks','component',0,1,1,21,0,'0000-00-00 00:00:00',0,0,'class:weblinks',0,'',49,54,0,'*',1),(19,'menu','com_weblinks_links','Links','','Weblinks/Links','index.php?option=com_weblinks','component',0,18,2,21,0,'0000-00-00 00:00:00',0,0,'class:weblinks',0,'',50,51,0,'*',1),(20,'menu','com_weblinks_categories','Categories','','Weblinks/Categories','index.php?option=com_categories&extension=com_weblinks','component',0,18,2,6,0,'0000-00-00 00:00:00',0,0,'class:weblinks-cat',0,'',52,53,0,'*',1),(21,'menu','com_finder','Smart Search','','Smart Search','index.php?option=com_finder','component',0,1,1,27,0,'0000-00-00 00:00:00',0,0,'class:finder',0,'',57,58,0,'*',1),(22,'menu','com_joomlaupdate','Joomla! Update','','Joomla! Update','index.php?option=com_joomlaupdate','component',0,1,1,28,0,'0000-00-00 00:00:00',0,0,'class:joomlaupdate',0,'',61,62,0,'*',1),(23,'main','com_tags','Tags','','Tags','index.php?option=com_tags','component',0,1,1,29,0,'0000-00-00 00:00:00',0,1,'class:tags',0,'',63,64,0,'',1),(102,'mainmenu','Home','home-mainmenu-1','','home-mainmenu-1','index.php?option=com_content&view=featured','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"featured_categories\":[\"\"],\"layout_type\":\"blog\",\"num_leading_articles\":\"0\",\"num_intro_articles\":\"6\",\"num_columns\":\"1\",\"num_links\":\"0\",\"multi_column_order\":\"1\",\"orderby_pri\":\"\",\"orderby_sec\":\"rdate\",\"order_date\":\"\",\"show_pagination\":\"2\",\"show_pagination_results\":\"1\",\"show_title\":\"1\",\"link_titles\":\"1\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"0\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"0\",\"link_author\":\"\",\"show_create_date\":\"1\",\"show_modify_date\":\"0\",\"show_publish_date\":\"0\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_readmore\":\"\",\"show_readmore_title\":\"0\",\"show_icons\":\"\",\"show_print_icon\":\"0\",\"show_email_icon\":\"0\",\"show_hits\":\"0\",\"show_noauth\":\"\",\"show_feed_link\":\"1\",\"feed_summary\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"Welcome to Philippine Overseas Employment Center \",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"Return Home\",\"s5_group_child\":\"0\"}',133,134,1,'*',0),(103,'mainmenu','News','news-mainmenu-2','','features-mainmenu-47/joomla-stuff-mainmenu-26/news-mainmenu-2','index.php?option=com_content&view=category&layout=blog&id=7','component',0,109,3,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu_image\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"back_button\":\"\",\"description_sec\":1,\"description_sec_image\":1,\"orderby\":\"\",\"other_cat_show_section\":1,\"empty_cat_show_section\":0,\"show_category_description\":1,\"description_cat_image\":1,\"show_categories\":1,\"show_empty_categories\":0,\"show_cat_num_articles\":1,\"cat_show_description\":1,\"date_format\":\"\",\"show_date\":\"\",\"show_author\":\"\",\"show_hits\":\"\",\"show_headings\":1,\"show_item_navigation\":1,\"order_select\":1,\"show_pagination_limit\":1,\"display_num\":50,\"filter\":1,\"filter_type\":\"title\",\"unpublished\":1,\"show_title\":1,\"show_page_heading\":\"0\"}',247,248,0,'*',0),(104,'mainmenu','Search','search-mainmenu-5','','features-mainmenu-47/joomla-stuff-mainmenu-26/search-mainmenu-5','index.php?option=com_search','component',0,109,3,19,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu_image\":\"\",\"pageclass_sfx\":\"\",\"back_button\":\"\",\"show_page_title\":1,\"page_title\":\"\",\"show_title\":1,\"show_page_heading\":\"0\"}',245,246,0,'*',0),(105,'mainmenu','News Feeds','news-feeds-mainmenu-7','','features-mainmenu-47/joomla-stuff-mainmenu-26/news-feeds-mainmenu-7','index.php?option=com_newsfeeds&view=categories','component',0,109,3,17,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu_image\":\"\",\"pageclass_sfx\":\"\",\"back_button\":\"\",\"show_page_title\":1,\"page_title\":\"\",\"other_cat_show_section\":1,\"show_categories\":1,\"cat_show_description\":1,\"show_cat_num_articles\":1,\"show_description\":1,\"description_text\":\"\",\"image\":-1,\"image_align\":\"right\",\"show_headings\":1,\"name\":1,\"articles\":1,\"num_links\":0,\"feed_image\":1,\"feed_descr\":1,\"item_descr\":1,\"word_count\":0,\"show_title\":1,\"show_page_heading\":\"0\"}',249,250,0,'*',0),(106,'mainmenu','Wrapper','wrapper-mainmenu-8','','features-mainmenu-47/joomla-stuff-mainmenu-26/wrapper-mainmenu-8','index.php?option=com_wrapper&view=wrapper','component',0,109,3,2,0,'0000-00-00 00:00:00',0,1,'',0,'{\"url\":\"http:\\/\\/getfirebug.com\\/\",\"scrolling\":\"auto\",\"width\":\"100%\",\"height\":\"600\",\"height_auto\":\"0\",\"add_scheme\":\"1\",\"frameborder\":\"1\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"\",\"s5_group_child\":\"0\"}',257,258,0,'*',0),(107,'mainmenu','Blog','blog-mainmenu-9','','features-mainmenu-47/joomla-stuff-mainmenu-26/links-mainmenu-23/blog-mainmenu-9','index.php?option=com_content&view=category&layout=blog&id=2','component',0,108,4,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu_image\":\"\",\"pageclass_sfx\":\"\",\"back_button\":\"\",\"page_title\":\"A blog of all sections with no images\",\"show_page_title\":1,\"num_leading_articles\":0,\"num_intro_articles\":6,\"num_columns\":2,\"num_links\":4,\"orderby_pri\":\"\",\"orderby_sec\":\"\",\"show_pagination\":2,\"show_pagination_results\":1,\"image\":0,\"show_description\":0,\"show_description_image\":0,\"show_category\":0,\"category_num_links\":0,\"show_title\":1,\"link_titles\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_show_date\":\"\",\"show_modify_show_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"unpublished\":0,\"sectionid\":0,\"show_page_heading\":\"0\"}',252,253,0,'*',0),(108,'mainmenu','Links','links-mainmenu-23','','features-mainmenu-47/joomla-stuff-mainmenu-26/links-mainmenu-23','index.php?option=com_weblinks&view=categories','component',0,109,3,21,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu_image\":\"\",\"pageclass_sfx\":\"\",\"back_button\":\"\",\"show_page_title\":1,\"page_title\":\"\",\"show_headings\":1,\"show_hits\":\"\",\"item_show_description\":1,\"other_cat_show_section\":1,\"show_categories\":1,\"show_description\":1,\"description_text\":\"\",\"image\":-1,\"image_align\":\"right\",\"weblink_icons\":\"\",\"show_title\":1,\"show_page_heading\":\"0\"}',251,254,0,'*',0),(109,'mainmenu','J! Stuff','joomla-stuff-mainmenu-26','','features-mainmenu-47/joomla-stuff-mainmenu-26','javascript:;','url',0,119,2,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"images\\/stories\\/joomla.png\",\"menu_text\":1,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"Default Joomla Items\",\"s5_group_child\":\"0\"}',244,259,0,'*',0),(110,'mainmenu','Typography','typography-mainmenu-27','','features-mainmenu-47/style-and-layout-options/typography-mainmenu-27','index.php?option=com_content&view=article&id=12','component',0,178,3,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":1,\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',273,274,0,'*',0),(111,'mainmenu','S5 Flex Menu','s5-flex-menu-1360','','job-seekers/s5-flex-menu-1360','index.php?option=com_content&view=article&id=13','component',0,134,2,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_title\":\"1\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"2\",\"s5_subtext\":\"Advanced Menu System\",\"s5_group_child\":\"0\"}',162,195,0,'*',0),(112,'mainmenu','Drop Down Menu','sample-menu','','job-seekers/s5-flex-menu-1360/sample-menu','javascript:;','url',0,111,3,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"images\\/stories\\/application_put.png\",\"menu_text\":1,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"Unlimited Level Options\",\"s5_group_child\":\"0\"}',163,176,0,'*',0),(113,'mainmenu','Dummy Item','dummy-item-mainmenu-33','','job-seekers/s5-flex-menu-1360/sample-menu/dummy-item-mainmenu-33','javascript:;','url',0,112,4,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu_image\":\"\",\"show_title\":1,\"show_page_title\":1,\"show_page_heading\":\"0\"}',164,165,0,'*',0),(114,'mainmenu','Dummy Item','dummy-item-mainmenu-34','','job-seekers/s5-flex-menu-1360/sample-menu/dummy-item-mainmenu-34','javascript:;','url',0,112,4,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu_image\":\"\",\"show_title\":1,\"show_page_title\":1,\"show_page_heading\":\"0\"}',166,167,0,'*',0),(115,'mainmenu','Dummy Item','dummy-item-mainmenu-35','','job-seekers/s5-flex-menu-1360/sample-menu/dummy-item-mainmenu-35','javascript:;','url',0,112,4,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu_image\":\"\",\"show_title\":1,\"show_page_title\":1,\"show_page_heading\":\"0\"}',168,175,0,'*',0),(116,'mainmenu','Dummy Item','dummy-item-mainmenu-36','','job-seekers/s5-flex-menu-1360/sample-menu/dummy-item-mainmenu-35/dummy-item-mainmenu-36','javascript:;','url',0,115,5,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu_image\":\"\",\"show_title\":1,\"show_page_title\":1,\"show_page_heading\":\"0\"}',169,170,0,'*',0),(117,'mainmenu','Dummy Item','dummy-item-mainmenu-37','','job-seekers/s5-flex-menu-1360/sample-menu/dummy-item-mainmenu-35/dummy-item-mainmenu-37','javascript:;','url',0,115,5,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu_image\":\"\",\"show_title\":1,\"show_page_title\":1,\"show_page_heading\":\"0\"}',171,172,0,'*',0),(118,'mainmenu','Dummy Item','dummy-item-mainmenu-38','','job-seekers/s5-flex-menu-1360/sample-menu/dummy-item-mainmenu-35/dummy-item-mainmenu-38','javascript:;','url',0,115,5,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu_image\":\"\",\"show_title\":1,\"show_page_title\":1,\"show_page_heading\":\"0\"}',173,174,0,'*',0),(119,'mainmenu','Features','features-mainmenu-47','','features-mainmenu-47','javascript:;','url',0,1,1,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"s5_load_mod\":\"0\",\"s5_columns\":\"2\",\"s5_subtext\":\"What\'s Included\",\"s5_group_child\":\"0\"}',213,290,0,'*',0),(120,'mainmenu','Tutorials','tutorials-mainmenu-48','','tutorials-mainmenu-48','javascript:;','url',0,1,1,0,335,'2013-12-09 16:42:48',0,1,'',0,'{\"s5_load_mod\":0,\"s5_columns\":1,\"s5_subtext\":\"Find Help Here\",\"s5_group_child\":0,\"menu_image\":\"\",\"show_page_heading\":\"0\"}',11,26,0,'*',0),(121,'mainmenu','98 Module Positions','98-module-positions','','features-mainmenu-47/template-features/98-module-positions','index.php?option=com_content&view=article&id=14','component',0,135,3,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_title\":\"1\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"Thousands of Layout Options\",\"s5_group_child\":\"0\"}',225,226,0,'*',0),(122,'mainmenu','Contact Us','contact-us','','features-mainmenu-47/joomla-stuff-mainmenu-26/contact-us','index.php?option=com_contact&view=contact&id=2','component',0,109,3,8,0,'0000-00-00 00:00:00',0,1,'',0,'{\"presentation_style\":\"plain\",\"show_contact_category\":\"\",\"show_contact_list\":\"0\",\"show_name\":\"\",\"show_position\":\"\",\"show_email\":\"\",\"show_street_address\":\"\",\"show_suburb\":\"\",\"show_state\":\"\",\"show_postcode\":\"\",\"show_country\":\"\",\"show_telephone\":\"\",\"show_mobile\":\"\",\"show_fax\":\"\",\"show_webpage\":\"\",\"show_misc\":\"\",\"show_image\":\"\",\"allow_vcard\":\"\",\"show_articles\":\"\",\"show_links\":\"\",\"linka_name\":\"\",\"linkb_name\":\"\",\"linkc_name\":\"\",\"linkd_name\":\"\",\"linke_name\":\"\",\"show_email_form\":\"\",\"show_email_copy\":\"\",\"banned_email\":\"\",\"banned_subject\":\"\",\"banned_text\":\"\",\"validate_session\":\"\",\"custom_reply\":\"\",\"redirect\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"\",\"s5_group_child\":\"0\"}',255,256,0,'*',0),(123,'mainmenu','Site Shaper Available','site-shaper-available','','features-mainmenu-47/style-and-layout-options/site-shaper-available','index.php?option=com_content&view=article&id=39','component',0,178,3,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"s5_load_mod\":0,\"s5_columns\":1,\"s5_subtext\":\"\",\"s5_group_child\":0,\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',267,268,0,'*',0),(124,'mainmenu','Site Shaper Setup','site-shaper-setup','','tutorials-mainmenu-48/site-shaper-setup','index.php?option=com_content&view=article&id=39','component',0,120,2,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"s5_load_mod\":0,\"s5_columns\":1,\"s5_subtext\":\"Site Shapers Are Highly Recommended\",\"s5_group_child\":0,\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',14,15,0,'*',0),(125,'mainmenu','Setting Up Module Styles','setting-up-module-styles','','tutorials-mainmenu-48/setting-up-module-styles','index.php?option=com_content&view=article&id=14','component',0,120,2,22,0,'0000-00-00 00:00:00',0,1,'',15,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',18,19,0,'*',0),(126,'mainmenu','Fluid and Fixed Layouts','fluid-and-fixed-layouts','','features-mainmenu-47/style-and-layout-options/fluid-and-fixed-layouts','index.php?option=com_content&view=article&id=24','component',0,178,3,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',277,278,0,'*',0),(127,'mainmenu','Tool Tips Enabled','tool-tips-enabled','','features-mainmenu-47/template-features/tool-tips-enabled','index.php?option=com_content&view=article&id=37','component',0,135,3,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',231,232,0,'*',0),(129,'mainmenu','Installing The Template','installing-the-template','','tutorials-mainmenu-48/installing-the-template','index.php?option=com_content&view=article&id=17','component',0,120,2,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',16,17,0,'*',0),(130,'mainmenu','Configuring The Template','configuring-the-template','','tutorials-mainmenu-48/configuring-the-template','index.php?option=com_content&view=article&id=18','component',0,120,2,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',20,21,0,'*',0),(131,'mainmenu','Search and Menus Setup','search-and-menus-setup','','tutorials-mainmenu-48/search-and-menus-setup','index.php?option=com_content&view=article&id=36','component',0,120,2,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',22,23,0,'*',0),(134,'mainmenu','Job Seekers','job-seekers','','job-seekers','index.php?option=com_jsjobs&view=jobseeker&layout=controlpanel','component',1,1,1,10050,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"2\",\"s5_subtext\":\"Job Applicants\",\"s5_group_child\":\"0\"}',153,198,0,'*',0),(135,'mainmenu','Vertex Template Features','template-features','','features-mainmenu-47/template-features','javascript:;','url',0,119,2,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"images\\/stories\\/application_split.png\",\"menu_text\":1,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"Powerful Template Settings\",\"s5_group_child\":\"1\"}',218,243,0,'*',0),(136,'mainmenu','LTR Language','ltr-language','','features-mainmenu-47/style-and-layout-options/ltr-language','?lang=ltr','url',0,178,3,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"\",\"s5_group_child\":\"0\"}',285,286,0,'*',0),(137,'mainmenu','RTL Language','rtl-language','','features-mainmenu-47/style-and-layout-options/rtl-language','?lang=rtl','url',0,178,3,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"\",\"s5_group_child\":\"0\"}',287,288,0,'*',0),(138,'mainmenu','SEO Optimized','seo-optimized','','features-mainmenu-47/template-features/seo-optimized','index.php?option=com_content&view=article&id=173','component',0,135,3,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',227,228,0,'*',0),(139,'second-menu','About us','about-us','','about-us','index.php?option=com_content&view=article&id=208','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',107,108,0,'*',0),(140,'second-menu','FAQs','faqs','','faqs','index.php?option=com_content&view=article&id=208','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',109,110,0,'*',0),(141,'second-menu','News','news','','news','index.php?option=com_content&view=article&id=208','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',121,122,0,'*',0),(142,'second-menu','Blog','blog','','blog','index.php?option=com_content&view=article&id=208','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',129,130,0,'*',0),(143,'mainmenu','Multibox Enabled','multibox-enabled','','features-mainmenu-47/template-features/multibox-enabled','index.php?option=com_content&view=article&id=195','component',0,135,3,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',233,234,0,'*',0),(145,'mainmenu','Template Specific Features','template-specific-features','','features-mainmenu-47/template-specific-features','index.php?option=com_content&view=article&id=197','component',0,119,2,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"images\\/stories\\/color_wheel.png\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"Options Specific To This Template\",\"s5_group_child\":\"0\"}',216,217,0,'*',0),(146,'mainmenu','Google Fonts Enabled','google-fonts-enabled','','features-mainmenu-47/style-and-layout-options/google-fonts-enabled','index.php?option=com_content&view=article&id=204','component',0,178,3,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"s5_load_mod\":0,\"s5_columns\":1,\"s5_subtext\":\"\",\"s5_group_child\":0,\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',269,270,0,'*',0),(149,'mainmenu','Page, Row and Column Widths','page-row-and-column-widths','','features-mainmenu-47/style-and-layout-options/page-row-and-column-widths','index.php?option=com_content&view=article&id=24','component',0,178,3,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',271,272,0,'*',0),(150,'mainmenu','Mobile Device Ready','mobile-device-ready','','features-mainmenu-47/template-features/mobile-device-ready','index.php?option=com_content&view=article&id=287','component',0,135,3,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"\",\"s5_group_child\":\"0\"}',229,230,0,'*',0),(151,'second-menu','Home','home','','','index.php?Itemid=','alias',1,0,1,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu_item\":1,\"aliasoptions\":1,\"show_page_heading\":\"0\"}',0,0,0,'*',0),(152,'mainmenu','CSS Tableless Overrides','css-tableless-overrides','','features-mainmenu-47/style-and-layout-options/css-tableless-overrides','index.php?option=com_content&view=article&id=212','component',0,178,3,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',275,276,0,'*',0),(153,'mainmenu','S5 Box','s5-box','','job-seekers/s5-box','index.php?option=com_content&view=article&id=146','component',0,134,2,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"s5_load_mod\":0,\"s5_columns\":1,\"s5_subtext\":\"Popup Box for Login\",\"s5_group_child\":0,\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',156,157,0,'*',0),(154,'mainmenu','S5 Login and Register Setup','s5-login-and-register-setup','','tutorials-mainmenu-48/s5-login-and-register-setup','index.php?option=com_content&view=article&id=146','component',0,120,2,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',24,25,0,'*',0),(155,'mainmenu','S5 Accordion Menu','s5-accordion-menu','','job-seekers/s5-accordion-menu','index.php?option=com_content&view=article&id=143','component',0,134,2,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"s5_load_mod\":0,\"s5_columns\":1,\"s5_subtext\":\"Accordion Column Menu\",\"s5_group_child\":0,\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',154,155,0,'*',0),(156,'second-menu','Site Map','site-map','','site-map','index.php?option=com_content&view=article&id=208','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',147,148,0,'*',0),(157,'second-menu','Site Terms','site-terms','','site-terms','index.php?option=com_content&view=article&id=208','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',207,208,0,'*',0),(158,'Bottom-Menu-1','Our Latest Updates','updates-25678','','updates-25678','index.php?option=com_content&view=article&id=208','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"s5_load_mod\":0,\"s5_columns\":1,\"s5_subtext\":\"\",\"s5_group_child\":0,\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',99,100,0,'*',0),(159,'Bottom-Menu-1','The Newest Gallery','addons-10607','','addons-10607','index.php?option=com_content&view=article&id=208','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"s5_load_mod\":0,\"s5_columns\":1,\"s5_subtext\":\"\",\"s5_group_child\":0,\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',115,116,0,'*',0),(160,'Bottom-Menu-1','Knowledge Base','knowledge-base','','knowledge-base','index.php?option=com_content&view=article&id=208','component',0,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',131,132,0,'*',0),(161,'Bottom-Menu-1','Simply Great Designs','designs-9852','','designs-9852','index.php?option=com_content&view=article&id=208','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"s5_load_mod\":0,\"s5_columns\":1,\"s5_subtext\":\"\",\"s5_group_child\":0,\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',201,202,0,'*',0),(162,'Bottom-Menu-2','Careers','careers-23301','','careers-23301','index.php?option=com_content&view=article&id=208','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',291,292,0,'*',0),(163,'Bottom-Menu-2','Our Forum','our-forum-30554','','our-forum-30554','index.php?option=com_content&view=article&id=208','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',111,112,0,'*',0),(164,'Bottom-Menu-2','Listings','listings-28043','','listings-28043','index.php?option=com_content&view=article&id=208','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',123,124,0,'*',0),(165,'Bottom-Menu-2','Community','community','','community','index.php?option=com_content&view=article&id=208','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',145,146,0,'*',0),(166,'Bottom-Menu-1','Learn More About Us','learn-more-11880','','learn-more-11880','index.php?option=com_content&view=article&id=208','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"s5_load_mod\":0,\"s5_columns\":1,\"s5_subtext\":\"\",\"s5_group_child\":0,\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',151,152,0,'*',0),(167,'Bottom-Menu-2','Learn How','learn-how-8833','','learn-how-8833','index.php?option=com_content&view=article&id=208','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',205,206,0,'*',0),(168,'Bottom-Menu-1','Mobile','mobile','','mobile','index.php?option=com_content&view=article&id=208','component',0,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"s5_load_mod\":0,\"s5_columns\":1,\"s5_subtext\":\"\",\"s5_group_child\":0,\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',103,104,0,'*',0),(169,'Bottom-Menu-4','Affiliates','affiliates','','affiliates','index.php?option=com_content&view=article&id=208','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"s5_load_mod\":0,\"s5_columns\":1,\"s5_subtext\":\"\",\"s5_group_child\":0,\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',97,98,0,'*',0),(170,'Bottom-Menu-1','Specials','specials','','specials','index.php?option=com_content&view=article&id=208','component',0,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"s5_load_mod\":0,\"s5_columns\":1,\"s5_subtext\":\"\",\"s5_group_child\":0,\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',119,120,0,'*',0),(171,'Bottom-Menu-4','Supplies','supplies','','supplies','index.php?option=com_content&view=article&id=208','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"s5_load_mod\":0,\"s5_columns\":1,\"s5_subtext\":\"\",\"s5_group_child\":0,\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',117,118,0,'*',0),(172,'Bottom-Menu-2','Where To','where-to','','where-to','index.php?option=com_content&view=article&id=208','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"s5_load_mod\":0,\"s5_columns\":1,\"s5_subtext\":\"\",\"s5_group_child\":0,\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',105,106,0,'*',0),(173,'Bottom-Menu-4','Careers','careers','','careers','index.php?option=com_content&view=article&id=208','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',113,114,0,'*',0),(174,'Bottom-Menu-4','Our Forum','our-forum','','our-forum','index.php?option=com_content&view=article&id=208','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',149,150,0,'*',0),(175,'Bottom-Menu-4','Listings','listings','','listings','index.php?option=com_content&view=article&id=208','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',101,102,0,'*',0),(176,'Bottom-Menu-4','Designs','designs','','designs','index.php?option=com_content&view=article&id=208','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',125,126,0,'*',0),(177,'Bottom-Menu-2','Learn How','learn-how','','learn-how','index.php?option=com_content&view=article&id=208','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"s5_load_mod\":0,\"s5_columns\":1,\"s5_subtext\":\"\",\"s5_group_child\":0,\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',127,128,0,'*',0),(178,'mainmenu','Continued Vertex Features','style-and-layout-options','','features-mainmenu-47/style-and-layout-options','','separator',0,119,2,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu_image\":\"images\\/stories\\/application_view_tile.png\",\"menu_text\":1,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"More Great S5 Vertex Options\",\"s5_group_child\":\"1\"}',262,289,0,'*',0),(179,'mainmenu','Fixed Side Tabs','fixed-side-tabs','','features-mainmenu-47/style-and-layout-options/fixed-side-tabs','index.php?option=com_content&view=article&id=214','component',0,178,3,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',279,280,0,'*',0),(180,'second-menu','Learn More','learn-more','','learn-more','index.php?option=com_content&view=article&id=208','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',209,210,0,'*',0),(181,'second-menu','Updates','updates','','updates','index.php?option=com_content&view=article&id=208','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',211,212,0,'*',0),(182,'mainmenu','S5 Flex Menu','s5-flex-menu','','s5-flex-menu','index.php?option=com_kunena&view=home&defaultmenu=302','component',0,1,1,10101,0,'0000-00-00 00:00:00',0,1,'',0,'{\"catids\":[\"0\"],\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"Advanced Menu System\",\"s5_group_child\":\"0\"}',349,350,0,'*',0),(183,'mainmenu','Grouped Child Menu','sample-grouped-child-menu','','job-seekers/s5-flex-menu-1360/sample-grouped-child-menu','','separator',0,111,3,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu_image\":\"images\\/stories\\/application_side_boxes.png\",\"menu_text\":1,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"Group Children Together\",\"s5_group_child\":\"1\"}',179,192,0,'*',0),(184,'mainmenu','Dummy Sample Link 1','dummy-link-1','','job-seekers/s5-flex-menu-1360/sample-grouped-child-menu/dummy-link-1','','separator',0,183,4,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"s5_load_mod\":0,\"s5_columns\":1,\"s5_subtext\":\"\",\"s5_group_child\":0,\"menu_image\":\"\",\"show_page_heading\":\"0\"}',182,183,0,'*',0),(185,'mainmenu','Dummy Sample Link 2','dummy-link-2','','job-seekers/s5-flex-menu-1360/sample-grouped-child-menu/dummy-link-2','','separator',0,183,4,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"s5_load_mod\":0,\"s5_columns\":1,\"s5_subtext\":\"\",\"s5_group_child\":0,\"menu_image\":\"\",\"show_page_heading\":\"0\"}',180,181,0,'*',0),(186,'mainmenu','Dummy Sample Link 3','dummy-link-3','','job-seekers/s5-flex-menu-1360/sample-grouped-child-menu/dummy-link-3','','separator',0,183,4,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"s5_load_mod\":0,\"s5_columns\":1,\"s5_subtext\":\"\",\"s5_group_child\":0,\"menu_image\":\"\",\"show_page_heading\":\"0\"}',184,185,0,'*',0),(187,'mainmenu','Dummy Sample Link 4','dummy-link-4','','job-seekers/s5-flex-menu-1360/sample-grouped-child-menu/dummy-link-4','','separator',0,183,4,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"s5_load_mod\":0,\"s5_columns\":1,\"s5_subtext\":\"\",\"s5_group_child\":0,\"menu_image\":\"\",\"show_page_heading\":\"0\"}',186,187,0,'*',0),(188,'mainmenu','Dummy Sample Link 5','dummy-link-5','','job-seekers/s5-flex-menu-1360/sample-grouped-child-menu/dummy-link-5','','separator',0,183,4,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"s5_load_mod\":0,\"s5_columns\":1,\"s5_subtext\":\"\",\"s5_group_child\":0,\"menu_image\":\"\",\"show_page_heading\":\"0\"}',188,189,0,'*',0),(189,'mainmenu','Dummy Sample Link 6','dummy-link-6','','job-seekers/s5-flex-menu-1360/sample-grouped-child-menu/dummy-link-6','','separator',0,183,4,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"s5_load_mod\":0,\"s5_columns\":1,\"s5_subtext\":\"\",\"s5_group_child\":0,\"menu_image\":\"\",\"show_page_heading\":\"0\"}',190,191,0,'*',0),(190,'mainmenu','Menu Module Example','menu-module-example','','job-seekers/s5-flex-menu-1360/menu-module-example','','separator',0,111,3,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu_image\":\"images\\/stories\\/cog_edit.png\",\"menu_text\":1,\"s5_load_mod\":\"1\",\"s5_position\":\"s5_menu1\",\"s5_columns\":\"1\",\"s5_subtext\":\"Publish Any Module to Any Menu\",\"s5_group_child\":\"1\"}',177,178,0,'*',0),(191,'mainmenu','Menu With No Menu Icon','item-with-menu-icon','','job-seekers/s5-flex-menu-1360/item-with-menu-icon','','separator',0,111,3,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"s5_load_mod\":0,\"s5_columns\":1,\"s5_subtext\":\"Standard Sub Menu Link\",\"s5_group_child\":0,\"menu_image\":\"\",\"show_page_heading\":\"0\"}',193,194,0,'*',0),(192,'mainmenu','Menu Scroll To','menu-scroll-to','','features-mainmenu-47/template-features/menu-scroll-to','index.php?option=com_content&view=article&id=227','component',0,135,3,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"s5_load_mod\":0,\"s5_columns\":1,\"s5_subtext\":\"\",\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',237,238,0,'*',0),(193,'mainmenu','IE7 and 8 CSS3 Support','ie7-and-8-css3-support','','features-mainmenu-47/style-and-layout-options/ie7-and-8-css3-support','index.php?option=com_content&view=article&id=228','component',0,178,3,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"s5_load_mod\":0,\"s5_columns\":1,\"s5_subtext\":\"\",\"s5_group_child\":0,\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',281,282,0,'*',0),(195,'mainmenu','S5 Vertex Framework','shape-5-vertex-framework','','features-mainmenu-47/shape-5-vertex-framework','http://www.shape5.com/joomla/framework/vertex_framework.html','url',0,119,2,0,0,'0000-00-00 00:00:00',1,1,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"images\\/stories\\/application_link.png\",\"menu_text\":1,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"Lear More About Vertex\",\"s5_group_child\":\"0\"}',214,215,0,'*',0),(196,'Bottom-Menu-4','Addons','addons','','addons','index.php?option=com_content&view=article&id=208','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',203,204,0,'*',0),(197,'mainmenu','Hide Article Component Area','hide-article-component-area','','features-mainmenu-47/template-features/hide-article-component-area','index.php?option=com_content&view=article&id=231','component',0,135,3,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"s5_load_mod\":0,\"s5_columns\":1,\"s5_subtext\":\"\",\"s5_group_child\":0,\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',239,240,0,'*',0),(198,'mainmenu','Lazy Load Enabled','lazy-load-enabled','','features-mainmenu-47/template-features/lazy-load-enabled','index.php?option=com_content&view=article&id=230','component',0,135,3,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"s5_load_mod\":0,\"s5_columns\":1,\"s5_subtext\":\"\",\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',235,236,0,'*',0),(200,'mainmenu','Drop Down Panel','drop-down-panel','','features-mainmenu-47/template-features/drop-down-panel','index.php?option=com_content&view=article&id=233','component',0,135,3,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"s5_load_mod\":0,\"s5_columns\":1,\"s5_subtext\":\"\",\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',241,242,0,'*',0),(202,'mainmenu','S5 Tab Show','s5-tab-show','','job-seekers/s5-tab-show','index.php?option=com_content&view=article&id=110','component',0,134,2,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"Organize Your Site\'s Content\",\"s5_group_child\":\"0\"}',158,159,0,'*',0),(203,'mainmenu','Joomla and Vertex Tutorials','joomla-tutorials-12070','','features-mainmenu-47/joomla-tutorials-12070','http://www.shape5.com/joomla_tutorials.html','url',0,119,2,0,0,'0000-00-00 00:00:00',1,1,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"images\\/stories\\/help.png\",\"menu_text\":1,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"Download Vertex and Joomla Tutorials\",\"s5_group_child\":\"0\"}',260,261,0,'*',0),(204,'mainmenu','Joomla and Vertex Tutorials','joomla-tutorials','','tutorials-mainmenu-48/joomla-tutorials','http://www.shape5.com/joomla_tutorials.html','url',0,120,2,0,0,'0000-00-00 00:00:00',1,1,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"images\\/stories\\/help.png\",\"menu_text\":1,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"Download Vertex and Joomla Tutorials\",\"s5_group_child\":\"0\"}',12,13,0,'*',0),(205,'mainmenu','3rd Party Component Compatible','3rd-party-component-compatible','','features-mainmenu-47/style-and-layout-options/3rd-party-component-compatible','index.php?option=com_content&view=article&id=255','component',0,178,3,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"s5_load_mod\":0,\"s5_columns\":1,\"s5_subtext\":\"\",\"show_noauth\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"feed_summary\":\"\",\"page_title\":\"\",\"show_page_title\":1,\"pageclass_sfx\":\"\",\"menu_image\":\"\",\"secure\":0,\"show_page_heading\":\"0\"}',283,284,0,'*',0),(206,'mainmenu','S5 Image and Content Fader','s5-image-and-content-fader','','job-seekers/s5-image-and-content-fader','index.php?option=com_content&view=article&id=256','component',0,134,2,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"Image Rotating Extension\",\"s5_group_child\":\"0\"}',160,161,0,'*',0),(208,'top-bottom-menu','Home','bottommenu-home','','bottommenu-home','index.php?Itemid=','alias',1,1,1,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"aliasoptions\":\"102\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"\",\"s5_group_child\":\"0\"}',59,60,0,'*',0),(209,'top-bottom-menu','About Us','about','','about','index.php?Itemid=','alias',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"aliasoptions\":\"209\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"\",\"s5_group_child\":\"0\"}',65,66,0,'*',0),(210,'top-bottom-menu','FAQs','faq','','faq','index.php?Itemid=','alias',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"aliasoptions\":\"210\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"\",\"s5_group_child\":\"0\"}',67,68,0,'*',0),(211,'top-bottom-menu','News','new','','new','index.php?Itemid=','alias',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"aliasoptions\":\"211\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"\",\"s5_group_child\":\"0\"}',69,70,0,'*',0),(212,'top-bottom-menu','Blog','blogs','','blogs','index.php?Itemid=','alias',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"aliasoptions\":\"212\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"\",\"s5_group_child\":\"0\"}',71,72,0,'*',0),(213,'top-bottom-menu','Contact Us','bottommenu-contact-us','','bottommenu-contact-us','index.php?Itemid=','alias',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"aliasoptions\":\"280\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"\",\"s5_group_child\":\"0\"}',73,74,0,'*',0),(214,'top-bottom-menu','Site Terms','terms','','terms','index.php?option=com_content&view=article&id=208','component',0,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"\",\"s5_group_child\":\"0\"}',75,76,0,'*',0),(215,'top-bottom-menu','Directions','directions','','directions','index.php?option=com_content&view=article&id=208','component',0,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"\",\"s5_group_child\":\"0\"}',77,78,0,'*',0),(216,'top-bottom-menu','Updates','update','','update','index.php?option=com_content&view=article&id=208','component',0,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"\",\"s5_group_child\":\"0\"}',79,80,0,'*',0),(223,'mainmenu','Jobs','jobs','','jobs','index.php?option=com_jsjobs&view=jobseeker&layout=jobcat','component',1,1,1,10050,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_position\":\"s5_menu2\",\"s5_columns\":\"1\",\"s5_subtext\":\"Jobs\",\"s5_group_child\":\"0\"}',137,144,0,'*',0),(247,'mainmenu','Hide Content and Modules','hide-content-and-modules','','features-mainmenu-47/template-features/hide-content-and-modules','index.php?option=com_content&view=article&id=289','component',0,135,3,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"\",\"s5_group_child\":\"0\"}',221,222,0,'*',0),(248,'mainmenu','Responsive Layout','responsive-layout','','features-mainmenu-47/template-features/responsive-layout','index.php?option=com_content&view=article&id=287','component',0,135,3,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"Adapt to Any Screen Size\",\"s5_group_child\":\"1\"}',219,220,0,'*',0),(249,'mainmenu','Info Slide Enabled','info-slide-enabled','','features-mainmenu-47/template-features/info-slide-enabled','index.php?option=com_content&view=article&id=288','component',0,135,3,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"\",\"s5_group_child\":\"0\"}',223,224,0,'*',0),(250,'mainmenu','File Compression','file-compression','','features-mainmenu-47/style-and-layout-options/file-compression','index.php?option=com_content&view=article&id=290','component',0,178,3,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"\",\"s5_group_child\":\"0\"}',263,264,0,'*',0),(251,'mainmenu','Fixed Width','2012-06-11-23-22-43','','jobs/2012-06-11-23-22-43','?body_width=960&fixed_fluid=px','url',-2,223,2,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"View a Fixed Width Demo With Responsive\",\"s5_group_child\":\"0\"}',138,139,0,'*',0),(252,'mainmenu','Fluid Width','2012-06-11-23-23-29','','jobs/2012-06-11-23-23-29','?body_width=94&fixed_fluid=%','url',-2,223,2,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"View a Fluid Width Demo With Responsive\",\"s5_group_child\":\"0\"}',140,141,0,'*',0),(253,'mainmenu','Stock Photography','stock-photography','','features-mainmenu-47/style-and-layout-options/stock-photography','index.php?option=com_content&view=article&id=291','component',0,178,3,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"\",\"s5_group_child\":\"0\"}',265,266,0,'*',0),(260,'top-bottom-menu','Sample','sample','','sample','index.php?option=com_content&view=article&id=276','component',-2,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"\",\"s5_group_child\":\"0\"}',81,82,0,'*',0),(261,'top-menu','Home','topmenu-home','','topmenu-home','index.php?Itemid=','alias',1,1,1,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"aliasoptions\":\"102\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"\",\"s5_group_child\":\"0\"}',83,84,0,'*',0),(262,'top-menu','About Us','topmenu-about-us','','topmenu-about-us','index.php?option=com_content&view=article&id=297','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_tags\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"\",\"s5_group_child\":\"0\"}',85,86,0,'*',0),(263,'top-menu','FAQs','topmenu-faq','','topmenu-faq','index.php?option=com_content&view=article&id=298','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_tags\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"\",\"s5_group_child\":\"0\"}',87,90,0,'*',0),(264,'top-menu','News','topmenu-news','','topmenu-news','index.php?option=com_content&view=article&id=276','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_tags\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"\",\"s5_group_child\":\"0\"}',91,92,0,'*',0),(265,'top-menu','Blog','topmenu-blog','','topmenu-blog','index.php?option=com_content&view=category&layout=blog&id=48','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"layout_type\":\"blog\",\"show_category_heading_title_text\":\"\",\"show_category_title\":\"\",\"show_description\":\"\",\"show_description_image\":\"\",\"maxLevel\":\"\",\"show_empty_categories\":\"\",\"show_no_articles\":\"\",\"show_subcat_desc\":\"\",\"show_cat_num_articles\":\"\",\"page_subheading\":\"\",\"num_leading_articles\":\"2\",\"num_intro_articles\":\"2\",\"num_columns\":\"2\",\"num_links\":\"\",\"multi_column_order\":\"\",\"show_subcategory_content\":\"\",\"orderby_pri\":\"\",\"orderby_sec\":\"\",\"order_date\":\"\",\"show_pagination\":\"\",\"show_pagination_results\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_readmore\":\"\",\"show_readmore_title\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"show_feed_link\":\"\",\"feed_summary\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"Blogs\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"blogs, work abroad, jobs abroad, jobs, abroad\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"\",\"s5_group_child\":\"0\"}',93,94,0,'*',0),(266,'top-menu','Home (6)','2012-10-12-14-57-16','','2012-10-12-14-57-16','index.php?Itemid=','alias',-2,1,1,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"aliasoptions\":\"208\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"\",\"s5_group_child\":\"0\"}',95,96,0,'*',0),(268,'main','eXtplorer','extplorer','','extplorer','index.php?option=com_extplorer&tmpl=component','component',0,1,1,10087,0,'0000-00-00 00:00:00',0,1,'class:component',0,'',293,294,0,'',1),(269,'main','COM_FOXCONTACT_MENU','com-foxcontact-menu','','com-foxcontact-menu','index.php?option=com_foxcontact','component',0,1,1,10090,0,'0000-00-00 00:00:00',0,1,'class:component',0,'',295,296,0,'',1),(275,'mainmenu','Employers','employer','','employer','index.php?option=com_jsjobs&view=employer&layout=controlpanel','component',1,1,1,10050,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"Employer\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"employer,company,jobs\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"Recruiters\",\"s5_group_child\":\"0\"}',199,200,0,'*',0),(276,'mainmenu','Newest Jobs','newest-jobs','','jobs/newest-jobs','index.php?option=com_jsjobs&view=jobseeker&layout=listnewestjobs','component',-2,223,2,10050,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"Newest Jobs\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"newest jobs,jobs,new job\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"Newst jobs abroad & locally\",\"s5_group_child\":\"0\"}',142,143,0,'*',0),(277,'mainmenu','Jobs Posting','jobs-list','','jobs-list','index.php?option=com_jsjobs&view=jobseeker&layout=jobcat','component',-2,1,1,10050,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"Jobs List by Category\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"jobs list by category\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"Jobs Posting by Category\",\"s5_group_child\":\"0\"}',297,298,0,'*',0),(278,'mainmenu','Control Panel','control-panel','','job-seekers/control-panel','index.php?option=com_jsjobs&view=jobseeker&layout=controlpanel','component',-2,134,2,10050,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"Job Seekers Control Panel\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"job seekers control panel\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"Job seekers control panel\",\"s5_group_child\":\"0\"}',196,197,0,'*',0),(279,'mainmenu','Register','registration','','registration','index.php?option=com_jsjobs&view=jobseeker&layout=userregister&userrole=1','component',-2,1,1,10050,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"User Registration\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"User Registration\",\"s5_group_child\":\"0\"}',135,136,0,'*',0),(280,'top-menu','Contact Us','contact-us','','contact-us','index.php?option=com_foxcontact&view=foxcontact','component',1,1,1,10090,0,'0000-00-00 00:00:00',0,1,'',0,'{\"to_address\":\"info@poec.org\",\"cc_address\":\"admin@poec.org\",\"bcc_address\":\"\",\"email_subject\":\"Message thru Website Contact Us Form\",\"jmessenger_user\":\"0\",\"page_subheading\":\"\",\"form__width\":{\"text\":\"\",\"select\":\"auto\"},\"customhtml0\":\"\",\"customhtml0display\":\"1\",\"customhtml0order\":\"-1000\",\"customhtml1\":\"\",\"customhtml1display\":\"1\",\"customhtml1order\":\"1000\",\"labelsdisplay\":\"1\",\"form_layout\":\"extended\",\"labels__width\":{\"text\":\"230\",\"select\":\"px\"},\"sender0\":\"Name\",\"sender0display\":\"2\",\"sender0order\":\"5\",\"sender1\":\"Email\",\"sender1display\":\"2\",\"sender1order\":\"10\",\"sender1isemail\":\"1\",\"text0\":\"\",\"text0display\":\"0\",\"text0order\":\"15\",\"text1\":\"\",\"text1display\":\"0\",\"text1order\":\"20\",\"text2\":\"\",\"text2display\":\"0\",\"text2order\":\"25\",\"text3\":\"\",\"text3display\":\"0\",\"text3order\":\"30\",\"text4\":\"\",\"text4display\":\"0\",\"text4order\":\"35\",\"text5\":\"\",\"text5display\":\"0\",\"text5order\":\"40\",\"text6\":\"\",\"text6display\":\"0\",\"text6order\":\"45\",\"text7\":\"\",\"text7display\":\"0\",\"text7order\":\"50\",\"text8\":\"\",\"text8display\":\"0\",\"text8order\":\"55\",\"text9\":\"\",\"text9display\":\"0\",\"text9order\":\"60\",\"text__width\":{\"text\":\"270\",\"select\":\"px\"},\"dropdown0\":\"\",\"dropdown0display\":\"0\",\"dropdown0values\":\"\",\"dropdown0order\":\"65\",\"dropdown1\":\"\",\"dropdown1display\":\"0\",\"dropdown1values\":\"\",\"dropdown1order\":\"70\",\"dropdown2\":\"\",\"dropdown2display\":\"0\",\"dropdown2values\":\"\",\"dropdown2order\":\"75\",\"dropdown__width\":{\"text\":\"270\",\"select\":\"px\"},\"textarea0\":\"Your Message\",\"textarea0display\":\"1\",\"textarea0order\":\"80\",\"textarea1\":\"\",\"textarea1display\":\"0\",\"textarea1order\":\"85\",\"textarea2\":\"\",\"textarea2display\":\"0\",\"textarea2order\":\"90\",\"textarea__width\":{\"text\":\"270\",\"select\":\"px\"},\"textarea__height\":{\"text\":\"180\",\"select\":\"px\"},\"checkbox0\":\"\",\"checkbox0display\":\"0\",\"checkbox0order\":\"95\",\"checkbox1\":\"\",\"checkbox1display\":\"0\",\"checkbox1order\":\"100\",\"checkbox2\":\"\",\"checkbox2display\":\"0\",\"checkbox2order\":\"105\",\"checkbox3\":\"\",\"checkbox3display\":\"0\",\"checkbox3order\":\"110\",\"checkbox4\":\"\",\"checkbox4display\":\"0\",\"checkbox4order\":\"115\",\"uploaddisplay\":\"0\",\"uploadmethod\":\"1\",\"upload\":\"\",\"uploadmax_file_size\":\"102400\",\"upload_filter\":\"1\",\"upload_audio\":\"0\",\"upload_video\":\"0\",\"upload_images\":\"1\",\"upload_documents\":\"1\",\"upload_archives\":\"1\",\"submittext\":\"Send\",\"submittype\":\"0\",\"submiticon\":\"mail-small.png\",\"submitimage\":\"-1\",\"resetbutton\":\"1\",\"resettext\":\"Cancel\",\"resettype\":\"0\",\"reseticon\":\"cross.png\",\"resetimage\":\"-1\",\"email_sent_action\":\"0\",\"email_sent_text\":\"\",\"email_sent_textdisplay\":\"1\",\"email_sent_page\":\"208\",\"copy_to_submitter\":\"1\",\"email_copy_subject\":\"Your message sent to POEC Infodesk\",\"email_copy_text\":\"Your message has been sent to our Infodesk. We will get back to you as soon as possible. \",\"email_copy_summary\":\"1\",\"spam_check\":\"1\",\"spam_words\":\"\",\"spam_detected_text\":\"\",\"spam_detected_textdisplay\":\"1\",\"stdcaptchadisplay\":\"1\",\"stdcaptcha\":\"\",\"stdcaptchatype\":\"0\",\"stdcaptcha_length\":\"5\",\"stdcaptchawidth\":\"150\",\"stdcaptchaheight\":\"75\",\"stdcaptchafont\":\"-1\",\"stdcaptchafontmin\":\"14\",\"stdcaptchafontmax\":\"20\",\"stdcaptchaangle\":\"20\",\"stdcaptcha_backgroundcolor\":\"#ffffff\",\"stdcaptcha_textcolor\":\"#191919\",\"stdcaptcha_disturbcolor\":\"#c8c8c8\",\"css\":\"bootstrap.css\",\"acymailing\":\"0\",\"acymailing_checkboxes\":\"hidden|hidden\",\"acymailing_auto_checked\":\"0\",\"jnews\":\"0\",\"jnews_checkboxes\":\"hidden|hidden\",\"jnews_auto_checked\":\"0\",\"othernewsletters\":\"1\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"\",\"s5_group_child\":\"0\"}',299,300,0,'*',0),(281,'top-menu','Employers','employers','','topmenu-faq/employers','index.php?option=com_content&view=article&id=298','component',1,263,2,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_tags\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"\",\"s5_group_child\":\"0\"}',88,89,0,'*',0),(282,'main','com_postinstall','Post-installation messages','','Post-installation messages','index.php?option=com_postinstall','component',0,1,1,32,0,'0000-00-00 00:00:00',0,1,'class:postinstall',0,'',47,48,0,'*',1),(283,'hidden-menu','Register','register','','register','index.php?option=com_jsjobs&view=jobseeker&layout=userregister&userrole=1','component',1,1,1,10050,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"\",\"s5_group_child\":\"0\"}',301,302,0,'*',0),(284,'hidden-menu','Login','login','','login','index.php?option=com_users&view=login','component',1,1,1,25,0,'0000-00-00 00:00:00',0,1,'',0,'{\"login_redirect_url\":\"\",\"logindescription_show\":\"1\",\"login_description\":\"\",\"login_image\":\"\",\"logout_redirect_url\":\"\",\"logoutdescription_show\":\"1\",\"logout_description\":\"\",\"logout_image\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"\",\"s5_group_child\":\"0\"}',303,304,0,'*',0),(290,'main','COM_KUNENA','com-kunena','','com-kunena','index.php?option=com_kunena','component',0,1,1,10101,0,'0000-00-00 00:00:00',0,1,'components/com_kunena/media/icons/favicons/kunena-logo-white.png',0,'',305,328,0,'',1),(291,'main','COM_KUNENA_DASHBOARD','com-kunena-dashboard','','com-kunena/com-kunena-dashboard','index.php?option=com_kunena&view=cpanel','component',0,290,2,10101,0,'0000-00-00 00:00:00',0,1,'components/com_kunena/media/icons/favicons/kunena-logo-white.png',0,'',306,307,0,'',1),(292,'main','COM_KUNENA_CATEGORY_MANAGER','com-kunena-category-manager','','com-kunena/com-kunena-category-manager','index.php?option=com_kunena&view=categories','component',0,290,2,10101,0,'0000-00-00 00:00:00',0,1,'components/com_kunena/media/icons/favicons/kunena-categories.png',0,'',308,309,0,'',1),(293,'main','COM_KUNENA_USER_MANAGER','com-kunena-user-manager','','com-kunena/com-kunena-user-manager','index.php?option=com_kunena&view=users','component',0,290,2,10101,0,'0000-00-00 00:00:00',0,1,'components/com_kunena/media/icons/favicons/kunena-users.png',0,'',310,311,0,'',1),(294,'main','COM_KUNENA_FILE_MANAGER','com-kunena-file-manager','','com-kunena/com-kunena-file-manager','index.php?option=com_kunena&view=attachments','component',0,290,2,10101,0,'0000-00-00 00:00:00',0,1,'components/com_kunena/media/icons/favicons/kunena-files.png',0,'',312,313,0,'',1),(295,'main','COM_KUNENA_EMOTICON_MANAGER','com-kunena-emoticon-manager','','com-kunena/com-kunena-emoticon-manager','index.php?option=com_kunena&view=smilies','component',0,290,2,10101,0,'0000-00-00 00:00:00',0,1,'components/com_kunena/media/icons/favicons/kunena-smileys.png',0,'',314,315,0,'',1),(296,'main','COM_KUNENA_RANK_MANAGER','com-kunena-rank-manager','','com-kunena/com-kunena-rank-manager','index.php?option=com_kunena&view=ranks','component',0,290,2,10101,0,'0000-00-00 00:00:00',0,1,'components/com_kunena/media/icons/favicons/kunena-ranks.png',0,'',316,317,0,'',1),(297,'main','COM_KUNENA_TEMPLATE_MANAGER','com-kunena-template-manager','','com-kunena/com-kunena-template-manager','index.php?option=com_kunena&view=templates','component',0,290,2,10101,0,'0000-00-00 00:00:00',0,1,'components/com_kunena/media/icons/favicons/kunena-templates.png',0,'',318,319,0,'',1),(298,'main','COM_KUNENA_CONFIGURATION','com-kunena-configuration','','com-kunena/com-kunena-configuration','index.php?option=com_kunena&view=config','component',0,290,2,10101,0,'0000-00-00 00:00:00',0,1,'components/com_kunena/media/icons/favicons/kunena-prune.png',0,'',320,321,0,'',1),(299,'main','COM_KUNENA_PLUGIN_MANAGER','com-kunena-plugin-manager','','com-kunena/com-kunena-plugin-manager','index.php?option=com_kunena&view=plugins','component',0,290,2,10101,0,'0000-00-00 00:00:00',0,1,'components/com_kunena/media/icons/favicons/kunena-plugins.png',0,'',322,323,0,'',1),(300,'main','COM_KUNENA_FORUM_TOOLS','com-kunena-forum-tools','','com-kunena/com-kunena-forum-tools','index.php?option=com_kunena&view=tools','component',0,290,2,10101,0,'0000-00-00 00:00:00',0,1,'components/com_kunena/media/icons/favicons/kunena-config.png',0,'',324,325,0,'',1),(301,'main','COM_KUNENA_TRASH_MANAGER','com-kunena-trash-manager','','com-kunena/com-kunena-trash-manager','index.php?option=com_kunena&view=trash','component',0,290,2,10101,0,'0000-00-00 00:00:00',0,1,'components/com_kunena/media/icons/favicons/kunena-trash.png',0,'',326,327,0,'',1),(302,'kunenamenu','Forum','forum','','forum','index.php?option=com_kunena&view=home&defaultmenu=304','component',1,1,1,10101,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"catids\":0}',329,346,0,'*',0),(303,'kunenamenu','Index','index','','forum/index','index.php?option=com_kunena&view=category&layout=list','component',1,302,2,10101,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',330,331,0,'*',0),(304,'kunenamenu','Recent Topics','recent','','forum/recent','index.php?option=com_kunena&view=topics&mode=replies','component',1,302,2,10101,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"topics_catselection\":\"\",\"topics_categories\":\"\",\"topics_time\":720}',332,333,0,'*',0),(305,'kunenamenu','New Topic','newtopic','','forum/newtopic','index.php?option=com_kunena&view=topic&layout=create','component',1,302,2,10101,0,'0000-00-00 00:00:00',0,2,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',334,335,0,'*',0),(306,'kunenamenu','No Replies','noreplies','','forum/noreplies','index.php?option=com_kunena&view=topics&mode=noreplies','component',1,302,2,10101,0,'0000-00-00 00:00:00',0,2,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"topics_catselection\":\"\",\"topics_categories\":\"\",\"topics_time\":-1}',336,337,0,'*',0),(307,'kunenamenu','My Topics','mylatest','','forum/mylatest','index.php?option=com_kunena&view=topics&layout=user&mode=default','component',1,302,2,10101,0,'0000-00-00 00:00:00',0,2,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"topics_catselection\":\"2\",\"topics_categories\":\"0\",\"topics_time\":-1}',338,339,0,'*',0),(308,'kunenamenu','Profile','profile','','forum/profile','index.php?option=com_kunena&view=user','component',1,302,2,10101,0,'0000-00-00 00:00:00',0,2,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"integration\":1}',340,341,0,'*',0),(309,'kunenamenu','Help','help','','forum/help','index.php?option=com_kunena&view=misc','component',1,302,2,10101,0,'0000-00-00 00:00:00',0,3,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"body\":\"This help page is a menu item inside [b]Kunena Menu[\\/b], which allows easy navigation in your forum. \\n\\n You can use Joomla Menu Manager to edit items in this menu. Please go to [b]Administration[\\/b] >> [b]Menus[\\/b] >> [b]Kunena Menu[\\/b] >> [b]Help[\\/b] to edit or remove this menu item. \\n\\n In this menu item you can use Plain Text, BBCode or HTML. If you want to bind article into this page, you may use article BBCode (with article id): [code][article=full]123[\\/article][\\/code] \\n\\n If you want to create your own menu for Kunena, please start by creating [b]Home Page[\\/b] first. In that page you can select default menu item, which is shown when you enter to Kunena.\",\"body_format\":\"bbcode\"}',342,343,0,'*',0),(310,'kunenamenu','Search','search','','forum/search','index.php?option=com_kunena&view=search','component',1,302,2,10101,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',344,345,0,'*',0),(311,'mainmenu','Forum','kunena-forum','','kunena-forum','index.php?Itemid=302','alias',1,1,1,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"aliasoptions\":\"302\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"s5_load_mod\":\"0\",\"s5_columns\":\"1\",\"s5_subtext\":\"Community\",\"s5_group_child\":\"0\"}',347,348,0,'*',0),(312,'main','JCE','jce','','jce','index.php?option=com_jce','component',0,1,1,10094,0,'0000-00-00 00:00:00',0,1,'components/com_jce/media/img/menu/logo.png',0,'',351,360,0,'',1),(313,'main','WF_MENU_CPANEL','wf-menu-cpanel','','jce/wf-menu-cpanel','index.php?option=com_jce','component',0,312,2,10094,0,'0000-00-00 00:00:00',0,1,'components/com_jce/media/img/menu/jce-cpanel.png',0,'',352,353,0,'',1),(314,'main','WF_MENU_CONFIG','wf-menu-config','','jce/wf-menu-config','index.php?option=com_jce&view=config','component',0,312,2,10094,0,'0000-00-00 00:00:00',0,1,'components/com_jce/media/img/menu/jce-config.png',0,'',354,355,0,'',1),(315,'main','WF_MENU_PROFILES','wf-menu-profiles','','jce/wf-menu-profiles','index.php?option=com_jce&view=profiles','component',0,312,2,10094,0,'0000-00-00 00:00:00',0,1,'components/com_jce/media/img/menu/jce-profiles.png',0,'',356,357,0,'',1),(316,'main','WF_MENU_INSTALL','wf-menu-install','','jce/wf-menu-install','index.php?option=com_jce&view=installer','component',0,312,2,10094,0,'0000-00-00 00:00:00',0,1,'components/com_jce/media/img/menu/jce-install.png',0,'',358,359,0,'',1),(317,'main','JS_JOBS','js-jobs','','js-jobs','index.php?option=com_jsjobs','component',0,1,1,10050,0,'0000-00-00 00:00:00',0,1,'../administrator/components/com_jsjobs/include/images/js.png',0,'',361,362,0,'',1);
/*!40000 ALTER TABLE `jom_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_menu_types`
--

DROP TABLE IF EXISTS `jom_menu_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_menu_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menutype` varchar(24) NOT NULL,
  `title` varchar(48) NOT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_menutype` (`menutype`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_menu_types`
--

LOCK TABLES `jom_menu_types` WRITE;
/*!40000 ALTER TABLE `jom_menu_types` DISABLE KEYS */;
INSERT INTO `jom_menu_types` (`id`, `menutype`, `title`, `description`) VALUES (1,'mainmenu','Main Menu','The main menu for the site'),(2,'top-bottom-menu','Bottom Menu',''),(9,'top-menu','Top Menu',''),(10,'hidden-menu','Hidden Menu',''),(11,'kunenamenu','Kunena Menu','This is the default Kunena menu. It is used as the top navigation for Kunena. It can be publish in any module position. Simply unpublish items that are not required.');
/*!40000 ALTER TABLE `jom_menu_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_messages`
--

DROP TABLE IF EXISTS `jom_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_messages` (
  `message_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id_from` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id_to` int(10) unsigned NOT NULL DEFAULT '0',
  `folder_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `priority` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` text NOT NULL,
  PRIMARY KEY (`message_id`),
  KEY `useridto_state` (`user_id_to`,`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_messages`
--

LOCK TABLES `jom_messages` WRITE;
/*!40000 ALTER TABLE `jom_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_messages_cfg`
--

DROP TABLE IF EXISTS `jom_messages_cfg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_messages_cfg` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `cfg_name` varchar(100) NOT NULL DEFAULT '',
  `cfg_value` varchar(255) NOT NULL DEFAULT '',
  UNIQUE KEY `idx_user_var_name` (`user_id`,`cfg_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_messages_cfg`
--

LOCK TABLES `jom_messages_cfg` WRITE;
/*!40000 ALTER TABLE `jom_messages_cfg` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_messages_cfg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_modules`
--

DROP TABLE IF EXISTS `jom_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `title` varchar(100) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `position` varchar(50) NOT NULL DEFAULT '',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `module` varchar(50) DEFAULT NULL,
  `access` int(10) unsigned DEFAULT NULL,
  `showtitle` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `published` (`published`,`access`),
  KEY `newsfeeds` (`module`,`published`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB AUTO_INCREMENT=198 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_modules`
--

LOCK TABLES `jom_modules` WRITE;
/*!40000 ALTER TABLE `jom_modules` DISABLE KEYS */;
INSERT INTO `jom_modules` (`id`, `asset_id`, `title`, `note`, `content`, `ordering`, `position`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `published`, `module`, `access`, `showtitle`, `params`, `client_id`, `language`) VALUES (2,0,'Login','','',1,'login',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_login',1,1,'',1,'*'),(3,0,'Popular Articles','','',3,'cpanel',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_popular',3,1,'{\"count\":\"5\",\"catid\":\"\",\"user_id\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\",\"automatic_title\":\"1\"}',1,'*'),(4,0,'Recently Added Articles','','',4,'cpanel',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_latest',3,1,'{\"count\":\"5\",\"ordering\":\"c_dsc\",\"catid\":\"\",\"user_id\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\",\"automatic_title\":\"1\"}',1,'*'),(6,0,'Unread Messages','','',1,'header',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_unread',3,1,'',1,'*'),(7,0,'Online Users','','',2,'header',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_online',3,1,'',1,'*'),(8,0,'Toolbar','','',1,'toolbar',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_toolbar',3,1,'',1,'*'),(9,0,'Quick Icons','','',1,'icon',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_quickicon',3,1,'',1,'*'),(10,0,'Logged-in Users','','',2,'cpanel',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_logged',3,1,'{\"count\":\"5\",\"name\":\"1\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\",\"automatic_title\":\"1\"}',1,'*'),(12,0,'Admin Menu','','',1,'menu',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_menu',3,1,'{\"layout\":\"\",\"moduleclass_sfx\":\"\",\"shownew\":\"1\",\"showhelp\":\"1\",\"cache\":\"0\"}',1,'*'),(13,0,'Admin Submenu','','',1,'submenu',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_submenu',3,1,'',1,'*'),(14,0,'User Status','','',2,'status',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_status',3,1,'',1,'*'),(15,0,'Title','','',1,'title',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_title',3,1,'',1,'*'),(19,0,'Main Menu','','',1,'right',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_menu',1,1,'{\"menutype\":\"mainmenu\",\"startLevel\":\"1\",\"endLevel\":\"0\",\"showAllChildren\":\"0\",\"tag_id\":\"\",\"class_sfx\":\"\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"-background\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\"}',0,'*'),(21,0,'Login','','',1,'login',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',-2,'mod_login',1,1,'{\"pretext\":\"\",\"posttext\":\"\",\"login\":\"\",\"logout\":\"\",\"greeting\":\"1\",\"name\":\"0\",\"usesecure\":\"0\",\"usetext\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(22,0,'Statistics','','',9,'right',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_stats',1,1,'{\"serverinfo\":\"1\",\"siteinfo\":\"1\",\"counter\":\"1\",\"increase\":\"0\",\"moduleclass_sfx\":\"\",\"cache\":\"0\",\"cache_time\":\"900\"}',0,'*'),(23,0,'Guests Online','','',11,'right',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_whosonline',1,1,'{\"showmode\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\",\"filter_groups\":\"0\"}',0,'*'),(24,0,'Popular Articles','','',1,'bottom_row3_2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_articles_popular',1,1,'{\"catid\":[\"\"],\"count\":\"4\",\"show_front\":\"1\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(25,0,'Archive','','',2,'left',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_articles_archive',1,1,'{\"count\":10,\"moduleclass_sfx\":\"-blue tester\",\"cache\":1}',0,'*'),(26,0,'Sections','','',4,'left',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_sections',1,1,'{\"count\":\"5\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\"}',0,'*'),(27,0,'Related Items','','',7,'left',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_related_items',1,1,'{}',0,'*'),(28,0,'Search','','',1,'right',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_search',1,1,'{\"label\":\"\",\"width\":\"50\",\"text\":\"\",\"button\":\"\",\"button_pos\":\"right\",\"imagebutton\":\"\",\"button_text\":\"Find\",\"opensearch\":\"1\",\"opensearch_title\":\"\",\"set_itemid\":\"212\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"-highlight\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\"}',0,'*'),(29,0,'Random Image','','',5,'left',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_random_image',1,1,'{\"type\":\"jpg\",\"folder\":\"\",\"link\":\"\",\"width\":\"\",\"height\":\"\",\"moduleclass_sfx\":\"\",\"cache\":\"0\",\"cache_time\":\"900\"}',0,'*'),(30,0,'Banners','','',1,'banner',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_banners',1,0,'{\"target\":\"1\",\"count\":\"1\",\"cid\":\"1\",\"catid\":\"13\",\"tag_search\":\"0\",\"ordering\":\"random\",\"header_text\":\"\",\"footer_text\":\"\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"15\"}',0,'*'),(31,0,'Wrapper','','',4,'bottom_row_1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_wrapper',1,1,'{\"moduleclass_sfx\":\"\",\"url\":\"\",\"scrolling\":\"auto\",\"width\":\"100%\",\"height\":\"200\",\"height_auto\":\"1\",\"add\":\"1\",\"target\":\"\",\"cache\":\"0\",\"cache_time\":\"900\"}',0,'*'),(32,0,'Feed Display','','',1,'above_body_2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_feed',1,1,'{\"rssurl\":\"http:\\/\\/www.poea.gov.ph\\/\",\"rssrtl\":\"0\",\"rsstitle\":\"1\",\"rssdesc\":\"1\",\"rssimage\":\"1\",\"rssitems\":\"3\",\"rssitemdesc\":\"1\",\"word_count\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\",\"cache_time\":\"15\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(33,0,'Breadcrumbs','','',1,'breadcrumb',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_breadcrumbs',1,1,'{\"showHere\":\"0\",\"showHome\":\"1\",\"homeText\":\"Home\",\"showLast\":\"1\",\"separator\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\",\"cache_time\":\"900\",\"cachemode\":\"itemid\"}',0,'*'),(34,0,'Syndication','','',3,'left',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_syndicate',1,1,'{\"cache\":\"0\",\"text\":\"Feed Entries\",\"format\":\"rss\",\"moduleclass_sfx\":\"\"}',0,'*'),(35,0,'Advertisement','','',6,'left',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_banners',1,1,'{\"target\":\"1\",\"count\":\"4\",\"cid\":\"0\",\"catid\":\"14\",\"tag_search\":\"0\",\"ordering\":\"0\",\"header_text\":\"Featured Links:\",\"footer_text\":\"<a href=\\\"http:\\/\\/www.joomla.org\\\">Ads by Joomla!<\\/a>\",\"moduleclass_sfx\":\"_text\",\"cache\":\"0\",\"cache_time\":\"900\"}',0,'*'),(37,0,'Our Latest News','','',2,'bottom_row3_3',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_articles_latest',1,1,'{\"catid\":[\"20\",\"7\",\"8\",\"2\"],\"count\":\"6\",\"show_featured\":\"\",\"ordering\":\"c_dsc\",\"user_id\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"_:static\"}',0,'*'),(38,0,'Quick Menu','','',2,'right',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_s5_accordion_menu',1,1,'{\"menutype\":\"mainmenu\",\"parentlinks\":\"1\",\"startLevel\":\"1\",\"endLevel\":\"0\",\"showAllChildren\":\"1\",\"class_sfx\":\"\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"-dark_title\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(41,0,'Top Row1 Modules','','This is an example of a module published to the top_row_1 row. This row contains 6 modules, read below for a full description.',1,'top_row1_1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(42,0,'Top Row2 Modules','','This is an example of a module published to the top_row_2 row. This row contains 6 modules, read below for a full description.',0,'top_row2_1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"moduleclass_sfx\":\"\"}',0,'*'),(43,0,'Top Row3 Modules','','<p>This is an example of a module published to the top_row_3 row. This row contains 6 modules, read below for a full description.</p>',3,'top_row3_1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"moduleclass_sfx\":\"\"}',0,'*'),(44,0,'Bottom Row1 Modules','','This is an example of a module published to the bottom_row_1 row. This row contains 6 modules, read above for a full description.',4,'bottom_row1_1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"moduleclass_sfx\":\"\"}',0,'*'),(45,0,'Bottom Row2 Modules','','This is an example of a module published to the bottom_row_2 row. This row contains 6 modules, read above for a full description.',0,'bottom_row2_1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"moduleclass_sfx\":\"\"}',0,'*'),(46,0,'Bottom Row3 Modules','','This is an example of a module published to the bottom_row_3 row. This row contains 6 modules, read above for a full description.',1,'bottom_row3_1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"moduleclass_sfx\":\"\"}',0,'*'),(51,0,'Right','','This is an example of a module published to the right position. There are also left, insets, rows, etc. positions and many others, be sure to read the full description. This is the default style that will appear for most module positions in the white body area.',5,'right',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(52,0,'Right Inset','','This is an example of a module published to the right_inset position. There is also a left_inset position and many others, be sure to read the full description.',1,'right_inset',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(53,0,'Register','','',1,'register',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_s5_register',1,1,'{\"moduleclass_sfx\":\"\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(54,0,'Quick Links/Downloads','','<p><em><strong>Government Agencies Websites:</strong></em></p>\r\n<p><a href=\"http://www.president.gov.ph\">Office of the President</a></p>\r\n<p><a href=\"http://www.dole.gov.ph/\">Department of Labour &amp; Employment</a></p>\r\n<p><a href=\"http://www.dfa.gov.ph/\">Department of Foreign Affairs</a></p>\r\n<p><a href=\"http://www.owwa.gov.ph\">POEA</a> | <a href=\"http://www.owwa.gov.ph\">OWWA</a> | <a href=\"http://www.philhealth.gov.ph/\">PHILHEALTH</a> | <a href=\"http://www.tesda.gov.ph/\">TESDA</a> | <a href=\"http://www.pagibigfund.gov.ph/\">PAG-IBIG</a></p>\r\n<p><a href=\"http://www.mtc.gov.ph/\">Maritime Training Council</a></p>\r\n<p><a href=\"http://www.sss.gov.ph/\">Social Security System</a></p>\r\n<p><a href=\"http://www.doh.gov.ph/\">Department of Health</a></p>\r\n<p>&nbsp;</p>\r\n<p><em><strong>Downloadables:</strong></em></p>\r\n<p><a href=\"http://www.poea.gov.ph/ofw/BMinfoSheet_23Oct2012.pdf\">Balik-Manggagawa Info Sheet</a></p>\r\n<p><a href=\"http://www.poea.gov.ph/docs/sec_various_new.pdf\">Standard Employment Contract for Various Skills</a></p>\r\n<p><a href=\"http://www.poea.gov.ph/docs/sec_seafarers_new.pdf\">Standard Employment Contract for Seafarers</a></p>\r\n<p><a href=\"http://www.poea.gov.ph/agency/MARITIMEWATCH%20FORM.xls\">Maritime Watch Monitoring Form</a></p>\r\n<p><a href=\"http://www.poea.gov.ph/stats/statistics.htm\">Statistics</a></p>',1,'bottom_row3_1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(55,0,'Our Partners','','<p>Our partners&nbsp;<a href=\"index.php/tutorials-mainmenu-48/site-shaper-setup\"></a></p>',1,'bottom_row3_1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_custom',1,1,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(56,0,'Bottom Menu','','',1,'bottom_menu',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_menu',1,1,'{\"menutype\":\"top-bottom-menu\",\"startLevel\":\"1\",\"endLevel\":\"1\",\"showAllChildren\":\"0\",\"tag_id\":\"\",\"class_sfx\":\"\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\"}',0,'*'),(58,0,'Featured News','','',0,'right_inset',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_articles_news',1,0,'{\"layout\":\"vertical\",\"image\":\"0\",\"link_titles\":\"1\",\"showLastSeparator\":\"0\",\"item_title\":\"1\",\"moduleclass_sfx\":\"\",\"cache\":\"0\",\"cache_time\":\"900\",\"catid\":[\"22\"],\"item_heading\":\"h4\",\"count\":\"5\",\"ordering\":\"a.publish_up\",\"cachemode\":\"itemid\"}',0,'*'),(62,0,'S5 Flex Menu Sample Module','','<div style=\"width:182px;font-size:0.85em\"><div style=\"float:left\"><img style=\"width:72px\" src=\"http://www.shape5.com/demo/images/multibox3.jpg\" alt=\"\" /></div>This is a sample module to showcase the functionality of the S5 Flex Menu system. This menu system contains up to 40 module positions and you can publish any module to any of these positions under any menu item.</div>',1,'s5_menu1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(66,0,'Sample Drop Down Module','','This is an example of a module published to the drop_down row. This row contains 6 modules. To enable the drop down simple publish any module to any of the drop_down_x positions.',0,'drop_down_1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"moduleclass_sfx\":\"\"}',0,'*'),(67,0,'Banner Position','','This is a custom html module published to the \'banner\' position with the suffix -style1 applied.',2,'banner',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_custom',1,1,'{\"moduleclass_sfx\":\"-style1\"}',0,'*'),(79,0,'Multilanguage status','','',1,'status',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_multilangstatus',3,1,'{\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\"}',1,'*'),(80,0,'Joomla Version','','',1,'footer',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_version',3,1,'{\"format\":\"short\",\"product\":\"1\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\"}',1,'*'),(81,0,'Search','','',5,'right',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_finder',1,0,'{\"searchfilter\":\"\",\"show_autosuggest\":\"1\",\"show_advanced\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"-highlight\",\"field_size\":28,\"alt_label\":\"\",\"show_label\":\"1\",\"label_pos\":\"top\",\"show_button\":\"0\",\"button_pos\":\"right\",\"opensearch\":\"1\",\"opensearch_title\":\"\"}',0,'*'),(111,0,'S5 Box','','',1,'bottom_menu',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_s5_box',1,1,'{\"s5_jsversion\":\"jquery\",\"s5_boxeffect\":\"elastic\",\"s5boxwidth1\":\"35\",\"s5boxwidth2\":\"35\",\"s5boxwidth3\":\"35\",\"s5boxwidth4\":\"35\",\"s5boxwidth5\":\"35\",\"s5boxwidth6\":\"35\",\"s5boxwidth7\":\"35\",\"s5boxwidth8\":\"35\",\"s5boxwidth9\":\"35\",\"s5boxwidth10\":\"35\",\"moduleclass_sfx\":\"-s5_box\"}',0,'*'),(112,0,'S5 Image and Content Fader v3','','',1,'custom_1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_s5_image_and_content_fader',1,0,'{\"pretext\":\"\",\"moduleclass_sfx\":\"\",\"height\":\"430px\",\"width\":\"100%\",\"s5stretchimage\":\"stretch\",\"s5pixelwidth\":\"0px\",\"background\":\"212121\",\"jslibrary\":\"mootools\",\"jseffect\":\"continuoushorizontal\",\"s5_dropdowntext\":\"Open Gallery\",\"s5_delay\":\"7000\",\"s5_slide_opacity\":\"70\",\"s5_hidecar\":\"falsee\",\"s5_hidebut\":\"truee\",\"s5_hidetext\":\"truee\",\"title1\":\"Your dream jobs abroad\",\"title2\":\"Santarli Training & Testing Center\",\"title3\":\"Paid Ads Here...\",\"title4\":\"\",\"title5\":\"\",\"title6\":\"\",\"title7\":\"\",\"title8\":\"\",\"title9\":\"\",\"title10\":\"\",\"picture1\":\"images\\/iacf1.jpg\",\"picture1link\":\"index.php\\/features-mainmenu-47\\/template-specific-features\",\"picture1text\":\"Jobs abroad available! Hiring now!\\r\\n<a href=\\\"index.php\\/features-mainmenu-47\\/template-specific-features\\\">Read More...<\\/a>\",\"picture2\":\"images\\/iacf2.jpg\",\"picture2link\":\"index.php\\/features-mainmenu-47\\/template-features\\/responsive-layout\",\"picture2text\":\"Santarli unboxes your opportunities abroad...\\r\\n<a href=\\\"index.php\\/features-mainmenu-47\\/template-features\\/responsive-layout\\\">Read More...<\\/a>\",\"picture3\":\"images\\/iacf3.jpg\",\"picture3link\":\"index.php\\/extensions\\/s5-flex-menu-1360\",\"picture3text\":\"This section can be for paid ads.\\r\\n<a href=\\\"index.php\\/extensions\\/s5-flex-menu-1360\\\">Read More...<\\/a>\",\"picture4\":\"\",\"picture4link\":\"\",\"picture4text\":\"\",\"picture5\":\"\",\"picture5link\":\"\",\"picture5text\":\"\",\"picture6\":\"\",\"picture6link\":\"\",\"picture6text\":\"\",\"picture7\":\"\",\"picture7link\":\"\",\"picture7text\":\"\",\"picture8\":\"\",\"picture8link\":\"\",\"picture8text\":\"\",\"picture9\":\"\",\"picture9link\":\"\",\"picture9text\":\"\",\"picture10\":\"\",\"picture10link\":\"\",\"picture10text\":\"\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(146,0,'Contact Us','','<p>Visit our office located at:</p>\r\n<p><span class=\"null\">3F, 1770 A. Mabini St., Malate, Manila&nbsp;</span></p>\r\n<p>For more information, please don\'t hesitate to contact us.<br /> <img style=\"float: left; margin-right: 10px;\" src=\"images/phone.png\" alt=\"\" /><span style=\"float: left;\">(02) 353-5523</span></p>\r\n<div style=\"clear: both; width: 10px; height: 5px;\">&nbsp;</div>\r\n<p><img style=\"float: left; margin-right: 10px;\" src=\"images/email.png\" alt=\"\" /><span style=\"float: left;\"><a href=\"mailto:info@poec.org\">info@poec.org</a> | Admin: <a href=\"mailto:admin@poec.org\">admin@poec.org</a> <br /></span></p>',1,'bottom_row3_2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(147,0,'S5 Tab Show','','',1,'bottom_row1_1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_s5_tabshow',1,0,'{\"pretext\":\"\",\"moduleclass_sfx\":\"\",\"s5_width\":\"1000\",\"s5_buttonheight\":\"27px\",\"s5_lineheight\":\"2.2em\",\"s5_buttoncolor\":\"transparent\",\"s5_buttonimage\":\"..\\/modules\\/mod_s5_tabshow\\/s5_tabshow\\/s5_tab_show_nonactive.png\",\"s5_hovercolor\":\"#FFFFFF\",\"s5_hoverimage\":\"..\\/modules\\/mod_s5_tabshow\\/s5_tabshow\\/s5_tab_show_active.png\",\"s5_fontcolor\":\"#000000\",\"s5_javascript\":\"mootools\",\"s5_mootoolsmouse\":\"mouse\",\"s5_effectsani\":\"fade\",\"s5_effectmouse\":\"mouse\",\"text1line\":\"Who We Are\",\"text2line\":\"More About Us\",\"text3line\":\"\",\"text4line\":\"\",\"text5line\":\"\",\"text6line\":\"\",\"text7line\":\"\",\"text8line\":\"\",\"text9line\":\"\",\"text10line\":\"\"}',0,'*'),(148,0,'Tab 1','','<div class=\"tab_left\">\r\n<div class=\"tab_left_inner\">\r\n<h2>We work hard to offer you the best</h2>\r\n<span> Guided by our vision and principles, we work hard to make sure that we deliver for you the best. We properly validate and scrutinize employers-recruiters to make sure that they are POEA-approved and certified, with no bad track record. </span></div>\r\n<div class=\"tab_left_inner\">In the same manner, we make sure to train and coach our job seekers in order to empower and prepare them to be professional and skillful with global competitiveness and competencies.<br /> <br /> <br /> <a class=\"s5_readon\" href=\"index.php/component/content/article?id=277\">Learn More</a>\r\n<div style=\"clear: both;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n<div class=\"tab_right\">\r\n<div class=\"tab_row1\">\r\n<div class=\"tab_row1_inner\">\r\n<div class=\"tab_box1\">\r\n<div class=\"tab_box\"><img src=\"images/tab2.jpg\" alt=\"tab2\" />\r\n<div style=\"clear: both;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n<div class=\"tab_box2\">\r\n<div class=\"tab_box\"><img src=\"images/tab1.jpg\" alt=\"tab1\" />\r\n<div style=\"clear: both;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n<div style=\"clear: both;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n<div class=\"tab_row2\">\r\n<div class=\"tab_row2_inner\">\r\n<div class=\"tab_box3\">\r\n<div class=\"tab_box\"><img src=\"images/tab3.jpg\" alt=\"tab3\" />\r\n<div style=\"clear: both;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n<div class=\"tab_box4\">\r\n<div class=\"tab_box\"><img src=\"images/tab4.jpg\" alt=\"tab4\" />\r\n<div style=\"clear: both;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n<div style=\"clear: both;\">&nbsp;</div>\r\n</div>\r\n</div>\r\n<div style=\"clear: both;\">&nbsp;</div>\r\n</div>',1,'s5_tab1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(149,0,'Tab 2','','<div class=\"tab_text1\"><img class=\"padded\" style=\"width: 44%; margin-bottom: 10px; margin-right: 10px; float: left;\" src=\"images/tab2_image1.jpg\" alt=\"tab2 image1\" width=\"44%\" height=\"391\" /> <span> Philippine Overseas Employment Center (POEC) has affiliates and sister companies like... </span>Put more descriptions here. <br /> <br /> <a class=\"s5_readon\" href=\"index.php/component/content/article?id=277\">Read More</a></div>\r\n<div class=\"tab_text2\"><span><img style=\"margin-right: 10px; margin-bottom: 10px; float: left;\" src=\"images/tab2_image2.jpg\" alt=\"tab2 image2\" width=\"44%\" height=\"NaN\" />Put more descriptions here..</span><br /> <br /> <a class=\"s5_readon\" href=\"index.php/component/content/article?id=277\">Read More</a></div>',1,'s5_tab2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(152,0,'-background','','This is the -background module style and can be applied to most most module positions.',5,'right',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"-background\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(158,0,'-highlight','','This is the -highlight module style and can be applied to most most module positions.',5,'right',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"-highlight\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(159,0,'Homepage Custom3 Module','','<p><span style=\"width: 67%; display: block; margin-left: auto; margin-right: auto; font-size: 1.7em; text-align: center; line-height: 166%;\"> Philippine Overseas Employment Center is <span style=\"color: #808080;\">your passport to your dreams. </span><a class=\"s5_readon\" href=\"http://www.poec.org\" target=\"_blank\">More...</a> </span></p>',1,'custom_3',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(160,0,'Bottom Row - We Are Here To Help','','<p><img class=\"padded\" style=\"margin: 0px 0px 20px;\" src=\"images/row1.jpg\" alt=\"row1\" /> <span style=\"clear: both; display: block;\"></span></p>\r\n<h3 class=\"font_highlight\">We Are Here To Help</h3>\r\n<p><br /> <span style=\"font-size: 0.85em;\"> We open opportunities for Filipino families to work and live abroad by bringing job employers right in your fingertip.</span><br /><br /> <a class=\"readon\" href=\"index.php?option=com_content&amp;view=article&amp;id=277\">Read More...</a></p>',1,'bottom_row2_1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(161,0,'Bottom Row - Easy Job Application','','<p><img class=\"padded\" style=\"margin: 0px 0px 20px;\" src=\"images/row2.jpg\" alt=\"row2\" /> <span style=\"clear: both; display: block;\"></span></p>\r\n<h3 class=\"font_highlight\">Easy Job Online Application</h3>\r\n<p><br /> <span style=\"font-size: 0.85em;\">We provide job posting and recruitment solutions online, and application is easy.&nbsp; Upload your CV, record a video self-introduction and upload to capture the interest of your prospective employer.</span></p>\r\n<p><br /> <a class=\"readon\" href=\"index.php?option=com_content&amp;view=article&amp;id=277\">Read More...</a></p>',1,'bottom_row2_2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(162,0,'Bottom Row - Years Of Experience','','<p><img class=\"padded\" style=\"margin: 0px 0px 20px;\" src=\"images/row3.jpg\" alt=\"row3\" /> <span style=\"clear: both; display: block;\"></span></p>\r\n<h3 class=\"font_highlight\">Years Of Experience</h3>\r\n<p><br /> <span style=\"font-size: 0.85em;\"> We have been in the industry of human resource management pooling and recruitment for the past 20 years in the country and around the world, thus our experience is proven.</span><br /><br /> <a class=\"readon\" href=\"index.php?option=com_content&amp;view=article&amp;id=277\">Read More...</a></p>',1,'bottom_row2_3',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(163,0,'Bottom Row - We Empower You','','<p><img class=\"padded\" style=\"margin: 0px 0px 20px;\" src=\"images/row4.jpg\" alt=\"row4\" /> <span style=\"clear: both; display: block;\"></span></p>\r\n<h3 class=\"font_highlight\">We Empower You</h3>\r\n<p><br /> <span style=\"font-size: 0.85em;\">We empower and equip you with skills and trainings for your professional and career advancement. We see to it that we are confident to recommend you to top high-paying employers around the world. </span> <br /><br /> <a class=\"readon\" href=\"index.php?option=com_content&amp;view=article&amp;id=277\">Read More...</a></p>',1,'bottom_row2_4',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(164,0,'Top Menu','','',1,'top_menu',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_menu',1,1,'{\"menutype\":\"top-menu\",\"startLevel\":\"1\",\"endLevel\":\"1\",\"showAllChildren\":\"0\",\"tag_id\":\"\",\"class_sfx\":\"\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\"}',0,'*'),(165,0,'Upcoming Events','','11.10.2012\r\n<br /><br />\r\nProin magna mi, porttitor eget loboris sit amet, bibendum id orci. Nam arius mollis.\r\n<br /><br />\r\n12.15.2012\r\n<br /><br />\r\nSuspendisse in ipsum ut magna pharetra aliquet non sodales velit. Proin pellenesque.',2,'bottom_row3_2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_custom',1,1,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(167,0,'Custom 3','','This is the custom_3 position.',1,'custom_3',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(168,0,'Custom 2','','This is the custom_2 position.',1,'custom_2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(169,0,'Custom_1','','This row also contains a custom_1 position which shows below the top_row1 positions. We do not recommend publishing other modules to this row when custom_1 is used. Custom_1 is meant specifically for the Image and Content Fader module only. There are several settings for this in the template configuration as well.',2,'top_row1_1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(170,0,'-dark_title','','This is the -dark_title module style and can be applied to most most module positions.',5,'right',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"-dark_title\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(171,0,'-highlight_title','','This is the -highlight_title module style and can be applied to most most module positions.',5,'right',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"-highlight_title\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(172,0,'-highlight_full','','This is the -highlight_full module style and can be applied to most most module positions.',5,'right',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"-highlight_full\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(173,0,'-dark_full','','This is the -dark_full module style and can be applied to most most module positions.',5,'right',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"-dark_full\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(174,0,'Featured Companies','','',1,'',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_jsfeaturedcompanies',1,1,'{\"noofcompanies\":\"7\",\"theme\":\"1\",\"title\":\"Featured Companies\",\"listingstyle\":\"1\",\"shtitle\":\"1\",\"category\":\"1\",\"location\":\"1\",\"posteddate\":\"1\",\"noofcols\":\"3\",\"companyname\":\"1\",\"logo\":\"1\",\"logowidth\":\"130\",\"logoheight\":\"70\",\"separator\":\"1\",\"sliding\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(175,0,'Featured Jobs','','',1,'bottom_row3_3',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_jsfeaturedjobs',1,1,'{\"noofjobs\":\"7\",\"theme\":\"1\",\"title\":\"Featured Jobs\",\"listingstyle\":\"1\",\"shtitle\":\"1\",\"company\":\"1\",\"category\":\"1\",\"subcategory\":\"0\",\"jobtype\":\"1\",\"location\":\"1\",\"posteddate\":\"1\",\"noofcols\":\"3\",\"logo\":\"1\",\"logowidth\":\"130\",\"logoheight\":\"70\",\"separator\":\"1\",\"sliding\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(176,0,'JS Featured Resumes','','',0,'',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_jsfeaturedresumes',1,1,'',0,'*'),(177,0,'JS Gold Companies','','',0,'',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_jsgoldcompanies',1,1,'',0,'*'),(178,0,'JS Gold Jobs','','',0,'',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_jsgoldjobs',1,1,'',0,'*'),(179,0,'JS Gold Resumes','','',0,'',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_jsgoldresumes',1,1,'',0,'*'),(180,0,'Hot Jobs','','',1,'',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_hotjsjobs',1,1,'{\"noofjobs\":\"7\",\"theme\":\"1\",\"company\":\"1\",\"category\":\"1\",\"subcategory\":\"0\",\"jobtype\":\"1\",\"posteddate\":\"1\",\"separator\":\"1\",\"colperrow\":\"\",\"sliding\":\"1\",\"slidingdirection\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(181,0,'Search JS Jobs','','',0,'',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_jsjobssearch',1,1,'',0,'*'),(182,0,'JS Resume Search','','',0,'',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_jsresumesearch',1,1,'',0,'*'),(183,0,'JS Top Resume','','',0,'',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_jstopresume',1,1,'',0,'*'),(184,0,'JS Job Categories','','',0,'',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_jsjobcategories',1,1,'',0,'*'),(185,0,'JS Jobs BY City','','',0,'',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_jsjobscity',1,1,'',0,'*'),(186,0,'JS Jobs BY Country','','',0,'',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_jsjobscountry',1,1,'',0,'*'),(187,173,'JS Jobs Login','','',1,'login',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_jsjobslogin',1,1,'{\"cache\":\"0\",\"moduleclass_sfx\":\"\",\"pretext\":\"\",\"posttext\":\"\",\"login\":\"jsjobs\",\"logout\":\"208\",\"greeting\":\"1\",\"name\":\"0\",\"usesecure\":\"0\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(188,0,'JS Jobs Stats','','',0,'',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_jsjobsstats',1,1,'',0,'*'),(189,0,'Newest JS Jobs','','',0,'',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_newestjsjobs',1,1,'',0,'*'),(190,0,'JS Newest Resumes','','',0,'',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_newestjsresume',1,1,'',0,'*'),(191,0,'Top JS Jobs','','',0,'',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_topjsjobs',1,1,'',0,'*'),(193,0,'Featured Companies','','',1,'bottom_row3_2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',-2,'mod_jsfeaturedcompanies',1,1,'{\"noofcompanies\":\"7\",\"theme\":\"1\",\"title\":\"Featured Companies\",\"listingstyle\":\"1\",\"shtitle\":\"1\",\"category\":\"1\",\"location\":\"1\",\"posteddate\":\"1\",\"noofcols\":\"3\",\"companyname\":\"1\",\"logo\":\"1\",\"logowidth\":\"130\",\"logoheight\":\"70\",\"separator\":\"1\",\"sliding\":\"1\",\"consecutivesliding\":\"3\",\"Itemid\":\"\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(194,171,'Register','','',1,'register',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',-2,'mod_menu',1,0,'{\"menutype\":\"hidden-menu\",\"base\":\"\",\"startLevel\":\"1\",\"endLevel\":\"0\",\"showAllChildren\":\"0\",\"tag_id\":\"\",\"class_sfx\":\"\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(195,172,'Login','','',1,'login',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',-2,'mod_menu',1,1,'{\"menutype\":\"top-bottom-menu\",\"base\":\"\",\"startLevel\":\"1\",\"endLevel\":\"0\",\"showAllChildren\":\"1\",\"tag_id\":\"\",\"class_sfx\":\"\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(196,174,'Login','','',1,'login',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',-2,'mod_menu',1,1,'{\"menutype\":\"hidden-menu\",\"base\":\"284\",\"startLevel\":\"1\",\"endLevel\":\"0\",\"showAllChildren\":\"1\",\"tag_id\":\"\",\"class_sfx\":\"\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(197,176,'JS Jobs BY State','','',0,'',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_jsjobsstates',1,1,'',0,'*');
/*!40000 ALTER TABLE `jom_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_modules_menu`
--

DROP TABLE IF EXISTS `jom_modules_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_modules_menu` (
  `moduleid` int(11) NOT NULL DEFAULT '0',
  `menuid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`moduleid`,`menuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_modules_menu`
--

LOCK TABLES `jom_modules_menu` WRITE;
/*!40000 ALTER TABLE `jom_modules_menu` DISABLE KEYS */;
INSERT INTO `jom_modules_menu` (`moduleid`, `menuid`) VALUES (1,0),(2,0),(3,0),(4,0),(6,0),(7,0),(8,0),(9,0),(10,0),(12,0),(13,0),(14,0),(15,0),(16,0),(17,0),(18,0),(19,0),(21,0),(22,0),(23,110),(23,111),(23,122),(23,123),(23,126),(23,145),(23,146),(23,154),(23,179),(23,182),(23,206),(24,-222),(24,-221),(24,-220),(24,-216),(24,-215),(24,-214),(24,-213),(24,-212),(24,-211),(24,-210),(24,-209),(24,-208),(24,-125),(24,-121),(25,0),(26,0),(28,102),(28,110),(28,123),(28,124),(28,145),(28,146),(28,149),(28,150),(28,198),(28,223),(28,247),(28,248),(30,0),(31,0),(31,1),(32,0),(33,0),(34,0),(35,102),(37,-125),(37,-121),(38,-202),(38,-125),(38,-121),(39,-125),(39,-121),(40,0),(41,121),(41,125),(42,121),(42,125),(43,121),(43,125),(44,121),(44,125),(45,121),(45,125),(46,121),(46,125),(51,121),(51,125),(52,121),(52,125),(53,0),(54,-125),(54,-121),(55,-125),(55,-121),(56,0),(58,102),(62,0),(66,121),(66,125),(66,200),(67,121),(67,125),(79,0),(80,0),(81,0),(97,-125),(97,-121),(99,-125),(99,-121),(111,0),(112,102),(112,206),(121,-125),(121,-121),(146,-125),(146,-121),(147,102),(147,202),(148,0),(149,0),(152,121),(152,125),(158,121),(158,125),(159,102),(160,102),(161,102),(162,102),(163,102),(164,0),(165,-125),(165,-121),(167,121),(167,125),(168,121),(168,125),(169,121),(169,125),(170,121),(170,125),(171,121),(171,125),(172,121),(172,125),(173,121),(173,125),(174,0),(175,0),(180,0),(187,0),(193,0),(194,0),(195,0),(196,0),(248,1),(249,1),(258,1),(259,1),(590,1),(590,2),(590,5),(590,7),(590,8),(590,23),(590,26),(590,27),(590,28),(590,32),(590,33),(590,34),(590,35),(590,36),(590,37),(590,38),(590,47),(590,48),(590,81),(590,88),(590,89),(590,93),(590,96),(590,97),(590,99),(590,100),(590,113),(590,120),(590,129),(590,141),(590,142),(590,201),(590,202),(590,207),(590,210),(590,211),(590,213),(590,214),(590,225),(590,226),(590,228),(590,230),(590,233),(590,234),(590,250),(590,252),(590,259),(590,264),(590,266),(590,268),(590,269),(590,270),(590,275),(590,276),(590,277),(590,278),(590,279),(590,280),(590,281),(590,282),(590,283),(590,284),(590,285),(590,286),(590,287),(590,288),(590,289),(590,290),(590,291),(590,292),(590,293),(590,294),(590,295);
/*!40000 ALTER TABLE `jom_modules_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_molajotools_customperms`
--

DROP TABLE IF EXISTS `jom_molajotools_customperms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_molajotools_customperms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `path` varchar(255) NOT NULL,
  `perms` varchar(4) DEFAULT '0644',
  UNIQUE KEY `id` (`id`),
  KEY `path` (`path`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_molajotools_customperms`
--

LOCK TABLES `jom_molajotools_customperms` WRITE;
/*!40000 ALTER TABLE `jom_molajotools_customperms` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_molajotools_customperms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_newsfeeds`
--

DROP TABLE IF EXISTS `jom_newsfeeds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_newsfeeds` (
  `catid` int(11) NOT NULL DEFAULT '0',
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `link` varchar(200) NOT NULL DEFAULT '',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `numarticles` int(10) unsigned NOT NULL DEFAULT '1',
  `cache_time` int(10) unsigned NOT NULL DEFAULT '3600',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rtl` tinyint(4) NOT NULL DEFAULT '0',
  `access` int(10) unsigned DEFAULT NULL,
  `language` char(7) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `metadata` text NOT NULL,
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `description` text NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `images` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`published`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_newsfeeds`
--

LOCK TABLES `jom_newsfeeds` WRITE;
/*!40000 ALTER TABLE `jom_newsfeeds` DISABLE KEYS */;
INSERT INTO `jom_newsfeeds` (`catid`, `id`, `name`, `alias`, `link`, `published`, `numarticles`, `cache_time`, `checked_out`, `checked_out_time`, `ordering`, `rtl`, `access`, `language`, `params`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `metakey`, `metadesc`, `metadata`, `xreference`, `publish_up`, `publish_down`, `description`, `version`, `hits`, `images`) VALUES (29,1,'Joomla! Announcements','joomla-official-news','http://feeds.joomla.org/JoomlaAnnouncements',1,5,3600,0,'0000-00-00 00:00:00',1,0,1,'*','','0000-00-00 00:00:00',335,'','0000-00-00 00:00:00',0,'','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','',1,0,''),(29,2,'Joomla! Core Team Blog','joomla-core-team-blog','http://feeds.joomla.org/JoomlaCommunityCoreTeamBlog',1,5,3600,0,'0000-00-00 00:00:00',2,0,1,'*','','0000-00-00 00:00:00',335,'','0000-00-00 00:00:00',0,'','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','',1,0,''),(29,3,'Joomla! Community Magazine','joomla-community-magazine','http://feeds.joomla.org/JoomlaMagazine',1,20,3600,0,'0000-00-00 00:00:00',3,0,1,'*','','0000-00-00 00:00:00',335,'','0000-00-00 00:00:00',0,'','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','',1,0,''),(29,4,'Joomla! Developer News','joomla-developer-news','http://feeds.joomla.org/JoomlaDeveloper',1,5,3600,0,'0000-00-00 00:00:00',4,0,1,'*','','0000-00-00 00:00:00',335,'','0000-00-00 00:00:00',0,'','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','',1,0,''),(29,5,'Joomla! Security News','joomla-security-news','http://feeds.joomla.org/JoomlaSecurityNews',1,5,3600,0,'0000-00-00 00:00:00',5,0,1,'*','','0000-00-00 00:00:00',335,'','0000-00-00 00:00:00',0,'','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','',1,0,''),(30,6,'Free Software Foundation Blogs','free-software-foundation-blogs','http://www.fsf.org/blogs/RSS',1,5,3600,0,'0000-00-00 00:00:00',4,0,1,'*','','0000-00-00 00:00:00',335,'','0000-00-00 00:00:00',0,'','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','',1,0,''),(30,7,'Free Software Foundation','free-software-foundation','http://www.fsf.org/news/RSS',1,5,3600,62,'2008-09-14 00:24:25',3,0,1,'*','','0000-00-00 00:00:00',335,'','0000-00-00 00:00:00',0,'','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','',1,0,''),(30,8,'Software Freedom Law Center Blog','software-freedom-law-center-blog','http://www.softwarefreedom.org/feeds/blog/',1,5,3600,0,'0000-00-00 00:00:00',2,0,1,'*','','0000-00-00 00:00:00',335,'','0000-00-00 00:00:00',0,'','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','',1,0,''),(30,9,'Software Freedom Law Center News','software-freedom-law-center','http://www.softwarefreedom.org/feeds/news/',1,5,3600,0,'0000-00-00 00:00:00',1,0,1,'*','','0000-00-00 00:00:00',335,'','0000-00-00 00:00:00',0,'','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','',1,0,''),(30,10,'Open Source Initiative Blog','open-source-initiative-blog','http://www.opensource.org/blog/feed',1,5,3600,0,'0000-00-00 00:00:00',5,0,1,'*','','0000-00-00 00:00:00',335,'','0000-00-00 00:00:00',0,'','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','',1,0,''),(31,11,'PHP News and Announcements','php-news-and-announcements','http://www.php.net/feed.atom',1,5,3600,62,'2008-09-14 00:25:37',1,0,1,'*','','0000-00-00 00:00:00',335,'','0000-00-00 00:00:00',0,'','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','',1,0,''),(31,12,'Planet MySQL','planet-mysql','http://www.planetmysql.org/rss20.xml',1,5,3600,62,'2008-09-14 00:25:51',2,0,1,'*','','0000-00-00 00:00:00',335,'','0000-00-00 00:00:00',0,'','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','',1,0,''),(31,13,'Linux Foundation Announcements','linux-foundation-announcements','http://www.linuxfoundation.org/press/rss20.xml',1,5,3600,62,'2008-09-14 00:26:11',3,0,1,'*','','0000-00-00 00:00:00',335,'','0000-00-00 00:00:00',0,'','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','',1,0,''),(31,14,'Mootools Blog','mootools-blog','http://feeds.feedburner.com/mootools-blog',1,5,3600,62,'2008-09-14 00:26:51',4,0,1,'*','','0000-00-00 00:00:00',335,'','0000-00-00 00:00:00',0,'','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','',1,0,'');
/*!40000 ALTER TABLE `jom_newsfeeds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_overrider`
--

DROP TABLE IF EXISTS `jom_overrider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_overrider` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `constant` varchar(255) NOT NULL,
  `string` text NOT NULL,
  `file` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_overrider`
--

LOCK TABLES `jom_overrider` WRITE;
/*!40000 ALTER TABLE `jom_overrider` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_overrider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_plg_system_adminexile`
--

DROP TABLE IF EXISTS `jom_plg_system_adminexile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_plg_system_adminexile` (
  `ip` varchar(45) NOT NULL,
  `firstattempt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastattempt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `attempts` int(11) NOT NULL,
  `penalty` int(11) NOT NULL,
  PRIMARY KEY (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_plg_system_adminexile`
--

LOCK TABLES `jom_plg_system_adminexile` WRITE;
/*!40000 ALTER TABLE `jom_plg_system_adminexile` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_plg_system_adminexile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_postinstall_messages`
--

DROP TABLE IF EXISTS `jom_postinstall_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_postinstall_messages` (
  `postinstall_message_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `extension_id` bigint(20) NOT NULL DEFAULT '700' COMMENT 'FK to #__extensions',
  `title_key` varchar(255) NOT NULL DEFAULT '' COMMENT 'Lang key for the title',
  `description_key` varchar(255) NOT NULL DEFAULT '' COMMENT 'Lang key for description',
  `action_key` varchar(255) NOT NULL DEFAULT '',
  `language_extension` varchar(255) NOT NULL DEFAULT 'com_postinstall' COMMENT 'Extension holding lang keys',
  `language_client_id` tinyint(3) NOT NULL DEFAULT '1',
  `type` varchar(10) NOT NULL DEFAULT 'link' COMMENT 'Message type - message, link, action',
  `action_file` varchar(255) DEFAULT '' COMMENT 'RAD URI to the PHP file containing action method',
  `action` varchar(255) DEFAULT '' COMMENT 'Action method name or URL',
  `condition_file` varchar(255) DEFAULT NULL COMMENT 'RAD URI to file holding display condition method',
  `condition_method` varchar(255) DEFAULT NULL COMMENT 'Display condition method, must return boolean',
  `version_introduced` varchar(50) NOT NULL DEFAULT '3.2.0' COMMENT 'Version when this message was introduced',
  `enabled` tinyint(3) NOT NULL DEFAULT '1',
  PRIMARY KEY (`postinstall_message_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_postinstall_messages`
--

LOCK TABLES `jom_postinstall_messages` WRITE;
/*!40000 ALTER TABLE `jom_postinstall_messages` DISABLE KEYS */;
INSERT INTO `jom_postinstall_messages` (`postinstall_message_id`, `extension_id`, `title_key`, `description_key`, `action_key`, `language_extension`, `language_client_id`, `type`, `action_file`, `action`, `condition_file`, `condition_method`, `version_introduced`, `enabled`) VALUES (1,700,'PLG_TWOFACTORAUTH_TOTP_POSTINSTALL_TITLE','PLG_TWOFACTORAUTH_TOTP_POSTINSTALL_BODY','PLG_TWOFACTORAUTH_TOTP_POSTINSTALL_ACTION','plg_twofactorauth_totp',1,'action','site://plugins/twofactorauth/totp/postinstall/actions.php','twofactorauth_postinstall_action','site://plugins/twofactorauth/totp/postinstall/actions.php','twofactorauth_postinstall_condition','3.2.0',1),(2,700,'COM_CPANEL_MSG_EACCELERATOR_TITLE','COM_CPANEL_MSG_EACCELERATOR_BODY','COM_CPANEL_MSG_EACCELERATOR_BUTTON','com_cpanel',1,'action','admin://components/com_admin/postinstall/eaccelerator.php','admin_postinstall_eaccelerator_action','admin://components/com_admin/postinstall/eaccelerator.php','admin_postinstall_eaccelerator_condition','3.2.0',1),(3,700,'PLG_USER_JOOMLA_POSTINSTALL_STRONGPW_TITLE','PLG_USER_JOOMLA_POSTINSTALL_STRONGPW_TEXT','PLG_USER_JOOMLA_POSTINSTALL_STRONGPW_BTN','plg_user_joomla',1,'action','site://plugins/user/joomla/postinstall/actions.php','plguserjoomla_postinstall_action','site://plugins/user/joomla/postinstall/actions.php','plguserjoomla_postinstall_condition','3.2.0',1);
/*!40000 ALTER TABLE `jom_postinstall_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_redirect_links`
--

DROP TABLE IF EXISTS `jom_redirect_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_redirect_links` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `old_url` varchar(255) DEFAULT NULL,
  `new_url` varchar(255) DEFAULT NULL,
  `referer` varchar(150) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(4) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_link_old` (`old_url`),
  KEY `idx_link_modifed` (`modified_date`)
) ENGINE=InnoDB AUTO_INCREMENT=411 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_redirect_links`
--

LOCK TABLES `jom_redirect_links` WRITE;
/*!40000 ALTER TABLE `jom_redirect_links` DISABLE KEYS */;
INSERT INTO `jom_redirect_links` (`id`, `old_url`, `new_url`, `referer`, `comment`, `hits`, `published`, `created_date`, `modified_date`) VALUES (1,'http://localhost/cyan/jupgrade/index.php/extensions/images/fd_image1.jpg','','http://localhost/cyan/jupgrade/index.php/extensions/s5-frontpage-display','',0,0,'2012-02-13 16:46:25','0000-00-00 00:00:00'),(2,'http://localhost/cyan/jupgrade/index.php/extensions/images/fd_active.png','','http://localhost/cyan/jupgrade/index.php/extensions/s5-frontpage-display','',0,0,'2012-02-13 16:46:25','0000-00-00 00:00:00'),(3,'http://localhost/cyan/jupgrade/index.php/extensions/images/fd_inactive.png','','http://localhost/cyan/jupgrade/index.php/extensions/s5-frontpage-display','',0,0,'2012-02-13 16:46:25','0000-00-00 00:00:00'),(4,'http://localhost/cyan/jupgrade/index.php/extensions/images/fd_image2.jpg','','http://localhost/cyan/jupgrade/index.php/extensions/s5-frontpage-display','',0,0,'2012-02-13 16:46:35','0000-00-00 00:00:00'),(5,'http://localhost/cyan/jupgrade/index.php/extensions/images/fd_image3.jpg','','http://localhost/cyan/jupgrade/index.php/extensions/s5-frontpage-display','',0,0,'2012-02-13 16:46:40','0000-00-00 00:00:00'),(6,'http://localhost/cyan/jupgrade/index.php/images/fd_active.png','','http://localhost/cyan/jupgrade/index.php/extensions/s5-frontpage-display','',0,0,'2012-02-13 18:49:36','0000-00-00 00:00:00'),(7,'http://localhost/cyan/jupgrade/index.php/images/fd_inactive.png','','http://localhost/cyan/jupgrade/index.php/extensions/s5-frontpage-display','',0,0,'2012-02-13 18:49:44','0000-00-00 00:00:00'),(8,'http://localhost/cyan/jupgrade/index.php/extensions/.images/fd_active.png','','http://localhost/cyan/jupgrade/index.php/extensions/s5-frontpage-display','',0,0,'2012-02-13 18:50:50','0000-00-00 00:00:00'),(9,'http://localhost/sports/index.php/modules/mod_s5_box/images/internet_explorer/borderTopRight.png','','http://localhost/sports/index.php/s5-flex-menu-1360','',0,0,'2012-04-03 19:11:07','0000-00-00 00:00:00'),(10,'http://localhost/sports/index.php/modules/mod_s5_box/images/internet_explorer/borderMiddleLeft.png','','http://localhost/sports/index.php/s5-flex-menu-1360','',0,0,'2012-04-03 19:11:07','0000-00-00 00:00:00'),(11,'http://localhost/sports/index.php/modules/mod_s5_box/images/internet_explorer/borderBottomLeft.png','','http://localhost/sports/index.php/s5-flex-menu-1360','',0,0,'2012-04-03 19:11:07','0000-00-00 00:00:00'),(12,'http://localhost/sports/index.php/modules/mod_s5_box/images/internet_explorer/borderBottomCenter.png','','http://localhost/sports/index.php/s5-flex-menu-1360','',0,0,'2012-04-03 19:11:07','0000-00-00 00:00:00'),(13,'http://localhost/sports/index.php/modules/mod_s5_box/images/internet_explorer/borderMiddleRight.png','','http://localhost/sports/index.php/s5-flex-menu-1360','',0,0,'2012-04-03 19:11:07','0000-00-00 00:00:00'),(14,'http://localhost/sports/index.php/modules/mod_s5_box/images/internet_explorer/borderBottomRight.png','','http://localhost/sports/index.php/s5-flex-menu-1360','',0,0,'2012-04-03 19:11:07','0000-00-00 00:00:00'),(15,'http://localhost/sports/index.php/modules/mod_s5_box/images/internet_explorer/borderTopLeft.png','','http://localhost/sports/index.php/s5-flex-menu-1360','',0,0,'2012-04-03 19:11:08','0000-00-00 00:00:00'),(16,'http://localhost/sports/index.php/modules/mod_s5_box/images/internet_explorer/borderTopCenter.png','','http://localhost/sports/index.php/s5-flex-menu-1360','',0,0,'2012-04-03 19:11:08','0000-00-00 00:00:00'),(17,'http://localhost/sports/index.php/templates/sports_nation/css/PIE.htc','','','',0,0,'2012-04-03 19:11:16','0000-00-00 00:00:00'),(18,'http://localhost/sports/index.php/extensions/index.php','','http://localhost/sports/index.php/extensions/s5-flex-menu','',0,0,'2012-04-05 13:14:06','0000-00-00 00:00:00'),(19,'http://localhost/sports/index.php/tutorials-mainmenu-48/index.php','','http://localhost/sports/index.php/tutorials-mainmenu-48/installing-the-template','',0,0,'2012-04-08 02:53:36','0000-00-00 00:00:00'),(20,'http://localhost/sports/index.php/blogs','','http://localhost/sports/','',0,0,'2012-04-10 20:26:39','0000-00-00 00:00:00'),(21,'http://localhost/sports/index.php/component/content/article/2-uncategorised/index.php','','http://localhost/sports/index.php/component/content/article/2-uncategorised/276-sample-content','',0,0,'2012-04-11 16:13:04','0000-00-00 00:00:00'),(22,'http://localhost/corporate/index.php/features-mainmenu-47/template-features/index.php','','http://localhost/corporate/index.php/features-mainmenu-47/template-features/multibox-enabled','',0,0,'2012-06-06 16:28:26','0000-00-00 00:00:00'),(23,'http://localhost/corporate/index.php/features-mainmenu-47/style-and-layout-options/templates/corporate_response/css/PIE.htc','','','',0,0,'2012-06-07 13:41:23','0000-00-00 00:00:00'),(24,'http://localhost/corporate/index.php/extensions/index.php','','http://localhost/corporate/index.php/extensions/s5-cssjs-compressor','',0,0,'2012-06-10 14:55:39','0000-00-00 00:00:00'),(25,'http://localhost/corporate/index.php/features-mainmenu-47/joomla-stuff-mainmenu-26/index.php','','http://localhost/corporate/index.php/features-mainmenu-47/joomla-stuff-mainmenu-26/contact-us','',0,0,'2012-06-11 18:28:13','0000-00-00 00:00:00'),(26,'http://localhost/modern/index.php/features-mainmenu-47/joomla-stuff-mainmenu-26/www','','http://localhost/modern/index.php/features-mainmenu-47/joomla-stuff-mainmenu-26/wrapper-mainmenu-8','',1,0,'2012-08-08 13:43:00','0000-00-00 00:00:00'),(27,'http://localhost/modern/index.php/sample','','http://localhost/modern/','',1,0,'2012-08-13 15:50:37','0000-00-00 00:00:00'),(28,'http://localhost/modern/index.php/features-mainmenu-47/template-features/95-module-positions','','http://localhost/modern/index.php/features-mainmenu-47/template-features/info-slide-enabled','',1,0,'2012-08-13 19:46:25','0000-00-00 00:00:00'),(29,'http://localhost/newvision/index.php/modules/mod_s5_box/images/internet_explorer/borderBottomLeft.png','','http://localhost/newvision/index.php/s5-flex-menu-1360','',15,0,'2012-10-08 22:10:27','0000-00-00 00:00:00'),(30,'http://localhost/newvision/index.php/modules/mod_s5_box/images/internet_explorer/borderTopRight.png','','http://localhost/newvision/index.php/s5-flex-menu-1360','',15,0,'2012-10-08 22:10:27','0000-00-00 00:00:00'),(31,'http://localhost/newvision/index.php/modules/mod_s5_box/images/internet_explorer/borderMiddleLeft.png','','http://localhost/newvision/index.php/s5-flex-menu-1360','',15,0,'2012-10-08 22:10:27','0000-00-00 00:00:00'),(32,'http://localhost/newvision/index.php/modules/mod_s5_box/images/internet_explorer/borderTopLeft.png','','http://localhost/newvision/index.php/s5-flex-menu-1360','',15,0,'2012-10-08 22:10:27','0000-00-00 00:00:00'),(33,'http://localhost/newvision/index.php/modules/mod_s5_box/images/internet_explorer/borderTopCenter.png','','http://localhost/newvision/index.php/s5-flex-menu-1360','',15,0,'2012-10-08 22:10:27','0000-00-00 00:00:00'),(34,'http://localhost/newvision/index.php/modules/mod_s5_box/images/internet_explorer/borderMiddleRight.png','','http://localhost/newvision/index.php/s5-flex-menu-1360','',15,0,'2012-10-08 22:10:27','0000-00-00 00:00:00'),(35,'http://localhost/newvision/index.php/modules/mod_s5_box/images/internet_explorer/borderBottomRight.png','','http://localhost/newvision/index.php/s5-flex-menu-1360','',15,0,'2012-10-08 22:10:28','0000-00-00 00:00:00'),(36,'http://localhost/newvision/index.php/modules/mod_s5_box/images/internet_explorer/borderBottomCenter.png','','http://localhost/newvision/index.php/s5-flex-menu-1360','',15,0,'2012-10-08 22:10:28','0000-00-00 00:00:00'),(37,'http://localhost/newvision/index.php/s5-flex-menu-1360','','','',1,0,'2012-10-10 15:23:11','0000-00-00 00:00:00'),(38,'http://localhost/newvision/index.php/features-mainmenu-47/template-features/index.php','','http://localhost/newvision/index.php/features-mainmenu-47/template-features/94-module-positions','',11,0,'2012-10-12 12:50:02','0000-00-00 00:00:00'),(39,'http://localhost/newvision/index.php/features-mainmenu-47/index.php','','http://localhost/newvision/index.php/features-mainmenu-47/template-specific-features','',4,0,'2012-10-13 20:58:05','0000-00-00 00:00:00'),(40,'http://poec.org/index.php/about-us/9-news','','','',1,0,'2013-10-28 19:46:03','0000-00-00 00:00:00'),(41,'http://poec.org/index.php/10-news/latest/20-s5-drop-down-panel','','','',1,0,'2013-10-28 21:29:30','0000-00-00 00:00:00'),(42,'http://poec.org/index.php/network-of-people/2-uncategorised/29-sample-content-3','','','',1,0,'2013-10-28 23:01:20','0000-00-00 00:00:00'),(43,'http://poec.org/index.php/network-of-people/10-news/latest/32-stock-photography','','','',1,0,'2013-10-28 23:17:33','0000-00-00 00:00:00'),(44,'http://poec.org/index.php/non-profit-project/2-uncategorised/29-sample-content-3','','','',1,0,'2013-10-28 23:40:03','0000-00-00 00:00:00'),(45,'http://poec.org/index.php/our-privacy-policy/2-uncategorised/29-sample-content-3','','','',1,0,'2013-10-29 00:02:40','0000-00-00 00:00:00'),(46,'http://poec.org/index.php/customer-satisfaction/2-uncategorised/29-sample-content-3','','','',1,0,'2013-10-29 00:11:24','0000-00-00 00:00:00'),(47,'http://www.poec.org/index.php/features-mainmenu-47/template-features/responsive-layout','','','',1,0,'2013-10-29 00:18:10','0000-00-00 00:00:00'),(48,'http://www.poec.org/index.php/featured/10-news/latest/30-search-engine-optimized','','','',1,0,'2013-10-29 00:20:50','0000-00-00 00:00:00'),(49,'http://www.poec.org/index.php/features-mainmenu-47/template-features/95-module-positions','','','',1,0,'2013-10-29 00:39:16','0000-00-00 00:00:00'),(50,'http://www.poec.org/index.php/features-mainmenu-47/template-features/hide-divs-and-modules','','','',1,0,'2013-10-29 00:59:39','0000-00-00 00:00:00'),(51,'http://www.poec.org/index.php/features-mainmenu-47/style-and-layout-options/file-compression','','','',1,0,'2013-10-29 02:49:12','0000-00-00 00:00:00'),(52,'http://www.poec.org/index.php/features-mainmenu-47/template-features/hide-content-and-modules','','','',1,0,'2013-10-29 03:09:23','0000-00-00 00:00:00'),(53,'http://www.poec.org/index.php/features-mainmenu-47/style-and-layout-options/stock-photography','','','',1,0,'2013-10-29 03:39:01','0000-00-00 00:00:00'),(54,'http://poec.org/index.php?Itemid=208','','http://poec.org/','',1,0,'2013-10-29 04:44:46','0000-00-00 00:00:00'),(55,'http://www.poec.org/index.php/network-of-people/10-news/latest/21-s5-flex-menu-menu-system','','','',1,0,'2013-10-29 05:09:14','0000-00-00 00:00:00'),(56,'http://www.poec.org/index.php/our-privacy-policy/10-news/latest/21-s5-flex-menu-menu-system','','','',1,0,'2013-10-29 05:32:16','0000-00-00 00:00:00'),(57,'http://www.poec.org/index.php/non-profit-project/10-news/latest/21-s5-flex-menu-menu-system','','','',1,0,'2013-10-29 05:57:16','0000-00-00 00:00:00'),(58,'http://poec.org/index.php/network-of-people/10-news/latest/33-template-specific-options','','','',1,0,'2013-10-29 06:10:28','0000-00-00 00:00:00'),(59,'http://www.poec.org/index.php/customer-satisfaction/10-news/latest/21-s5-flex-menu-menu-system','','','',1,0,'2013-10-29 06:38:55','0000-00-00 00:00:00'),(60,'http://poec.org/downloads/apache/old/devel-2.0.XX/apachectl','','','',1,0,'2013-10-29 08:53:34','0000-00-00 00:00:00'),(61,'http://www.poec.org/index.php/aboutus/9-news','','','',1,0,'2013-10-29 10:25:48','0000-00-00 00:00:00'),(62,'http://www.poec.org/index.php/10-news/latest/35-the-template-s-settings','','','',1,0,'2013-10-29 10:26:29','0000-00-00 00:00:00'),(63,'http://www.poec.org/index.php/network-of-people/10-news/latest/30-search-engine-optimized','','','',1,0,'2013-10-29 11:05:37','0000-00-00 00:00:00'),(64,'http://poec.org/index.php/our-privacy-policy/10-news/latest/31-site-shapers','','','',1,0,'2013-10-29 11:10:24','0000-00-00 00:00:00'),(65,'http://www.poec.org/index.php/get-to-know-us/10-news/latest','','','',1,0,'2013-10-29 11:11:27','0000-00-00 00:00:00'),(66,'http://www.poec.org/index.php/get-to-know-us/9-news','','','',1,0,'2013-10-29 11:21:23','0000-00-00 00:00:00'),(67,'http://www.poec.org/index.php/non-profit-project/10-news/latest/30-search-engine-optimized','','','',1,0,'2013-10-29 11:23:34','0000-00-00 00:00:00'),(68,'http://www.poec.org/index.php/10-news/latest/31-site-shapers','','','',1,0,'2013-10-29 11:44:26','0000-00-00 00:00:00'),(69,'http://www.poec.org/index.php/network-of-people/10-news/latest/23-s5-tab-show','','','',1,0,'2013-10-29 12:09:56','0000-00-00 00:00:00'),(70,'http://www.poec.org/index.php/10-news/latest/33-template-specific-options','','','',1,0,'2013-10-29 13:52:41','0000-00-00 00:00:00'),(71,'http://www.poec.org/index.php/extensions/s5-flex-menu-1360','','','',1,0,'2013-10-29 14:36:25','0000-00-00 00:00:00'),(72,'http://www.poec.org/th1s_1s_a_4o4.html','','http://www.google.com/url?url=www.poec.org&yahoo.com','',1,0,'2013-10-29 14:38:26','0000-00-00 00:00:00'),(73,'http://www.poec.org/index.php/aboutus/10-news/latest/22-s5-frontpage-display','','','',1,0,'2013-10-29 17:19:59','0000-00-00 00:00:00'),(74,'http://www.poec.org/index.php/aboutus/10-news/latest/23-s5-tab-show','','','',1,0,'2013-10-29 17:20:29','0000-00-00 00:00:00'),(75,'http://poec.org/index.php/non-profit-project/10-news/latest/35-the-template-s-settings','','','',1,0,'2013-10-29 17:41:34','0000-00-00 00:00:00'),(76,'http://poec.org/index.php/our-privacy-policy/10-news/latest/33-template-specific-options','','','',1,0,'2013-10-29 17:56:20','0000-00-00 00:00:00'),(77,'http://www.poec.org/index.php/10-news/latest/32-stock-photography','','','',1,0,'2013-10-29 18:36:11','0000-00-00 00:00:00'),(78,'http://poec.org/index.php/address-information/2-uncategorised/28-sample-content-2','','','',1,0,'2013-10-29 21:50:04','0000-00-00 00:00:00'),(79,'http://poec.org/wp-login.php','','','',1,0,'2013-10-29 22:45:03','0000-00-00 00:00:00'),(80,'http://poec.org/index.php/non-profit-project/10-news/latest/32-stock-photography','','','',1,0,'2013-10-30 02:43:27','0000-00-00 00:00:00'),(81,'http://www.poec.org/index.php/aboutus/10-news/latest/30-search-engine-optimized','','','',1,0,'2013-10-30 03:04:32','0000-00-00 00:00:00'),(82,'http://www.poec.org/index.php/site-terms/10-news/latest/21-s5-flex-menu-menu-system','','','',1,0,'2013-10-30 03:18:53','0000-00-00 00:00:00'),(83,'http://www.poec.org/index.php/about-us/10-news/latest/21-s5-flex-menu-menu-system','','','',1,0,'2013-10-30 03:24:34','0000-00-00 00:00:00'),(84,'http://poec.org/index.php/our-privacy-policy/10-news/latest/32-stock-photography','','','',1,0,'2013-10-30 03:25:10','0000-00-00 00:00:00'),(85,'http://www.poec.org/index.php/features-mainmenu-47/template-specific-features','','http://www.poec.org/','',1,0,'2013-10-30 06:18:29','0000-00-00 00:00:00'),(86,'http://poec.org/index.php/about-us/10-news/latest/33-template-specific-options','','','',1,0,'2013-10-30 08:36:42','0000-00-00 00:00:00'),(87,'http://www.poec.org/index.htm','','','',1,0,'2013-10-30 09:28:44','0000-00-00 00:00:00'),(88,'http://www.poec.org/join-now.html','','','',1,0,'2013-10-30 09:48:44','0000-00-00 00:00:00'),(89,'http://poec.org/downloads/SpamAssassin/contrib/milterscripts/DESCRIPTION','','','',1,0,'2013-10-30 10:10:16','0000-00-00 00:00:00'),(90,'http://poec.org/downloads/apache/current/old/INSTALL-devel-DSO','','','',1,0,'2013-10-30 11:04:44','0000-00-00 00:00:00'),(91,'http://poec.org/index.php/aboutus/10-news/latest/32-stock-photography','','','',1,0,'2013-10-30 13:46:12','0000-00-00 00:00:00'),(92,'http://www.poec.org/index.php/component/content/article?id=article','','','',1,0,'2013-10-30 13:46:38','0000-00-00 00:00:00'),(93,'http://poec.org/domainsigma_removal_468500da633a8322f094eb2915cf75d1e3f5c26a.html','','','',1,0,'2013-10-30 15:30:12','0000-00-00 00:00:00'),(94,'http://poec.org/index.php/tutorials-mainmenu-48/site-shaper-setup','','','',1,0,'2013-10-30 16:28:15','0000-00-00 00:00:00'),(95,'http://www.poec.org/index.php/get-to-know-us/10-news/latest/30-search-engine-optimized','','','',1,0,'2013-10-30 16:48:21','0000-00-00 00:00:00'),(96,'http://www.poec.org/index.php/our-privacy-policy/10-news/latest/30-search-engine-optimized','','','',1,0,'2013-10-30 17:08:46','0000-00-00 00:00:00'),(97,'http://poec.org/index.php/address-information/10-news/latest/35-the-template-s-settings','','','',1,0,'2013-10-30 20:54:39','0000-00-00 00:00:00'),(98,'http://poec.org/index.php/get-to-know-us/10-news/latest/31-site-shapers','','','',1,0,'2013-10-31 00:52:05','0000-00-00 00:00:00'),(99,'http://poec.org/index.php/get-to-know-us/10-news/latest/32-stock-photography','','','',1,0,'2013-10-31 06:11:09','0000-00-00 00:00:00'),(100,'http://poec.org/index.php/get-to-know-us/10-news/latest/35-the-template-s-settings','','','',1,0,'2013-10-31 06:48:29','0000-00-00 00:00:00'),(101,'http://poec.org/downloads/sendmail/sendmail-8.13.X/contrib/timeout_values','','','',1,0,'2013-10-31 10:29:18','0000-00-00 00:00:00'),(102,'http://www.poec.org/index.php/site-terms','','','',1,0,'2013-10-31 20:22:06','0000-00-00 00:00:00'),(103,'http://POEC.ORG//wp-login.php','','','',1,0,'2013-10-31 21:48:53','0000-00-00 00:00:00'),(104,'http://www.poec.org/robots','','http://www.baidu.com','',1,0,'2013-10-31 22:26:47','0000-00-00 00:00:00'),(105,'http://www.poec.org/ask','','http://www.baidu.com','',1,0,'2013-10-31 22:26:47','0000-00-00 00:00:00'),(106,'http://www.poec.org/admin/help/online_help_1.htm','','http://www.baidu.com','',1,0,'2013-10-31 22:26:47','0000-00-00 00:00:00'),(107,'http://www.poec.org/do/reg.php','','http://www.baidu.com','',1,0,'2013-10-31 22:26:47','0000-00-00 00:00:00'),(108,'http://www.poec.org/admin/template/foot.htm','','http://www.baidu.com','',1,0,'2013-10-31 22:26:47','0000-00-00 00:00:00'),(109,'http://www.poec.org/digg.php','','http://www.baidu.com','',1,0,'2013-10-31 22:26:48','0000-00-00 00:00:00'),(110,'http://www.poec.org/admin/list.html','','http://www.baidu.com','',1,0,'2013-10-31 22:26:48','0000-00-00 00:00:00'),(111,'http://www.poec.org/index.php/i','','http://www.baidu.com','',1,0,'2013-10-31 22:26:48','0000-00-00 00:00:00'),(112,'http://www.poec.org/admin/template/article_more/config.htm','','http://www.baidu.com','',1,0,'2013-10-31 22:26:48','0000-00-00 00:00:00'),(113,'http://www.poec.org/special','','http://www.baidu.com','',1,0,'2013-10-31 22:26:49','0000-00-00 00:00:00'),(114,'http://www.poec.org/hack/gather/template/edit_title.htm','','http://www.baidu.com','',1,0,'2013-10-31 22:26:49','0000-00-00 00:00:00'),(115,'http://www.poec.org/admin/licence','','http://www.baidu.com','',1,0,'2013-10-31 22:26:49','0000-00-00 00:00:00'),(116,'http://www.poec.org/member/template/homepage.htm','','http://www.baidu.com','',1,0,'2013-10-31 22:26:49','0000-00-00 00:00:00'),(117,'http://www.poec.org/admin','','http://www.baidu.com','',1,0,'2013-10-31 22:26:49','0000-00-00 00:00:00'),(118,'http://www.poec.org/template/home.htm','','http://www.baidu.com','',1,0,'2013-10-31 22:26:49','0000-00-00 00:00:00'),(119,'http://www.poec.org/data','','http://www.baidu.com','',1,0,'2013-10-31 22:26:50','0000-00-00 00:00:00'),(120,'http://www.poec.org/install/templates/step-1.html','','http://www.baidu.com','',1,0,'2013-10-31 22:26:50','0000-00-00 00:00:00'),(121,'http://www.poec.org/99billdo.php','','http://www.baidu.com','',1,0,'2013-10-31 22:26:50','0000-00-00 00:00:00'),(122,'http://www.poec.org/admin/tpl/showmessage.htm','','http://www.baidu.com','',1,0,'2013-10-31 22:26:50','0000-00-00 00:00:00'),(123,'http://www.poec.org/template/default/refreshto.htm','','http://www.baidu.com','',1,0,'2013-10-31 22:26:50','0000-00-00 00:00:00'),(124,'http://www.poec.org/install/templates/header.htm','','http://www.baidu.com','',1,0,'2013-10-31 22:26:50','0000-00-00 00:00:00'),(125,'http://www.poec.org/system/skins/default/system.login.htm','','http://www.baidu.com','',1,0,'2013-10-31 22:26:50','0000-00-00 00:00:00'),(126,'http://www.poec.org/dede/login.php?gotopage=%2Fdede%2F','','http://www.baidu.com','',1,0,'2013-10-31 22:26:51','0000-00-00 00:00:00'),(127,'http://www.poec.org/login.php','','http://www.baidu.com','',1,0,'2013-10-31 22:26:51','0000-00-00 00:00:00'),(128,'http://www.poec.org/leiame.html','','http://www.baidu.com','',1,0,'2013-10-31 22:26:51','0000-00-00 00:00:00'),(129,'http://www.poec.org/media/blogs/index.html','','http://www.baidu.com','',1,0,'2013-10-31 22:26:51','0000-00-00 00:00:00'),(130,'http://www.poec.org/admin/tpl/footer.htm','','http://www.baidu.com','',1,0,'2013-10-31 22:26:52','0000-00-00 00:00:00'),(131,'http://www.poec.org/custom/README','','http://www.baidu.com','',1,0,'2013-10-31 22:26:52','0000-00-00 00:00:00'),(132,'http://www.poec.org/index.html','','http://www.baidu.com','',1,0,'2013-10-31 22:26:53','0000-00-00 00:00:00'),(133,'http://www.poec.org/Dialog/about.htm','','http://www.baidu.com','',1,0,'2013-10-31 22:26:53','0000-00-00 00:00:00'),(134,'http://www.poec.org/agent/templates/Smarty/utf-8/footer.html','','http://www.baidu.com','',1,0,'2013-10-31 22:26:53','0000-00-00 00:00:00'),(135,'http://www.poec.org/Southidceditor/Dialog/about.htm','','http://www.baidu.com','',1,0,'2013-10-31 22:26:53','0000-00-00 00:00:00'),(136,'http://www.poec.org/themes/lazycms/home.html','','http://www.baidu.com','',1,0,'2013-10-31 22:26:53','0000-00-00 00:00:00'),(137,'http://www.poec.org/install/templates/default/errorinfo.php','','http://www.baidu.com','',1,0,'2013-10-31 22:26:54','0000-00-00 00:00:00'),(138,'http://www.poec.org/templates/default/cn/public/footer.html','','http://www.baidu.com','',1,0,'2013-10-31 22:26:54','0000-00-00 00:00:00'),(139,'http://www.poec.org/js/index.htm','','http://www.baidu.com','',1,0,'2013-10-31 22:26:54','0000-00-00 00:00:00'),(140,'http://www.poec.org/phpldapadmin','','http://www.baidu.com','',1,0,'2013-10-31 22:26:54','0000-00-00 00:00:00'),(141,'http://www.poec.org/eWebEditor/Dialog/about.htm','','http://www.baidu.com','',1,0,'2013-10-31 22:26:54','0000-00-00 00:00:00'),(142,'http://www.poec.org/install/templates/default/footer.php','','http://www.baidu.com','',1,0,'2013-10-31 22:26:54','0000-00-00 00:00:00'),(143,'http://www.poec.org/templates/default/en/public/footer.html','','http://www.baidu.com','',1,0,'2013-10-31 22:26:54','0000-00-00 00:00:00'),(144,'http://www.poec.org/pla','','http://www.baidu.com','',1,0,'2013-10-31 22:26:55','0000-00-00 00:00:00'),(145,'http://www.poec.org/minica_down.php','','http://www.baidu.com','',1,0,'2013-10-31 22:26:55','0000-00-00 00:00:00'),(146,'http://www.poec.org/admin/Southidceditor/Dialog/about.htm','','http://www.baidu.com','',1,0,'2013-10-31 22:26:55','0000-00-00 00:00:00'),(147,'http://www.poec.org/index.php/featured/10-news/latest/23-s5-tab-show','','','',1,0,'2013-11-01 03:27:49','0000-00-00 00:00:00'),(148,'http://www.poec.org/index.php/featured/10-news/latest/22-s5-frontpage-display','','','',1,0,'2013-11-01 03:48:47','0000-00-00 00:00:00'),(149,'http://www.poec.org/index.php/address-information/10-news/latest/23-s5-tab-show','','','',1,0,'2013-11-01 04:07:41','0000-00-00 00:00:00'),(150,'http://www.poec.org/index.php/customer-satisfaction/10-news/latest/23-s5-tab-show','','','',1,0,'2013-11-01 04:28:13','0000-00-00 00:00:00'),(151,'http://www.poec.org/index.php/featured/10-news/latest?start=5','','','',1,0,'2013-11-01 04:48:38','0000-00-00 00:00:00'),(152,'http://www.poec.org/index.php/featured/10-news/latest?start=20','','','',1,0,'2013-11-01 05:27:37','0000-00-00 00:00:00'),(153,'http://www.poec.org/index.php/featured/10-news/latest?start=10','','','',1,0,'2013-11-01 05:48:36','0000-00-00 00:00:00'),(154,'http://www.poec.org/index.php/featured/10-news/latest?start=15','','','',1,0,'2013-11-01 06:09:04','0000-00-00 00:00:00'),(155,'http://www.poec.org/index.php/featured/10-news/latest?start=25','','','',1,0,'2013-11-01 06:28:05','0000-00-00 00:00:00'),(156,'http://poec.org/index.php/features-mainmenu-47/template-specific-features','','','',1,0,'2013-11-01 08:05:50','0000-00-00 00:00:00'),(157,'http://poec.org/index.php/extensions/s5-flex-menu-1360','','','',1,0,'2013-11-01 08:39:11','0000-00-00 00:00:00'),(158,'http://poec.org/index.php/features-mainmenu-47/template-features/responsive-layout','','','',1,0,'2013-11-01 10:52:30','0000-00-00 00:00:00'),(159,'http://poec.org/index.php/address-information/10-news/latest','','','',1,0,'2013-11-01 12:16:01','0000-00-00 00:00:00'),(160,'http://poec.org/index.php/address-information/9-news','','','',1,0,'2013-11-01 18:39:26','0000-00-00 00:00:00'),(161,'http://poec.org/index.php/aboutus/9-news','','','',1,0,'2013-11-02 00:30:16','0000-00-00 00:00:00'),(162,'http://poec.org/wordpress','','http://poec.org/wordpress','',1,0,'2013-11-02 09:58:34','0000-00-00 00:00:00'),(163,'http://poec.org/index.php/component/content/article','','','',1,0,'2013-11-02 23:22:49','0000-00-00 00:00:00'),(164,'http://poec.org/index.php/features-mainmenu-47/template-features/hide-divs-and-modules','','','',1,0,'2013-11-02 23:23:55','0000-00-00 00:00:00'),(165,'http://poec.org/index.php/features-mainmenu-47/template-features/95-module-positions','','','',1,0,'2013-11-02 23:24:24','0000-00-00 00:00:00'),(166,'http://www.poec.org/index.php/featured','','','',1,0,'2013-11-03 03:22:04','0000-00-00 00:00:00'),(167,'http://poec.org/admin.php','','','',1,0,'2013-11-03 08:10:30','0000-00-00 00:00:00'),(168,'http://poec.org/index.php/about-us/10-news/latest/30-search-engine-optimized','','','',1,0,'2013-11-03 10:29:16','0000-00-00 00:00:00'),(169,'http://poec.org/index.php/non-profit-project/9-news','','','',1,0,'2013-11-03 16:39:16','0000-00-00 00:00:00'),(170,'http://www.poec.org/index.php/aboutus','','','',1,0,'2013-11-03 19:48:35','0000-00-00 00:00:00'),(171,'http://www.poec.org/index.php/our-privacy-policy/10-news/latest/35-the-template-s-settings','','','',1,0,'2013-11-04 03:31:47','0000-00-00 00:00:00'),(172,'http://www.poec.org/index.php/non-profit-project','','','',1,0,'2013-11-04 03:57:43','0000-00-00 00:00:00'),(173,'http://www.poec.org/index.php/network-of-people','','','',1,0,'2013-11-04 07:48:05','0000-00-00 00:00:00'),(174,'http://www.poec.org/index.php/component/content/article','','','',1,0,'2013-11-04 11:03:10','0000-00-00 00:00:00'),(175,'http://www.poec.org/index.php/news','','','',1,0,'2013-11-04 11:51:25','0000-00-00 00:00:00'),(176,'http://www.poec.org/index.php/extensions/s5-frontpage-display','','','',1,0,'2013-11-04 17:11:12','0000-00-00 00:00:00'),(177,'http://poec.org/index.php/non-profit-project/10-news/latest','','','',1,0,'2013-11-04 18:47:26','0000-00-00 00:00:00'),(178,'http://poec.org/index.php/customer-satisfaction/10-news/latest/31-site-shapers','','','',1,0,'2013-11-05 04:52:29','0000-00-00 00:00:00'),(179,'http://poec.org/index.php/news/10-news/latest/33-template-specific-options','','','',1,0,'2013-11-05 05:47:22','0000-00-00 00:00:00'),(180,'http://poec.org/index.php/featured/10-news/latest/35-the-template-s-settings','','','',1,0,'2013-11-05 11:28:16','0000-00-00 00:00:00'),(181,'http://www.poec.org/opec_web/en/','','','',1,0,'2013-11-05 13:26:14','0000-00-00 00:00:00'),(182,'http://www.poec.org/index.php/get-to-know-us','','','',1,0,'2013-11-06 07:53:16','0000-00-00 00:00:00'),(183,'http://www.poec.org/index.php/customer-satisfaction','','','',1,0,'2013-11-06 08:22:58','0000-00-00 00:00:00'),(184,'http://www.poec.org/index.php/news/10-news/latest/30-search-engine-optimized','','','',1,0,'2013-11-06 12:51:18','0000-00-00 00:00:00'),(185,'http://www.poec.org/index.php/news/10-news/latest','','','',1,0,'2013-11-06 13:27:26','0000-00-00 00:00:00'),(186,'http://poec.org/index.php/aboutus','','','',1,0,'2013-11-06 14:10:18','0000-00-00 00:00:00'),(187,'http://poec.org/index.php/site-terms','','','',1,0,'2013-11-06 15:13:36','0000-00-00 00:00:00'),(188,'http://poec.org/index.php/get-to-know-us','','','',1,0,'2013-11-06 16:08:51','0000-00-00 00:00:00'),(189,'http://poec.org/index.php/network-of-people','','','',1,0,'2013-11-06 18:02:56','0000-00-00 00:00:00'),(190,'http://poec.org/index.php/non-profit-project','','','',1,0,'2013-11-06 18:35:11','0000-00-00 00:00:00'),(191,'http://www.poec.org/index.php/news/9-news','','','',1,0,'2013-11-06 19:17:03','0000-00-00 00:00:00'),(192,'http://poec.org/index.php/address-information','','','',1,0,'2013-11-06 20:02:51','0000-00-00 00:00:00'),(193,'http://poec.org/index.php/our-privacy-policy','','','',1,0,'2013-11-06 20:58:29','0000-00-00 00:00:00'),(194,'http://poec.org/index.php/customer-satisfaction','','','',1,0,'2013-11-06 21:06:12','0000-00-00 00:00:00'),(195,'http://poec.org/index.php/10-news/latest/35-the-template-s-settings','','','',1,0,'2013-11-06 22:08:24','0000-00-00 00:00:00'),(196,'http://poec.org/index.php/10-news/latest/32-stock-photography','','','',1,0,'2013-11-06 22:24:03','0000-00-00 00:00:00'),(197,'http://poec.org/index.php/about-us','','','',1,0,'2013-11-07 01:57:21','0000-00-00 00:00:00'),(198,'http://poec.org/index.php/10-news/latest/33-template-specific-options','','','',1,0,'2013-11-07 02:59:03','0000-00-00 00:00:00'),(199,'http://poec.org/index.php/10-news/latest/31-site-shapers','','','',1,0,'2013-11-07 03:01:16','0000-00-00 00:00:00'),(200,'http://poec.org/index.php/news','','','',1,0,'2013-11-07 03:35:32','0000-00-00 00:00:00'),(201,'http://poec.org/index.php/featured','','','',1,0,'2013-11-07 03:37:52','0000-00-00 00:00:00'),(202,'http://poec.org/index.php/customer-satisfaction/2-uncategorised/28-sample-content-2','','','',1,0,'2013-11-07 10:45:05','0000-00-00 00:00:00'),(203,'http://poec.org/index.php/featured/10-news/latest/32-stock-photography','','','',1,0,'2013-11-08 02:32:41','0000-00-00 00:00:00'),(204,'http://poec.org/index.php/featured/10-news/latest/31-site-shapers','','','',1,0,'2013-11-08 04:41:36','0000-00-00 00:00:00'),(205,'http://www.poec.org/index.php/address-information/10-news/latest','','','',1,0,'2013-11-08 04:48:30','0000-00-00 00:00:00'),(206,'http://www.poec.org/index.php/address-information/9-news','','','',1,0,'2013-11-08 09:42:22','0000-00-00 00:00:00'),(207,'http://www.poec.org/index.php/network-of-people/9-news','','','',1,0,'2013-11-08 10:23:00','0000-00-00 00:00:00'),(208,'http://www.poec.org/index.php/about-us','','','',1,0,'2013-11-08 12:15:52','0000-00-00 00:00:00'),(209,'http://www.poec.org/index.php/address-information','','','',1,0,'2013-11-08 13:18:23','0000-00-00 00:00:00'),(210,'http://www.poec.org/index.php/our-privacy-policy','','','',1,0,'2013-11-08 16:02:00','0000-00-00 00:00:00'),(211,'http://poec.org/index.php/network-of-people/10-news/latest','','','',1,0,'2013-11-08 19:26:18','0000-00-00 00:00:00'),(212,'http://poec.org/index.php/news/10-news/latest/31-site-shapers','','','',1,0,'2013-11-09 01:59:53','0000-00-00 00:00:00'),(213,'http://poec.org/index.php/news/10-news/latest/32-stock-photography','','','',1,0,'2013-11-09 10:29:16','0000-00-00 00:00:00'),(214,'http://www.poec.org/index.php/non-profit-project/10-news/latest/33-template-specific-options','','','',1,0,'2013-11-09 17:18:55','0000-00-00 00:00:00'),(215,'http://poec.org/index.php/news/10-news/latest/35-the-template-s-settings','','','',1,0,'2013-11-09 21:22:58','0000-00-00 00:00:00'),(216,'http://poec.org/blog','','http://poec.org/blog','',1,0,'2013-11-10 05:23:57','0000-00-00 00:00:00'),(217,'http://www.poec.org/index.php/customer-satisfaction/10-news/latest/32-stock-photography','','','',1,0,'2013-11-10 12:52:08','0000-00-00 00:00:00'),(218,'http://poec.org/%c2%a02013-11-01%c2%a0','','','',1,0,'2013-11-10 13:59:32','0000-00-00 00:00:00'),(219,'http://www.poec.org/index.php/customer-satisfaction/10-news/latest/33-template-specific-options','','','',1,0,'2013-11-10 19:43:26','0000-00-00 00:00:00'),(220,'http://www.poec.org/index.php/customer-satisfaction/10-news/latest/35-the-template-s-settings','','','',1,0,'2013-11-10 19:46:39','0000-00-00 00:00:00'),(221,'http://poec.org/index.php/site-terms/10-news/latest/31-site-shapers','','','',1,0,'2013-11-11 02:12:26','0000-00-00 00:00:00'),(222,'http://poec.org/index.php/site-terms/10-news/latest/35-the-template-s-settings','','','',1,0,'2013-11-11 06:42:00','0000-00-00 00:00:00'),(223,'http://www.poec.org/index.php/featured/10-news/latest/33-template-specific-options','','','',1,0,'2013-11-11 13:05:25','0000-00-00 00:00:00'),(224,'http://poec.org/index.php/site-terms/10-news/latest/32-stock-photography','','','',1,0,'2013-11-12 01:59:10','0000-00-00 00:00:00'),(225,'http://www.poec.org//fonts.googleapis.com/css?family=Open+Sans+Condensed','','','',1,0,'2013-11-12 10:33:36','0000-00-00 00:00:00'),(226,'http://www.poec.org/a','','','',1,0,'2013-11-13 15:02:31','0000-00-00 00:00:00'),(227,'http://www.poec.org/index.php/about/8-news/','','','',1,0,'2013-11-13 15:02:33','0000-00-00 00:00:00'),(228,'http://www.poec.org/index.php/8-news/','','','',1,0,'2013-11-13 15:03:00','0000-00-00 00:00:00'),(229,'http://www.poec.org/index.php/new/8-news/','','','',1,0,'2013-11-13 15:03:15','0000-00-00 00:00:00'),(230,'http://www.poec.org/index.php/blogs/8-news/','','','',1,0,'2013-11-13 15:03:17','0000-00-00 00:00:00'),(231,'http://www.poec.org/index.php/faq/8-news/','','','',1,0,'2013-11-13 15:04:08','0000-00-00 00:00:00'),(232,'http://www.poec.org/media/system/js/s?=1','','','',1,0,'2013-11-13 15:04:08','0000-00-00 00:00:00'),(233,'http://www.poec.org/index.php/join-now.html','','','',1,0,'2013-11-13 15:07:35','0000-00-00 00:00:00'),(234,'http://www.poec.org/index.php/new/join-now.html','','','',1,0,'2013-11-13 15:09:11','0000-00-00 00:00:00'),(235,'http://www.poec.org/index.php/blogs/join-now.html','','','',1,0,'2013-11-13 15:09:29','0000-00-00 00:00:00'),(236,'http://www.poec.org/index.php/faq/join-now.html','','','',1,0,'2013-11-13 15:09:40','0000-00-00 00:00:00'),(237,'http://www.poec.org/index.php/about/join-now.html','','','',1,0,'2013-11-13 15:09:41','0000-00-00 00:00:00'),(238,'http://poec.org/wp','','http://poec.org/wp','',1,0,'2013-11-14 03:11:17','0000-00-00 00:00:00'),(239,'http://poec.org/index.php/aboutus/10-news/latest/30-search-engine-optimized','','','',1,0,'2013-11-14 12:41:28','0000-00-00 00:00:00'),(240,'http://www.poec.org/pdfs/POEC_Membership_Form_04_2008.pdf','','','',1,0,'2013-11-15 20:29:06','0000-00-00 00:00:00'),(241,'http://poec.org/index.php/get-to-know-us/10-news/latest','','','',1,0,'2013-11-16 20:30:59','0000-00-00 00:00:00'),(242,'http://poec.org/index.php/our-privacy-policy/2-uncategorised/28-sample-content-2','','','',1,0,'2013-11-16 21:31:39','0000-00-00 00:00:00'),(243,'http://www.poec.org/index.php/about-us/10-news/latest/30-search-engine-optimized','','','',1,0,'2013-11-16 21:42:23','0000-00-00 00:00:00'),(244,'http://www.poec.org/index.php/featured/10-news/latest','','','',1,0,'2013-11-16 23:12:41','0000-00-00 00:00:00'),(245,'http://poec.org/index.php/news/25-sample-article-2','','','',1,0,'2013-11-17 00:24:36','0000-00-00 00:00:00'),(246,'http://poec.org/index.php/network-of-people/2-uncategorised','','','',1,0,'2013-11-17 01:29:05','0000-00-00 00:00:00'),(247,'http://poec.org/index.php/get-to-know-us/9-news','','','',1,0,'2013-11-17 02:31:41','0000-00-00 00:00:00'),(248,'http://poec.org/index.php/our-privacy-policy/10-news/latest/35-the-template-s-settings','','','',1,0,'2013-11-17 02:38:09','0000-00-00 00:00:00'),(249,'http://poec.org/index.php/non-profit-project/2-uncategorised','','','',1,0,'2013-11-17 03:44:42','0000-00-00 00:00:00'),(250,'http://poec.org/index.php/our-privacy-policy/2-uncategorised','','','',1,0,'2013-11-17 04:21:41','0000-00-00 00:00:00'),(251,'http://poec.org/index.php/about-us/10-news/latest/31-site-shapers','','','',1,0,'2013-11-17 05:32:23','0000-00-00 00:00:00'),(252,'http://poec.org/index.php/customer-satisfaction/2-uncategorised','','','',1,0,'2013-11-17 07:17:35','0000-00-00 00:00:00'),(253,'http://poec.org/index.php/site-terms/9-news','','','',1,0,'2013-11-17 07:31:36','0000-00-00 00:00:00'),(254,'http://poec.org/index.php/10-news/latest/30-search-engine-optimized','','','',1,0,'2013-11-17 08:54:34','0000-00-00 00:00:00'),(255,'http://poec.org/index.php/non-profit-project/2-uncategorised/28-sample-content-2','','','',1,0,'2013-11-17 09:45:57','0000-00-00 00:00:00'),(256,'http://poec.org/index.php/aboutus/23-site-info','','','',1,0,'2013-11-17 10:58:11','0000-00-00 00:00:00'),(257,'http://poec.org/index.php/address-information/2-uncategorised','','','',1,0,'2013-11-17 12:03:45','0000-00-00 00:00:00'),(258,'http://poec.org/index.php/about-us/2-uncategorised/28-sample-content-2','','','',1,0,'2013-11-17 12:47:48','0000-00-00 00:00:00'),(259,'http://poec.org/join-now.html','','','',1,0,'2013-11-17 12:58:39','0000-00-00 00:00:00'),(260,'http://poec.org/index.php/get-to-know-us/2-uncategorised/28-sample-content-2','','','',1,0,'2013-11-17 14:20:41','0000-00-00 00:00:00'),(261,'http://poec.org/index.php/network-of-people/2-uncategorised/28-sample-content-2','','','',1,0,'2013-11-17 14:59:26','0000-00-00 00:00:00'),(262,'http://poec.org/index.php/network-of-people/10-news/latest/35-the-template-s-settings','','','',1,0,'2013-11-17 16:47:37','0000-00-00 00:00:00'),(263,'http://poec.org/index.php/about-us/10-news/latest/32-stock-photography','','','',1,0,'2013-11-17 17:18:25','0000-00-00 00:00:00'),(264,'http://poec.org/index.php/address-information/10-news/latest/31-site-shapers','','','',1,0,'2013-11-17 17:56:28','0000-00-00 00:00:00'),(265,'http://poec.org/index.php/aboutus/10-news/latest/33-template-specific-options','','','',1,0,'2013-11-17 18:14:16','0000-00-00 00:00:00'),(266,'http://poec.org/index.php/about-us/10-news/latest/35-the-template-s-settings','','','',1,0,'2013-11-17 18:53:25','0000-00-00 00:00:00'),(267,'http://poec.org/index.php/get-to-know-us/2-uncategorised/29-sample-content-3','','','',1,0,'2013-11-17 19:29:03','0000-00-00 00:00:00'),(268,'http://poec.org/index.php/address-information/2-uncategorised/29-sample-content-3','','','',1,0,'2013-11-17 20:11:44','0000-00-00 00:00:00'),(269,'http://poec.org/index.php/10-news/latest/23-s5-tab-show','','','',1,0,'2013-11-17 21:57:20','0000-00-00 00:00:00'),(270,'http://poec.org/index.php/10-news/latest/22-s5-frontpage-display','','','',1,0,'2013-11-17 22:58:20','0000-00-00 00:00:00'),(271,'http://poec.org/index.htm','','','',1,0,'2013-11-18 02:33:28','0000-00-00 00:00:00'),(272,'http://poec.org/index.php/8-frontpage/38-homepage-article-2','','','',1,0,'2013-11-18 02:38:28','0000-00-00 00:00:00'),(273,'http://poec.org/index.php/8-frontpage/34-homepage-article-1','','','',1,0,'2013-11-18 04:48:24','0000-00-00 00:00:00'),(274,'http://poec.org/index.php/news/26-sample-article-3','','','',1,0,'2013-11-18 06:56:53','0000-00-00 00:00:00'),(275,'http://poec.org/blogs/wp-login.php','','poec.org/blogs','',1,0,'2013-11-18 07:28:15','0000-00-00 00:00:00'),(276,'http://www.poec.org/index.php/about-us/10-news/latest/35-the-template-s-settings','','','',1,0,'2013-11-18 19:41:07','0000-00-00 00:00:00'),(277,'http://www.poec.org/index.php/network-of-people/10-news/latest/33-template-specific-options','','','',1,0,'2013-11-18 20:52:47','0000-00-00 00:00:00'),(278,'http://www.poec.org/index.php/our-privacy-policy/10-news/latest/33-template-specific-options','','','',1,0,'2013-11-18 22:07:16','0000-00-00 00:00:00'),(279,'http://www.poec.org/index.php/non-profit-project/10-news/latest/35-the-template-s-settings','','','',1,0,'2013-11-18 23:11:11','0000-00-00 00:00:00'),(280,'http://www.poec.org/index.php/get-to-know-us/10-news/latest/32-stock-photography','','','',1,0,'2013-11-19 01:55:19','0000-00-00 00:00:00'),(281,'http://www.poec.org/index.php/about-us/10-news/latest/32-stock-photography','','','',1,0,'2013-11-19 09:25:01','0000-00-00 00:00:00'),(282,'http://www.poec.org/index.php/site-terms/10-news/latest/35-the-template-s-settings','','','',1,0,'2013-11-19 10:07:08','0000-00-00 00:00:00'),(283,'http://www.poec.org/index.php/customer-satisfaction/10-news/latest/30-search-engine-optimized','','','',1,0,'2013-11-19 10:46:23','0000-00-00 00:00:00'),(284,'http://www.poec.org/index.php/address-information/10-news/latest/30-search-engine-optimized','','','',1,0,'2013-11-19 11:30:09','0000-00-00 00:00:00'),(285,'http://www.poec.org/index.php/aboutus/10-news/latest','','','',1,0,'2013-11-19 12:11:21','0000-00-00 00:00:00'),(286,'http://www.poec.org/index.php/site-terms/10-news/latest','','','',1,0,'2013-11-19 12:48:59','0000-00-00 00:00:00'),(287,'http://www.poec.org/index.php/about-us/10-news/latest','','','',1,0,'2013-11-19 14:54:51','0000-00-00 00:00:00'),(288,'http://www.poec.org/index.php/about-us/9-news','','','',1,0,'2013-11-19 16:23:27','0000-00-00 00:00:00'),(289,'http://www.poec.org/index.php/site-terms/10-news/latest/23-s5-tab-show','','','',1,0,'2013-11-19 17:05:14','0000-00-00 00:00:00'),(290,'http://www.poec.org/index.php/site-terms/10-news/latest/22-s5-frontpage-display','','','',1,0,'2013-11-19 17:52:47','0000-00-00 00:00:00'),(291,'http://www.poec.org/index.php/about-us/10-news/latest/23-s5-tab-show','','','',1,0,'2013-11-19 18:36:42','0000-00-00 00:00:00'),(292,'http://www.poec.org/index.php/about-us/10-news/latest/22-s5-frontpage-display','','','',1,0,'2013-11-19 19:12:11','0000-00-00 00:00:00'),(293,'http://www.poec.org/home/','','','',1,0,'2013-11-19 21:47:12','0000-00-00 00:00:00'),(294,'http://poec.org/index.php/10-news/latest/21-s5-flex-menu-menu-system','','','',1,0,'2013-11-20 08:54:56','0000-00-00 00:00:00'),(295,'http://poec.org/index.php/component/content/article?id=article','','','',1,0,'2013-11-20 18:43:29','0000-00-00 00:00:00'),(296,'http://poec.org/trackback/','','http://poec.org/trackback/','',1,0,'2013-11-21 02:40:04','0000-00-00 00:00:00'),(297,'http://www.poec.org/index.php/address-information/10-news/latest/31-site-shapers','','','',1,0,'2013-11-22 12:43:17','0000-00-00 00:00:00'),(298,'http://www.poec.org/index.php/site-terms/10-news/latest/30-search-engine-optimized','','','',1,0,'2013-11-23 18:22:11','0000-00-00 00:00:00'),(299,'http://www.poec.org/index.php/address-information/10-news/latest/32-stock-photography','','','',1,0,'2013-11-23 19:11:21','0000-00-00 00:00:00'),(300,'http://www.poec.org/index.php/network-of-people/10-news/latest/32-stock-photography','','','',1,0,'2013-11-24 06:34:30','0000-00-00 00:00:00'),(301,'http://www.poec.org/index.php/network-of-people/2-uncategorised','','','',1,0,'2013-11-24 10:35:40','0000-00-00 00:00:00'),(302,'http://www.poec.org/index.php/get-to-know-us/2-uncategorised','','','',1,0,'2013-11-24 11:36:38','0000-00-00 00:00:00'),(303,'http://www.poec.org/index.php/non-profit-project/2-uncategorised','','','',1,0,'2013-11-24 13:32:04','0000-00-00 00:00:00'),(304,'http://www.poec.org/index.php/address-information/2-uncategorised','','','',1,0,'2013-11-24 14:39:52','0000-00-00 00:00:00'),(305,'http://www.poec.org/index.php/our-privacy-policy/2-uncategorised','','','',1,0,'2013-11-24 15:31:57','0000-00-00 00:00:00'),(306,'http://www.poec.org/index.php/customer-satisfaction/2-uncategorised','','','',1,0,'2013-11-24 16:39:36','0000-00-00 00:00:00'),(307,'http://www.poec.org/index.php/news/10-news/latest/32-stock-photography','','','',1,0,'2013-11-24 17:45:22','0000-00-00 00:00:00'),(308,'http://www.poec.org/index.php/aboutus/23-site-info','','','',1,0,'2013-11-24 18:24:58','0000-00-00 00:00:00'),(309,'http://www.poec.org/index.php/news/25-sample-article-2','','','',1,0,'2013-11-24 18:39:07','0000-00-00 00:00:00'),(310,'http://www.poec.org/index.php/news/26-sample-article-3','','','',1,0,'2013-11-24 19:10:28','0000-00-00 00:00:00'),(311,'http://www.poec.org/index.php/about-us/2-uncategorised/28-sample-content-2','','','',1,0,'2013-11-24 19:51:36','0000-00-00 00:00:00'),(312,'http://www.poec.org/index.php/network-of-people/10-news/latest/31-site-shapers','','','',1,0,'2013-11-24 19:55:18','0000-00-00 00:00:00'),(313,'http://www.poec.org/index.php/news/10-news/latest/33-template-specific-options','','','',1,0,'2013-11-24 19:55:21','0000-00-00 00:00:00'),(314,'http://www.poec.org/index.php/get-to-know-us/2-uncategorised/28-sample-content-2','','','',1,0,'2013-11-24 20:35:39','0000-00-00 00:00:00'),(315,'http://www.poec.org/index.php/network-of-people/2-uncategorised/28-sample-content-2','','','',1,0,'2013-11-24 20:39:11','0000-00-00 00:00:00'),(316,'http://www.poec.org/index.php/our-privacy-policy/2-uncategorised/28-sample-content-2','','','',1,0,'2013-11-24 21:23:40','0000-00-00 00:00:00'),(317,'http://www.poec.org/index.php/non-profit-project/2-uncategorised/28-sample-content-2','','','',1,0,'2013-11-24 21:23:54','0000-00-00 00:00:00'),(318,'http://www.poec.org/index.php/address-information/2-uncategorised/28-sample-content-2','','','',1,0,'2013-11-24 21:24:05','0000-00-00 00:00:00'),(319,'http://www.poec.org/index.php/customer-satisfaction/2-uncategorised/28-sample-content-2','','','',1,0,'2013-11-24 22:07:31','0000-00-00 00:00:00'),(320,'http://www.poec.org/index.php/non-profit-project/10-news/latest/31-site-shapers','','','',1,0,'2013-11-24 23:27:30','0000-00-00 00:00:00'),(321,'http://www.poec.org/index.php/aboutus/10-news/latest/35-the-template-s-settings','','','',1,0,'2013-11-24 23:28:32','0000-00-00 00:00:00'),(322,'http://www.poec.org/index.php/our-privacy-policy/10-news/latest/31-site-shapers','','','',1,0,'2013-11-24 23:30:13','0000-00-00 00:00:00'),(323,'http://www.poec.org/cuteeditor_files/Help/default.htm','','http://www.baidu.com','',1,0,'2013-11-25 00:09:15','0000-00-00 00:00:00'),(324,'http://www.poec.org/phpmyadmin/README','','http://www.baidu.com','',1,0,'2013-11-25 00:09:15','0000-00-00 00:00:00'),(325,'http://www.poec.org/Help/default.htm','','http://www.baidu.com','',1,0,'2013-11-25 00:09:16','0000-00-00 00:00:00'),(326,'http://www.poec.org/phpmyadmin/ChangeLog','','http://www.baidu.com','',1,0,'2013-11-25 00:09:17','0000-00-00 00:00:00'),(327,'http://www.poec.org/README','','http://www.baidu.com','',1,0,'2013-11-25 00:09:18','0000-00-00 00:00:00'),(328,'http://www.poec.org/editor/Dialog/about.htm','','http://www.baidu.com','',1,0,'2013-11-25 00:09:18','0000-00-00 00:00:00'),(329,'http://www.poec.org/editor/Help/default.htm','','http://www.baidu.com','',1,0,'2013-11-25 00:09:18','0000-00-00 00:00:00'),(330,'http://www.poec.org/ChangeLog','','http://www.baidu.com','',1,0,'2013-11-25 00:09:19','0000-00-00 00:00:00'),(331,'http://www.poec.org/index.php/aboutus/10-news/latest/31-site-shapers','','','',1,0,'2013-11-25 01:08:46','0000-00-00 00:00:00'),(332,'http://www.poec.org/index.php/featured/10-news/latest/31-site-shapers','','','',1,0,'2013-11-25 01:10:39','0000-00-00 00:00:00'),(333,'http://www.poec.org/index.php/about-us/10-news/latest/31-site-shapers','','','',1,0,'2013-11-25 01:10:52','0000-00-00 00:00:00'),(334,'http://www.poec.org/index.php/site-terms/10-news/latest/31-site-shapers','','','',1,0,'2013-11-25 01:11:04','0000-00-00 00:00:00'),(335,'http://www.poec.org/index.php/featured/10-news/latest/35-the-template-s-settings','','','',1,0,'2013-11-25 01:11:17','0000-00-00 00:00:00'),(336,'http://www.poec.org/index.php/aboutus/10-news/latest/32-stock-photography','','','',1,0,'2013-11-25 03:08:36','0000-00-00 00:00:00'),(337,'http://www.poec.org/index.php/featured/10-news/latest/32-stock-photography','','','',1,0,'2013-11-25 03:09:26','0000-00-00 00:00:00'),(338,'http://www.poec.org/index.php/get-to-know-us/10-news/latest/31-site-shapers','','','',1,0,'2013-11-25 03:10:16','0000-00-00 00:00:00'),(339,'http://www.poec.org/index.php/aboutus/10-news/latest/33-template-specific-options','','','',1,0,'2013-11-25 03:10:29','0000-00-00 00:00:00'),(340,'http://www.poec.org/index.php/site-terms/10-news/latest/32-stock-photography','','','',1,0,'2013-11-25 04:27:08','0000-00-00 00:00:00'),(341,'http://www.poec.org/index.php/customer-satisfaction/10-news/latest/31-site-shapers','','','',1,0,'2013-11-25 04:27:20','0000-00-00 00:00:00'),(342,'http://www.poec.org/index.php/about-us/10-news/latest/33-template-specific-options','','','',1,0,'2013-11-25 05:23:21','0000-00-00 00:00:00'),(343,'http://www.poec.org/index.php/our-privacy-policy/10-news/latest/32-stock-photography','','','',1,0,'2013-11-25 05:24:20','0000-00-00 00:00:00'),(344,'http://www.poec.org/index.php/site-terms/10-news/latest/33-template-specific-options','','','',1,0,'2013-11-25 06:23:01','0000-00-00 00:00:00'),(345,'http://www.poec.org/index.php/non-profit-project/10-news/latest/32-stock-photography','','','',1,0,'2013-11-25 06:23:14','0000-00-00 00:00:00'),(346,'http://www.poec.org/index.php/news/10-news/latest/31-site-shapers','','','',1,0,'2013-11-25 07:21:30','0000-00-00 00:00:00'),(347,'http://www.poec.org/index.php/news/10-news/latest/35-the-template-s-settings','','','',1,0,'2013-11-25 07:22:06','0000-00-00 00:00:00'),(348,'http://www.poec.org/index.php/10-news/latest/30-search-engine-optimized','','','',1,0,'2013-11-25 09:23:09','0000-00-00 00:00:00'),(349,'http://poec.org/index.php/about-us/2-uncategorised/29-sample-content-3','','','',1,0,'2013-11-26 02:48:16','0000-00-00 00:00:00'),(350,'http://poec.org/index.php/modules/mod_s5_box/images/internet_explorer/borderTopCenter.png','','http://poec.org/index.php/jobs','',1,0,'2013-11-27 02:52:14','0000-00-00 00:00:00'),(351,'http://poec.org/index.php/modules/mod_s5_box/images/internet_explorer/borderBottomLeft.png','','http://poec.org/index.php/jobs','',1,0,'2013-11-27 02:52:14','0000-00-00 00:00:00'),(352,'http://poec.org/index.php/modules/mod_s5_box/images/internet_explorer/borderMiddleRight.png','','http://poec.org/index.php/jobs','',1,0,'2013-11-27 02:52:14','0000-00-00 00:00:00'),(353,'http://poec.org/index.php/modules/mod_s5_box/images/internet_explorer/borderMiddleLeft.png','','http://poec.org/index.php/jobs','',1,0,'2013-11-27 02:52:14','0000-00-00 00:00:00'),(354,'http://poec.org/index.php/modules/mod_s5_box/images/internet_explorer/borderBottomRight.png','','http://poec.org/index.php/jobs','',1,0,'2013-11-27 02:52:14','0000-00-00 00:00:00'),(355,'http://poec.org/index.php/modules/mod_s5_box/images/internet_explorer/borderBottomCenter.png','','http://poec.org/index.php/jobs','',1,0,'2013-11-27 02:52:14','0000-00-00 00:00:00'),(356,'http://poec.org/index.php/modules/mod_s5_box/images/internet_explorer/borderTopRight.png','','http://poec.org/index.php/jobs','',1,0,'2013-11-27 02:52:15','0000-00-00 00:00:00'),(357,'http://poec.org/index.php/modules/mod_s5_box/images/internet_explorer/borderTopLeft.png','','http://poec.org/index.php/jobs','',1,0,'2013-11-27 02:52:15','0000-00-00 00:00:00'),(358,'http://www.poec.org/index.php/customer-satisfaction/2-uncategorised/29-sample-content-3','','','',1,0,'2013-11-27 14:26:51','0000-00-00 00:00:00'),(359,'http://www.poec.org/index.php/our-privacy-policy/2-uncategorised/29-sample-content-3','','','',1,0,'2013-11-29 15:38:55','0000-00-00 00:00:00'),(360,'http://www.poec.org/index.php/network-of-people/2-uncategorised/29-sample-content-3','','','',1,0,'2013-11-29 21:40:39','0000-00-00 00:00:00'),(361,'http://www.poec.org/index.php/non-profit-project/2-uncategorised/29-sample-content-3','','','',1,0,'2013-11-29 21:48:55','0000-00-00 00:00:00'),(362,'http://poec.org/index.php/get-to-know-us/2-uncategorised','','','',1,0,'2013-12-02 19:23:54','0000-00-00 00:00:00'),(363,'http://www.poec.org/itrk3/files/pdfs/whatworksHypothesis.pdf','','','',1,0,'2013-12-04 09:13:56','0000-00-00 00:00:00'),(364,'http://poec.org/index.php/network-of-people/10-news/latest/31-site-shapers','','','',1,0,'2013-12-06 08:01:55','0000-00-00 00:00:00'),(365,'http://poec.org/index.php/non-profit-project/10-news/latest/31-site-shapers','','','',1,0,'2013-12-06 09:56:45','0000-00-00 00:00:00'),(366,'http://www.poec.org/index.php/get-to-know-us/10-news/latest/33-template-specific-options','','','',1,0,'2013-12-06 11:49:38','0000-00-00 00:00:00'),(367,'http://www.poec.org/index.php/network-of-people/10-news/latest/22-s5-frontpage-display','','','',1,0,'2013-12-06 11:51:12','0000-00-00 00:00:00'),(368,'http://poec.org/index.php/aboutus/10-news/latest/35-the-template-s-settings','','','',1,0,'2013-12-06 11:53:33','0000-00-00 00:00:00'),(369,'http://www.poec.org/index.php/non-profit-project/10-news/latest','','','',1,0,'2013-12-06 11:54:24','0000-00-00 00:00:00'),(370,'http://poec.org/index.php/site-terms/10-news/latest/33-template-specific-options','','','',1,0,'2013-12-06 11:56:33','0000-00-00 00:00:00'),(371,'http://www.poec.org/index.php/our-privacy-policy/9-news','','','',1,0,'2013-12-06 12:50:17','0000-00-00 00:00:00'),(372,'http://poec.org/index.php/aboutus/10-news/latest/31-site-shapers','','','',1,0,'2013-12-06 12:51:42','0000-00-00 00:00:00'),(373,'http://poec.org/index.php/address-information/10-news/latest/32-stock-photography','','','',1,0,'2013-12-06 12:54:49','0000-00-00 00:00:00'),(374,'http://www.poec.org/index.php/featured/9-news','','','',1,0,'2013-12-06 12:55:18','0000-00-00 00:00:00'),(375,'http://poec.org/index.php/get-to-know-us/10-news/latest/33-template-specific-options','','','',1,0,'2013-12-06 12:59:57','0000-00-00 00:00:00'),(376,'http://www.poec.org/index.php/non-profit-project/10-news/latest/23-s5-tab-show','','','',1,0,'2013-12-06 13:58:08','0000-00-00 00:00:00'),(377,'http://www.poec.org/index.php/get-to-know-us/10-news/latest/35-the-template-s-settings','','','',1,0,'2013-12-06 13:58:48','0000-00-00 00:00:00'),(378,'http://www.poec.org/index.php/our-privacy-policy/10-news/latest/22-s5-frontpage-display','','','',1,0,'2013-12-06 14:00:53','0000-00-00 00:00:00'),(379,'http://www.poec.org/index.php/our-privacy-policy/10-news/latest','','','',1,0,'2013-12-06 15:03:30','0000-00-00 00:00:00'),(380,'http://www.poec.org/index.php/customer-satisfaction/10-news/latest','','','',1,0,'2013-12-06 15:06:35','0000-00-00 00:00:00'),(381,'http://poec.org/index.php/address-information/10-news/latest/33-template-specific-options','','','',1,0,'2013-12-06 15:08:53','0000-00-00 00:00:00'),(382,'http://www.poec.org/index.php/site-terms/9-news','','','',1,0,'2013-12-06 15:45:23','0000-00-00 00:00:00'),(383,'http://www.poec.org/index.php/network-of-people/10-news/latest','','','',1,0,'2013-12-06 16:15:42','0000-00-00 00:00:00'),(384,'http://www.poec.org/index.php/customer-satisfaction/9-news','','','',1,0,'2013-12-06 17:26:34','0000-00-00 00:00:00'),(385,'http://www.poec.org/index.php/customer-satisfaction/10-news/latest/22-s5-frontpage-display','','','',1,0,'2013-12-06 17:29:49','0000-00-00 00:00:00'),(386,'http://www.poec.org/index.php/non-profit-project/10-news/latest/22-s5-frontpage-display','','','',1,0,'2013-12-06 17:32:24','0000-00-00 00:00:00'),(387,'http://www.poec.org/index.php/our-privacy-policy/10-news/latest/23-s5-tab-show','','','',1,0,'2013-12-06 17:34:03','0000-00-00 00:00:00'),(388,'http://poec.org/index.php/non-profit-project/10-news/latest/33-template-specific-options','','','',1,0,'2013-12-06 17:37:33','0000-00-00 00:00:00'),(389,'http://www.poec.org/index.php/non-profit-project/9-news','','','',1,0,'2013-12-06 18:45:19','0000-00-00 00:00:00'),(390,'http://www.poec.org/index.php/address-information/10-news/latest/33-template-specific-options','','','',1,0,'2013-12-06 18:58:06','0000-00-00 00:00:00'),(391,'http://www.poec.org/index.php/8-frontpage/38-homepage-article-2','','','',1,0,'2013-12-06 20:58:53','0000-00-00 00:00:00'),(392,'http://www.poec.org/index.php/8-frontpage/34-homepage-article-1','','','',1,0,'2013-12-07 00:18:47','0000-00-00 00:00:00'),(393,'http://www.poec.org/index.php/address-information/10-news/latest/35-the-template-s-settings','','','',1,0,'2013-12-07 02:49:28','0000-00-00 00:00:00'),(394,'http://poec.org/index.php/20-frontpage/index.php/20-frontpage/index.php','','http://poec.org/index.php','',1,0,'2013-12-07 14:55:07','0000-00-00 00:00:00'),(395,'http://www.poec.org/index.php/network-of-people/10-news/latest/35-the-template-s-settings','','','',1,0,'2013-12-07 15:55:30','0000-00-00 00:00:00'),(396,'http://www.poec.org//index.php/Contact.us','','','',1,0,'2013-12-08 06:52:49','0000-00-00 00:00:00'),(397,'http://www.poec.org/index.php/registration','','','',1,0,'2013-12-09 06:04:51','0000-00-00 00:00:00'),(398,'http://www.poec.org/index.php/modules/mod_s5_box/images/internet_explorer/borderMiddleRight.png','','http://www.poec.org/index.php/login','',1,0,'2013-12-09 06:11:12','0000-00-00 00:00:00'),(399,'http://www.poec.org/index.php/modules/mod_s5_box/images/internet_explorer/borderBottomCenter.png','','http://www.poec.org/index.php/login','',1,0,'2013-12-09 06:11:12','0000-00-00 00:00:00'),(400,'http://www.poec.org/index.php/modules/mod_s5_box/images/internet_explorer/borderMiddleLeft.png','','http://www.poec.org/index.php/login','',1,0,'2013-12-09 06:11:12','0000-00-00 00:00:00'),(401,'http://www.poec.org/index.php/modules/mod_s5_box/images/internet_explorer/borderTopCenter.png','','http://www.poec.org/index.php/login','',1,0,'2013-12-09 06:11:12','0000-00-00 00:00:00'),(402,'http://www.poec.org/index.php/modules/mod_s5_box/images/internet_explorer/borderTopLeft.png','','http://www.poec.org/index.php/login','',1,0,'2013-12-09 06:11:13','0000-00-00 00:00:00'),(403,'http://www.poec.org/index.php/modules/mod_s5_box/images/internet_explorer/borderBottomLeft.png','','http://www.poec.org/index.php/login','',1,0,'2013-12-09 06:11:13','0000-00-00 00:00:00'),(404,'http://www.poec.org/index.php/modules/mod_s5_box/images/internet_explorer/borderBottomRight.png','','http://www.poec.org/index.php/login','',1,0,'2013-12-09 06:11:13','0000-00-00 00:00:00'),(405,'http://www.poec.org/index.php/modules/mod_s5_box/images/internet_explorer/borderTopRight.png','','http://www.poec.org/index.php/login','',1,0,'2013-12-09 06:11:13','0000-00-00 00:00:00'),(406,'http://poec.org/administrator/jsjobsdata/data/jobseeker/resume_1/resume/resume.pdf','','http://poec.org/administrator/index.php?option=com_jsjobs&view=application&layout=view_resume&rd=1&oi=1','',1,0,'2013-12-09 12:26:55','0000-00-00 00:00:00'),(407,'http://www.poec.org/index.php/,','','','',1,0,'2013-12-10 15:07:25','0000-00-00 00:00:00'),(408,'http://poec.org/index.php/jobs/jsjobs/jobseeker/jobcat','','','',1,0,'2013-12-10 16:57:15','0000-00-00 00:00:00'),(409,'http://poec.org/index.php/jobs','','','',1,0,'2013-12-10 17:52:18','0000-00-00 00:00:00'),(410,'http://poec.org/index.php/employer','','','',1,0,'2013-12-10 18:43:53','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `jom_redirect_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_responses`
--

DROP TABLE IF EXISTS `jom_responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_responses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `parent_id` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set parent.',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `level` int(11) unsigned NOT NULL COMMENT 'The cached level in the nested tree.',
  `extension` varchar(50) NOT NULL DEFAULT '' COMMENT 'Joomla! Extension that this response',
  `content_id` int(10) unsigned NOT NULL COMMENT 'Response to Primary Key for Content',
  `content_title` varchar(255) NOT NULL DEFAULT 'Resposne to Primary Key Content Title',
  `catid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Response to Content Category ID',
  `response_type` tinyint(3) NOT NULL DEFAULT '0' COMMENT '1: Comment 2: Content Rating 3: Social Bookmark 4: Poll Response 5: Email Subscription Response 6: Statistical Log 7: Trackback',
  `title` varchar(255) NOT NULL DEFAULT 'Response Title',
  `alias` varchar(255) NOT NULL DEFAULT 'Response Alias',
  `textual_response` mediumtext NOT NULL COMMENT 'Textual Response to Content',
  `numeric_response` int(11) NOT NULL DEFAULT '0' COMMENT 'Numeric Resposne to Content',
  `linked_response` varchar(255) NOT NULL DEFAULT '' COMMENT 'Linked Response to Content',
  `subscription_response` varchar(255) NOT NULL DEFAULT '' COMMENT 'Email Subscription to Content',
  `state` tinyint(3) NOT NULL DEFAULT '0' COMMENT 'State',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Created Date and Time',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Created By User ID, if Member',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '' COMMENT 'Created By Alias',
  `created_by_email` varchar(255) NOT NULL DEFAULT '' COMMENT 'Created By Email Address',
  `created_by_website` varchar(255) NOT NULL DEFAULT '' COMMENT 'Created By Website',
  `created_by_ip_address` varchar(10) NOT NULL DEFAULT '' COMMENT 'Created By IP Address',
  `created_by_referer` varchar(10) NOT NULL DEFAULT '' COMMENT 'Created By Referer',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Modified Date and Time',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Modified By User ID',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Checked Out User ID',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Checked Out Date and Time',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Publish Up Date and Time',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Publish Down Date and Time',
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if response item is featured.',
  `language` char(7) NOT NULL COMMENT 'The language code for the response.',
  `ordering` int(11) NOT NULL DEFAULT '0' COMMENT 'Ordering within the Content Item.',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`state`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_extension` (`extension`,`content_id`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_responses`
--

LOCK TABLES `jom_responses` WRITE;
/*!40000 ALTER TABLE `jom_responses` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_responses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_schemas`
--

DROP TABLE IF EXISTS `jom_schemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_schemas` (
  `extension_id` int(11) NOT NULL,
  `version_id` varchar(20) NOT NULL,
  PRIMARY KEY (`extension_id`,`version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_schemas`
--

LOCK TABLES `jom_schemas` WRITE;
/*!40000 ALTER TABLE `jom_schemas` DISABLE KEYS */;
INSERT INTO `jom_schemas` (`extension_id`, `version_id`) VALUES (700,'3.2.0'),(10050,'1.0.4'),(10090,'1.9.0'),(10091,'2.1.3');
/*!40000 ALTER TABLE `jom_schemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_session`
--

DROP TABLE IF EXISTS `jom_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_session` (
  `session_id` varchar(200) NOT NULL DEFAULT '',
  `client_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `guest` tinyint(4) unsigned DEFAULT '1',
  `time` varchar(14) DEFAULT '',
  `data` mediumtext,
  `userid` int(11) DEFAULT '0',
  `username` varchar(150) DEFAULT '',
  PRIMARY KEY (`session_id`),
  KEY `userid` (`userid`),
  KEY `time` (`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_session`
--

LOCK TABLES `jom_session` WRITE;
/*!40000 ALTER TABLE `jom_session` DISABLE KEYS */;
INSERT INTO `jom_session` (`session_id`, `client_id`, `guest`, `time`, `data`, `userid`, `username`) VALUES ('358bbc7366c09e308441e784232515f4',1,1,'1386762414','__default|a:8:{s:15:\"session.counter\";i:1;s:19:\"session.timer.start\";i:1386762414;s:18:\"session.timer.last\";i:1386762414;s:17:\"session.timer.now\";i:1386762414;s:22:\"session.client.browser\";s:108:\"Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.63 Safari/537.36\";s:8:\"registry\";O:9:\"JRegistry\":1:{s:7:\"\\0\\0\\0data\";O:8:\"stdClass\":0:{}}s:4:\"user\";O:5:\"JUser\":24:{s:9:\"\\0\\0\\0isRoot\";N;s:2:\"id\";i:0;s:4:\"name\";N;s:8:\"username\";N;s:5:\"email\";N;s:8:\"password\";N;s:14:\"password_clear\";s:0:\"\";s:5:\"block\";N;s:9:\"sendEmail\";i:0;s:12:\"registerDate\";N;s:13:\"lastvisitDate\";N;s:10:\"activation\";N;s:6:\"params\";N;s:6:\"groups\";a:1:{i:0;s:1:\"1\";}s:5:\"guest\";i:1;s:13:\"lastResetTime\";N;s:10:\"resetCount\";N;s:10:\"\\0\\0\\0_params\";O:9:\"JRegistry\":1:{s:7:\"\\0\\0\\0data\";O:8:\"stdClass\":0:{}}s:14:\"\\0\\0\\0_authGroups\";N;s:14:\"\\0\\0\\0_authLevels\";a:2:{i:0;i:1;i:1;i:1;}s:15:\"\\0\\0\\0_authActions\";N;s:12:\"\\0\\0\\0_errorMsg\";N;s:10:\"\\0\\0\\0_errors\";a:0:{}s:3:\"aid\";i:0;}s:13:\"session.token\";s:32:\"484463d5f51c86df157f277d33d8db55\";}',0,''),('7fa95f6751a660a18bf20a5db275b8e8',0,1,'1386762408','__default|a:7:{s:15:\"session.counter\";i:7;s:19:\"session.timer.start\";i:1386761446;s:18:\"session.timer.last\";i:1386762320;s:17:\"session.timer.now\";i:1386762407;s:22:\"session.client.browser\";s:72:\"Mozilla/5.0 (Windows NT 6.3; WOW64; rv:25.0) Gecko/20100101 Firefox/25.0\";s:8:\"registry\";O:9:\"JRegistry\":1:{s:7:\"\\0\\0\\0data\";O:8:\"stdClass\":0:{}}s:4:\"user\";O:5:\"JUser\":24:{s:9:\"\\0\\0\\0isRoot\";b:0;s:2:\"id\";i:0;s:4:\"name\";N;s:8:\"username\";N;s:5:\"email\";N;s:8:\"password\";N;s:14:\"password_clear\";s:0:\"\";s:5:\"block\";N;s:9:\"sendEmail\";i:0;s:12:\"registerDate\";N;s:13:\"lastvisitDate\";N;s:10:\"activation\";N;s:6:\"params\";N;s:6:\"groups\";a:1:{i:0;s:1:\"1\";}s:5:\"guest\";i:1;s:13:\"lastResetTime\";N;s:10:\"resetCount\";N;s:10:\"\\0\\0\\0_params\";O:9:\"JRegistry\":1:{s:7:\"\\0\\0\\0data\";O:8:\"stdClass\":0:{}}s:14:\"\\0\\0\\0_authGroups\";a:1:{i:0;i:1;}s:14:\"\\0\\0\\0_authLevels\";a:2:{i:0;i:1;i:1;i:1;}s:15:\"\\0\\0\\0_authActions\";N;s:12:\"\\0\\0\\0_errorMsg\";N;s:10:\"\\0\\0\\0_errors\";a:0:{}s:3:\"aid\";i:0;}}JSItemid|s:3:\"275\";',0,''),('b2290e1ff94c3bfb51c49de441ea06e2',1,0,'1386762491','__default|a:8:{s:15:\"session.counter\";i:5;s:19:\"session.timer.start\";i:1386762439;s:18:\"session.timer.last\";i:1386762486;s:17:\"session.timer.now\";i:1386762488;s:22:\"session.client.browser\";s:108:\"Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.63 Safari/537.36\";s:8:\"registry\";O:9:\"JRegistry\":1:{s:7:\"\\0\\0\\0data\";O:8:\"stdClass\":3:{s:18:\"plg_sys_adminexile\";O:8:\"stdClass\":1:{s:9:\"pixxelsis\";b:1;}s:11:\"application\";O:8:\"stdClass\":1:{s:4:\"lang\";s:5:\"en-GB\";}s:13:\"com_installer\";O:8:\"stdClass\":2:{s:7:\"message\";s:0:\"\";s:17:\"extension_message\";s:0:\"\";}}}s:4:\"user\";O:5:\"JUser\":26:{s:9:\"\\0\\0\\0isRoot\";b:1;s:2:\"id\";s:3:\"335\";s:4:\"name\";s:10:\"Super User\";s:8:\"username\";s:5:\"admin\";s:5:\"email\";s:17:\"ressfos@gmail.com\";s:8:\"password\";s:60:\"$2y$10$kdV4yZfrAVoANYYmP7Mk7uw.mp5doCrvEIpUm2Hg7PSnSErctFg8a\";s:14:\"password_clear\";s:0:\"\";s:5:\"block\";s:1:\"0\";s:9:\"sendEmail\";s:1:\"1\";s:12:\"registerDate\";s:19:\"2013-10-28 18:08:42\";s:13:\"lastvisitDate\";s:19:\"2013-12-11 11:45:57\";s:10:\"activation\";s:1:\"0\";s:6:\"params\";s:92:\"{\"admin_style\":\"\",\"admin_language\":\"\",\"language\":\"\",\"editor\":\"\",\"helpsite\":\"\",\"timezone\":\"\"}\";s:6:\"groups\";a:1:{i:8;s:1:\"8\";}s:5:\"guest\";i:0;s:13:\"lastResetTime\";s:19:\"0000-00-00 00:00:00\";s:10:\"resetCount\";s:1:\"0\";s:10:\"\\0\\0\\0_params\";O:9:\"JRegistry\":1:{s:7:\"\\0\\0\\0data\";O:8:\"stdClass\":6:{s:11:\"admin_style\";s:0:\"\";s:14:\"admin_language\";s:0:\"\";s:8:\"language\";s:0:\"\";s:6:\"editor\";s:0:\"\";s:8:\"helpsite\";s:0:\"\";s:8:\"timezone\";s:0:\"\";}}s:14:\"\\0\\0\\0_authGroups\";a:2:{i:0;i:1;i:1;i:8;}s:14:\"\\0\\0\\0_authLevels\";a:4:{i:0;i:1;i:1;i:1;i:2;i:2;i:3;i:3;}s:15:\"\\0\\0\\0_authActions\";N;s:12:\"\\0\\0\\0_errorMsg\";N;s:10:\"\\0\\0\\0_errors\";a:1:{i:0;s:28:\"User not Super Administrator\";}s:3:\"aid\";i:0;s:6:\"otpKey\";s:0:\"\";s:4:\"otep\";s:0:\"\";}s:13:\"session.token\";s:32:\"5c68b2622264999c0830d023d8119e5d\";}__wf|a:1:{s:13:\"session.token\";s:32:\"4a2a7848f7776d2e6c94083eedef4257\";}',335,'admin'),('c4fb510c5732d42fc4b9db5ebf6c0f9f',0,1,'1386762415','__default|a:7:{s:15:\"session.counter\";i:1;s:19:\"session.timer.start\";i:1386762415;s:18:\"session.timer.last\";i:1386762415;s:17:\"session.timer.now\";i:1386762415;s:22:\"session.client.browser\";s:108:\"Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.63 Safari/537.36\";s:8:\"registry\";O:9:\"JRegistry\":1:{s:7:\"\\0\\0\\0data\";O:8:\"stdClass\":0:{}}s:4:\"user\";O:5:\"JUser\":24:{s:9:\"\\0\\0\\0isRoot\";b:0;s:2:\"id\";i:0;s:4:\"name\";N;s:8:\"username\";N;s:5:\"email\";N;s:8:\"password\";N;s:14:\"password_clear\";s:0:\"\";s:5:\"block\";N;s:9:\"sendEmail\";i:0;s:12:\"registerDate\";N;s:13:\"lastvisitDate\";N;s:10:\"activation\";N;s:6:\"params\";N;s:6:\"groups\";a:1:{i:0;s:1:\"1\";}s:5:\"guest\";i:1;s:13:\"lastResetTime\";N;s:10:\"resetCount\";N;s:10:\"\\0\\0\\0_params\";O:9:\"JRegistry\":1:{s:7:\"\\0\\0\\0data\";O:8:\"stdClass\":0:{}}s:14:\"\\0\\0\\0_authGroups\";a:1:{i:0;i:1;}s:14:\"\\0\\0\\0_authLevels\";a:2:{i:0;i:1;i:1;i:1;}s:15:\"\\0\\0\\0_authActions\";N;s:12:\"\\0\\0\\0_errorMsg\";N;s:10:\"\\0\\0\\0_errors\";a:0:{}s:3:\"aid\";i:0;}}JSItemid|s:3:\"275\";',0,'');
/*!40000 ALTER TABLE `jom_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_tag_content`
--

DROP TABLE IF EXISTS `jom_tag_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_tag_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `tag_id` int(10) unsigned NOT NULL COMMENT 'Tag to Primary Key for Content',
  `extension` varchar(50) NOT NULL DEFAULT '' COMMENT 'Joomla! Extension associated with this Tag',
  `content_id` int(10) unsigned NOT NULL COMMENT 'Tag to Primary Key for Content',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`tag_id`),
  KEY `idx_extension` (`extension`,`content_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_tag_content`
--

LOCK TABLES `jom_tag_content` WRITE;
/*!40000 ALTER TABLE `jom_tag_content` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_tag_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_tags`
--

DROP TABLE IF EXISTS `jom_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0',
  `level` int(10) unsigned NOT NULL DEFAULT '0',
  `path` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `metadesc` varchar(1024) NOT NULL COMMENT 'The meta description for the page.',
  `metakey` varchar(1024) NOT NULL COMMENT 'The meta keywords for the page.',
  `metadata` varchar(2048) NOT NULL COMMENT 'JSON encoded metadata properties.',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `images` text NOT NULL,
  `urls` text NOT NULL,
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `tag_idx` (`published`,`access`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_path` (`path`),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_alias` (`alias`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_tags`
--

LOCK TABLES `jom_tags` WRITE;
/*!40000 ALTER TABLE `jom_tags` DISABLE KEYS */;
INSERT INTO `jom_tags` (`id`, `parent_id`, `lft`, `rgt`, `level`, `path`, `title`, `alias`, `note`, `description`, `published`, `checked_out`, `checked_out_time`, `access`, `params`, `metadesc`, `metakey`, `metadata`, `created_user_id`, `created_time`, `created_by_alias`, `modified_user_id`, `modified_time`, `images`, `urls`, `hits`, `language`, `version`, `publish_up`, `publish_down`) VALUES (1,0,0,1,0,'','ROOT','root','','',1,0,'0000-00-00 00:00:00',1,'{}','','','',0,'2011-01-01 00:00:01','',0,'0000-00-00 00:00:00','','',0,'*',1,'0000-00-00 00:00:00','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `jom_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_template_styles`
--

DROP TABLE IF EXISTS `jom_template_styles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_template_styles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `template` varchar(50) NOT NULL DEFAULT '',
  `client_id` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `home` char(7) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_template` (`template`),
  KEY `idx_home` (`home`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_template_styles`
--

LOCK TABLES `jom_template_styles` WRITE;
/*!40000 ALTER TABLE `jom_template_styles` DISABLE KEYS */;
INSERT INTO `jom_template_styles` (`id`, `template`, `client_id`, `home`, `title`, `params`) VALUES (2,'bluestork',1,'0','Bluestork - Default','{\"useRoundedCorners\":\"1\",\"showSiteName\":\"0\"}'),(3,'atomic',0,'0','Atomic - Default','{}'),(4,'beez_20',0,'0','Beez2 - Default','{\"wrapperSmall\":\"53\",\"wrapperLarge\":\"72\",\"logo\":\"images\\/joomla_black.gif\",\"sitetitle\":\"Joomla!\",\"sitedescription\":\"Open Source Content Management\",\"navposition\":\"left\",\"templatecolor\":\"personal\",\"html5\":\"0\"}'),(5,'hathor',1,'0','Hathor - Default','{\"showSiteName\":\"0\",\"colourChoice\":\"\",\"boldText\":\"0\"}'),(6,'beez5',0,'0','Beez5 - Default-Fruit Shop','{\"wrapperSmall\":\"53\",\"wrapperLarge\":\"72\",\"logo\":\"images\\/sampledata\\/fruitshop\\/fruits.gif\",\"sitetitle\":\"Matuna Market \",\"sitedescription\":\"Fruit Shop Sample Site\",\"navposition\":\"left\",\"html5\":\"0\"}'),(8,'ja_purity',0,'0','ja_purity',''),(9,'rhuk_milkyway',0,'0','rhuk_milkyway',''),(17,'test',0,'0','test - Default','{\"settings\":\"\"}'),(18,'new_vision',0,'1','new_vision - Default','{\"settings\":\"\"}'),(20,'protostar',0,'0','protostar - Default','{\"templateColor\":\"\",\"logoFile\":\"\",\"googleFont\":\"1\",\"googleFontName\":\"Open+Sans\",\"fluidContainer\":\"0\"}'),(21,'isis',1,'1','isis - Default','{\"templateColor\":\"\",\"logoFile\":\"\"}'),(22,'beez3',0,'0','beez3 - Default','{\"wrapperSmall\":53,\"wrapperLarge\":72,\"logo\":\"\",\"sitetitle\":\"\",\"sitedescription\":\"\",\"navposition\":\"center\",\"bootstrap\":\"\",\"templatecolor\":\"nature\",\"headerImage\":\"\",\"backgroundcolor\":\"#eee\"}');
/*!40000 ALTER TABLE `jom_template_styles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_ucm_content`
--

DROP TABLE IF EXISTS `jom_ucm_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_ucm_content` (
  `core_content_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `core_type_alias` varchar(255) NOT NULL DEFAULT '' COMMENT 'FK to the content types table',
  `core_title` varchar(255) NOT NULL,
  `core_alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `core_body` mediumtext NOT NULL,
  `core_state` tinyint(1) NOT NULL DEFAULT '0',
  `core_checked_out_time` varchar(255) NOT NULL DEFAULT '',
  `core_checked_out_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `core_access` int(10) unsigned NOT NULL DEFAULT '0',
  `core_params` text NOT NULL,
  `core_featured` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `core_metadata` varchar(2048) NOT NULL COMMENT 'JSON encoded metadata properties.',
  `core_created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `core_created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `core_created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `core_modified_user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Most recent user that modified',
  `core_modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `core_language` char(7) NOT NULL,
  `core_publish_up` datetime NOT NULL,
  `core_publish_down` datetime NOT NULL,
  `core_content_item_id` int(10) unsigned DEFAULT NULL COMMENT 'ID from the individual type table',
  `asset_id` int(10) unsigned DEFAULT NULL COMMENT 'FK to the #__assets table.',
  `core_images` text NOT NULL,
  `core_urls` text NOT NULL,
  `core_hits` int(10) unsigned NOT NULL DEFAULT '0',
  `core_version` int(10) unsigned NOT NULL DEFAULT '1',
  `core_ordering` int(11) NOT NULL DEFAULT '0',
  `core_metakey` text NOT NULL,
  `core_metadesc` text NOT NULL,
  `core_catid` int(10) unsigned NOT NULL DEFAULT '0',
  `core_xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `core_type_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`core_content_id`),
  KEY `tag_idx` (`core_state`,`core_access`),
  KEY `idx_access` (`core_access`),
  KEY `idx_alias` (`core_alias`),
  KEY `idx_language` (`core_language`),
  KEY `idx_title` (`core_title`),
  KEY `idx_modified_time` (`core_modified_time`),
  KEY `idx_created_time` (`core_created_time`),
  KEY `idx_content_type` (`core_type_alias`),
  KEY `idx_core_modified_user_id` (`core_modified_user_id`),
  KEY `idx_core_checked_out_user_id` (`core_checked_out_user_id`),
  KEY `idx_core_created_user_id` (`core_created_user_id`),
  KEY `idx_core_type_id` (`core_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Contains core content data in name spaced fields';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_ucm_content`
--

LOCK TABLES `jom_ucm_content` WRITE;
/*!40000 ALTER TABLE `jom_ucm_content` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_ucm_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_ucm_history`
--

DROP TABLE IF EXISTS `jom_ucm_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_ucm_history` (
  `version_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ucm_item_id` int(10) unsigned NOT NULL,
  `ucm_type_id` int(10) unsigned NOT NULL,
  `version_note` varchar(255) NOT NULL DEFAULT '' COMMENT 'Optional version name',
  `save_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `editor_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `character_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Number of characters in this version.',
  `sha1_hash` varchar(50) NOT NULL DEFAULT '' COMMENT 'SHA1 hash of the version_data column.',
  `version_data` mediumtext NOT NULL COMMENT 'json-encoded string of version data',
  `keep_forever` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0=auto delete; 1=keep',
  PRIMARY KEY (`version_id`),
  KEY `idx_ucm_item_id` (`ucm_type_id`,`ucm_item_id`),
  KEY `idx_save_date` (`save_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_ucm_history`
--

LOCK TABLES `jom_ucm_history` WRITE;
/*!40000 ALTER TABLE `jom_ucm_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_ucm_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_update_sites`
--

DROP TABLE IF EXISTS `jom_update_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_update_sites` (
  `update_site_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '',
  `type` varchar(20) DEFAULT '',
  `location` text NOT NULL,
  `enabled` int(11) DEFAULT '0',
  `last_check_timestamp` bigint(20) DEFAULT '0',
  PRIMARY KEY (`update_site_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='Update Sites';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_update_sites`
--

LOCK TABLES `jom_update_sites` WRITE;
/*!40000 ALTER TABLE `jom_update_sites` DISABLE KEYS */;
INSERT INTO `jom_update_sites` (`update_site_id`, `name`, `type`, `location`, `enabled`, `last_check_timestamp`) VALUES (1,'Joomla Core','collection','http://update.joomla.org/core/list.xml',1,1386762488),(2,'Joomla Extension Directory','collection','http://update.joomla.org/jed/list.xml',0,0),(3,'Accredited Joomla! Translations','collection','http://update.joomla.org/language/translationlist_3.xml',1,1386762488),(4,'Foxcontact update site','extension','http://www.fox.ra.it/phocadownload/foxcontact.xml',1,1386762488),(5,'JCE Editor Updates','extension','https://www.joomlacontenteditor.net/index.php?option=com_updates&view=update&format=xml&id=1',1,1386762488),(6,'JCE Editor Updates','extension','https://www.joomlacontenteditor.net/index.php?option=com_updates&view=update&format=xml&id=1&file=extension.xml',1,1386762488),(7,'WebInstaller Update Site','extension','http://appscdn.joomla.org/webapps/jedapps/webinstaller.xml',1,1386762488),(8,'Kunena 3.0 Update Site','collection','http://update.kunena.org/3.0/list.xml',1,1386762488);
/*!40000 ALTER TABLE `jom_update_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_update_sites_extensions`
--

DROP TABLE IF EXISTS `jom_update_sites_extensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_update_sites_extensions` (
  `update_site_id` int(11) NOT NULL DEFAULT '0',
  `extension_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`update_site_id`,`extension_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Links extensions to update sites';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_update_sites_extensions`
--

LOCK TABLES `jom_update_sites_extensions` WRITE;
/*!40000 ALTER TABLE `jom_update_sites_extensions` DISABLE KEYS */;
INSERT INTO `jom_update_sites_extensions` (`update_site_id`, `extension_id`) VALUES (1,700),(2,700),(3,600),(4,10090),(5,10094),(6,10094),(7,10096),(8,10102);
/*!40000 ALTER TABLE `jom_update_sites_extensions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_updates`
--

DROP TABLE IF EXISTS `jom_updates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_updates` (
  `update_id` int(11) NOT NULL AUTO_INCREMENT,
  `update_site_id` int(11) DEFAULT '0',
  `extension_id` int(11) DEFAULT '0',
  `name` varchar(100) DEFAULT '',
  `description` text NOT NULL,
  `element` varchar(100) DEFAULT '',
  `type` varchar(20) DEFAULT '',
  `folder` varchar(20) DEFAULT '',
  `client_id` tinyint(3) DEFAULT '0',
  `version` varchar(10) DEFAULT '',
  `data` text NOT NULL,
  `detailsurl` text NOT NULL,
  `infourl` text NOT NULL,
  PRIMARY KEY (`update_id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8 COMMENT='Available Updates';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_updates`
--

LOCK TABLES `jom_updates` WRITE;
/*!40000 ALTER TABLE `jom_updates` DISABLE KEYS */;
INSERT INTO `jom_updates` (`update_id`, `update_site_id`, `extension_id`, `name`, `description`, `element`, `type`, `folder`, `client_id`, `version`, `data`, `detailsurl`, `infourl`) VALUES (1,3,0,'Malay','','pkg_ms-MY','package','',0,'3.1.5.4','','http://update.joomla.org/language/details3/ms-MY_details.xml',''),(2,3,0,'Romanian','','pkg_ro-RO','package','',0,'3.2.0.1','','http://update.joomla.org/language/details3/ro-RO_details.xml',''),(3,3,0,'Flemish','','pkg_nl-BE','package','',0,'3.2.0.2','','http://update.joomla.org/language/details3/nl-BE_details.xml',''),(4,3,0,'Chinese Traditional','','pkg_zh-TW','package','',0,'3.2.0.1','','http://update.joomla.org/language/details3/zh-TW_details.xml',''),(5,3,0,'French','','pkg_fr-FR','package','',0,'3.2.0.2','','http://update.joomla.org/language/details3/fr-FR_details.xml',''),(6,3,0,'German','','pkg_de-DE','package','',0,'3.2.0.2','','http://update.joomla.org/language/details3/de-DE_details.xml',''),(7,3,0,'Greek','','pkg_el-GR','package','',0,'3.2.0.1','','http://update.joomla.org/language/details3/el-GR_details.xml',''),(8,3,0,'Japanese','','pkg_ja-JP','package','',0,'3.2.0.2','','http://update.joomla.org/language/details3/ja-JP_details.xml',''),(9,3,0,'Hebrew','','pkg_he-IL','package','',0,'3.1.1.1','','http://update.joomla.org/language/details3/he-IL_details.xml',''),(10,3,0,'Hungarian','','pkg_hu-HU','package','',0,'3.2.0.1','','http://update.joomla.org/language/details3/hu-HU_details.xml',''),(11,3,0,'Afrikaans','','pkg_af-ZA','package','',0,'3.2.0.1','','http://update.joomla.org/language/details3/af-ZA_details.xml',''),(12,3,0,'Arabic Unitag','','pkg_ar-AA','package','',0,'3.2.0.1','','http://update.joomla.org/language/details3/ar-AA_details.xml',''),(13,3,0,'Bulgarian','','pkg_bg-BG','package','',0,'3.0.3.1','','http://update.joomla.org/language/details3/bg-BG_details.xml',''),(14,3,0,'Catalan','','pkg_ca-ES','package','',0,'3.2.0.1','','http://update.joomla.org/language/details3/ca-ES_details.xml',''),(15,3,0,'Chinese Simplified','','pkg_zh-CN','package','',0,'3.2.0.1','','http://update.joomla.org/language/details3/zh-CN_details.xml',''),(16,3,0,'Croatian','','pkg_hr-HR','package','',0,'3.1.5.1','','http://update.joomla.org/language/details3/hr-HR_details.xml',''),(17,3,0,'Czech','','pkg_cs-CZ','package','',0,'3.2.0.1','','http://update.joomla.org/language/details3/cs-CZ_details.xml',''),(18,3,0,'Danish','','pkg_da-DK','package','',0,'3.2.0.1','','http://update.joomla.org/language/details3/da-DK_details.xml',''),(19,3,0,'Dutch','','pkg_nl-NL','package','',0,'3.2.0.1','','http://update.joomla.org/language/details3/nl-NL_details.xml',''),(20,3,0,'English AU','','pkg_en-AU','package','',0,'3.1.0.1','','http://update.joomla.org/language/details3/en-AU_details.xml',''),(21,3,0,'English US','','pkg_en-US','package','',0,'3.1.0.1','','http://update.joomla.org/language/details3/en-US_details.xml',''),(22,3,0,'Estonian','','pkg_et-EE','package','',0,'3.1.2.1','','http://update.joomla.org/language/details3/et-EE_details.xml',''),(23,3,0,'Italian','','pkg_it-IT','package','',0,'3.2.0.1','','http://update.joomla.org/language/details3/it-IT_details.xml',''),(24,3,0,'Korean','','pkg_ko-KR','package','',0,'3.2.0.3','','http://update.joomla.org/language/details3/ko-KR_details.xml',''),(25,3,0,'Latvian','','pkg_lv-LV','package','',0,'3.2.0.1','','http://update.joomla.org/language/details3/lv-LV_details.xml',''),(26,3,0,'Macedonian','','pkg_mk-MK','package','',0,'3.2.0.1','','http://update.joomla.org/language/details3/mk-MK_details.xml',''),(27,3,0,'Norwegian Bokmal','','pkg_nb-NO','package','',0,'3.2.0.1','','http://update.joomla.org/language/details3/nb-NO_details.xml',''),(28,3,0,'Persian','','pkg_fa-IR','package','',0,'3.2.0.1','','http://update.joomla.org/language/details3/fa-IR_details.xml',''),(29,3,0,'Polish','','pkg_pl-PL','package','',0,'3.2.0.3','','http://update.joomla.org/language/details3/pl-PL_details.xml',''),(30,3,0,'Russian','','pkg_ru-RU','package','',0,'3.1.5.1','','http://update.joomla.org/language/details3/ru-RU_details.xml',''),(31,3,0,'Slovak','','pkg_sk-SK','package','',0,'3.2.0.2','','http://update.joomla.org/language/details3/sk-SK_details.xml',''),(32,3,0,'Swedish','','pkg_sv-SE','package','',0,'3.2.1.1','','http://update.joomla.org/language/details3/sv-SE_details.xml',''),(33,3,0,'Syriac','','pkg_sy-IQ','package','',0,'3.2.0.2','','http://update.joomla.org/language/details3/sy-IQ_details.xml',''),(34,3,0,'Tamil','','pkg_ta-IN','package','',0,'3.2.0.1','','http://update.joomla.org/language/details3/ta-IN_details.xml',''),(35,3,0,'Thai','','pkg_th-TH','package','',0,'3.2.0.1','','http://update.joomla.org/language/details3/th-TH_details.xml',''),(36,3,0,'Turkish','','pkg_tr-TR','package','',0,'3.2.0.1','','http://update.joomla.org/language/details3/tr-TR_details.xml',''),(37,3,0,'Ukrainian','','pkg_uk-UA','package','',0,'3.2.0.6','','http://update.joomla.org/language/details3/uk-UA_details.xml',''),(38,3,0,'Uyghur','','pkg_ug-CN','package','',0,'3.2.0.1','','http://update.joomla.org/language/details3/ug-CN_details.xml',''),(39,3,0,'Albanian','','pkg_sq-AL','package','',0,'3.1.1.1','','http://update.joomla.org/language/details3/sq-AL_details.xml',''),(40,3,0,'Serbian Latin','','pkg_sr-YU','package','',0,'3.2.0.1','','http://update.joomla.org/language/details3/sr-YU_details.xml',''),(41,3,0,'Spanish','','pkg_es-ES','package','',0,'3.2.0.1','','http://update.joomla.org/language/details3/es-ES_details.xml',''),(42,3,0,'Bosnian','','pkg_bs-BA','package','',0,'3.1.1.1','','http://update.joomla.org/language/details3/bs-BA_details.xml',''),(43,3,0,'Serbian Cyrillic','','pkg_sr-RS','package','',0,'3.2.0.1','','http://update.joomla.org/language/details3/sr-RS_details.xml',''),(44,3,0,'Bahasa Indonesia','','pkg_id-ID','package','',0,'3.1.4.1','','http://update.joomla.org/language/details3/id-ID_details.xml',''),(45,3,0,'Finnish','','pkg_fi-FI','package','',0,'3.2.0.1','','http://update.joomla.org/language/details3/fi-FI_details.xml',''),(46,3,0,'Swahili','','pkg_sw-KE','package','',0,'3.2.0.1','','http://update.joomla.org/language/details3/sw-KE_details.xml',''),(47,3,0,'Montenegrin','','pkg_srp-ME','package','',0,'3.2.0.2','','http://update.joomla.org/language/details3/srp-ME_details.xml',''),(48,8,0,'Kunena Language Pack','Language Pack for Kunena Forum','pkg_kunena_languages','package','',0,'3.0.3','','http://update.kunena.org/3.0/pkg_kunena_languages.xml',''),(49,8,0,'Kunena Latest Module','','mod_kunenalatest','module','',0,'3.0.1','','http://update.kunena.org/3.0/mod_kunenalatest.xml',''),(50,8,0,'Kunena Login Module','','mod_kunenalogin','module','',0,'3.0.1','','http://update.kunena.org/3.0/mod_kunenalogin.xml',''),(51,8,0,'Kunena Search Module','','mod_kunenasearch','module','',0,'3.0.1','','http://update.kunena.org/3.0/mod_kunenasearch.xml',''),(52,8,0,'Kunena Statistics Module','','mod_kunenastats','module','',0,'3.0.1','','http://update.kunena.org/3.0/mod_kunenastats.xml',''),(53,8,0,'Content - Kunena Discuss','','kunenadiscuss','plugin','content',0,'3.0.1','','http://update.kunena.org/3.0/plg_content_kunenadiscuss.xml',''),(54,8,0,'Search - Kunena','','kunena','plugin','search',0,'3.0.1','','http://update.kunena.org/3.0/plg_search_kunena.xml','');
/*!40000 ALTER TABLE `jom_updates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_user_keys`
--

DROP TABLE IF EXISTS `jom_user_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_user_keys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `series` varchar(255) NOT NULL,
  `invalid` tinyint(4) NOT NULL,
  `time` varchar(200) NOT NULL,
  `uastring` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `series` (`series`),
  UNIQUE KEY `series_2` (`series`),
  UNIQUE KEY `series_3` (`series`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_user_keys`
--

LOCK TABLES `jom_user_keys` WRITE;
/*!40000 ALTER TABLE `jom_user_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_user_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_user_notes`
--

DROP TABLE IF EXISTS `jom_user_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_user_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(100) NOT NULL DEFAULT '',
  `body` text NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_user_id` int(10) unsigned NOT NULL,
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `review_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_category_id` (`catid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_user_notes`
--

LOCK TABLES `jom_user_notes` WRITE;
/*!40000 ALTER TABLE `jom_user_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_user_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_user_profiles`
--

DROP TABLE IF EXISTS `jom_user_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_user_profiles` (
  `user_id` int(11) NOT NULL,
  `profile_key` varchar(100) NOT NULL,
  `profile_value` varchar(255) NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `idx_user_id_profile_key` (`user_id`,`profile_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Simple user profile storage table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_user_profiles`
--

LOCK TABLES `jom_user_profiles` WRITE;
/*!40000 ALTER TABLE `jom_user_profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `jom_user_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_user_usergroup_map`
--

DROP TABLE IF EXISTS `jom_user_usergroup_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_user_usergroup_map` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Foreign Key to #__users.id',
  `group_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Foreign Key to #__usergroups.id',
  PRIMARY KEY (`user_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_user_usergroup_map`
--

LOCK TABLES `jom_user_usergroup_map` WRITE;
/*!40000 ALTER TABLE `jom_user_usergroup_map` DISABLE KEYS */;
INSERT INTO `jom_user_usergroup_map` (`user_id`, `group_id`) VALUES (335,8),(705,2),(706,2),(707,2),(708,2),(709,2),(710,2),(711,2),(712,2),(713,2),(714,2),(715,2),(716,2),(717,2),(718,2),(719,2),(720,2);
/*!40000 ALTER TABLE `jom_user_usergroup_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_usergroups`
--

DROP TABLE IF EXISTS `jom_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_usergroups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Adjacency List Reference Id',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `title` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_usergroup_parent_title_lookup` (`parent_id`,`title`),
  KEY `idx_usergroup_title_lookup` (`title`),
  KEY `idx_usergroup_adjacency_lookup` (`parent_id`),
  KEY `idx_usergroup_nested_set_lookup` (`lft`,`rgt`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_usergroups`
--

LOCK TABLES `jom_usergroups` WRITE;
/*!40000 ALTER TABLE `jom_usergroups` DISABLE KEYS */;
INSERT INTO `jom_usergroups` (`id`, `parent_id`, `lft`, `rgt`, `title`) VALUES (1,0,1,16,'Public'),(2,1,6,13,'Registered'),(3,2,7,12,'Author'),(4,3,8,11,'Editor'),(5,4,9,10,'Publisher'),(6,1,2,5,'Manager'),(7,6,3,4,'Administrator'),(8,1,14,15,'Super Users');
/*!40000 ALTER TABLE `jom_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_users`
--

DROP TABLE IF EXISTS `jom_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(150) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  `block` tinyint(4) NOT NULL DEFAULT '0',
  `sendEmail` tinyint(4) DEFAULT '0',
  `registerDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastvisitDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activation` varchar(100) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  `lastResetTime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Date of last password reset',
  `resetCount` int(11) NOT NULL DEFAULT '0' COMMENT 'Count of password resets since lastResetTime',
  `otpKey` varchar(1000) NOT NULL DEFAULT '' COMMENT 'Two factor authentication encrypted keys',
  `otep` varchar(1000) NOT NULL DEFAULT '' COMMENT 'One time emergency passwords',
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`),
  KEY `idx_block` (`block`),
  KEY `username` (`username`),
  KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=721 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_users`
--

LOCK TABLES `jom_users` WRITE;
/*!40000 ALTER TABLE `jom_users` DISABLE KEYS */;
INSERT INTO `jom_users` (`id`, `name`, `username`, `email`, `password`, `block`, `sendEmail`, `registerDate`, `lastvisitDate`, `activation`, `params`, `lastResetTime`, `resetCount`, `otpKey`, `otep`) VALUES (335,'Super User','admin','ressfos@gmail.com','$2y$10$zbqyGwXEBhVq3x32mUjMoeu8kBIPjuYeJmuRTqwu2XlVwfb27tFgi:t1D9XtVmdN0CTdGnXGSTrvqjZezxGuBE',0,1,'2013-10-28 18:08:42','2013-12-11 11:47:58','0','{\"admin_style\":\"\",\"admin_language\":\"\",\"language\":\"\",\"editor\":\"\",\"helpsite\":\"\",\"timezone\":\"\"}','0000-00-00 00:00:00',0,'',''),(705,'Ressie Fos','ressiefos','ressiefos@yahoo.com','$2y$10$nCSIoxufghtsAj5r7eILte47dyBrciuhoWUMqi502OymRQE4lznJi',0,1,'2013-10-28 19:49:45','2013-12-09 10:30:17','','{\"admin_style\":\"\",\"admin_language\":\"\",\"language\":\"en-GB\",\"editor\":\"jce\",\"helpsite\":\"\",\"timezone\":\"Asia\\/Qatar\"}','0000-00-00 00:00:00',0,'',''),(706,'Job Seeker','jobseeker','info@pixxelsis.com','$2y$10$OyEIE3K635lEROuqntwrVuieVwY/4v.S9TaCPeeP.gUDgrjVJlhTW',0,0,'2013-10-28 20:23:57','2013-12-09 16:08:58','','{}','0000-00-00 00:00:00',0,'',''),(707,'Employer','employer','admin@pixxelsis.com','$2y$10$t2ajmTvt9B3y9A2mrpfXOOzsmhgX5Ye/zuxdiX3/uCloQBmbslrQ.',0,0,'2013-10-28 20:30:46','2013-12-09 12:13:18','','{\"editor\":\"jce\",\"timezone\":\"Asia\\/Qatar\",\"language\":\"en-GB\"}','0000-00-00 00:00:00',0,'',''),(708,'EDUARDO B. DAMASO','ED','pinoytext08@gmail.com','18bcdaa6196306a96e71955751d15ea6:6bbZJW6JNSieJbVT3Gcp8pDB8ACrpsXC',0,0,'2013-10-30 06:32:48','2013-10-30 08:58:36','','{}','0000-00-00 00:00:00',0,'',''),(709,'LEIZEL R. SADIASA','leizel','r_text@yahoo.com','$2y$10$yrP8foslvNDEdjZIvIEyv.qOzld2qKylzuqpfAdLsRT4eGOty3tLi',0,0,'2013-10-30 07:39:47','2013-12-05 02:05:51','','{}','0000-00-00 00:00:00',0,'',''),(710,'Cost U Less','Ava','poec2013@gmail.com','c28ac42cf1ceca61ecbeadfecb928917:xlqMpzAe6GSiWvg9gH0OJLEpVbovXWvX',1,0,'2013-11-03 12:13:08','0000-00-00 00:00:00','8328edb8c71d0b427f2c4d5a7271dc03','{}','0000-00-00 00:00:00',0,'',''),(711,'Winny Hilario','winny','winnyimex@yahoo.com.ph','$2y$10$s/g7Hqu4V87tEIUvPU3R0O28hv29jqOsR6BzVETUyOGfA.hOo3mYG',0,0,'2013-11-04 06:20:44','2013-12-05 01:15:42','','{\"editor\":\"\",\"timezone\":\"\",\"language\":\"\"}','0000-00-00 00:00:00',0,'',''),(712,'Nanette Demaosa','nettezky08@yahoo.com','nettezky08@yahoo.com','$2y$10$ctatsr2hF4F0fXDgCBcC4eeWKe.gGlCpixSO6cuIFXuc06XzG9tq6',0,0,'2013-11-04 07:25:40','2013-12-04 08:37:45','','{}','0000-00-00 00:00:00',0,'',''),(713,'User1','User1','mail@yahoo.com','$2y$10$dg4dTWEm8derEA567gh9tewxs9cGHUNXU0.qNECLGaE340yiksSHK',0,0,'2013-12-04 05:08:13','2013-12-04 05:16:38','','{}','0000-00-00 00:00:00',0,'',''),(714,'Aljo Marric A. Joson','aljo20','aljian24@gmail.com','$2y$10$Fq46JkUWb0h6IlNDCam4o.RnFBn1wQMJZ6neFJMeCHgACkLXY.xCu',0,0,'2013-12-04 05:13:39','2013-12-04 05:42:13','','{\"activate\":0}','0000-00-00 00:00:00',0,'',''),(715,'Eduardo B. Damaso','EdDamaso','edamaso3@gmail.com','$2y$10$QoatNxKcgjDEVoYoYRRYyep7I.1OU4/5sk6y4zmRfIrWsRPXNImcu',0,0,'2013-12-04 05:45:44','2013-12-04 05:56:22','','{\"activate\":0}','0000-00-00 00:00:00',0,'',''),(716,'test2','test2','test@mail.com','$2y$10$vXioFuy42Zu6/D8CzLofl.4DWfYiSU8gOT9aAPK1Z1hCcBy3jEh.S',0,0,'2013-12-04 06:21:51','0000-00-00 00:00:00','','{}','0000-00-00 00:00:00',0,'',''),(717,'Alex Lin','Alex','hsklin@yahoo.com.tw','$2y$10$ewFFjRayHsfRl/5oRu5tTOsph6xagFMyQz.yTP8UOBMK9e9r6OvI.',0,0,'2013-12-04 08:32:32','0000-00-00 00:00:00','','{\"activate\":0}','0000-00-00 00:00:00',0,'',''),(718,'santarli','santarli','winnyhilario@gmail.com','$2y$10$A.3IW79jmgc5g5vxScYlOOYfkzhK6vthnMDDusK5ibGos5.LtlOJi',1,0,'2013-12-05 01:01:10','0000-00-00 00:00:00','04ac7f1d1871054e237f1ee9e5c20837','{}','0000-00-00 00:00:00',0,'',''),(719,'Edgardo Santos Tuale Jr.','itzmeed','edgardotuale@gmail.com','$2y$10$mnXSHLD1sYDipiMFBfFJuOVQZgzUexXzzoCRizvupxPDrMf07cdSu',0,0,'2013-12-09 04:26:38','0000-00-00 00:00:00','','{\"activate\":0}','0000-00-00 00:00:00',0,'',''),(720,'Pixxelsis Recruitment','pixxelsis','hr@pixxelsis.com','$2y$10$fJ6Hje6EzbjyWOCQ5GL1suuLzLeaufKps/jnuVymWW8kY8F8Liai.',0,1,'2013-12-09 06:10:04','2013-12-09 14:18:40','','{\"admin_style\":\"\",\"admin_language\":\"\",\"language\":\"\",\"editor\":\"\",\"helpsite\":\"\",\"timezone\":\"\"}','0000-00-00 00:00:00',0,'','');
/*!40000 ALTER TABLE `jom_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_viewlevels`
--

DROP TABLE IF EXISTS `jom_viewlevels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_viewlevels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `title` varchar(100) NOT NULL DEFAULT '',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rules` varchar(5120) NOT NULL COMMENT 'JSON encoded access control.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_assetgroup_title_lookup` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_viewlevels`
--

LOCK TABLES `jom_viewlevels` WRITE;
/*!40000 ALTER TABLE `jom_viewlevels` DISABLE KEYS */;
INSERT INTO `jom_viewlevels` (`id`, `title`, `ordering`, `rules`) VALUES (1,'Public',0,'[1]'),(2,'Registered',1,'[6,2,8]'),(3,'Special',2,'[6,3,8]');
/*!40000 ALTER TABLE `jom_viewlevels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_weblinks`
--

DROP TABLE IF EXISTS `jom_weblinks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_weblinks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(11) NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `url` varchar(250) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `hits` int(11) NOT NULL DEFAULT '0',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `access` int(11) NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  `language` char(7) NOT NULL DEFAULT '',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `metadata` text NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if link is featured.',
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `images` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`state`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_featured_catid` (`featured`,`catid`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_weblinks`
--

LOCK TABLES `jom_weblinks` WRITE;
/*!40000 ALTER TABLE `jom_weblinks` DISABLE KEYS */;
INSERT INTO `jom_weblinks` (`id`, `catid`, `title`, `alias`, `url`, `description`, `hits`, `state`, `checked_out`, `checked_out_time`, `ordering`, `access`, `params`, `language`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `metakey`, `metadesc`, `metadata`, `featured`, `xreference`, `publish_up`, `publish_down`, `version`, `images`) VALUES (1,32,'Joomla!','joomla','http://www.joomla.org','Home of Joomla!',3,1,0,'0000-00-00 00:00:00',1,1,'{\"target\":0}','','0000-00-00 00:00:00',335,'','0000-00-00 00:00:00',0,'','','',0,'','0000-00-00 00:00:00','0000-00-00 00:00:00',1,''),(2,32,'php.net','php','http://www.php.net','The language that Joomla! is developed in',8,1,0,'0000-00-00 00:00:00',3,1,'{}','','0000-00-00 00:00:00',335,'','0000-00-00 00:00:00',0,'','','',0,'','0000-00-00 00:00:00','0000-00-00 00:00:00',1,''),(3,32,'MySQL','mysql','http://www.mysql.com','The database that Joomla! uses',1,1,0,'0000-00-00 00:00:00',5,1,'{}','','0000-00-00 00:00:00',335,'','0000-00-00 00:00:00',0,'','','',0,'','0000-00-00 00:00:00','0000-00-00 00:00:00',1,''),(4,32,'OpenSourceMatters','opensourcematters','http://www.opensourcematters.org','Home of OSM',11,1,0,'0000-00-00 00:00:00',2,1,'{\"target\":0}','','0000-00-00 00:00:00',335,'','0000-00-00 00:00:00',0,'','','',0,'','0000-00-00 00:00:00','0000-00-00 00:00:00',1,''),(5,32,'Joomla! - Forums','joomla-forums','http://forum.joomla.org','Joomla! Forums',4,1,0,'0000-00-00 00:00:00',4,1,'{\"target\":0}','','0000-00-00 00:00:00',335,'','0000-00-00 00:00:00',0,'','','',0,'','0000-00-00 00:00:00','0000-00-00 00:00:00',1,''),(6,32,'Ohloh Tracking of Joomla!','ohloh-tracking-of-joomla','http://www.ohloh.net/projects/20','Objective reports from Ohloh about Joomla\'s development activity. Joomla! has some star developers with serious kudos.',1,1,0,'0000-00-00 00:00:00',6,1,'{\"target\":0}','','0000-00-00 00:00:00',335,'','0000-00-00 00:00:00',0,'','','',0,'','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'');
/*!40000 ALTER TABLE `jom_weblinks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jom_wf_profiles`
--

DROP TABLE IF EXISTS `jom_wf_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jom_wf_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `users` text NOT NULL,
  `types` text NOT NULL,
  `components` text NOT NULL,
  `area` tinyint(3) NOT NULL,
  `device` varchar(255) NOT NULL,
  `rows` text NOT NULL,
  `plugins` text NOT NULL,
  `published` tinyint(3) NOT NULL,
  `ordering` int(11) NOT NULL,
  `checked_out` tinyint(3) NOT NULL,
  `checked_out_time` datetime NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jom_wf_profiles`
--

LOCK TABLES `jom_wf_profiles` WRITE;
/*!40000 ALTER TABLE `jom_wf_profiles` DISABLE KEYS */;
INSERT INTO `jom_wf_profiles` (`id`, `name`, `description`, `users`, `types`, `components`, `area`, `device`, `rows`, `plugins`, `published`, `ordering`, `checked_out`, `checked_out_time`, `params`) VALUES (1,'Default','Default Profile for all users','','3,4,5,6,8,7','',0,'desktop,tablet,phone','help,newdocument,undo,redo,spacer,bold,italic,underline,strikethrough,justifyfull,justifycenter,justifyleft,justifyright,spacer,blockquote,formatselect,styleselect,removeformat,cleanup;fontselect,fontsizeselect,forecolor,backcolor,spacer,clipboard,indent,outdent,lists,sub,sup,textcase,charmap,hr;directionality,fullscreen,preview,source,print,searchreplace,spacer,table;visualaid,visualchars,visualblocks,nonbreaking,style,xhtmlxtras,anchor,unlink,link,imgmanager,spellchecker,article','charmap,contextmenu,browser,inlinepopups,media,help,clipboard,searchreplace,directionality,fullscreen,preview,source,table,textcase,print,style,nonbreaking,visualchars,visualblocks,xhtmlxtras,imgmanager,anchor,link,spellchecker,article,lists',1,1,0,'0000-00-00 00:00:00',''),(2,'Front End','Sample Front-end Profile','','3,4,5','',1,'desktop,tablet,phone','help,newdocument,undo,redo,spacer,bold,italic,underline,strikethrough,justifyfull,justifycenter,justifyleft,justifyright,spacer,formatselect,styleselect;clipboard,searchreplace,indent,outdent,lists,cleanup,charmap,removeformat,hr,sub,sup,textcase,nonbreaking,visualchars,visualblocks;fullscreen,preview,print,visualaid,style,xhtmlxtras,anchor,unlink,link,imgmanager,spellchecker,article','charmap,contextmenu,inlinepopups,help,clipboard,searchreplace,fullscreen,preview,print,style,textcase,nonbreaking,visualchars,visualblocks,xhtmlxtras,imgmanager,anchor,link,spellchecker,article,lists',0,2,0,'0000-00-00 00:00:00',''),(3,'Blogger','Simple Blogging Profile','','3,4,5,6,8,7','',0,'desktop,tablet,phone','bold,italic,strikethrough,lists,blockquote,spacer,justifyleft,justifycenter,justifyright,spacer,link,unlink,imgmanager,article,spellchecker,fullscreen,kitchensink;formatselect,underline,justifyfull,forecolor,clipboard,removeformat,charmap,indent,outdent,undo,redo,help','link,imgmanager,article,spellchecker,fullscreen,kitchensink,clipboard,contextmenu,inlinepopups,lists',0,3,0,'0000-00-00 00:00:00','{\"editor\":{\"toggle\":\"0\"}}'),(4,'Mobile','Sample Mobile Profile','','3,4,5,6,8,7','',0,'tablet,phone','undo,redo,spacer,bold,italic,underline,formatselect,spacer,justifyleft,justifycenter,justifyfull,justifyright,spacer,fullscreen,kitchensink;styleselect,lists,spellchecker,article,link,unlink','fullscreen,kitchensink,spellchecker,article,link,inlinepopups,lists',0,4,0,'0000-00-00 00:00:00','{\"editor\":{\"toolbar_theme\":\"mobile\",\"resizing\":\"0\",\"resize_horizontal\":\"0\",\"resizing_use_cookie\":\"0\",\"toggle\":\"0\",\"links\":{\"popups\":{\"default\":\"\",\"jcemediabox\":{\"enable\":\"0\"},\"window\":{\"enable\":\"0\"}}}}}');
/*!40000 ALTER TABLE `jom_wf_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'poec_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-12-11  5:48:51
