-- cPanel mysql backup
GRANT USAGE ON *.* TO 'poec'@'localhost' IDENTIFIED BY PASSWORD '372a0a7a601079c5';
GRANT ALL PRIVILEGES ON `poec\_db`.* TO 'poec'@'localhost';
GRANT ALL PRIVILEGES ON `poec\_%`.* TO 'poec'@'localhost';
GRANT USAGE ON *.* TO 'poec_admin'@'localhost' IDENTIFIED BY PASSWORD '1adba55a26bdc269';
GRANT ALL PRIVILEGES ON `poec\_db`.* TO 'poec_admin'@'localhost';
