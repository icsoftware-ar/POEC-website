DROP TABLE IF EXISTS `#__js_auto_messages`;
CREATE TABLE `#__js_auto_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sellerid` int(11) DEFAULT NULL,
  `buyerid` int(11) DEFAULT NULL,
  `sendby` int(11) DEFAULT NULL,
  `vehicleid` int(11) DEFAULT NULL,
  `replytoid` int(11) DEFAULT NULL,
  `subject` varchar(500) DEFAULT NULL,
  `message` text,
  `isread` tinyint(1) DEFAULT NULL,
  `isconflict` tinyint(1) DEFAULT NULL,
  `conflictvalue` varchar(500) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 CHARACTER SET `utf8`;

ALTER TABLE `#__js_auto_deller`
	ADD COLUMN `latitude` varchar(255) DEFAULT NULL,
	ADD COLUMN `longitude` varchar(255) DEFAULT NULL;

ALTER TABLE `#__js_auto_vehicles`
	ADD COLUMN  `issold` tinyint(1) DEFAULT '0',
	ADD COLUMN  `solddated` datetime DEFAULT NULL,
	ADD COLUMN  `latitude` double DEFAULT NULL,
	ADD COLUMN  `longitude` double DEFAULT NULL,
	ADD COLUMN  `registrationnumber` varchar(255) DEFAULT NULL,
	ADD COLUMN  `chasisnumber` varchar(255) DEFAULT NULL,
	ADD COLUMN  `enginenumber` varchar(255) DEFAULT NULL;

ALTER TABLE `#__js_auto_new_listing_alerts`
	ADD COLUMN  `alerttype` int(3) DEFAULT NULL,
	ADD COLUMN  `longitude` double DEFAULT NULL,
	ADD COLUMN  `latitude` double DEFAULT NULL,
	ADD COLUMN  `coordinatesradius` int(11) NOT NULL,
	ADD COLUMN  `lastmailsend` datetime DEFAULT NULL;

INSERT INTO `#__js_auto_fieldordering` VALUES (174,'issold','Is Sold',33,NULL,1,1,0,0,'0'),(175,'registrationnumber','Registration Number',11,NULL,1,1,0,0,'0'),(176,'chasisnumber','Chasis Number',13,NULL,1,1,0,0,'0'),(177,'enginenumber','Engine Number',12,NULL,1,1,0,0,'0');

INSERT INTO `#__js_auto_emailtemplates` VALUES    (11,NULL,'vehicle-visitor',NULL,NULL,'<p>Dear {VISITOR} ,</p>\r\n<p>You add new Vehicle  {VEHICLE_TITLE}.You are visitor your Vehicle id is {VEHICLE_ID} </p>\r\n<p>Title: {VEHICLE_TITLE}</p>\r\n<p>Make: {MAKE}</p>\r\n<p>MODEL: {MODEL}</p>\r\n<p>MODEL YEAR: {MODEL_YEAR}</p>\r\n<p>Location: {LOCATION}</p>\r\n<p>Login and view detail at Please do not respond to this message. It is automatically generated and is for information purposes only.</p>',NULL,NULL),
 (12,42,'message-btosemail',NULL,'JS Autoz: New Message Alert','<p>Dear {SELLER},</p>\r\n<p>{BUYER}: send you new message.</p>\r\n<p><strong><span style=\"text-decoration: underline;\">Summary</span></strong></p>\r\n<p>Vehicle Title: {VEHICLE_TITLE} {LINK}</p>\r\n<p>Subject: {SUBJECT}</p>\r\n<p>Message: {MESSAGE}</p>\r\n<p><span style=\"color: red;\"><strong>*DO NOT REPLY TO THIS E-MAIL*</strong></span><br />This is an automated e-mail message sent from our support system. Do not reply to this e-mail as we wonot receive your reply!</p>',1,'2012-04-05 12:25:41'),
 (13,42,'message-stobemail',NULL,'JS Autoz: New Message Alert','<p>Dear {BUYER},</p>\r\n<p>{SELLER}: send you new message.</p>\r\n<p><strong><span style=\"text-decoration: underline;\">Summary</span></strong></p>\r\n<p>Vehicle Title: {VEHICLE_TITLE} {LINK}</p>\r\n<p>Subject: {SUBJECT}</p>\r\n<p>Message: {MESSAGE}</p>\r\n<p><span style=\"color: red;\"><strong>*DO NOT REPLY TO THIS E-MAIL*</strong></span><br />This is an automated e-mail message sent from our support system. Do not reply to this e-mail as we wonot receive your reply!</p>',1,'2012-04-05 12:25:41'),
 (14,42,'tell-friend',NULL,'JS Autoz : Your friend find a vehcile.','<p>Dear ,</p>\r\n<p>Your Friend {SENDER_NAME} will send you this mail through our site {SITE_NAME} to inform you for a vehicle.</p>\r\n<p>Title: {VEHICLE_TITLE}</p>\r\n<p>Make: {MAKE}</p>\r\n<p>Model : {MODEL}</p>\r\n<p>Model Year: {MODEL_YEAR}</p>\r\n<p>Price: {PRICE}</p>\r\n<p>Location: {LOCATION}</p>\r\n<p>{CLICK_HERE_TO_VISIT} the vehicle detail.</p>\r\n<p>{FRIEND_MESSAGE}</p>\r\n<p>{SENDER_MESSAGE}</p>\r\n<p>Thank you.</p>\r\n<p><span style=\"color: red;\"><strong>*DO NOT REPLY TO THIS E-MAIL*</strong></span><br />This is an automated e-mail message sent from our support system. Do not reply to this e-mail as we wonot receive your reply!</p>',1,'2012-07-21 06:35:14');

INSERT INTO `#__js_auto_config` VALUES ('show_sold_vehicles','1','default'),('rss_vehicle_title','JS Autoz Vehicle ','rss'),('rss_vehicle_description','JS Autoz For vehicle feed','rss'),('rss_vehicle_copyright','©Copyright Buruj Solutions ','rss'),('rss_vehicle_webmaster','Powered by Joom Sky','rss'),('rss_vehicle_editor','zain_22pugc@yahoo.com','rss'),('rss_vehicle_ttl','vehicle','rss'),('custom_css','float:left;width:100%;clear:both;overflow: hidden;','addon'),('add_on_repitation','5','addon'),('visitor_can_edit_vehicle','1','visitor'),('bcomparevehicle','1','links'),('bmessages','1','links'),('messages','1','links'),('vformnewvehicle','1','links'),('vformusedvehicle','1','links'),('vmyvehicles','1','links'),('vbformnewvehicles','1','links'),('vbformusedvehicles','1','links'),('vbsearchvehicles','1','links'),('vbnvehiclebymakes','1','links'),('vbuvehiclebymakes','1','links'),('vbvehiclebycity','1','links'),('vbvehiclebyprice','1','links'),('vbvehiclebymodelyears','1','links'),('vbgoldvehicles','1','links'),('vbfeaturedvehicles','1','links'),('vbdealers','1','links'),('vbvehiclealerts','1','links'),('vbcomparevehicle','1','links'),('searchtitle','1','search'),('searchvehicletype','1','search'),('searchmake','1','search'),('searchmodel','1','search'),('searchregcountry','1','search'),('searchregstate','1','search'),('searchregcounty','1','search'),('searchregcity','1','search'),('searchloccountry','1','search'),('searchlocstate','1','search'),('searchloccounty','1','search'),('searchloccity','1','search'),('searchloczip','1','search'),('searchradius','1','search'),('searchmodelyear','1','search'),('searchfueltype','1','search'),('searchcylinder','1','search'),('searchprice','1','search'),('searchexteriorcolor','1','search'),('searchregistrationnumber','1','search'),('searchenginecapacity','1','search'),('searchcondition','1','search'),('searchmileages','1','search'),('vehiclefilter','1','default'),('filtercondition','1','filter'),('filtermodel','1','filter'),('filtermake','1','filter'),('filtercountry','1','filter'),('filterstate','1','filter'),('filtercounty','1','filter'),('filtercity','1','filter'),('filtermodelyear','1','filter'),('bvehiclebytypes','1','links'),('vbvehiclebytypes','1','links'),('default_longitude','73.07150769999998','default'),('default_latitude','33.7180684','default'),('filtermap','1','filter'),('searchmap','1','search'),('add_on_client','ca-pub-8827762976015158','addon'),('add_on_slot','9560237528','addon'),('add_on_format','728 x 90','addon'),('listvehiclesshowadsense','1','addon'),('searchresultshowadsense','1','addon'),('goldvehiclesshowadsense','1','addon'),('featuredvehicleshowadsense','1','addon'),('showgoogleadsense','1','addon'),('showrssfeeding','1','rss'),('captcha','1','default'),('vpackages','1','links'),('vpurchasehistory','1','links'),('vmystats','1','links'),('vmessages','1','links'),('cron_vehicle_alert_key','',''),('cron_job_alert_admin','','email'),('default_radius','km','default');

UPDATE `#__js_auto_config` SET configvalue = '1.0.1' WHERE configname = 'version';
UPDATE `#__js_auto_config` SET configvalue = '101' WHERE configname = 'versioncode';
UPDATE `#__js_auto_config` SET configvalue = 'business' WHERE configname = 'vtype';
