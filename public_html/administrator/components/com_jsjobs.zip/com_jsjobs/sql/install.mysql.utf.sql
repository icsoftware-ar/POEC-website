CREATE TABLE IF NOT EXISTS`#__js_job_ages` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(45) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ;
INSERT INTO `#__js_job_ages` VALUES (1,'10 Years',1), (2,'15 Years',1), (3,'20 Years',1), (4,'25 Years',1), (5,'30 Years',1), (6,'35 Years',1), (7,'40 Years',1), (8,'45 Years',1), (9,'50 Years',1), (10,'55 Years',1);

CREATE TABLE IF NOT EXISTS`#__js_job_careerlevels` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(150) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY  (`id`)
) ;
INSERT INTO `#__js_job_careerlevels` VALUES (1,'Student (Undergraduate)',1), (2,'Student (Graduate)',1), (3,'Entry Level',1), (4,'Experienced (Non-Manager)',1), (5,'Manager',1), (6,'Executive (Department Head, SVP, VP etc)',1), (7,'Senior Executive (President, CEO, etc)',1);

CREATE TABLE IF NOT EXISTS`#__js_job_experiences` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(100) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY  (`id`)
) ;
INSERT INTO `#__js_job_experiences` VALUES (1,'Fresh',1), (2,'Less then 1 Year',1), (3,'1 Year',1), (4,'2 Year',1), (5,'3 Year',1), (6,'4 Year',1), (7,'5 Year',1), (8,'6 Year',1), (9,'7 Year',1), (10,'8 Year',1), (11,'9 Year',1), (12,'10 Year',1), (13,'11 Year',1), (14,'12 Year',1), (15,'13 Year',1), (16,'14 Year',1), (17,'15 Year',1), (18,'16 Year',1), (19,'17 Year',1), (20,'18 Year',1), (21,'19 Year',1), (22,'20 Year',1), (23,'21 Year',1), (24,'22 Year',1), (25,'23 Year',1), (26,'24 Year',1), (27,'25 Year',1);


CREATE TABLE IF NOT EXISTS`#__js_job_departments` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) NOT NULL,
  `companyid` int(11) NOT NULL,
  `name` varchar(70) NOT NULL,
  `description` text,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY  (`id`,`companyid`),
  KEY `departments` (`companyid`),
  KEY `departments_uid` (`uid`)
) ;

CREATE TABLE IF NOT EXISTS`#__js_job_shortlistcandidates` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) default NULL,
  `jobid` int(11) NOT NULL,
  `jobseekerid` int(11) default NULL,
  `cvid` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `shortlistcandidates_uid` (`uid`),
  KEY `shortlistcandidates_jobid` (`jobid`),
  KEY `shortlistcandidates_cvid` (`cvid`)
) ;


CREATE TABLE IF NOT EXISTS`#__js_job_employerpackages` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `discount` int(11) default NULL,
  `discounttype` tinyint(4) default NULL,
  `discountmessage` varchar(500) default NULL,
  `discountstartdate` datetime default NULL,
  `discountenddate` datetime default NULL,
  `companiesallow` int(11) NOT NULL,
  `jobsallow` int(11) NOT NULL,
  `viewresumeindetails` int(11) NOT NULL,
  `resumesearch` int(11) NOT NULL,
  `saveresumesearch` int(11) NOT NULL,
  `featuredcompaines` int(11) NOT NULL,
  `goldcompanies` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `featuredjobs` int(11) NOT NULL,
  `goldjobs` int(11) NOT NULL,
  `jobseekershortlist` tinyint(4) default NULL,
  `shortdetails` varchar(1000) default NULL,
  `description` text,
  `status` tinyint(4) NOT NULL,
  `video` tinyint(4) default NULL,
  `map` tinyint(4) default NULL,
  `packageexpireindays` int(11) NOT NULL,
  `featuredcompaniesexpireindays` int(11) default NULL,
  `goldcompaniesexpireindays` int(11) default NULL,
  `featuredjobsexpireindays` int(11) default NULL,
  `goldjobsexpireindays` int(11) default NULL,
  `enforcestoppublishjob` tinyint(1) default '0',
  `enforcestoppublishjobvalue` int(11) default NULL,
  `enforcestoppublishjobtype` tinyint(4) default NULL,
  `fastspringlink` varchar(1000) default NULL,
  `otherpaymentlink` varchar(1000) default NULL,
  `messageallow` tinyint(1) DEFAULT NULL,
  `folders` tinyint(4) DEFAULT NULL,
  PRIMARY KEY  (`id`)
) ;
INSERT INTO `#__js_job_employerpackages` VALUES(1,'Free Package',0,0,	0,	'',	'2010-06-01 11:53:05','2010-08-24 00:00:00',1,	3,5,0,0,0,0,CURDATE(),0,0,1,'Free Package for single company','Free Package for single company',1,1,1,60,0,0,0,0,1,30,1,'','',0,1);

CREATE TABLE IF NOT EXISTS`#__js_job_employerpaymenthistory` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) default NULL,
  `companyid` int(11) default NULL,
  `packageid` int(11) NOT NULL,
  `packagetitle` varchar(255) NOT NULL,
  `packageprice` int(11) NOT NULL,
  `discountamount` int(11) default NULL,
  `paidamount` int(11) default NULL,
  `discountmessage` varchar(500) default NULL,
  `packagediscountstartdate` datetime default NULL,
  `packagediscountenddate` datetime default NULL,
  `companiesallow` int(11) NOT NULL,
  `jobsallow` int(11) default NULL,
  `viewresumeindetails` int(11) NOT NULL,
  `resumesearch` int(11) NOT NULL,
  `saveresumesearch` int(11) NOT NULL,
  `featuredcompanies` int(11) default NULL,
  `goldcompanies` int(11) default NULL,
  `featuredjobs` int(11) default NULL,
  `goldjobs` int(11) default NULL,
  `candidateshortlist` tinyint(4) default NULL,
  `video` tinyint(4) default NULL,
  `map` tinyint(4) default NULL,
  `packageexpireindays` int(11) NOT NULL,
  `packageshortdetails` varchar(255) default NULL,
  `packagedescription` text,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  `transactionverified` tinyint(4) default NULL,
  `transactionautoverified` tinyint(4) default NULL,
  `verifieddate` datetime default NULL,
  `referenceid` varchar(150) default NULL,
  `payer_firstname` varchar(150) default NULL,
  `payer_lastname` varchar(150) default NULL,
  `payer_email` varchar(255) default NULL,
  `payer_amount` float default NULL,
  `payer_itemname` varchar(255) default NULL,
  `payer_itemname2` varchar(255) default NULL,
  `payer_status` varchar(255) default NULL,
  `payer_tx_token` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `employerpayment_uid` (`uid`),
  KEY `employerpayment_packageid` (`packageid`)
) ;

CREATE TABLE IF NOT EXISTS`#__js_job_jobseekerpackages` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `discount` int(11) default NULL,
  `discounttype` tinyint(4) default NULL,
  `discountmessage` varchar(500) default NULL,
  `discountstartdate` datetime default NULL,
  `discountenddate` datetime default NULL,
  `resumeallow` int(11) NOT NULL,
  `coverlettersallow` int(11) NOT NULL,
  `applyjobs` int(11) NOT NULL,
  `jobsearch` int(11) NOT NULL,
  `savejobsearch` int(11) NOT NULL,
  `featuredresume` int(11) NOT NULL,
  `goldresume` int(11) NOT NULL,
  `video` tinyint(4) default NULL,
  `packageexpireindays` int(11) NOT NULL,
  `shortdetails` varchar(1000) default NULL,
  `description` text,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  `freaturedresumeexpireindays` int(11) default NULL,
  `goldresumeexpireindays` int(11) default NULL,
  `fastspringlink` varchar(1000) default NULL,
  `otherpaymentlink` varchar(1000) default NULL,
  `jobalertsetting` tinyint(1) DEFAULT NULL,
  PRIMARY KEY  (`id`)
) ;
INSERT INTO `#__js_job_jobseekerpackages` VALUES(1,'Free Package',0,0,1,'','2010-06-01 11:53:05','2010-08-24 00:00:00',1,3,-1,1,1,0,0,0,60,'Free Package','Free Package',1,CURDATE(),0,0,'','',1);


CREATE TABLE IF NOT EXISTS`#__js_job_jobseekerpaymenthistory` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) default NULL,
  `packageprice` int(11) NOT NULL,
  `discountamount` int(11) default NULL,
  `paidamount` int(11) default NULL,
  `discountmessage` varchar(500) default NULL,
  `packagestartdate` datetime default NULL,
  `packageenddate` datetime default NULL,
  `resumeallow` int(11) NOT NULL,
  `coverlettersallow` int(11) default NULL,
  `applyjobs` int(11) default NULL,
  `jobsearch` int(11) NOT NULL,
  `savejobsearch` int(11) NOT NULL,
  `featuredresume` int(11) default NULL,
  `status` tinyint(4) NOT NULL default '1',
  `created` datetime NOT NULL,
  `transactionverified` tinyint(4) default NULL,
  `transactionautoverified` tinyint(4) default NULL,
  `verifieddate` datetime default NULL,
  `packageid` int(11) default NULL,
  `packagetitle` varchar(255) NOT NULL,
  `video` tinyint(4) default NULL,
  `goldresume` int(11) default NULL,
  `packageexpireindays` int(11) NOT NULL,
  `packageshortdetails` varchar(1000) default NULL,
  `packagedescription` text,
  `referenceid` varchar(150) default NULL,
  `payer_firstname` varchar(150) default NULL,
  `payer_lastname` varchar(150) default NULL,
  `payer_email` varchar(255) default NULL,
  `payer_amount` float default NULL,
  `payer_itemname` varchar(255) default NULL,
  `payer_itemname1` varchar(255) default NULL,
  `payer_status` varchar(255) default NULL,
  `payer_tx_token` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `employerpayment_uid` (`uid`),
  KEY `employerpayment_packageid` (`packageid`)
) ;

CREATE TABLE IF NOT EXISTS`#__js_job_goldcompanies` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) default NULL,
  `packageid` int(11) default NULL,
  `companyid` int(11) NOT NULL,
  `startdate` datetime NOT NULL,
  `enddate` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `goldcompanies_uid` (`uid`),
  KEY `goldcompanies_packageid` (`packageid`),
  KEY `goldcompanies_companyid` (`companyid`)
) ;

CREATE TABLE IF NOT EXISTS`#__js_job_goldjobs` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) default NULL,
  `packageid` int(11) default NULL,
  `jobid` int(11) NOT NULL,
  `startdate` datetime NOT NULL,
  `enddate` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `goldjobs_uid` (`uid`),
  KEY `goldjobs_packageid` (`packageid`),
  KEY `goldjobs_jobid` (`jobid`)
) ;

CREATE TABLE IF NOT EXISTS`#__js_job_goldresumes` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) default NULL,
  `packageid` int(11) default NULL,
  `resumeid` int(11) default NULL,
  `startdate` datetime NOT NULL,
  `enddate` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `goldresumes_uid` (`uid`),
  KEY `goldresumes_packageid` (`packageid`),
  KEY `goldresumes_resumeid` (`resumeid`)
) ;

CREATE TABLE IF NOT EXISTS`#__js_job_featuredcompanies` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) default NULL,
  `packageid` int(11) default NULL,
  `companyid` int(11) NOT NULL,
  `startdate` datetime NOT NULL,
  `enddate` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `featuredcompanies_uid` (`uid`),
  KEY `featuredcompanies_packageid` (`packageid`),
  KEY `featuredcompanies_companyid` (`companyid`)
) ;

CREATE TABLE IF NOT EXISTS`#__js_job_featuredjobs` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) default NULL,
  `packageid` int(11) default NULL,
  `jobid` int(11) NOT NULL,
  `startdate` datetime NOT NULL,
  `enddate` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `featuredjobs_uid` (`uid`),
  KEY `featuredjobs_packageid` (`packageid`),
  KEY `featuredjobs_jobid` (`jobid`)
) ;

CREATE TABLE IF NOT EXISTS`#__js_job_featuredresumes` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) default NULL,
  `packageid` int(11) default NULL,
  `resumeid` int(11) default NULL,
  `startdate` datetime NOT NULL,
  `enddate` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `featuredjobs_uid` (`uid`),
  KEY `featuredjobs_packageid` (`packageid`),
  KEY `featuredjobs_resumeid` (`resumeid`)
) ;


CREATE TABLE IF NOT EXISTS`#__js_job_categories` (
  `id` int(11) NOT NULL auto_increment,
  `cat_value` varchar(255) default NULL,
  `cat_title` varchar(255) default NULL,
  `isactive` smallint(1) default '1',
  PRIMARY KEY  (`id`)
) ;

INSERT INTO `#__js_job_categories` (cat_title) VALUES ('Accounting/Finance'), ('Administrative'), ('Advertising'), ('Airlines/Avionics/Aerospace'), ('Architectural'), ('Automotive'), ('Banking/Finance'), ('Biotechnology'), ('Civil/Construction'), ('Engineering'), ('Cleared Jobs'), ('Communications'), ('Computer/IT'), ('Construction'), ('Consultant/Contractual'), ('Customer Service'), ('Defense'), ('Design'), ('Education'), ('Electrical Engineering'), ('Electronics Engineering'), ('Energy'), ('Engineering'), ('Environmental/Safety'), ('Fundraising'), ('Health/Medicine'), ('Homeland Security'), ('Human Resources'), ('Insurance'), ('Intelligence Jobs'), ('Internships/Trainees'), ('Legal'), ('Logistics/Transportation'), ('Maintenance'), ('Management'), ('Manufacturing/Warehouse'), ('Marketing'), ('Materials Management'), ('Mechanical Engineering'), ('Mortgage/Real Estate'), ('National Security'), ('Part-time/Freelance'), ('Printing'), ('Product Design'), ('Public Relations'), ('Public Safety'), ('Research'), ('Retail'), ('Sales'), ('Scientific'), ('Shipping/Distribution'), ('Technicians'), ('Trades'), ('Transportation'), ('Transportation Engineering'), ('Web Site Development');


CREATE TABLE IF NOT EXISTS`#__js_job_salaryrange` (
  `id` int(11) NOT NULL auto_increment,
  `rangevalue` varchar(255) default NULL,
  `rangestart` varchar(255) default NULL,
  `rangeend` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
);
INSERT INTO `#__js_job_salaryrange` (rangestart, rangeend) VALUES ('1000', '1500'), ('1500', '2000'), ('2000', '2500'), ('2500', '3000'), ('3000', '3500'), ('3500', '4000'), ('4000', '4500'), ('4500', '5000'), ('5000', '5500'), ('5500', '6000'), ('6000', '7000'), ('7000', '8000'), ('8000', '9000'), ('9000', '10000'), ('10000', '10000+');


CREATE TABLE IF NOT EXISTS`#__js_job_salaryrangetypes` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(45) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY  (`id`)
) ;
INSERT INTO `#__js_job_salaryrangetypes` (title, status) VALUES ('Per Year', 1), ('Per Month', 1), ('Per Week', 1), ('Per Date', 1);

CREATE TABLE IF NOT EXISTS
`#__js_job_companies` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) default NULL,
  `category` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `url` varchar(255) default NULL,
  `logofilename` varchar(100) default NULL,
  `logoisfile` tinyint(1) default '-1',
  `logo` blob,
  `smalllogofilename` varchar(100) default NULL,
  `smalllogoisfile` tinyint(1) default '-1',
  `smalllogo` tinyblob,
  `aboutcompanyfilename` varchar(100) default NULL,
  `aboutcompanyisfile` tinyint(1) default '-1',
  `aboutcompanyfilesize` varchar(100) default NULL,
  `aboutcompany` mediumblob,
  `contactname` varchar(255) NOT NULL default '',
  `contactphone` varchar(255) default NULL,
  `companyfax` varchar(250) default NULL,
  `contactemail` varchar(255) NOT NULL default '',
  `since` datetime default NULL,
  `companysize` varchar(255) default NULL,
  `income` varchar(255) default NULL,
  `description` text,
  `country` varchar(255) NOT NULL default '0',
  `state` varchar(255) default NULL,
  `county` varchar(255) default NULL,
  `city` varchar(255) default NULL,
  `zipcode` varchar(15) default NULL,
  `address1` varchar(255) default NULL,
  `address2` varchar(255) default NULL,
  `created` datetime NOT NULL default '0000-00-00 00:00:00',
  `modified` datetime default NULL,
  `hits` int(11) default NULL,
  `metadescription` text,
  `metakeywords` text,
  `status` tinyint(1) NOT NULL default '0',
  `packageid` int(11) default NULL,
  `paymenthistoryid` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `companies_uid` (`uid`),
  KEY `companies_category` (`category`),
  KEY `companies_packageid` (`packageid`)
);

CREATE TABLE `#__js_job_jobs` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) NOT NULL,
  `companyid` int(11) default NULL,
  `title` varchar(255) NOT NULL default '',
  `jobcategory` varchar(255) NOT NULL default '',
  `jobtype` tinyint(1) unsigned default '0',
  `jobstatus` tinyint(3) NOT NULL default '1',
  `jobsalaryrange` varchar(255) default '',
  `salaryrangetype` varchar(20) default NULL,
  `hidesalaryrange` tinyint(1) default '1',
  `description` text,
  `qualifications` text,
  `prefferdskills` text,
  `applyinfo` text,
  `company` varchar(255) NOT NULL default '',
  `country` varchar(255) default '',
  `state` varchar(255) default '',
  `county` varchar(255) default '',
  `city` varchar(255) default '',
  `zipcode` varchar(10) default '',
  `address1` varchar(255) default '',
  `address2` varchar(255) default '',
  `companyurl` varchar(255) default '',
  `contactname` varchar(255) default '',
  `contactphone` varchar(255) default '',
  `contactemail` varchar(255) default '',
  `showcontact` tinyint(1) unsigned default '0',
  `noofjobs` int(11) unsigned NOT NULL default '1',
  `reference` varchar(255) NOT NULL default '',
  `duration` varchar(255) NOT NULL default '',
  `heighestfinisheducation` varchar(255) default '',
  `created` datetime NOT NULL default '0000-00-00 00:00:00',
  `created_by` int(11) unsigned NOT NULL default '0',
  `modified` datetime NOT NULL default '0000-00-00 00:00:00',
  `modified_by` int(11) unsigned NOT NULL default '0',
  `hits` int(11) unsigned NOT NULL default '0',
  `experience` int(11) default '0',
  `startpublishing` datetime NOT NULL default '0000-00-00 00:00:00',
  `stoppublishing` datetime NOT NULL default '0000-00-00 00:00:00',
  `departmentid` varchar(255) default NULL,
  `shift` varchar(255) default NULL,
  `sendemail` tinyint(1) NOT NULL default '0',
  `metadescription` text,
  `metakeywords` text,
  `agreement` text,
  `ordering` tinyint(3) NOT NULL default '0',
  `aboutjobfile` varchar(50) default NULL,
  `status` int(11) default '1',
  `educationminimax` tinyint(1) default NULL,
  `educationid` int(11) default NULL,
  `mineducationrange` int(11) default NULL,
  `maxeducationrange` int(11) default NULL,
  `iseducationminimax` tinyint(1) default NULL,
  `degreetitle` varchar(255) default NULL,
  `careerlevel` int(11) default NULL,
  `experienceminimax` tinyint(1) default NULL,
  `experienceid` int(11) default NULL,
  `minexperiencerange` int(11) default NULL,
  `maxexperiencerange` int(11) default NULL,
  `isexperienceminimax` tinyint(1) default NULL,
  `experiencetext` varchar(255) default NULL,
  `workpermit` varchar(20) default NULL,
  `requiredtravel` int(11) default NULL,
  `agefrom` int(11) default NULL,
  `ageto` int(11) default NULL,
  `salaryrangefrom` int(11) default NULL,
  `salaryrangeto` int(11) default NULL,
  `gender` int(5) default NULL,
  `video` varchar(150) default NULL,
  `map` varchar(1000) default NULL,
  `packageid` int(11) default NULL,
  `paymenthistoryid` int(11) default NULL,
  `subcategoryid` int(11) default NULL,
  `currencyid` int(11) DEFAULT NULL,
  `jobid` varchar(25) DEFAULT '',
  `longitude` varchar(50) DEFAULT NULL,
  `latitude` varchar(50) DEFAULT NULL,
  PRIMARY KEY  (`id`),
  KEY `jobcategory` (`jobcategory`),
  KEY `jobs_companyid` (`companyid`),
  KEY `jobsalaryrange` (`jobsalaryrange`)
) ;

		
CREATE TABLE IF NOT EXISTS
`#__js_job_jobapply` (
  `id` int(11) NOT NULL auto_increment,
  `jobid` int(11) NOT NULL default '0',
  `uid` int(11) NOT NULL default '0',
  `cvid` int(11) default NULL,
  `apply_date` datetime default NULL,
  `resumeview` tinyint(1) NOT NULL default '0',
  `comments` varchar(1000) DEFAULT NULL,
  `coverletterid` int(11) DEFAULT NULL,
  PRIMARY KEY  (`id`),
  KEY `jobapply_uid` (`uid`),
  KEY `jobapply_jobid` (`jobid`),
  KEY `jobapply_cvid` (`cvid`)
) ;

CREATE TABLE IF NOT EXISTS
`#__js_job_jobsearches` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) default NULL,
  `searchname` varchar(50) NOT NULL,
  `jobtitle` varchar(255) default NULL,
  `category` int(11) default NULL,
  `jobtype` int(11) default NULL,
  `jobstatus` int(11) default NULL,
  `salaryrange` int(11) default NULL,
  `heighesteducation` int(11) default NULL,
  `shift` int(11) default NULL,
  `experience` varchar(30) default NULL,
  `durration` varchar(30) default NULL,
  `startpublishing` datetime default NULL,
  `stoppublishing` datetime default NULL,
  `company` int(11) default NULL,
  `country_istext` tinyint(1) default NULL,
  `country` varchar(50) default NULL,
  `state_istext` tinyint(1) default NULL,
  `state` varchar(50) default NULL,
  `county_istext` tinyint(1) default NULL,
  `county` varchar(50) default NULL,
  `city_istext` tinyint(1) default NULL,
  `city` varchar(50) default NULL,
  `zipcode_istext` tinyint(1) default NULL,
  `zipcode` varchar(50) default NULL,
  `created` datetime default NULL,
  `status` tinyint(1) default NULL,
  PRIMARY KEY  (`id`),
  KEY `jobsearches_uid` (`uid`)
) ;

CREATE TABLE IF NOT EXISTS
`#__js_job_jobstatus` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(100) NOT NULL default '',
  `isactive` tinyint(1) default 1,
  PRIMARY KEY  (`id`)
) ;
INSERT INTO `#__js_job_jobstatus` VALUES (1,'Sourcing','1'), (2,'Interviewing','1'), (3,'Closed to New Applicants','1'), (4,'Finalists Identified','1'), (5,'Pending Approval','1'), (6,'Hold','1');


CREATE TABLE IF NOT EXISTS
`#__js_job_jobtypes` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(100) NOT NULL default '',
  `isactive` tinyint(1) default 1,
  `status` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ;
INSERT INTO `#__js_job_jobtypes` VALUES (1,'Full-Time','1','0'), (2,'Part-Time','1','0'), (3,'Internship','1','0');


CREATE TABLE IF NOT EXISTS
`#__js_job_shifts` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(100) NOT NULL default '',
  `isactive` tinyint(1) default 1,
  `status` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ;
INSERT INTO `#__js_job_shifts` VALUES (1,'Morning','1','0'), (2,'Evening','1','0'), (3,'8 PM to 4 AM','1','0');

CREATE TABLE IF NOT EXISTS `#__js_job_config` (
  `configname` varchar(100) NOT NULL default '',
  `configvalue` varchar(255) NOT NULL default '',
  `configfor` varchar(50) default NULL,
  PRIMARY KEY  (`configname`),
   KEY `config_name` (`configname`),
   KEY `config_for` (`configfor`)
) ;

INSERT INTO `#__js_job_config` VALUES ('companyautoapprove','1','default'), ('comp_city','1','default'), ('comp_county','1','default'), ('comp_editor','1','default'), ('comp_state','1','default'), ('comp_zipcode','1','default'), ('currency','$','default'), ('cur_location','1','default'), ('defaultcountry','PK','default'), ('defaultempallow','1','defaultallow'), ('defaultjoballow','0','defaultallow'), ('empautoapprove','0','default'), ('employerdefaultrole','1','notuse'), ('jobautoapprove','0','default'), ('jobseekerdefaultrole','2','notuse'), ('job_editor','1','default'), ('mailfromaddress','sender@joomshark.com','email'), ('mailfromname','JS Jobs','email'), ('newdays','7','default'), ('resumeaddress','1','resume'), ('resumeeducation','1','resume'), ('resumeedu_gradeschool','1','resume'), ('resumeedu_highschool','1','resume'), ('resumeedu_otherchool','1','resume'), ('resumeedu_university','1','resume'), ('resumeemployer','1','resume'), ('resumeem_1','1','resume'), ('resumeem_2','1','resume'), ('resumeem_3','1','resume'), ('resumeem_recent','1','resume'), ('resumereference','1','resume'), ('resumereference1','1','resume'), ('resumereference2','1','resume'), ('resumereference3','1','resume'), ('resumeskill','1','resume'), ('search_job_durration','1','searchjob'), ('search_job_experience','1','searchjob'), ('search_job_heighesteducation','1','searchjob'), ('search_job_salaryrange','1','searchjob'), ('search_job_shift','1','searchjob'), ('search_job_showsave','1','searchjob'), ('search_job_startpublishing','1','searchjob'), ('search_job_stoppublishing','1','searchjob'), ('search_job_companysite','1','searchjob'), ('search_resume_available','1','searchresume'), ('search_resume_experience','1','searchresume'), ('actk', '0','default'), ('search_resume_gender','1','searchresume'), ('search_resume_heighesteducation','1','searchresume'), ('search_resume_name','1','searchresume'), ('search_resume_nationality','1','searchresume'), ('search_resume_salaryrange','1','searchresume'), ('search_resume_showsave','1','searchresume'), ('search_resume_title','1','searchresume'), ('showemployerlink','1','default'), ('theme','graywhite/css/jsjobsgraywhite.css','default'), ('title','JS JOBS','default'), ('data_directory', 'jsjobsdata', 'default'), ('version','1.0.8.7',NULL), ('versioncode', '1087',NULL), ('versiontype', 'business',NULL), ('filter_address', '1','default'), ('refercode', '0','default'), ('filter_address_fields_width', '130','default'), ('filter_category', '1','default'), ('filter_jobtype', '1','default'), ('filter_heighesteducation', '1','default'), ('filter_salaryrange', '1','default'), ('filter', '1','default'), ('fr_cr_txa', '<img src=\"components/com_jsjobs/images/jsjobs_logo_small.png\" width=\"65\">&nbsp;&nbsp;&nbsp;Powered by <a href=\"http://www.joomsky.com\" target=\"_blank\">Joom Sky</a>','default'), ('fr_cr_txsh', '1','default'), ('fr_cr_txb', '<br>&copy;Copyright 2008 - 2011, <a href=\"http://www.burujsolutions.com\" target=\"_blank\">Buruj Solutions </a> ','default'), ('backuponuninstall', '1',NULL), ('company_logofilezize', '50','default'), ('resume_photofilesize', '50','default'), ('offline', '1','default'), ('offline_text', 'JS Jobs is down for maintenance.<br /> Please check back again soon.','default'), ('payment_multicompanies','0','payment'), ('lj_title','1','listjob'), ('lj_category','1','listjob'), ('lj_jobtype','1','listjob'), ('lj_jobstatus','1','listjob'), ('lj_company','1','listjob'), ('lj_companysite','0','listjob'), ('lj_country','1','listjob'), ('lj_state','1','listjob'), ('lj_county','1','listjob'), ('lj_city','1','listjob'), ('lj_salary','1','listjob'), ('lj_created','1','listjob'), ('lj_noofjobs','1','listjob');

INSERT INTO `#__js_job_config` VALUES ('visitor_lj_title','1','listjob'), ('visitor_lj_category','1','listjob'), ('visitor_lj_jobtype','1','listjob'), ('visitor_lj_jobstatus','1','listjob'), ('visitor_lj_company','1','listjob'), ('visitor_lj_companysite','0','listjob'), ('visitor_lj_country','1','listjob'), ('visitor_lj_state','1','listjob'), ('visitor_lj_county','1','listjob'), ('visitor_lj_city','1','listjob'), ('visitor_lj_salary','1','listjob'), ('visitor_lj_created','1','listjob'), ('visitor_lj_noofjobs','1','listjob'), ('visitorview_js_controlpanel', '1','default'), ('visitorview_js_packages', '1','default'), ('visitorview_js_viewpackage', '1','default'), ('visitorview_js_jobcat', '1','default'), ('visitorview_js_listjob', '1','default'), ('visitorview_js_newestjobs', '1','default'), ('visitorview_js_jobsearch', '1','default'), ('visitorview_js_jobsearchresult', '1','default'), ('visitorview_js_viewresume', '1','default'), ('visitorview_emp_conrolpanel', '1','default'), ('visitorview_emp_packages', '1','default'), ('visitorview_emp_viewpackage', '1','default'), ('visitorview_emp_resumesearch', '1','default'), ('visitorview_emp_resumesearchresult', '1','default'), ('visitorview_emp_viewcompany', '1','default'), ('visitorview_emp_viewjob', '1','default'), ('search_job_title','1','searchjob'), ('search_job_category','1','searchjob'), ('search_job_type','1','searchjob'), ('search_job_status','1','searchjob'), ('search_job_company','1','searchjob'), ('search_job_country','1','searchjob'), ('search_job_state','1','searchjob'), ('search_job_county','1','searchjob'), ('search_job_city','1','searchjob'), ('search_job_zipcode','0','searchjob'), ('search_resume_category','1','searchresume'), ('search_resume_type','1','searchresume');
INSERT INTO `#__js_job_config` VALUES ('featuredjob_autoapprove', '1', 'featuredjob'), ('goldjob_autoapprove', '1', 'goldjob'), ('featuredcompany_autoapprove', '1', 'featuredcompany'), ('goldcompany_autoapprove', '1', 'goldcompany'), ('featuredresume_autoapprove', '1', 'featuredresume'), ('goldresume_autoapprove', '1', 'goldresume'), ('payment_method', 'paypal', 'payment'), ('payment_shopingurl', '', 'payment'), ('payment_successefulurl', '', 'payment'), ('payment_cancelurl', '', 'payment'), ('payment_paypalaccount', '', 'payment'), ('payment_showdescription', '1', 'payment'), ('payment_description', 'Description', 'payment'), ('payment_showfooter', '1', 'payment'), ('payment_currency', 'USD', 'payment'), ('payment_authtoken', '', 'payment'), ('payment_test_mode', '0', 'payment'), ('employer_defaultpackage', '1', 'package'), ('jobseeker_defaultpackage', '1', 'package'), ('date_format', 'd-m-Y', 'default'), ('adminemailaddress', '', 'email'), ('email_admin_new_company', '1', 'email'), ('email_admin_new_job', '1', 'email'), ('email_admin_new_resume', '1', 'email'), ('email_admin_job_apply', '1', 'email'), ('email_admin_new_department', '1', 'email'), ('email_admin_employer_package_purchase', '1', 'email'), ('email_admin_jobseeker_package_purchase', '1', 'email'), ('onlyonce_employer_getfreepackage', '1', 'package'), ('onlyonce_jobseeker_getfreepackage', '1', 'package'), ('employer_freepackage_autoapprove', '1', 'package'), ('jobseeker_freepackage_autoapprove', '1', 'package'), ('subcategories', '1', 'listjob'), ('subcategories_all', '1', 'listjob'), ('subcategories_colsperrow', '3', 'listjob'), ('subcategoeis_max_hight', '250', 'listjob'), ('categories_colsperrow', '3', 'default'), ('message_auto_approve', '1', 'messages'), ('conflict_message_auto_approve', '0', 'messages'), ('overwrite_jobalert_settings', '1', 'default'), ('visitor_can_apply_to_job', '0', 'default'), ('visitor_show_login_message', '1', 'default'), ('folder_auto_approve', '1', 'folder'), ('department_auto_approve', '1', 'department');

INSERT INTO `#__js_job_config` VALUES ('formcompany', '1', 'emcontrolpanel'), ('mycompanies', '1', 'emcontrolpanel'), ('formjob', '1', 'emcontrolpanel'), ('myjobs', '1', 'emcontrolpanel'), ('formdepartment', '1', 'emcontrolpanel'), ('mydepartment', '1', 'emcontrolpanel'), ('empmessages', '1', 'emcontrolpanel'), ('alljobsappliedapplications', '1', 'emcontrolpanel'), ('resumesearch', '1', 'emcontrolpanel'), ('my_resumesearches', '1', 'emcontrolpanel'), ('packages', '1', 'emcontrolpanel'), ('purchasehistory', '1', 'emcontrolpanel'), ('my_stats', '1', 'emcontrolpanel'), ('myfolders', '1', 'emcontrolpanel'), ('formresume', '1', 'jscontrolpanel'), ('myresumes', '1', 'jscontrolpanel'), ('formcoverletter', '1', 'jscontrolpanel'), ('mycoverletters', '1', 'jscontrolpanel'), ('jspackages', '1', 'jscontrolpanel'), ('jspurchasehistory', '1', 'jscontrolpanel'), ('jobalertsetting', '1', 'jscontrolpanel'), ('jobcat', '1', 'jscontrolpanel'), ('listnewestjobs', '1', 'jscontrolpanel'), ('myappliedjobs', '1', 'jscontrolpanel'), ('jobsearch', '1', 'jscontrolpanel'), ('my_jobsearches', '1', 'jscontrolpanel'), ('jsmy_stats', '1', 'jscontrolpanel'), ('jsmessages', '1', 'jscontrolpanel'), ('tmenu_emcontrolpanel', '1', 'default'), ('tmenu_emnewcompany', '1', 'default'), ('tmenu_emnewjob', '1', 'default'), ('tmenu_emmyjobs', '1', 'default'), ('tmenu_emmycompanies', '1', 'default'), ('tmenu_emappliedresume', '1', 'default'), ('tmenu_emnewdepartment', '1', 'default'), ('tmenu_emnewfolder', '1', 'default'), ('tmenu_jscontrolpanel', '1', 'default'), ('tmenu_jsjobcategory', '1', 'default'), ('tmenu_jssearchjob', '1', 'default'), ('tmenu_jsnewestjob', '1', 'default'), ('tmenu_jsmyresume', '1', 'default'), ('tmenu_jsaddresume', '1', 'default'), ('login_redirect', '', 'default'), ('tmenu_jsaddcoverletter', '1', 'default'), ('hidecountry', '0', 'default'), ('jobalert_auto_approve', '1', 'jobalert'), ('pagseguro_email', '1', 'payment'), ('lj_description','1','listjob'), ('visitor_lj_description','1','listjob'), ('lj_shortdescriptionlenght','200','listjob'), ('lj_joblistingstyle','july2011','listjob'), ('search_resume_style','july2011','searchresume'), ('filter_address_country','1','default'), ('filter_address_state','1','default'), ('filter_address_county','1','default'), ('filter_address_city','1','default'), ('testing_mode','1','default'), ('resume_style','tabular','default'), ('api_primary','','api'), ('api_secondary','','api');

INSERT INTO `#__js_job_config` VALUES ('search_job_subcategory','1','searchjob'), ('search_resume_subcategory','1','searchresume'), ('comp_show_url','1','default'), ('employerview_js_controlpanel','1','default'), ('search_job_keywords','1','searchjob'), ('vis_emformjob','1','default'), ('vis_emresumesearch','1','default'), ('vis_emmycompanies','1','default'), ('vis_emalljobsappliedapplications','1','default'), ('vis_emformcompany','1','default'), ('tmenu_vis_emappliedresume','1','default'), ('tmenu_vis_emmycompanies','1','default'), ('tmenu_vis_emmyjobs','1','default'), ('tmenu_vis_emnewjob','1','default'), ('tmenu_vis_emcontrolpanel','1','default'), ('vis_emmy_resumesearches','1','default'), ('vis_emmyjobs','1','default'), ('vis_empackages','1','default'), ('vis_emformdepartment','1','default'), ('vis_empurchasehistory','1','default'), ('vis_emmydepartment','1','default'), ('vis_emmy_stats','1','default'), ('vis_emmessages','1','default'), ('vis_emmyfolders','1','default'), ('tmenu_vis_jscontrolpanel','1','default'), ('tmenu_vis_jsjobcategory','1','default'), ('tmenu_vis_jsnewestjob','1','default'), ('tmenu_vis_jsmyresume','1','default'), ('vis_jsformresume','1','default'), ('vis_jsjobcat','1','default'), ('vis_jsmyresumes','1','default'), ('vis_jslistnewestjobs','1','default'), ('vis_jsformcoverletter','1','default'), ('vis_jsmyappliedjobs','1','default'), ('vis_jsmycoverletters','1','default'), ('vis_jspackages','1','default'), ('vis_jsmy_jobsearches','1','default'), ('vis_jspurchasehistory','1','default'), ('vis_jsjobsearch','1','default'), ('vis_jsmy_stats','1','default'), ('vis_jsjobalertsetting','1','default'), ('vis_jsmessages','1','default'), ('tmenu_vis_jssearchjob','1','default'), ('rss_job_title','Jobs RSS','rss'), ('rss_job_description','Job RSS Show the Latest Jobs On Our Sites','rss'), ('rss_job_categories','1','rss'), ('rss_job_image','1','rss'), ('rss_resume_categories','1','rss'), ('rss_resume_image','1','rss'), ('rss_resume_title','Resume RSS','rss'), ('rss_resume_description','Resume RSS Show the Latest Resume On Our Sites','rss'), ('rss_job_ttl','12','rss'), ('rss_job_copyright','Copyright 2009-2012','rss'), ('rss_job_webmaster','admin@domain.com','rss'), ('rss_job_editor','admin@domain.com','rss'), ('rss_resume_copyright','','rss'), ('rss_resume_webmaster','','rss'), ('rss_resume_editor','','rss'), ('rss_resume_ttl','','rss'), ('rss_resume_file','1','rss'), ('visitor_can_post_job','0','default'), ('visitor_can_edit_job','1','default'), ('job_captcha','1','default'), ('resume_captcha','1','default');
INSERT INTO `#__js_job_config` VALUES ('job_rss','1','default'), ('resume_rss','1','default'), ('empresume_rss','1','default'), ('jsjob_rss','1','default'), ('vis_resume_rss','1','default'), ('vis_job_rss','1','default'), ('default_longitude','74.3833333','default'),('default_latitude','31.5166667','default'),('search_job_coordinates','1','searchjob'),('vis_emresumebycategory','1','default'),('noofgoldjobsinlisting','3','default'),('nooffeaturedjobsinlisting','2','default'),('showgoldjobsinnewestjobs','1','default'),('showfeaturedjobsinnewestjobs','1','default'),('showgoldjobsinlistjobs','1','default'),('showfeaturedjobsinlistjobs','1','default'),('googleadsenseclient','ca-pub-8827762976015158','default'),('googleadsenseslot','9560237528','default'),('googleadsensewidth','717','default'),('googleadsenseheight','90','default'),('googleadsensecustomcss','','default'),('googleadsenseshowafter','4','default'),('googleadsenseshowinnewestjobs','0','default'),('googleadsenseshowinlistjobs','0','default'),('cron_job_alert_key','','default'),('empexpire_package_message','1','emcontrolpanel'),('jsexpire_package_message','1','jscontrolpanel'),('filter_map','1','default'),('defaultradius','2','default'), ('filter_map_fields_width','140','default'),('filter_cat_jobtype_fields_width','140','default'),('mapwidth','500','default'),('mapheight','200','default'),('comp_name','1','default'),('comp_email_address','1','default'),('filter_sub_category','1','default'),('topimage','1','default'),('labelinlisting','1','default'),('jsregister','1','jscontrolpanel'),('vis_jsregister','1','default'),('empregister','1','emcontrolpanel'),('vis_emempregister','1','default');

CREATE TABLE IF NOT EXISTS `#__js_job_coverletters` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) NOT NULL,
  `title` varchar(300) NOT NULL,
  `description` text NOT NULL,
  `hits` int(11) default NULL,
  `published` tinyint(1) NOT NULL,
  `searchable` tinyint(1) default NULL,
  `status` tinyint(1) default NULL,
  `created` datetime default NULL,
  `packageid` int(11) default NULL,
  `paymenthistoryid` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `coverletter_uid` (`uid`),
  KEY `coverletter_packgeid` (`packageid`)
) ;

CREATE TABLE IF NOT EXISTS
`#__js_job_emailtemplates` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) default NULL,
  `templatefor` varchar(50) default NULL,
  `title` varchar(50) default NULL,
  `subject` varchar(255) default NULL,
  `body` text,
  `status` tinyint(1) default NULL,
  `created` datetime default NULL,
  PRIMARY KEY  (`id`)
) ;
INSERT INTO `#__js_job_emailtemplates` VALUES (1,0,'company-approval',NULL,'Company {COMPANY_NAME} has been approved','<p>Dear  {EMPLOYER_NAME} , <br /><br />Your company <strong>{COMPANY_NAME}</strong> has been approved.</p><p> Login and view detail at www.joomsky.com  <br /><br />Please do not respond to this message. It is automatically generated and is for information purposes only. </p>',1,'2009-08-17 18:08:41'), (2,0,'company-rejecting',NULL,'Your Company {COMPANY_NAME} has been rejected','<p>Dear  {EMPLOYER_NAME} , </p><p>Your company<strong> {COMPANY_NAME}</strong> has been rejected. </p><p>Login and view detail at www.joomsky.com  </p><p>Please do not respond to this message. It is automatically generated and is for information purposes only. </p>',NULL,'2009-08-17 17:54:48'), (4,0,'job-approval',NULL,'Your job {JOB_TITLE} has been approved.','<p>Dear {EMPLOYER_NAME} , </p><p>Your job <strong>{JOB_TITLE}</strong> has been approved.</p><p> Login and view detail at $siteAddress </p><p>Please do not respond to this message. It is automatically generated and is for information purposes only.</p>',NULL,'2009-08-17 22:10:27'), (5,0,'job-rejecting',NULL,'Your job {JOB_TITLE} has been rejected.','<p>Dear {EMPLOYER_NAME} , </p><p>Your job <strong>{JOB_TITLE}</strong> has been rejected.</p><p> Login and view detail at $siteAddress </p><p>Please do not respond to this message. It is automatically generated and is for information purposes only.</p>',NULL,'2009-08-17 22:12:43'), (6,0,'resume-approval',NULL,'Your resume {RESUME_TITLE} has been approval.','<p>Dear {JOBSEEKER_NAME}  , </p><p> Your resume <strong>{RESUME_TITLE}</strong>  has been approval.</p><p> Login and view detail at $siteAddress </p><p>Please do not respond to this message. It is automatically generated and is for information purposes only.</p>',NULL,'2009-08-17 22:15:12'), (7,0,'resume-rejecting',NULL,'Your company {RESUME_TITLE} has been rejected. ','<p>Dear {JOBSEEKER_NAME}  , </p><p> Your resume <strong>{RESUME_TITLE}</strong>  has been rejected.</p><p> Login and view detail at $siteAddress </p><p>Please do not respond to this message. It is automatically generated and is for information purposes only.</p>',NULL,'2009-08-17 22:14:52'), (8,0,'jobapply-jobapply',NULL,'JS Jobs :  {JOBSEEKER_NAME} apply for {JOB_TITLE}','<p>Hello {EMPLOYER_NAME} , </p><p> Mr/Mrs {JOBSEEKER_NAME} apply for {JOB_TITLE}.</p><p> Login and view detail at $siteAddress \\n\\nPlease do not respond to this message. It is automatically generated and is for information purposes only.</p>',NULL,'2009-08-18 16:46:16'), (9,0,'company-new',NULL,'JS Jobs : New Company {COMPANY_NAME} has beed received','<p>Hello Admin , </p><p> We receive new company.</p><p> Login and view detail at $siteAddress \\n\\nPlease do not respond to this message. It is automatically generated and is for information purposes only.</p>',NULL,'2009-08-18 16:46:16'), (10,0,'job-new',NULL,'JS Jobs : New Job {JOB_TITLE} has beed received','<p>Hello Admin , </p><p> We receive new job.</p><p> Login and view detail at $siteAddress \\n\\nPlease do not respond to this message. It is automatically generated and is for information purposes only.</p>',NULL,'2009-08-18 16:46:16'), (11,0,'resume-new',NULL,'JS Jobs :  New resume {RESUME_TITLE} has beed received','<p>Hello Admin , </p><p> We receive new resume.</p><p> Login and view detail at $siteAddress \\n\\nPlease do not respond to this message. It is automatically generated and is for information purposes only.</p>',NULL,'2009-08-18 16:46:16'), (12,0,'department-new',NULL,'JS Jobs : New Department {DEPARTMENT_NAME} {COMPANY_NAME} has beed received','<p>Hello Admin , </p><p> We receive new department.</p><p> Login and view detail at $siteAddress \\n\\nPlease do not respond to this message. It is automatically generated and is for information purposes only.</p>',NULL,'2009-08-18 16:46:16'), (13,0,'employer-buypackage',NULL,'JS Jobs : Employer Buy Package {PACKAGE_NAME}','<p>Hello Admin , </p><p> Employer buy a package.</p><p> Login and view detail at $siteAddress \\n\\nPlease do not respond to this message. It is automatically generated and is for information purposes only.</p>',NULL,'2009-08-18 16:46:16'), (14,0,'jobseeker-buypackage',NULL,'JS Jobs : Jobseeker Buy Package {PACKAGE_NAME}','<p>Hello Admin , </p><p> Job Seeker buy package.</p><p> Login and view detail at $siteAddress \\n\\nPlease do not respond to this message. It is automatically generated and is for information purposes only.</p>',NULL,'2009-08-18 16:46:16'), (15,'0','message-email', null, 'JS Jobs: New Message Alert', '<p>Dear {NAME},</p>\r\n<p>{SENDER_NAME}: send you new message.</p>\r\n<p><strong><span style=\"text-decoration: underline;\">Summary</span></strong></p>\r\n<p>Company Name: {COMPANY_NAME}</p>\r\n<p>Job Title: {JOB_TITLE}</p>\r\n<p>Resume Title: {RESUME_TITLE}</p>', '1', '2009-08-18 16:46:16'), (16,0,'job-alert',NULL,'JS Jobs: New Job','<p>Dear {JOBSEEKER_NAME} , </p><p> We receive new job.</p><p> {JOBS_INFO}</p><p> Login and view detail at  Please do not respond to this message. It is automatically generated and is for information purposes only.</p>	',NULL,'2011-03-31 16:46:16'), (17,0,'job-alert-visitor',NULL,'JS Jobs: New Job By Visitor','<p>Dear {CONTACT_NAME} ,</p>\r\n<p>We receive new job.</p>\r\n<p>Title: {JOB_TITLE}</p>\r\n<p>Job Category: {JOB_CATEGORY}</p>\r\n<p>Company Name: {COMPANY_NAME}</p>\r\n<p>Status: {JOB_STATUS}</p>\r\n<p>Login and view detail at Please do not respond to this message. It is automatically generated and is for information purposes only.</p>',NULL,'2011-03-31 16:46:16'), (18, 0, 'job-to-friend', NULL, 'JS Jobs: Job To Friend', '<p>Dear Mr/Miss,</p>\r\n<p>Your Friend {SENDER_NAME} will send you this mail through our site {SITE_NAME} to inform you for a job.</p>\r\n<p>Title: {JOB_TITLE}</p>\r\n<p>Job Category: {JOB_CATEGORY}</p>\r\n<p>Company Name: {COMPANY_NAME}</p>\r\n<p>{CLICK_HERE_TO_VISIT} the job detail.</p>\r\n<p>Thank you.</p>\r\n<p>{SENDER_MESSAGE}</p>', NULL, '2011-03-31 16:46:16');

CREATE TABLE IF NOT EXISTS
`#__js_job_fieldsordering` (
  `id` int(11) NOT NULL auto_increment,
  `field` varchar(50) NOT NULL,
  `fieldtitle` varchar(50) default NULL,
  `ordering` int(11) default NULL,
  `section` varchar(20) default NULL,
  `fieldfor` tinyint(2) default NULL,
  `published` tinyint(1) default NULL,
  `sys` tinyint(1) NOT NULL,
  `cannotunpublish` tinyint(1) NOT NULL,
  `required` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `fieldordering_filedfor` (`fieldfor`)
) ;
INSERT INTO `#__js_job_fieldsordering` (`id`, `field`, `fieldtitle`, `ordering`, `section`, `fieldfor`, `published`, `sys`, `cannotunpublish`, `required`) VALUES (1,'jobcategory','Job Category',2,NULL,1,1,1,1,1), (2,'name','Name',1,NULL,1,1,1,1,0), (3,'url','URL',3,NULL,1,1,1,0,0), (4,'contactname','Contact Name',4,NULL,1,1,1,1,0), (5,'contactphone','Contact Phone',5,NULL,1,1,1,0,0), (6,'contactemail','Contact Email',6,NULL,1,1,1,1,0), (7,'since','Since',8,NULL,1,1,1,0,0), (8,'companysize','Company Size',9,NULL,1,0,1,0,0), (9,'income','Income',10,NULL,1,1,1,0,0), (10,'description','Description',11,NULL,1,1,1,0,0), (11,'address1','Address1',17,NULL,1,1,1,0,0), (12,'logo','Logo',19,NULL,1,1,1,0,0), (20,'contactfax','Contact Fax',7,NULL,1,0,1,0,0), (21,'country','Country',12,NULL,1,1,1,1,0), (22,'state','State',13,NULL,1,1,1,0,0), (23,'county','County',14,'',1,1,1,0,0), (24,'city','City',15,NULL,1,1,1,0,0), (25,'zipcode','Zipcode',16,NULL,1,1,1,0,0), (26,'address2','Address2',18,NULL,1,1,1,0,0), (101,'jobtitle','Job Title',1,NULL,2,1,1,1,1), (102,'company','Company',2,NULL,2,1,1,1,1), (103,'department','Department',3,NULL,2,1,1,0,1), (104,'jobcategory','Job Category',4,NULL,2,1,1,1,1), (105,'subcategory','Sub Category',5,NULL,2,1,1,0,0), (106,'jobtype','Job Type',6,NULL,2,1,1,1,1), (107,'jobstatus','Job Status',7,NULL,2,1,1,1,1), (108,'gender','Gender',8,NULL,2,1,1,0,0), (109,'age','Age',9,NULL,2,1,1,0,0), (110,'jobsalaryrange','Job Salary Range',10,NULL,2,1,1,0,0), (111,'jobshift','Job Shift',11,NULL,2,1,1,0,0), (112,'heighesteducation','Heighest Education',12,NULL,2,1,1,1,0), (113,'experience','Experience',13,NULL,2,1,1,1,0), (114,'noofjobs','No of Jobs',14,NULL,2,1,1,0,0), (115,'duration','Duration',15,NULL,2,1,1,0,0), (116,'careerlevel','Career Level',16,NULL,2,1,1,0,0), (117,'workpermit','Work Permit',17,NULL,2,1,1,0,0), (118,'requiredtravel','Required Travel',18,NULL,2,1,1,0,0), (119,'video','Video',19,NULL,2,1,1,0,0), (120,'map','Map',20,NULL,2,1,1,0,1), (121,'startpublishing','Start Publishing',21,NULL,2,1,1,1,1), (122,'stoppublishing','Stop Publishing',22,NULL,2,1,1,1,1), (123,'country','Country',23,NULL,2,1,1,0,0), (124,'state','State',24,NULL,2,1,1,0,0), (125,'county','County',25,NULL,2,1,1,0,0), (126,'city','City',26,NULL,2,1,1,0,0), (130,'sendemail','Send Email',27,NULL,2,1,1,0,0), (131,'sendmeresume','Send me Resume',28,NULL,2,1,1,0,0), (132,'description','Description',29,NULL,2,1,1,0,0), (133,'qualifications','Qualifications',30,NULL,2,1,1,0,0), (134,'prefferdskills','Prefered Skills',31,NULL,2,1,1,0,0), (135,'agreement','Agreement',32,NULL,2,1,1,0,1), (136,'metadescription','Meta Description',33,NULL,2,1,1,0,1), (137,'metakeywords','Meta Keywords',34,NULL,2,1,1,0,1), (127,'zipcode','Zipcode',26,NULL,2,1,1,0,0);
INSERT INTO `#__js_job_fieldsordering` (`id`, `field`, `fieldtitle`, `ordering`, `section`, `fieldfor`, `published`, `sys`, `cannotunpublish`, `required`) VALUES (301,'section_personal','Personal Information',0,'10',3,1,1,1,0), (302,'applicationtitle','Application Title',1,'10',3,1,1,1,0), (303,'firstname','First Name',2,'10',3,1,1,1,0), (304,'middlename','Middle Name',3,'10',3,1,1,0,0), (305,'lastname','Last Name',4,'10',3,1,1,1,0), (306,'emailaddress','Email Address',5,'10',3,1,1,1,0), (307,'homephone','Home Phone',6,'10',3,1,1,0,0), (308,'workphone','Work Phone',7,'10',3,1,1,0,0), (309,'cell','Cell',8,'10',3,1,1,0,0), (310,'nationality','Nationality',9,'10',3,1,1,0,0), (311,'gender','Gender',10,'10',3,1,1,0,0), (312,'photo','Photo',12,'10',3,1,1,0,0), (453,'fileupload','File Upload',13,'10',3,1,1,0,0), (313,'section_basic','Basic Information',15,'20',3,1,1,1,0), (314,'category','Category',16,'20',3,1,1,1,0), (315,'salary','Salary ',17,'20',3,1,1,1,0), (316,'jobtype','Job Type',18,'20',3,1,1,1,0), (317,'heighesteducation','Heighest Education',19,'20',3,1,1,1,0), (318,'totalexperience','Total Experience',20,'20',3,1,1,1,0), (319,'startdate','Date you can start',21,'20',3,1,1,1,0), (320,'section_addresses','Addresses',42,'30',3,1,1,0,0), (321,'section_sub_address','Current Address',43,'31',3,1,1,0,0), (322,'address_country','Country',44,'31',3,1,1,0,0), (323,'address_state','State',45,'31',3,1,1,0,0), (324,'address_county','County',46,'31',3,1,1,0,0), (325,'address_city','City',47,'31',3,1,1,0,0), (326,'address_zipcode','Zip Code',48,'31',3,1,1,0,0), (327,'address_address','Address',49,'31',3,1,1,0,0), (328,'section_sub_address1','Address1',51,'32',3,1,1,0,0), (329,'address1_country','Country',52,'32',3,1,1,0,0), (330,'address1_state','State',53,'32',3,1,1,0,0), (331,'address1_county','County',54,'32',3,1,1,0,0), (332,'address1_city','City',55,'32',3,1,1,0,0), (333,'address1_zipcode','Zip Code',56,'32',3,1,1,0,0), (334,'address1_address','Address',57,'32',3,1,1,0,0), (335,'section_sub_address2','Address1',61,'33',3,1,1,0,0), (336,'address2_country','Country',62,'33',3,1,1,0,0), (337,'address2_state','State',63,'33',3,1,1,0,0), (338,'address2_county','County',64,'33',3,1,1,0,0), (339,'address2_city','City',65,'33',3,1,1,0,0), (340,'address2_zipcode','Zip Code',66,'33',3,1,1,0,0), (341,'address2_address','Address',67,'33',3,1,1,0,0), (342,'section_education','Education',71,'40',3,1,1,0,0), (343,'section_sub_institute','High School',72,'41',3,1,1,0,0), (344,'institute_institute','Institute',73,'41',3,1,1,0,0), (345,'institute_country','Country',74,'41',3,1,1,0,0), (346,'institute_state','State',75,'41',3,1,1,0,0), (347,'institute_county','County',76,'41',3,1,1,0,0), (348,'institute_city','City',77,'41',3,1,1,0,0), (349,'institute_address','Address',78,'41',3,1,1,0,0), (350,'institute_certificate','Certificate Name',79,'41',3,1,1,0,0), (351,'institute_study_area','Study Area',80,'41',3,1,1,0,0);
INSERT INTO `#__js_job_fieldsordering` (`id`, `field`, `fieldtitle`, `ordering`, `section`, `fieldfor`, `published`, `sys`, `cannotunpublish`, `required`) VALUES (352,'section_sub_institute1','University',82,'42',3,1,1,0,0), (353,'institute1_institute','Institute',83,'42',3,1,1,0,0), (354,'institute1_country','Country',84,'42',3,1,1,0,0), (355,'institute1_state','State',85,'42',3,1,1,0,0), (356,'institute1_county','County',86,'42',3,1,1,0,0), (357,'institute1_city','City',87,'42',3,1,1,0,0), (358,'institute1_address','Address',88,'42',3,1,1,0,0), (359,'institute1_certificate','Certificate Name',89,'42',3,1,1,0,0), (360,'institute1_study_area','Study Area',90,'42',3,1,1,0,0), (361,'section_sub_institute2','Grade School',92,'43',3,1,1,0,0), (362,'institute2_institute','Institute',93,'43',3,1,1,0,0), (363,'institute2_country','Country',94,'43',3,1,1,0,0), (364,'institute2_state','State',95,'43',3,1,1,0,0), (365,'institute2_county','County',96,'43',3,1,1,0,0), (366,'institute2_city','City',97,'43',3,1,1,0,0), (367,'institute2_address','Address',98,'43',3,1,1,0,0), (368,'institute2_certificate','Certificate Name',99,'43',3,1,1,0,0), (369,'institute2_study_area','Study Area',100,'43',3,1,1,0,0), (370,'section_sub_institute3','Other School',102,'44',3,1,1,0,0), (371,'institute3_institute','Institute',103,'44',3,1,1,0,0), (372,'institute3_country','Country',104,'44',3,1,1,0,0), (373,'institute3_state','State',105,'44',3,1,1,0,0), (374,'institute3_county','County',106,'44',3,1,1,0,0), (375,'institute3_city','City',107,'44',3,1,1,0,0), (376,'institute3_address','Address',108,'44',3,1,1,0,0), (377,'institute3_certificate','Certificate Name',109,'44',3,1,1,0,0), (378,'institute3_study_area','Study Area',110,'44',3,1,1,0,0), (379,'section_employer','Employer',112,'50',3,1,1,0,0), (380,'section_sub_employer','Recent Employer',113,'51',3,1,1,0,0), (381,'employer_employer','Employer',114,'51',3,1,1,0,0), (382,'employer_position','Position',114,'51',3,1,1,0,0), (383,'employer_resp','Responsibilities',115,'51',3,1,1,0,0), (384,'employer_pay_upon_leaving','Pay Upon Leaving',116,'51',3,1,1,0,0), (385,'employer_supervisor','Supervisor',117,'51',3,1,1,0,0), (386,'employer_from_date','From Date',118,'51',3,1,1,0,0), (387,'employer_to_date','To Date',119,'51',3,1,1,0,0), (388,'employer_leave_reason','Leave Reason',120,'51',3,1,1,0,0), (389,'employer_country','Country',121,'51',3,1,1,0,0), (390,'employer_state','State',122,'51',3,1,1,0,0), (391,'employer_county','County',123,'51',3,1,1,0,0), (392,'employer_city','City',124,'51',3,1,1,0,0), (393,'employer_zip','Zip Code',125,'51',3,1,1,0,0), (394,'employer_phone','Phone',126,'51',3,1,1,0,0), (395,'employer_address','Address',127,'51',3,1,1,0,0), (396,'section_sub_employer1','Prior Employer 1',128,'52',3,1,1,0,0), (397,'employer1_employer','Employer',129,'52',3,1,1,0,0), (398,'employer1_position','Position',130,'52',3,1,1,0,0), (399,'employer1_resp','Responsibilities',131,'52',3,1,1,0,0), (400,'employer1_pay_upon_leaving','Pay Upon Leaving',132,'52',3,1,1,0,0), (401,'employer1_supervisor','Supervisor',133,'52',3,1,1,0,0), (402,'employer1_from_date','From Date',134,'52',3,1,1,0,0), (403,'employer1_to_date','To Date',135,'52',3,1,1,0,0), (404,'employer1_leave_reason','Leave Reason',136,'52',3,1,1,0,0), (405,'employer1_country','Country',137,'52',3,1,1,0,0), (406,'employer1_state','State',138,'52',3,1,1,0,0), (407,'employer1_county','County',139,'52',3,1,1,0,0), (408,'employer1_city','City',140,'52',3,1,1,0,0), (409,'employer1_zip','Zip Code',141,'52',3,1,1,0,0), (410,'employer1_phone','Phone',142,'52',3,1,1,0,0), (412,'employer1_address','Address',143,'52',3,1,1,0,0);
INSERT INTO `#__js_job_fieldsordering` (`id`, `field`, `fieldtitle`, `ordering`, `section`, `fieldfor`, `published`, `sys`, `cannotunpublish`, `required`) VALUES (413,'section_sub_employer2','Prior Employer 2',146,'53',3,1,1,0,0), (414,'employer2_employer','Employer',147,'53',3,1,1,0,0), (415,'employer2_position','Position',148,'53',3,1,1,0,0), (416,'employer2_resp','Responsibilities',149,'53',3,1,1,0,0), (417,'employer2_pay_upon_leaving','Pay Upon Leaving',150,'53',3,1,1,0,0), (418,'employer2_supervisor','Supervisor',151,'53',3,1,1,0,0), (419,'employer2_from_date','From Date',152,'53',3,1,1,0,0), (420,'employer2_to_date','To Date',153,'53',3,1,1,0,0), (421,'employer2_leave_reason','Leave Reason',154,'53',3,1,1,0,0), (423,'employer2_country','Country',155,'53',3,1,1,0,0), (424,'employer2_state','State',156,'53',3,1,1,0,0), (425,'employer2_county','County',157,'53',3,1,1,0,0), (426,'employer2_city','City',158,'53',3,1,1,0,0), (427,'employer2_zip','Zip Code',159,'53',3,1,1,0,0), (428,'employer2_phone','Phone',160,'53',3,1,1,0,0), (429,'employer2_address','Address',161,'53',3,1,1,0,0), (430,'section_sub_employer3','Prior Employer 3',166,'54',3,1,1,0,0), (431,'employer3_employer','Employer',167,'54',3,1,1,0,0), (432,'employer3_position','Position',168,'54',3,1,1,0,0), (433,'employer3_resp','Responsibilities',169,'54',3,1,1,0,0), (434,'employer3_pay_upon_leaving','Pay Upon Leaving',170,'54',3,1,1,0,0), (435,'employer3_supervisor','Supervisor',171,'54',3,1,1,0,0), (436,'employer3_from_date','From Date',172,'54',3,1,1,0,0), (437,'employer3_to_date','To Date',173,'54',3,1,1,0,0), (438,'employer3_leave_reason','Leave Reason',174,'54',3,1,1,0,0), (439,'employer3_country','Country',175,'54',3,1,1,0,0), (440,'employer3_state','State',176,'54',3,1,1,0,0), (441,'employer3_county','County',177,'54',3,1,1,0,0), (442,'employer3_city','City',178,'54',3,1,1,0,0), (443,'employer3_zip','Zip Code',179,'54',3,1,1,0,0), (444,'employer3_phone','Phone',180,'54',3,1,1,0,0), (445,'employer3_address','Address',181,'54',3,1,1,0,0), (446,'section_skills','Skills',186,'60',3,1,1,0,0), (447,'driving_license','Driving License',187,'60',3,1,1,0,0), (448,'license_no','License No',188,'60',3,1,1,0,0), (449,'license_country','License Country',189,'60',3,1,1,0,0), (450,'skills','Skills',190,'60',3,1,1,0,0), (451,'section_resumeeditor','Resume Editor',196,'70',3,1,1,0,0), (452,'editor','Editor',197,'70',3,1,1,0,0), (454,'section_references','References',206,'80',3,1,1,0,0), (455,'section_sub_reference','Reference 1',207,'81',3,1,1,0,0), (456,'reference_reference','Reference',208,'81',3,1,1,0,0), (457,'reference_name','Name',209,'81',3,1,1,0,0), (458,'reference_country','Country',210,'81',3,1,1,0,0), (459,'reference_state','State',211,'81',3,1,1,0,0), (460,'reference_county','County',212,'81',3,1,1,0,0), (471,'reference_city','City',213,'81',3,1,1,0,0), (472,'reference_zipcode','Zip Code',214,'81',3,1,1,0,0), (473,'reference_phone','Phone',215,'81',3,1,1,0,0), (474,'reference_relation','Relation',216,'81',3,1,1,0,0), (475,'reference_years','Years',217,'81',3,1,1,0,0);
INSERT INTO `#__js_job_fieldsordering` (`id`, `field`, `fieldtitle`, `ordering`, `section`, `fieldfor`, `published`, `sys`, `cannotunpublish`, `required`) VALUES (476,'section_sub_reference1','Reference 2',221,'82',3,1,1,0,0), (477,'reference1_reference','Reference',222,'82',3,1,1,0,0), (478,'reference1_name','Name',223,'82',3,1,1,0,0), (479,'reference1_country','Country',224,'82',3,1,1,0,0), (480,'reference1_state','State',225,'82',3,1,1,0,0), (481,'reference1_county','County',226,'82',3,1,1,0,0), (482,'reference1_city','City',227,'82',3,1,1,0,0), (483,'reference1_zipcode','Zip Code',228,'82',3,1,1,0,0), (484,'reference1_phone','Phone',229,'82',3,1,1,0,0), (485,'reference1_relation','Relation',230,'82',3,1,1,0,0), (486,'reference1_years','Years',231,'82',3,1,1,0,0), (487,'section_sub_reference2','Reference 3',232,'83',3,1,1,0,0), (488,'reference2_reference','Reference',233,'83',3,1,1,0,0), (489,'reference2_name','Name',234,'83',3,1,1,0,0), (490,'reference2_country','Country',235,'83',3,1,1,0,0), (491,'reference2_state','State',236,'83',3,1,1,0,0), (492,'reference2_county','County',237,'83',3,1,1,0,0), (493,'reference2_city','City',238,'83',3,1,1,0,0), (494,'reference2_zipcode','Zip Code',239,'83',3,1,1,0,0), (495,'reference2_phone','Phone',240,'83',3,1,1,0,0), (496,'reference2_relation','Relation',241,'83',3,1,1,0,0), (497,'reference2_years','Years',242,'83',3,1,1,0,0), (498,'section_sub_reference3','Reference 4',243,'84',3,1,1,0,0), (499,'reference3_reference','Reference',244,'84',3,1,1,0,0), (500,'reference3_name','Name',245,'84',3,1,1,0,0), (501,'reference3_country','Country',246,'84',3,1,1,0,0), (502,'reference3_state','State',247,'84',3,1,1,0,0), (503,'reference3_county','County',248,'84',3,1,1,0,0), (504,'reference3_city','City',249,'84',3,1,1,0,0), (505,'reference3_zipcode','Zip Code',250,'84',3,1,1,0,0), (506,'reference3_phone','Phone',251,'84',3,1,1,0,0), (507,'reference3_relation','Relation',252,'84',3,1,1,0,0), (508,'reference3_years','Years',253,'84',3,1,1,0,0), (510,'Iamavailable','I am Available',11,'10',3,1,1,0,0), (511,'searchable','Searchable',12,'10',3,1,1,0,0), (512,'section_userfields','User Fields',22,'1000',3,0,0,0,0), (513,'userfield1','User Field 1',23,'1000',3,0,0,0,0), (514,'userfield2','User Field 2',24,'1000',3,0,0,0,0), (515,'userfield3','User Field 3',25,'1000',3,0,0,0,0), (516,'userfield4','User Field 4',26,'1000',3,0,0,0,0), (517,'userfield5','User Field 5',27,'1000',3,0,0,0,0), (518,'userfield6','User Field 6',28,'1000',3,0,0,0,0), (519,'userfield7','User Field 7',29,'1000',3,0,0,0,0), (520,'userfield8','User Field 8',30,'1000',3,0,0,0,0), (521,'userfield9','User Field 9',31,'1000',3,0,0,0,0), (522,'userfield10','User Field 10',32,'1000',3,0,0,0,0);
INSERT INTO `#__js_job_fieldsordering` (`id`, `field`, `fieldtitle`, `ordering`, `section`, `fieldfor`, `published`, `sys`, `cannotunpublish`, `required`) VALUES (523,'jobcategory','Job Category',1,NULL,11,1,1,1,1), (524,'name','Name',2,NULL,11,1,1,1,0), (525,'url','URL',3,NULL,11,0,1,0,0), (526,'contactname','Contact Name',4,NULL,11,1,1,1,0), (527,'contactphone','Contact Phone',5,NULL,11,0,1,0,0), (528,'contactemail','Contact Email',6,NULL,11,1,1,1,0), (529,'since','Since',8,NULL,11,0,1,0,0), (530,'companysize','Company Size',9,NULL,11,0,1,0,0), (531,'income','Income',10,NULL,11,1,1,0,0), (532,'description','Description',11,NULL,11,1,1,0,0), (533,'address1','Address1',17,NULL,11,1,1,0,0), (534,'logo','Logo',19,NULL,11,1,1,0,0), (535,'contactfax','Contact Fax',7,NULL,11,0,1,0,0), (536,'country','Country',12,NULL,11,1,1,1,0), (537,'state','State',13,NULL,11,1,1,0,0), (538,'county','County',14,'',11,1,1,0,0), (539,'city','City',15,NULL,11,1,1,0,0), (540,'zipcode','Zipcode',16,NULL,11,1,1,0,0), (541,'address2','Address2',18,NULL,11,1,1,0,0), (542,'jobtitle','Job Title',1,NULL,12,1,1,1,1), (543,'company','Company',2,NULL,12,1,1,1,1), (544,'department','Department',3,NULL,12,1,1,0,1), (545,'jobcategory','Job Category',4,NULL,12,1,1,1,1), (546,'subcategory','Sub Category',5,NULL,12,1,1,0,0), (547,'jobtype','Job Type',6,NULL,12,1,1,1,1), (548,'jobstatus','Job Status',7,NULL,12,1,1,1,1), (549,'gender','Gender',8,NULL,12,1,1,0,0), (550,'age','Age',9,NULL,12,1,1,0,0), (551,'jobsalaryrange','Job Salary Range',10,NULL,12,1,1,0,0), (552,'jobshift','Job Shift',11,NULL,12,1,1,0,0), (553,'heighesteducation','Heighest Education',12,NULL,12,1,1,1,0), (554,'experience','Experience',13,NULL,12,1,1,1,0), (555,'noofjobs','No of Jobs',14,NULL,12,1,1,0,0), (556,'duration','Duration',15,NULL,12,1,1,0,0), (557,'careerlevel','Career Level',16,NULL,12,1,1,0,0), (558,'workpermit','Work Permit',17,NULL,12,1,1,0,0), (559,'requiredtravel','Required Travel',18,NULL,12,1,1,0,0), (560,'video','Video',19,NULL,12,1,1,0,0), (561,'map','Map',20,NULL,12,1,1,0,1), (562,'startpublishing','Start Publishing',21,NULL,12,1,1,1,1), (563,'stoppublishing','Stop Publishing',22,NULL,12,1,1,1,1), (564,'country','Country',23,NULL,12,1,1,0,0), (565,'state','State',24,NULL,12,1,1,0,0), (566,'county','County',25,NULL,12,1,1,0,0), (567,'city','City',26,NULL,12,1,1,0,0), (568,'sendemail','Send Email',27,NULL,12,1,1,0,0), (569,'sendmeresume','Send me Resume',28,NULL,12,1,1,0,0), (570,'description','Description',29,NULL,12,1,1,0,0), (571,'qualifications','Qualifications',30,NULL,12,1,1,0,0), (572,'prefferdskills','Prefered Skills',31,NULL,12,1,1,0,0), (573,'agreement','Agreement',32,NULL,12,1,1,0,1), (574,'metadescription','Meta Description',33,NULL,12,1,1,0,1), (575,'metakeywords','Meta Keywords',34,NULL,12,1,1,0,1), (576,'zipcode','Zipcode',26,NULL,12,1,1,0,0);
INSERT INTO `#__js_job_fieldsordering` (`id`, `field`, `fieldtitle`, `ordering`, `section`, `fieldfor`, `published`, `sys`, `cannotunpublish`, `required`) VALUES (577,'section_personal','Personal Information',0,'10',13,1,1,1,0), (578,'applicationtitle','Application Title',1,'10',13,1,1,1,0), (579,'firstname','First Name',2,'10',13,1,1,1,0), (580,'middlename','Middle Name',3,'10',13,0,1,0,0), (581,'lastname','Last Name',4,'10',13,1,1,1,0), (582,'emailaddress','Email Address',5,'10',13,1,1,1,0), (583,'homephone','Home Phone',6,'10',13,1,1,0,0), (584,'workphone','Work Phone',7,'10',13,1,1,0,0), (585,'cell','Cell',8,'10',13,1,1,0,0), (586,'nationality','Nationality',9,'10',13,1,1,0,0), (587,'gender','Gender',10,'10',13,1,1,0,0), (588,'photo','Photo',12,'10',13,1,1,0,0), (589,'fileupload','File Upload',13,'10',13,1,1,0,0), (590,'section_basic','Basic Information',15,'20',13,1,1,1,0), (591,'category','Category',16,'20',13,1,1,1,0), (592,'salary','Salary ',17,'20',13,1,1,1,0), (593,'jobtype','Job Type',18,'20',13,1,1,1,0), (594,'heighesteducation','Heighest Education',19,'20',13,1,1,1,0), (595,'totalexperience','Total Experience',20,'20',13,1,1,1,0), (596,'startdate','Date you can start',21,'20',13,1,1,1,0), (597,'section_addresses','Addresses',42,'30',13,1,1,0,0), (598,'section_sub_address','Current Address',43,'31',13,1,1,0,0), (599,'address_country','Country',44,'31',13,1,1,0,0), (600,'address_state','State',45,'31',13,1,1,0,0), (601,'address_county','County',46,'31',13,1,1,0,0), (602,'address_city','City',47,'31',13,1,1,0,0), (603,'address_zipcode','Zip Code',48,'31',13,1,1,0,0), (604,'address_address','Address',49,'31',13,1,1,0,0), (605,'section_sub_address1','Address1',51,'32',13,1,1,0,0), (606,'address1_country','Country',52,'32',13,1,1,0,0), (607,'address1_state','State',53,'32',13,1,1,0,0), (608,'address1_county','County',54,'32',13,1,1,0,0), (609,'address1_city','City',55,'32',13,1,1,0,0), (610,'address1_zipcode','Zip Code',56,'32',13,1,1,0,0), (611,'address1_address','Address',57,'32',13,1,1,0,0), (612,'section_sub_address2','Address1',61,'33',13,1,1,0,0), (613,'address2_country','Country',62,'33',13,1,1,0,0), (614,'address2_state','State',63,'33',13,1,1,0,0), (615,'address2_county','County',64,'33',13,1,1,0,0), (616,'address2_city','City',65,'33',13,1,1,0,0), (617,'address2_zipcode','Zip Code',66,'33',13,1,1,0,0), (618,'address2_address','Address',67,'33',13,1,1,0,0), (619,'section_education','Education',71,'40',13,1,1,0,0), (620,'section_sub_institute','High School',72,'41',13,1,1,0,0), (621,'institute_institute','Institute',73,'41',13,1,1,0,0), (622,'institute_country','Country',74,'41',13,1,1,0,0), (623,'institute_state','State',75,'41',13,1,1,0,0), (624,'institute_county','County',76,'41',13,1,1,0,0), (625,'institute_city','City',77,'41',13,1,1,0,0), (626,'institute_address','Address',78,'41',13,1,1,0,0), (627,'institute_certificate','Certificate Name',79,'41',13,1,1,0,0), (628,'institute_study_area','Study Area',80,'41',13,1,1,0,0);
INSERT INTO `#__js_job_fieldsordering` (`id`, `field`, `fieldtitle`, `ordering`, `section`, `fieldfor`, `published`, `sys`, `cannotunpublish`, `required`) VALUES (629,'section_sub_institute1','University',82,'42',13,1,1,0,0), (630,'institute1_institute','Institute',83,'42',13,1,1,0,0), (631,'institute1_country','Country',84,'42',13,1,1,0,0), (632,'institute1_state','State',85,'42',13,1,1,0,0), (633,'institute1_county','County',86,'42',13,1,1,0,0), (634,'institute1_city','City',87,'42',13,1,1,0,0), (635,'institute1_address','Address',88,'42',13,1,1,0,0), (636,'institute1_certificate','Certificate Name',89,'42',13,1,1,0,0), (637,'institute1_study_area','Study Area',90,'42',13,1,1,0,0), (638,'section_sub_institute2','Grade School',92,'43',13,1,1,0,0), (639,'institute2_institute','Institute',93,'43',13,1,1,0,0), (640,'institute2_country','Country',94,'43',13,1,1,0,0), (641,'institute2_state','State',95,'43',13,1,1,0,0), (642,'institute2_county','County',96,'43',13,1,1,0,0), (643,'institute2_city','City',97,'43',13,1,1,0,0), (644,'institute2_address','Address',98,'43',13,1,1,0,0), (645,'institute2_certificate','Certificate Name',99,'43',13,1,1,0,0), (646,'institute2_study_area','Study Area',100,'43',13,1,1,0,0), (647,'section_sub_institute3','Other School',102,'44',13,1,1,0,0), (648,'institute3_institute','Institute',103,'44',13,1,1,0,0), (649,'institute3_country','Country',104,'44',13,1,1,0,0), (650,'institute3_state','State',105,'44',13,1,1,0,0), (651,'institute3_county','County',106,'44',13,1,1,0,0), (652,'institute3_city','City',107,'44',13,1,1,0,0), (653,'institute3_address','Address',108,'44',13,1,1,0,0), (654,'institute3_certificate','Certificate Name',109,'44',13,1,1,0,0), (655,'institute3_study_area','Study Area',110,'44',13,1,1,0,0), (656,'section_employer','Employer',112,'50',13,1,1,0,0), (657,'section_sub_employer','Recent Employer',113,'51',13,1,1,0,0), (658,'employer_employer','Employer',114,'51',13,1,1,0,0), (659,'employer_position','Position',114,'51',13,1,1,0,0), (660,'employer_resp','Responsibilities',115,'51',13,1,1,0,0), (661,'employer_pay_upon_leaving','Pay Upon Leaving',116,'51',13,1,1,0,0), (662,'employer_supervisor','Supervisor',117,'51',13,1,1,0,0), (663,'employer_from_date','From Date',118,'51',13,1,1,0,0), (664,'employer_to_date','To Date',119,'51',13,1,1,0,0), (665,'employer_leave_reason','Leave Reason',120,'51',13,1,1,0,0), (666,'employer_country','Country',121,'51',13,1,1,0,0), (667,'employer_state','State',122,'51',13,1,1,0,0), (668,'employer_county','County',123,'51',13,1,1,0,0), (669,'employer_city','City',124,'51',13,1,1,0,0), (670,'employer_zip','Zip Code',125,'51',13,1,1,0,0), (671,'employer_phone','Phone',126,'51',13,1,1,0,0), (672,'employer_address','Address',127,'51',13,1,1,0,0), (673,'section_sub_employer1','Prior Employer 1',128,'52',13,1,1,0,0), (674,'employer1_employer','Employer',129,'52',13,1,1,0,0), (675,'employer1_position','Position',130,'52',13,1,1,0,0), (676,'employer1_resp','Responsibilities',131,'52',13,1,1,0,0), (677,'employer1_pay_upon_leaving','Pay Upon Leaving',132,'52',13,1,1,0,0), (678,'employer1_supervisor','Supervisor',133,'52',13,1,1,0,0), (679,'employer1_from_date','From Date',134,'52',13,1,1,0,0), (680,'employer1_to_date','To Date',135,'52',13,1,1,0,0), (681,'employer1_leave_reason','Leave Reason',136,'52',13,1,1,0,0), (682,'employer1_country','Country',137,'52',13,1,1,0,0), (683,'employer1_state','State',138,'52',13,1,1,0,0), (684,'employer1_county','County',139,'52',13,1,1,0,0), (685,'employer1_city','City',140,'52',13,1,1,0,0), (686,'employer1_zip','Zip Code',141,'52',13,1,1,0,0), (687,'employer1_phone','Phone',142,'52',13,1,1,0,0), (688,'employer1_address','Address',143,'52',13,1,1,0,0);
INSERT INTO `#__js_job_fieldsordering` (`id`, `field`, `fieldtitle`, `ordering`, `section`, `fieldfor`, `published`, `sys`, `cannotunpublish`, `required`) VALUES (689,'section_sub_employer2','Prior Employer 2',146,'53',13,1,1,0,0), (690,'employer2_employer','Employer',147,'53',13,1,1,0,0), (691,'employer2_position','Position',148,'53',13,1,1,0,0), (692,'employer2_resp','Responsibilities',149,'53',13,1,1,0,0), (693,'employer2_pay_upon_leaving','Pay Upon Leaving',150,'53',13,1,1,0,0), (694,'employer2_supervisor','Supervisor',151,'53',13,1,1,0,0), (695,'employer2_from_date','From Date',152,'53',13,1,1,0,0), (696,'employer2_to_date','To Date',153,'53',13,1,1,0,0), (697,'employer2_leave_reason','Leave Reason',154,'53',13,1,1,0,0), (698,'employer2_country','Country',155,'53',13,1,1,0,0), (699,'employer2_state','State',156,'53',13,1,1,0,0), (700,'employer2_county','County',157,'53',13,1,1,0,0), (701,'employer2_city','City',158,'53',13,1,1,0,0), (702,'employer2_zip','Zip Code',159,'53',13,1,1,0,0), (703,'employer2_phone','Phone',160,'53',13,1,1,0,0), (704,'employer2_address','Address',161,'53',13,1,1,0,0), (705,'section_sub_employer3','Prior Employer 3',166,'54',13,1,1,0,0), (706,'employer3_employer','Employer',167,'54',13,1,1,0,0), (707,'employer3_position','Position',168,'54',13,1,1,0,0), (708,'employer3_resp','Responsibilities',169,'54',13,1,1,0,0), (709,'employer3_pay_upon_leaving','Pay Upon Leaving',170,'54',13,1,1,0,0), (710,'employer3_supervisor','Supervisor',171,'54',13,1,1,0,0), (711,'employer3_from_date','From Date',172,'54',13,1,1,0,0), (712,'employer3_to_date','To Date',173,'54',13,1,1,0,0), (713,'employer3_leave_reason','Leave Reason',174,'54',13,1,1,0,0), (714,'employer3_country','Country',175,'54',13,1,1,0,0), (715,'employer3_state','State',176,'54',13,1,1,0,0), (716,'employer3_county','County',177,'54',13,1,1,0,0), (717,'employer3_city','City',178,'54',13,1,1,0,0), (718,'employer3_zip','Zip Code',179,'54',13,1,1,0,0), (719,'employer3_phone','Phone',180,'54',13,1,1,0,0), (720,'employer3_address','Address',181,'54',13,1,1,0,0), (721,'section_skills','Skills',186,'60',13,1,1,0,0), (722,'driving_license','Driving License',187,'60',13,1,1,0,0), (723,'license_no','License No',188,'60',13,1,1,0,0), (724,'license_country','License Country',189,'60',13,1,1,0,0), (725,'skills','Skills',190,'60',13,1,1,0,0), (726,'section_resumeeditor','Resume Editor',196,'70',13,1,1,0,0), (727,'editor','Editor',197,'70',13,1,1,0,0), (728,'section_references','References',206,'80',13,1,1,0,0), (729,'section_sub_reference','Reference 1',207,'81',13,1,1,0,0), (730,'reference_reference','Reference',208,'81',13,1,1,0,0), (731,'reference_name','Name',209,'81',13,1,1,0,0), (732,'reference_country','Country',210,'81',13,1,1,0,0), (733,'reference_state','State',211,'81',13,1,1,0,0), (734,'reference_county','County',212,'81',13,1,1,0,0), (735,'reference_city','City',213,'81',13,1,1,0,0), (736,'reference_zipcode','Zip Code',214,'81',13,1,1,0,0), (737,'reference_phone','Phone',215,'81',13,1,1,0,0), (738,'reference_relation','Relation',216,'81',13,1,1,0,0), (739,'reference_years','Years',217,'81',13,1,1,0,0);
INSERT INTO `#__js_job_fieldsordering` (`id`, `field`, `fieldtitle`, `ordering`, `section`, `fieldfor`, `published`, `sys`, `cannotunpublish`, `required`) VALUES (740,'section_sub_reference1','Reference 2',221,'82',13,1,1,0,0), (741,'reference1_reference','Reference',222,'82',13,1,1,0,0), (742,'reference1_name','Name',223,'82',13,1,1,0,0), (743,'reference1_country','Country',224,'82',13,1,1,0,0), (744,'reference1_state','State',225,'82',13,1,1,0,0), (745,'reference1_county','County',226,'82',13,1,1,0,0), (746,'reference1_city','City',227,'82',13,1,1,0,0), (747,'reference1_zipcode','Zip Code',228,'82',13,1,1,0,0), (748,'reference1_phone','Phone',229,'82',13,1,1,0,0), (749,'reference1_relation','Relation',230,'82',13,1,1,0,0), (750,'reference1_years','Years',231,'82',13,1,1,0,0), (751,'section_sub_reference2','Reference 3',232,'83',13,1,1,0,0), (752,'reference2_reference','Reference',233,'83',13,1,1,0,0), (753,'reference2_name','Name',234,'83',13,1,1,0,0), (754,'reference2_country','Country',235,'83',13,1,1,0,0), (755,'reference2_state','State',236,'83',13,1,1,0,0), (756,'reference2_county','County',237,'83',13,1,1,0,0), (757,'reference2_city','City',238,'83',13,1,1,0,0), (758,'reference2_zipcode','Zip Code',239,'83',13,1,1,0,0), (759,'reference2_phone','Phone',240,'83',13,1,1,0,0), (760,'reference2_relation','Relation',241,'83',13,1,1,0,0), (761,'reference2_years','Years',242,'83',13,1,1,0,0), (762,'section_sub_reference3','Reference 4',243,'84',13,1,1,0,0), (763,'reference3_reference','Reference',244,'84',13,1,1,0,0), (764,'reference3_name','Name',245,'84',13,1,1,0,0), (765,'reference3_country','Country',246,'84',13,1,1,0,0), (766,'reference3_state','State',247,'84',13,1,1,0,0), (767,'reference3_county','County',248,'84',13,1,1,0,0), (768,'reference3_city','City',249,'84',13,1,1,0,0), (769,'reference3_zipcode','Zip Code',250,'84',13,1,1,0,0), (770,'reference3_phone','Phone',251,'84',13,1,1,0,0), (771,'reference3_relation','Relation',252,'84',13,1,1,0,0), (772,'reference3_years','Years',253,'84',13,1,1,0,0);
	
INSERT INTO  `#__js_job_fieldsordering` (`id`, `field`, `fieldtitle`, `ordering`, `section`, `fieldfor`, `published`, `sys`, `cannotunpublish`, `required`) VALUES (773,'Iamavailable','I am Available',11,'10',13,1,1,0,0), (774,'searchable','Searchable',12,'10',13,1,1,0,0), (775,'section_userfields','Visitor User Fields',22,'1000',13,0,0,0,1), (776,'userfield1','User Field 1',23,'1000',13,0,0,0,0), (777,'userfield2','User Field 2',24,'1000',13,0,0,0,0), (778,'userfield3','User Field 3',25,'1000',13,0,0,0,0), (779,'userfield4','User Field 4',26,'1000',13,0,0,0,0), (780,'userfield5','User Field 5',27,'1000',13,0,0,0,0), (781,'userfield6','User Field 6',28,'1000',13,0,0,0,0), (782,'userfield7','User Field 7',29,'1000',13,0,0,0,0), (783,'userfield8','User Field 8',30,'1000',13,0,0,0,0), (784,'userfield9','User Field 9',31,'1000',13,0,0,0,0), (785,'userfield10','User Field 10',32,'1000',13,0,0,0,0), (786,'date_of_birth','Date of Birth',14,'10',3,1,0,0,0), (787,'date_of_birth','Date of Birth',14,'10',13,1,0,0,0), (788,'video','Youtube Video Id',22,'20',3,1,1,0,0), (789,'video','Youtube Video Id',22,'20',13,1,1,0,0), (790,'address_location','Longitude And Latitude',50,'31',3,1,1,0,0), (791,'address_location','Longitude And Latitude',50,'31',13,1,1,0,0);

CREATE TABLE IF NOT EXISTS
`#__js_job_filters` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) NOT NULL,
  `country_istext` tinyint(1) default NULL,
  `country` varchar(50) default NULL,
  `state_istext` tinyint(1) default NULL,
  `state` varchar(50) default NULL,
  `county_istext` tinyint(1) default NULL,
  `county` varchar(50) default NULL,
  `city_istext` tinyint(1) default NULL,
  `city` varchar(50) default NULL,
  `zipcode` varchar(20) default NULL,
  `category` int(11) default NULL,
  `jobtype` int(11) default NULL,
  `jobstatus` int(11) default NULL,
  `heighesteducation` int(11) default NULL,
  `salaryrange` int(11) default NULL,
  `created` datetime default NULL,
  `status` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)

) ;

CREATE TABLE IF NOT EXISTS
`#__js_job_heighesteducation` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(100) NOT NULL default '',
  `isactive` tinyint(1) default 1,
  PRIMARY KEY  (`id`)
) ;
INSERT INTO `#__js_job_heighesteducation` VALUES (1,'University','1'), (2,'College','1'), (3,'High School','1'), (4,'No School','1');

CREATE TABLE IF NOT EXISTS
`#__js_job_resumesearches` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) default NULL,
  `searchname` varchar(50) NOT NULL,
  `application_title` varchar(255) default NULL,
  `nationality` varchar(50) default NULL,
  `gender` tinyint(2) default NULL,
  `iamavailable` tinyint(1) default '0',
  `category` int(11) default NULL,
  `jobtype` int(11) default NULL,
  `salaryrange` int(11) default NULL,
  `education` int(11) default NULL,
  `experience` varchar(30) default NULL,
  `created` datetime default NULL,
  `status` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ;

CREATE TABLE IF NOT EXISTS
`#__js_job_roles` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(50) default NULL,
  `rolefor` tinyint(4) default NULL,
  `companies` int(11) default NULL,
  `jobs` int(11) default NULL,
  `resumes` int(11) default NULL,
  `coverletters` int(11) default NULL,
  `searchjob` int(11) default NULL,
  `searchresume` int(11) default NULL,
  `savesearchresume` int(11) default NULL,
  `savesearchjob` int(11) default NULL,
  `published` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ;
INSERT INTO `#__js_job_roles` VALUES (1,'Employer',1,-1,-1,-1,-1,-1,-1,-1,-1,1), (2,'Job Seeker',2,-1,-1,-1,-1,-1,-1,-1,-1,1);

CREATE TABLE IF NOT EXISTS
`#__js_job_userfields` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL default '',
  `title` varchar(255) NOT NULL,
  `description` mediumtext,
  `type` varchar(50) NOT NULL default '',
  `maxlength` int(11) default NULL,
  `size` int(11) default NULL,
  `required` tinyint(4) default '0',
  `ordering` int(11) default NULL,
  `cols` int(11) default NULL,
  `rows` int(11) default NULL,
  `value` varchar(50) default NULL,
  `default` int(11) default NULL,
  `published` tinyint(1) NOT NULL default '1',
  `fieldfor` tinyint(2) NOT NULL default '0',
  `readonly` tinyint(1) NOT NULL default '0',
  `calculated` tinyint(1) NOT NULL default '0',
  `sys` tinyint(4) NOT NULL default '0',
  `params` mediumtext,
  PRIMARY KEY  (`id`)

) ;

CREATE TABLE IF NOT EXISTS
`#__js_job_userfieldvalues` (
  `id` int(11) NOT NULL auto_increment,
  `field` int(11) NOT NULL default '0',
  `fieldtitle` varchar(255) NOT NULL default '',
  `fieldvalue` varchar(255) NOT NULL,
  `ordering` int(11) NOT NULL default '0',
  `sys` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ;

CREATE TABLE IF NOT EXISTS
`#__js_job_userfield_data` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `referenceid` int(11) NOT NULL,
  `field` int(10) unsigned default NULL,
  `data` varchar(1000) default NULL,
  PRIMARY KEY  (`id`)
) ;
	
CREATE TABLE IF NOT EXISTS
`#__js_job_userroles` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) NOT NULL,
  `role` int(11) NOT NULL,
  `dated` datetime default NULL,
  PRIMARY KEY  (`id`)
) ;
	
CREATE TABLE IF NOT EXISTS`#__js_job_countries` (
  `id` int(11) NOT NULL auto_increment,
  `loc` char(2) default NULL,
  `code` char(2) default NULL,
  `name` varchar(100) default NULL,
  `enabled` char(1) default 'Y',
  PRIMARY KEY  (`id`),
  KEY `name` (`name`),
  KEY `code` (`code`)
) ;
INSERT INTO `#__js_job_countries` VALUES (3,'AF','BF','Burkina Faso','Y'), (5,'AF','CM','Cameroon','Y'), (6,'AF','CV','Cape Verde','Y'), (7,'AF','CF','Central African Republic','Y'), (8,'AF','TD','Chad','Y'), (9,'AF','KM','Comoros','Y'), (10,'AF','CG','Congo','Y'), (12,'AF','BJ','Benin','Y'), (14,'AF','BI','Burundi','Y'), (21,'AF','CI','Cote D\Ivorie','Y'), (22,'AF','DJ','Djibouti','Y'), (23,'AF','GQ','Equatorial Guinea','Y'), (24,'AF','ER','Eritrea','Y'), (25,'AF','ET','Ethiopia','Y'), (26,'AF','EG','Egypt','Y'), (27,'AF','GA','Gabon','Y'), (28,'AF','GH','Ghana','Y'), (29,'AF','GN','Guinea','Y'), (30,'AF','GM','Gambia','Y'), (31,'AF','GW','Guinea-Bissau','Y'), (32,'AF','KE','Kenya','Y'), (33,'AF','LS','Lesotho','Y'), (34,'AF','LR','Liberia','Y'), (35,'AF','MG','Madagascar','Y'), (36,'AF','ML','Mali','Y'), (37,'AF','MR','Mauritania','Y'), (38,'AF','YT','Mayotte','Y'), (39,'AF','MA','Morocco','Y'), (40,'AF','MZ','Mozambique','Y'), (41,'AF','MW','Malawi','Y'), (42,'AF','NA','Namibia','Y'), (43,'AF','NE','Niger','Y'), (44,'AF','NG','Nigeria','Y'), (45,'AF','RE','Reunion','Y'), (46,'AF','SH','St. Helena','Y'), (47,'AF','ST','Sao Tome and Principe','Y'), (48,'AF','SN','Senegal','Y'), (49,'AF','SL','Sierra Leone','Y'), (50,'AF','SO','Somalia','Y'), (51,'AF','ZA','South Africa','Y'), (52,'AF','SD','Sudan','Y'), (53,'AF','SZ','Swaziland','Y'), (54,'AF','TZ','Tanzania','Y'), (55,'AF','TG','Togo','Y'), (56,'AF','UG','Uganda','Y'), (57,'AF','EH','Western Sahara','Y'), (58,'AF','ZR','Zaire','Y'), (59,'AF','ZM','Zambia','Y'), (60,'AF','ZW','Zimbabwe','Y'), (62,'AS','AF','Afghanistan','Y'), (63,'AS','BD','Bangladesh','Y'), (64,'AS','BT','Bhutan','Y'), (65,'AS','BN','Brunei','Y'), (66,'AS','KH','Cambodia','Y'), (67,'AS','CN','China','Y'), (68,'AS','HK','Hong Kong','Y'), (69,'AS','IN','India','Y'), (70,'AS','ID','Indonesia','Y'), (71,'AS','JP','Japan','Y'), (72,'AS','KZ','Kazakhstan','Y'), (73,'AS','KG','Kyrgyzstan','Y'), (74,'AS','LA','Laos','Y'), (75,'AS','MO','Macau','Y'), (76,'AS','MY','Malaysia','Y'), (77,'AS','MV','Maldives','Y'), (78,'AS','MN','Mongolia','Y'), (79,'AS','NP','Nepal','Y'), (80,'AS','PK','Pakistan','Y'), (81,'AS','PH','Philippines','Y'), (82,'AS','KR','Republic of Korea','Y'), (83,'AS','RU','Russia','Y'), (84,'AS','SC','Seychelles','Y'), (85,'AS','SG','Singapore','Y'), (86,'AS','LK','Sri Lanka','Y'), (87,'AS','TW','Taiwan','Y'), (88,'AS','TJ','Tajikistan','Y'), (89,'AS','TH','Thailand','Y'), (90,'AS','TM','Turkmenistan','Y'), (91,'AS','UZ','Uzbekistan','Y'), (92,'AS','VN','Vietnam','Y'), (94,'AU','AU','Australia','Y'), (95,'AU','FM','Federated States of Micronesia','Y'), (96,'AU','FJ','Fiji','Y'), (97,'AU','PF','French Polynesia','Y'), (98,'AU','GU','Guam','Y'), (99,'AU','KI','Kiribati','Y'), (100,'AU','MH','Marshall Islands','Y'), (101,'AU','NR','Nauru','Y'), (102,'AU','NC','New Caledonia','Y'), (103,'AU','NZ','New Zealand','Y'), (104,'AU','MP','Northern Mariana Islands','Y'), (105,'AU','PW','Palau','Y'), (106,'AU','PG','Papua New Guinea','Y'), (107,'AU','PN','Pitcairn','Y'), (108,'AU','SB','Solomon Islands','Y'), (109,'AU','TO','Tonga','Y'), (110,'AU','TV','Tuvalu','Y'), (111,'AU','VU','Vanuatu','Y'), (112,'CA','AI','Anguilla','Y'), (114,'CA','AW','Aruba','Y'), (115,'CA','BS','Bahamas','Y'), (116,'CA','BB','Barbados','Y'), (117,'CA','BM','Bermuda','Y'), (118,'CA','VI','British Virgin Islands','Y'), (119,'CA','KY','Cayman Islands','Y'), (120,'CA','DM','Dominica','Y'), (121,'CA','DO','Dominican Republic','Y'), (122,'CA','GD','Grenada','Y'), (123,'CA','GP','Guadeloupe','Y'), (124,'CA','HT','Haiti','Y'), (125,'CA','JM','Jamaica','Y'), (126,'CA','MQ','Martinique','Y'), (127,'CA','AN','Neterlands Antilles','Y'), (128,'CA','PR','Puerto Rico','Y'), (129,'CA','KN','St. Kitts and Nevis','Y'), (130,'CA','LC','St. Lucia','Y'), (131,'CA','VC','St. Vincent and the Grenadines','Y'), (132,'CA','TT','Trinidad and Tobago','Y'), (133,'CA','TC','Turks and Caicos Islands','Y'), (134,'CE','BZ','Belize','Y'), (135,'CE','CR','Costa Rica','Y'), (136,'CE','SV','El Salvador','Y'), (137,'CE','GT','Guatemala','Y'), (138,'CE','HN','Honduras','Y'), (139,'CE','NI','Nicaragua','Y'), (140,'CE','PA','Panama','Y'), (143,'CE','AM','Armenia','Y'), (144,'CE','AT','Austria','Y'), (145,'CE','AZ','Azerbaijan','Y'), (146,'CE','BY','Belarus','Y'), (147,'CE','BE','Belgium','Y'), (148,'CE','BG','Bulgaria','Y'), (149,'CE','HR','Croatia','Y'), (150,'CE','CY','Cyprus','Y'), (151,'CE','CZ','Czech Republic','Y'), (152,'CE','DK','Denmark','Y'), (153,'CE','EE','Estonia','Y'), (154,'CE','FO','Faroe Islands','Y'), (155,'CE','FI','Finland','Y'), (156,'CE','FR','France','Y'), (157,'CE','GE','Georgia','Y'), (158,'CE','DE','Germany','Y'), (159,'CE','GI','Gibraltar','Y'), (160,'CE','GR','Greece','Y'), (161,'CE','GL','Greenland','Y'), (162,'CE','HU','Hungary','Y'), (163,'CE','IS','Iceland','Y'), (164,'CE','IE','Ireland','Y'), (165,'CE','IT','Italy','Y'), (166,'CE','LV','Latvia','Y'), (167,'CE','LI','Liechtenstein','Y'), (168,'CE','LT','Lithuania','Y'), (169,'CE','LU','Luxembourg','Y'), (170,'CE','MT','Malta','Y'), (171,'CE','FX','Metropolitan France','Y'), (172,'CE','MD','Moldova','Y'), (173,'CE','NL','Netherlands','Y'), (174,'CE','NO','Norway','Y'), (175,'CE','PL','Poland','Y'), (176,'CE','PT','Portugal','Y'), (177,'CE','RO','Romania','Y'), (178,'CE','SK','Slovakia','Y'), (179,'CE','SI','Slovenia','Y'), (180,'CE','ES','Spain','Y'), (181,'CE','SJ','Svalbard and Jan Mayen Islands','Y'), (182,'CE','SE','Sweden','Y'), (183,'CE','CH','Switzerland','Y'), (184,'CE','MK','Republic of Macedonia','Y'), (185,'CE','TR','Turkey','Y'), (186,'CE','UA','Ukraine','Y'), (187,'CE','GB','United Kingdom','Y'), (188,'CE','VA','Vatican City','Y'), (189,'CE','YU','Yugoslavia','Y'), (190,'ME','IL','Israel','Y'), (191,'ME','JO','Jordan','Y'), (192,'ME','KW','Kuwait','Y'), (193,'ME','LB','Lebanon','Y'), (194,'ME','OM','Oman','Y'), (195,'ME','QA','Qatar','Y'), (196,'ME','SA','Saudi Arabia','Y'), (197,'ME','SY','Syria','Y'), (198,'ME','AE','United Arab Emirates','Y'), (199,'ME','YE','Yemen','Y'), (200,'NA','CA','Canada','Y'), (201,'NA','MX','Mexico','Y'), (202,'NA','US','United States','Y'), (204,'SA','BO','Bolivia','Y'), (205,'SA','BR','Brazil','Y'), (206,'SA','CL','Chile','Y'), (207,'SA','CO','Colombia','Y'), (208,'SA','EC','Equador','Y'), (209,'SA','FK','Falkland Islands','Y'), (210,'SA','GF','French Guiana','Y'), (211,'SA','GY','Guyana','Y'), (212,'SA','PY','Paraguay','Y'), (213,'SA','PE','Peru','Y'), (214,'SA','SR','Suriname','Y'), (215,'SA','UY','Uruguay','Y'), (216,'SA','VE','Venezuela','Y'), (217,'OT','BH','Bahrain','Y'), (218,'OT','BV','Bouvet Islands','Y'), (219,'OT','IO','British Indian Ocean Territory','Y');


CREATE TABLE IF NOT EXISTS`#__js_job_states` (
  `id` int(11) NOT NULL auto_increment,
  `code` varchar(50) default NULL,
  `name` varchar(100) default NULL,
  `enabled` char(1) default 'Y',
  `countrycode` varchar(5) NOT NULL default 'US',
  PRIMARY KEY  (`id`),
  KEY `code` (`code`),
  KEY `enabled` (`enabled`),
  KEY `countrycode` (`countrycode`)
) ;
INSERT INTO `#__js_job_states` (`code`,`name`,`enabled`,`countrycode`) VALUES ('Capital','Capital','Y','PK'), ('Punjab','Punjab','Y','PK'), ('Sind','Sind','Y','PK'), ('NWFP','NWFP','Y','PK'), ('Balochstan','Balochistan','Y','PK'), ('AJK','Azad Jammu Kashmir','Y','PK');

CREATE TABLE IF NOT EXISTS`#__js_job_counties` (
  `id` int(11) NOT NULL auto_increment,
  `code` varchar(50) default NULL,
  `name` varchar(100) default NULL,
  `enabled` char(1) default 'Y',
  `countrycode` varchar(5) NOT NULL default 'PK',
  `statecode` varchar(50) default NULL,
  PRIMARY KEY  (`id`),
  KEY `code` (`code`),
  KEY `countrystate` (`countrycode`,`statecode`)
) ;
INSERT INTO `#__js_job_counties` (`code`,`name`,`enabled`,`countrycode`,`statecode`) VALUES ('Chitral','Chitral','Y','PK','NWFP'), ('UpperDir','Upper Dir','Y','PK','NWFP'), ('LowerDir','Lower Dir','Y','PK','NWFP'), ('Swat','Swat','Y','PK','NWFP'), ('Shangla','Shangla','Y','PK','NWFP'), ('Buner','Buner','Y','PK','NWFP'), ('Malakand','Malakand P.A.','Y','PK','NWFP'), ('Kohistan','Kohistan','Y','PK','NWFP'), ('Mansehra','Mansehra','Y','PK','NWFP'), ('Batagram','Batagram','Y','PK','NWFP'), ('Abbottabad','Abbottabad','Y','PK','NWFP'), ('Haripur','Haripur','Y','PK','NWFP'), ('Mardan','Mardan','Y','PK','NWFP'), ('Swabi','Swabi','Y','PK','NWFP'), ('Charsadda','Charsadda','Y','PK','NWFP'), ('Peshawar','Peshawar','Y','PK','NWFP'), ('Nowshera','Nowshera','Y','PK','NWFP'), ('Kohat','Kohat','Y','PK','NWFP'), ('Hangu','Hangu','Y','PK','NWFP'), ('Karak','Karak','Y','PK','NWFP'), ('Bannu','Bannu','Y','PK','NWFP'), ('DIKhan','Dera Ismail Khan','Y','PK','NWFP'), ('Tank','Tank','Y','PK','NWFP'), ('LakkiMarw','Lakki Marwat','Y','PK','NWFP'), ('Rawalpindi','Rawalpindi','Y','PK','Punjab'), ('Jhelum','Jhelum','Y','PK','Punjab'), ('Chakwal','Chakwal','Y','PK','Punjab'), ('Sargodha','Sargodha','Y','PK','Punjab'), ('Bhakkar','Bhakkar','Y','PK','Punjab'), ('Khushab','Khushab','Y','PK','Punjab'), ('Mianwali','Mianwali','Y','PK','Punjab'), ('Faisalabad','Faisalabad','Y','PK','Punjab'), ('Jhang','Jhang','Y','PK','Punjab'), ('TTSingh','Toba Tek Singh','Y','PK','Punjab'), ('Gujranwala','Gujranwala','Y','PK','Punjab'), ('Hafizabad','Hafizabad','Y','PK','Punjab'), ('Gujrat','Gujrat','Y','PK','Punjab'), ('MandiBaha','Mandi Bahauddin','Y','PK','Punjab'), ('Sialkot','Sialkot','Y','PK','Punjab'), ('Narowal','Narowal','Y','PK','Punjab'), ('Lahore','Lahore','Y','PK','Punjab'), ('Kasur','Kasur','Y','PK','Punjab'), ('Okara','Okara','Y','PK','Punjab'), ('Sheikhupur','Sheikhupura','Y','PK','Punjab'), ('Vehari','Vehari','Y','PK','Punjab'), ('Sahiwal','Sahiwal','Y','PK','Punjab'), ('Pakpattan','Pakpattan','Y','PK','Punjab'), ('Multan','Multan','Y','PK','Punjab'), ('Lodhran','Lodhran','Y','PK','Punjab'), ('Khanewal','Khanewal','Y','PK','Punjab'), ('DGKhan','Dera Ghazi Khan','Y','PK','Punjab'), ('Rajanpur','Rajanpur','Y','PK','Punjab'), ('Layyah','Layyah','Y','PK','Punjab'), ('Muzaffarga','Muzaffargarh','Y','PK','Punjab'), ('Bahawalpur','Bahawalpur','Y','PK','Punjab'), ('Bahawalnag','Bahawalnagar','Y','PK','Punjab'), ('RYKhan','Rahim Yar Khan','Y','PK','Punjab'), ('Attock','Attock','Y','PK','Punjab'), ('Islamabad','Islamabad','Y','PK','Capital'), ('Shikarpur','Shikarpur','Y','PK','Sind'), ('Larkana','Larkana','Y','PK','Sind'), ('Sukkur','Sukkur','Y','PK','Sind'), ('Ghotki','Ghotki','Y','PK','Sind'), ('Khairpur','Khairpur','Y','PK','Sind'), ('Naushahro','Naushahro Feroze','Y','PK','Sind'), ('NawabShah','Nawab Shah','Y','PK','Sind'), ('Dadu','Dadu','Y','PK','Sind'), ('Hyderabad','Hyderabad','Y','PK','Sind'), ('Badin','Badin','Y','PK','Sind'), ('Thatta','Thatta','Y','PK','Sind'), ('Sanghar','Sanghar','Y','PK','Sind'), ('MirpurKha','Mirpur Khas','Y','PK','Sind'), ('Umerkot','Umerkot','Y','PK','Sind'), ('Tharparkar','Tharparkar','Y','PK','Sind'), ('Karachi','Karachi','Y','PK','Sind'), ('Quetta','Quetta','Y','PK','Balochstan'), ('Pishin','Pishin','Y','PK','Balochstan'), ('KillaAbdu','Killa Abdullah','Y','PK','Balochstan'), ('Chagai','Chagai','Y','PK','Balochstan'), ('Loralai','Loralai','Y','PK','Balochstan'), ('Musakhel','Musakhel','Y','PK','Balochstan'), ('KillaSaif','Killa Saifullah','Y','PK','Balochstan'), ('Zhob','Zhob','Y','PK','Balochstan'), ('Sibi','Sibi','Y','PK','Balochstan'), ('Ziarat','Ziarat','Y','PK','Balochstan'), ('Kohlu','Kohlu','Y','PK','Balochstan'), ('DeraBugti','Dera Bugti','Y','PK','Balochstan'), ('Jaffarabad','Jaffarabad','Y','PK','Balochstan'), ('Nasirabad','Nasirabad','Y','PK','Balochstan'), ('Bolan','Bolan','Y','PK','Balochstan'), ('Kachhi','Kachhi','Y','PK','Balochstan'), ('Kalat','Kalat','Y','PK','Balochstan'), ('Mastung','Mastung','Y','PK','Balochstan'), ('Khuzdar','Khuzdar','Y','PK','Balochstan'), ('Awaran','Awaran','Y','PK','Balochstan'), ('Kharan','Kharan','Y','PK','Balochstan'), ('Lasbela','Lasbela','Y','PK','Balochstan'), ('Kech','Kech','Y','PK','Balochstan'), ('Gwadar','Gwadar','Y','PK','Balochstan'), ('Panjgur','Panjgur','Y','PK','Balochstan'), ('Bajaur','Bajaur','Y','PK','FATA'), ('Mohmand','Mohmand','Y','PK','FATA'), ('Khyber','Khyber','Y','PK','FATA'), ('Kurram','Kurram','Y','PK','FATA'), ('Orakzai','Orakzai','Y','PK','FATA'), ('SouthWazi','South Waziristan','Y','PK','FATA'), ('NorthWazi','North Waziristan','Y','PK','FATA');

CREATE TABLE IF NOT EXISTS`#__js_job_cities` (
  `id` int(8) NOT NULL auto_increment,
  `code` varchar(50) default NULL,
  `name` varchar(100) default NULL,
  `enabled` char(1) default 'Y',
  `countrycode` varchar(5) NOT NULL default 'US',
  `statecode` varchar(50) default NULL,
  `countycode` varchar(50) default NULL,
  PRIMARY KEY  (`id`),
  KEY `code` (`code`),
  KEY `countrystate` (`countrycode`,`statecode`),
  KEY `countrystatecounty` (`countrycode`,`statecode`,`countycode`)
) ;
INSERT INTO `#__js_job_cities` (`code`,`name`,`enabled`,`countrycode`,`statecode`,`countycode`) VALUES ('Chitral','Chitral','Y','PK','NWFP','Chitral'), ('Dir','Dir','Y','PK','NWFP','UpperDir'), ('Kohistan','Kohistan','Y','PK','NWFP','UpperDir'), ('Swat','Swat','Y','PK','NWFP','Swat'), ('Peshawar','Peshawar','Y','PK','NWFP','Peshawar'), ('Nowshera','Nowshera','Y','PK','NWFP','Nowshera'), ('Kohat','Kohat','Y','PK','NWFP','Kohat'), ('Hangu','Hangu','Y','PK','NWFP','Hangu'), ('Karak','Karak','Y','PK','NWFP','Karak'), ('Hassanabda','Hassanabdal','Y','PK','Punjab','Attock'), ('FatehJang','Fateh Jang','Y','PK','Punjab','Attock'), ('PindiGheb','Pindi Gheb','Y','PK','Punjab','Attock'), ('Rawalpindi','Rawalpindi','Y','PK','Punjab','Rawalpindi'), ('Taxila','Taxila','Y','PK','Punjab','Rawalpindi'), ('Kahuta','Kahuta','Y','PK','Punjab','Rawalpindi'), ('Murree','Murree','Y','PK','Punjab','Rawalpindi'), ('GujarKhan','Gujar Khan','Y','PK','Punjab','Rawalpindi'), ('Jhelum','Jhelum','Y','PK','Punjab','Jhelum'), ('Sohawa','Sohawa','Y','PK','Punjab','Jhelum'), ('PindDadan','Pind Dadan Khan','Y','PK','Punjab','Jhelum'), ('Dina','Dina','Y','PK','Punjab','Jhelum'), ('Chakwal','Chakwal','Y','PK','Punjab','Chakwal'), ('Talagang','Talagang','Y','PK','Punjab','Chakwal'), ('Sargodha','Sargodha','Y','PK','Punjab','Sargodha'), ('Bhalwal','Bhalwal','Y','PK','Punjab','Sargodha'), ('KotMomin','Kot Momin','Y','PK','Punjab','Sargodha'), ('Bhakkar','Bhakkar','Y','PK','Punjab','Bhakkar'), ('Khushab','Khushab','Y','PK','Punjab','Khushab'), ('Faisalabad','Faisalabad City','Y','PK','Punjab','Faisalabad'), ('Faisalabad','Faisalabad Saddar','Y','PK','Punjab','Faisalabad'), ('Sammundri','Sammundri','Y','PK','Punjab','Faisalabad'), ('Jaranwala','Jaranwala','Y','PK','Punjab','Faisalabad'), ('Tandlianwa','Tandlianwala','Y','PK','Punjab','Faisalabad'), ('Chiniot','Chiniot','Y','PK','Punjab','Jhang'), ('Jhang','Jhang','Y','PK','Punjab','Jhang'), ('TobaTekS','Toba Tek Singh','Y','PK','Punjab','TTSingh'), ('Gojra','Gojra','Y','PK','Punjab','TTSingh'), ('Wazirabad','Wazirabad','Y','PK','Punjab','Gujranwala'), ('Gujranwalacity','Gujranwala City','Y','PK','Punjab','Gujranwala'), ('Gujranwalasaddar','Gujranwala Saddar','Y','PK','Punjab','Gujranwala'), ('NowsheraVirkan','Nowshera Virkan','Y','PK','Punjab','Gujranwala'), ('Kamoki','Kamoki','Y','PK','Punjab','Gujranwala'), ('Hafizabad','Hafizabad','Y','PK','Punjab','Hafizabad'), ('Gujrat','Gujrat','Y','PK','Punjab','Gujrat'), ('Kharian','Kharian','Y','PK','Punjab','Gujrat'), ('MandiBaha','Mandi Bahauddin','Y','PK','Punjab','MandiBaha'), ('Sialkot','Sialkot','Y','PK','Punjab','Sialkot'), ('Narowal','Narowal','Y','PK','Punjab','Narowal');
INSERT INTO `#__js_job_cities` (`code`,`name`,`enabled`,`countrycode`,`statecode`,`countycode`) VALUES ('LahoreCity','Lahore City','Y','PK','Punjab','Lahore'), ('Lahore Cantt','Lahore Cantt.','Y','PK','Punjab','Lahore'), ('Kasur','Kasur','Y','PK','Punjab','Kasur'), ('Okara','Okara','Y','PK','Punjab','Okara'), ('NankanaSa','Nankana Sahib','Y','PK','Punjab','Sheikhupur'), ('Sheikhupur','Sheikhupura','Y','PK','Punjab','Sheikhupur'), ('Vehari','Vehari','Y','PK','Punjab','Vehari'), ('Burewala','Burewala','Y','PK','Punjab','Vehari'), ('Sahiwal','Sahiwal','Y','PK','Punjab','Sahiwal'), ('MultanCit','Multan City','Y','PK','Punjab','Multan'), ('MultanSad','Multan Saddar','Y','PK','Punjab','Multan'), ('DGKhan','Dera Ghazi Khan','Y','PK','Punjab','DGKhan'), ('Taunsa','Taunsa','Y','PK','Punjab','DGKhan'), ('Rajanpur','Rajanpur','Y','PK','Punjab','Rajanpur'), ('Muzaffarga','Muzaffargarh','Y','PK','Punjab','Muzaffarga'), ('Bahawalpur','Bahawalpur','Y','PK','Punjab','Hasilpur'), ('Bahawalnag','Bahawalnagar','Y','PK','Punjab','Bahawalnag'), ('Liaquatpur','Liaquatpur','Y','PK','Punjab','RYKhan'), ('Sadiqabad','Sadiqabad','Y','PK','Punjab','RYKhan'), ('Attock','Attock','Y','PK','Punjab','Attock'), ('Islamabad','Islamabad City','Y','PK','Capital','Islamabad'), ('Jacobabad','Jacobabad','Y','PK','Sind','Jacobabad'), ('Thul','Thul','Y','PK','Sind','Jacobabad'), ('Kashmor','Kashmor','Y','PK','Sind','Jacobabad'), ('Shikarpur','Shikarpur','Y','PK','Sind','Shikarpur'), ('Shahdadkot','Shahdadkot','Y','PK','Sind','Larkana'), ('Larkana','Larkana','Y','PK','Sind','Larkana'), ('Sukkur','Sukkur','Y','PK','Sind','Sukkur'), ('Ghotki','Ghotki','Y','PK','Sind','Ghotki'), ('Khairpur','Khairpur','Y','PK','Sind','Khairpur'), ('Naushahro','Naushahro Feroze','Y','PK','Sind','Naushahro'), ('NawabShah','Nawab Shah','Y','PK','Sind','NawabShah'), ('Dadu','Dadu','Y','PK','Sind','Dadu'), ('Johi','Johi','Y','PK','Sind','Dadu'), ('TandoAlla','Tando Allahyar','Y','PK','Sind','Hyderabad'), ('Hyderabad','Hyderabad City','Y','PK','Sind','Hyderabad'), ('Latifabad','Latifabad','Y','PK','Sind','Hyderabad'), ('Hyderabad','Hyderabad','Y','PK','Sind','Hyderabad'), ('Qasimabad','Qasimabad','Y','PK','Sind','Hyderabad'), ('TandoMoha','Tando Mohammad Khan','Y','PK','Sind','Hyderabad'), ('Golarchi','Golarchi','Y','PK','Sind','Badin'), ('Badin','Badin','Y','PK','Sind','Badin'), ('Thatta','Thatta','Y','PK','Sind','Thatta'), ('TandoAdam','Tando Adam','Y','PK','Sind','Sanghar'), ('MirpurKha','Mirpur Khas','Y','PK','Sind','MirpurKha'), ('EntireEa','Entire  East','Y','PK','Sind','Karachi'), ('KarachiWest','Karachi West','Y','PK','Sind','Karachi'), ('KarachiSouth','Karachi South','Y','PK','Sind','Karachi'), ('EntireUrban','Entire Urban','Y','PK','Sind','Karachi'), ('KarachiCental','Karachi Central','Y','PK','Sind','Karachi'), ('Mali','Mali','Y','PK','Sind','Karachi'), ('Quetta','Quetta','Y','PK','Balochstan','Quetta'), ('Panjpai','Panjpai','Y','PK','Balochstan','Quetta'), ('Pishin','Pishin','Y','PK','Balochstan','Pishin'), ('KillaAbdu','Killa Abdullah','Y','PK','Balochstan','KillaAbdu'), ('Nushki','Nushki','Y','PK','Balochstan','Chagai'), ('Dalbandin','Dalbandin','Y','PK','Balochstan','Chagai'), ('Chagai','Chagai','Y','PK','Balochstan','Chagai'), ('Nokundi','Nokundi','Y','PK','Balochstan','Chagai'), ('Dak','Dak','Y','PK','Balochstan','Chagai'), ('Taftan','Taftan','Y','PK','Balochstan','Chagai'), ('LoralaiBo','Loralai/Bori','Y','PK','Balochstan','Loralai'), ('Barkhan','Barkhan','Y','PK','Balochstan','Barkhan'), ('Musakhel','Musakhel','Y','PK','Balochstan','Musakhel'), ('KillaSaif','Killa Saifullah','Y','PK','Balochstan','KillaSaif'), ('Zhob','Zhob','Y','PK','Balochstan','Zhob'), ('Sibi','Sibi','Y','PK','Balochstan','Sibi'), ('Ziarat','Ziarat','Y','PK','Balochstan','Ziarat'), ('Kohlu','Kohlu','Y','PK','Balochstan','Kohlu'), ('DeraBugti','Dera Bugti','Y','PK','Balochstan','DeraBugti'), ('Sui','Sui','Y','PK','Balochstan','DeraBugti'), ('Bhag','Bhag','Y','PK','Balochstan','Bolan'), ('Balanari','Balanari','Y','PK','Balochstan','Bolan'), ('Sani','Sani','Y','PK','Balochstan','Bolan'), ('Mirpur','Mirpur','Y','PK','Balochstan','Kachhi'), ('Kalat','Kalat','Y','PK','Balochstan','Kalat'), ('Mangochar','Mangochar','Y','PK','Balochstan','Kalat'), ('Johan','Johan','Y','PK','Balochstan','Kalat'), ('Dasht','Dasht','Y','PK','Balochstan','Mastung'), ('JhalJao','Jhal Jao','Y','PK','Balochstan','Awaran'), ('Kharan','Kharan','Y','PK','Balochstan','Kharan'), ('Besima','Besima','Y','PK','Balochstan','Kharan'), ('Hub','Hub','Y','PK','Balochstan','Lasbela'), ('Kech','Kech','Y','PK','Balochstan','Kech'), ('Hoshab','Hoshab','Y','PK','Balochstan','Kech'), ('Gwadar','Gwadar','Y','PK','Balochstan','Gwadar'), ('Pasni','Pasni','Y','PK','Balochstan','Gwadar'), ('Gichk','Gichk','Y','PK','Balochstan','Panjgur'), ('Bara','Bara','Y','PK','FATA','Khyber'), ('Jamrud','Jamrud','Y','PK','FATA','Khyber'), ('LandiKota','Landi Kotal','Y','PK','FATA','Khyber'), ('Ladha','Ladha','Y','PK','FATA','SouthWazi'), ('Sararogha','Sararogha','Y','PK','FATA','SouthWazi'), ('Wana','Wana','Y','PK','FATA','SouthWazi'), ('DattaKhel','Datta Khel','Y','PK','FATA','NorthWazi'), ('Dossali','Dossali','Y','PK','FATA','NorthWazi'), ('Garyum','Garyum','Y','PK','FATA','NorthWazi'), ('GhulamKha','Ghulam Khan','Y','PK','FATA','NorthWazi'), ('MirAli','Mir Ali','Y','PK','FATA','NorthWazi'), ('MiranShah','Miran Shah','Y','PK','FATA','NorthWazi'), ('Razmak','Razmak','Y','PK','FATA','NorthWazi'), ('Spinwam','Spinwam','Y','PK','FATA','NorthWazi'), ('Shewa','Shewa','Y','PK','FATA','NorthWazi');

CREATE TABLE IF NOT EXISTS`#__js_job_zips` (
  `id` int(8) NOT NULL auto_increment,
  `code` varchar(30) default NULL,
  `enabled` char(1) default 'Y',
  `countrycode` varchar(5) NOT NULL default 'US',
  `statecode` varchar(50) default NULL,
  `countycode` varchar(50) default NULL,
  `citycode` varchar(50) default NULL,
  `latitude` float default NULL,
  `longitude` float default NULL,
  PRIMARY KEY  (`id`),
  KEY `code` (`code`),
  KEY `countrystatecountycity` (`countrycode`,`statecode`,`countycode`,`citycode`)
) ; 


CREATE TABLE IF NOT EXISTS
	`#__js_job_resume`
		(
		  `id` int(11) NOT NULL auto_increment,

		  `uid` int(11) default NULL,

		  `create_date` datetime NOT NULL default '0000-00-00 00:00:00',

		  `modified_date` datetime default NULL,

		  `published` tinyint(1) default 1,

		  `hits` int(11) default NULL,

		  `application_title`  varchar(150) NOT NULL,

		  `first_name`  varchar(150) NOT NULL,

		  `last_name`  varchar(150) NOT NULL,

		  `middle_name`  varchar(150),

		  `gender` varchar(10) default NULL,

		  `email_address`  varchar(200),

		  `home_phone` varchar(60) NOT NULL,

		  `work_phone` varchar(60) default NULL,

		  `cell` varchar(60) default NULL,

		  `nationality` varchar(50) default NULL,

		  `iamavailable` tinyint(1) default NULL,

		  `searchable` tinyint(1) default '1',

		  `photo` varchar(150) default NULL,

		  `job_category` int(11) default NULL,

		  `jobsalaryrange` int(11) default NULL,

		  `jobtype` int(11) default NULL,

		  `heighestfinisheducation` varchar(60) default NULL,

		  `address_country` varchar(100) default NULL,

		  `address_state` varchar(60) default NULL,

		  `address_county` varchar(100) default NULL,

		  `address_city` varchar(100) default NULL,

		  `address_zipcode` varchar(60) default NULL,

		  `address` text,

		  `institute` varchar(100) default NULL,

		  `institute_country` varchar(100) default NULL,

		  `institute_state` varchar(100) default NULL,

		  `institute_county` varchar(100) default NULL,

		  `institute_city` varchar(100) default NULL,

		  `institute_address` varchar(150) default NULL,

		  `institute_certificate_name` varchar(100) default NULL,

		  `institute_study_area` text,

		  `employer` varchar(250) default NULL,

		  `employer_position` varchar(150) default NULL,

		  `employer_resp` text,

		  `employer_pay_upon_leaving` varchar(250) default NULL,

		  `employer_supervisor` varchar(100) default NULL,

		  `employer_from_date` varchar(60) default NULL,

		  `employer_to_date` varchar(60) default NULL,

		  `employer_leave_reason` text,

		  `employer_country` varchar(100) default NULL,

		  `employer_state` varchar(100) default NULL,

		  `employer_county` varchar(100) default NULL,

		  `employer_city` varchar(100) default NULL,

		  `employer_zip` varchar(60) default NULL,

		  `employer_phone` varchar(60) default NULL,

		  `employer_address` varchar(150) default NULL,

		  `filename` varchar(50) default NULL,

		  `filetype` varchar(50) default NULL,

		  `filesize` int(11) default NULL,

		  `filecontent` mediumblob,

		  `field1` text,

		  `field2` text,

		  `field3` text,

		  `status` int(11) NOT NULL default '1',

		  `resume` text,

		  `institute1` varchar(100) default NULL,

		  `institute1_country` varchar(100) default NULL,

		  `institute1_state` varchar(100) default NULL,

		  `institute1_county` varchar(100) default NULL,

		  `institute1_city` varchar(100) default NULL,

		  `institute1_address` varchar(150) default NULL,

		  `institute1_study_area` text,

		  `institute1_certificate_name` varchar(100) default NULL,

		  `institute2` varchar(100) default NULL,

		  `institute2_country` varchar(100) default NULL,

		  `institute2_state` varchar(100) default NULL,

		  `institute2_county` varchar(100) default NULL,

		  `institute2_city` varchar(100) default NULL,

		  `institute2_address` varchar(150) default NULL,

		  `institute2_certificate_name` varchar(100) default NULL,

		  `institute2_study_area` text,

		  `institute3` varchar(100) default NULL,

		  `institute3_country` varchar(100) default NULL,

		  `institute3_state` varchar(100) default NULL,

		  `institute3_county` varchar(100) default NULL,

		  `institute3_city` varchar(100) default NULL,

		  `institute3_address` varchar(150) default NULL,

		  `institute3_study_area` text,

		  `institute3_certificate_name` varchar(100) default NULL,

		  `employer1` varchar(250) default NULL,

		  `employer1_position` varchar(150) default NULL,

		  `employer1_resp` text,

		  `employer1_pay_upon_leaving` varchar(250) default NULL,

		  `employer1_supervisor` varchar(100) default NULL,

		  `employer1_from_date` varchar(60) default NULL,

		  `employer1_to_date` varchar(60) default NULL,

		  `employer1_leave_reason` text,

		  `employer1_country` varchar(100) default NULL,

		  `employer1_state` varchar(100) default NULL,

		  `employer1_county` varchar(100) default NULL,

		  `employer1_city` varchar(100) default NULL,

		  `employer1_zip` varchar(60) default NULL,

		  `employer1_phone` varchar(60) default NULL,

		  `employer1_address` varchar(150) default NULL,

		  `employer2` varchar(250) default NULL,

		  `employer2_position` varchar(150) default NULL,

		  `employer2_resp` text,

		  `employer2_pay_upon_leaving` varchar(250) default NULL,

		  `employer2_supervisor` varchar(100) default NULL,

		  `employer2_from_date` varchar(60) default NULL,

		  `employer2_to_date` varchar(60) default NULL,

		  `employer2_leave_reason` text,

		  `employer2_country` varchar(100) default NULL,

		  `employer2_state` varchar(100) default NULL,

		  `employer2_county` varchar(100) default NULL,

		  `employer2_city` varchar(100) default NULL,

		  `employer2_zip` varchar(60) default NULL,

		  `employer2_address` varchar(150) default NULL,

		  `employer2_phone` varchar(60) default NULL,

		  `employer3` varchar(250) default NULL,

		  `employer3_position` varchar(150) default NULL,

		  `employer3_resp` text,

		  `employer3_pay_upon_leaving` varchar(250) default NULL,

		  `employer3_supervisor` varchar(100) default NULL,

		  `employer3_from_date` varchar(60) default NULL,

		  `employer3_to_date` varchar(60) default NULL,

		  `employer3_leave_reason` text,

		  `employer3_country` varchar(100) default NULL,

		  `employer3_state` varchar(100) default NULL,

		  `employer3_county` varchar(100) default NULL,

		  `employer3_city` varchar(100) default NULL,

		  `employer3_zip` varchar(60) default NULL,

		  `employer3_address` varchar(150) default NULL,

		  `employer3_phone` varchar(60) default NULL,

		  `language` varchar(50) default NULL,

		  `langugage_reading` varchar(20) default NULL,

		  `langugage_writing` varchar(20) default NULL,

		  `langugage_undarstanding` varchar(20) default NULL,

		  `langugage_where_learned` varchar(100) default NULL,

		  `language1` varchar(50) default NULL,

		  `langugage1_reading` varchar(20) default NULL,

		  `langugage1_writing` varchar(20) default NULL,

		  `langugage1_undarstanding` varchar(20) default NULL,

		  `langugage1_where_learned` varchar(100) default NULL,

		  `language2` varchar(50) default NULL,

		  `langugage2_reading` varchar(20) default NULL,

		  `langugage2_writing` varchar(20) default NULL,

		  `langugage2_undarstanding` varchar(20) default NULL,

		  `langugage2_where_learned` varchar(100) default NULL,

		  `language3` varchar(50) default NULL,

		  `langugage3_reading` varchar(20) default NULL,

		  `langugage3_writing` varchar(20) default NULL,

		  `langugage3_undarstanding` varchar(20) default NULL,

		  `langugage3_where_learned` varchar(100) default NULL,

		  `date_start` datetime default NULL,

		  `desired_salary` int(11) default NULL,

		  `can_work` varchar(250) default NULL,

		  `available` varchar(250) default NULL,

		  `unalailable` varchar(250) default NULL,

		  `total_experience` varchar(50) default NULL,

		  `skills` text,

		  `driving_license` tinyint(1) default NULL,

		  `license_no` varchar(100) default NULL,

		  `license_country` varchar(50) default NULL,

		  `reference` varchar(50) default NULL,

		  `reference_name` varchar(50) default NULL,

		  `reference_country` varchar(50) default NULL,

		  `reference_state` varchar(50) default NULL,

		  `reference_county` varchar(50) default NULL,

		  `reference_city` varchar(50) default NULL,

		  `reference_zipcode` varchar(20) default NULL,

		  `reference_address` varchar(150) default NULL,

		  `reference_phone` varchar(50) default NULL,

		  `reference_relation` varchar(50) default NULL,

		  `reference_years` varchar(10) default NULL,

		  `reference1` varchar(50) default NULL,

		  `reference1_name` varchar(50) default NULL,

		  `reference1_country` varchar(50) default NULL,

		  `reference1_state` varchar(50) default NULL,

		  `reference1_county` varchar(50) default NULL,

		  `reference1_city` varchar(50) default NULL,

		  `reference1_address` varchar(150) default NULL,

		  `reference1_phone` varchar(50) default NULL,

		  `reference1_relation` varchar(50) default NULL,

		  `reference1_years` varchar(10) default NULL,

		  `reference2` varchar(50) default NULL,

		  `reference2_name` varchar(50) default NULL,

		  `reference2_country` varchar(50) default NULL,

		  `reference2_state` varchar(50) default NULL,

		  `reference2_county` varchar(50) default NULL,

		  `reference2_city` varchar(50) default NULL,

		  `reference2_address` varchar(150) default NULL,

		  `reference2_phone` varchar(50) default NULL,

		  `reference2_relation` varchar(50) default NULL,

		  `reference2_years` varchar(10) default NULL,

		  `reference3` varchar(50) default NULL,

		  `reference3_name` varchar(50) default NULL,

		  `reference3_country` varchar(50) default NULL,

		  `reference3_state` varchar(50) default NULL,

		  `reference3_county` varchar(50) default NULL,
		  `reference3_city` varchar(50) default NULL,
		  `reference3_address` varchar(150) default NULL,
		  `reference3_phone` varchar(50) default NULL,

		  `reference3_relation` varchar(50) default NULL,

		  `reference3_years` varchar(10) default NULL,

		  `address1_country` varchar(100) default NULL,

		  `address1_state` varchar(60) default NULL,

		  `address1_county` varchar(100) default NULL,

		  `address1_city` varchar(100) default NULL,

		  `address1_zipcode` varchar(60) default NULL,

		  `address1` text,

		  `address2_country` varchar(100) default NULL,

		  `address2_state` varchar(60) default NULL,

		  `address2_county` varchar(100) default NULL,

		  `address2_city` varchar(100) default NULL,

		  `address2_zipcode` varchar(60) default NULL,

		  `address2` text,

		  `reference1_zipcode` varchar(20) default NULL,

		  `reference2_zipcode` varchar(20) default NULL,
		  `reference3_zipcode` varchar(20) default NULL,
		  `packageid` int(11) default NULL,
		  `paymenthistoryid` int(11) default NULL,
		  `userfield1`  varchar(255) default NULL,
		  `userfield2`  varchar(255) default NULL,
		  `userfield3`  varchar(255) default NULL,
		  `userfield4`  varchar(255) default NULL,
		  `userfield5`  varchar(255) default NULL,
		  `userfield6`  varchar(255) default NULL,
		  `userfield7`  varchar(255) default NULL,
		  `userfield8`  varchar(255) default NULL,
		  `userfield9`  varchar(255) default NULL,
		  `userfield10`  varchar(255) default NULL,
			`currencyid` int(11) DEFAULT NULL,	
			`job_subcategory` int(11) DEFAULT NULL,
			`date_of_birth` datetime DEFAULT NULL,
			`longitude` varchar(50) DEFAULT NULL,
			`latitude` varchar(50) DEFAULT NULL,
			`video` varchar(50) DEFAULT NULL,
			  PRIMARY KEY  (`id`),
			  KEY `resume_uid` (`uid`),
			  KEY `resume_packageid` (`packageid`)
	) ;

CREATE TABLE IF NOT EXISTS`#__js_job_folderresumes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `jobid` int(11) NOT NULL,
  `resumeid` int(11) NOT NULL,
  `folderid` int(11) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ;

CREATE TABLE IF NOT EXISTS`#__js_job_folders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `global` tinyint(1) NOT NULL,
  `jobid` int(11) DEFAULT NULL,
  `packageid` int(11) NOT NULL,
  `paymenthistoryid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `decription` text,
  `status` tinyint(1) NOT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ;

CREATE TABLE IF NOT EXISTS`#__js_job_jobalertsetting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `categoryid` int(11) NOT NULL,
  `subcategoryid` int(11) NOT NULL,
  `contactemail` varchar(255) NOT NULL,
  `country` varchar(100) NOT NULL,
  `state` varchar(60) DEFAULT NULL,
  `county` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `zipcode` varchar(60) DEFAULT NULL,
  `sendtime` datetime NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `alerttype` tinyint(1) DEFAULT NULL,
  `longitude` varchar(50) DEFAULT NULL,
  `latitude` varchar(50) DEFAULT NULL,
  `coordinatesradius` int(11) NOT NULL,
  `lastmailsend` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ;

CREATE TABLE IF NOT EXISTS`#__js_job_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employerid` int(11) NOT NULL,
  `jobseekerid` int(11) DEFAULT NULL,
  `sendby` int(11) NOT NULL,
  `jobid` int(11) NOT NULL,
  `replytoid` int(11) NOT NULL,
  `resumeid` int(11) NOT NULL,
  `subject` varchar(500) NOT NULL,
  `message` text NOT NULL,
  `isread` tinyint(1) NOT NULL,
  `isconflict` tinyint(1) DEFAULT NULL,
  `conflictvalue` varchar(500) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ;

CREATE TABLE IF NOT EXISTS`#__js_job_resumerating` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `jobid` int(11) NOT NULL,
  `resumeid` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `votes` float DEFAULT NULL,
  `meonly` tinyint(1) DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ;

CREATE TABLE IF NOT EXISTS`#__js_job_subcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categoryid` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_category_id` (`categoryid`)
) ;

INSERT INTO `#__js_job_subcategories` (categoryid,title,status) VALUES ('1', 'Cast Accounting ', '1'), ('1', 'Controllership & Accounting Managment', '1'), ('1', 'Payroll ', '1'), ('1', 'Corporate Finance', '1'), ('2', 'Administrative Division', '1'), ('2', 'Autonomous Territories', '1'), ('2', 'Administrative County', '1'), ('2', 'Administrative Communes', '1'), ('3', 'Finance Advertising ', '1'), ('3', 'Advertising-Tourism', '1'), ('3', 'Advertising Social Net', '1'), ('3', 'Distributor Marketing', '1'), ('3', 'Facebook Advertising', '1'), ('4', 'Quality Engineer ', '1'), ('4', 'Office Assistant ', '1'), ('4', 'Air Host/hostess', '1'), ('4', 'Ticketing/reservation', '1'), ('5', 'Architectural Drafting', '1'), ('5', 'Enterprize Architecture', '1'), ('5', 'Architecture Frameworks', '1'), ('6', 'Automotive Design', '1'), ('6', 'Autmotive Paints', '1'), ('6', 'Automotive Equipment/Parts', '1'), ('6', 'Automotive Search Engine', '1'), ('7', 'Private Banking', '1'), ('7', 'Stock Brocker', '1'), ('7', 'Fractional-reserve Banking', '1'), ('7', 'Mobile Banking', '1'), ('8', 'Plant Biotechnology', '1'), ('8', 'Animal Biotechnology', '1'), ('8', 'Biotechnology & Medicine', '1'), ('8', 'Biotechnology & Society', '1'), ('8', 'Industrail & Microbial Biotechnonogy', '1'), ('9', 'Construction (Design & Managment)', '1'), ('9', 'Construction Engineering ', '1'), ('9', 'Composite Construction', '1'), ('10', 'Civil Engineering', '1'), ('10', 'Software Engineering', '1'), ('10', 'Nuclear Engineering', '1'), ('10', 'Ocean Engingeering', '1'), ('10', 'Transpotation Engineering', '1'), ('11', 'Security Cleared Jobs', '1'), ('11', 'Security Cleared IT Jobs', '1'), ('11', 'Confidential & Secret Security Clearance Job', '1'), ('12', 'Verbal', '1'), ('12', 'E-mail', '1'), ('12', 'Non-verbal', '1'), ('13', 'Computer Consulting Services ', '1'), ('13', 'Computer Installations Services', '1'), ('13', 'Software Vendors', '1'), ('14', 'Renovaiton', '1'), ('14', 'Addition', '1'), ('14', 'New Construction', '1'), ('15', 'Organization Development', '1'), ('15', 'Construction Management', '1'), ('15', 'Managment Consulting ', '1'), ('16', 'High Touch Customer Service ', '1'), ('16', 'Low Touch Customer Service', '1'), ('16', 'Bad Touch Customer Service', '1'), ('17', 'By Using legal services for the poor', '1'), ('17', 'By Using Retained Counsel', '1'), ('17', 'By Self-representation', '1'), ('18', 'Project Subtype Design', '1'), ('18', 'Graphic Design', '1'), ('18', 'Interior Desing', '1'), ('19', 'IT or Engineering Education', '1'), ('19', 'Commerce & Managment', '1'), ('19', 'Medical Education', '1'), ('20', 'Power Engineering', '1'), ('20', 'Instrumentation', '1'), ('20', 'Telecommunication', '1'), ('20', 'Signal Processing', '1'), ('21', 'Electromagnetics', '1'), ('21', 'Network Analysis', '1'), ('21', 'Control Systems', '1'), ('22', 'Thermal Energy', '1'), ('22', 'Chemical Energy', '1'), ('22', 'Electrical Energy', '1'), ('22', 'Nuclear Energy', '1'), ('23', 'Software Engineering ', '1'), ('23', 'Civil Engineering ', '1'), ('23', 'Nuclear Engineering', '1'), ('24', 'Nuclear Safety', '1'), ('24', 'Agriculture Safety', '1'), ('24', 'Occupational Health Safety', '1'), ('25', 'Unique Fundraisers', '1'), ('25', 'Sports Fundraiserse', '1'), ('25', 'Fundraisers', '1'), ('26', 'Staying Informed', '1'), ('26', 'Medical Edcuation ', '1'), ('26', 'Managing a partucular disease', '1'), ('27', 'Customs & Border Protection', '1'), ('27', 'Federal Law & Enforcement', '1'), ('27', 'Nation Protection', '1'), ('28', 'Benefits Administrators', '1'), ('28', 'Executive Compensation Analysts', '1'), ('28', 'Managment Analysts', '1'), ('29', 'Health Insurance ', '1'), ('29', 'Life Insurance', '1'), ('29', 'Vehicle Insurance', '1'), ('30', 'Artificial Intelligence ', '1'), ('30', 'Predictive Analytics ', '1'), ('30', 'Science & Technology', '1'), ('31', 'Work Experience internship', '1'), ('31', 'Research internship', '1'), ('31', 'Sales & Marketing Intern', '1'), ('32', 'According To Law', '1'), ('32', 'Defined Rule', '1'), ('33', 'Shipping ', '1'), ('33', 'Transpotation Managment', '1'), ('33', 'Third-party Logistics Provider', '1'), ('34', 'General Maintenance', '1'), ('34', 'Automobile Maintenance ', '1'), ('34', 'Equipment Manitenance', '1'), ('35', 'Project Managment', '1'), ('35', 'Planning ', '1'), ('35', 'Risk Managment', '1'), ('36', 'Quality Assurance ', '1'), ('36', 'Product Manager', '1'), ('36', 'Planning Supervisor ', '1'), ('37', 'Networking ', '1'), ('37', 'Direct Mail Marketing', '1'), ('37', 'Media Advertising ', '1'), ('38', 'Supply Chain ', '1'), ('38', 'Hazardous Materials Management', '1'), ('38', 'Materials Inventory Managment', '1'), ('39', 'Aerospace ', '1'), ('39', 'Automotive ', '1'), ('39', 'Biomedical', '1'), ('39', 'Mechanical', '1'), ('39', 'Naval', '1'), ('40', 'Conventional Mortgage', '1'), ('40', 'Adjustable Rate Mortgage', '1'), ('40', 'Commercial Mortgages', '1'), ('41', 'Economic Security', '1'), ('41', 'Environmental Security', '1'), ('41', 'Military Security', '1'), ('42', 'Freelance Portfolios', '1'), ('42', 'Freelance Freedom ', '1'), ('42', 'Freelance Jobs', '1'), ('43', 'Offset Lithographp ', '1'), ('43', 'Themography Raised Printing', '1'), ('43', 'Digital Printing ', '1'), ('44', 'idea Generation', '1'), ('44', 'Need Based Generation', '1'), ('44', 'Design Solution', '1'), ('45', 'Media Relations', '1'), ('45', 'Media Tours ', '1'), ('45', 'Newsletters ', '1'), ('46', 'Automised Security', '1'), ('46', 'Environmental & Social Safety', '1'), ('47', 'Basic Research', '1'), ('47', 'Applied Research', '1'), ('47', 'Methods & Appraches ', '1'), ('48', 'Department Stores', '1'), ('48', 'Discount Stores', '1'), ('48', 'Supermarkets', '1'), ('49', 'Sales Contracts ', '1'), ('49', 'Sales Forecasts ', '1'), ('49', 'Sales Managment', '1'), ('50', 'Scientific Managment', '1'), ('50', 'Scientific Research', '1'), ('50', 'Scientific invenctions ', '1'), ('51', 'Shppping/Distrubution Companies', '1'), ('51', 'Services ', '1'), ('51', 'Channels & Softwares', '1'), ('52', 'Medical Technicians ', '1'), ('52', 'Electrical Technicians', '1'), ('52', 'Accounting Technicians ', '1'), ('53', 'Construction Trade ', '1'), ('53', 'Stock Trade', '1'), ('53', 'skilled Trade ', '1'), ('53', 'Option Trade ', '1'), ('54', 'Transpotation System', '1'), ('54', 'Human-Powered ', '1'), ('54', 'Airline,Train,bus,car', '1'), ('55', 'Subway & Civil', '1'), ('55', 'Traffic Highway Transpotation', '1'), ('56', 'Small Business ', '1'), ('56', 'E-Commerce Sites ', '1'), ('56', 'Portals ', '1'), ('56', 'Search Engines ', '1'), ('56', 'Personal,Commercial,Govt', '1');


CREATE TABLE IF NOT EXISTS`#__js_job_currencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(60) DEFAULT NULL,
  `symbol` varchar(60) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `default` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ;
INSERT INTO `#__js_job_currencies` VALUES (1,'Pakistani Rupee','Rs.',1,1), (2,'USD','$',1,0);

