<?php
/**
 * @Copyright Copyright (C) 2009-2011
 * @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
 + Created by:	Ahmad Bilal
 * Company:		Buruj Solutions
 + Contact:		www.burujsolutions.com , ahmad@burujsolutions.com
 * Created on:	Jan 11, 2009
 ^
 + Project: 		JS Jobs
 * File Name:	admin-----/views/application/tmpl/info.php
 ^ 
 * Description: JS Jobs Information
 ^ 
 * History:		NONE
 ^ 
 */

 JRequest :: setVar('layout', 'info');
$_SESSION['cur_layout']='info';
$document = &JFactory::getDocument();
$document->addStyleSheet('components/com_jsjobs/include/css/jsjobsadmin.css');

?>
<table width="100%">
	<tr>
		<td align="left" width="175" valign="top">
			<table width="100%"><tr><td style="vertical-align:top;">
			<?php
			include_once('components/com_jsjobs/views/menu.php');
			?>
			</td>
			</tr></table>
		</td>
		<td width="100%" valign="top">
			<form action="index.php" method="POST" name="adminForm">
			  
			    <table cellpadding="2" cellspacing="4" border="1" width="100%" class="adminform">
			      <tr align="left" height="55" valign="middle" class="adminform">
			         <td align="left" valign="middle"><h1><?php echo JText::_('JS Jobs') ; ?></h1></td>
			      </tr>
			      <tr align="left" valign="middle">
			         <td align="left" valign="top"><?php echo JText::_('JS_CREATE_BY') . ' :<strong> ' . JText::_('Ahmad Bilal').'</strong>'; ?></td>
			      </tr>
			      <tr align="left" valign="middle">
			         <td align="left" valign="top"><?php echo JText::_('JS_COMPANY') . ' :<strong> ' . JText::_('Joom Sky').'</strong>'; ?></td>
			      </tr>
			      <tr align="left" valign="middle">
			         <td align="left" valign="top"><?php echo JText::_('JS_PROJECT_NAME') . ' :<strong> ' . JText::_('com_jsjobs').'</strong>'; ?></td>
			      </tr>
			      <tr align="left" valign="middle">
			         <td align="left" valign="top"><?php echo JText::_('JS_VIRSION') . ' : <strong>1.0.8.7 - b</strong>'; ?></td>
			      </tr>
			      <tr align="left" valign="middle">
			         <td align="left" valign="top"><?php echo JText::_('JS_DESCCRIPTION') . ' :<strong> ' . JText::_('A component for job posting and resume submission.').'</strong>'; ?></td>
			      </tr>
			      <tr align="left" valign="middle">
			         <td align="left" valign="top">
			         <?php echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='http://www.joomsky.com' target='_blank'><strong>" . JText::_('www.joomsky.com') ."</strong></a>"; ?>
					 </td>
			      </tr>
			    </table>
			  



			</form>
		</td>
	</tr>
	<tr>
		<td colspan="2" align="left" width="100%"  valign="top">
			<table width="100%" style="table-layout:fixed;"><tr><td style="vertical-align:top;"><?php echo eval(base64_decode('CQkJZWNobyAnPHRhYmxlIHdpZHRoPSIxMDAlIiBzdHlsZT0idGFibGUtbGF5b3V0OmZpeGVkOyI+DQo8dHI+PHRkIGhlaWdodD0iMTUiPjwvdGQ+PC90cj4NCjx0cj4NCjx0ZCBzdHlsZT0idmVydGljYWwtYWxpZ246bWlkZGxlOyIgYWxpZ249ImNlbnRlciI+DQo8YSBocmVmPSJodHRwOi8vd3d3Lmpvb21za3kuY29tIiB0YXJnZXQ9Il9ibGFuayI+PGltZyBzcmM9Imh0dHA6Ly93d3cuam9vbXNreS5jb20vbG9nby9qc2pvYnNjcmxvZ28ucG5nIiA+PC9hPg0KPGJyPg0KQ29weXJpZ2h0ICZjb3B5OyAyMDA4IC0gJy4gZGF0ZSgnWScpIC4nLCA8YSBocmVmPSJodHRwOi8vd3d3LmJ1cnVqc29sdXRpb25zLmNvbSIgdGFyZ2V0PSJfYmxhbmsiPkJ1cnVqIFNvbHV0aW9uczwvYT4gDQo8L3RkPg0KPC90cj4NCjwvdGFibGU+JzsNCg=='));	?>	</td></tr></table>
		</td>
	</tr>
</table>							
<script language="javascript" type="text/javascript">
	dhtml.cycleTab('tab1');
</script>
