<?php
/**
 * @Copyright Copyright (C) 2009-2011
 * @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
 + Created by:	Ahmad Bilal
 * Company:		Buruj Solutions
 + Contact:		www.burujsolutions.com , ahmad@burujsolutions.com
 * Created on:	Jan 11, 2009
 ^
 + Project: 		JS Jobs
 * File Name:	admin-----/views/application/tmpl/formjobsearch.php
 ^ 
 * Description: Form template for a company
 ^ 
 * History:		NONE
 ^ 
 */
 
defined('_JEXEC') or die('Restricted access'); 
jimport('joomla.html.pane');
$document = &JFactory::getDocument();
$document->addStyleSheet('components/com_jsjobs/include/css/jsjobsadmin.css');

$document = &JFactory::getDocument();
$document->addScript( JURI::base() . '/includes/js/joomla.javascript.js');
$version = new JVersion;
$joomla = $version->getShortVersion();
$jversion = substr($joomla,0,3);

JHTML :: _('behavior.calendar');
$width_big = 40;
$width_med = 25;
$width_sml = 15;

	$dateformat = $this->config['date_format'];
	$firstdash = strpos($dateformat,'-',0);
	$firstvalue = substr($dateformat, 0,$firstdash);
	$firstdash = $firstdash + 1;
	$seconddash = strpos($dateformat,'-',$firstdash);
	$secondvalue = substr($dateformat, $firstdash,$seconddash-$firstdash);
	$seconddash = $seconddash + 1;
	$thirdvalue = substr($dateformat, $seconddash,strlen($dateformat)-$seconddash);
	$js_dateformat = '%'.$firstvalue.'-%'.$secondvalue.'-%'.$thirdvalue;
$ADMINPATH = JPATH_BASE .'\components\com_jsjobs';
?>

<script language="javascript">
// for joomla 1.6
Joomla.submitbutton = function(task){
        if (task == ''){
                return false;
        }else{
                if (task == 'save'){
                    returnvalue = validate_form(document.adminForm);
                }else returnvalue  = true;
                if (returnvalue){
                        Joomla.submitform(task);
                        return true;
                }else return false;
        }
}
// for joomla 1.5

function submitbutton(pressbutton) {
	if (pressbutton) {
		document.adminForm.task.value=pressbutton;
	}
	if(pressbutton == 'save'){
		returnvalue = validate_form(document.adminForm);
	}else returnvalue  = true;
	
	if (returnvalue == true){
		try {
			  document.adminForm.onsubmit();
	        }
		catch(e){}
		document.adminForm.submit();
	}
}

function validate_form(f)
{
        if (document.formvalidator.isValid(f)) {
                f.check.value='<?php if(($jversion == '1.5') || ($jversion == '2.5')) echo JUtility::getToken(); else echo  JSession::getFormToken(); ?>';//send token
        }
        else {
                alert('Some values are not acceptable.  Please retry.');
				return false;
        }
		return true;
}
</script>

<table width="100%" >
	<tr>
		<td align="left" width="175"  valign="top">
			<table width="100%" ><tr><td style="vertical-align:top;">
			<?php
			include_once('components/com_jsjobs/views/menu.php');
			?>
			</td>
			</tr></table>
		</td>
		<td width="100%" valign="top" align="left">


<form action="index.php?option=com_jsjobs&task=view&layout=job_searchresult" method="post" name="adminForm" id="adminForm"  >
    <input type="hidden" name="isjobsearch" value="1" />
    <table cellpadding="5" cellspacing="0" border="0" width="100%" class="adminform">
		<?php
		$trclass = array("row0", "row1");
		$isodd = 1;
		?>
		 <?php if ( $this->searchjobconfig['search_job_title'] == '1' ) { $isodd = 1 - $isodd; ?>
			 <tr class="<?php echo $trclass[$isodd]; ?>">	       		 <td width="20%" align="right"><?php echo JText::_('JS_JOB_TITLE'); ?></td>
         	 <td width="60%"><input class="inputbox" type="text" name="title" size="40" maxlength="255"  />
       		 </td>
     		 </tr>
	  <?php } ?>
	 <?php if ( $this->searchjobconfig['search_job_category'] == '1' ) { $isodd = 1 - $isodd;?>
 				<tr class="<?php echo $trclass[$isodd]; ?>">				<td valign="top" align="right"><?php echo JText::_('JS_CATEGORIES'); ?></td>
				<td><?php echo $this->searchoptions['jobcategory']; ?></td>
			  </tr>
	  <?php } ?>
	 <?php if ( $this->searchjobconfig['search_job_subcategory'] == '1' ) { $isodd = 1 - $isodd;?>
 				<tr class="<?php echo $trclass[$isodd]; ?>">				<td valign="top" align="right"><?php echo JText::_('JS_SUB_CATEGORIES'); ?></td>
				<td id="fj_subcategory"><?php echo $this->searchoptions['jobsubcategory']; ?></td>
			  </tr>
	  <?php } ?>
	 <?php if ( $this->searchjobconfig['search_job_type'] == '1' ) { $isodd = 1 - $isodd; ?>
      <tr class="<?php echo $trclass[$isodd]; ?>">
        <td valign="top" align="right"><?php echo JText::_('JS_JOBTYPE'); ?></td>
        <td><?php echo $this->searchoptions['jobtype']; ?></td>
      </tr>
	  <?php } ?>
	 <?php if ( $this->searchjobconfig['search_job_status'] == '1' ) {	$isodd = 1 - $isodd; ?>
      <tr class="<?php echo $trclass[$isodd]; ?>">
        <td valign="top" align="right"><?php echo JText::_('JS_JOBSTATUS'); ?></td>
        <td><?php echo $this->searchoptions['jobstatus']; ?></td>
      </tr>
	  <?php } ?>
      <?php if ( $this->searchjobconfig['search_job_salaryrange'] == '1' ) { 	$isodd = 1 - $isodd;	?>
	  <tr class="<?php echo $trclass[$isodd]; ?>">
            <td valign="top" align="right"><?php echo JText::_('JS_SALARYRANGE'); ?></td>
            <td nowrap>
            <?php echo $this->searchoptions['currency']; ?>&nbsp;&nbsp;&nbsp;
            <?php echo $this->searchoptions['salaryrangefrom']; ?>&nbsp;&nbsp;&nbsp;
            <?php echo $this->searchoptions['salaryrangeto']; ?>&nbsp;&nbsp;&nbsp;
            <?php echo $this->searchoptions['salaryrangetypes']; ?>&nbsp;&nbsp;&nbsp;
        </td>
      </tr>
       <?php } ?>
      <?php /* if ( $this->searchjobconfig['search_job_heighesteducation'] == '1' ) { $isodd = 1 - $isodd;	?>
	    <tr class="<?php echo $trclass[$isodd]; ?>">
        <td valign="top" align="right"><?php echo JText::_('JS_HEIGHTESTFINISHEDEDUCATION'); ?></td>
        <td><?php echo $this->searchoptions['heighestfinisheducation']; ?></td>
      </tr>
       <?php } */ ?>
      <?php if ( $this->searchjobconfig['search_job_shift'] == '1' ) { $isodd = 1 - $isodd;	?>
	    <tr class="<?php echo $trclass[$isodd]; ?>">
        <td valign="top" align="right"><?php echo JText::_('JS_SHIFT'); ?></td>
        <td><?php echo $this->searchoptions['shift']; ?></td>
      </tr>
       <?php } ?>
      <?php /* if ( $this->searchjobconfig['search_job_experience'] == '1' ) { $isodd = 1 - $isodd;	?>
	    <tr class="<?php echo $trclass[$isodd]; ?>">
        <td valign="top" align="right"><?php echo JText::_('JS_EXPERIENCE'); ?></td>
        <td><input class="inputbox" type="text" name="experience" size="10" maxlength="15"  /></td>
      </tr>
       <?php } */ ?>
      <?php if ( $this->searchjobconfig['search_job_durration'] == '1' ) { $isodd = 1 - $isodd;	?>
	    <tr class="<?php echo $trclass[$isodd]; ?>">
        <td valign="top" align="right"><?php echo JText::_('JS_DURATION'); ?></td>
        <td><input class="inputbox" type="text" name="durration" size="10" maxlength="15"  /></td>
      </tr>
       <?php } ?>
      <?php if ( $this->searchjobconfig['search_job_startpublishing'] == '1' ) { $isodd = 1 - $isodd;	?>
	   <tr class="<?php echo $trclass[$isodd]; ?>">
        <td valign="top" align="right"><?php echo JText::_('JS_START_PUBLISHING'); ?></td>
        <td><?php if($jversion == '1.5'){?><input class="inputbox" type="text" name="startpublishing" id="startpublishing" readonly class="Shadow Bold" size="10" value="" />
			        <input type="reset" class="button" value="..." onclick="return showCalendar('startpublishing','<?php echo $js_dateformat; ?>');"  />
			<?php }else	echo JHTML::_('calendar', '','startpublishing', 'startpublishing',$js_dateformat,array('class'=>'inputbox', 'size'=>'10',  'maxlength'=>'19')); ?>
		</td>
      </tr>
       <?php } ?>
      <?php if ( $this->searchjobconfig['search_job_stoppublishing'] == '1' ) { $isodd = 1 - $isodd;	?>
	   <tr class="<?php echo $trclass[$isodd]; ?>">
        <td valign="top" align="right"><?php echo JText::_('JS_STOP_PUBLISHING'); ?></td>
        <td><?php if($jversion == '1.5'){?><input class="inputbox" type="text" name="stoppublishing" id="stoppublishing" readonly class="Shadow Bold" size="10" value="" />
			        <input type="reset" class="button" value="..." onclick="return showCalendar('stoppublishing','<?php echo $js_dateformat; ?>');"  />
			<?php }else echo JHTML::_('calendar', '','stoppublishing', 'stoppublishing',$js_dateformat,array('class'=>'inputbox', 'size'=>'10',  'maxlength'=>'19')); ?>
		</td>
      </tr>
	  <?php } ?>
	 <?php if ( $this->searchjobconfig['search_job_company'] == '1' ) { $isodd = 1 - $isodd;	?>

   		<tr class="<?php echo $trclass[$isodd]; ?>">
        <td align="right"><?php echo JText::_('JS_COMPANYNAME'); ?></td>
        <td><?php echo $this->searchoptions['companies']; ?>
        </td>
      </tr>
	  <?php } ?>
	 <?php if ( $this->searchjobconfig['search_job_country'] == '1' ) { $isodd = 1 - $isodd;	?>
       <tr class="<?php echo $trclass[$isodd]; ?>">
        <td align="right"><?php echo JText::_('JS_COUNTRY'); ?></td>
        <td id="country">
		    <?php echo $this->searchoptions['country']; ?>
        </td>
      </tr>
	  <?php } ?>
	 <?php if ( $this->searchjobconfig['search_job_state'] == '1' ) { $isodd = 1 - $isodd;	?>
       <tr class="<?php echo $trclass[$isodd]; ?>">
        <td align="right"><?php echo JText::_('JS_STATE'); ?></td>
        <td id="state">
			<?php
				if ((isset($this->searchoptions['state'])) && ($this->searchoptions['state']!='')){
				echo $this->searchoptions['state']; 
				} else{ ?>
				<input class="inputbox" type="text" name="state" size="40" maxlength="100" value="<?php  ?>" />
			<?php } ?>
					
		</td>
      </tr>
	  <?php } ?>
	 <?php if ( $this->searchjobconfig['search_job_county'] == '1' ) { $isodd = 1 - $isodd;	?>
      <tr class="<?php echo $trclass[$isodd]; ?>">
        <td align="right"><?php echo JText::_('JS_COUNTY'); ?></td>
        <td id="county">
			<?php 
				if ((isset($this->searchoptions['county'])) && ($this->searchoptions['county']!='')){
				echo $this->searchoptions['county']; 
				} else{ ?>
				<input class="inputbox" type="text" name="county" size="40" maxlength="100" value="<?php ?>" />
			<?php } ?>
					 
		</td>
      </tr>
	  <?php } ?>
	
	 <?php if ( $this->searchjobconfig['search_job_city'] == '1' ) { $isodd = 1 - $isodd;	?>
      <tr class="<?php echo $trclass[$isodd]; ?>">
        <td align="right"><?php echo JText::_('JS_CITY'); ?></td>
        <td id="city">
		<?php 
			if((isset($this->searchoptions['city'])) && ($this->searchoptions['city']!='')){
			echo $this->searchoptions['city']; 
			} else{ ?>
			<input class="inputbox" type="text" name="city" size="40" maxlength="100" value="<?php  ?>" />
		<?php } ?>
					 
		</td>
      </tr>
	  <?php } ?>
    
	 <?php if ( $this->searchjobconfig['search_job_zipcode'] == '1' ) { $isodd = 1 - $isodd;	?>
      <tr class="<?php echo $trclass[$isodd]; ?>">
        <td align="right"><?php echo JText::_('JS_ZIPCODE'); ?></td>
        <td><input class="inputbox" type="text" name="zipcode" size="40" maxlength="100"  />
        </td>
      </tr>
	  <?php } ?>
	
      <tr>
        <td colspan="2" height="5"></td>
      <tr>
	<tr>
		<td colspan="2" align="center">
		<input class="button" type="submit" onclick="document.adminForm.submit();" name="submit_app" onClick="return myValidate();" value="<?php echo JText::_('JS_SEARCH_JOB'); ?>" />
		</td>
	</tr>
    </table>


		 	<input type="hidden" name="uid" value="<?php echo $this->uid; ?>" />
			<input type="hidden" name="option" value="<?php echo $this->option; ?>" />
			<input type="hidden" name="task11" value="view" />
		  


<script language=Javascript>
function dochange(src, val){
	var xhr; 
	try {  xhr = new ActiveXObject('Msxml2.XMLHTTP');   }
	catch (e) 
	{
		try {   xhr = new ActiveXObject('Microsoft.XMLHTTP');    }
		catch (e2) 
		{
		  try {  xhr = new XMLHttpRequest();     }
		  catch (e3) {  xhr = false;   }
		}
	 }

	xhr.onreadystatechange = function(){
   
      if(xhr.readyState == 4 && xhr.status == 200){
 
        	document.getElementById(src).innerHTML=xhr.responseText; //retuen value

			if(src=='state'){
			countyhtml = "<input class='inputbox' type='text' name='county' size='40' maxlength='100'  />";
			cityhtml = "<input class='inputbox' type='text' name='city' size='40' maxlength='100'  />";
			document.getElementById('county').innerHTML=countyhtml; //retuen value
			document.getElementById('city').innerHTML=cityhtml; //retuen value
			}else if(src=='county'){
				cityhtml = "<input class='inputbox' type='text' name='city' size='40' maxlength='100'  />";
				document.getElementById('city').innerHTML=cityhtml; //retuen value
			}
 
      }
    }
 
	xhr.open("GET","index.php?option=com_jsjobs&task=listsearchaddressdata&data="+src+"&val="+val,true);
	xhr.send(null);

}
function fj_getsubcategories(src, val){
	var xhr;
	try {  xhr = new ActiveXObject('Msxml2.XMLHTTP');   }
	catch (e){
		try {   xhr = new ActiveXObject('Microsoft.XMLHTTP');    }
		catch (e2) {
		  try {  xhr = new XMLHttpRequest();     }
		  catch (e3) {  xhr = false;   }
		}
	 }

	xhr.onreadystatechange = function(){
            if(xhr.readyState == 4 && xhr.status == 200){
        	document.getElementById(src).innerHTML=xhr.responseText; //retuen value
            }
        }

	xhr.open("GET","index.php?option=com_jsjobs&task=listsubcategoriesforsearch&val="+val,true);
	xhr.send(null);
}

//window.onLoad=dochange('country', -1);  
			  
</script>
	</form>

		</td>
	</tr>
	<tr>
		<td colspan="2" align="left" width="100%"  valign="top">
			<table width="100%" style="table-layout:fixed;"><tr><td style="vertical-align:top;"><?php echo eval(base64_decode('CQkJZWNobyAnPHRhYmxlIHdpZHRoPSIxMDAlIiBzdHlsZT0idGFibGUtbGF5b3V0OmZpeGVkOyI+DQo8dHI+PHRkIGhlaWdodD0iMTUiPjwvdGQ+PC90cj4NCjx0cj4NCjx0ZCBzdHlsZT0idmVydGljYWwtYWxpZ246bWlkZGxlOyIgYWxpZ249ImNlbnRlciI+DQo8YSBocmVmPSJodHRwOi8vd3d3Lmpvb21za3kuY29tIiB0YXJnZXQ9Il9ibGFuayI+PGltZyBzcmM9Imh0dHA6Ly93d3cuam9vbXNreS5jb20vbG9nby9qc2pvYnNjcmxvZ28ucG5nIiA+PC9hPg0KPGJyPg0KQ29weXJpZ2h0ICZjb3B5OyAyMDA4IC0gJy4gZGF0ZSgnWScpIC4nLCA8YSBocmVmPSJodHRwOi8vd3d3LmJ1cnVqc29sdXRpb25zLmNvbSIgdGFyZ2V0PSJfYmxhbmsiPkJ1cnVqIFNvbHV0aW9uczwvYT4gDQo8L3RkPg0KPC90cj4NCjwvdGFibGU+JzsNCg=='));	?>	</td></tr></table>
		</td>
	</tr>
	
</table>				
