<?php
/**
 * @Copyright Copyright (C) 2009-2011
 * @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
 + Created by:	Ahmad Bilal
 * Company:		Buruj Solutions
 + Contact:		www.burujsolutions.com , ahmad@burujsolutions.com
 * Created on:	Mar 25, 2009
 ^
 + Project: 		JS Jobs
 * File Name:	views/applications/view.html.php
 ^ 
 * Description: HTML view of all applications 
 ^ 
 * History:		NONE
 ^ 
 */
 
defined('_JEXEC') or die('Restricted access');

$document = &JFactory::getDocument();
$document->addStyleSheet('components/com_jsjobs/include/css/jsjobsadmin.css');
?>
	<script type="text/javascript">
//	var myMenu;
	function mymenu(val) {
		myMenu = new SDMenu("my_menu");
myMenu.speed = 3;                     // Menu sliding speed (1 - 5 recomended)
myMenu.remember = true;               // Store menu states (expanded or collapsed) in cookie and restore later
myMenu.oneSmOnly = true;             // One expanded submenu at a time
myMenu.markCurrent = true;            // Mark current link / page (link.href == location.href)

myMenu.init();

// Additional methods...
var firstSubmenu = myMenu.submenus[val];
myMenu.expandMenu(firstSubmenu);      // Expand a submenu
	};
	</script>

<table width="100%">
	<tr>
		<td align="left" width="150" valign="top">
			<table width="100%"><tr><td style="vertical-align:top;">
			<?php
			include_once('components/com_jsjobs/views/menu.php');
			?>
			</td>
			</tr></table>
		</td>
		<td width="100%" valign="top">
			<table width="100%" border="0">
				<tr><td height="0"></td></tr>
				<tr>
					<td align="center" class="header" colspan="2">
						
						<div class="header"><h2><u>JS Jobs</u></h2></div>

					</td>
				</tr>
				<tr>
					<td width="7%"></td>
					<td align="center" width="85%">
						<table class="adminlist" >
								<thead>
									<tr><th><?php echo JText::_('JS_CONTROL_PANEL'); ?></th></tr>
								</thead>
								<tbody>
									<tr>
										<td align="center">
											<div id="cpanel" >
												<table width="85%" border="0" cellpadding="0" cellspacing="1" >
													<tr align="center">
														<td width="15"></td>
														<td width="90">
														       
															   <div style="float:center;align:center;"><div class="icon">
																<a href="index.php?option=com_jsjobs&task=view&layout=companies" onclick="mymenu(2)">
																	<img src="components/com_jsjobs/include/images/companies.png" height="56" width="56">
																	<br /><?php echo JText::_('JS_COMPANIES'); ?></a>
																</div></div>
														</td>
														<td width="90">
															<div ><div class="icon">
																<a href="index.php?option=com_jsjobs&task=view&layout=jobs" onclick="mymenu(4)">
																<img src="components/com_jsjobs/include/images/jobs.png" height="56" width="56"> 
																<br/><?php echo JText::_('JS_JOBS'); ?></a>
															</div></div>
														</td>	
														<td width="90">
															<div ><div class="icon">
																<a href="index.php?option=com_jsjobs&task=view&layout=empapps" onclick="mymenu(5)">
																<img src="components/com_jsjobs/include/images/resume.png" height="56" width="56"> 
																<br/><?php echo JText::_('JS_RESUME'); ?></a>
															</div></div>
														</td>	
														<td width="90">
															<div ><div class="icon">
																<a href="index.php?option=com_jsjobs&task=view&layout=payment_report" onclick="mymenu(6)">
																<img src="components/com_jsjobs/include/images/payments.png" height="56" width="56"> 
																<br/><?php echo JText::_('JS_PAYMENT_REPORT'); ?></a>
															</div></div>
														</td>	
													</tr>
													<tr><td colspan="4" height="25"></td></tr>	
													<tr align="center">
														<td></td>
														<td width="90">
															<div ><div class="icon">
																<a href="index.php?option=com_jsjobs&task=view&layout=jobsearch" onclick="mymenu(4)">
																<img src="components/com_jsjobs/include/images/search.png" height="56" width="56">
																<br/><?php echo JText::_('JS_JOB_SEARCH'); ?></a>
															</div></div>
														</td>	
														<td width="90">
															<div ><div class="icon">
																<a href="index.php?option=com_jsjobs&task=view&layout=resumesearch" onclick="mymenu(5)">
																<img src="components/com_jsjobs/include/images/search.png" height="56" width="56">
																<br/><?php echo JText::_('JS_RESUME_SEARCH'); ?></a>
															</div></div>
														</td>	
														<td width="90">
															<div ><div class="icon">
																<a href="index.php?option=com_jsjobs&task=view&layout=userstats" onclick="mymenu(0)">
																<img src="components/com_jsjobs/include/images/stats.png" height="56" width="56">
																<br/><?php echo JText::_('JS_USER_STATS'); ?></a>
															</div></div>
														</td>	
													</tr>
												</table>
											</div>
										</td>
									</tr>
								</tbody>
							</table>		
                            <table class="adminlist" >
                                <thead>
									<tr><th><?php echo JText::_('JS_CONFIGURATIONS'); ?></th></tr>
	                        </thead>
	                        <tbody>
	                                <tr>
		                                <td align="center">
											<div id="cpanel" >
													<table width="85%" border="0" cellpadding="0" cellspacing="1" >
															<tr align="center">
																	<td width="15"></td>
																	<td width="90">
																			   <div style="float:center;align:center;"><div class="icon">
																							<a  href="index.php?option=com_jsjobs&task=view&layout=configurations" onclick="mymenu(1)">
																							<img src="components/com_jsjobs/include/images/configurations.png" height="56" width="56">
																							<br /><?php echo JText::_('JS_GENERAL'); ?></a>
																					</div></div>
																	</td>
																	<td width="90">
																			<div ><div class="icon">
																									<a href="index.php?option=com_jsjobs&task=view&layout=configurationsemployer" onclick="mymenu(1)">
																									<img src="components/com_jsjobs/include/images/employer_conf.png" height="56" width="56">
																									<br/><?php echo JText::_('JS_EMPLOYER'); ?></a>
																			</div></div>
																	</td>
																	<td width="90">
																			<div ><div class="icon">
																					<a href="index.php?option=com_jsjobs&task=view&layout=configurationsjobseeker" onclick="mymenu(1)">
																					<img src="components/com_jsjobs/include/images/jobseeker_conf.png" height="56" width="56">
																					<br/><?php echo JText::_('JS_JOBSEEKER'); ?></a>
																			</div></div>
																	</td>
																	<td width="90">
																			<div ><div class="icon">
																					<a href="index.php?option=com_jsjobs&task=view&layout=themes" onclick="mymenu(1)">
																					<img src="components/com_jsjobs/include/images/themes.png" height="56" width="56">
																					<br/><?php echo JText::_('JS_THEMES'); ?></a>
																			</div></div>
																	</td>
															</tr>
															<tr><td colspan="4" height="25"></td></tr>
													</table>
												</div>
											</td>
										</tr>
									</tbody>
								</table>

                            <table class="adminlist" >
                                <thead>
									<tr><th><?php echo JText::_('JS_INFORMATION'); ?></th></tr>
	                        </thead>
	                        <tbody>
	                                <tr>
		                                <td align="center">
											<div id="cpanel" >
													<table width="85%" border="0" cellpadding="0" cellspacing="1" >
															<tr align="center">
																	<td width="15"></td>
																	<td width="90">
																			   <div style="float:center;align:center;"><div class="icon">
																							<a  href="index.php?option=com_jsjobs&task=view&layout=info" onclick="mymenu(0)">
																							<img src="components/com_jsjobs/include/images/information.png" height="56" width="56">
																							<br /><?php echo JText::_('JS_ABOUT'); ?></a>
																					</div></div>
																	</td>
																	<td width="90">
																			<div ><div class="icon">
																									<a href="index.php?option=com_jsjobs&task=view&layout=updates" onclick="mymenu(0)">
																									<img src="components/com_jsjobs/include/images/copyright.png" height="56" width="56">
																									<br/><?php echo JText::_('JS_REMOVE_FOOTER'); ?></a>
																			</div></div>
																	</td>
																	<td width="90">
																			<div ><div class="icon">
																					<a href="index.php?option=com_jsjobs&task=view&layout=updates" onclick="mymenu(0)">
																					<img src="components/com_jsjobs/include/images/updates.png" height="56" width="56">
																					<br/><?php echo JText::_('JS_UPDATES'); ?></a>
																			</div></div>
																	</td>
																	<td width="90">
																			<div ><div class="icon">
															<?php

																	$url = 'http://www.joomsky.com/jsjobssys/getlatestversion.php';
																	$pvalue = "dt=".date('Y-m-d');
																	if  (in_array  ('curl', get_loaded_extensions())) {
																		$ch = curl_init();
																		curl_setopt($ch,CURLOPT_URL,$url);
																		curl_setopt($ch,CURLOPT_POST,8);
																		curl_setopt($ch,CURLOPT_POSTFIELDS,$pvalue);
																		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
																		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
																		curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
																		$curl_errno = curl_errno($ch);
																		$curl_error = curl_error($ch);
																		$result = curl_exec($ch);
																		curl_close($ch);
																		if($result == $this->config['versioncode']){ ?>
																					<img src="components/com_jsjobs/include/images/systemupdated.png" height="56" width="56" title="<?php echo JText::_('YOUR_SYSTEM_IS_UP_TO_DATE'); ?>">
																					<br/><?php echo JText::_('YOUR_SYSTEM_IS_UP_TO_DATE'); ?></a>
																		<?php	
																		}elseif($result){ ?>
																					<img src="components/com_jsjobs/include/images/newversionavailable.png" height="56" width="56" title="<?php echo JText::_('NEW_VERSION_AVAILABLE'); ?>">
																					<br/><?php echo JText::_('NEW_VERSION_AVAILABLE'); ?></a>
																		<?php			
																		}else{ ?>
																					<img src="components/com_jsjobs/include/images/unabletoconnect.png" height="56" width="56" title="<?php echo JText::_('UNABLE_CONNECT_TO_SERVER'); ?>">
																					<br/><?php echo JText::_('UNABLE_TO_CONNECT'); ?></a>
																		<?php			
																		}
																	}else{ ?>
																				<img src="components/com_jsjobs/include/images/unabletoconnect.png" height="56" width="56" title="<?php echo JText::_('UNABLE_CONNECT_TO_SERVER'); ?>">
																				<br/><?php echo JText::_('UNABLE_TO_CONNECT'); ?></a>
																	<?php			
																	}
															
															?>
																			</div></div>
																	</td>
															</tr>
															<tr><td colspan="4" height="25">
															
															</td></tr>
													</table>
												</div>
											</td>
										</tr>
									</tbody>
								</table>
                            <table class="adminlist" >
                                <thead>
									<tr><th><?php echo JText::_('JS_SUPPORT'); ?></th></tr>
	                        </thead>
	                        <tbody>
	                                <tr>
		                                <td align="center">
											<div id="cpanel" >
													<table width="85%" border="0" cellpadding="0" cellspacing="1" >
															<tr align="center">
																	<td width="15"></td>
																	<td width="90">
																			   <div style="float:center;align:center;"><div class="icon">
																							<a  href="http://www.joomsky.com/jsjobssys/forum.php"  target="_blank">
																							<img src="components/com_jsjobs/include/images/forum.png" height="56" width="56">
																							<br /><?php echo JText::_('JS_FORUM'); ?></a>
																					</div></div>
																	</td>
																	<td width="90">
																			<div ><div class="icon">
																									<a href="http://www.joomsky.com/jsjobssys/documentation.php" target="_blank">
																									<img src="components/com_jsjobs/include/images/documentation.png" height="56" width="56">
																									<br/><?php echo JText::_('JS_DOCUMENTATION'); ?></a>
																			</div></div>
																	</td>
																	<td width="90">
																			<div ><div class="icon">
																					<a href="http://www.joomsky.com/jsjobssys/ticket.php" target="_blank">
																					<img src="components/com_jsjobs/include/images/ticket.png" height="56" width="56">
																					<br/><?php echo JText::_('JS_OPEN_A_TICKET'); ?></a>
																			</div></div>
																	</td>
																	<td width="90">
																	</td>
															</tr>
															<tr><td colspan="4" height="25"></td></tr>
													</table>
												</div>
											</td>
										</tr>
									</tbody>
								</table>


                            <table class="adminlist" >
                                <thead>
									<tr><th><?php echo JText::_('JS_MAKE_A_REVIEW'); ?></th></tr>
	                        </thead>
	                        <tbody>
	                                <tr>
		                                <td align="center">
											<div id="cpanel" >
													<table width="85%" border="0" cellpadding="0" cellspacing="1" >
															<tr><td height="10"></td></tr>
															<tr align="center">
																	<td width="25"></td>
																	<td >
																			   <div style="float:center;align:center;">
																							<strong><?php echo JText::_('JS_REVIEW_AT_JED'); ?>&nbsp;<a href="http://extensions.joomla.org/extensions/ads-a-affiliates/jobs-a-recruitment/7550" target="_blank"><?php echo JText::_('JS_JED'); ?></a></strong>
																					</div>
																	</td>
															</tr>
															<tr><td height="10"></td></tr>
													</table>
												</div>
											</td>
										</tr>
									</tbody>
								</table>

                            <table class="adminlist" >
                                <thead>
									<tr><th><?php echo JText::_('JS_CRON_JOB'); ?></th></tr>
	                        </thead>
	                        <tbody>
	                                <tr>
		                                <td align="center">
											<div id="cpanel" >
													<table width="85%" border="0" cellpadding="0" cellspacing="1" >
															<tr><td height="10"></td></tr>
															<tr align="center">
																	<td width="25"></td>
																	<td >
																			   <div style="float:center;align:center;">
																							<strong><?php echo JText::_('CRON_JOB_FOR_JOB_ALERT'); ?></strong>
																							<br /><textarea cols="70" rows="1" readonly="readonly" style="resize:none;width:100%;">curl "<?php echo JURI::root()."index.php?option=com_jsjobs&c=jsjobs&task=sendjobalert&ck=".$this->ck;?>"</textarea>
																					</div>
																	</td>
															</tr>
															<tr><td height="10"></td></tr>
													</table>
												</div>
											</td>
										</tr>
									</tbody>
								</table>

					</td>
					<td width="4%"></td>

				</tr>	
			</table>	
		</td>
	</tr>
	<tr>
		<td colspan="2" align="left" width="100%"  valign="top">
			<table width="100%" style="table-layout:fixed;"><tr><td style="vertical-align:top;"><?php echo eval(base64_decode('CQkJZWNobyAnPHRhYmxlIHdpZHRoPSIxMDAlIiBzdHlsZT0idGFibGUtbGF5b3V0OmZpeGVkOyI+DQo8dHI+PHRkIGhlaWdodD0iMTUiPjwvdGQ+PC90cj4NCjx0cj4NCjx0ZCBzdHlsZT0idmVydGljYWwtYWxpZ246bWlkZGxlOyIgYWxpZ249ImNlbnRlciI+DQo8YSBocmVmPSJodHRwOi8vd3d3Lmpvb21za3kuY29tIiB0YXJnZXQ9Il9ibGFuayI+PGltZyBzcmM9Imh0dHA6Ly93d3cuam9vbXNreS5jb20vbG9nby9qc2pvYnNjcmxvZ28ucG5nIiA+PC9hPg0KPGJyPg0KQ29weXJpZ2h0ICZjb3B5OyAyMDA4IC0gJy4gZGF0ZSgnWScpIC4nLCA8YSBocmVmPSJodHRwOi8vd3d3LmJ1cnVqc29sdXRpb25zLmNvbSIgdGFyZ2V0PSJfYmxhbmsiPkJ1cnVqIFNvbHV0aW9uczwvYT4gDQo8L3RkPg0KPC90cj4NCjwvdGFibGU+JzsNCg=='));	?>	</td></tr></table>
		</td>
	</tr>
	
</table>	
