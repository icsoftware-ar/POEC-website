<?php
/**
 * @Copyright Copyright (C) 2009-2011
 * @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
 + Created by:	Ahmad Bilal
 * Company:		Buruj Solutions
 + Contact:		www.burujsolutions.com , ahmad@burujsolutions.com
 * Created on:	Jan 11, 2009
 ^
 + Project: 		JS Jobs
 * File Name:	admin-----/views/applications/tmpl/jobappliedresumes.php
 ^ 
 * Description: Default template for job applied resumes view
 ^ 
 * History:		NONE
 ^ 
 */
 
defined('_JEXEC') or die('Restricted access');
$document = &JFactory::getDocument();
$document->addStyleSheet('components/com_jsjobs/include/css/jsjobsadmin.css');

JRequest :: setVar('layout', 'jobappliedresume');
$_SESSION['cur_layout']='jobappliedresume';
$version = new JVersion;
$joomla = $version->getShortVersion();
$jversion = substr($joomla,0,3);

$document =& JFactory::getDocument();
$document->addStyleSheet('../components/com_jsjobs/css/jsjobsresumerating.css');


$actions = array(
	'0' => array('value' => 1,'text' => JText::_('JS_SHORT_LIST')),
	'1' => array('value' => 2,'text' => JText::_('JS_SEND_MESSAGE')),
	'2' => array('value' => 3,'text' => JText::_('JS_FOLDER')),
	'3' => array('value' => 4,'text' => JText::_('JS_COMMENTS')),
        );
$actioncombo = JHTML::_('select.genericList', $actions, 'action', 'class="inputbox" '. '', 'value', 'text', '');

$status = array(
	'1' => JText::_('JOB_APPROVED'),
	'-1' => JText::_('JOB_REJECTED'));

?>
<table width="100%" >
	<tr>
		<td align="left" width="175"  valign="top">
			<table width="100%"><tr><td style="vertical-align:top;">
			<?php
			include_once('components/com_jsjobs/views/menu.php');
			?>
			</td>
			</tr></table>
		</td>
		<td width="100%" valign="top">

			<form action="index.php" method="post" name="adminForm">
			<table>
				<tr>
					<td width="100%">
						<strong><?php echo JText::_( 'Filter' ); ?></strong>
					</td>
					<td nowrap="nowrap">
						<?php echo JText::_( 'JS_NAME' ); ?> :
						<input type="text" name="searchname" id="searchname" value="<?php if(isset($this->lists['searchname'])) echo $this->lists['searchname'];?>" class="text_area" onchange="document.adminForm.submit();" />
						<button onclick="this.form.submit();"><?php echo JText::_( 'Go' ); ?></button>
					&nbsp;&nbsp;&nbsp;</td>
					<td nowrap="nowrap">
						<?php echo $this->lists['jobtype'];?>
					&nbsp;&nbsp;&nbsp;</td>
					<td>
						<button onclick="document.getElementById('searchname').value='';this.form.getElementById('searchjobtype').value='';this.form.submit();"><?php echo JText::_( 'Reset' ); ?></button>
					</td>
				</tr>
			</table>
			
			<table class="adminlist">
		<?php  $exportlink='index.php?option=com_jsjobs&task=exportresume&bd='.$this->oi;?>
		<tr >
		<?php if ($this->items){ ?>			
			<td align="right" colspan="8"><a  href="<?php echo $exportlink; ?>" >Export Resumes</a></td>
		<?php } ?>			
		</tr>

			<thead>
				
					<tr>
						<th width="20">
							<input type="checkbox" name="toggle" value="" onclick="Joomla.checkAll(this);" />
						</th>
						<th class="title"><?php echo JText::_('JS_NAME'); ?></th>
						<th><?php echo JText::_('JS_CATEGORY'); ?></th>
						<th><?php echo JText::_('JS_PREFFERD'); ?></th>
						<th><?php echo JText::_('JS_SALARY_RANGE'); ?></th>
						<th><?php echo JText::_('JS_APPLIED_DATE'); ?></th>
						<th><?php echo JText::_('JS_CONTACT_EMAIL'); ?></th>
						<th>s</th>
					</tr>
				</thead>
			<?php
			jimport('joomla.filter.output');
			$k = 0;
                        $count = 0;
                            for ($i=0, $n=count( $this->items ); $i < $n; $i++)
				{
                                $count++;
        			$row =& $this->items[$i];
				$checked = JHTML::_('grid.id', $i, $row->id);
				$link = JFilterOutput::ampReplace('index.php?option='.$this->option.'&task=edit&cid[]='.$row->id);
				$resumelink = 'index.php?option=com_jsjobs&view=application&layout=view_resume&rd='.$row->appid.'&oi='.$this->oi;
				$plink = 'index.php?option=com_jsjobs&view=application&layout=resumeprint&rd='.$row->appid.'&oi='.$this->oi;
				?>
				<tr valign="top" class="<?php echo "row$k"; ?>">
					<td>
						<?php echo $checked; ?>
					</td>
					<td>
						<a href="<?php echo $resumelink; ?>">
						<?php echo $row->first_name.' '.$row->last_name; ?></a>
					</td>
					<td>
						<?php 
						echo $row->cat_title;
						?>
					</td>
					<td style="text-align: center;">
						<?php echo $row->jobtypetitle; ?>
					</td>
					<td style="text-align: center;">
						<?php echo $row->symbol.$row->rangestart.' - '.$row->symbol. ' '.$row->rangeend; ?>
					</td>
					<td style="text-align: center;">
						<?php echo date( $this->config['date_format'],strtotime($row->apply_date)); ?>
					</td>
					<td style="text-align: center;">
						<?php echo  $row->email_address; ?>
					</td>
					<td nowrap="nowrap" >
						<?php echo "<a href='".$resumelink ."'>".JText::_('JS_RESUME')."  </a>"; ?>
						<?php if( $jversion == '1.5'){ ?>
							<a href="<?php echo $plink ?>"><img src="../components/com_jsjobs/images/print.png"></a>
						<?php } ?>
					</td>
				</tr>
                                <tr>
                                    <td colspan="">
                                        <strong><?php echo JText::_('JS_COMMENTS'); ?></strong>
                                    </td>
                                    <td colspan="4">
                                        <div>
                                            <?php echo  $row->comments; ?>
                                            </div>
                                        </td>
                                    <td colspan="3">
                                        <div>
                                        <?php
                                            $id = $row->jobapplyid ;
                                            $percent = 0;
                                            $stars = '';
                                            $percent = $row->rating * 20;
                                            $stars = '-small';
                                            $html="
                                                <div class=\"jsjobs-container".$stars."\"".( " style=\"margin-top:5px;\"" ).">
                                                <ul class=\"jsjobs-stars".$stars."\">
                                                <li id=\"rating_".$id."\" class=\"current-rating\" style=\"width:".(int)$percent."%;\"></li>
                                                <li><a href=\"javascript:void(null)\" onclick=\"javascript:setrating('rating_".$id."',1,".(int)$row->ratingid.",".$this->oi.",".$row->appid.");\" title=\"".JTEXT::_('Very Poor')."\" class=\"one-star\">1</a></li>
                                                <li><a href=\"javascript:void(null)\" onclick=\"javascript:setrating('rating_".$id."',2,".(int)$row->ratingid.",".$this->oi.",".$row->appid.");\" title=\"".JTEXT::_('Poor')."\" class=\"two-stars\">2</a></li>
                                                <li><a href=\"javascript:void(null)\" onclick=\"javascript:setrating('rating_".$id."',3,".(int)$row->ratingid.",".$this->oi.",".$row->appid.");\" title=\"".JTEXT::_('Regular')."\" class=\"three-stars\">3</a></li>
                                                <li><a href=\"javascript:void(null)\" onclick=\"javascript:setrating('rating_".$id."',4,".(int)$row->ratingid.",".$this->oi.",".$row->appid.");\" title=\"".JTEXT::_('Good')."\" class=\"four-stars\">4</a></li>
                                                <li><a href=\"javascript:void(null)\" onclick=\"javascript:setrating('rating_".$id."',5,".(int)$row->ratingid.",".$this->oi.",".$row->appid.");\" title=\"".JTEXT::_('Very Good')."\" class=\"five-stars\">5</a></li>
                                                </ul>
                                                </div>
                                            ";
                                            $html .="</small></span>";
                                            echo $html;
                                        ?>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                            <td>
                                <strong><?php echo JText::_('JS_LOCATION'); ?></strong>
                            </td>
                            <td colspan="3" align="left">
                                <?php
									$id = $row->jobapplyid ;
                                    if ($row->cityname) { echo $row->cityname; $comma = 1; }
                                    elseif ($row->address_city) { echo $row->address_city; $comma = 1; }
                                    if ($row->countyname) { if($comma) echo', '; echo $row->countyname; $comma = 1; }
                                    elseif ($row->address_county) { if($comma) echo', '; echo $row->address_county; $comma = 1; }
                                    if ($row->statename) { if($comma) echo', '; echo $row->statename; $comma = 1; }
                                    elseif ($row->address_state) { if($comma) echo', '; echo $row->address_state; $comma = 1; }
                                    if ($row->countryname) { if($comma) echo', '; echo $row->countryname; $comma = 1; }
                                 ?>
                            </td>
                                    <td align="right" colspan="4" >
                                            <?php echo JText::_('JS_ACTION').'&nbsp;&nbsp;&nbsp;'.JHTML::_('select.genericList', $actions, 'action_'.$count, 'class="inputbox" '. '', 'value', 'text', '');; ?>&nbsp;&nbsp;&nbsp;
                                            <input type="button" class="button" onclick="actioncall(<?php echo $id; ?>,<?php echo $this->oi; ?>,<?php echo $row->appid; ?>,'<?php echo "action_$count"; ?>')" value="<?php echo JText::_('JS_GO'); ?>">
                                        </td>
                                    
                                </tr>
                                <tr><td  id="resumeaction_<?php echo $id; ?>" colspan="8"></td></tr>
                                <tr><td  id="resumedetail_<?php echo $row->appid; ?>" colspan="8"></td></tr>
				<?php
				$k = 1 - $k;
			}
			?>
			<tr>
				<td colspan="9">
					<?php echo $this->pagination->getListFooter(); ?>
				</td>
			</tr>
			</table>
			<input type="hidden" name="option" value="<?php echo $this->option; ?>" />
			<input type="hidden" name="task"  id="task" value="actionresume" />
			<input type="hidden" name="jobid" id="jobid" value="<?php echo $this->oi; ?>" />
			<input type="hidden" name="resumeid" id="resumeid" value="<?php echo $row->appid; ?>" />
			<input type="hidden" name="id" id="id" value="" />
			<input type="hidden" name="action" id="action" value="" />
			<input type="hidden" name="boxchecked" value="0" />
			</form>
		</td>
	</tr>
	<tr>
		<td colspan="2" align="left" width="100%"  valign="top">
			<table width="100%" style="table-layout:fixed;"><tr><td style="vertical-align:top;"><?php echo eval(base64_decode('CQkJZWNobyAnPHRhYmxlIHdpZHRoPSIxMDAlIiBzdHlsZT0idGFibGUtbGF5b3V0OmZpeGVkOyI+DQo8dHI+PHRkIGhlaWdodD0iMTUiPjwvdGQ+PC90cj4NCjx0cj4NCjx0ZCBzdHlsZT0idmVydGljYWwtYWxpZ246bWlkZGxlOyIgYWxpZ249ImNlbnRlciI+DQo8YSBocmVmPSJodHRwOi8vd3d3Lmpvb21za3kuY29tIiB0YXJnZXQ9Il9ibGFuayI+PGltZyBzcmM9Imh0dHA6Ly93d3cuam9vbXNreS5jb20vbG9nby9qc2pvYnNjcmxvZ28ucG5nIiA+PC9hPg0KPGJyPg0KQ29weXJpZ2h0ICZjb3B5OyAyMDA4IC0gJy4gZGF0ZSgnWScpIC4nLCA8YSBocmVmPSJodHRwOi8vd3d3LmJ1cnVqc29sdXRpb25zLmNvbSIgdGFyZ2V0PSJfYmxhbmsiPkJ1cnVqIFNvbHV0aW9uczwvYT4gDQo8L3RkPg0KPC90cj4NCjwvdGFibGU+JzsNCg=='));	?>	</td></tr></table>
		</td>
	</tr>
	
</table>
<script language=Javascript>
function actioncall(jobapplyid,jobid, resumeid, action){
        actionvalue = document.getElementById(action).value;
        if(actionvalue == 3){ // folder
            getfolders('resumeaction_'+jobapplyid,jobid,resumeid);
        }else if(actionvalue == 4){ // comments
            getresumecomments('resumeaction_'+jobapplyid,jobapplyid);
        }else{
            document.getElementById('resumeid').value=resumeid;
            document.getElementById('action').value=actionvalue;
            document.forms["adminForm"].submit();
        }
}
function setresumeid(resumeid, action){
        document.getElementById('resumeid').value=resumeid;
        document.getElementById('action').value=document.getElementById(action).value;
        document.forms["adminForm"].submit();
}
function saveaddtofolder(jobid,resumeid){
        document.getElementById('resumeid').value=resumeid;
        document.getElementById('jobid').value=jobid;
        document.getElementById('task').value='saveresumefolder';
        document.forms["adminForm"].submit();
}
function saveresumecomments(jobapplyid){
        document.getElementById('id').value=jobapplyid;
        document.getElementById('task').value='saveresumecomments';
        document.forms["adminForm"].submit();
}
function getfolders(src,jobid,resumeid){
	document.getElementById(src).innerHTML="Loading ...";
	var xhr;
	try {  xhr = new ActiveXObject('Msxml2.XMLHTTP');   }
	catch (e)
	{
		try {   xhr = new ActiveXObject('Microsoft.XMLHTTP');    }
		catch (e2)
		{
		  try {  xhr = new XMLHttpRequest();     }
		  catch (e3) {  xhr = false;   }
		}
	 }

	xhr.onreadystatechange = function(){
      if(xhr.readyState == 4 && xhr.status == 200){
        	document.getElementById(src).innerHTML=xhr.responseText; //retuen value

      }
    }

	xhr.open("GET","index.php?option=com_jsjobs&task=getmyforlders&jobid="+jobid+"&resumeid="+resumeid,true);
	xhr.send(null);
}
function getresumecomments(src,jobapplyid){
	document.getElementById(src).innerHTML="Loading ...";
	var xhr;
	try {  xhr = new ActiveXObject('Msxml2.XMLHTTP');   }
	catch (e)
	{
		try {   xhr = new ActiveXObject('Microsoft.XMLHTTP');    }
		catch (e2)
		{
		  try {  xhr = new XMLHttpRequest();     }
		  catch (e3) {  xhr = false;   }
		}
	 }

	xhr.onreadystatechange = function(){
      if(xhr.readyState == 4 && xhr.status == 200){
        	document.getElementById(src).innerHTML=xhr.responseText; //retuen value

      }
    }
	xhr.open("GET","index.php?option=com_jsjobs&task=getresumecomments&jobapplyid="+jobapplyid,true);
	xhr.send(null);
}
function getjobdetail(src,jobid, resumeid){
	document.getElementById(src).innerHTML="Loading ...";
	var xhr;
	try {  xhr = new ActiveXObject('Msxml2.XMLHTTP');   }
	catch (e)
	{
		try {   xhr = new ActiveXObject('Microsoft.XMLHTTP');    }
		catch (e2)
		{
		  try {  xhr = new XMLHttpRequest();     }
		  catch (e3) {  xhr = false;   }
		}
	 }

	xhr.onreadystatechange = function(){
      if(xhr.readyState == 4 && xhr.status == 200){
        	document.getElementById(src).innerHTML=xhr.responseText; //retuen value

      }
    }

	xhr.open("GET","index.php?option=com_jsjobs&task=getresumedetail&jobid="+jobid+"&resumeid="+resumeid,true);
	xhr.send(null);
}

function clsjobdetail(src){
        document.getElementById(src).innerHTML="";

}

function setrating(src,newrating,ratingid,jobid,resumeid){
	var xhr;
	try {  xhr = new ActiveXObject('Msxml2.XMLHTTP');   }
	catch (e)
	{
		try {   xhr = new ActiveXObject('Microsoft.XMLHTTP');    }
		catch (e2)
		{
		  try {  xhr = new XMLHttpRequest();     }
		  catch (e3) {  xhr = false;   }
		}
	 }

	xhr.onreadystatechange = function(){
      if(xhr.readyState == 4 && xhr.status == 200){
               if(xhr.responseText == 1)
                document.getElementById(src).style.width=parseInt(newrating*20)+'%';

      }
    }
	xhr.open("GET","index.php?option=com_jsjobs&task=saveresumerating&ratingid="+ratingid+"&jobid="+jobid+"&resumeid="+resumeid+"&newrating="+newrating,true);
	xhr.send(null);


}

</script>
