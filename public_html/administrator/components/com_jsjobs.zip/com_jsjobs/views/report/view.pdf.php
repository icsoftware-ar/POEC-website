<?php



defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');

class JSJobsViewReport extends JViewLegacy
{
	function display($tpl = null)
	{
		$model		= &$this->getModel();
		$cur_layout = $_SESSION['cur_layout'];
		/*
		if ($results){ //not empty
			foreach ($results as $result){
				$config[$result->configname] = $result->configvalue;
			}
		}
                 * 
                 */
		

		if($cur_layout == 'resume1'){									
				$resumeid = $_GET['rd'];
				if (is_numeric($resumeid) == true) $result =  $model->getResumeViewbyId($resumeid);	
				$this->assignRef('resume', $result[0]);
				$this->assignRef('resume2', $result[1]);
				$this->assignRef('resume3', $result[2]);
				$this->assignRef('fieldsordering', $result[3]);
		}
	
		$this->assignRef('config', $config);
		
		$document = &JFactory::getDocument();
				$document->setTitle('Resume');
		parent :: display();
	}

}
?>
