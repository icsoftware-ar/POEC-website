<?php
/**
 * @Copyright Copyright (C) 2009-2011 ... Ahmad Bilal
 * @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
 * Company:		Buruj Solutions
 + Contact:		www.burujsolutions.com , ahmad@burujsolutions.com
 * Created on:	Jan 11, 2009
 ^
 + Project: 		JS Jobs
 * File Name:	admin-----/views/application/tmpl/formjob.php
 ^ 
 * Description: Form template for a job
 ^ 
 * History:		NONE
 ^ 
 */
 
defined('_JEXEC') or die('Restricted access'); 
jimport('joomla.html.pane');
$document = &JFactory::getDocument();
$document->addStyleSheet('components/com_jsjobs/include/css/jsjobsadmin.css');
$version = new JVersion;
$joomla = $version->getShortVersion();
$jversion = substr($joomla,0,3);

$editor = &JFactory::getEditor();
JHTML::_('behavior.calendar');
JHTML::_('behavior.formvalidation');  


	if($this->config['date_format']=='m/d/Y') $dash = '/';else $dash = '-';
	$dateformat = $this->config['date_format'];
	$firstdash = strpos($dateformat,$dash,0);
	$firstvalue = substr($dateformat, 0,$firstdash);
	$firstdash = $firstdash + 1;
	$seconddash = strpos($dateformat,$dash,$firstdash);
	$secondvalue = substr($dateformat, $firstdash,$seconddash-$firstdash);
	$seconddash = $seconddash + 1;
	$thirdvalue = substr($dateformat, $seconddash,strlen($dateformat)-$seconddash);
	$js_dateformat = '%'.$firstvalue.$dash.'%'.$secondvalue.$dash.'%'.$thirdvalue;
	
?>
<style type="text/css">
	#coordinatebutton{
		float:right;
	}
	#coordinatebutton .button{
		border-radius: 20px 20px 20px 20px;
		background: gray;
		color:ghostwhite;
	}
	#coordinatebutton .button:hover{
		background:black;
		color:ghostwhite;
	}
</style>
<script language="javascript">
function hideShowRange(hideSrc, showSrc, showName, showVal){
		document.getElementById(hideSrc).style.visibility = "hidden";
		document.getElementById(showSrc).style.visibility = "visible";
		document.getElementById(showName).value = showVal;
	
	}
function submitbutton(pressbutton) {
	if (pressbutton) {
		document.adminForm.task.value=pressbutton;
	}
	if(pressbutton == 'save'){
		returnvalue = validate_form(document.adminForm);
	}else returnvalue  = true;
	
	if (returnvalue == true){
		try {
			  document.adminForm.onsubmit();
	        }
		catch(e){}
		document.adminForm.submit();
	}
}

function validate_form(f)
{
        if (document.formvalidator.isValid(f)) {
                f.check.value='<?php if(($jversion == '1.5') || ($jversion == '2.5')) echo JUtility::getToken(); else echo  JSession::getFormToken(); ?>';//send token
        }
        else {
                alert('<?php echo JText::_( 'JS_SOME_VALUES_ARE_NOT_ACCEPTABLE_PLEASE_RETRY');?>');
				return false;
        }
		return true;
}
</script>

<table width="100%" >
	<tr>
		<td align="left" width="175"  valign="top">
			<table width="100%" ><tr><td style="vertical-align:top;">
			<?php
			include_once('components/com_jsjobs/views/menu.php');
			?>
			</td>
			</tr></table>
		</td>
		<td width="100%" valign="top" align="left">


			<form action="index.php" method="POST" name="adminForm" id="adminForm">
				<table cellpadding="0" cellspacing="0" border="0" width="100%" class="adminform">
				<?php
				if($this->msg != ''){
				?>
				 <tr>
			        <td colspan="2" align="center"><font color="red"><strong><?php echo JText::_($this->msg); ?></strong></font></td>
			      </tr>
				  <tr><td colspan="2" height="10"></td></tr>	
				<?php
				}
				?>
		<?php
		$trclass = array("row0", "row1");
		$isodd = 1;
		$i = 0;
		foreach($this->fieldsordering as $field){ 
			//echo '<br> uf'.$field->field;
			switch ($field->field) {
				case "jobtitle":  $isodd = 1 - $isodd; ?>
				  <tr class="<?php echo $trclass[$isodd]; ?>">
			        <td width="20%" align="right"><label id="titlemsg" for="title"><?php echo JText::_('JS_JOB_TITLE'); ?></label>&nbsp;<font color="red">*</font></td>
			          <td width="60%"><input class="inputbox required" type="text" name="title" id="title" size="40" maxlength="255" value="<?php if(isset($this->job)) echo $this->job->title; ?>" />
			        </td>
			      </tr>
				<?php break;
				case "company":
                                    $showcompany = 1;
                                    if (isset($this->job)) if ($this->job->uid != $this->uid) $showcompany = 0;
                                    if ($showcompany == 1) {
                                            $isodd = 1 - $isodd;  ?>
                                          <tr class="<?php echo $trclass[$isodd]; ?>">
                                        <td valign="top" align="right"><label id="companymsg" for="company"><?php echo JText::_('JS_COMPANY'); ?></label>&nbsp;<font color="red">*</font></td>
                                        <td><?php echo $this->lists['companies']; ?></td>
                                      </tr>
				<?php } break;
				case "department":  $isodd = 1 - $isodd; ?>
				  <tr class="<?php echo $trclass[$isodd]; ?>">
			        <td valign="top" align="right"><label id="departmentmsg" for="department"><?php echo JText::_('JS_DEPARTMENT'); ?></label></td>
			        <td><?php if(isset($this->lists['departments'])) echo $this->lists['departments']; ?></td>
				</tr>
				<?php break;
				case "jobcategory":  $isodd = 1 - $isodd; ?>
			      <tr class="<?php echo $trclass[$isodd]; ?>">
			        <td valign="top" align="right"><?php echo JText::_('JS_CATEGORY'); ?></td>
			        <td><?php echo $this->lists['jobcategory']; ?></td>
			      </tr>
				<?php break;
				case "subcategory":  $isodd = 1 - $isodd; ?>
			      <tr class="<?php echo $trclass[$isodd]; ?>">
			        <td valign="top" align="right"><?php echo JText::_('JS_SUB_CATEGORY'); ?></td>
			        <td id="fj_subcategory"><?php echo $this->lists['subcategory']; ?></td>
			      </tr>
				<?php break;
				case "jobtype":  $isodd = 1 - $isodd; ?>
				  <tr class="<?php echo $trclass[$isodd]; ?>">
			        <td valign="top" align="right"><?php echo JText::_('JS_JOBTYPE'); ?></td>
			        <td><?php echo $this->lists['jobtype']; ?></td>
			      </tr>
				<?php break;
				case "jobstatus": $isodd = 1 - $isodd;  ?>
				  <tr class="<?php echo $trclass[$isodd]; ?>">
			        <td valign="top" align="right"><?php echo JText::_('JS_JOBSTATUS'); ?></td>
			        <td><?php echo $this->lists['jobstatus']; ?></td>
			      </tr>
				<?php break;
				case "heighesteducation":  ?>
			      <?php if ( $field->published == 1 ) { $isodd = 1 - $isodd; ?>
				  <tr class="<?php echo $trclass[$isodd]; ?>">
					<td valign="top" align="right"><?php echo JText::_('JS_EDUCATION'); ?></td>
					<td height="31" colspan="53"  valign="top">
						<?php
							if(isset($this->job)) $iseducationminimax = $this->job->iseducationminimax; else $iseducationminimax = 1;
							if ($iseducationminimax == 1) {
								$educationminimaxdivstyle = "position:absolute;";
								$educationrangedivstyle = "visibility:hidden;position:absolute;";
							}else{
								$educationminimaxdivstyle = "visibility:hidden;position:absolute;";
								$educationrangedivstyle = "position:absolute;";
							}	
						?>
						<input type="hidden" name="iseducationminimax" id="iseducationminimax" value="<?php echo $iseducationminimax; ?>">
						<div id="educationminimaxdiv" style="<?php echo $educationminimaxdivstyle; ?>">
							<?php echo $this->lists['educationminimax']; ?>&nbsp;&nbsp;&nbsp;
							<?php echo $this->lists['education']; ?>&nbsp;&nbsp;&nbsp;
							<a  onclick="hideShowRange('educationminimaxdiv','educationrangediv','iseducationminimax',0);"><?php echo JText::_('JS_SPECIFY_RANGE'); ?></a>
						</div>
						<div id="educationrangediv" style="<?php echo $educationrangedivstyle; ?>">
							<?php echo $this->lists['minimumeducationrange']; ?>&nbsp;&nbsp;&nbsp;
							<?php echo $this->lists['maximumeducationrange']; ?>&nbsp;&nbsp;&nbsp;
							<a onclick="hideShowRange('educationrangediv','educationminimaxdiv','iseducationminimax',1);"><?php echo JText::_('JS_CANCEL_RANGE'); ?></a>						
						</div>
					</td>
				      </tr>
					<?php $isodd = 1 - $isodd;?>
					<tr class="<?php echo $trclass[$isodd]; ?>">
					<td valign="top" align="right"><label id="degreetitlesmsg" for="degreetitle"><?php echo JText::_('JS_DEGREE_TITLE'); ?></label></td>
					<td colspan="53"><input class="inputbox" type="text" name="degreetitle" id="degreetitle" size="30" maxlength="40" value="<?php if(isset($this->job)) echo $this->job->degreetitle; ?>" />
					</td>
					</tr>
					<?php } ?>
				<?php break;
				case "jobshift": ?>
				  <?php if ( $field->published == 1 ) {   $isodd = 1 - $isodd;?>
			      <tr class="<?php echo $trclass[$isodd]; ?>">
			        <td valign="top" align="right"><?php echo JText::_('JS_SHIFT'); ?></td>
			        <td><?php echo $this->lists['shift']; ?></td>
			      </tr>
				   <?php } ?>
				<?php break;
				case "jobsalaryrange":  ?>
			      <?php if ( $field->published == 1 ) { $isodd = 1 - $isodd;?>
				  <tr class="<?php echo $trclass[$isodd]; ?>">
			        <td valign="top" align="right"><?php echo JText::_('JS_SALARYRANGE'); ?></td>
			        <td colspan="53">
					<?php echo $this->lists['currencyid']; ?>&nbsp;&nbsp;&nbsp;
					<?php echo $this->lists['salaryrangefrom']; ?>&nbsp;&nbsp;&nbsp;
					<?php echo $this->lists['salaryrangeto']; ?>&nbsp;&nbsp;&nbsp;
					<?php echo $this->lists['salaryrangetypes']; ?>&nbsp;&nbsp;&nbsp;
				</td>
			      </tr>
					<?php /*
					<tr>
					  <td valign="top" align="right"><?php echo JText::_('JS_HIDE_SALARY'); ?></td>
					  <td><input type='checkbox' name='hidesalaryrange' value='1' <?php if(isset($this->job)) echo ($this->job->hidesalaryrange == "1") ? "checked='checked'" : ""; ?> /></td>
					</tr>
					      */ ?>
				  <?php } ?>
				<?php break;
				case "heighesteducation":  ?>
				    <?php if ( $field->published == 1 ) { $isodd = 1 - $isodd; ?>
					<tr class="<?php echo $trclass[$isodd]; ?>">
					<td valign="top" align="right"><?php echo JText::_('JS_HEIGHEST_EDUCATION'); ?></td>
					<td><?php echo $this->lists['heighesteducation']; ?></td>
					</tr>
					<?php } ?>
				<?php break;
				case "noofjobs":  $isodd = 1 - $isodd; ?>
					<tr class="<?php echo $trclass[$isodd]; ?>">
					<td valign="top" align="right"><label id="noofjobsmsg" for="noofjobs"><?php echo JText::_('JS_NOOFJOBS'); ?></label>&nbsp;<font color="red">*</font></td>
					<td><input class="inputbox  required validate-numeric" type="text" name="noofjobs" id="noofjobs" size="10" maxlength="10" value="<?php if(isset($this->job)) echo $this->job->noofjobs; ?>" />
					</td>
					</tr>
				<?php break;
				case "experience":  ?>
			      <?php if ( $field->published == 1 ) { $isodd = 1 - $isodd;?>
			       <tr class="<?php echo $trclass[$isodd]; ?>">
			        <td valign="top" align="right"><label id="experiencesmsg" for="experience"><?php echo JText::_('JS_EXPERIENCE'); ?></label></td>
			        <td height="31" colspan="53"  valign="top">
					<?php
						if(isset($this->job)) $isexperienceminimax = $this->job->isexperienceminimax; else $isexperienceminimax = 1;
						if ($isexperienceminimax == 1) {
							$experienceminimaxdivstyle = "position:absolute;";
							$experiencerangedivstyle = "visibility:hidden;position:absolute;";
						}else{
							$experienceminimaxdivstyle = "visibility:hidden;position:absolute;";
							$experiencerangedivstyle = "position:absolute;";
						}	
					?>
					<input type="hidden" name="isexperienceminimax" id="isexperienceminimax" value="<?php echo $isexperienceminimax; ?>">
					<div id="experienceminimaxdiv" style="<?php echo $experienceminimaxdivstyle; ?>">
						<?php echo $this->lists['experienceminimax']; ?>&nbsp;&nbsp;&nbsp;
						<?php echo $this->lists['experience']; ?>&nbsp;&nbsp;&nbsp;
						<a  onclick="hideShowRange('experienceminimaxdiv','experiencerangediv','isexperienceminimax',0);"><?php echo JText::_('JS_SPECIFY_RANGE'); ?></a>
					</div>
					<div id="experiencerangediv" style="<?php echo $experiencerangedivstyle; ?>">
						<?php echo $this->lists['minimumexperiencerange']; ?>&nbsp;&nbsp;&nbsp;
						<?php echo $this->lists['maximumexperiencerange']; ?>&nbsp;&nbsp;&nbsp;
						<a onclick="hideShowRange('experiencerangediv','experienceminimaxdiv','isexperienceminimax',1);"><?php echo JText::_('JS_CANCEL_RANGE'); ?></a>						
					</div>
			        </td>
						
			      </tr>
				<?php $isodd = 1 - $isodd;?>
			       <tr class="<?php echo $trclass[$isodd]; ?>">
			        <td valign="top" align="right"></td>
			        <td height="31" colspan="53"  valign="top">
					<input class="inputbox" type="text" name="experiencetext" id="experiencetext" size="30" maxlength="150" value="<?php if(isset($this->job)) echo $this->job->experiencetext; ?>" />
					&nbsp;&nbsp;&nbsp;<?php echo JText::_('JS_ANY_OTHER_EXPERIENCE'); ?>
			        </td>
			      </tr>
				  <?php } ?>
				<?php break;
				case "duration":  ?>
			      <?php if ( $field->published == 1 ) { $isodd = 1 - $isodd; ?>
			       <tr class="<?php echo $trclass[$isodd]; ?>">
			        <td valign="top" align="right"><label id="durationmsg" for="duration"><?php echo JText::_('JS_DURATION'); ?></label></td>
			        <td><input class="inputbox" type="text" name="duration" id="duration" size="10" maxlength="15" value="<?php if(isset($this->job)) echo $this->job->duration; ?>" />
			        <?php echo JText::_('JS_DURATION_DESC'); ?>
					</td>
			      </tr>
				  <?php } ?>
				<?php break;
				case "map":  $isodd = 1 - $isodd;?>
				  <tr class="<?php echo $trclass[$isodd]; ?>">
			        <td width="3%" align="right"><label id="mapmsg" for="map"><?php echo JText::_('JS_MAP'); ?></label></td>
			        <td>
						<div id="map_container"></div>
						<br/><input type="text" id="longitude" name="longitude" value="<?php if(isset($this->job)) echo $this->job->longitude;?>"/><?php echo JText::_('JS_LONGITUDE');?><div id="coordinatebutton"><input type="button" class="button" value="<?php echo JText::_('JS_GET_ADDRESS_FROM_MARKER');?>" onclick="Javascript: loadMap(2,'country','state','county','city');"/></div>
						<br/><input type="text" id="latitude" name="latitude" value="<?php if(isset($this->job)) echo $this->job->latitude;?>"/><?php echo JText::_('JS_LATITTUDE');?><div id="coordinatebutton"><input type="button" class="button" value="<?php echo JText::_('JS_SET_MARKER_FROM_ADDRESS');?>" onclick="Javascript: loadMap(3,'country','state','county','city');"/></div>
			        </td>
			      </tr>
				<?php break;
				case "startpublishing":  $isodd = 1 - $isodd; ?>
					<?php 
						$startdatevalue = '';
						if(isset($this->job)) $startdatevalue = date($this->config['date_format'],strtotime($this->job->startpublishing));
						?>
						<tr class="<?php echo $trclass[$isodd]; ?>">
							<td valign="top" align="right"><label id="startpublishingmsg" for="startpublishing"><?php echo JText::_('JS_START_PUBLISHING'); ?></label>&nbsp;<font color="red">*</font></td>
							<td ><?php if(isset($this->job)){ //edit
								if($jversion == '1.5') { ?> <input class="inputbox required" type="text" name="startpublishing" id="job_startpublishing" readonly class="Shadow Bold" size="10" value="<?php if(isset($this->job)) echo  date($this->config['date_format'],strtotime($this->job->startpublishing)); ?>" />
								<input type="reset" class="button" value="..." onclick="return showCalendar('job_startpublishing','<?php echo $js_dateformat; ?>');"  />
									<?php } else echo JHTML::_('calendar', $startdatevalue,'startpublishing', 'job_startpublishing',$js_dateformat,array('class'=>'inputbox', 'size'=>'10',  'maxlength'=>'19')); ?>
								<?php //}
							}else { 
								if($jversion == '1.5'){ ?><input class="inputbox required" type="text" name="startpublishing" id="job_startpublishing" readonly class="Shadow Bold" size="10" value="<?php if(isset($this->job)) echo  date($this->config['date_format'],strtotime($this->job->startpublishing)); ?>" />
								<input type="reset" class="button" value="..." onclick="return showCalendar('job_startpublishing','<?php echo $js_dateformat; ?>');"  />

								<?php 
								}else	echo JHTML::_('calendar', $startdatevalue,'startpublishing', 'job_startpublishing',$js_dateformat,array('class'=>'inputbox', 'size'=>'10',  'maxlength'=>'19')); ?>

						<?php } ?>
					</td>
					</tr>
				<?php break;
				case "stoppublishing":  $isodd = 1 - $isodd; ?>
					<?php 
						$stopdatevalue = '';
						if(isset($this->job)) $stopdatevalue = date($this->config['date_format'],strtotime($this->job->stoppublishing));
						?>
			       <tr class="<?php echo $trclass[$isodd]; ?>">
			        <td valign="top" align="right"><label id="stoppublishingmsg" for="stoppublishing"><?php echo JText::_('JS_STOP_PUBLISHING'); ?></label>&nbsp;<font color="red">*</font></td>
			        <td ><?php if(isset($this->job)){
                                        if($jversion == '1.5') { ?> <input class="inputbox required" type="text" name="stoppublishing" id="job_stoppublishing" readonly class="Shadow Bold" size="10" value="<?php if(isset($this->job)) echo  date($this->config['date_format'],strtotime($this->job->stoppublishing)); ?>" />
                                        <input type="reset" class="button" value="..." onclick="return showCalendar('job_stoppublishing','<?php echo $js_dateformat; ?>');"  />
                                        <?php }
                                        else  { echo JHTML::_('calendar', $stopdatevalue,'stoppublishing', 'job_stoppublishing',$js_dateformat,array('class'=>'inputbox', 'size'=>'10',  'maxlength'=>'19')); ?>
                                        <?php }
                                }else {
                                        if($jversion == '1.5'){ ?><input class="inputbox required" type="text" name="stoppublishing" id="job_stoppublishing" readonly class="Shadow Bold" size="10" value="<?php if(isset($this->job)) echo  date($this->config['date_format'],strtotime($this->job->stoppublishing)); ?>" />
                                                <input type="reset" class="button" value="..." onclick="return showCalendar('job_stoppublishing','<?php echo $js_dateformat; ?>');"  />

                                        <?php
                                        }else echo JHTML::_('calendar', $stopdatevalue,'stoppublishing', 'job_stoppublishing',$js_dateformat,array('class'=>'inputbox', 'size'=>'10',  'maxlength'=>'19')); ?>

                            <?php   } ?>
				</td>
			      </tr>
				<?php break;
				case "age":  ?>
				<?php if ( $field->published == 1 ) { $isodd = 1 - $isodd;?>
					<tr class="<?php echo $trclass[$isodd]; ?>">
					 <td valign="top" align="right"><label id="agefrommsg" for="agefrom"><?php echo JText::_('JS_AGE'); ?></label><?php if($field->required == 1) echo '&nbsp;<font color="red">*</font>'; ?></td>
					 <td colspan="53"><?php echo $this->lists['agefrom']; ?>&nbsp;&nbsp;&nbsp;
					 <?php echo $this->lists['ageto']; ?>
					 </td>
				       </tr>
				<?php } ?>
				<?php break;
				case "gender":  ?>
				<?php if ( $field->published == 1 ) { $isodd = 1 - $isodd; ?>
					<tr class="<?php echo $trclass[$isodd]; ?>">
					 <td valign="top" align="right"><label id="gendermsg" for="gender"><?php echo JText::_('JS_GENDER'); ?><?php if($field->required == 1) echo '&nbsp;<font color="red">*</font>'; ?></label></td>
					 <td colspan="53"><?php echo $this->lists['gender']; ?></td>
				       </tr>
				<?php } ?>
				<?php break;
				case "careerlevel":  ?>
				<?php if ( $field->published == 1 ) { $isodd = 1 - $isodd;?>
					<tr class="<?php echo $trclass[$isodd]; ?>">
					 <td valign="top" align="right"><label id="careerlevelmsg" for="careerlevel"><?php echo JText::_('JS_CAREER_LEVEL'); ?></label></td>
					 <td colspan="53"><?php echo $this->lists['careerlevel']; ?></td>
				       </tr>
				<?php } ?>

				<?php break;
				case "workpermit":  ?>
				<?php if ( $field->published == 1 ) { $isodd = 1 - $isodd;?>
					<tr class="<?php echo $trclass[$isodd]; ?>">
					 <td valign="top" align="right"><label id="workpermitmsg" for="workpermit"><?php echo JText::_('JS_WORK_PERMIT'); ?></label></td>
					 <td colspan="53"><?php echo $this->lists['workpermit']; ?></td>
				       </tr>
				<?php } ?>
				<?php break;
				case "requiredtravel":  ?>
				<?php if ( $field->published == 1 ) { $isodd = 1 - $isodd;?>
					<tr class="<?php echo $trclass[$isodd]; ?>">
					 <td valign="top" align="right"><label id="requiredtravelmsg" for="requiredtravel"><?php echo JText::_('JS_REQUIRED_TRAVEL'); ?></label></td>
					 <td colspan="53"><?php echo $this->lists['requiredtravel']; ?></td>
				       </tr>
				<?php } ?>

				<?php break;
				case "description": $isodd = 1 - $isodd; ?>
					<?php if ( $this->config['job_editor'] == 1 ) { ?>
							<tr class="<?php echo $trclass[$isodd]; ?>"><td height="10" colspan="54"></td></tr>
							<tr class="<?php echo $trclass[$isodd]; ?>">
								<td colspan="54" valign="top" align="center"><label id="descriptionmsg" for="description"><strong><?php echo JText::_('JS_DESCRIPTION'); ?></strong></label>&nbsp;<font color="red">*</font></td>
							</tr>
							<tr class="<?php echo $trclass[$isodd]; ?>">
								<td colspan="54" align="center">
								<?php
									$editor =& JFactory::getEditor();
									if(isset($this->job))
										echo $editor->display('description', $this->job->description, '550', '300', '60', '20', false);
									else
										echo $editor->display('description', '', '550', '300', '60', '20', false);

								?>	
									<!--<textarea class="inputbox required" name="description" id="description" cols="60" rows="5"><?php if(isset($this->job)) echo $this->job->description; ?></textarea>-->
								</td>
							</tr>
					<?php }else{ ?>
							<tr class="<?php echo $trclass[$isodd]; ?>">
								<td valign="top" align="right"><label id="descriptionmsg" for="description"><?php echo JText::_('JS_DESCRIPTION'); ?></label>&nbsp;<font color="red">*</font></td>
								<td colspan="53"><textarea class="inputbox required" name="description" id="description" cols="60" rows="5"><?php if(isset($this->job)) echo $this->job->description; ?></textarea></td>
							</tr>
					<?php } ?>
					
				<?php break;
				case "qualifications":  $isodd = 1 - $isodd; ?>
	 			    <?php if ( $this->config['job_editor'] == 1 ) { ?>
							<?php if ( $field->published == 1 ) { ?>
							<tr><td height="10" colspan="2"></td></tr>
							<tr class="<?php echo $trclass[$isodd]; ?>">
								<td colspan="2" valign="top" align="center"><label id="qualificationsmsg" for="qualifications"><strong><?php echo JText::_('JS_QUALIFICATIONS'); ?></strong></label></td>
							</tr>
							<tr class="<?php echo $trclass[$isodd]; ?>">
								<td colspan="2" align="center">
								<?php
									$editor =& JFactory::getEditor();
									if(isset($this->job))
										echo $editor->display('qualifications', $this->job->qualifications, '550', '300', '60', '20', false);
									else
										echo $editor->display('qualifications', '', '550', '300', '60', '20', false);

								?>	
								</td>
							</tr>
							<?php } ?>
					<?php }else{ ?>
							<?php if ( $field->published == 1 ) { ?>
							<tr class="<?php echo $trclass[$isodd]; ?>">
								<td valign="top" align="right"><?php echo JText::_('JS_QUALIFICATIONS');?></td>
								<td><textarea class="inputbox" name="qualifications" id="qualifications" cols="60" rows="5"><?php if(isset($this->job)) echo $this->job->qualifications; ?></textarea></td>
							</tr>
							<?php } ?>
					<?php } ?>
				<?php break;
				case "prefferdskills":  $isodd = 1 - $isodd; ?>
	 			    <?php if ( $this->config['job_editor'] == 1 ) { ?>
							<?php if ( $field->published == 1 ) { ?>
							<tr><td height="10" colspan="2"></td></tr>
							<tr class="<?php echo $trclass[$isodd]; ?>">
								<td colspan="2" valign="top" align="center"><label id="prefferdskillsmsg" for="prefferdskills"><strong><?php echo JText::_('JS_PREFFERD_SKILLS'); ?></strong></label></td>
							</tr>
							<tr class="<?php echo $trclass[$isodd]; ?>">
								<td colspan="2" align="center">
								<?php
									$editor =& JFactory::getEditor();
									if(isset($this->job))
										echo $editor->display('prefferdskills', $this->job->prefferdskills, '550', '300', '60', '20', false);
									else
										echo $editor->display('prefferdskills', '', '550', '300', '60', '20', false);
								?>	
								</td>
							</tr>
							<?php } ?>

					<?php }else{ ?>
							<?php if ( $field->published == 1 ) { ?>
							<tr class="<?php echo $trclass[$isodd]; ?>">
								<td valign="top" align="right"><label id="prefferdskillsmsg" for="prefferdskills"><?php echo JText::_('JS_PREFFERD_SKILLS'); ?></label></td>
								<td>
									<textarea class="inputbox" name="prefferdskills" id="prefferdskills" cols="60" rows="5"><?php if(isset($this->job)) echo $this->job->prefferdskills; ?></textarea>
								</td>
							</tr>
							<?php } ?>
					<?php } ?>
				<?php break;
				case "country":  $isodd = 1 - $isodd; ?>
				      <tr class="<?php echo $trclass[$isodd]; ?>">
				        <td align="right"><label id="countrymsg" for="country"><?php echo JText::_('JS_COUNTRY'); ?></label></td>
				        <td id="countrytd">
						      <?php echo $this->lists['country']; ?>
				        </td>
				      </tr>
				<?php break;
				case "state":   ?>
					  <?php if ( $field->published == 1 ) { $isodd = 1 - $isodd;?>
				      <tr class="<?php echo $trclass[$isodd]; ?>">
				        <td align="right"><label id="statemsg" for="state"><?php echo JText::_('JS_STATE'); ?></label></td>
				        <td id="statetd">
						<?php
							if ((isset($this->lists['state'])) && ($this->lists['state']!='')){
								echo $this->lists['state']; 
							} else{ ?>
								<input class="inputbox" type="text" name="state" id="state" size="40" maxlength="100" value="<?php if(isset($this->job)) echo $this->job->state; ?>" />
							<?php } ?>
						</td>
				      </tr>
					  <?php } ?>
				<?php break;
				case "county":  ?>
					  <?php if ( $field->published == 1 ) { $isodd = 1 - $isodd;?>
				      <tr class="<?php echo $trclass[$isodd]; ?>">
				        <td align="right"><label id="countymsg" for="county"><?php echo JText::_('JS_COUNTY'); ?></label></td>
				        <td id="countytd"><?php 
							if ((isset($this->lists['county'])) && ($this->lists['county']!='')){
								echo $this->lists['county']; 
							} else{ ?>
								<input class="inputbox" type="text" name="county" id="county" size="40" maxlength="100" value="<?php if(isset($this->job)) echo $this->job->county; ?>" />
							<?php } ?>
				        </td>
				      </tr>
					  <?php } ?>
				<?php break;
				case "city":   ?>
					  <?php if ( $field->published == 1 ) { $isodd = 1 - $isodd;?>
				      <tr class="<?php echo $trclass[$isodd]; ?>">
				        <td align="right"><label id="citymsg" for="city"><?php echo JText::_('JS_CITY'); ?></label></td>
				        <td id="citytd"><?php 
							if((isset($this->lists['city'])) && ($this->lists['city']!='')){
								echo $this->lists['city']; 
							} else{ ?>
								<input class="inputbox" type="text" name="city" id="city" size="40" maxlength="100" value="<?php if(isset($this->job)) echo $this->job->city; ?>" />
							<?php } ?>
				        </td>
				      </tr>
					  <?php } ?>
				<?php break;
				case "sendemail":  $isodd = 1 - $isodd; ?>
					<tr class="<?php echo $trclass[$isodd]; ?>">
				        <td valign="top" align="right"><?php echo JText::_('JS_SEND_EMAIL'); ?></td>
				        <td ><?php echo $this->lists['sendemail']; ?></td>
				      </tr>
				<?php break;
				case "video": $isodd=1-$isodd; ?>
					<tr class="<?php echo $trclass[$isodd];?>">
					<td valign="top" align="right"><?php echo JText::_('JS_VIDEO');?></td>
			          <td width="60%"><input type="text" name="video" id="video" size="40" maxlength="255" value="<?php if(isset($this->job)) echo $this->job->video; ?>" />
										</tr>
				 <?php break; 
				 case "map": $isodd=1-$isodd;?>
				 <tr class="<?php echo $trclass[$isodd];?>">
				 <td valign="top" align="right"><?php echo JText::_('JS_MAP');?></td>
			          <td width="60%"><input type="text" name="map" id="map" size="40" maxlength="255" value="<?php if(isset($this->job)) echo $this->job->map; ?>" />
				 
				 </tr>
				 <?php break;
				 case "agreement": $isodd=1-$isodd;?>
				 				<?php //echo 'job editor'.$this->config['job_editor'];
					 if ( $this->config['job_editor'] == 1 ) { ?>
							<tr><td height="10" colspan="2"></td></tr>
							<tr class="<?php echo $trclass[$isodd]; ?>">
								<td colspan="2" valign="top" align="center"><label id="agreementmsg" for="agreement"><strong><?php echo JText::_('JS_AGREEMENT'); ?></strong></label></td>
							</tr>
							<tr class="<?php echo $trclass[$isodd]; ?>">
								<td colspan="2" align="center">
								<?php
									$editor =& JFactory::getEditor();
									if(isset($this->job))
										echo $editor->display('agreement', $this->job->agreement, '550', '300', '60', '20', false);
									else
										echo $editor->display('agreement', '', '550', '300', '60', '20', false);

								?>	
									<!--<textarea class="inputbox required" name="description" id="description" cols="60" rows="5"><?php if(isset($this->job)) echo $this->job->agreement; ?></textarea>-->
								</td>
							</tr>
					<?php }else{ ?>
							<tr class="<?php echo $trclass[$isodd]; ?>">
								<td valign="top" align="right"><label id="agreementmsg" for="agreement"><?php echo JText::_('JS_AGREEMENT'); ?></label></td>
								<td><textarea class="inputbox " name="agreement" id="agreement" cols="60" rows="5"><?php if(isset($this->job)) echo $this->job->agreement; ?></textarea></td>
							</tr>
					<?php } ?>
				 <?php break;
				 case "metadescription": $isodd=1-$isodd;?>
							<tr class="<?php echo $trclass[$isodd]; ?>">
								<td valign="top" align="right"><label id="metadescriptionmsg" for="metadescription"><?php echo JText::_('JS_META_DESCRIPTION'); ?></label></td>
								<td><textarea class="inputbox " name="metadescription" id="metadescription" cols="60" rows="5"><?php if(isset($this->job)) echo $this->job->metadescription; ?></textarea></td>
							</tr>
					
				 <?php break;
				  case "metakeywords": $isodd=1-$isodd;?>
				  				
							<tr class="<?php echo $trclass[$isodd]; ?>">
								<td valign="top" align="right"><label id="metakeywordsmsg" for="metakeywords"><?php echo JText::_('JS_META_KEYWORDS'); ?></label></td>
								<td><textarea class="inputbox " name="metakeywords" id="metakeywords" cols="60" rows="5"><?php if(isset($this->job)) echo $this->job->metakeywords; ?></textarea></td>
							</tr>
					
					 <?php break;
				default:
					//echo '<br> default uf '.$filed->field;
			        if ( $field->published == 1 ) { 
						foreach($this->userfields as $ufield){ 
							if($field->field == $ufield[0]->id) {
								$userfield = $ufield[0];
								$i++;
								$isodd = 1 - $isodd; 
								echo "<tr class='".$trclass[$isodd]."'><td valign='top' align='right'>";
								if($userfield->required == 1){
									echo "<label id=".$userfield->name."msg for=$userfield->name>$userfield->title</label>&nbsp;<font color='red'>*</font>";
									$cssclass = "class ='inputbox required' ";
								}else{
									echo $userfield->title; $cssclass = "class='inputbox' ";
								}
								echo "</td><td>"	;
									
								$readonly = $userfield->readonly ? ' readonly="readonly"' : '';
		   						$maxlength = $userfield->maxlength ? 'maxlength="'.$userfield->maxlength.'"' : '';
								if(isset($ufield[1])){ $fvalue = $ufield[1]->data; $userdataid = $ufield[1]->id;}  else {$fvalue=""; $userdataid = ""; }
								echo '<input type="hidden" id="userfields_'.$i.'_id" name="userfields_'.$i.'_id"  value="'.$userfield->id.'"  />';
								echo '<input type="hidden" id="userdata_'.$i.'_id" name="userdata_'.$i.'_id"  value="'.$userdataid.'"  />';
								switch( $userfield->type ) {
									case 'text':
										echo '<input type="text" id="userfields_'.$i.'" name="userfields_'.$i.'" size="'.$userfield->size.'" value="'. $fvalue .'" '.$cssclass .$maxlength . $readonly . ' />';
										break;
									case 'textarea':
										echo '<textarea name="userfields_'.$i.'" id="userfields_'.$i.'_field" cols="'.$userfield->cols.'" rows="'.$userfield->rows.'" '.$readonly.'>'.$fvalue.'</textarea>';
										break;	
									case 'checkbox':
										echo '<input type="checkbox" name="userfields_'.$i.'" id="userfields_'.$i.'_field" value="1" '.  'checked="checked"' .'/>';
										break;	
									case 'select':
										$htm = '<select name="userfields_'.$i.'" id="userfields_'.$i.'" >';
										if (isset ($ufield[2])){
											foreach($ufield[2] as $opt){
												if ($opt->id == $fvalue)
													$htm .= '<option value="'.$opt->id.'" selected="yes">'. $opt->fieldtitle .' </option>';
												else
													$htm .= '<option value="'.$opt->id.'">'. $opt->fieldtitle .' </option>';
											}
										}
										$htm .= '</select>';	
										echo $htm;
								}
								echo '</td></tr>';
							}
						}
					}			

			}
			
		} 
		echo '<input type="hidden" id="userfields_total" name="userfields_total"  value="'.$i.'"  />';
		?>
	  
			<?php  if(isset($this->job)) {  $isodd = 1 - $isodd; ?>
			  <tr class="<?php echo $trclass[$isodd]; ?>">
				<td align="right"><label id="statusmsg" for="status"><?php echo JText::_('JS_STATUS'); ?></label></td>
				<td><?php  echo $this->lists['status']; ?>
				</td>
			  </tr>
			<?php }else { ?>
				<input type="hidden" name="status" value="1" />
			<?php } ?>	
	<tr>
		<td colspan="2" align="center">
		<input class="button" type="submit" name="submit_app" onclick="return validate_form(document.adminForm)" value="<?php echo JText::_('JS_SAVE_JOB'); ?>" />
		</td>
	</tr>

			    </table>
			<?php 	
				if(isset($this->job)) {
					$uid = $this->job->uid;
					if (($this->job->created=='0000-00-00 00:00:00') || ($this->job->created==''))
						$curdate = date('Y-m-d H:i:s');
					else  
						$curdate = $this->job->created;
				}else{
					$uid = $this->uid;
					$curdate = date('Y-m-d H:i:s');
				}	
				
			?>
			<input type="hidden" name="created" value="<?php echo $curdate; ?>" />
			<input type="hidden" name="view" value="jobposting" />
			<input type="hidden" name="check" value="" />
			<input type="hidden" name="layout" value="viewjob" />
			<input type="hidden" name="uid" value="<?php echo $uid; ?>" />
			<input type="hidden" name="option" value="<?php echo $this->option; ?>" />
			<input type="hidden" name="task" value="savejob" />
			
		  <input type="hidden" name="id" value="<?php if(isset($this->job)) echo $this->job->id; ?>" />
		  <input type="hidden" name="default_longitude" id="default_longitude" value="<?php echo $this->config['default_longitude']; ?>" />
		  <input type="hidden" name="default_latitude" id="default_latitude" value="<?php  echo $this->config['default_latitude']; ?>" />

<script language=Javascript>
function dochange(src, val){
	var xhr; 
	try {  xhr = new ActiveXObject('Msxml2.XMLHTTP');   }
	catch (e) 
	{
		try {   xhr = new ActiveXObject('Microsoft.XMLHTTP');    }
		catch (e2) 
		{
		  try {  xhr = new XMLHttpRequest();     }
		  catch (e3) {  xhr = false;   }
		}
	 }

	xhr.onreadystatechange = function(){
      if(xhr.readyState == 4 && xhr.status == 200){
        	document.getElementById(src+'td').innerHTML=xhr.responseText; //retuen value

			if(src=='state'){
				countyhtml = "<input class='inputbox' type='text' name='county' id='county' size='40' maxlength='100'  />";
				cityhtml = "<input class='inputbox' type='text' name='city' id='city' size='40' maxlength='100'  />";
				document.getElementById('countytd').innerHTML=countyhtml; //retuen value
				document.getElementById('citytd').innerHTML=cityhtml; //retuen value
			}else if(src=='county'){
				cityhtml = "<input class='inputbox' type='text' name='city' id='city' size='40' maxlength='100'  />";
				document.getElementById('citytd').innerHTML=cityhtml; //retuen value
			}
      }
    }
 
	xhr.open("GET","index.php?option=com_jsjobs&task=listaddressdata&data="+src+"&val="+val,true);
	xhr.send(null);
}
			//window.onLoad=dochange('country', -1);         // value in first dropdown
			
			
function getdepartments(src, val){
	document.getElementById(src).innerHTML="Loading ...";
	var xhr; 
	try {  xhr = new ActiveXObject('Msxml2.XMLHTTP');   }
	catch (e) {
		try {   xhr = new ActiveXObject('Microsoft.XMLHTTP');    }
		catch (e2) {
		  try {  xhr = new XMLHttpRequest();     }
		  catch (e3) {  xhr = false;   }
		}
	 }

	xhr.onreadystatechange = function(){
		if(xhr.readyState == 4 && xhr.status == 200){
			document.getElementById(src).innerHTML=xhr.responseText; //retuen value
		}
	}
 
	xhr.open("GET","index.php?option=com_jsjobs&task=listsubcategories&val="+val,true);
	xhr.send(null);
}
			
function fj_getsubcategories(src, val){
	var xhr;
	try {  xhr = new ActiveXObject('Msxml2.XMLHTTP');   }
	catch (e){
		try {   xhr = new ActiveXObject('Microsoft.XMLHTTP');    }
		catch (e2) {
		  try {  xhr = new XMLHttpRequest();     }
		  catch (e3) {  xhr = false;   }
		}
	 }

	xhr.onreadystatechange = function(){
            if(xhr.readyState == 4 && xhr.status == 200){
        	document.getElementById(src).innerHTML=xhr.responseText; //retuen value
            }
        }

	xhr.open("GET","index.php?option=com_jsjobs&task=listsubcategories&val="+val,true);
	xhr.send(null);
}


			
	</script>

				
			  </form>
		</td>
	</tr>
	<tr>
		<td colspan="2" align="left" width="100%"  valign="top">
			<table width="100%" style="table-layout:fixed;"><tr><td style="vertical-align:top;"><?php echo eval(base64_decode('CQkJZWNobyAnPHRhYmxlIHdpZHRoPSIxMDAlIiBzdHlsZT0idGFibGUtbGF5b3V0OmZpeGVkOyI+DQo8dHI+PHRkIGhlaWdodD0iMTUiPjwvdGQ+PC90cj4NCjx0cj4NCjx0ZCBzdHlsZT0idmVydGljYWwtYWxpZ246bWlkZGxlOyIgYWxpZ249ImNlbnRlciI+DQo8YSBocmVmPSJodHRwOi8vd3d3Lmpvb21za3kuY29tIiB0YXJnZXQ9Il9ibGFuayI+PGltZyBzcmM9Imh0dHA6Ly93d3cuam9vbXNreS5jb20vbG9nby9qc2pvYnNjcmxvZ28ucG5nIiA+PC9hPg0KPGJyPg0KQ29weXJpZ2h0ICZjb3B5OyAyMDA4IC0gJy4gZGF0ZSgnWScpIC4nLCA8YSBocmVmPSJodHRwOi8vd3d3LmJ1cnVqc29sdXRpb25zLmNvbSIgdGFyZ2V0PSJfYmxhbmsiPkJ1cnVqIFNvbHV0aW9uczwvYT4gDQo8L3RkPg0KPC90cj4NCjwvdGFibGU+JzsNCg=='));	?>	</td></tr></table>
		</td>
	</tr>
	
</table>				
<style type="text/css">
div#map_container{
	width:100%;
	height:350px;
}
</style>
<script type="text/javascript" 
   src="http://maps.googleapis.com/maps/api/js?sensor=false"></script>
 
<script type="text/javascript">
  function loadMap(callfrom,country,state,county,city) {
		var longitude = document.getElementById('longitude').value;
		var default_latitude = document.getElementById('default_latitude').value;
		var default_longitude = document.getElementById('default_longitude').value;
		var latitude = document.getElementById('latitude').value;
		if(longitude != '' && latitude != ''){ var latlng = new google.maps.LatLng(latitude, longitude); zoom = 12;}
		else {var latlng = new google.maps.LatLng(default_latitude, default_longitude); zoom=4;}
		var myOptions = {
		  zoom: zoom,
		  center: latlng,
		  mapTypeId: google.maps.MapTypeId.ROADMAP
		};
		var map = new google.maps.Map(document.getElementById("map_container"),myOptions);
		var lastmarker = new google.maps.Marker({
			postiion:latlng,
			map:map,
		});
		if(callfrom == 1){
			var marker = new google.maps.Marker({
			  position: latlng, 
			  map: map, 
			});
			document.getElementById('longitude').value = marker.position.lng();
			document.getElementById('latitude').value = marker.position.lat();
			marker.setMap(map);
			lastmarker = marker;
		}
	google.maps.event.addListener(map,"click", function(e){
		var latLng = new google.maps.LatLng(e.latLng.lat(),e.latLng.lng());
		geocoder = new google.maps.Geocoder();
		geocoder.geocode( { 'latLng': latLng}, function(results, status) {
		  if (status == google.maps.GeocoderStatus.OK) {
			lastmarker.setMap(null);
			var marker = new google.maps.Marker({
				position: results[0].geometry.location, 
				map: map, 
			});
			marker.setMap(map);
			lastmarker = marker;
			document.getElementById('latitude').value = marker.position.lat();
			document.getElementById('longitude').value = marker.position.lng();
			
		  } else {
			alert("Geocode was not successful for the following reason: " + status);
		  }
		});
	}); 


	if(callfrom == 3){
		var value='';var zoom=4;
		if(country != ''){
			var field = document.getElementById(country);
			value = field.options[field.selectedIndex].text;
		}
		if(state != ''){
			var field = document.getElementById(state);
			if(field.type == "text"){ if(field.value !=''){ value = field.value+", "+value;zoom+=2;}}
			else{ value = field.options[field.selectedIndex].text+", "+value;zoom+=2;}
		}
		if(county != ''){
			var field = document.getElementById(county);
			if(field.type == "text"){ if(field.value !=''){ value = field.value+", "+value;zoom+=2;}}
			else{ value = field.options[field.selectedIndex].text+", "+value;zoom+=2;}
		}
		if(city != ''){
			var field = document.getElementById(city);
			if(field.type == "text"){ if(field.value !=''){ value = field.value+", "+value;zoom+=2;}}
			else{ value = field.options[field.selectedIndex].text+", "+value;zoom+=2;}
		}
		if(value != ''){
			geocoder = new google.maps.Geocoder();
			geocoder.geocode( { 'address': value}, function(results, status) {
			  if (status == google.maps.GeocoderStatus.OK) {
				map.setCenter(results[0].geometry.location);
				document.getElementById('latitude').value = results[0].geometry.location.lat();
				document.getElementById('longitude').value = results[0].geometry.location.lng();
				map.setZoom(zoom);
				lastmarker.setMap(null);
				var marker = new google.maps.Marker({
				position: results[0].geometry.location, 
				map: map, 
				});
				marker.setMap(map);
				lastmarker = marker;
			  } else {
				alert("Geocode was not successful for the following reason: " + status);
			  }
			});
		}
	}
	if(callfrom == 2){
		var latLng = new google.maps.LatLng(latitude,longitude);
		geocoder = new google.maps.Geocoder();
		geocoder.geocode( { 'latLng': latLng}, function(results, status) {
		  if (status == google.maps.GeocoderStatus.OK) {
			lastmarker.setMap(null);
			var marker = new google.maps.Marker({
				position: results[0].geometry.location, 
				map: map, 
			});
			map.setZoom(12);
			marker.setMap(map);
			lastmarker = marker;
			var address = results[1].formatted_address;
			var xhr;
			try {  xhr = new ActiveXObject('Msxml2.XMLHTTP');   }
			catch (e){
				try {   xhr = new ActiveXObject('Microsoft.XMLHTTP');    }
				catch (e2) {
				  try {  xhr = new XMLHttpRequest();     }
				  catch (e3) {  xhr = false;   }
				}
			 }
			xhr.onreadystatechange = function(){
					if(xhr.readyState == 4 && xhr.status == 200){
						var obj = eval("("+xhr.responseText+")");
						document.getElementById('country').value = obj.countrycode;
						document.getElementById('statetd').innerHTML = obj.states;
						document.getElementById('countytd').innerHTML = obj.counties;
						document.getElementById('citytd').innerHTML = obj.city;
					}
				}

			xhr.open("GET","index.php?option=com_jsjobs&task=getaddressdata&val="+address,true);
			xhr.send(null);
		}
		});
	}
}
</script>
<script type="text/javascript" src="<?php echo JURI::root();?>components/com_jsjobs/js/jquery-1.2.6.pack.js"></script>
<script type="text/javascript">
	loadMap(1,'','','','');
</script>
