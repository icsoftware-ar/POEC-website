<?php
/**
 * @Copyright Copyright (C) 2010- ... Ahmad Bilal
 * @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
 * Company:		Al-Barr Technologies
 + Contact:		www.al-barr.com , info@al-barr.com
 * Created on:	Jan 11, 2009
 ^
 + Project: 		JS Jobs
 * File Name:	admin-----/controllers/jsjobs.php
 ^ 
 * Description: Controller class for admin site
 ^ 
 * History:		NONE
 ^ 
 */

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controller');

class JSJobsControllerJsjobs extends JControllerLegacy
{

	function __construct()
	{
		parent :: __construct();

		$this->registerTask('add', 'edit');
	}
	
	
        function editsubcategories(){
            JRequest :: setVar('layout', 'formsubcategory');
            JRequest :: setVar('view', 'application');
            $this->display();
        }
	function edit()
	{
		$cur_layout = $_SESSION['cur_layout'];
		JRequest :: setVar('view', 'application');
		JRequest :: setVar('hidemainmenu', 1);
		
		if ($cur_layout == 'categories') JRequest :: setVar('layout', 'formcategory');
		elseif ($cur_layout == 'jobtypes') JRequest :: setVar('layout', 'formjobtype');
		elseif ($cur_layout == 'ages') JRequest :: setVar('layout', 'formages');
		elseif ($cur_layout == 'careerlevels') JRequest :: setVar('layout', 'formcareerlevels');
		elseif ($cur_layout == 'experience') JRequest :: setVar('layout', 'formexperience');
		elseif ($cur_layout == 'jobstatus') JRequest :: setVar('layout', 'formjobstatus');
		elseif ($cur_layout == 'shifts') JRequest :: setVar('layout', 'formshift');
		elseif ($cur_layout == 'salaryrangetype') JRequest :: setVar('layout', 'formsalaryrangetype');
		elseif ($cur_layout == 'highesteducations') JRequest :: setVar('layout', 'formhighesteducation');
		elseif (($cur_layout == 'companies') || ($cur_layout == 'companiesqueue'))
			JRequest :: setVar('layout', 'formcompany');	
		elseif (($cur_layout == 'folders') || ($cur_layout == 'foldersqueue'))
			JRequest :: setVar('layout', 'formfolder');
		elseif (($cur_layout == 'jobs') || ($cur_layout == 'jobqueue'))
			JRequest :: setVar('layout', 'formjob');	
		elseif (($cur_layout == 'empapps') || ($cur_layout == 'appqueue'))
			JRequest :: setVar('layout', 'formresume');	
		elseif ($cur_layout == 'salaryrange')
			JRequest :: setVar('layout', 'formsalaryrange');	
		elseif ($cur_layout == 'userfields')
			JRequest :: setVar('layout', 'formuserfield');	
		elseif ($cur_layout == 'resumeuserfields')
			JRequest :: setVar('layout', 'formresumeuserfield');	
		elseif ($cur_layout == 'roles')	JRequest :: setVar('layout', 'formrole');	
		elseif ($cur_layout == 'users')	JRequest :: setVar('layout', 'changerole');	
		elseif ($cur_layout == 'countries')	JRequest :: setVar('layout', 'formcountry');	
		elseif ($cur_layout == 'states')	JRequest :: setVar('layout', 'formstate');	
		elseif ($cur_layout == 'counties')	JRequest :: setVar('layout', 'formcounty');	
		elseif ($cur_layout == 'cities')	JRequest :: setVar('layout', 'formcity');	
		elseif ($cur_layout == 'employerpackages')	JRequest :: setVar('layout', 'formemployerpackage');	
		elseif ($cur_layout == 'jobseekerpackages')	JRequest :: setVar('layout', 'formjobseekerpackage');
		elseif (($cur_layout == 'message_history') || ($cur_layout == 'messages')|| ($cur_layout == 'jobappliedresume')){
                    JRequest :: setVar('layout', 'formmessage');
                    JRequest :: setVar('sm', JRequest :: getVar('sm'));
                    }
		//elseif (($cur_layout == 'featuredjobs') || ($cur_layout == 'featuredjobsqueue'))	JRequest :: setVar('layout', 'formfeaturedjob');
		//elseif (($cur_layout == 'featuredcompanies')|| ($cur_layout == 'featuredcompaniesqueue'))JRequest :: setVar('layout', 'formfeaturedcompany');	
		elseif (( $cur_layout == 'goldjobs')	|| ($cur_layout == 'goldjobsqueue')){
			if (isset($_GET['cid'][0])) 	$c_id= $_GET['cid'][0];	else $c_id='';	
			if ($c_id == ''){$cids = JRequest :: getVar('cid', array (0), 'post', 'array'); $c_id= $cids[0]; }
			if ($c_id ==''){
				JRequest :: setVar('layout', 'addtogoldjobs');
				JRequest :: setVar('view', 'applications');
			}else JRequest :: setVar('layout', 'formgoldjob');
		}	
		elseif( ( $cur_layout == 'featuredjobs') || ($cur_layout == 'featuredjobsqueue') )	{
			if (isset($_GET['cid'][0])) 	$c_id= $_GET['cid'][0];	else $c_id='';	
			if ($c_id == ''){$cids = JRequest :: getVar('cid', array (0), 'post', 'array'); $c_id= $cids[0]; }
			if ($c_id ==''){
				JRequest :: setVar('layout', 'addtofeaturedjobs');
				JRequest :: setVar('view', 'applications');
			}else JRequest :: setVar('layout', 'formfeaturedjob');
		}	
		elseif( ( $cur_layout == 'featuredcompanies') || ($cur_layout == 'featuredcompaniesqueue') )	{
			if (isset($_GET['cid'][0])) 	$c_id= $_GET['cid'][0];	else $c_id='';	
			if ($c_id == ''){$cids = JRequest :: getVar('cid', array (0), 'post', 'array'); $c_id= $cids[0]; }
			if ($c_id ==''){
				JRequest :: setVar('layout', 'addtofeaturedcompanies');
				JRequest :: setVar('view', 'applications');
			}else JRequest :: setVar('layout', 'formfeaturedcompany');
		}elseif( ( $cur_layout == 'goldcompanies') || ($cur_layout == 'goldcompaniesqueue') )	{
			if (isset($_GET['cid'][0])) 	$c_id= $_GET['cid'][0];	else $c_id='';	
			if ($c_id == ''){$cids = JRequest :: getVar('cid', array (0), 'post', 'array'); $c_id= $cids[0]; }
			if ($c_id ==''){
				JRequest :: setVar('layout', 'addtogoldcompanies');
				JRequest :: setVar('view', 'applications');
			}else JRequest :: setVar('layout', 'formgoldcompany');
		}elseif( ( $cur_layout == 'featuredresumes') || ($cur_layout == 'featuredresumesqueue') )	{
			if (isset($_GET['cid'][0])) 	$c_id= $_GET['cid'][0];	else $c_id='';	
			if ($c_id == ''){$cids = JRequest :: getVar('cid', array (0), 'post', 'array'); $c_id= $cids[0]; }
			if ($c_id ==''){
				JRequest :: setVar('layout', 'addtofeaturedresumes');
				JRequest :: setVar('view', 'applications');
			}else JRequest :: setVar('layout', 'formfeaturedresume');
		}elseif( ( $cur_layout == 'goldresumes') || ($cur_layout == 'goldresumesqueue') )	{
			if (isset($_GET['cid'][0])) 	$c_id= $_GET['cid'][0];	else $c_id='';	
			if ($c_id == ''){$cids = JRequest :: getVar('cid', array (0), 'post', 'array'); $c_id= $cids[0]; }
			if ($c_id ==''){
				JRequest :: setVar('layout', 'addtogoldresumes');
				JRequest :: setVar('view', 'applications');
			}else JRequest :: setVar('layout', 'formgoldresume');
		}					
		//elseif ( ($cur_layout == 'goldjobs')	|| ($cur_layout == 'goldjobsqueue'))JRequest :: setVar('layout', 'formgoldjob');
		elseif (($cur_layout == 'goldresumes')	|| ($cur_layout == 'goldresumesqueue'))JRequest :: setVar('layout', 'formgoldresume');
		//elseif (($cur_layout == 'featuredresumes')|| ($cur_layout == 'featuredresumesqueue'))JRequest :: setVar('layout', 'formfeaturedresume');
		//elseif (($cur_layout == 'goldcompanies') || ($cur_layout == 'goldcompaniesqueue'))	JRequest :: setVar('layout', 'formgoldcompany');
		elseif (($cur_layout == 'departments')	|| ($cur_layout == 'departmentqueue'))JRequest :: setVar('layout', 'formdepartment');
		elseif ($cur_layout == 'currency') JRequest :: setVar('layout', 'formcurrency');
		elseif ($cur_layout == 'jobseekerpaymenthistory') JRequest :: setVar('layout', 'assignpackage');
		elseif ($cur_layout == 'employerpaymenthistory') JRequest :: setVar('layout', 'assignpackage');

		
		//parent :: display();
		$this->display();
	}

        function getmyforlders()  {
            global $mainframe;
			$mainframe = &JFactory::getApplication();
		
            $user=& JFactory::getUser();
            $uid=$user->id;
            $jobid=JRequest::getVar( 'jobid');
            $resumeid=JRequest::getVar( 'resumeid');

            $model = $this->getModel('jsjobs', 'JSJobsModel');
            $returnvalue = $model->getMyFoldersAJAX($uid, $jobid, $resumeid);

            echo $returnvalue;
            $mainframe->close();
        }
        function getresumecomments()  {
            global $mainframe;
         	$mainframe = &JFactory::getApplication();

            $jobapplyid=JRequest::getVar( 'jobapplyid');
            $model = $this->getModel('jsjobs', 'JSJobsModel');
            $returnvalue = $model->getResumeCommentsAJAX($jobapplyid);

            echo $returnvalue;
            $mainframe->close();
        }
/* STRAT EXPORT RESUMES */
	function exportresume(){
		$jobid =  JRequest::getVar('bd');
		$model =  $this->getModel('jsjobs','JSJobsModel');
		$return_value = $model->setExport($jobid);
		if($return_value == true){
			$msg = JText ::_('JS_RESUME_EXPORT');
			// Push the report now!
			$this->name = 'export-resume';
			header("Content-type: application/octet-stream");
			header("Content-Disposition: attachment; filename=".$this->name.".xls");
			header("Pragma: no-cache");
			header("Expires: 0");
			header("Lacation: excel.htm?id=yes");
			print $return_value ;
			die();   
		}else{
			$msg = JText ::_('JS_RESUME_NOT_EXPORT');
		}		
		$link = 'index.php?option=com_jsjobs&c=jsjobs&task=view&layout=jobappliedresume&oi='.$jobid;
		$this->setRedirect($link, $msg);
	}
/* END EXPORT RESUMES */
        function saveresumerating()  {
            global $mainframe;
		    $mainframe = &JFactory::getApplication();
            $user=& JFactory::getUser();
            $uid=$user->id;
            $ratingid=JRequest::getVar( 'ratingid');
            $jobid=JRequest::getVar( 'jobid');
            $resumeid=JRequest::getVar( 'resumeid');
            $newrating=JRequest::getVar( 'newrating');
            $model = $this->getModel('jsjobs', 'JSJobsModel');
            $returnvalue = $model->storeResumeRating($uid,$ratingid,$jobid,$resumeid,$newrating);
            
            echo $returnvalue;
            $mainframe->close();

        }
        function saveresumefolder() // save folder
	{
		global $mainframe;
		$data = JRequest :: get('post');
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->storeFolderResume();
		$link = 'index.php?option=com_jsjobs&c=jsjobs&task=view&layout=jobappliedresume&oi='.$data['jobid'];
		if ($return_value == 1)	{ $msg = JText :: _('JS_RESUME_SAVE_FOLDER');
		}elseif($return_value == 3){
                    $msg = JText::_('JS_RESUME_ALREADY_EXISTS_IN_FOLDER' );
                }else{	$msg = JText :: _('JS_ERROR_SAVING_RESUME_FOLDER');
		}
		$this->setRedirect($link, $msg);

	}
        function saveresumecomments() // save resume comments
	{
		global $mainframe;
		$data = JRequest :: get('post');
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->storeResumeComments();
		$link = 'index.php?option=com_jsjobs&c=jsjobs&task=view&layout=jobappliedresume&oi='.$data['jobid'];
		if ($return_value == 1)	{ $msg = JText :: _('JS_RESUME_COMMENTS_SAVE');
		}else{	$msg = JText :: _('JS_ERROR_SAVING_RESUME_RESUME_COMMENTS');
		}
		$this->setRedirect($link, $msg);

	}
	function actionresume() //save shortlist candidate
	{
		global $mainframe;

		$model = $this->getModel('jsjobs', 'JSJobsModel');

		$user	=& JFactory::getUser();
		$uid = $user->id;
		$data = JRequest :: get('post');
                $jobid=$data['jobid'];
                $resumeid=$data['resumeid'];
                //echo $jobid;
                //echo 'ac '.$data['action'];
		if($data['action'] == 1){ // short list
                    $return_value = $model->storeShortListCandidatee($uid);
                    if ($return_value == 1) $msg = JText :: _('JS_SHORT_LIST_CANDIDATE_SAVED');
                    elseif ($return_value == 2) $msg = JText :: _('JS_FILL_REQ_FIELDS');
                    elseif ($return_value == 3) $msg = JText :: _('JS_ALLREADY_SHORTLIST_THIS_CANDIDATE');
                    else $msg = JText :: _($return_value.'JS_ERROR_SAVING_SHORT_LIST_CANDIDATE');
                    $link = 'index.php?option=com_jsjobs&c=jsjobs&view=applications&layout=jobappliedresume&oi='.$jobid;
		}elseif($data['action'] == 2){ // send message
                    $link = 'index.php?option=com_jsjobs&c=jsjobs&view=application&layout=formmessage&bd='.$data['jobid'].'&rd='.$data['resumeid'];
                }
		$this->setRedirect($link, $msg);
	}
	function listsearchaddressdata()
	  { 
			global $mainframe;
			$mainframe = &JFactory::getApplication();
			$data=JRequest::getVar( 'data');
			$val=JRequest::getVar( 'val');
			$model = $this->getModel('jsjobs', 'JSJobsModel');
			$returnvalue = $model->listSearchAddressData($data, $val);
			echo $returnvalue;
			$mainframe->close();
	  }
	  
	function jobenforcedelete()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''	, 'array' );
		$jobid = $cid[0];
		$user	=& JFactory::getUser();
		$uid=$user->id;
		$return_value = $model->jobEnforceDelete($jobid, $uid);
		if ($return_value == 1)	{
			$msg = JText::_('JS_JOB_DELETED');
		}elseif ($return_value == 2){
			$msg = JText::_('JS_ERROR_IN_DELETING_JOB');
		}elseif ($return_value == 3){
			$msg = JText::_('JS_THIS_JOB_IS_NOT_OF_THIS_USER');
		}
		$link = 'index.php?option=com_jsjobs&task=view&layout=jobs';
		$this->setRedirect($link, $msg);
	}
	
	function companyenforcedelete()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$companyid = $cid[0];
		$user	=& JFactory::getUser();
		$uid=$user->id;
		$return_value = $model->companyEnforceDelete($companyid, $uid);
		if ($return_value == 1)	{
			$msg = JText::_('JS_COMPANY_DELETED');
		}elseif ($return_value == 2){
			$msg = JText::_('JS_ERROR_IN_DELETING_COMPANY');
		}elseif ($return_value == 3){
			$msg = JText::_('JS_THIS_COMPANY_IS_NOT_OF_THIS_USER');
		}
		$link = 'index.php?option=com_jsjobs&task=view&layout=companies';
		$this->setRedirect($link, $msg);
	}
	
        function folderenforcedelete()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$folderid = $cid[0];
		$user	=& JFactory::getUser();
		$uid=$user->id;
		$return_value = $model->folderEnforceDelete($folderid, $uid);
		if ($return_value == 1)	{
			$msg = JText::_('JS_FOLDER_DELETED');
		}elseif ($return_value == 2){
			$msg = JText::_('JS_ERROR_IN_DELETING_FOLDER');
		}elseif ($return_value == 3){
			$msg = JText::_('JS_THIS_FOLDER_IS_NOT_OF_THIS_USER');
		}
		$link = 'index.php?option=com_jsjobs&task=view&layout=folders';
		$this->setRedirect($link, $msg);
	}
	function resumeenforcedelete()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$resumeid = $cid[0];
		$user	=& JFactory::getUser();
		$uid=$user->id;
		$return_value = $model->resumeEnforceDelete($resumeid, $uid);
		if ($return_value == 1)	{
			$msg = JText::_('JS_RESUME_DELETED');
		}elseif ($return_value == 2){
			$msg = JText::_('JS_ERROR_IN_DELETING_RESUME');
		}elseif ($return_value == 3){
			$msg = JText::_('JS_THIS_RESUME_IS_NOT_OF_THIS_USER');
		}
		$link = 'index.php?option=com_jsjobs&task=view&layout=empapps';
		$this->setRedirect($link, $msg);
	}
	
	function deletecategoryandsubcategory(){       // delete category and subcategory
		
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$returnvalue = $model->deleteCategoryAndSubcategory();
	
		if ($returnvalue == 1){
			$msg = JText::_('JS_CATEGORY_AND_SUBCATEGORY_DELETED');
		}else{
			$msg = $returnvalue -1 .' '. JText::_('JS_ERROR_CATEGORY_AND_SUBCATEGORY_COULD_NOT_DELETE');
		}
		$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=categories', $msg);
	}
	
	
	function companyapprove()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$companyid = $cid[0];
		$return_value = $model->companyApprove($companyid);
		if ($return_value == 1)	{
			$msg = JText::_('JS_COMPANY_APPROVED');
		}else
			$msg = JText::_('JS_ERROR_IN_APPROVING_COMPANY');
			
		$link = 'index.php?option=com_jsjobs&task=view&layout=companiesqueue';
		$this->setRedirect($link, $msg);
	}

	function companyreject()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$companyid = $cid[0];
		
		$return_value = $model->companyReject($companyid);
		if ($return_value == 1)	{
			$msg = JText::_('JS_COMPANY_REJECTED');
		}else
			$msg = JText::_('JS_ERROR_IN_REJECTING_COMPANY');
			
		$link = 'index.php?option=com_jsjobs&task=view&layout=companiesqueue';
		$this->setRedirect($link, $msg);
	}
	function folderapprove()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$folderid = $cid[0];
		$return_value = $model->folderApprove($folderid);
		if ($return_value == 1)	{
			$msg = JText::_('JS_FOLDER_APPROVED');
		}else
			$msg = JText::_('JS_ERROR_IN_APPROVING_FOLDER');

		$link = 'index.php?option=com_jsjobs&task=view&layout=foldersqueue';
		$this->setRedirect($link, $msg);
	}

	function folderreject()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$folderid = $cid[0];

		$return_value = $model->folderReject($folderid);
		if ($return_value == 1)	{
			$msg = JText::_('JS_FOLDER_REJECTED');
		}else
			$msg = JText::_('JS_ERROR_IN_REJECTING_FOLDER');

		$link = 'index.php?option=com_jsjobs&task=view&layout=foldersqueue';
		$this->setRedirect($link, $msg);
	}


	function departmentapprove()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$departmentid = $cid[0];
		$return_value = $model->departmentApprove($departmentid);
		if ($return_value == 1)	{
			$msg = JText::_('JS_DEPARTMENT_APPROVED');
		}else
			$msg = JText::_('JS_ERROR_IN_APPROVING_DEPARTMENT');
			
		$link = 'index.php?option=com_jsjobs&task=view&layout=departmentqueue';
		$this->setRedirect($link, $msg);
	}
	function departmentreject()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$departmentid = $cid[0];
		
		$return_value = $model->departmentReject($departmentid);
		if ($return_value == 1)	{
			$msg = JText::_('JS_DEPARTMENT_REJECTED');
		}else
			$msg = JText::_('JS_ERROR_IN_REJECTING_DEPARTMENT');
			
		$link = 'index.php?option=com_jsjobs&task=view&layout=departmentqueue';
		$this->setRedirect($link, $msg);
	}
	
// Payment System Start
	function featuredcompanyapprove()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$companyid = $cid[0];
		$return_value = $model->featuredCompanyApprove($companyid);
		if ($return_value == 1)	{
			$msg = JText::_('JS_FETAURED_COMPANY_APPROVED');
		}else
			$msg = JText::_('JS_ERROR_IN_APPROVING_FEATURED_COMPANY');
			
		$link = 'index.php?option=com_jsjobs&task=view&layout=featuredcompanies';
		$this->setRedirect($link, $msg);
	}
	function featuredcompanyreject()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$companyid = $cid[0];
		
		$return_value = $model->featuredCompanyReject($companyid);
		if ($return_value == 1)	{
			$msg = JText::_('JS_FEATURED_COMPANY_REJECTED');
		}else
			$msg = JText::_('JS_ERROR_IN_REJECTING_FEATURED_COMPANY');
			
		$link = 'index.php?option=com_jsjobs&task=view&layout=featuredcompanies';
		$this->setRedirect($link, $msg);
	}
	function goldcompanyapprove()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$companyid = $cid[0];
		$return_value = $model->goldCompanyApprove($companyid);
		if ($return_value == 1)	{
			$msg = JText::_('JS_GOLD_COMPANY_APPROVED');
		}else
			$msg = JText::_('JS_ERROR_IN_APPROVING_GOLD_COMPANY');
			
		$link = 'index.php?option=com_jsjobs&task=view&layout=goldcompanies';
		$this->setRedirect($link, $msg);
	}
	function goldcompanyreject()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$companyid = $cid[0];
		
		$return_value = $model->goldCompanyReject($companyid);
		if ($return_value == 1)	{
			$msg = JText::_('JS_GOLD_COMPANY_REJECTED');
		}else
			$msg = JText::_('JS_ERROR_IN_REJECTING_GOLD_COMPANY');
			
		$link = 'index.php?option=com_jsjobs&task=view&layout=goldcompanies';
		$this->setRedirect($link, $msg);
	}
	
	function featuredjobapprove()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$jobid = $cid[0];
		$return_value = $model->featuredJobApprove($jobid);
		if ($return_value == 1)	{
			$msg = JText::_('JS_FEATURED_JOB_APPROVED');
		}else
			$msg = JText::_('JS_ERROR_IN_APPROVING_FEATURED_JOB');
			
		$link = 'index.php?option=com_jsjobs&task=view&layout=featuredjobs';
		$this->setRedirect($link, $msg);
	}
	function featuredjobreject()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$jobid = $cid[0];
		$return_value = $model->featuredJobReject($jobid);
		if ($return_value == 1)	{
			$msg = JText::_('JS_FEATURED_JOB_REJECTED');
		}else
			$msg = JText::_('JS_ERROR_IN_REJECTING_FEATURED_JOB');
			
		$link = 'index.php?option=com_jsjobs&task=view&layout=featuredjobs';
		$this->setRedirect($link, $msg);
	}
	
	function goldjobapprove()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$jobid = $cid[0];
		$return_value = $model->goldJobApprove($jobid);
		if ($return_value == 1)	{
			$msg = JText::_('JS_GOLD_JOB_APPROVED');
		}else
			$msg = JText::_('JS_ERROR_IN_APPROVING_GOLD_JOB');
			
		$link = 'index.php?option=com_jsjobs&task=view&layout=goldjobs';
		$this->setRedirect($link, $msg);
	}
	function goldjobreject()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$jobid = $cid[0];
		$return_value = $model->goldJobReject($jobid);
		if ($return_value == 1)	{
			$msg = JText::_('JS_GOLD_JOB_REJECTED');
		}else
			$msg = JText::_('JS_ERROR_IN_REJECTING_GOLD_JOB');
			
		$link = 'index.php?option=com_jsjobs&task=view&layout=goldjobs';
		$this->setRedirect($link, $msg);
	}
	
	function featuredresumeapprove()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$resumeid = $cid[0];
		$return_value = $model->featuredResumeApprove($resumeid);
		if ($return_value == 1)	{
			$msg = JText::_('JS_GOLD_JOB_APPROVED');
		}else
			$msg = JText::_('JS_ERROR_IN_APPROVING_GOLD_JOB');
			
		$link = 'index.php?option=com_jsjobs&task=view&layout=featuredresumes';
		$this->setRedirect($link, $msg);
	}
	function featuredresumereject()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$resumeid = $cid[0];
		$return_value = $model->featuredResumeReject($resumeid);
		if ($return_value == 1)	{
			$msg = JText::_('JS_FEATURED_RESUME_REJECTED');
		}else
			$msg = JText::_('JS_ERROR_IN_REJECTING_FEATURED_RESUME');
			
		$link = 'index.php?option=com_jsjobs&task=view&layout=featuredresumes';
		$this->setRedirect($link, $msg);
	}
	function goldresumeapprove()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$resumeid = $cid[0];
		$return_value = $model->goldResumeApprove($resumeid);
		if ($return_value == 1)	{
			$msg = JText::_('JS_GOLD_RESUME_APPROVED');
		}else
			$msg = JText::_('JS_ERROR_IN_APPROVING_GOLD_RESUME');
			
		$link = 'index.php?option=com_jsjobs&task=view&layout=goldresumes';
		$this->setRedirect($link, $msg);
	}
        function goldresumereject()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$resumeid = $cid[0];
		$return_value = $model->goldResumeReject($resumeid);
		if ($return_value == 1)	{
			$msg = JText::_('JS_GOLD_RESUME_REJECTED');
		}else
			$msg = JText::_('JS_ERROR_IN_REJECTING_GOLD_RESUME');
			
		$link = 'index.php?option=com_jsjobs&task=view&layout=goldresumes';
		$this->setRedirect($link, $msg);
	}
	function publishcategories()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$id = $cid[0];
		$return_value = $model->categoryChangeStatus($id, 1);
		if ($return_value != 1)	$msg = JText::_('JS_ERROR_OCCUR');

		$link = 'index.php?option=com_jsjobs&task=view&layout=categories';
		$this->setRedirect($link, $msg);
	}
	function unpublishcategories()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$id = $cid[0];
		$return_value = $model->categoryChangeStatus($id, 0);
		if ($return_value != 1)	$msg = JText::_('JS_ERROR_OCCUR');

		$link = 'index.php?option=com_jsjobs&task=view&layout=categories';
		$this->setRedirect($link, $msg);
	}
	function publishsubcategories()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$id = $cid[0];
		$return_value = $model->subCategoryChangeStatus($id, 1);
		if ($return_value != 1)	$msg = JText::_('JS_ERROR_OCCUR');

                $session = JFactory::getSession();
                $categoryid = $session->set('sub_categoryid');
		$link = 'index.php?option=com_jsjobs&task=view&layout=subcategories&cd='.$categoryid;
		$this->setRedirect($link, $msg);
	}
	function unpublishsubcategories()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$id = $cid[0];
		$return_value = $model->subCategoryChangeStatus($id, 0);
		if ($return_value != 1)	$msg = JText::_('JS_ERROR_OCCUR');

                $session = JFactory::getSession();
                $categoryid = $session->set('sub_categoryid');
		$link = 'index.php?option=com_jsjobs&task=view&layout=subcategories&cd='.$categoryid;
		$this->setRedirect($link, $msg);
	}
        function publishfolder()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$id = $cid[0];
		$return_value = $model->folderChangeStatus($id, 1);
		if ($return_value != 1){$msg = JText::_('JS_ERROR_OCCUR');}
                $msg = JText::_('JS_FOLDER_APPROVED');
		$link = 'index.php?option=com_jsjobs&task=view&layout=foldersqueue';
		$this->setRedirect($link, $msg);
	}
	function unpublishfolder()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$id = $cid[0];
		$return_value = $model->folderChangeStatus($id, -1);
		if ($return_value != 1){$msg = JText::_('JS_ERROR_OCCUR');}
                $msg = JText::_('JS_FOLDER_REJECTED');
		$link = 'index.php?option=com_jsjobs&task=view&layout=foldersqueue';
		$this->setRedirect($link, $msg);
	}
	function publishmessages()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$id = $cid[0];
		$return_value = $model->messageChangeStatus($id, 1);
		if ($return_value != 1){$msg = JText::_('JS_ERROR_OCCUR');}
                $msg = JText::_('JS_MESSAGE_APPROVED');
		$link = 'index.php?option=com_jsjobs&task=view&layout=messages';
		$this->setRedirect($link, $msg);
	}
	function unpublishmessages()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$id = $cid[0];
		$return_value = $model->messageChangeStatus($id, -1);
		if ($return_value != 1){$msg = JText::_('JS_ERROR_OCCUR');}
                $msg = JText::_('JS_MESSAGE_REJECTED');
		$link = 'index.php?option=com_jsjobs&task=view&layout=messages';
		$this->setRedirect($link, $msg);
	}
        function savemessage() //save message
	{
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$user	=& JFactory::getUser();
		$uid=$user->id;
                $data = JRequest :: get('post');
                $jobid=$data['jobid'];
				echo $jobid;
                $resumeid=$data['resumeid'];
				echo $resumeid;
                $sm=$data['sm'];
                $cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
                $return_value = $model->storeMessage($uid,$cid);
                if ($return_value == 1) $msg = JText :: _('JS_MESSAGE_SEND');
                elseif ($return_value == 2) $msg = JText :: _('JS_MESSAGE_SEND_AND_WAITING_FOR_APPROVAL');
                else $msg = JText :: _($return_value.'JS_MESSAGE_REJECTED');
                if($sm == 1){
                    $link = 'index.php?option=com_jsjobs&task=view&layout=jobappliedresume&oi='.$jobid;
                }elseif($sm == 3){
                    $link = 'index.php?option=com_jsjobs&task=view&layout=messages';
                }elseif($sm == 2){
                    if ($return_value == 1) $msg = JText :: _('JS_MESSAGE_SAVED');
                    elseif ($return_value == 2) $msg = JText :: _('JS_MESSAGE_SAVED_AND_WAITING_FOR_APPROVAL');
                    else $msg = JText :: _($return_value.'JS_MESSAGE_REJECTED');
                    $link = 'index.php?option=com_jsjobs&task=view&layout=message_history&bd='.$jobid.'&rd='. $resumeid.'';
                }
                $this->setRedirect($link, $msg);
	}
        function savemessages() //save message
	{
		$model = $this->getModel('jsjobs', 'JSJobsModel');
                $session = &JFactory::getSession();
                $jobid=$session->get('bd');
                $resumeid=$session->get('rd');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$data = JRequest :: get('post');
                $return_value = $model->storeMessage($cid);
                if ($return_value == 1) $msg = JText :: _('JS_MESSAGE_SAVED');
                elseif ($return_value == 2) $msg = JText :: _('JS_MESSAGE_SAVED_AND_WAITING_FOR_APPROVAL');
                else $msg = JText :: _($return_value.'JS_ERROR_SAVING_MESSAGE');
                $link = 'index.php?option=com_jsjobs&task=view&layout=messages';
                $this->setRedirect($link, $msg);
	}
	function savegoldcompany()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$data = JRequest :: get('post');
		$companyid=$data['companyid'];
		$user	=& JFactory::getUser();
		$uid=$user->id;
		$return_value = $model->storeGoldCompany($uid, $companyid);
		if ($return_value == 1)
		{
			$msg = JText::_('GOLD_COMPANY_SAVED');

		}else if ($return_value == 6){
			$msg = JText :: _('JS_ALREADY_ADDED_GOLD_COMPANY');
		}else {
			$msg = JText::_('ERROR_SAVING_GOLD_COMPANY');

		}
		$link = 'index.php?option=com_jsjobs&task=view&layout=goldcompanies';
		$this->setRedirect($link, $msg);
	}
	function savegoldjob()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$data = JRequest :: get('post');
		$jobid=$data['jobid'];
		//$jobid =($_GET['cid'][0]);
		$user	=& JFactory::getUser();
		$uid=$user->id;

		$return_value = $model->storeGoldJob($jobid,$uid);
		if ($return_value == 1)
		{
			$msg = JText::_('GOLD_JOB_SAVED');
		}elseif($return_value == 6){
			$msg = JText :: _('JS_ALREADY_ADDED_GOLD_JOB');
		}else{
			$msg = JText::_('ERROR_SAVING_GOLD_JOB');

		}
		$link = 'index.php?option=com_jsjobs&task=view&layout=goldjobs';
			$this->setRedirect($link, $msg);
	}


	function savegoldresume()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$data=JRequest :: get('post');
		$resumeid=$data['resumeid'];
		$user	=& JFactory::getUser();
		$uid=$user->id;
		$return_value = $model->storeGoldResume($uid, $resumeid);
		if ($return_value == 1)
		{
			$msg = JText::_('GOLD_RESUME_SAVED');
		}else if ($return_value == 6){
			$msg = JText :: _('JS_ALREADY_ADDED_GOLD_RESUME');
		}else {
			$msg = JText::_('ERROR_SAVING_GOLD_RESUME');
		}
		$link = 'index.php?option=com_jsjobs&task=view&layout=goldresumes';
			$this->setRedirect($link, $msg);
	}

	function savefeaturedresume()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');

		$data = JRequest :: get('post');
		$resumeid=$data['resumeid'];


		$user	=& JFactory::getUser();
		$uid=$user->id;

		$return_value = $model->storeFeaturedResume($uid, $resumeid);
		if ($return_value == 1)
		{
			$msg = JText::_('FEATURED_RESUME_SAVED');
		}elseif ($return_value == 6){
			$msg = JText :: _('JS_ALREADY_ADDED_FEATURED_RESUME');
		}else {
			$msg = JText::_('ERROR_SAVING_FEATURED_RESUME');

		}
		$link = 'index.php?option=com_jsjobs&task=view&layout=featuredresumes';
		$this->setRedirect($link, $msg);
	}
	function savefeaturedjob()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$data = JRequest :: get('post');
		$jobid=$data['jobid'];
		//$jobid =($_GET['cid'][0]);
		$user	=& JFactory::getUser();
		$uid=$user->id;
		$return_value = $model->storeFeaturedJob($uid, $jobid);
		if ($return_value == 1)
		{
			$msg = JText::_('FEATURED_JOB_SAVED');

		}elseif($return_value == 6){
			$msg = JText :: _('JS_ALREADY_ADDED_FEATURED_JOB');
		}else {
			$msg = JText::_('ERROR_SAVING_FEATURED_JOB');

		}
			$link = 'index.php?option=com_jsjobs&task=view&layout=featuredjobs';
			$this->setRedirect($link, $msg);
	}


	function savefeaturedcompany()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');

		$data = JRequest :: get('post');
		$companyid=$data['companyid'];

		$user	=& JFactory::getUser();
		$uid=$user->id;

		$return_value = $model->storeFeaturedCompany($companyid,$uid);
		if ($return_value == 1)
		{
			$msg =JText::_('JS_COMPANY_SAVED');
		}elseif($return_value == 6){
			$msg = JText :: _('JS_ALREADY_ADDED_FEATURED_COMPANY');
		}else {
			$msg = JText::_('ERROR_SAVING_COMPANY');

		}
		$link = 'index.php?option=com_jsjobs&task=view&layout=featuredcompanies';
		$this->setRedirect($link, $msg);
	}

// Payment System End
	function jobseekerpaymentapprove()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$packageid = $cid[0];
		$return_value = $model->jobseekerPaymentApprove($packageid);
		if ($return_value == 1)	{
			$msg = JText::_('JS_PAYMENT_APPROVED');
		}else
			$msg = JText::_('JS_ERROR_IN_APPROVING_PAYMENT');
			
		$link = 'index.php?option=com_jsjobs&task=view&layout=jobseekerpaymenthistory';
		$this->setRedirect($link, $msg);
	}
	
	function jobseekerpaymentereject()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$packageid = $cid[0];
		
		$return_value = $model->jobseekerPaymentReject($packageid);
		if ($return_value == 1)	{
			$msg = JText::_('JS_PAYMENT_REJECTED');
		}else
			$msg = JText::_('JS_ERROR_IN_REJECTING_PAYMENT');
			
		$link = 'index.php?option=com_jsjobs&task=view&layout=jobseekerpaymenthistory';
		$this->setRedirect($link, $msg);
	}
	function employerpaymentapprove()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$packageid = $cid[0];
		$return_value = $model->employerPaymentApprove($packageid);
		if ($return_value == 1)	{
			$msg = JText::_('JS_PAYMENT_APPROVED');
			
		}else{
			$msg = JText::_('JS_ERROR_IN_APPROVING_PAYMENT');
			
			}
			
		$link = 'index.php?option=com_jsjobs&task=view&layout=employerpaymenthistory';
		$this->setRedirect($link, $msg);
	}
	function employerpaymentreject()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$packageid = $cid[0];
		
		//$packageid = $_GET['packageid'];
		$return_value = $model->employerPaymentReject($packageid);
		if ($return_value == 1)	{
			$msg = JText::_('JS_PAYMENT_REJECTED');
		}else
			$msg = JText::_('JS_ERROR_IN_REJECTING_PAYMENT');
			
		$link = 'index.php?option=com_jsjobs&task=view&layout=employerpaymenthistory';
		$this->setRedirect($link, $msg);
	}
	function jobapprove()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$jobid = $cid[0];
		$return_value = $model->jobApprove($jobid);
		if ($return_value == 1)	{
			$msg = JText::_('JOB_APPROVED');
		}else
			$msg = JText::_('ERROR_IN_APPROVING_JOB');
			
		$link = 'index.php?option=com_jsjobs&task=view&layout=jobqueue';
		$this->setRedirect($link, $msg);
	}

	function jobreject()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$jobid = $cid[0];
		$return_value = $model->jobReject($jobid);
		if ($return_value == 1)	{
			$msg = JText::_('JOB_REJECTED');
		}else
			$msg = JText::_('ERROR_IN_REJECTING_JOB');
			
		$link = 'index.php?option=com_jsjobs&task=view&layout=jobqueue';
		$this->setRedirect($link, $msg);
	}

	function empappapprove()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$appid = $cid[0];
		$return_value = $model->empappApprove($appid);
		if ($return_value == 1)	{
			$msg = JText::_('EMP_APP_APPROVED');
		}else
			$msg = JText::_('ERROR_IN_APPROVING_EMP_APP');
			
		$link = 'index.php?option=com_jsjobs&task=view&layout=appqueue';
		$this->setRedirect($link, $msg);
	}

	function empappreject()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$appid = $cid[0];
		$return_value = $model->empappReject($appid);
		if ($return_value == 1)	{
			$msg = JText::_('EMP_APP_REJECTED');
		}else
			$msg = JText::_('ERROR_IN_REJECTING_EMP_APP');
			
		$link = 'index.php?option=com_jsjobs&task=view&layout=appqueue';
		$this->setRedirect($link, $msg);
	}

	function fieldpublished()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$fieldid = $cid[0];
		$return_value = $model->fieldPublished($fieldid, 1);//published
		$link = 'index.php?option=com_jsjobs&task=view&layout=fieldsordering';
		$this->setRedirect($link, $msg);
	}

	function fieldunpublished()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$fieldid = $cid[0];
		$return_value = $model->fieldPublished($fieldid, 0); // unpublished
		$link = 'index.php?option=com_jsjobs&task=view&layout=fieldsordering';
		$this->setRedirect($link, $msg);
	}

	function fieldorderingup()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$fieldid = $cid[0];
		$return_value = $model->fieldOrderingUp($fieldid);
		$link = 'index.php?option=com_jsjobs&task=view&layout=fieldsordering';
		$this->setRedirect($link, $msg);
	}

	function fieldorderingdown()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cid 	= JRequest::getVar( 'cid', array(), ''		, 'array' );
		$fieldid = $cid[0];
		$return_value = $model->fieldOrderingDown($fieldid);
		$link = 'index.php?option=com_jsjobs&task=view&layout=fieldsordering';
		$this->setRedirect($link, $msg);
	}

	function remove()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$cur_layout = $_SESSION['cur_layout'];
		if ($cur_layout == 'categories'){
			$returnvalue = $model->deleteCategory();
			if ($returnvalue == 1){
				$msg = JText::_('CATEGORY_DELETED');
			}else{
				$msg = $returnvalue -1 .' '. JText::_('ERROR_CATEGORY_COULD_NOT_DELETE');
			}
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=categories', $msg);

                }elseif ($cur_layout == 'jobtypes'){
			$returnvalue = $model->deleteJobType();
			if ($returnvalue == 1)	$msg = JText::_('JS_JOB_TYPE_DELETED');
			else	$msg = $returnvalue -1 .' '. JText::_('JS_ERROR_JOB_TYPE_COULD_NOT_DELETE');
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=jobtypes', $msg);
                }elseif ($cur_layout == 'ages'){
			$returnvalue = $model->deleteAge();
			if ($returnvalue == 1)	$msg = JText::_('JS_AGE_DELETED');
			else	$msg = $returnvalue -1 .' '. JText::_('JS_ERROR_AGE_COULD_NOT_DELETE');
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=ages', $msg);
                }elseif ($cur_layout == 'careerlevels'){
			$returnvalue = $model->deleteCareerLevel();
			if ($returnvalue == 1)	$msg = JText::_('JS_CAREER_LEVEL_DELETED');
			else	$msg = $returnvalue -1 .' '. JText::_('JS_ERROR_CAREER_LEVEL_COULD_NOT_DELETE');
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=careerlevels', $msg);
                }elseif ($cur_layout == 'experience'){
			$returnvalue = $model->deleteExperience();
			if ($returnvalue == 1)	$msg = JText::_('JS_EXPERIENCE_DELETED');
			else	$msg = $returnvalue -1 .' '. JText::_('JS_ERROR_EXPERIENCE_COULD_NOT_DELETE');
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=experience', $msg);
		}elseif ($cur_layout == 'jobstatus'){
			$returnvalue = $model->deleteJobStatus();
			if ($returnvalue == 1)	$msg = JText::_('JS_JOB_STATUS_DELETED');
			else	$msg = $returnvalue -1 .' '. JText::_('JS_ERROR_JOB_STATUS_COULD_NOT_DELETE');
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=jobstatus', $msg);
		}elseif ($cur_layout == 'shifts'){
			$returnvalue = $model->deleteShift();
			if ($returnvalue == 1)	$msg = JText::_('JS_SHIFT_DELETED');
			else	$msg = $returnvalue -1 .' '. JText::_('JS_ERROR_SHIFT_COULD_NOT_DELETE');
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=shifts', $msg);
		}elseif ($cur_layout == 'highesteducations'){
			$returnvalue = $model->deleteHighestEducation();
			if ($returnvalue == 1)	$msg = JText::_('JS_HIGHEST_EDUCATION_DELETED');
			else	$msg = $returnvalue -1 .' '. JText::_('JS_ERROR_HIGHEST_EDUCATION_COULD_NOT_DELETE');
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=highesteducations', $msg);
		}elseif ($cur_layout == 'salaryrange'){
			$returnvalue = $model->deleteSalaryRange();
			if ($returnvalue == 1){
				$msg = JText::_('SALARY_RANGE_DELETED');
			}else{
				$msg = $returnvalue -1 .' '. JText::_('ERROR_RANGE_COULD_NOT_DELETE');
			}
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=salaryrange', $msg);
		}elseif ($cur_layout == 'salaryrangetype'){
			$returnvalue = $model->deleteSalaryRangeType();
			if ($returnvalue == 1){
				$msg = JText::_('JS_SALARY_RANGE_TYPE_DELETED');
			}else{
				$msg = $returnvalue -1 .' '. JText::_('JS_ERROR_SALARY_RANGE_TYPE_COULD_NOT_DELETE');
			}
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=salaryrangetype', $msg);
		}elseif ($cur_layout == 'empapps'){
			$returnvalue = $model->deleteResume();
			if ($returnvalue == 1){
				$msg = JText::_('EMP_APP_DELETED');
			}else{
				$msg = $returnvalue -1 .' '. JText::_('ERROR_EMP_APP_COULD_NOT_DELETE');
			}
			$this->setRedirect('index.php?option=com_jsjobs&task=view', $msg);
		}elseif ($cur_layout == 'companies'){
			$returnvalue = $model->deleteCompany();
			if ($returnvalue == 1){
				$msg = JText::_('COMPANY_DELETED');
			}else{
				$msg = $returnvalue -1 .' '. JText::_('COMPANY_COULD_NOT_DELETE');
			}
			$this->setRedirect('index.php?option=com_jsjobs&task=view', $msg);
		}elseif ($cur_layout == 'departments'){
			$returnvalue = $model->deleteDepartment();
			if ($returnvalue == 1){
				$msg = JText::_('DEPARTMENT_DELETED');
			}else{
				$msg = $returnvalue -1 .' '. JText::_('DEPARTMENT_COULD_NOT_DELETE');
			}
			$this->setRedirect('index.php?option=com_jsjobs&task=view', $msg);
                }elseif ($cur_layout == 'jobs'){
			$returnvalue = $model->deleteJob();
			if ($returnvalue == 1){
				$msg = JText::_('JOB_DELETED');
			}else{
				$msg = $returnvalue -1 .' '. JText::_('JOB_COULD_NOT_DELETE');
			}
			$this->setRedirect('index.php?option=com_jsjobs&task=view', $msg);
		}elseif ($cur_layout == 'roles'){
			$returnvalue = $model->deleteRole();
			if ($returnvalue == 1){
				$msg = JText::_('ROLE_DELETED');
			}else{
				$msg = $returnvalue -1 .' '. JText::_('ROLE_COULD_NOT_DELETE');
			}
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=roles', $msg);
		}elseif ($cur_layout == 'jobseekerpackages'){
			$returnvalue = $model->deleteJobSeekerPackage();
			if ($returnvalue == 1){
				$msg = JText::_('PACKAGE_DELETED');
			}else{
				$msg = $returnvalue.''.$returnvalue -1 .' '. JText::_('PACKAGE_COULD_NOT_DELETE');
			}
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=jobseekerpackages', $msg);
		}elseif ($cur_layout == 'employerpackages'){
			$returnvalue = $model->deleteEmployerPackage();
			if ($returnvalue == 1){
				$msg = JText::_('PACKAGE_DELETED');
			}else{
				$msg = $returnvalue.''.$returnvalue -1 .' '. JText::_('PACKAGE_COULD_NOT_DELETE');
			}
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=employerpackages', $msg);
		}elseif ($cur_layout == 'goldresumes'){
			$returnvalue = $model->deleteGoldResume();
			if ($returnvalue == 1){
				$msg = JText::_('GOLD_RESUME_DELETED');
			}else{
				$msg =  JText::_('GOLD_RESUME_COULD_NOT_DELETE');
			}
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=goldresumes', $msg);
		}elseif ($cur_layout == 'featuredresumes'){
			$returnvalue = $model->deleteFeaturedResume();
			if ($returnvalue == 1){
				$msg = JText::_('FEATURED_RESUME_DELETED');
			}else{
				$msg =  JText::_('FEATURED_RESUME_COULD_NOT_DELETE');
			}
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=featuredresumes', $msg);
		}elseif ($cur_layout == 'featuredjobs'){
			$returnvalue = $model->deleteFeaturedJob();
			if ($returnvalue == 1){
				$msg = JText::_('FEATURED_JOB_DELETED');
			}else{
				$msg =  JText::_('FEATURED_JOB_COULD_NOT_DELETE');
			}
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=featuredjobs', $msg);
		}elseif ($cur_layout == 'goldjobs'){
			$returnvalue = $model->deleteGoldJob();
			if ($returnvalue == 1){
				$msg = JText::_('GOLD_JOB_DELETED');
			}else{
				$msg =  JText::_('GOLD_JOB_COULD_NOT_DELETE');
			}
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=goldjobs', $msg);
		}elseif ($cur_layout == 'goldcompanies'){
			$returnvalue = $model->deleteGoldCompany();
			if ($returnvalue == 1){
				$msg = JText::_('COMPANY_DELETED');
			}else{
				$msg = $returnvalue -1 .' '. JText::_('COMPANY_COULD_NOT_DELETE');
			}
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=goldcompanies', $msg);
		}elseif ($cur_layout == 'featuredcompanies'){
			$returnvalue = $model->deleteFeaturedCompany();
			if ($returnvalue == 1){
				$msg = JText::_('FEATURED_COMPANY_DELETED');
			}else{
				$msg = $returnvalue -1 .' '. JText::_('FEATURED_COMPANY_COULD_NOT_DELETE');
			}
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=featuredcompanies', $msg);
		}elseif ($cur_layout == 'messages'){
			$returnvalue = $model->deleteMessages();
			if ($returnvalue == 1){
				$msg = JText::_('JS_MAEEAGE_DELETED');
			}else{
				$msg = $returnvalue -1 .' '. JText::_('JS_MASSAGE_COULD_NOT_DELETE');
			}
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=messages', $msg);
		}elseif ($cur_layout == 'folders'){
			$returnvalue = $model->deleteFolder();
			if ($returnvalue == 1){
				$msg = JText::_('JS_FOLDER_DELETED');
			}else{
				$msg = $returnvalue -1 .' '. JText::_('JS_FOLDER_COULD_NOT_DELETE');
			}
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=folders', $msg);
		}
		elseif ($cur_layout == 'userfields') $this->deleteuserfield();
		elseif ($cur_layout == 'countries')	$this->deletecountry();
		elseif ($cur_layout == 'states')	$this->deletestate();
		elseif ($cur_layout == 'counties')	$this->deletecounty();
		elseif ($cur_layout == 'cities')	$this->deletecity();
		elseif ($cur_layout == 'currency'){
			$returnvalue = $model->deleteCurrency();
			if ($returnvalue == 1){
				$msg = JText::_('CURRENCY_DELETED');
			}else{
				$msg = $returnvalue -1 .' '. JText::_('ERROR_CURRENCY_COULD_NOT_DELETE');
			}
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=currency', $msg);
		}
		
	}

        function removesubcategory(){
                $model = & $this->getModel('jsjobs', 'JSJobsModel');
                $returnvalue = $model->deleteSubCategory();
                if ($returnvalue == 1) $msg = JText::_('CATEGORY_DELETED');
                else $msg = $returnvalue -1 .' '. JText::_('ERROR_CATEGORY_COULD_NOT_DELETE');
                $session = JFactory::getSession();
                $categoryid = $session->get('sub_categoryid');
                
                $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=subcategories&cd='.$categoryid, $msg);
        }
 
	function deleteuserfield(){
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->deleteUserField();
		if ($return_value == 1){
			$msg = JText::_('JS_USER_FIELD_DELETE');
		} else {
				$msg = $returnvalue -1 .' '. JText::_('JS_USER_FIELD_COULD_NOT_DELETE');
		}
		$link = 'index.php?option=com_jsjobs&task=view&layout=userfields';
		$this->setRedirect($link, $msg);
	}

	function deletecountry(){
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->deleteCountry();
		if ($return_value == 1){
			$msg = JText::_('JS_COUNTRY_DELETE');
		} else {
				$msg = $returnvalue -1 .' '. JText::_('JS_COUNTRY_COULD_NOT_DELETE');
		}
		$link = 'index.php?option=com_jsjobs&task=view&layout=countries';
		$this->setRedirect($link, $msg);
	}

	function deletestate(){
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		if (isset($_SESSION['js_countrycode'])) $countrycode = $_SESSION['js_countrycode']; 
		$return_value = $model->deleteState();
		if ($return_value == 1){
			$msg = JText::_('JS_STATE_DELETE');
		} else {
				$msg = $returnvalue -1 .' '. JText::_('JS_STATE_COULD_NOT_DELETE');
		}
		$link = 'index.php?option=com_jsjobs&task=view&layout=states&ct='.$countrycode;
		$this->setRedirect($link, $msg);
		
	}

	function deletecounty(){
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		if (isset($_SESSION['js_statecode'])) $statecode = $_SESSION['js_statecode']; 
		$return_value = $model->deleteCounty();
		if ($return_value == 1){
			$msg = JText::_('JS_COUNTY_DELETE');
		} else {
				$msg = $returnvalue -1 .' '. JText::_('JS_COUNTY_COULD_NOT_DELETE');
		}
		$link = 'index.php?option=com_jsjobs&task=view&layout=counties&sd='.$statecode;
		$this->setRedirect($link, $msg);
	}

	function deletecity(){
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		if (isset($_SESSION['js_countycode'])) $countycode = $_SESSION['js_countycode']; 
		$return_value = $model->deleteCity();
		if ($return_value == 1){
			$msg = JText::_('JS_CITY_DELETE');
		} else {
				$msg = $returnvalue -1 .' '. JText::_('JS_CITY_COULD_NOT_DELETE');
		}
		$link = 'index.php?option=com_jsjobs&task=view&layout=cities&co='.$countycode;
		$this->setRedirect($link, $msg);
	}

	function cancel()
	{
		$msg = JText::_('OPERATION_CANCELLED');
                //$session = &JFactory::getSession();
                //$jobid=$session->get('bd');
                //$resumeid=$session->get('rd');
                $cur_layout = $_SESSION['cur_layout'];
		if ($cur_layout == 'categories')
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=categories', $msg);
		elseif ($cur_layout == 'message_history')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=message_history&bd='.$jobid.'&rd='. $resumeid.'', $msg);
		elseif ($cur_layout == 'formresumeuserfield')	$this->setRedirect('index.php?option=com_jsjobs&view=application&layout=formresumeuserfield', $msg);
		elseif ($cur_layout == 'jobtypes')	$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=jobtypes', $msg);
		elseif ($cur_layout == 'ages')	$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=ages', $msg);
		elseif ($cur_layout == 'careerlevels')	$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=careerlevels', $msg);
		elseif ($cur_layout == 'experience')	$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=experience', $msg);
		elseif ($cur_layout == 'salaryrangetype')	$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=salaryrangetype', $msg);
		elseif ($cur_layout == 'jobstatus')	$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=jobstatus', $msg);
		elseif ($cur_layout == 'shifts')	$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=shifts', $msg);
		elseif ($cur_layout == 'highesteducations')	$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=highesteducations', $msg);
		elseif ($cur_layout == 'companies')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=companies', $msg);
		elseif ( $cur_layout == 'folders' || $cur_layout == 'folder_resumes' )
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=folders', $msg);
		elseif ($cur_layout == 'foldersqueue')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=foldersqueue', $msg);
                elseif ($cur_layout == 'view_company')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=job_searchresult', $msg);
                elseif ($cur_layout == 'view_job')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=job_searchresult', $msg);
                elseif ($cur_layout == 'package_paymentreport')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=payment_report', $msg);
                elseif ($cur_layout == 'job_searchresult')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=jobsearch', $msg);
                elseif ($cur_layout == 'resume_searchresult')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=resumesearch', $msg);
                elseif ($cur_layout == 'employerpaymentdetails')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=employerpaymenthistory', $msg);
                elseif ($cur_layout == 'jobseekerpaymentdetails')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=jobseekerpaymenthistory', $msg);
		elseif ($cur_layout == 'employerpackages')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=employerpackages', $msg);
                elseif ($cur_layout == 'jobseekerpackages')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=jobseekerpackages', $msg);
                elseif ($cur_layout == 'packageinfo')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=jobseekerpackages', $msg);
                elseif ($cur_layout == 'goldresumes')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=goldresumes', $msg);
                elseif ($cur_layout == 'goldresumesqueue')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=goldresumesqueue', $msg);
                elseif ($cur_layout == 'featuredresumes')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=featuredresumes', $msg);
                elseif ($cur_layout == 'featuredresumesqueue')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=featuredresumesqueue', $msg);
                elseif ($cur_layout == 'goldjobs')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=goldjobs', $msg);
                elseif ($cur_layout == 'goldjobsqueue')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=goldjobsqueue', $msg);
                elseif ($cur_layout == 'goldcompanies')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=goldcompanies', $msg);
                elseif ($cur_layout == 'goldcompaniesqueue')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=goldcompaniesqueue', $msg);
                elseif ($cur_layout == 'featuredcompanies')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=featuredcompanies', $msg);
                elseif ($cur_layout == 'featuredcompaniesqueue')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=featuredcompaniesqueue', $msg);
                elseif ($cur_layout == 'departments')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=departments', $msg);
                elseif ($cur_layout == 'departmentsqueue')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=departmentsqueue', $msg);
                elseif ($cur_layout == 'company_departments')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=companies', $msg);
                elseif ($cur_layout == 'featuredjobs')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=featuredjobs', $msg);
                elseif ($cur_layout == 'featuredjobsqueue')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=featuredjobsqueue', $msg);
		elseif ($cur_layout == 'jobs')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=jobs', $msg);
		elseif ($cur_layout == 'userstats')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=userstats', $msg);
		elseif ($cur_layout == 'userstate_companies')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=userstats', $msg);
		elseif ($cur_layout == 'userstate_jobs')
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=userstats', $msg);
		elseif ($cur_layout == 'userstate_resumes')
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=userstats', $msg);
		elseif ($cur_layout == 'jobqueue')
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=jobqueue', $msg);
		elseif ($cur_layout == 'jobappliedresume')	$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=appliedresumes', $msg);
		elseif ($cur_layout == 'view_resume'){
                    $jobid = JRequest::getVar( 'oi');
                    $folderid = JRequest::getVar( 'fd');
                    if($jobid) $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=jobappliedresume&oi='.$jobid, $msg);
                    elseif($folderid ) $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=folder_resumes&fd='.$folderid, $msg);
                    else $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=resume_searchresults', $msg);
		}	
		elseif ($cur_layout == 'empapps')
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=empapps', $msg);
		elseif ($cur_layout == 'salaryrange')
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=salaryrange', $msg);
		elseif ($cur_layout == 'userfields')
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=userfields', $msg);
		elseif ($cur_layout == 'resumeuserfields')
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=resumeuserfields', $msg);
		elseif ($cur_layout == 'roles')
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=roles', $msg);
		elseif ($cur_layout == 'users')
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=users', $msg);
		elseif ($cur_layout == 'formmessage'){
                    $data = JRequest :: get('post');
                    $sm=$data['sm'];
                    $jobid=$data['jobid'];
                    $resumeid=$data['resumeid'];
                    if($sm == 3){
                    $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=messages', $msg);
                    }elseif($sm == 2){
                        $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=message_history&bd='.$jobid.'&rd='.$resumeid, $msg);
                    }
                }elseif ($cur_layout == 'countries')	$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=countries', $msg);
		elseif ($cur_layout == 'states'){
			if (isset($_SESSION['js_countrycode'])) $countrycode = $_SESSION['js_countrycode']; ;
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=states&ct='.$countrycode, $msg);
		}elseif ($cur_layout == 'counties'){
			if (isset($_SESSION['js_statecode'])) $statecode = $_SESSION['js_statecode']; 
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=counties&sd='.$statecode, $msg);
		}elseif ($cur_layout == 'cities'){
			if (isset($_SESSION['js_countycode'])) $countycode = $_SESSION['js_countycode']; 
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=cities&co='.$countycode, $msg);
		}elseif ($cur_layout == 'currency'){
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=currency', $msg);
		}elseif ($cur_layout == 'jobseekerpaymenthistory'){
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=jobseekerpaymenthistory', $msg);
		}elseif ($cur_layout == 'employerpaymenthistory'){
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=employerpaymenthistory', $msg);
		}elseif ($cur_layout == 'themes')
			$this->setRedirect('index.php?option=com_jsjobs&task=view&layout=themes', $msg);

	}
        function cancelsendmessage(){
                $data = JRequest :: get('post');
                $jobid=$data['jobid'];
		$msg = JText::_('OPERATION_CANCELLED');
                $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=jobappliedresume&oi='.$jobid, $msg);

        }
        function cancelmessagehistory(){
            $msg = JText::_('OPERATION_CANCELLED');
            $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=messages', $msg);
        }
        function cancelsubcategories(){
		$msg = JText::_('OPERATION_CANCELLED');
                $session = JFactory::getSession();
                $categoryid = $session->get('sub_categoryid');
                $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=jobs&cd='.$categoryid, $msg);
        }
        function cancelshortlistcandidates(){
		$msg = JText::_('OPERATION_CANCELLED');
                $this->setRedirect('index.php?option=com_jsjobs&task=view&layout=jobs', $msg);
        }        
	function save()
	{
		$cur_layout = $_SESSION['cur_layout'];
		if ($cur_layout == 'categories')
			$this->savecategory();
		//elseif ($cur_layout == 'jobtypes')	$this->savejobtype();
		//elseif ($cur_layout == 'ages')	$this->saveages();
		//elseif ($cur_layout == 'careerlevels')	$this->savecareerlevel();
		//elseif ($cur_layout == 'experience')	$this->saveexperience ();
		//elseif ($cur_layout == 'jobstatus')	$this->savejobstatus();
		//elseif ($cur_layout == 'shifts')	$this->saveshift();
		//elseif ($cur_layout == 'salaryrangetype')	$this->savesalaryrangetype();
		//elseif ($cur_layout == 'highesteducations')	$this->savehighesteducation();
		//elseif ($cur_layout == 'companies')	$this->saveCompany();
		//elseif ($cur_layout == 'folders')	$this->savefolder();
		//elseif ($cur_layout == 'foldersqueue')	$this->savefolder();
		//elseif ($cur_layout == 'employerpackages')  $this->saveemployerpackage();
		//elseif ($cur_layout == 'jobseekerpackages')  $this->savejobseekerpackage();
		//elseif ($cur_layout == 'goldresumes')  $this->savegoldresume();
		//elseif ($cur_layout == 'goldresumesqueue') $this->savegoldresume();
		//elseif ($cur_layout == 'featuredresumes')  $this->savefeaturedresume();
		//elseif ($cur_layout == 'featuredresumesqueue') $this->savefeaturedresume();
		//elseif ($cur_layout == 'featuredjobs')  $this->savefeaturedjob();
		//elseif ($cur_layout == 'featuredjobsqueue') $this->savefeaturedjob();
		//elseif ($cur_layout == 'goldjobs')  $this->savegoldjob();
		//elseif ($cur_layout == 'goldjobsqueue') $this->savegoldjob();
		//elseif ($cur_layout == 'goldcompanies')  $this->savegoldcompany();
		//elseif ($cur_layout == 'goldcompaniesqueue') $this->savegoldcompany();
		//elseif ($cur_layout == 'featuredcompanies')  $this->savefeaturedcompany();
		//elseif ($cur_layout == 'featuredcompaniesqueue') $this->savefeaturedcompany();
		//elseif ($cur_layout == 'jobs') $this->savejob();
		//elseif ($cur_layout == 'jobqueue') $this->savejob();
		//elseif ($cur_layout == 'empapps') $this->saveresume();
		//elseif ($cur_layout == 'appqueue') $this->saveresume();
		//elseif ($cur_layout == 'currency') $this->savecurrency();
		//elseif ($cur_layout == 'configurations' || $cur_layout == 'configurationsemployer' || $cur_layout == 'configurationsjobseeker')
			//$this->saveconf($cur_layout);
		//elseif ($cur_layout == 'salaryrange') $this->savesalaryrange();
		//elseif ($cur_layout == 'roles')	$this->saverole();
		//elseif ($cur_layout == 'users')	$this->saveuserrole();
		//elseif ($cur_layout == 'userfields') $this->saveuserfield();
		elseif ($cur_layout == 'emailtemplate')
			$this->saveemailtemplate();
		//elseif ($cur_layout == 'countries')	$this->savecountry();
		//elseif ($cur_layout == 'states')	$this->savestate();
		//elseif ($cur_layout == 'counties')	$this->savecounty();
		//elseif ($cur_layout == 'cities')	$this->savecity();
		//elseif ($cur_layout == 'departments')	$this->savedepatrment();
		//elseif ($cur_layout == 'departmentsqueue')	$this->savedepatrment();
		elseif ($cur_layout == 'jobseekerpaymenthistory')	$this->saveuserpackage();
		elseif ($cur_layout == 'employerpaymenthistory')	$this->saveuserpackage();
	}
    function saveuserpackage(){
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
                $userrole = JRequest::getVar('userrole');
		$return_value = $model->storeUserPackage();
		if ($return_value == 1){
			$msg = JText::_('JS_PACKAGE_ASSIGN_TO_USER');
		}elseif($return_value == 5){
			$msg = JText::_('JS_CANNOT_ASSIGN_FREE_PACKAGE_MORE_THEN_ONCE');
                }else{
			$msg = JText::_('JS_ERROR_PACKAGE_CANNOT_ASSIGN_TO_USER');
		}
		if($userrole == 1)
                    $link = 'index.php?option=com_jsjobs&task=view&layout=employerpaymenthistory';
                else
                    $link = 'index.php?option=com_jsjobs&task=view&layout=jobseekerpaymenthistory';

                $this->setRedirect($link, $msg);
            
    }
	function saveconf(){
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->storeConfig();
		$cur_layout = $_SESSION['cur_layout'];

		if ($return_value == 1){
			$msg = JText::_('The Configuration Details have been updated');
		} else {
			$msg = JText::_('ERRORCONFIGFILE');
		}
                $session = JFactory::getSession();
                $config = null;
                $session->set('jsjobconfig_dft', $config);
		$link = 'index.php?option=com_jsjobs&task=view&layout='.$cur_layout;
		$this->setRedirect($link, $msg);
		
	}

	function savedepatrment()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->storeDepartment();
		if ($return_value == 1)
		{
			$msg = JText::_('DEPARTMENT_SAVED');
			$link = 'index.php?option=com_jsjobs&task=view&layout=departments';
			$this->setRedirect($link, $msg);
		}else {
			$msg = JText::_('ERROR_SAVING_DEPARTMENT');
			$link = 'index.php?option=com_jsjobs&task=view&layout=departments';
			$this->setRedirect($link, $msg);
		}
	}

	function savecompany()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->storeCompany();
		if ($return_value == 1)
		{
			$msg = JText::_('COMPANY_SAVED');
			$link = 'index.php?option=com_jsjobs&task=view&layout=companies';
			$this->setRedirect($link, $msg);
		}else {
			$msg = JText::_('ERROR_SAVING_COMPANY');
			$link = 'index.php?option=com_jsjobs&task=view&layout=companies';
			$this->setRedirect($link, $msg);
		}
	}

        function savefolder()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->storeFolder();
		if ($return_value == 1) {
			$msg = JText::_('JS_FOLDER_SAVED');
		}elseif($return_value == 3){
                    $msg = JText::_('JS_FOLDER_ALREADY_EXIST');
                }else{
			$msg = JText::_('JS_ERROR_SAVING_FOLDER');
		}
                $link = 'index.php?option=com_jsjobs&task=view&layout=folders';
                $this->setRedirect($link, $msg);
	}
	function saveemployerpackage()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->storeEmployerPackage();
		if ($return_value == 1)
		{
			$msg = JText::_('PACKAGE_SAVED');
			$link = 'index.php?option=com_jsjobs&task=view&layout=employerpackages';
			$this->setRedirect($link, $msg);
		}else {
			$msg = JText::_('ERROR_SAVING_PACKAGE');
			$link = 'index.php?option=com_jsjobs&task=view&layout=employerpackages';
			$this->setRedirect($link, $msg);
		}
	}
	
	function savejobseekerpackage()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->storeJobSeekerPackage();
		if ($return_value == 1)
		{
			$msg = JText::_('PACKAGE_SAVED');
			$link = 'index.php?option=com_jsjobs&task=view&layout=jobseekerpackages';
			$this->setRedirect($link, $msg);
		}else {
			$msg = JText::_('ERROR_SAVING_PACKAGE');
			$link = 'index.php?option=com_jsjobs&task=view&layout=jobseekerpackages';
			$this->setRedirect($link, $msg);
		}
	}
	function savejob()
	{

		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->storeJob();
		if ($return_value == 1)
		{
			$msg = JText::_('JOB_POST_SAVED');
			$link = 'index.php?option=com_jsjobs&task=view&layout=jobs';
			$this->setRedirect($link, $msg);
		}else if ($return_value == 2){
			$msg = JText::_('ALL_FIELD_MUST_BE_ENTERD');
			$link = 'index.php?option=com_jsjobs&view=application&layout=formjob';
                        $this->setRedirect($link, $msg);
		}elseif ($return_value == 12){
			$msg = JText::_('JS_DESCRIPTION_MUST_BE_ENTERD');
			$link = 'index.php?option=com_jsjobs&view=application&layout=formjob';
			$this->setRedirect($link, $msg);
                        $this->setRedirect($link, $msg);
		}else {
			$msg = JText::_($return_value.'ERROR_SAVING_JOB');
			$link = 'index.php?option=com_jsjobs&task=view&layout=jobs';
			$this->setRedirect($link, $msg);
		}
	}

	function saveresume(){
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->storeResume();
		if ($return_value == 1)	{
			$msg = JText::_('EMP_APP_SAVED');
			$link = 'index.php?option=com_jsjobs&task=view&layout=empapps';
			$this->setRedirect($link, $msg);
		}elseif ($return_value == 2){
			$msg = JText::_('ALL_FIELD_MUST_BE_ENTERD');
			$link = 'index.php?option=com_jsjobs&view=application&layout=formemp';
			$this->setRedirect($link, $msg);
		}elseif ($return_value == 6){ // file type mismatch
			$msg = JText :: _('JS_FILE_TYPE_ERROR');
			$link = 'index.php?option=com_jsjobs&task=view&layout=empapps';
			$this->setRedirect($link, $msg);
		}else{
			$msg = JText::_('ERROR_SAVING_EMP_APP');
			$link = 'index.php?option=com_jsjobs&task=view&layout=empapps';
			$this->setRedirect($link, $msg);
		}
	}

	function saveshortlistcandiate() //save shortlist candidate
	{
		global $mainframe;

		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$session = &JFactory::getSession();

		$Itemid =  JRequest::getVar('Itemid');
		$jobid =  JRequest::getVar('oi');
		$resumeid =  JRequest::getVar('rd');
		$Itemid =  JRequest::getVar('Itemid');
		$user	=& JFactory::getUser();
		$uid = $user->id;
		$return_value = $model->storeShortListCandidate($uid,$resumeid,$jobid);
		if ($return_value == 1)	{
			$msg = JText :: _('JS_SHORT_LIST_CANDIDATE_SAVED');
		}elseif ($return_value == 2){
			$msg = JText :: _('JS_FILL_REQ_FIELDS');
		}elseif ($return_value == 3){
			$msg = JText :: _('JS_ALLREADY_SHORTLIST_THIS_CANDIDATE');
		}else{
			$msg = JText :: _($return_value.'JS_ERROR_SAVING_SHORT_LIST_CANDIDATE');
		}
		$link = 'index.php?option=com_jsjobs&view=application&layout=view_resume&rd='.$resumeid.'&oi='.$jobid;
		$this->setRedirect($link, $msg);
	}

        function savecategory()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->storeCategory();
		if ($return_value == 1)
		{
			$msg = JText::_('CATEGORY_SAVED');
			$link = 'index.php?option=com_jsjobs&task=view&layout=categories';
			$this->setRedirect($link, $msg);
		}
		else if ($return_value == 2){
			$msg = JText::_('ALL_FIELD_MUST_BE_ENTERD');
			JRequest :: setVar('view', 'application');
			JRequest :: setVar('hidemainmenu', 1);
				JRequest :: setVar('layout', 'formcategory');
				JRequest :: setVar('msg', $msg);
			
			// Display based on the set variables
			parent :: display();
			//$link = 'index.php?option=com_jsjobs&c=application&layout=categories';
		}else if ($return_value == 3){
			$msg = JText::_('CATEGORY_ALREADY_EXIST');
			JRequest :: setVar('view', 'application');
			JRequest :: setVar('hidemainmenu', 1);
			JRequest :: setVar('layout', 'formcategory');
			JRequest :: setVar('msg', $msg);
			parent :: display();
		}else 
		{
			$msg = JText::_('ERROR_SAVING_CATEGORY');
			$link = 'index.php?option=com_jsjobs&task=view&layout=categories';
			$this->setRedirect($link, $msg);
		}

	}

	function savesubcategory(){
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->storeSubCategory();
                $session = JFactory::getSession();
                $categoryid = $session->get('sub_categoryid');
		if ($return_value == 1){
			$msg = JText::_('CATEGORY_SAVED');
			$link = 'index.php?option=com_jsjobs&task=view&layout=subcategories&cd='.$categoryid;
			$this->setRedirect($link, $msg);
		}else if ($return_value == 2){
			$msg = JText::_('ALL_FIELD_MUST_BE_ENTERD');
			JRequest :: setVar('view', 'application');
			JRequest :: setVar('hidemainmenu', 1);
                        JRequest :: setVar('layout', 'formsubcategory');
                        JRequest :: setVar('msg', $msg);
			// Display based on the set variables
			$this->display();//parent :: display();
		}else if ($return_value == 3){
			$msg = JText::_('CATEGORY_ALREADY_EXIST');
			JRequest :: setVar('view', 'application');
			JRequest :: setVar('hidemainmenu', 1);
			JRequest :: setVar('layout', 'formsubcategory');
			JRequest :: setVar('msg', $msg);
			$this->display();//parent :: display();
		}else{
			$msg = JText::_('ERROR_SAVING_CATEGORY');
			$link = 'index.php?option=com_jsjobs&task=view&layout=subcategories&cd='.$categoryid;
			$this->setRedirect($link, $msg);
		}
	}

        function savejobtype()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->storeJobType();
		$link = 'index.php?option=com_jsjobs&task=view&layout=jobtypes';
		if ($return_value == 1)	{
			$msg = JText::_('JS_JOB_TYPE_SAVED');
			$this->setRedirect($link, $msg);
		}else {
			$msg = JText::_('JS_ERROR_SAVING_JOB_TYPE');
			$this->setRedirect($link, $msg);
		}
	}
        function saveages()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->storeAges();
		$link = 'index.php?option=com_jsjobs&task=view&layout=ages';
		if ($return_value == 1)	{
			$msg = JText::_('JS_AGE_SAVED');
			$this->setRedirect($link, $msg);
		}else {
			$msg = JText::_('JS_ERROR_SAVING_AGE');
			$this->setRedirect($link, $msg);
		}
	}
    function savecurrency()	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->storeCurrency();
		$link = 'index.php?option=com_jsjobs&task=view&layout=currency';
		if ($return_value == 1)	{
			$msg = JText::_('JS_CURRENCY_SAVED');
			$this->setRedirect($link, $msg);
		}else {
			$msg = JText::_('JS_ERROR_SAVING_CURRENCY');
			$this->setRedirect($link, $msg);
		}
	}

        function savecareerlevel()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->storeCareerLevel();
		$link = 'index.php?option=com_jsjobs&task=view&layout=careerlevels';
		if ($return_value == 1)	{
			$msg = JText::_('JS_CAREER_LEVEL_SAVED');
			$this->setRedirect($link, $msg);
		}else {
			$msg = JText::_('JS_ERROR_SAVING_CAREER_LEVEL');
			$this->setRedirect($link, $msg);
		}
	}

        function saveexperience()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->storeExperience();
		$link = 'index.php?option=com_jsjobs&task=view&layout=experience';
		if ($return_value == 1)	{
			$msg = JText::_('JS_EXPERIENCE_SAVED');
			$this->setRedirect($link, $msg);
		}else {
			$msg = JText::_('JS_ERROR_SAVING_EXPERIENCE');
			$this->setRedirect($link, $msg);
		}
	}
        function savesalaryrangetype()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->storeSalaryRangeType();
		$link = 'index.php?option=com_jsjobs&task=view&layout=salaryrangetype';
		if ($return_value == 1)	{
			$msg = JText::_('JS_SALARY_RANGE_TYPE_SAVED');
			$this->setRedirect($link, $msg);
		}else {
			$msg = JText::_('JS_ERROR_SAVING_SALARY_RANGE_TYPE');
			$this->setRedirect($link, $msg);
		}
	}

	function savejobstatus()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->storeJobStatus();
		$link = 'index.php?option=com_jsjobs&task=view&layout=jobstatus';
		if ($return_value == 1)	{
			$msg = JText::_('JS_JOB_STATUS_SAVED');
			$this->setRedirect($link, $msg);
		}else {
			$msg = JText::_('JS_ERROR_SAVING_JOB_STATUS');
			$this->setRedirect($link, $msg);
		}
	}

	function saveshift()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->storeShift();
		$link = 'index.php?option=com_jsjobs&task=view&layout=shifts';
		if ($return_value == 1)	{
			$msg = JText::_('JS_SHIFT_SAVED');
			$this->setRedirect($link, $msg);
		}else {
			$msg = JText::_('JS_ERROR_SAVING_SHIFT');
			$this->setRedirect($link, $msg);
		}
	}

	function savehighesteducation()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->storeHighestEducation();
		$link = 'index.php?option=com_jsjobs&task=view&layout=highesteducations';
		if ($return_value == 1)	{
			$msg = JText::_('JS_HIGHEST_EDUCATION_SAVED');
			$this->setRedirect($link, $msg);
		}else {
			$msg = JText::_('JS_ERROR_SAVING_HIGHEST_EDUCATION');
			$this->setRedirect($link, $msg);
		}
	}
	function savesalaryrange()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->storeSalaryRange();
		if ($return_value == 1)
		{
			$msg = JText::_('SALARY_RANGE_SAVED');
			$link = 'index.php?option=com_jsjobs&task=view&layout=salaryrange';
			$this->setRedirect($link, $msg);
		}else if ($return_value == 2){
			$msg = JText::_('ALL_FIELD_MUST_BE_ENTERD');
			JRequest :: setVar('view', 'application');
			JRequest :: setVar('hidemainmenu', 1);
				JRequest :: setVar('layout', 'formsalaryrange');
				JRequest :: setVar('msg', $msg);
			
			// Display based on the set variables
			parent :: display();
			//$link = 'index.php?option=com_jsjobs&c=application&layout=categories';
		}else if ($return_value == 3){
			$msg = JText::_('RANGE_ALREADY_EXIST');
			JRequest :: setVar('view', 'application');
			JRequest :: setVar('hidemainmenu', 1);
			JRequest :: setVar('layout', 'formsalaryrange');
			JRequest :: setVar('msg', $msg);
			parent :: display();
		}else {
			$msg = JText::_('ERROR_SAVING_RANGE');
			$link = 'index.php?option=com_jsjobs&task=view&layout=salaryrange';
			$this->setRedirect($link, $msg);
		}
		$link = 'index.php?option=com_jsjobs&c=application&layout=salaryrange';
	}

	function saveactivate()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->storeActivate();
		if ($return_value == 1)	{
			$msg = JText::_('JS_JOBS_ACTIVATED');
                        $session = JFactory::getSession();
                        $config = null;
                        $session->set('jsjobconfig_dft', $config);
		}elseif ($return_value == 3) {
			$msg = JText::_('JS_INVALID_ACTIVATION_KEY');
		}elseif ($return_value == 4) {
			$msg = JText::_('ERROR_CAN_NOT_ACTIVATE_JS_JOBS');
		}else {
			$msg = JText::_('ERROR_CAN_NOT_ACTIVATE_JS_JOBS');
		}
		$link = 'index.php?option=com_jsjobs&task=view&layout=updates';
		$this->setRedirect($link, $msg);
	}

	function saverole()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->storeRole();
		if ($return_value == 1)
		{
			$msg = JText::_('ROLE_SAVED');
			$link = 'index.php?option=com_jsjobs&task=view&layout=roles';
			$this->setRedirect($link, $msg);
		}else {
			$msg = JText::_('ERROR_SAVING_ROLE');
			$link = 'index.php?option=com_jsjobs&task=view&layout=roles';
			$this->setRedirect($link, $msg);
		}

		$link = 'index.php?option=com_jsjobs&c=application&layout=roles';
	}

	function saveuserrole()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->storeUserRole();
		if ($return_value == 1)	{
			$msg = JText::_('ROLE_SAVED');
			$link = 'index.php?option=com_jsjobs&task=view&layout=users';
			$this->setRedirect($link, $msg);
		}else {
			$msg = JText::_('ERROR_SAVING_ROLE');
			$link = 'index.php?option=com_jsjobs&task=view&layout=users';
			$this->setRedirect($link, $msg);
		}

	}

	function saveuserfield()
	{
		echo '<br> save user field';
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->storeUserField();
		if ($return_value == 1)
		{
			$msg = JText::_('USER_FIELD_SAVED');
			$link = 'index.php?option=com_jsjobs&task=view&layout=userfields';
			$this->setRedirect($link, $msg);
		}
		else if ($return_value == 2){
			$msg = JText::_('ALL_FIELD_MUST_BE_ENTERD');
			JRequest :: setVar('view', 'application');
			JRequest :: setVar('hidemainmenu', 1);
				JRequest :: setVar('layout', 'formuserfield');
				JRequest :: setVar('msg', $msg);
		
			// Display based on the set variables
			parent :: display();
		}else 
		{
			$msg = JText::_('ERROR_SAVING_USER_FIELD');
			$link = 'index.php?option=com_jsjobs&view=application&layout=formuserfield';
			$this->setRedirect($link, $msg);
		}
	}
    function publish(){
		$cur_layout = $_SESSION['cur_layout'];
		if ($cur_layout == 'countries') $this->publishcountries();
		elseif ($cur_layout == 'states') $this->publishstates();
		elseif ($cur_layout == 'counties')$this->publishcounties();
		elseif ($cur_layout == 'cities') $this->publishcities();

		elseif ($cur_layout == 'fieldsordering') $this->publishunpublishfields(1);
    }
    function publishunpublishfields($call){
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$ff = JRequest::getVar('ff');
		$return_value = $model->publishunpublishfields($call);
		if ($return_value == 1){
			$msg = JText::_('JS_PUBLISHED');
		}
		else{
			$msg = JText::_('JS_ERROR_PUBLISHING');
		}
		$link = 'index.php?option=com_jsjobs&task=view&layout=fieldsordering&ff='.$ff;
		$this->setRedirect($link, $msg);
    }
    function publishcountries(){
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->publishcountries();
		if ($return_value == 1){
                    $msg = JText::_('JS_PUBLISHED');
		}
		else{
                    $msg = JText::_('JS_ERROR_PUBLISHING');
		}

                $link = 'index.php?option=com_jsjobs&task=view&layout=countries';
                $this->setRedirect($link, $msg);
    }
    function publishstates(){
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
                $ct = JRequest::getVar('ct');
		$return_value = $model->publishstates();
		if ($return_value == 1){
                    $msg = JText::_('JS_PUBLISHED');
		}
		else{
                    $msg = JText::_('JS_ERROR_PUBLISHING');
		}

                $link = 'index.php?option=com_jsjobs&task=view&layout=states&ct='.$ct;
                $this->setRedirect($link, $msg);
    }
    function publishcounties(){
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
                $sd = JRequest::getVar('sd');
		$return_value = $model->publishcounties();
		if ($return_value == 1){
                    $msg = JText::_('JS_PUBLISHED');
		}
		else{
                    $msg = JText::_('JS_ERROR_PUBLISHING');
		}

                $link = 'index.php?option=com_jsjobs&task=view&layout=counties&sd='.$sd;
                $this->setRedirect($link, $msg);
    }
    function publishcities(){
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
                $co = JRequest::getVar('co');
		$return_value = $model->publishcities();
		if ($return_value == 1){
                    $msg = JText::_('JS_PUBLISHED');
		}
		else{
                    $msg = JText::_('JS_ERROR_PUBLISHING');
		}

                $link = 'index.php?option=com_jsjobs&task=view&layout=cities&co='.$co;
                $this->setRedirect($link, $msg);
    }
    function unpublish(){
		$cur_layout = $_SESSION['cur_layout'];
		if ($cur_layout == 'countries') $this->unpublishcountries();
		elseif ($cur_layout == 'states') $this->unpublishstates();
		elseif ($cur_layout == 'counties') $this->unpublishcounties();
		elseif ($cur_layout == 'cities') $this->unpublishcities();

		elseif ($cur_layout == 'fieldsordering') $this->publishunpublishfields(2);
        }
        function unpublishcountries(){
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->unpublishcountries();
		if ($return_value == 1){
                    $msg = JText::_('JS_UNPUBLISHED');
		}
		else{
                    $msg = JText::_('JS_ERROR_UNPUBLISHING');
		}

                $link = 'index.php?option=com_jsjobs&task=view&layout=countries';
                $this->setRedirect($link, $msg);
    }
    function unpublishstates(){
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
                $ct = JRequest::getVar('ct');
		$return_value = $model->unpublishstates();
		if ($return_value == 1){
                    $msg = JText::_('JS_UNPUBLISHED');
		}
		else{
                    $msg = JText::_('JS_ERROR_UNPUBLISHING');
		}

                $link = 'index.php?option=com_jsjobs&task=view&layout=states&ct='.$ct;
                $this->setRedirect($link, $msg);
    }
    function unpublishcounties(){
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
                $sd = JRequest::getVar('sd');
		$return_value = $model->unpublishcounties();
		if ($return_value == 1){
                    $msg = JText::_('JS_UNPUBLISHED');
		}
		else{
                    $msg = JText::_('JS_ERROR_UNPUBLISHING');
		}

                $link = 'index.php?option=com_jsjobs&task=view&layout=counties&sd='.$sd;
                $this->setRedirect($link, $msg);
    }
    function unpublishcities(){
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
                $co = JRequest::getVar('co');
		$return_value = $model->unpublishcities();
		if ($return_value == 1){
                    $msg = JText::_('JS_UNPUBLISHED');
		}
		else{
                    $msg = JText::_('JS_ERROR_UNPUBLISHING');
		}

                $link = 'index.php?option=com_jsjobs&task=view&layout=cities&co='.$co;
                $this->setRedirect($link, $msg);
        }
	function saveresumeuserfields()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$data = JRequest :: get('post');
		$fieldfor = $data['fieldfor'];
		//print_r($data);
		$return_value = $model->storeResumeUserFields();
		if ($return_value == 1) $msg = JText::_('RESUME_USER_FIELD_SAVED');
		else $msg = JText::_('ERROR_SAVING_RESUME_USER_FIELD');
		
		$link = 'index.php?option=com_jsjobs&view=application&layout=formresumeuserfield&ff='.$fieldfor;
		$this->setRedirect($link, $msg);
		
	}
	function saveemailtemplate()
	{
	$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$data = JRequest :: get('post');
		$templatefor = $data['templatefor'];
		$return_value = $model->storeEmailTemplate();
		switch($templatefor) {
			case 'company-new' : $tempfor = 'ew-cm'; break;
			case 'company-approval' : $tempfor = 'cm-ap'; break;
			case 'company-rejecting' : $tempfor = 'cm-rj'; break;
			case 'job-new' : $tempfor = 'ew-ob'; break;
			case 'job-approval' : $tempfor = 'ob-ap'; break;
			case 'job-rejecting' : $tempfor = 'ob-rj'; break;
			case 'resume-new' : $tempfor = 'ew-rm'; break;
			case 'message-email' : $tempfor = 'ew-ms'; break;
			case 'resume-approval' : $tempfor = 'rm-ap'; break;
			case 'resume-rejecting' : $tempfor = 'rm-rj'; break;
			case 'jobapply-jobapply' : $tempfor = 'ba-ja'; break;
			case 'department-new' : $tempfor = 'ew-md'; break;
			case 'employer-buypackage' : $tempfor = 'ew-rp'; break;
			case 'jobseeker-buypackage' : $tempfor = 'ew-js'; break;
			case 'job-alert' : $tempfor = 'jb-at'; break;
			case 'job-alert-visitor' : $tempfor = 'jb-at-vis'; break;
			case 'job-to-friend' : $tempfor = 'jb-to-fri'; break;
		}
		if ($return_value == 1)
		{
			$msg = JText::_('JS_EMAIL_TEMPATE_SAVED');
			$link = 'index.php?option=com_jsjobs&task=view&layout=emailtemplate&tf='.$tempfor;
			$this->setRedirect($link, $msg);
		}else {
			$msg = JText::_('ERROR_SAVING_EMAIL_TEMPLATE');
			$link = 'index.php?option=com_jsjobs&task=view&layout=emailtemplate&tf='.$tempfor;
			$this->setRedirect($link, $msg);
		}
	}

	function savecountry()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$data = JRequest :: get('post');
		$return_value = $model->storeCountry();
		$link = 'index.php?option=com_jsjobs&task=view&layout=countries';
		if ($return_value == 1)	{
			$msg = JText::_('JS_COUNTRY_SAVED');
		}elseif ($return_value == 3)	{
			$msg = JText::_('JS_COUNTRY_EXIST');
		}else {
			$msg = JText::_('JS_ERROR_SAVING_COUNTRY');
		}
		$this->setRedirect($link, $msg);
	}

	function savestate()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$data = JRequest :: get('post');
		$countrycode = $data['countrycode']; 
		$return_value = $model->storeState();
		$link = 'index.php?option=com_jsjobs&task=view&layout=states&ct='.$countrycode;
		if ($return_value == 1)	{
			$msg = JText::_('JS_STATE_SAVED');
		}elseif ($return_value == 3)	{
			$msg = JText::_('JS_STATE_EXIST');
		}else {
			$msg = JText::_('JS_ERROR_SAVING_STATE');
		}
		$this->setRedirect($link, $msg);
	}

	function savecounty()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$data = JRequest :: get('post');
		$statecode = $data['statecode']; 
		$return_value = $model->storeCounty();
		$link = 'index.php?option=com_jsjobs&task=view&layout=counties&sd='.$statecode;
		if ($return_value == 1)	{
			$msg = JText::_('JS_COUNTY_SAVED');
		}elseif ($return_value == 3)	{
			$msg = JText::_('JS_COUNTY_EXIST');
		}else {
			$msg = JText::_('JS_ERROR_SAVING_COUNTY');
		}
		$this->setRedirect($link, $msg);
	}

	function savecity()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$data = JRequest :: get('post');
		$countycode = $data['countycode']; 
		$return_value = $model->storeCity();
		$link = 'index.php?option=com_jsjobs&task=view&layout=cities&co='.$countycode;
		if ($return_value == 1)	{
			$msg = JText::_('JS_CITY_SAVED');
		}elseif ($return_value == 3)	{
			$msg = JText::_('JS_CITY_EXIST');
		}else {
			$msg = JText::_('JS_ERROR_SAVING_CITY');
		}
		$this->setRedirect($link, $msg);
	}

	function loadaddressdata()
	{
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		$data = JRequest :: get('post');
		$return_value = $model->loadAddressData();
		$link = 'index.php?option=com_jsjobs&task=view&layout=loadaddressdata&er=2';
		if ($return_value == 1)	{
			$msg = JText::_('JS_ADDRESS_DATA_SAVED');
			$link = 'index.php?option=com_jsjobs&task=view&layout=loadaddressdata';
		}elseif ($return_value == 3){ // file mismatch
			$msg = JText::_('JS_ADDRESS_DATA_COULD_NOT_SAVE');
		}elseif ($return_value == 3){ // file mismatch
			$msg = JText::_('JS_FILE_TYPE_ERROR');
		}elseif ($return_value == 5){ // state alredy exist 
			$msg = JText::_('JS_STATES_EXIST');
		}elseif ($return_value == 8){ // county alredy exist 
			$msg = JText::_('JS_COUNTIES_EXIST');
		}elseif ($return_value == 11){ // state and county alredy exist 
			$msg = JText::_('JS_STATES_COUNTIES_EXIST');
		}elseif ($return_value == 7){ // city alredy exist 
			$msg = JText::_('JS_CITIES_EXIST');
		}elseif ($return_value == 6){ // state and city alredy exist 
			$msg = JText::_('JS_STATES_CITIES_EXIST');
		}elseif ($return_value == 9){ // county and city alredy exist 
			$msg = JText::_('JS_COUNTIES_CITIES_EXIST');
		}elseif ($return_value == 12){ // state, counnty and city alredy exist 
			$msg = JText::_('JS_STATES_COUNTIES_CITIES_EXIST');
		}else {
			$msg = JText::_('JS_ADDRESS_DATA_COULD_NOT_SAVE');
		}
//		echo 're val '.$return_value;
		$this->setRedirect($link, $msg);
	}

	function listaddressdata()
	  { 
		 global $mainframe;
		 $mainframe = &JFactory::getApplication();
	     $data=JRequest::getVar( 'data');
	     $val=JRequest::getVar( 'val');
		
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$returnvalue = $model->listAddressData($data, $val);
		
		echo $returnvalue;
		$mainframe->close();
	  }

	function listempaddressdata()
	  { 
		 global $mainframe;
 		$mainframe = &JFactory::getApplication();
	     $name=JRequest::getVar( 'name');
	     $myname=JRequest::getVar( 'myname');
	     $nextname=JRequest::getVar( 'nextname');

	     $data=JRequest::getVar( 'data');
	     $val=JRequest::getVar( 'val');

		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$returnvalue = $model->listEmpAddressData($name, $myname, $nextname, $data, $val);
		
		echo $returnvalue;
		$mainframe->close();
	  }
	function listdepartments()
	{
		global $mainframe;
		$mainframe = &JFactory::getApplication();
		$val=JRequest::getVar( 'val');

		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$returnvalue = $model->listDepartments($val);

		echo $returnvalue;
		$mainframe->close();
	}
	
	function listsubcategories()
	{
		global $mainframe;
		$mainframe = &JFactory::getApplication();
		$val=JRequest::getVar( 'val');

		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$returnvalue = $model->listSubCategories($val);

		echo $returnvalue;
		$mainframe->close();
	}

	function listsubcategoriesforsearch()
	{
		global $mainframe;
		$mainframe = &JFactory::getApplication();
		$val=JRequest::getVar( 'val');

		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$returnvalue = $model->listSubCategoriesForSearch($val);

		echo $returnvalue;
		$mainframe->close();
	}
	function listuserdataforpackage()
	{
		global $mainframe;
		$mainframe = &JFactory::getApplication();
		$val=JRequest::getVar( 'val');

		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$returnvalue = $model->listUserDataForPackage($val);

		echo $returnvalue;
		$mainframe->close();
	}

    function makedefaultcurrency() // make default currency
	{
		$cid 	= JRequest::getVar( 'cid', array(), ''	, 'array' );
		$defaultid = $cid[0];
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->makeDefaultCurrency( $defaultid , 1 );
		if ($return_value == 1)	{ $msg = JText :: _('JS_DEFAULT_CURRENCY_SAVED'); }
		else{	$msg = JText :: _('JS_ERROR_MAKING_DEFAULT_CURRENCY'); }
		$link = 'index.php?option=com_jsjobs&c=jsjobs&task=view&layout=currency';
		$this->setRedirect($link, $msg);
	}

    function makedefaulttheme() // make default theme
	{
		$cid 	= JRequest::getVar( 'cid', array(), ''	, 'array' );
		$defaultid = $cid[0];
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->makeDefaultTheme( $defaultid , 1 );
		if ($return_value == 1)	{ $msg = JText :: _('JS_DEFAULT_THEME_SET'); }
		else{	$msg = JText :: _('JS_ERROR_MAKING_DEFAULT_THEME'); }
		$link = 'index.php?option=com_jsjobs&c=jsjobs&task=view&layout=themes';
		$this->setRedirect($link, $msg);
	}


    function display(){
		$document = & JFactory :: getDocument();
		$viewName = JRequest :: getVar('view', 'applications');
		$layoutName = JRequest :: getVar('layout', '');
		if ($layoutName == '')	
			if (isset($_SESSION['cur_layout']))$layoutName = $_SESSION['cur_layout'];
		if ($layoutName == '') {
			$layoutName = 'controlpanel';
			$_SESSION['cur_layout'] = $layoutName;
		}
		if($layoutName == 'formresumeuserfield'){
			$viewName = 'application';
		}
		$viewType = $document->getType();
		
		$view = & $this->getView($viewName, $viewType);
		$model = & $this->getModel('jsjobs', 'JSJobsModel');
		if (!JError :: isError($model))
		{
			$view->setModel($model, true);
		}
		$view->setLayout($layoutName);
		$view->display();
	}

	function getcopyjob()
	{
		global $mainframe;
		$mainframe = &JFactory::getApplication();
		$val=JRequest::getVar( 'val');

		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$returnvalue = $model->getCopyJob($val);

		echo $returnvalue;
		$mainframe->close();
	}
	function getaddressdata()
	{
		global $mainframe;
		$mainframe = &JFactory::getApplication();
		$val=JRequest::getVar( 'val');

		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$returnvalue = $model->getAddressData($val);

		echo json_encode($returnvalue);
		$mainframe->close();
	}

}
?>
