-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 18, 2013 at 01:57 PM
-- Server version: 5.5.24-log
-- PHP Version: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `newvision31`
--

-- --------------------------------------------------------

--
-- Table structure for table `#__assets`
--

DROP TABLE IF EXISTS `#__assets`;
CREATE TABLE IF NOT EXISTS `#__assets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `parent_id` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set parent.',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `level` int(10) unsigned NOT NULL COMMENT 'The cached level in the nested tree.',
  `name` varchar(50) NOT NULL COMMENT 'The unique name for the asset.\n',
  `title` varchar(100) NOT NULL COMMENT 'The descriptive title for the asset.',
  `rules` varchar(5120) NOT NULL COMMENT 'JSON encoded access control.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_asset_name` (`name`),
  KEY `idx_lft_rgt` (`lft`,`rgt`),
  KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=157 ;

--
-- Dumping data for table `#__assets`
--

INSERT INTO `#__assets` (`id`, `parent_id`, `lft`, `rgt`, `level`, `name`, `title`, `rules`) VALUES
(1, 0, 0, 67, 0, 'root.1', 'Root Asset', '{"core.login.site":{"6":1,"2":1},"core.login.admin":{"6":1},"core.login.offline":{"6":1},"core.admin":{"8":1},"core.manage":{"7":1},"core.create":{"6":1,"3":1},"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"core.edit.own":{"6":1,"3":1}}'),
(2, 1, 1, 2, 1, 'com_admin', 'com_admin', '{}'),
(3, 1, 3, 6, 1, 'com_banners', 'com_banners', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(4, 1, 7, 8, 1, 'com_cache', 'com_cache', '{"core.admin":{"7":1},"core.manage":{"7":1}}'),
(5, 1, 9, 10, 1, 'com_checkin', 'com_checkin', '{"core.admin":{"7":1},"core.manage":{"7":1}}'),
(6, 1, 11, 12, 1, 'com_config', 'com_config', '{}'),
(7, 1, 13, 16, 1, 'com_contact', 'com_contact', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(8, 1, 17, 30, 1, 'com_content', 'com_content', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":{"3":1},"core.delete":[],"core.edit":{"4":1},"core.edit.state":{"5":1},"core.edit.own":[]}'),
(9, 1, 31, 32, 1, 'com_cpanel', 'com_cpanel', '{}'),
(10, 1, 33, 34, 1, 'com_installer', 'com_installer', '{"core.admin":{"7":1},"core.manage":{"7":1},"core.delete":[],"core.edit.state":[]}'),
(11, 1, 35, 36, 1, 'com_languages', 'com_languages', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(12, 1, 37, 38, 1, 'com_login', 'com_login', '{}'),
(13, 1, 39, 40, 1, 'com_mailto', 'com_mailto', '{}'),
(14, 1, 41, 42, 1, 'com_massmail', 'com_massmail', '{}'),
(15, 1, 43, 44, 1, 'com_media', 'com_media', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":{"3":1},"core.delete":{"5":1}}'),
(16, 1, 45, 46, 1, 'com_menus', 'com_menus', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(17, 1, 47, 48, 1, 'com_messages', 'com_messages', '{"core.admin":{"7":1},"core.manage":{"7":1}}'),
(18, 1, 49, 50, 1, 'com_modules', 'com_modules', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(19, 1, 51, 54, 1, 'com_newsfeeds', 'com_newsfeeds', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(20, 1, 55, 56, 1, 'com_plugins', 'com_plugins', '{"core.admin":{"7":1},"core.manage":[],"core.edit":[],"core.edit.state":[]}'),
(21, 1, 57, 58, 1, 'com_redirect', 'com_redirect', '{"core.admin":{"7":1},"core.manage":[]}'),
(22, 1, 59, 60, 1, 'com_search', 'com_search', '{"core.admin":{"7":1},"core.manage":{"6":1}}'),
(23, 1, 61, 62, 1, 'com_templates', 'com_templates', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(24, 1, 63, 64, 1, 'com_users', 'com_users', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.own":{"6":1},"core.edit.state":[]}'),
(25, 1, 65, 68, 1, 'com_weblinks', 'com_weblinks', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":{"3":1},"core.delete":[],"core.edit":{"4":1},"core.edit.state":{"5":1},"core.edit.own":[]}'),
(26, 1, 69, 70, 1, 'com_wrapper', 'com_wrapper', '{}'),
(27, 8, 18, 21, 2, 'com_content.category.2', 'Uncategorised', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(28, 3, 4, 5, 2, 'com_banners.category.3', 'Uncategorised', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(29, 7, 14, 15, 2, 'com_contact.category.4', 'Uncategorised', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(30, 19, 52, 53, 2, 'com_newsfeeds.category.5', 'Uncategorised', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(31, 25, 66, 67, 2, 'com_weblinks.category.6', 'Uncategorised', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(32, 1, 425, 426, 0, 'com_content.category.7', 'News', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(33, 1, 427, 488, 0, 'com_content.category.8', 'Latest', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(45, 1, 489, 492, 0, 'com_content.category.20', 'Frontpage', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(49, 33, 484, 485, 1, 'com_content.article.12', 'Typography Options', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(50, 33, 468, 469, 1, 'com_content.article.13', 'S5 Flex Menu - Menu System', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(51, 33, 456, 457, 1, 'com_content.article.14', 'Module Positions and Styles', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(52, 33, 448, 449, 1, 'com_content.article.17', 'Installing The Template', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(53, 33, 480, 481, 1, 'com_content.article.18', 'The Template''s Settings', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(54, 33, 462, 463, 1, 'com_content.article.24', 'Page, Column and Row Widths', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(55, 33, 442, 443, 1, 'com_content.article.36', 'How To Setup the Search Box and Menus', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(56, 33, 482, 483, 1, 'com_content.article.37', 'Tool Tips', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(57, 33, 476, 477, 1, 'com_content.article.39', 'Site Shapers', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(59, 33, 472, 473, 1, 'com_content.article.110', 'S5 Tab Show', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(60, 33, 464, 465, 1, 'com_content.article.143', 'S5 Accordion Menu', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(61, 33, 452, 453, 1, 'com_content.article.146', 'Login and Register Setup', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(62, 33, 474, 475, 1, 'com_content.article.173', 'Search Engine Optimized ', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(63, 33, 458, 459, 1, 'com_content.article.195', 'Multibox', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(64, 33, 478, 479, 1, 'com_content.article.197', 'Template Specific Options', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(65, 33, 436, 437, 1, 'com_content.article.204', 'Google Fonts Enabled', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(68, 33, 432, 433, 1, 'com_content.article.212', 'CSS Tableless Overrides', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(69, 33, 434, 435, 1, 'com_content.article.214', 'Fixed Side Tabs', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(70, 33, 454, 455, 1, 'com_content.article.227', 'Menu Scroll To Section', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(71, 33, 444, 445, 1, 'com_content.article.228', 'IE7 and 8 CSS3 Support', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(72, 33, 450, 451, 1, 'com_content.article.230', 'Lazy Load Images', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(73, 33, 438, 439, 1, 'com_content.article.231', 'Hide Article Component Area', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(74, 33, 466, 467, 1, 'com_content.article.233', 'S5 Drop Down Panel', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(90, 1, 493, 494, 0, 'com_content.article.253', 'Cyan Template', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(92, 33, 428, 429, 1, 'com_content.article.255', '3rd Party Component Compatibility', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(93, 33, 470, 471, 1, 'com_content.article.256', 'S5 Image and Content Fader', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(95, 1, 495, 496, 0, 'com_banners.category.24', 'Joomla', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(96, 1, 497, 498, 0, 'com_banners.category.25', 'Text Ads', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(97, 1, 499, 500, 0, 'com_banners.category.26', 'Joomla! Promo', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(98, 1, 501, 502, 0, 'com_banners.category.27', 'Demo Banner', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(99, 1, 503, 504, 0, 'com_contact.category.28', 'Contacts', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(100, 1, 505, 506, 0, 'com_newsfeeds.category.29', 'Joomla!', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(101, 1, 507, 508, 0, 'com_newsfeeds.category.30', 'Free and Open Source Software', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(102, 1, 509, 510, 0, 'com_newsfeeds.category.31', 'Related Projects', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(103, 1, 511, 512, 0, 'com_weblinks.category.32', 'Joomla! Specific Links', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(104, 1, 513, 514, 0, 'com_weblinks.category.33', 'Other Resources', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(127, 27, 19, 20, 3, 'com_content.article.276', 'Sample Content', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(128, 8, 22, 29, 2, 'com_content.category.38', 'Sample Content', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(129, 128, 27, 28, 3, 'com_content.article.277', 'Sample Content', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(130, 128, 23, 24, 3, 'com_content.article.278', 'Sample Content', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(131, 128, 25, 26, 3, 'com_content.article.279', 'Sample Content', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(140, 33, 460, 461, 1, 'com_content.article.287', 'Optional Responsive Layout', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(141, 33, 446, 447, 1, 'com_content.article.288', 'Info Slide', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(142, 33, 440, 441, 1, 'com_content.article.289', 'Hide Divs, Content, and Modules', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(143, 33, 430, 431, 1, 'com_content.article.290', 'Built In File Compression', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(150, 33, 486, 487, 1, 'com_content.article.291', 'Stock Photography', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(156, 45, 490, 491, 1, 'com_content.article.296', 'Beautiful Design and Flexbile Features', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}');

-- --------------------------------------------------------

--
-- Table structure for table `#__associations`
--

DROP TABLE IF EXISTS `#__associations`;
CREATE TABLE IF NOT EXISTS `#__associations` (
  `id` int(11) NOT NULL COMMENT 'A reference to the associated item.',
  `context` varchar(50) NOT NULL COMMENT 'The context of the associated item.',
  `key` char(32) NOT NULL COMMENT 'The key for the association computed from an md5 on associated ids.',
  PRIMARY KEY (`context`,`id`),
  KEY `idx_key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__banners`
--

DROP TABLE IF EXISTS `#__banners`;
CREATE TABLE IF NOT EXISTS `#__banners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `imptotal` int(11) NOT NULL DEFAULT '0',
  `impmade` int(11) NOT NULL DEFAULT '0',
  `clicks` int(11) NOT NULL DEFAULT '0',
  `clickurl` varchar(200) NOT NULL DEFAULT '',
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `custombannercode` varchar(2048) NOT NULL,
  `sticky` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `params` text NOT NULL,
  `own_prefix` tinyint(1) NOT NULL DEFAULT '0',
  `metakey_prefix` varchar(255) NOT NULL DEFAULT '',
  `purchase_type` tinyint(4) NOT NULL DEFAULT '-1',
  `track_clicks` tinyint(4) NOT NULL DEFAULT '-1',
  `track_impressions` tinyint(4) NOT NULL DEFAULT '-1',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `reset` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `language` char(7) NOT NULL DEFAULT '',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`state`),
  KEY `idx_own_prefix` (`own_prefix`),
  KEY `idx_metakey_prefix` (`metakey_prefix`),
  KEY `idx_banner_catid` (`catid`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `#__banners`
--

INSERT INTO `#__banners` (`id`, `cid`, `type`, `name`, `alias`, `imptotal`, `impmade`, `clicks`, `clickurl`, `state`, `catid`, `description`, `custombannercode`, `sticky`, `ordering`, `metakey`, `params`, `own_prefix`, `metakey_prefix`, `purchase_type`, `track_clicks`, `track_impressions`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `reset`, `created`, `language`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `version`) VALUES
(1, 1, 0, 'OSM 1', 'osm-1', 0, 1919, 0, 'http://www.opensourcematters.org', 1, 24, '', '', 0, 1, '', '{}', 0, '', -1, -1, -1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '*', 0, '', '0000-00-00 00:00:00', 0, 1),
(2, 1, 0, 'OSM 2', 'osm-2', 0, 2021, 1, 'http://www.opensourcematters.org', 1, 24, '', '', 0, 2, '', '{}', 0, '', -1, -1, -1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '*', 0, '', '0000-00-00 00:00:00', 0, 1),
(3, 1, 0, 'Joomla!', 'joomla', 0, 504, 0, 'http://www.joomla.org', 1, 25, '', '<a href="{CLICKURL}" target="_blank">{NAME}</a>\r\n<br/>\r\nJoomla! The most popular and widely used Open Source CMS Project in the world.', 0, 1, '', '{}', 0, '', -1, -1, -1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '*', 0, '', '0000-00-00 00:00:00', 0, 1),
(4, 1, 0, 'JoomlaCode', 'joomlacode', 0, 504, 0, 'http://joomlacode.org', 1, 25, '', '<a href="{CLICKURL}" target="_blank">{NAME}</a>\r\n<br/>\r\nJoomlaCode, development and distribution made easy.', 0, 2, '', '{}', 0, '', -1, -1, -1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '*', 0, '', '0000-00-00 00:00:00', 0, 1),
(5, 1, 0, 'Joomla! Extensions', 'joomla-extensions', 0, 499, 0, 'http://extensions.joomla.org', 1, 25, '', '<a href="{CLICKURL}" target="_blank">{NAME}</a>\r\n<br/>\r\nJoomla! Components, Modules, Plugins and Languages by the bucket load.', 0, 3, '', '{}', 0, '', -1, -1, -1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '*', 0, '', '0000-00-00 00:00:00', 0, 1),
(6, 1, 0, 'Joomla! Shop', 'joomla-shop', 0, 499, 0, 'http://shop.joomla.org', 1, 25, '', '<a href="{CLICKURL}" target="_blank">{NAME}</a>\r\n<br/>\r\nFor all your Joomla! merchandise.', 0, 4, '', '{}', 0, '', -1, -1, -1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '*', 0, '', '0000-00-00 00:00:00', 0, 1),
(7, 1, 0, 'Joomla! Promo Shop', 'joomla-promo-shop', 0, 8, 1, 'http://shop.joomla.org', 1, 26, '', '', 0, 3, '', '{}', 0, '', -1, -1, -1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '*', 0, '', '0000-00-00 00:00:00', 0, 1),
(8, 1, 0, 'Joomla! Promo Books', 'joomla-promo-books', 0, 10, 0, 'http://shop.joomla.org/amazoncom-bookstores.html', 1, 26, '', '', 0, 4, '', '{}', 0, '', -1, -1, -1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '*', 0, '', '0000-00-00 00:00:00', 0, 1),
(9, 1, 0, 'Demo Banner', 'demo-banner', 0, 2634, 0, '', 1, 27, '', '', 0, 1, '', '{"width":0,"height":0}', 0, '', -1, -1, -1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '*', 0, '', '0000-00-00 00:00:00', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `#__banner_clients`
--

DROP TABLE IF EXISTS `#__banner_clients`;
CREATE TABLE IF NOT EXISTS `#__banner_clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `contact` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `extrainfo` text NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `metakey` text NOT NULL,
  `own_prefix` tinyint(4) NOT NULL DEFAULT '0',
  `metakey_prefix` varchar(255) NOT NULL DEFAULT '',
  `purchase_type` tinyint(4) NOT NULL DEFAULT '-1',
  `track_clicks` tinyint(4) NOT NULL DEFAULT '-1',
  `track_impressions` tinyint(4) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`id`),
  KEY `idx_own_prefix` (`own_prefix`),
  KEY `idx_metakey_prefix` (`metakey_prefix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `#__banner_tracks`
--

DROP TABLE IF EXISTS `#__banner_tracks`;
CREATE TABLE IF NOT EXISTS `#__banner_tracks` (
  `track_date` datetime NOT NULL,
  `track_type` int(10) unsigned NOT NULL,
  `banner_id` int(10) unsigned NOT NULL,
  `count` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`track_date`,`track_type`,`banner_id`),
  KEY `idx_track_date` (`track_date`),
  KEY `idx_track_type` (`track_type`),
  KEY `idx_banner_id` (`banner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__categories`
--

DROP TABLE IF EXISTS `#__categories`;
CREATE TABLE IF NOT EXISTS `#__categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0',
  `level` int(10) unsigned NOT NULL DEFAULT '0',
  `path` varchar(255) NOT NULL DEFAULT '',
  `extension` varchar(50) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `description` mediumtext,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access` int(10) unsigned DEFAULT NULL,
  `params` text NOT NULL,
  `metadesc` varchar(1024) NOT NULL COMMENT 'The meta description for the page.',
  `metakey` varchar(1024) NOT NULL COMMENT 'The meta keywords for the page.',
  `metadata` varchar(2048) NOT NULL COMMENT 'JSON encoded metadata properties.',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `cat_idx` (`extension`,`published`,`access`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_path` (`path`),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_alias` (`alias`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=47 ;

--
-- Dumping data for table `#__categories`
--

INSERT INTO `#__categories` (`id`, `asset_id`, `parent_id`, `lft`, `rgt`, `level`, `path`, `extension`, `title`, `alias`, `note`, `description`, `published`, `checked_out`, `checked_out_time`, `access`, `params`, `metadesc`, `metakey`, `metadata`, `created_user_id`, `created_time`, `modified_user_id`, `modified_time`, `hits`, `language`, `version`) VALUES
(1, 0, 0, 0, 39, 0, '', 'system', 'ROOT', 'root', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{}', '', '', '', 589, '2009-10-18 16:07:09', 0, '0000-00-00 00:00:00', 0, '*', 1),
(2, 27, 1, 27, 28, 1, 'uncategorised', 'com_content', 'Uncategorised', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 589, '2010-06-28 13:26:37', 0, '0000-00-00 00:00:00', 0, '*', 1),
(3, 28, 1, 29, 30, 1, 'uncategorised', 'com_banners', 'Uncategorised', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":"","foobar":""}', '', '', '{"page_title":"","author":"","robots":""}', 589, '2010-06-28 13:27:35', 0, '0000-00-00 00:00:00', 0, '*', 1),
(4, 29, 1, 31, 32, 1, 'uncategorised', 'com_contact', 'Uncategorised', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 589, '2010-06-28 13:27:57', 0, '0000-00-00 00:00:00', 0, '*', 1),
(5, 30, 1, 33, 34, 1, 'uncategorised', 'com_newsfeeds', 'Uncategorised', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 589, '2010-06-28 13:28:15', 0, '0000-00-00 00:00:00', 0, '*', 1),
(6, 31, 1, 35, 36, 1, 'uncategorised', 'com_weblinks', 'Uncategorised', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 589, '2010-06-28 13:28:33', 0, '0000-00-00 00:00:00', 0, '*', 1),
(7, 32, 1, 23, 26, 1, 'news', 'com_content', 'News', 'news', '', 'Select a news topic from the list below, then select a news article to read.', 1, 0, '0000-00-00 00:00:00', 1, '{}', '', '', '', 589, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 1, '*', 1),
(8, 33, 7, 24, 25, 2, 'news/latest-news', 'com_content', 'Latest', 'latest-news', '', 'The latest news from the Joomla! Team', 1, 0, '0000-00-00 00:00:00', 1, '{}', '', '', '', 589, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 1, '*', 1),
(20, 45, 1, 21, 22, 1, 'frontpage', 'com_content', 'Frontpage', 'frontpage', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{}', '', '', '', 589, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '*', 1),
(24, 95, 1, 19, 20, 1, 'joomla', 'com_banners', 'Joomla', 'joomla', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{}', '', '', '', 589, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '*', 1),
(25, 96, 1, 17, 18, 1, 'text-ads', 'com_banners', 'Text Ads', 'text-ads', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{}', '', '', '', 589, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '*', 1),
(26, 97, 1, 15, 16, 1, 'joomla-promo', 'com_banners', 'Joomla! Promo', 'joomla-promo', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{}', '', '', '', 589, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '*', 1),
(27, 98, 1, 13, 14, 1, 'demo-banner', 'com_banners', 'Demo Banner', 'demo-banner', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{}', '', '', '', 589, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '*', 1),
(28, 99, 1, 11, 12, 1, 'contacts', 'com_contact_details', 'Contacts', 'contacts', '', 'Contact Details for this Web site', 1, 0, '0000-00-00 00:00:00', 1, '{}', '', '', '', 589, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '*', 1),
(29, 100, 1, 9, 10, 1, 'joomla', 'com_newsfeeds', 'Joomla!', 'joomla', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{}', '', '', '', 589, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '*', 1),
(30, 101, 1, 7, 8, 1, 'free-and-open-source-software', 'com_newsfeeds', 'Free and Open Source Software', 'free-and-open-source-software', '', 'Read the latest news about free and open source software from some of its leading advocates.', 1, 0, '0000-00-00 00:00:00', 1, '{}', '', '', '', 589, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '*', 1),
(31, 102, 1, 5, 6, 1, 'related-projects', 'com_newsfeeds', 'Related Projects', 'related-projects', '', 'Joomla builds on and collaborates with many other free and open source projects. Keep up with the latest news from some of them.', 1, 0, '0000-00-00 00:00:00', 1, '{}', '', '', '', 589, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '*', 1),
(32, 103, 1, 3, 4, 1, 'joomla-specific-links', 'com_weblinks', 'Joomla! Specific Links', 'joomla-specific-links', '', 'A selection of links that are all related to the Joomla! Project.', 1, 0, '0000-00-00 00:00:00', 1, '{}', '', '', '', 589, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '*', 1),
(33, 104, 1, 1, 2, 1, 'other-resources', 'com_weblinks', 'Other Resources', 'other-resources', '', '', 1, 62, '2009-04-07 19:56:18', 1, '{}', '', '', '', 589, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '*', 1),
(38, 128, 1, 37, 38, 1, 'sample-content', 'com_content', 'Sample Content', 'sample-content', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 589, '2012-04-10 19:38:43', 0, '0000-00-00 00:00:00', 0, '*', 1);

-- --------------------------------------------------------

--
-- Table structure for table `#__contact_details`
--

DROP TABLE IF EXISTS `#__contact_details`;
CREATE TABLE IF NOT EXISTS `#__contact_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `con_position` varchar(255) DEFAULT NULL,
  `address` text,
  `suburb` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `postcode` varchar(100) DEFAULT NULL,
  `telephone` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `misc` mediumtext,
  `image` varchar(255) DEFAULT NULL,
  `email_to` varchar(255) DEFAULT NULL,
  `default_con` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `access` int(10) unsigned DEFAULT NULL,
  `mobile` varchar(255) NOT NULL DEFAULT '',
  `webpage` varchar(255) NOT NULL DEFAULT '',
  `sortname1` varchar(255) NOT NULL,
  `sortname2` varchar(255) NOT NULL,
  `sortname3` varchar(255) NOT NULL,
  `language` char(7) NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `metadata` text NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if article is featured.',
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`published`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_featured_catid` (`featured`,`catid`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `#__contact_details`
--

INSERT INTO `#__contact_details` (`id`, `name`, `alias`, `con_position`, `address`, `suburb`, `state`, `country`, `postcode`, `telephone`, `fax`, `misc`, `image`, `email_to`, `default_con`, `published`, `checked_out`, `checked_out_time`, `ordering`, `params`, `user_id`, `catid`, `access`, `mobile`, `webpage`, `sortname1`, `sortname2`, `sortname3`, `language`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `metakey`, `metadesc`, `metadata`, `featured`, `xreference`, `publish_up`, `publish_down`, `version`, `hits`) VALUES
(1, 'Name', 'name', 'Position', 'Street', 'Suburb', 'State', 'Country', 'Zip Code', 'Telephone', 'Fax', 'Miscellanous info', 'powered_by.png', 'email@email.com', 1, -2, 0, '0000-00-00 00:00:00', 1, '{"show_name":1,"show_position":1,"show_email":0,"show_street_address":1,"show_suburb":1,"show_state":1,"show_postcode":1,"show_country":1,"show_telephone":1,"show_mobile":1,"show_fax":1,"show_webpage":1,"show_misc":1,"show_image":1,"allow_vcard":0,"contact_icons":0,"icon_address":"","icon_email":"","icon_telephone":"","icon_fax":"","icon_misc":"","show_email_form":1,"email_description":1,"show_email_copy":1,"banned_email":"","banned_subject":"","banned_text":""}', 0, 12, 1, '', '', '', '', '', '', '0000-00-00 00:00:00', 589, '', '0000-00-00 00:00:00', 0, '', '', '', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0),
(2, 'Name', 'name', '', 'Street', 'Suburb', 'State', 'Country', 'Zip Code', 'Telephone', 'Fax', 'Miscellaneous info', '', 'email@email.com', 0, 1, 0, '0000-00-00 00:00:00', 2, '{"show_contact_category":"","show_contact_list":"","presentation_style":"plain","show_name":"1","show_position":"","show_email":"1","show_street_address":"1","show_suburb":"1","show_state":"1","show_postcode":"1","show_country":"1","show_telephone":"1","show_mobile":"","show_fax":"1","show_webpage":"","show_misc":"","show_image":"","allow_vcard":"","show_articles":"","show_profile":"","show_links":"","linka_name":"","linka":null,"linkb_name":"","linkb":null,"linkc_name":"","linkc":null,"linkd_name":"","linkd":null,"linke_name":"","linke":"","contact_layout":"","show_email_form":"1","show_email_copy":"1","banned_email":"","banned_subject":"","banned_text":"","validate_session":"","custom_reply":"","redirect":""}', 0, 4, 1, '', '', '', '', '', '*', '2012-08-08 13:48:06', 589, '', '2012-08-08 14:01:34', 42, '', '', '{"robots":"","rights":""}', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `#__content`
--

DROP TABLE IF EXISTS `#__content`;
CREATE TABLE IF NOT EXISTS `#__content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `introtext` mediumtext NOT NULL,
  `fulltext` mediumtext NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `images` text NOT NULL,
  `urls` text NOT NULL,
  `attribs` varchar(5120) NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `metadata` text NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if article is featured.',
  `language` char(7) NOT NULL COMMENT 'The language code for the article.',
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`state`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_featured_catid` (`featured`,`catid`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=297 ;

--
-- Dumping data for table `#__content`
--

INSERT INTO `#__content` (`id`, `asset_id`, `title`, `alias`, `introtext`, `fulltext`, `state`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`, `featured`, `language`, `xreference`) VALUES
(12, 49, 'Typography Options', 'typography-options', '<blockquote><p>This is a sample blockquote. Use <strong>&lt;blockquote&gt;&lt;p&gt;Your content goes \r\nhere!&lt;/p&gt;&lt;/blockquote&gt;</strong> to create a blockquote.</p></blockquote>\r\n\r\n\r\n\r\n\r\n<div class="s5_greenbox">\r\n<div class="point">\r\n\r\n\r\n&lt;div class="s5_greenbox"&gt;\r\n&lt;div class="point"&gt;\r\nYour text here\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n\r\n\r\n</div>\r\n</div>\r\n\r\n<br />\r\n\r\n\r\n<div class="s5_redbox">\r\n<div class="point">\r\n\r\n\r\n&lt;div class="s5_redbox"&gt;\r\n&lt;div class="point"&gt;\r\nYour text here\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n\r\n\r\n</div>\r\n</div>\r\n\r\n\r\n\r\n\r\n<br />\r\n\r\n<div class="s5_bluebox">\r\n<div class="point">\r\n\r\n\r\n&lt;div class="s5_bluebox"&gt;\r\n&lt;div class="point"&gt;\r\nYour text here\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n\r\n\r\n</div>\r\n</div>\r\n\r\n\r\n\r\n<br />\r\n\r\n\r\n<div class="s5_graybox">\r\n<div class="point">\r\n\r\n\r\n&lt;div class="s5_graybox"&gt;\r\n&lt;div class="point"&gt;\r\nYour text here\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n\r\n\r\n</div>\r\n</div>\r\n\r\n\r\n\r\n\r\n<br />\r\n\r\n<div class="black_box">This is a styled box. Use <strong>&lt;div class=&quot;black_box&quot;&gt;Your content \r\ngoes here!&lt;/div&gt;</strong></div>\r\n\r\n<br />\r\n\r\n<div class="gray_box">This is a styled box. Use <strong>&lt;div class=&quot;gray_box&quot;&gt;Your content \r\ngoes here!&lt;/div&gt;</strong></div>\r\n\r\n<br />\r\n\r\n<div class="red_box">This is a styled box. Use <strong>&lt;div class=&quot;red_box&quot;&gt;Your content \r\ngoes here!&lt;/div&gt;</strong></div>\r\n\r\n<br />\r\n\r\n<div class="blue_box">This is a styled box. Use <strong>&lt;div class=&quot;blue_box&quot;&gt;Your content \r\ngoes here!&lt;/div&gt;</strong></div>\r\n\r\n<br />\r\n\r\n<div class="green_box">This is a styled box. Use <strong>&lt;div class=&quot;green_box&quot;&gt;Your content \r\ngoes here!&lt;/div&gt;</strong></div>\r\n\r\n<br />\r\n\r\n<div class="yellow_box">This is a styled box. Use <strong>&lt;div class=&quot;yellow_box&quot;&gt;Your content \r\ngoes here!&lt;/div&gt;</strong></div>\r\n\r\n<br />\r\n\r\n<div class="orange_box">This is a styled box. Use <strong>&lt;div class=&quot;orange_box&quot;&gt;Your content \r\ngoes here!&lt;/div&gt;</strong></div>\r\n\r\n<br />\r\n\r\n\r\n\r\nThis is an image with the "boxed" class applied:<br /><br />\r\n\r\n<img class="boxed" src="http://www.shape5.com/demo/images/small1.jpg" alt=""></img>\r\n<br /><br /><br /><br />\r\n<br />\r\n\r\n\r\n\r\n\r\nThis is an image with the "boxed_black" class applied:<br /><br />\r\n\r\n<img class="boxed_black" src="http://www.shape5.com/demo/images/small1.jpg" alt=""></img>\r\n<br /><br />\r\n\r\n\r\n\r\n\r\nThis is an image with the "padded" class applied:<br /><br />\r\n\r\n<img class="padded" src="http://www.shape5.com/demo/images/small1.jpg" alt=""></img>\r\n<br /><br />\r\n\r\n\r\n\r\nThis is an image with the "full_width" class applied. This can also be done automatically in the template configuration. Be sure to review our Vertex Guide <a href="http://www.shape5.com/joomla_tutorials.html" target="_blank">here</a> for other full width image options.<br /><br />\r\n\r\n<img class="full_width" src="http://www.shape5.com/demo/images/general/typography_full_width.jpg" alt=""></img>\r\n<br /><br />\r\n\r\n\r\n\r\n\r\n<h1>Heading 1</h1>\r\n<h2>Heading 2</h2>\r\n<h3>Heading 3</h3>\r\n<h4>Heading 4</h4>\r\n<h5>Heading 5</h5>\r\n<br />\r\n\r\n\r\n&lt;a&gt; With s5_readon class applied:<br /><br />\r\n<a href="" class="s5_readon">s5_readon</a>\r\n<br /><br />\r\n&lt;h3&gt; With font_highlight class applied:<br /><br />\r\n<h3 class="font_highlight">font_highlight</h3>\r\n\r\n<br />\r\n\r\n<div class="code">This is a sample code div. Use <strong>&lt;div \r\n  class=&quot;code&quot;&gt;Your content goes here!&lt;/div&gt;</strong> to create a code div.<br /><br />#s5_code { width: 30px; color: #fff; line-height: 45px; } </div>\r\n\r\n<br />\r\n\r\n<ol>\r\n<li>This is an <strong>Ordered List</strong></li>\r\n<li>Congue Quisque augue elit dolor nibh.</li>\r\n<li>Condimentum elte quis.</li>\r\n<li>Opsum dolor sit amet consectetuer.</li>\r\n</ol>\r\n\r\n<br />\r\n\r\n<ul>\r\n<li>This is an <strong>Unordered List</strong></li>\r\n<li>Congue Quisque augue elit dolor nibh.</li>\r\n<li>Condimentum elte quis.</li>\r\n<li>Opsum dolor sit amet consectetuer.</li>\r\n</ul>\r\n\r\n<br />\r\n\r\n<ul class="ul_arrow">\r\n<li>This is an <strong>Unordered List with class ul_arrow</strong></li>\r\n<li>Congue Quisque augue elit dolor nibh.</li>\r\n<li>Condimentum elte quis.</li>\r\n<li>Opsum dolor sit amet consectetuer.</li>\r\n</ul>\r\n\r\n\r\n<br />\r\n\r\n<ul class="ul_star">\r\n<li>This is an <strong>Unordered List with class ul_star</strong></li>\r\n<li>Congue Quisque augue elit dolor nibh.</li>\r\n<li>Condimentum elte quis.</li>\r\n<li>Opsum dolor sit amet consectetuer.</li>\r\n</ul>\r\n\r\n<br />\r\n\r\n<ul class="ul_bullet">\r\n<li>This is an <strong>Unordered List with class ul_bullet</strong></li>\r\n<li>Congue Quisque augue elit dolor nibh.</li>\r\n<li>Condimentum elte quis.</li>\r\n<li>Opsum dolor sit amet consectetuer.</li>\r\n</ul>\r\n\r\n\r\n<br />\r\n\r\n<ul class="s5_features_list">\r\n<li>This is an <strong>Unordered List with class s5_features_list</strong></li>\r\n<li>Lorem ipsum dolor sit amet, consectetur es \r\nelit. In rhoncus lobortis orci, sed vestibulum \r\net. Fusce in dolor velit, sit amet vehicul.</li>\r\n<li>Lorem ipsum dolor sit amet, consectetur es \r\nelit. In rhoncus lobortis orci, sed vestibulum \r\net. Fusce in dolor velit, sit amet vehicul.</li>\r\n<li>Lorem ipsum dolor sit amet, consectetur es \r\nelit. In rhoncus lobortis orci, sed vestibulum \r\net. Fusce in dolor velit, sit amet vehicul.</li>\r\n</ul>\r\n\r\n\r\n<br />\r\n\r\nThe following list will support lists up to number 9, add the following class to the UL wrapping the below LI elements, class="ul_numbers":\r\n<br /><br />\r\n\r\n<ul class="ul_numbers">\r\n\r\n<li class="li_number1">This is a sample styled number list <strong>&lt;li class=&quot;li_number1&quot;&gt;Your content \r\ngoes here!&lt;/li&gt;</strong></li>\r\n\r\n<li class="li_number2">This is a sample styled number list <strong>&lt;li class=&quot;li_number2&quot;&gt;Your content \r\ngoes here!&lt;/li&gt;</strong></li>\r\n\r\n<li class="li_number3">This is a sample styled number list <strong>&lt;li class=&quot;li_number3&quot;&gt;Your content \r\ngoes here!&lt;/li&gt;</strong></li>\r\n\r\n<li class="li_number4">This is a sample styled number list <strong>&lt;li class=&quot;li_number4&quot;&gt;Your content \r\ngoes here!&lt;/li&gt;</strong></li>\r\n\r\n</ul>\r\n\r\n\r\n\r\n<br />', '', 1, 8, '2007-12-05 11:25:14', 589, '', '2012-10-13 19:05:54', 42, 0, '0000-00-00 00:00:00', '2007-12-05 11:24:52', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"1","link_author":"","show_create_date":"0","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 66, 21, '', '', 1, 25480, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(13, 50, 'S5 Flex Menu - Menu System', 's5-flex-menu-menu-system', 'The S5 Flex Menu system is a very powerful plugin that provides functionality \r\nfar beyond what the standard Joomla menu system can provide. This plugin \r\nis intended to be as an extension of the existing menu system in Joomla to add many new features! Please see the full list of features below. \r\n\r\n<br /><br />\r\n\r\nThis menu system works off of the core Joomla mootools script so no extra javascript library is needed and keep download sizes to a minimum. Also, if you do not want to use this menu you can simply turn it it off from the template configuration page.\r\n<br /><br />\r\n\r\nTake your website to  the next design level by using the robust and feature\r\nrich S5 Flex Menu System. Organize your links with ease and show content \r\nin places you never could before!\r\n<br /><br />\r\n\r\nPlease note - this template does not support sub text on the first level links. However, all sub menus do.\r\n\r\n<br /><br />\r\n<h3>Menu Features:</h3>\r\n\r\n\r\n\r\n<ul class="ul_star">\r\n<li>Multiple javascript effects with core mootools</li>\r\n<li>Multiple columns for menu items or modules</li>\r\n<li>Modules load directly into the menu</li>\r\n<li>Group sub menu items into the same column or fly out</li>\r\n<li>Optional sub texts for each menu item</li>\r\n<li>Optional menu icon images for each menu item</li>\r\n<li>And much more!</li>\r\n</ul>\r\n\r\n\r\n<br /><br />\r\n<h3>Menu Screenshot:</h3>\r\n\r\n<img class="padded" src="images/flexmenu.jpg" alt=""></img>\r\n\r\n<div style="clear:both;height:0px"></div>\r\n\r\n<br /><br />\r\n\r\n\r\n\r\n<div class="blue_box"><strong>I like what I see! I want to <a href="http://www.shape5.com/join-now.html" target="_top">JOIN TODAY</a>.</strong></div><br /></ul>', '', 1, 8, '2007-12-05 11:32:41', 589, '', '2012-06-25 19:54:14', 42, 0, '0000-00-00 00:00:00', '2007-12-05 11:32:07', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 86, 22, '', '', 1, 31527, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(14, 51, 'Module Positions and Styles', 'module-positions-and-styles', '<br />\r\n<div class="blue_box">\r\n<a style="text-decoration:underline" href="index.php/features-mainmenu-47/template-features/responsive-layout">\r\nBe sure to check out the responsive layout page to see how the layout below is constructed on multiple screen sizes</a>\r\n</div>\r\n<br />\r\n<br />\r\n<h3>All modules are fully collapsible</h3>\r\n<br />\r\nWhat exactly is a collapsing module? It&#39;s quite simple, whenever a module is not published to a postion that position does not appear on the frontend of the template. Consider the example below:\r\n<br /><br />\r\n<img class="padded" src="http://www.shape5.com/demo/images/general/modules_6.png"></img>\r\n<br /><br />\r\nThis particular row has 6 module positions available to publish to. Let&#39;s say you only want to publish to 4 of these positions. The template will automatically collapse the modules you do not want to use and adjust the size of the modules accordingly:\r\n<br /><br />\r\n<img class="padded" src="http://www.shape5.com/demo/images/general/modules_4.png"></img>\r\n<br /><br />\r\nIf no modules are published to the row the entire row itself will not show. The best feature of this is every module can be published to its own unique pages so the layout of your site can change on every page!\r\n<br /><br /><br />\r\n<h3>Infinite Layouts</h3>\r\n<br />\r\nBecause there are so many module positions available in so many different areas, the number of layouts you can create are limitless! For example, if you would like to show your main content area on the right side of your site but still have a column of modules, simply published your modules to the right or right_inset positions or both. The same would be true for the opposite, if you want a column on the left simply publish modules to left or left_inset. Of course you can always choose to not have a column at all. Remember, any module not published to will automatically collapse and the remaining area will automatically adjust. There is no need to choose a pre-defined layout for your entire site, simply use the power of collpasing module positions and take advantage of the numerous amount of module positions to create any layout you can dream of! Be sure to checkout the layout of modules below.\r\n<br /><br /><br />\r\n<h3>Dozens of Modules</h3>\r\n<br />\r\nBelow is a complete list of all the module positions available for this template.\r\n<br /><br />\r\n<img class="padded" src="http://www.shape5.com/images/products/2012/new_vision/new_vision_layout.png"></img>\r\n<br /><br /><br />\r\n\r\n<h3>How to install and setup module styles:</h3></p> <ol> <li>   Download any module you wish to publish to your site.</li> <li>In the backend of Joomla    navigate to the menu item Extensions/Install Uninstall</li> <br />   <img class="padded" style="margin-bottom:14px" src="http://www.shape5.com/demo/images/general/install_menu.png" border="0" width="199" height="172" /><br /> <li>Browse for the module&#39;s install file and click Upload File & Install.</li>  <li>   Once the module has be installed navigate to the menu item Extensions/Module    Manager (same menu as above)</li>  <li>Find the Module just installed and click on it&#39;s title.</li>  <li>   Change any parameters that you wish and be sure to set it to published and    publish it to your desired module position.</li><li>To apply a module style simply fill in the module class suffix field with any of this template&#39;s included module styles. This parameter setting is found under Module Parameters on the right side of the screen. </li> <br />   <img class="padded" style="margin-bottom:14px" src="http://www.shape5.com/demo/images/general/module_suffix.png" border="0" width="200" height="72" /><br /> <li>Assign what pages you would like the module to appear on and finally click Save.</li><br />   <img class="padded" src="http://www.shape5.com/demo/images/general/page_assignment.png" border="0" width="200" height="144" /><br />   </ol>            <p>&nbsp;</p>', '', 1, 8, '2007-12-05 13:16:18', 589, '', '2012-10-13 19:46:20', 42, 0, '0000-00-00 00:00:00', '2007-12-05 13:16:05', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 74, 23, '', '', 1, 26968, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(17, 52, 'Installing The Template', 'installing-the-template', '<br /><ul class="bullet_list"><ul class="ul_numbers"><li class="li_number1">Download the installation package from our download section.</li><li class="li_number2">Once the download is complete go to the backend of Joomla.</li><li class="li_number3">     Navigate through your menu system to Extensions/Extensions Manager.</li>   </ul>   \r\n</ul>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n<img border="0" src="http://www.shape5.com/demo/images/general/install_menu.png" /></p>\r\n<ul class="bullet_list"><ul class="ul_numbers">          <li class="li_number4">Once at the installation screen click the browse button and navigate to where you downloaded the template file.</li>     <li class="li_number5">Once you have the file selected click &#39;Upload File and Install&#39;</li>     \r\n  <p>\r\n  <img border="0" src="http://www.shape5.com/demo/images/general/browse.png" /></p>\r\n  <p><b>The template is now installed, now let&#39;s set it as the default template:</b><br />     </p>     <li class="li_number6">Navigate through your menu system to Extensions/Template Manager.</li><li class="li_number7">Find the radio button next to the newly installed template.</li><li class="li_number8">Click on the Default button at the top right of the screen and you&#39;re done!</li><p>\r\n  <img border="0" src="http://www.shape5.com/demo/images/general/default.png" /></ol>   </ul>   <p>&nbsp;</p>', '', 1, 8, '2007-12-11 19:38:14', 589, '', '2012-06-25 19:54:14', 42, 0, '0000-00-00 00:00:00', '2007-12-11 19:37:21', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 26, 17, '', '', 1, 11208, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(18, 53, 'The Template''s Settings', 'the-templates-settings', '<p>This template comes loaded with options that you can use to customize your site exactly how you want it. Here&#39;s how to get to these custom settings:</p>\r\n<ol>\r\n<li>In the backend of Joomla go menu item Extensions/Template Manager.</li>\r\n<li>Click on the title of the template.</li>\r\n<li>This will bring you to the template manager screen where you can edit the template&#39;s parameters.</li>\r\n<li>Click save when you are done</li>\r\n</ol>\r\n<p><img src="http://www.shape5.com/demo/images/general/template_edit15.jpg" border="0" alt=" " width="500" height="156" /> <br /><br /><br /></p>\r\n<div class="blue_box"><strong>I like what I see! I want to <a href="http://www.shape5.com/join-now.html" target="_top" style="color:#1B6FC2; text-decoration:underline">JOIN TODAY</a>.</strong></div>\r\n<p> </p>', '', 1, 8, '2007-12-11 19:46:04', 589, '', '2012-06-25 19:54:14', 42, 0, '0000-00-00 00:00:00', '2007-12-11 19:45:45', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_vote":"","show_author":"","show_create_date":"","show_modify_date":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","language":"","keyref":"","readmore":""}', 9, 18, '', '', 1, 11400, '', 0, '*', ''),
(24, 54, 'Page, Column and Row Widths', 'page-column-and-row-widths', '<br />\r\n<h3>Fixed or Fluid Width</h3><br />\r\nThis template has the ability to set the entire width of your set to either a \r\nfixed pixel width or a fluid percentage width. You can set the width to any size \r\nyou want.\r\n\r\n<br /><br />\r\n\r\n\r\n<div class="blue_box">\r\n<a style="text-decoration:underline" href="index.php/features-mainmenu-47/template-features/responsive-layout">\r\nBe sure to check out the responsive layout page to see how the layout below is constructed on multiple screen sizes. The responsive layout will work with both fixed or fluid settings. Responsive layouts are completely optional.</a>\r\n</div>\r\n\r\n\r\n<br /><h3>Column Widths</h3><br />\r\nYou may also set the widths of the following positions to any width that you \r\nneed to: left, left_inset, right, and right_inset. You may set them to any width \r\nyou need to.\r\n<br /><br /><h3>Row Widths</h3><br />\r\nThis template comes loaded with module positions, many of which appear in rows \r\nof 6 module positions. Any row that contains 6 module positions can have it&#39;s \r\nrow columns set to automatic widths or manual. For example, in the picture below \r\nthe first row shows 4 modules published and since it&#39;s set to automatic each is \r\nset to 25% width. The second row shows a manual calculation for each module in \r\nthe row. Again, you may do this for any row that contains 6 modules. If you \r\nsetup a manual calculation they must total to 100%. Not all 6 modules need to be \r\nused, as shown below.<p>\r\n</p>\r\n<p>All of this is done very easily in the template configuration.</p>\r\n<p align="center">\r\n<img style="border:solid 1px #333333" src="http://www.shape5.com/demo/images/general/custom_widths.png" width="600" height="432" /></p>\r\n<br />', '', 1, 8, '2007-12-11 21:25:09', 589, '', '2012-06-25 19:54:14', 42, 0, '0000-00-00 00:00:00', '2007-12-11 21:24:39', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 49, 19, '', '', 1, 10826, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(36, 55, 'How To Setup the Search Box and Menus', 'how-to-setup-the-search-box-and-menus', '<p> <h3>1. Search Setup</h3></p>\r\n<p><span style="font-size: medium;"><strong> <img src="images/search.png" class="padded" /></strong></span></p>\r\n<ul class="ul_arrow">\r\n<li>Simply publish the default Joomla search module to any main body position The demo shown is using the module class -highlight.</li>\r\n</ul>\r\n\r\n<br />\r\n\r\n<p><h3>2. Column Menu Setup</h3></p>\r\n<p><span style="font-size: medium;"><strong> <img src="images/column_menu.png" class="padded" /></strong></span></p>\r\n<ul class="ul_arrow">\r\n<li>Publish any menu module to the main body module positions on your site. </li>\r\n<li>There should be no menu style suffixes applied under advanced parameters.</li>\r\n<li> The menu style should be set to list.</li>\r\n</ul>\r\n\r\n\r\n\r\n<br />\r\n<p><h3>3. Bottom and Top Menu Setup</h3></p>\r\n<p><img src="images/bottom_menu.png" class="padded" /></p>\r\n<ul class="ul_arrow">\r\n<li>Publish any menu to the &#39;bottom_menu&#39; or &#39;top_menu&#39; position.</li>\r\n<li> There are no menu style suffixes applied under advanced parameters.</li>\r\n<li> The menu style should be set to list</li>\r\n</ul>\r\n<p> </p>', '', 1, 8, '2008-02-14 15:10:56', 589, '', '2012-10-13 19:12:03', 42, 0, '0000-00-00 00:00:00', '2008-02-14 15:10:36', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 68, 24, '', '', 1, 8213, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(37, 56, 'Tool Tips', 'tool-tips', '<br /><div class="blue_box"><strong>Note - The tool tips script is by default disabled. If you wish to use it you must enable this script in the template&#39;s configuration area. This also includes site shaper installations.</strong></div>\r\n<br/>\r\n<div class="blue_box">\r\n<a style="text-decoration:underline" target="_blank" href="http://www.shape5.com/joomla_tutorials.html">\r\nFor a tutorial on how to setup this script be sure to view the Vertex Guide on our Tutorials page.</a>\r\n</div>\r\n\r\n<br/>\r\n<br/>\r\n<strong>\r\nDemo 1:\r\n</strong>\r\n<br />\r\n\r\n\r\n\r\n\r\n<a onmouseover="Tip(&#39;This is a sample tooltip.&#39;, WIDTH, 140, OPACITY, 80, ABOVE, true, OFFSETX, 1, FADEIN, 200, FADEOUT, 300,SHADOW, true, SHADOWCOLOR, &#39;#000000&#39;,SHADOWWIDTH, 2, BGCOLOR, &#39;#000000&#39;,BORDERCOLOR, &#39;#000000&#39;,FONTCOLOR, &#39;#FFFFFF&#39;, PADDING, 9)" href="http://www.shape5.com/demo/etensity/">\r\n\r\n<img class="boxed2" alt="" src="http://www.shape5.com/demo/smart_blogger/images/tooltip.jpg"/>\r\n\r\n</a>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<br/><br />\r\n<strong>\r\nDemo 2:\r\n</strong>\r\n<br />\r\n\r\n\r\n\r\n<a href="index.htm" onmouseover="Tip(&#39;Image Demo<br /> <br /><img src=http://www.shape5.com/demo/smart_blogger/images/tooltip.jpg width=220 height=147>&#39;)"><strong>Demo 2 Image Tool Tip</strong></a><br/><br/> \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<strong>\r\nDemo 3:\r\n</strong>\r\n<br />\r\n\r\n\r\n\r\n\r\n<a href="#" onmouseover="Tip(&#39;Image Demo<br /> <br /><img src=http://www.shape5.com/demo/smart_blogger/images/tooltip.jpg width=220 height=147>&#39;,SHADOW, true,  BGCOLOR, &#39;#000000&#39;, FADEIN, 400, FADEOUT, 400, SHADOWCOLOR, &#39;#000000&#39;, BORDERCOLOR, &#39;#000000&#39;, OPACITY, 90,FONTCOLOR, &#39;#FFFFFF&#39;)"><strong>Demo 3 Image Tool Tip</strong></a>\r\n<br/><br/>', '', 1, 8, '2008-08-13 18:09:50', 589, '', '2012-06-25 19:54:14', 42, 0, '0000-00-00 00:00:00', '2008-08-13 18:09:37', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 18, 25, '', '', 1, 4847, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(39, 57, 'Site Shapers', 'site-shapers', '<p><br />So what are Site Shapers? They are quick installs of Joomla combined with all the modules, content, etc used on our demo, excluding stock photography. Within a few minutes you can have your site up, running and looking just like our demo. No more importing SQL dumps and installing modules.  Just head on over to the download section of this template and grab a Site Shaper.  Simply install the Site Shaper like any other Joomla installation, it&#39;s that easy!<br /><br /></p>\r\n\r\n\r\n<div class="blue_box">\r\n<a style="text-decoration:underline" target="_blank" href="http://www.shape5.com/joomla_tutorials.html">\r\nPlease also visit our tutorials download page for a more in depth site shaper tutorial.</a>\r\n</div>\r\n\r\n<br />\r\n\r\n<h3>How to setup a Site Shaper</h3>\r\n\r\n<br />\r\n<ul class="ul_bullet">\r\n<li>Login to your cpanel or your server admin panel.</li>\r\n<li>Locate the area where your databases are    (usually labeled Mysql Databases)</li>\r\n<li>Create a new database</li>\r\n<li>Next create a new database user and assign    it to this newly created database in the previous step</li>\r\n<li>You will then    need to extract the site shaper to either a folder on your server or the root    directory such as WWW. NOTE: if you already have a website in the root of your    WWW folder, we suggest creating a new folder and extract the site shaper    there. If your cpanel does not have an extract option or you cannot find it,    you may also extract the contents of your site shaper in to a folder on your    desktop and upload all the files via an ftp client to your server.</li>\r\n<li>Next, navigate to the url where you extracted the site shaper via your web browser.</li>\r\n<li>Continue through each screen until you reach the below screenshot:</li>\r\n<br /> <img src="http://www.shape5.com/demo/images/general/siteshaper.png" border="0" /> <br /><br />\r\n<li>At the above screen be sure to enter localhost as shown, continue to fill in the following text fields with your newly created database and username information</li>\r\n<li>Follow through the rest of the site shaper setup and click the install sample data at the last screen and the installation is complete! (be sure to rename/remove the installation directory after finishing the install)</li>\r\n</ul>\r\n<p><br /><br /></p>', '', 1, 8, '2008-08-13 18:43:32', 589, '', '2012-06-25 19:54:14', 42, 0, '0000-00-00 00:00:00', '2008-08-13 18:42:56', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 39, 20, '', '', 1, 8995, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(110, 59, 'S5 Tab Show', 's5-tab-show', 'The S5 Tab Show can be demo''d at the bottom of this page. This version of the module is customized specifically for this template and cannot be used with any other templates. We do have another version that can be used on any Joomla template.\r\n<br /><br />\r\nThe module holds up to 10 actual module positions so you can publish any of your favorite modules to one of the slides and keep your site clean and consolidated while giving it some eye candy. So simply publish the s5 tab show module to your desired module position and pages. Then start publishing modules to the positions in the tab show (s5_tab1, s5_tab2, etc); these modules will become the slides.', '', 1, 8, '2009-08-13 18:44:06', 589, '', '2012-10-13 18:45:33', 42, 0, '0000-00-00 00:00:00', '2009-08-13 18:44:06', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 19, 26, '', '', 1, 84, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(143, 60, 'S5 Accordion Menu', 's5-accordion-menu', '<br />The S5 Accordion menu is demo&#39;d on the right of this page. This version was built specifically for this template and cannot be transferred to another template. We do have another version that can be used on any Joomla template.<br /><br />   \r\n\r\nThis module is based off the Joomla main menu system module so you can still specify which Joomla menu you want to use with the S5 Accordion menu. The menu is powered off of the Mootools Javascript library but detects to see if the library is already initialized, if so then it doesn&#39;t load its own library to stop any conflicts from arising.\r\n\r\n<br /><br />   <div class="blue_box"><strong>I like what I see! I want to <a href="http://www.shape5.com/join-now.html" target="_top">JOIN TODAY</a>.</strong></div>', '', 1, 8, '2009-10-12 22:29:01', 589, '', '2012-06-25 19:54:14', 42, 0, '0000-00-00 00:00:00', '2009-10-12 22:29:01', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_vote":"","show_author":"","show_create_date":"","show_modify_date":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","language":"","keyref":"","readmore":""}', 10, 27, '', '', 1, 234, '', 0, '*', ''),
(146, 61, 'Login and Register Setup', 'login-and-register-setup', '<p>The S5 Box can be demo&#39;d by clicking on either the Login or Register buttons found towards the top of this page.  <br /> <br /> The module allows for up to 10 different S5 Box&#39;s on one page all via 10 module  positions. You simply add a class to any HTML element on your site and enable  the corresponding box and you are good to go!<br /><br /></p>\r\n<p><h3>To enable the login and register modules:</h3></p>\r\n<p>1. Install the S5 Box module and publish it to all pages on your site. Try  to publish it to a position where a module already exists on all pages, but  don&#39;t worry it won&#39;t change the layout of your site, the script is automatically  hidden on your site.</p>\r\n<p>2. Install and publish the S5 Register module to the &#39;register&#39; module  position</p>\r\n<p>3. Publish the default Joomla login module to the &#39;login&#39; module position.</p>\r\n<p>4. In your template parameters area of Joomla you can change the text for login, register and logout.</p>\r\n<p>5. That&#39;s it, you&#39;re all done!</p>\r\n<br />\r\n\r\n<strong>\r\nIf you do not wish to use the S5 Box but would still like to use the Login and Register links then simply complete step 4 above and also fill out your own custom urls just below those fields in the template configuration. Filling out the custom url fields will disable the S5 Box.\r\n</strong>\r\n\r\n<br /><br />\r\n\r\n<p>The S5 Box runs  off of the jQuery Javascript library in a no conflictions mode so you should not receive any problems with other third party extensions you may be running on your site. Alternatively you can also the core Joomla mootools script. <br /> <br /> <h3>Features:</h3></p>\r\n<ul class="ul_star">\r\n<li>Powered by no conflict mode jQuery Javascript or mootools</li>\r\n<li>Choose, elastic, fade or none for the popup effect</li>\r\n<li>Up to 10 S5 Box&#39;s throughout your site or on any one page!</li>\r\n<li>Set the percentage of width of each box according to overall screen size</li>\r\n</ul>\r\n<p> </p>\r\n<p><br /></p>\r\n<div class="gray_box">\r\nTutorial on how to get the s5 box working and use all 10 module positions it includes\r\n</div><br /><br />\r\n<p> <strong>1. Adding the S5 Box positions:</strong></p>\r\n<ul class="ul_bullet_small">\r\n<li>Open up the templateDetails.xml file included with the template you are using.</li>\r\n<li>Locate the positions area.</li>\r\n<li>Start adding new positions s5_box1, s5_box2, s5_box3, etc all the way up to s5_box10.</li>\r\n</ul>\r\n<p><strong>2. Adding the S5 Box classes:</strong></p>\r\n<ul class="ul_bullet_small">\r\n<li>The S5 Box class name of the corresponding position must be added to the link that will open the box. For example the following code will display a link that says Click Here and will open the S5 Box and display whatever module is published to the s5_box3 module position: <br /><br /> <img src="http://www.shape5.com/demo/get_reserved/images/box_link.png" border="0" /> <br /><br /> </li>\r\n<li>These classes can be added to any element, ie: divs, spans, etc., but the common use will be to add this into content with a link similar to the one shown in the picture above. To enter this link you must do so from the HTML edit screen on your content editor:  <br /><br /> Once you have clicked the HTML button the HTML code window will appear much like the first image. </li>\r\n<li>You can continue adding these classes throughout your site just be sure to have published a module to the corresponding position or the box will not work correctly. So if you add the class s5box_two you will also have to publish a module to the s5_box2 position.</li>\r\n<li> Module positions and their corresponding classes:<br /><br /> s5_box1 = s5box_one<br /> s5_box2 = s5box_two<br /> s5_box3 = s5box_three<br /> s5_box4 = s5box_four<br /> s5_box5 = s5box_five<br /> s5_box6 = s5box_six<br /> s5_box7 = s5box_seven<br /> s5_box8 = s5box_eight<br /> s5_box9 = s5box_nine<br /> s5_box10 = s5box_ten</li>\r\n</ul>\r\n<p><strong>3. Lastly, publish your modules to the S5 Box positions:</strong></p>\r\n<ul class="ul_bullet_small">\r\n<li>Now that you have added the s5 box positions just go to your site modules area and publish modules to those positions</li>\r\n<li>Make sure that you have added a class to an HTML element as described above or the s5 box will have no activation button </li>\r\n<li>Also make sure to publish the actual s5 box to a non s5 box position, perhaps publish it to the "debug" position or a similar one in your template.</li>\r\n</ul>\r\n<p><br /><br /> <h3>Main S5 Box Module Settings:</h3></p>\r\n<ul class="ul_bullet_small">\r\n<li>In the backend of the S5 Box module you can adjust the width of each box independent of each other. </li>\r\n<li>Make sure that the S5 Box module is published to all pages, it can be published to any template position. Also make sure that the module opening in the box is published to the page the link is on. </li>\r\n</ul>', '', 1, 8, '2009-10-12 22:44:23', 589, '', '2012-06-25 19:54:14', 42, 0, '0000-00-00 00:00:00', '2009-10-12 22:44:23', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 35, 28, '', '', 1, 114, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(173, 62, 'Search Engine Optimized ', 'search-engine-optimized', '<br/>\r\n<h3>SEO - Get your site noticed!</h3>\r\n<p><br /> Not only is this template beautifully designed but it is great for search engine optimization as well! What is SEO? It is simple the act of altering a web site so that it does well in the organic, crawler-based listings of search engines such as google.com. How does this template accomplish this? It&#39;s simple, the majority of your most valuable content is found in the main body of your site, through css we are able to alter the layout of the site and call the main content before the left and right columns are called. This allows for your content to be found first by search engines before it reaches your other content, which is vital in search engine optimization. This is a common feature this can be done with almost all of Shape 5 templates as well.</p>\r\n<p> </p>\r\n<div class="blue_box"><strong>I like what I see! I want to <a href="http://www.shape5.com/join-now.html" target="_top">JOIN TODAY</a>.</strong></div>', '', 1, 8, '2010-02-11 17:28:55', 589, '', '2012-06-25 19:54:14', 42, 0, '0000-00-00 00:00:00', '2010-02-11 17:28:55', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_vote":"","show_author":"","show_create_date":"","show_modify_date":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","language":"","keyref":"","readmore":""}', 12, 16, '', '', 1, 93, '', 0, '*', ''),
(195, 63, 'Multibox', 'multibox', '<br/>\r\n\r\n<div class="blue_box">\r\n<a style="text-decoration:underline" target="_blank" href="http://www.shape5.com/joomla_tutorials.html">\r\nFor a tutorial on how to setup this script be sure to view the Vertex Guide on our Tutorials page.</a>\r\n</div>\r\n\r\n\r\n<br/><h3>Features:</h3>\r\n\r\n<ul class="ul_bullet_small">\r\n<li>Supports a range of multimedia formats: images, flash, video, mp3s, html!</li>\r\n<li>Auto detects formats or you can specify the format</li>\r\n<li>Html descriptions</li>\r\n<li>Enable/Disable page overlay when multibox pops up (via template parameters)</li>\r\n<li>Enable/Disable controls (via template parameters)</li>\r\n\r\n\r\n\r\n\r\n<br/>\r\n\r\n\r\n\r\n<p><strong><font size="2">Images Example</font></strong></p>          \r\n\r\n<a href="http://www.shape5.com/demo/images/multibox1_lrg.jpg" id="mb1" class="s5mb" title="Image #1:">\r\n<img src="http://www.shape5.com/demo/images/multibox1.jpg" style="margin-right:20px" class="boxed" alt="" />\r\n</a>\r\n<div class="s5_multibox mb1">Image #1. It can support <strong>html</strong>.</div>\r\n&nbsp;&nbsp;\r\n<a href="http://www.shape5.com/demo/images/multibox2_lrg.jpg" id="mb2" class="s5mb" title="Image #2:">\r\n<img src="http://www.shape5.com/demo/images/multibox2.jpg" style="margin-right:20px" class="boxed" alt="" />\r\n</a>\r\n<div class="s5_multibox mb2">Image #2. It can support <strong>html</strong>.</div>\r\n&nbsp;&nbsp;\r\n<a href="http://www.shape5.com/demo/images/multibox3_lrg.jpg" id="mb3" class="s5mb" title="Image #3:">\r\n<img src="http://www.shape5.com/demo/images/multibox3.jpg" class="boxed" alt="" />\r\n</a>\r\n<div class="s5_multibox mb3">Image #3. It can support <strong>html</strong>.</div>\r\n\r\n\r\n\r\n<div style="clear:both"></div>\r\n\r\n\r\n<p><strong><font size="2">Separeate Group Images Example</font></strong></p>          \r\n\r\n<a href="http://www.shape5.com/demo/images/multibox1_lrg.jpg" rel="[group1]" id="mb9" class="s5mb" title="Image #1:">\r\n<img src="http://www.shape5.com/demo/images/multibox1.jpg" style="margin-right:20px" class="boxed" alt="" />\r\n</a>\r\n<div class="s5_multibox mb9">Image #1. It can support <strong>html</strong>.</div>\r\n&nbsp;&nbsp;\r\n<a href="http://www.shape5.com/demo/images/multibox2_lrg.jpg" rel="[group1]" id="mb10" class="s5mb" title="Image #2:">\r\n<img src="http://www.shape5.com/demo/images/multibox2.jpg" style="margin-right:20px" class="boxed" alt="" />\r\n</a>\r\n<div class="s5_multibox mb10">Image #2. It can support <strong>html</strong>.</div>\r\n&nbsp;&nbsp;\r\n<a href="http://www.shape5.com/demo/images/multibox3_lrg.jpg" rel="[group1]" id="mb11" class="s5mb" title="Image #3:">\r\n<img src="http://www.shape5.com/demo/images/multibox3.jpg" class="boxed" alt="" />\r\n</a>\r\n<div class="s5_multibox mb11">Image #3. It can support <strong>html</strong>.</div>\r\n\r\n\r\n\r\n<div style="clear:both"></div>\r\n\r\n\r\n\r\n\r\n\r\n<p><strong><font size="2">Video Example:</font></strong></p>   \r\n\r\n<a href="http://www.youtube.com/v/VGiGHQeOqII" id="youtube" class="s5mb" title="Youtube.com Video">\r\nYoutube.com Video - CLICK ME\r\n</a>\r\n<div class="s5_multibox youtube">UP: Carl and Ellie </div>\r\n\r\n<br/>\r\n<br/>\r\nYou can use the following video formats: flv, mov, wmv, real and swf.  Just insert the URL to the videos in the href of the hyperlink, here is an example of how we did this for a Youtube video:<br/>\r\n\r\n\r\n\r\n<br/>\r\nYouTube Tutorial:  Simply right click on a youtube video and copy the embed code, then paste into a text editor and look for the embed src and use that URL in your hyperlink.\r\n\r\n\r\n\r\n\r\n<br/><br/>\r\n\r\n\r\n<p><strong><font size="2">MP3 Example:</font></strong></p>   \r\n\r\n<a href="http://www.shape5.com/demo/images/music.mp3"  id="mb8" class="s5mb" title="Music">MP3 example - CLICK ME</a>\r\n<div class="s5_multibox mb8">mp3 example</div><br />\r\n\r\n\r\n\r\n\r\n<br/>\r\n\r\n\r\n<p><strong><font size="2">iFrame:</font></strong></p>   \r\n\r\n<a href="http://www.getfirebug.com" rel="width:790,height:600" id="mb28" class="s5mb" title="getfirebug.com">iFrame/HTML Example - CLICK ME</a>\r\n<div class="s5_multibox mb28">getfirebug.com</div><br />\r\n\r\n\r\n\r\n\r\n<br/><br/>\r\n\r\n\r\n\r\n\r\n\r\n \r\n\r\n\r\n<div class="blue_box">\r\nI like what I see! I want to <a href="http://www.shape5.com/join-now.html" target="_top"><strong>JOIN TODAY</strong></a>. </div>\r\n <br />', '', 1, 8, '2010-08-13 18:18:32', 589, '', '2012-06-25 19:54:14', 42, 0, '0000-00-00 00:00:00', '2010-08-13 18:18:32', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 33, 15, '', '', 1, 239, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(197, 64, 'Template Specific Options', 'template-specific-options', 'This template is built on the very powerful S5 Vertex Framework, which comes packed with amazing features! <a href="http://www.shape5.com/joomla/framework/vertex_framework.html" target="blank">Learn More About Vertex...</a> \r\n<br /><br />\r\nEvery template built on Vertex also comes with it&#39;s own unique template specific options applicable to that particular template such as highlight colors, social icons, and much more. These features are in addition to the standard functions of Vertex, and are still controlled through the very user friendly interface of Vertex. This page will document the features specific to this template.\r\n\r\n<br /><br /><br />\r\n<h2>Template Specific Configuration Interface of Vertex</h2><br />\r\nBelow is a screenshot that shows all the template specific features available in the user friendly Vertex admin:<br /><br />\r\n<img class="padded" src="images/template_specific.png"></img>\r\n\r\n\r\n<br /><br /><br />\r\n<h2>Optional Floating Header</h2><br />\r\nThe header area of this template that contains the logo and main menu has an optional floating optional. You can have the header stay static at the top of your browser as the user scrolls down the page (as this demo shows), or you can disable this option and have it stay at the top of the page only, and not scroll with the page. Note - this feature will disable at 750px for tablets and phones.\r\n<br /><br />\r\n<img class="padded" src="images/header.jpg"></img><br />\r\n\r\n\r\n\r\n<br /><br /><br />\r\n<h2>Optional Background For Component/Article Are</h2><br />\r\nThe main component and article area of this template has an optional white background. It can either have no background as shown throughout this demo, or you can apply a white background as shown below.\r\n<br /><br />\r\n<img class="padded" src="images/background1.jpg"></img><br /><br />\r\n<img class="padded" src="images/background2.jpg"></img><br />\r\n\r\n\r\n\r\n<br /><br /><br />\r\n<h2>Custom Highlight Colors</h2><br />\r\nNeed your own custom color scheme? Not a problem, this template comes with ultimate color control! With four highlight colors of your choice you can set titles, hyperlinks, buttons, backgrounds, and much more to any color you wish! This color can easily be set in the template configuration area. Below are some examples of custom color schemes created through the highlight color options. Below is a screenshot of this effect and some of the areas that you can alter.\r\n<br /><br />\r\n<img class="padded" src="images/example1.jpg"></img><br />\r\n\r\n\r\n\r\n\r\n<br /><br /><br />\r\n<h2>Social Icons</h2><br />\r\nEasily link to a social media site with the built in social icons found in the header of this template. Simply enter the url of your social site in the configuration and the icon will automatically appear. To disable an icon simply leave the url blank for that particular icon. \r\n<br /><br />\r\n<img class="padded" src="images/social.jpg"></img><br />\r\n\r\n\r\n\r\n<br /><br /><br />\r\n<h2>Small Menu</h2><br />\r\nOn this demo you can subtext on the first level parent items. If you choose not to use subtext on these links simply choose a small menu option and the menu will automatically down size.\r\n<br /><br />\r\n<img class="padded" src="images/small_menu1.jpg"></img><br />\r\n<br />\r\n<img class="padded" src="images/small_menu2.jpg"></img><br />\r\n\r\n\r\n\r\n\r\n<br /><br /><br />\r\n<h2>Custom Highlight Fonts</h2><br />\r\nChoose a custom highlight font powered by Google fonts. You can set a custom font for the S5 Flex Menu main level items and another custom font for most module titles. You can also change the default font under the General tab of Vertex.\r\n<br /><br />\r\n<img class="padded" src="images/highlight_font.jpg"></img><br />', '', 1, 8, '2010-08-13 18:57:50', 589, '', '2012-10-13 20:43:58', 42, 0, '0000-00-00 00:00:00', '2010-08-13 18:57:50', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 73, 14, '', '', 1, 221, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', '');
INSERT INTO `#__content` (`id`, `asset_id`, `title`, `alias`, `introtext`, `fulltext`, `state`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`, `featured`, `language`, `xreference`) VALUES
(204, 65, 'Google Fonts Enabled', 'google-fonts-enabled', 'Do you want your own custom font? Not a problem, this template comes with Google Fonts enabled, allowing you to pick from over a dozen font families for your website. In the template parameters area of the template you can choose your own custom font, and preview it from the Vertex interface. Below are some examples of the fonts available.<br/><br/>\r\n\r\n<img alt="" src="http://www.shape5.com/demo/images/general/google_fonts.png"></img>\r\n\r\n<br />\r\n<br /><br />\r\n\r\n<div class="blue_box"><strong>I like what I see! I want to <a href="http://www.shape5.com/join-now.html" target="_top">JOIN TODAY</a>.</strong></div><br /></ul>', '', 1, 8, '2010-10-08 19:08:51', 589, '', '2012-06-25 19:54:14', 42, 0, '0000-00-00 00:00:00', '2010-10-08 19:08:51', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_vote":"","show_author":"","show_create_date":"","show_modify_date":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","language":"","keyref":"","readmore":""}', 7, 13, '', '', 1, 24, '', 0, '*', ''),
(212, 68, 'CSS Tableless Overrides', 'css-tableless-overrides', 'This template comes with CSS tabless overrides for the main Joomla content, overriding the default table layout. This makes your content much more accessible to search engines.\r\n<br /><br />\r\n<div class="blue_box"><strong>I like what I see! I want to <a href="http://www.shape5.com/join-now.html" target="_top">JOIN TODAY</a>.</strong></div>', '', 1, 8, '2010-12-13 23:29:23', 589, '', '2012-06-25 19:54:14', 42, 0, '0000-00-00 00:00:00', '2010-12-13 23:29:23', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_vote":"","show_author":"","show_create_date":"","show_modify_date":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","language":"","keyref":"","readmore":""}', 4, 29, '', '', 1, 14, '', 0, '*', ''),
(214, 69, 'Fixed Side Tabs', 'fixed-side-tabs', 'This template includes a "Fixed Tab" option that you can enable and publish on your site and will show in a fixed position on either the left or right side of the screen. The great feature about the fixed tabs is that you can enter any text you desire and the text is automatically flipped vertically! This is great for search engines to read your text and also saves the hassle of creating an image with vertical text and placing it on the side of your site. The tabs are published site wide and can have the following options that can be changed via the template parameters area and can link to any URL that you desire.\r\n\r\n\r\n<br /><br /><h3>The following is a quick list of features: </h3></p>\r\n<ul class="ul_star">\r\n<li>Change background to any hex color </li>\r\n<li>Change the border to any hex color</li>\r\n<li>Change the font to any hex color</li>\r\n<li>Set vertical position of each tab</li>\r\n<li>Set the height of each tab</li>\r\n<li>Set each tab to either the left or right of the screen</li>\r\n<li>Add a class to each fixed tab to enable s5 box or perhaps a lightbox or other 3rd party extension</li>\r\n<li>Add a URL to each fixed tab so onclick the URL loads</li>\r\n<li>Enter any text you desire</li>\r\n</ul>\r\n\r\n<br /><br />   <div class="blue_box"><strong>I like what I see! I want to <a href="http://www.shape5.com/join-now.html" target="_top">JOIN TODAY</a>.</strong></div>', '', 1, 8, '2010-12-13 23:40:43', 589, '', '2012-06-25 19:54:14', 42, 0, '0000-00-00 00:00:00', '2010-12-13 23:40:43', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_vote":"","show_author":"","show_create_date":"","show_modify_date":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","language":"","keyref":"","readmore":""}', 5, 12, '', '', 1, 10, '', 0, '*', ''),
(227, 70, 'Menu Scroll To Section', 'menu-scroll-to-section', 'This template includes a scroll to feature that will scroll your page to a specified section of your site. All you have to do is create an external link in your menu manager and then in the URL area enter in any ID on your page. You can reference any of the following IDs in order:<br /><br />\r\n\r\n<ul class="ul_bullet_small">\r\n<li>#s5_header_area1</li>\r\n<li>#s5_top_row1_area1</li>\r\n<li>#s5_top_row2_area1</li>\r\n<li>#s5_top_row3_area1</li>\r\n<li>#s5_center_area1</li>\r\n<li>#s5_bottom_row1_area1</li>\r\n<li>#s5_bottom_row2_area1</li>\r\n<li>#s5_bottom_row3_area1</li>\r\n<li>#s5_footer_area1</li>\r\n\r\n</ul>\r\n<br />\r\nScreenshot of admin area of an external menu item with DIV reference entered:<br /><br />\r\n\r\n<img border="0" src="http://www.shape5.com/demo/images/general/scrollto.jpg" style="">', '', 1, 8, '2011-06-10 21:35:45', 589, '', '2012-06-25 19:54:14', 42, 0, '0000-00-00 00:00:00', '2011-06-10 21:35:45', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_vote":"","show_author":"","show_create_date":"","show_modify_date":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","language":"","keyref":"","readmore":""}', 4, 11, '', '', 1, 11, '', 0, '*', ''),
(228, 71, 'IE7 and 8 CSS3 Support', 'ie7-and-8-css3-support', 'This template includes limited support of CSS3 for IE7 and IE8. With the power of css3, websites can now be built much faster and with far \r\nless code. Design features such as gradients or shadows that used to be \r\ncreated and then called as images on the page are now simply called \r\nby css code. Transition effects that used to require full javascript libraries can \r\nnow be called with less than 1kb of text. Rounded corners that used to \r\nrequire upwards of eight wrapping div elements can now be done with a \r\nsingle element. What does this mean for you? Simple, a lightning fast website, \r\nthat becomes even more search engine friendly. \r\n\r\n<br /><br />Many modern browsers such as Firefox4 of IE9 already support CSS3 natively, but where does that leave IE7 and IE8? Thankfully a great solution called CSS PIE (Progressive Internet Explorer) has been introduced and is integrated into this template. Simply put, CSS PIE a script that upgrades IE7 and 8 to support most CSS3 formatting.  There are slight variations and some CSS3 formatting isn&#39;t supported, but overall it does a great job and allows us to extend CSS3 support to IE7 and 8.', '', 1, 8, '2011-06-10 21:37:19', 589, '', '2012-06-25 19:54:14', 42, 0, '0000-00-00 00:00:00', '2011-06-10 21:37:19', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_vote":"","show_author":"","show_create_date":"","show_modify_date":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","language":"","keyref":"","readmore":""}', 2, 10, '', '', 1, 12, '', 0, '*', ''),
(230, 72, 'Lazy Load Images', 'lazy-load-images', 'The lazy load script is a great way to save bandwidth and load your pages much faster. Images that are not visible on the initial page load are not loaded or downloaded until they come into the main viewing area. Once an image comes into view it is then downloaded and faded into visibility. Scroll down this page to see the script in action.\r\n\r\n<br /><br />\r\n\r\nSetup is very easy! By default this script is disabled, in order to enable it simply choose All Images or Individual Images from the drop down, as shown below from inside the template configuration page.\r\n\r\n<br /><br />\r\n\r\n<img class="padded" src="http://www.shape5.com/demo/images/general/lazy_load.png" alt=""></img>\r\n\r\n<br /><br />\r\n\r\nAll images will load every standard image on the page with lazy load. There is no extra configuration or extra code to add with this configuration, it will just happen automatically. Individual images would be used if you want only certain images to load with this script and not all of them. To do this simply add class="s5_lazyload" to the image like so:\r\n\r\n<br />\r\n\r\n<div class="code">\r\n\r\n&lt;img class=&quot;s5_lazyload&quot; src=&quot;http://www.yoursite.com/image.jpg&quot;&gt;&lt;/img&gt;\r\n\r\n</div>\r\n\r\n<br /><br />\r\nThis script is compatible with Firefox3+, IE8+, Chrome14+, Safari5.05+, Opera 11.11+\r\n<br /><br />\r\n<h3>See the script in action:</h3>\r\n<br />\r\n\r\n<img src="http://www.shape5.com/demo/images/general/lazyload/lazy_load1.jpg" alt="" class="s5_lazyload padded"></img>\r\n<img src="http://www.shape5.com/demo/images/general/lazyload/lazy_load2.jpg" alt="" class="s5_lazyload padded"></img>\r\n<img src="http://www.shape5.com/demo/images/general/lazyload/lazy_load3.jpg" alt="" class="s5_lazyload padded"></img>\r\n<img src="http://www.shape5.com/demo/images/general/lazyload/lazy_load4.jpg" alt="" class="s5_lazyload padded"></img>\r\n<img src="http://www.shape5.com/demo/images/general/lazyload/lazy_load5.jpg" alt="" class="s5_lazyload padded"></img>\r\n<img src="http://www.shape5.com/demo/images/general/lazyload/lazy_load6.jpg" alt="" class="s5_lazyload padded"></img>\r\n<img src="http://www.shape5.com/demo/images/general/lazyload/lazy_load7.jpg" alt="" class="s5_lazyload padded"></img>\r\n<img src="http://www.shape5.com/demo/images/general/lazyload/lazy_load8.jpg" alt="" class="s5_lazyload padded"></img>\r\n<img src="http://www.shape5.com/demo/images/general/lazyload/lazy_load9.jpg" alt="" class="s5_lazyload padded"></img>\r\n<img src="http://www.shape5.com/demo/images/general/lazyload/lazy_load10.jpg" alt="" class="s5_lazyload padded"></img>', '', 1, 8, '2011-08-12 18:35:45', 589, '', '2012-06-25 19:54:14', 42, 0, '0000-00-00 00:00:00', '2011-08-12 18:35:45', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 17, 9, '', '', 1, 38, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(231, 73, 'Hide Article Component Area', 'hide-article-component-area', 'Did you ever need to create a page where this is no article present or no component to be shown, and only load modules? This template makes it all possible! From the template configuration page you can hide the main content area on any page on the site. \r\n\r\n<br /><br />\r\n\r\nBelow is a screenshot of this function from the configuration page, found under the General tab:\r\n\r\n<br /><br />\r\n\r\n<img class="padded" src="http://www.shape5.com/demo/images/general/hide_articles.png" alt=""></img>\r\n\r\n<div style="clear:both; height:0px"></div>', '', 1, 8, '2011-08-12 18:37:35', 589, '', '2012-06-25 19:54:14', 42, 0, '0000-00-00 00:00:00', '2011-08-12 18:37:35', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 8, 8, '', '', 1, 16, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(233, 74, 'S5 Drop Down Panel', 's5-drop-down-panel', 'The S5 Drop Down Panel is a slide down panel that can be demo&#39;d at the top of this page. The panel itself contains six module positions. You may publish any module that you wish into these positions. It comes packed with features so be sure to check out the list and screenshot below.\r\n<br />\r\n<br />\r\nNote - If the responsive layout is enabled the drop down will disable when the screen size reaches 750px so that it does not interfere with the mobile menu bar\r\n\r\n<br />\r\n<br />\r\n<img alt="" style="border:1px solid #CCCCCC" class="padded" src="http://www.shape5.com/demo/images/general/dropdown_tab.png" />\r\n<div style="clear:both"></div>\r\n<br />\r\n<ul class="ul_star"> \r\n<li>Customize almost everything! Shadows, borders, gradient, opacity</li> \r\n<li>Contains 6 module positions drop_down_1, drop_down_2, drop_down_3, drop_down_4, drop_down_5 and drop_down_6</li>\r\n<li>Auto adjust to the height of your content</li> \r\n<li>Set your own open and close text</li> \r\n<li>Auto collapse if no modules are published to it</li>\r\n<li>And many more features!</li>\r\n</ul>\r\n<br />\r\n<br />\r\n<h3>Screenshot of Drop Down admin in template configuration area:</h3><br />\r\n<img alt="" style="border:1px solid #CCCCCC" class="padded" src="http://www.shape5.com/demo/images/general/dropdown.png" />\r\n\r\n<div style="clear:both; height:0px"></div>', '', 1, 8, '2011-08-13 14:54:51', 589, '', '2012-06-25 19:54:14', 42, 0, '0000-00-00 00:00:00', '2011-08-13 14:54:51', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 16, 7, '', '', 1, 102, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(255, 92, '3rd Party Component Compatibility', '3rd-party-component-compatibility', 'This template is compatible with all the major 3rd party components available for Joomla. The following are just some of the ones available that work great with any Shape 5 template. A template itself should in no way hinder the functionality of a component. Although we haven&#39;t tested every single Joomla component available we can say quite confidently that this template will be compatible with any Joomla extension you use with it.</p>\r\n<p> </p>\r\n<p><img src="http://www.shape5.com/demo/images/general/3rdparty.png" border="0" /><br />And many more!', '', 1, 8, '2012-02-09 19:24:02', 589, '', '2012-06-25 19:54:14', 42, 0, '0000-00-00 00:00:00', '2012-02-09 19:24:02', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_vote":"","show_author":"","show_create_date":"","show_modify_date":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","language":"","keyref":"","readmore":""}', 3, 6, '', '', 1, 8, '', 0, '*', ''),
(256, 93, 'S5 Image and Content Fader', 's5-image-and-content-fader', '<p>This module can be viewed at the top of this page. This specific style of the module can only be used with this template. Publish your own content into each slide transition and for multiple slide transition effects, navigation arrows and also a drop down gallery tab that allows you to select a slide via a thumbnail. This module is fully responsive as well. The S5 Image and Content Fader v3 is powered by Mootools by default but still includes the S5 Effects library and allows you to use it in a "legacy module" if you are experiencing script conflicts. Best of all it&#39;s free!  <br /><br />NOTE: Legacy mode will display all your images, titles and slide text but includes limited functionality thus it does not include navigation arrows or the new drop down gallery tab.</p>\r\n\r\n<br />\r\n<br />\r\nThis module was designed only to work with the custom_1 position with this template.\r\n\r\n<br />\r\n<br />\r\n\r\n<p> </p>\r\n<p> </p>\r\n<h3>Features at a glance:</h3>\r\n<p> </p>\r\n<ul class="ul_star">\r\n<li>Responsive layout compatible</li>\r\n<li>horizontal sliding transition</li>\r\n<li>Choose between 4 slide transitions: Fade, Contiuous Horiztonal, Fade Slide Left, Continuous Vertical</li>\r\n<li>Specify height and width of module</li>\r\n<li>Includes a gallery tab drop down to show all images</li>\r\n<li>Each image slide can have its own hyperlink</li>\r\n<li>Show up to 10 images at once</li>\r\n<li>Publish your own content to each picture slide</li>\r\n<li>Navigation arrows</li>\r\n<li>Not all slides require titles</li>\r\n<li>Change delay time</li>\r\n<li>Hide or show: Navigation arrows, thumbnail carousel and popup text</li>\r\n</ul>\r\n<p><br /><br /></p>\r\n<h3>Admin side of the module:</h3>\r\n<p><br /> <img src="images/imageadmin.png" border="0" /> <br /> <br /><br /></p>\r\n<div class="blue_box">\r\nI like what I see! I want to <a href="../../join-now.html" target="_top"><strong>JOIN TODAY</strong></a>.</div>', '', 1, 8, '2008-02-14 15:10:56', 589, '', '2012-10-13 19:25:04', 42, 0, '0000-00-00 00:00:00', '2008-02-14 15:10:36', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"1","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 16, 5, '', '', 1, 32, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(276, 127, 'Sample Content', 'sample-content', 'Integer varius tempor auctor. Etiam fringilla venenatis mollis. Duis ullamcorper massa eu sapien fringilla consequat. Aliquam nec ligula mi, quis tincidunt odio. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum rutrum dui eros. Praesent nec nibh diam.\r\n<br /><br />\r\nProin augue risus, molestie at dictum quis, viverra non ipsum. Praesent lacus dui, euismod ut mollis vel, lacinia vel arcu. In commodo arcu vitae velit elementum a luctus nibh mattis. Ut vel turpis eros. Nam mattis velit sed nibh scelerisque in bibendum felis sodales. Vivamus ornare pellentesque pellentesque. Nullam dignissim semper quam nec mollis. In vel lacus lectus, ac tristique leo.\r\n<br /><br />\r\nAenean venenatis egestas iaculis. Nullam consectetur condimentum dolor at bibendum. Nulla in enim quis ipsum pulvinar imperdiet vitae nec velit. Donec non urna quam. Aliquam congue magna nec risus iaculis posuere. Vivamus bibendum interdum molestie. Sed libero risus, varius eu dictum ac, pharetra ac elit. Curabitur a nibh id ipsum sagittis blandit. Morbi cursus commodo leo quis rhoncus. In nec purus magna, id porta enim. Donec pulvinar aliquet vulputate. Donec sit amet justo sit amet ipsum posuere imperdiet id sed magna.\r\n<br /><br />\r\nSed ultricies condimentum augue, sed congue erat dapibus nec. Etiam quis tempor nibh. Vestibulum urna dui, sodales ut ornare vitae, porta non augue. Curabitur nunc ipsum, facilisis nec luctus blandit, luctus at sem. Vestibulum pharetra augue vitae orci mollis scelerisque. Quisque gravida diam vel mauris ultricies ac faucibus turpis volutpat. Maecenas augue elit, rutrum pharetra mattis ullamcorper, commodo varius enim. Phasellus dapibus mattis ipsum sit amet tincidunt. In hac habitasse platea dictumst. Sed nisi dolor, ullamcorper eget pretium molestie, commodo non dolor. Praesent volutpat aliquet neque ut bibendum. Pellentesque tincidunt tortor non ipsum venenatis ultricies.\r\n<br /><br />\r\nProin at justo eu orci condimentum ornare sed pellentesque orci. Duis nec interdum massa. Proin porta semper enim, sit amet condimentum lorem interdum non. Etiam vel sodales tellus. Nullam vulputate luctus sapien, in feugiat arcu pulvinar vitae. Phasellus risus orci, posuere non fringilla nec, placerat sit amet mauris. Mauris a sem turpis, vitae hendrerit risus. Mauris suscipit, purus ac ornare elementum, enim dolor convallis mauris, sit amet convallis urna metus at leo. Curabitur eget nisl a risus suscipit auctor. Ut a ultrices lectus. Pellentesque sed justo magna. Donec congue mi id odio sodales tincidunt. Integer cursus leo in libero imperdiet ac pharetra tortor venenatis. In nec purus at justo adipiscing condimentum. ', '', 1, 2, '2012-04-10 18:24:03', 589, '', '2012-06-25 19:54:53', 42, 0, '0000-00-00 00:00:00', '2012-04-10 18:24:03', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 2, 0, '', '', 1, 25, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(277, 129, 'Sample Content', 'sample-content', 'Integer varius tempor auctor. Etiam fringilla venenatis mollis. Duis ullamcorper massa eu sapien fringilla consequat. Aliquam nec ligula mi, quis tincidunt odio. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum rutrum dui eros. Praesent nec nibh diam.\r\n<br /><br />\r\nProin augue risus, molestie at dictum quis, viverra non ipsum. Praesent lacus dui, euismod ut mollis vel, lacinia vel arcu. In commodo arcu vitae velit elementum a luctus nibh mattis. Ut vel turpis eros. Nam mattis velit sed nibh scelerisque in bibendum felis sodales. Vivamus ornare pellentesque pellentesque. Nullam dignissim semper quam nec mollis. In vel lacus lectus, ac tristique leo.\r\n<br /><br />\r\nAenean venenatis egestas iaculis. Nullam consectetur condimentum dolor at bibendum. Nulla in enim quis ipsum pulvinar imperdiet vitae nec velit. Donec non urna quam. Aliquam congue magna nec risus iaculis posuere. Vivamus bibendum interdum molestie. Sed libero risus, varius eu dictum ac, pharetra ac elit. Curabitur a nibh id ipsum sagittis blandit. Morbi cursus commodo leo quis rhoncus. In nec purus magna, id porta enim. Donec pulvinar aliquet vulputate. Donec sit amet justo sit amet ipsum posuere imperdiet id sed magna.\r\n', '\r\n<br /><br />\r\nSed ultricies condimentum augue, sed congue erat dapibus nec. Etiam quis tempor nibh. Vestibulum urna dui, sodales ut ornare vitae, porta non augue. Curabitur nunc ipsum, facilisis nec luctus blandit, luctus at sem. Vestibulum pharetra augue vitae orci mollis scelerisque. Quisque gravida diam vel mauris ultricies ac faucibus turpis volutpat. Maecenas augue elit, rutrum pharetra mattis ullamcorper, commodo varius enim. Phasellus dapibus mattis ipsum sit amet tincidunt. In hac habitasse platea dictumst. Sed nisi dolor, ullamcorper eget pretium molestie, commodo non dolor. Praesent volutpat aliquet neque ut bibendum. Pellentesque tincidunt tortor non ipsum venenatis ultricies.\r\n<br /><br />\r\nProin at justo eu orci condimentum ornare sed pellentesque orci. Duis nec interdum massa. Proin porta semper enim, sit amet condimentum lorem interdum non. Etiam vel sodales tellus. Nullam vulputate luctus sapien, in feugiat arcu pulvinar vitae. Phasellus risus orci, posuere non fringilla nec, placerat sit amet mauris. Mauris a sem turpis, vitae hendrerit risus. Mauris suscipit, purus ac ornare elementum, enim dolor convallis mauris, sit amet convallis urna metus at leo. Curabitur eget nisl a risus suscipit auctor. Ut a ultrices lectus. Pellentesque sed justo magna. Donec congue mi id odio sodales tincidunt. Integer cursus leo in libero imperdiet ac pharetra tortor venenatis. In nec purus at justo adipiscing condimentum. ', 1, 38, '2012-04-10 18:24:03', 589, '', '2012-06-25 19:55:05', 42, 0, '0000-00-00 00:00:00', '2012-04-10 18:24:03', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 2, 0, '', '', 1, 11, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(278, 130, 'Sample Content', 'sample-content-2', 'Integer varius tempor auctor. Etiam fringilla venenatis mollis. Duis ullamcorper massa eu sapien fringilla consequat. Aliquam nec ligula mi, quis tincidunt odio. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum rutrum dui eros. Praesent nec nibh diam.\r\n<br /><br />\r\nProin augue risus, molestie at dictum quis, viverra non ipsum. Praesent lacus dui, euismod ut mollis vel, lacinia vel arcu. In commodo arcu vitae velit elementum a luctus nibh mattis. Ut vel turpis eros. Nam mattis velit sed nibh scelerisque in bibendum felis sodales. Vivamus ornare pellentesque pellentesque. Nullam dignissim semper quam nec mollis. In vel lacus lectus, ac tristique leo.\r\n<br /><br />\r\nAenean venenatis egestas iaculis. Nullam consectetur condimentum dolor at bibendum. Nulla in enim quis ipsum pulvinar imperdiet vitae nec velit. Donec non urna quam. Aliquam congue magna nec risus iaculis posuere. Vivamus bibendum interdum molestie. Sed libero risus, varius eu dictum ac, pharetra ac elit. Curabitur a nibh id ipsum sagittis blandit. Morbi cursus commodo leo quis rhoncus. In nec purus magna, id porta enim. Donec pulvinar aliquet vulputate. Donec sit amet justo sit amet ipsum posuere imperdiet id sed magna.\r\n', '\r\n<br /><br />\r\nSed ultricies condimentum augue, sed congue erat dapibus nec. Etiam quis tempor nibh. Vestibulum urna dui, sodales ut ornare vitae, porta non augue. Curabitur nunc ipsum, facilisis nec luctus blandit, luctus at sem. Vestibulum pharetra augue vitae orci mollis scelerisque. Quisque gravida diam vel mauris ultricies ac faucibus turpis volutpat. Maecenas augue elit, rutrum pharetra mattis ullamcorper, commodo varius enim. Phasellus dapibus mattis ipsum sit amet tincidunt. In hac habitasse platea dictumst. Sed nisi dolor, ullamcorper eget pretium molestie, commodo non dolor. Praesent volutpat aliquet neque ut bibendum. Pellentesque tincidunt tortor non ipsum venenatis ultricies.\r\n<br /><br />\r\nProin at justo eu orci condimentum ornare sed pellentesque orci. Duis nec interdum massa. Proin porta semper enim, sit amet condimentum lorem interdum non. Etiam vel sodales tellus. Nullam vulputate luctus sapien, in feugiat arcu pulvinar vitae. Phasellus risus orci, posuere non fringilla nec, placerat sit amet mauris. Mauris a sem turpis, vitae hendrerit risus. Mauris suscipit, purus ac ornare elementum, enim dolor convallis mauris, sit amet convallis urna metus at leo. Curabitur eget nisl a risus suscipit auctor. Ut a ultrices lectus. Pellentesque sed justo magna. Donec congue mi id odio sodales tincidunt. Integer cursus leo in libero imperdiet ac pharetra tortor venenatis. In nec purus at justo adipiscing condimentum. ', 1, 38, '2012-04-10 18:24:03', 589, '', '2012-06-25 19:55:05', 42, 0, '0000-00-00 00:00:00', '2012-04-10 18:24:03', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 3, 0, '', '', 1, 6, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(279, 131, 'Sample Content', 'sample-content-3', 'Integer varius tempor auctor. Etiam fringilla venenatis mollis. Duis ullamcorper massa eu sapien fringilla consequat. Aliquam nec ligula mi, quis tincidunt odio. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum rutrum dui eros. Praesent nec nibh diam.\r\n<br /><br />\r\nProin augue risus, molestie at dictum quis, viverra non ipsum. Praesent lacus dui, euismod ut mollis vel, lacinia vel arcu. In commodo arcu vitae velit elementum a luctus nibh mattis. Ut vel turpis eros. Nam mattis velit sed nibh scelerisque in bibendum felis sodales. Vivamus ornare pellentesque pellentesque. Nullam dignissim semper quam nec mollis. In vel lacus lectus, ac tristique leo.\r\n<br /><br />\r\nAenean venenatis egestas iaculis. Nullam consectetur condimentum dolor at bibendum. Nulla in enim quis ipsum pulvinar imperdiet vitae nec velit. Donec non urna quam. Aliquam congue magna nec risus iaculis posuere. Vivamus bibendum interdum molestie. Sed libero risus, varius eu dictum ac, pharetra ac elit. Curabitur a nibh id ipsum sagittis blandit. Morbi cursus commodo leo quis rhoncus. In nec purus magna, id porta enim. Donec pulvinar aliquet vulputate. Donec sit amet justo sit amet ipsum posuere imperdiet id sed magna.\r\n', '\r\n<br /><br />\r\nSed ultricies condimentum augue, sed congue erat dapibus nec. Etiam quis tempor nibh. Vestibulum urna dui, sodales ut ornare vitae, porta non augue. Curabitur nunc ipsum, facilisis nec luctus blandit, luctus at sem. Vestibulum pharetra augue vitae orci mollis scelerisque. Quisque gravida diam vel mauris ultricies ac faucibus turpis volutpat. Maecenas augue elit, rutrum pharetra mattis ullamcorper, commodo varius enim. Phasellus dapibus mattis ipsum sit amet tincidunt. In hac habitasse platea dictumst. Sed nisi dolor, ullamcorper eget pretium molestie, commodo non dolor. Praesent volutpat aliquet neque ut bibendum. Pellentesque tincidunt tortor non ipsum venenatis ultricies.\r\n<br /><br />\r\nProin at justo eu orci condimentum ornare sed pellentesque orci. Duis nec interdum massa. Proin porta semper enim, sit amet condimentum lorem interdum non. Etiam vel sodales tellus. Nullam vulputate luctus sapien, in feugiat arcu pulvinar vitae. Phasellus risus orci, posuere non fringilla nec, placerat sit amet mauris. Mauris a sem turpis, vitae hendrerit risus. Mauris suscipit, purus ac ornare elementum, enim dolor convallis mauris, sit amet convallis urna metus at leo. Curabitur eget nisl a risus suscipit auctor. Ut a ultrices lectus. Pellentesque sed justo magna. Donec congue mi id odio sodales tincidunt. Integer cursus leo in libero imperdiet ac pharetra tortor venenatis. In nec purus at justo adipiscing condimentum. ', 1, 38, '2012-04-10 18:24:03', 589, '', '2012-06-25 19:55:05', 42, 0, '0000-00-00 00:00:00', '2012-04-10 18:24:03', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 2, 0, '', '', 1, 3, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(287, 140, 'Optional Responsive Layout', 'responsive-layout', 'Responsive design at its most elementary definition is simply the use of css media queries and some javascript to rearrange a website''s layout to fit multiple screen sizes. This can range from a wide screen monitor down to the smallest of smart phones. It is done all through the same site, same installation, sharing the same files, and no extra layouts needed as in the past. Unlike many pixel grid based templates, Shape5 Vertex templates are already built on a fluid width layout based on percentages, with an optional pixel width wrapper, which is what responsive layouts require. Because of this Vertex templates do not require a responsive layout, instead it is completely optional! That''s right, if you''re uncomfortable with responsive layouts or it won''t work with your site, then simply turn it off and use the standard fixed or fluid width layout instead!\r\n<br /><br />\r\n<div class="blue_box">\r\n<a style="text-decoration:underline" target="_blank" href="http://www.shape5.com/joomla_tutorials.html">\r\nBe sure to visit our Tutorials page and download our Responsive Best Practices guide for useful responsive layout tips.</a>\r\n</div>\r\n<br />\r\n\r\n\r\n<h3>See It Live On Responsinator.com</h3>\r\n<a target="_blank" href="http://responsinator.com/?url=http%3A%2F%2Fwww.shape5.com%2Fdemo%2Fnew_vision">Open this website on responsinator.com to see its layout on multiple devices.</a>\r\n<br /><br />\r\n\r\n\r\n\r\n<h3>What Makes The Vertex Responsive Layout The Best and Most Flexible?</h3>\r\n<ul>\r\n<li>The responsive layout is completely optional, don''t use it if you don''t want it!</li>\r\n<li>Virtually no javascript. The only javascript used is for the mobile bar effects and to add responsive capabilites to IE7. We believe that javascript should only be used as a last resort.</li>\r\n<li>Start with a fixed or fluid layout.</li>\r\n<li>Optional IE7/8 responsive layout.</li>\r\n<li>Very easy to understand layout, which allows you to setup your site with very little effort.</li>\r\n<li>Fully customizable mobile bar styling.</li>\r\n<li>Hide divs, modules and content easily with hide classes at specified screen sizes.</li>\r\n<li>Wide screen support options.</li>\r\n<li>Multiple options for fluid width images.</li>\r\n<li>And much more!</li>\r\n</ul>\r\n<br />\r\n\r\n\r\n\r\n<h3>Easy To Understand Layout</h3>\r\nOne of the biggest advantages to the Vertex Responsive Layout is that we start the layout as if it were designed for a desktop viewer, and then simply reduce, modify, or remove certain sections or font sizes based on the size of the user''s screen. This is all done through css media queries, and is all done automatically for you! \r\n<br /><br />\r\nThe best way to see this approach, is simply resize your browser to see it all take effect.\r\n<br /><br />\r\nSome responsive designs simply use a series of floating divs that re-arrange themselves on the page and add columns as the screen width increases or decreases. The biggest con to this approach is it can become very confusing as to where your content will actually exist on any given screen; making it very hard to create a specific layout and confusing for a client; especially those with specific product and content placement needs. \r\n<br /><br />\r\nOur approach is much easier to understand. The site will always keep its core layout shown <a href="index.php/features-mainmenu-47/template-features/95-module-positions">here</a>. When the screen changes it will adjust as described below. The majority of rows and columns will not change their basic styling or positions until they reach the mobile version. Again, only minor adjustments are made on varying screen sizes so that you always know what your site will look like and where content will be placed!<br /><br />\r\n<ul>\r\n<li>If the column width option is enabled, the body is set to fluid, and the body width reaches 1300px the column sizes will increase by 30%. If it reaches 1900px they will increase by 60%. If it reaches 2500px they will increase by 90%. If you are using the max-body width calculations the column widths will be based off of this setting instead of screen width.</li>\r\n<li>Between 971px and 1300px no changes will occur to the layout. This is the standard desktop view of the template.</li>\r\n<li>At 970px (a standard 10 inch tablet screen) the body width will become fluid and will fill most of the viewing area. If the inset columns are used on the page they will be combined into their adjacent columns to create one column to increase the center column''s available width.</li>\r\n<li>At 750px (a standard 7 inch tablet screen) the mobile navigation bar will appear for easier navigation. If the column width option for small tablets is enabled you can set the center column to stay their original sizes, reduce the width by 20%, or stack into one column.</li>\r\n<li>At 580px (a standard mobile device size) the entire body will become one single column and module stack on top of each other. Some adjustments to the header and footer will occur.</li>\r\n</ul>\r\n<br />\r\n\r\nBelow are illustrations of the center columns only in the scenarios described above.\r\n<br /><br />\r\n\r\n\r\n<img class="padded" alt="" src="http://www.shape5.com/demo/images/general/responsive_columns.png"></img>\r\n\r\n<br /><br />\r\n\r\n\r\n\r\n\r\nBelow you will find a screenshot of the responsive options available in the Vertex framework. Below that you will find documentation for each feature shown.\r\n<br /><br />\r\n<img class="padded" alt="" src="http://www.shape5.com/demo/images/general/responsive1.png"></img>\r\n<br /><br />\r\n\r\n\r\n<h3>General Layout</h3>\r\nThe general layout options are the ones starting with Enable Font Resizer? and ending with Right Inset Width. These parameters are the core layout options that apply to all templates, whether responsive is enabled or not. Configuring this area is the first step in configuring a responsive layout. You can choose to set the site to either a fixed pixel width or fluid percentage width, the responsive layout will work with either option. If you are using the fluid width option we recommend enabling the Max Body Width option so that that your site does not go above the set pixels; this helps keep your site looking proportionate across very wide screen.\r\n<br /><br />\r\n\r\n\r\n\r\n<h3>Enable The Responsive Layout</h3>\r\nIf you wish to use the responsive layout simply turn on the switch and the Vertex framework will take care of the rest! It''s really that simple! Notice there is a separate switch for IE7 and IE8. This browser does not support css media queries natively, which is what makes responsive layouts possible. In order to add this functionality the template must use javascript, which can affect the performance of a website. With this added javascript IE7 and IE8 will support the responsive layout, but we highly recommend leaving it turned off. Keep in mind that the primary target for responsive websites is tablet and mobile devices, where IE7 and IE8 do not exist.\r\n<br /><br />\r\n\r\n\r\n\r\n<h3>Hide Tablet and Mobile Divs</h3>\r\nOne of the biggest obstacles to overcome when designing a responsive layout site is that not all content, images and extensions were designed to work with responsive layouts. That means that sometimes you need the ability to hide a specific element on only certain sized screens, so that something doesn''t break the site''s layout and everything looks proportionate. We''ve made that all possible and very easy to do for you with hiding classes! There are three main ways to hide content on different size screens, and they are documented <a href="index.php/features-mainmenu-47/template-features/hide-divs-and-modules">here</a>.\r\n<br /><br />\r\n\r\n\r\n\r\n<h3>Column Widths</h3>\r\nIf you are designing your site for very wide screens as well as standard desktop screens, then consider enabling this feature. If the body width is set to fluid then the left, left_inset, left_top, left_bottom, right, right_inset, right_top, and right_bottom positions will increase their widths for larger screens to keep everything proportionate. If the body width reaches 1300px this size will increase by 30%. If it reaches 1900px it will increase by 60%. If it reaches 2500px it will increase by 90%. If you are using the max-body width calculations will be based off of this setting instead of screen width. The original widths are calculated in the general layout area.\r\n<br /><br />\r\nFor smaller screens it is often hard to make all of your content fit in the main center columns. If the screen size reaches 750px you have the option to keep the widths of the center columns how they are, reduce them by 20%, or stack them on top of each other in a single column. This option is meant for 7 inch tablets and effects the main center columns only. At 580px all positions will become a single column for mobile devices.\r\n<br /><br />\r\n\r\n\r\n<h3>Mobile Bars</h3>\r\nWhen the screen size reaches 750px wide (anything smaller than a standard 10 inch tablet), a navigation bar will appear across the top of the site and the bottom. This bar replaces the main menu, login, register, and search, for easier user on mobile devices. In the configuration you can choose what to enable on these bars as well as change the colors and style however you would like.\r\n<br /><br />\r\n<img class="padded" alt="" src="http://www.shape5.com/demo/images/general/responsive2.jpg"></img>\r\n<br /><br />\r\n<img class="padded" alt="" src="http://www.shape5.com/demo/images/general/responsive3.jpg"></img>\r\n<br /><br />\r\n\r\n\r\n\r\n<h3>Mobile Links</h3>\r\nEven though this is a responsive layout and there is no separate layout page for mobile devices, that does not mean that your site''s viewers will understand this or even know what a responsive layout is. It has become a standard for websites that use a mobile layout to have a link to view the desktop view of the website, and this is what your site viewers will expect to see. This link simply turns off the responsive configuration using a cookie and calls the website like a standard desktop would when viewing in mobile. There is then a link to return back to the mobile view of the site presented.\r\n<br /><br />\r\n\r\n\r\n<div class="blue_box">\r\nI like what I see! I want to <a href="http://www.shape5.com/join-now.html" target="_top"><strong>JOIN TODAY</strong></a>. </div>', '', 1, 8, '2012-06-11 21:25:00', 589, '', '2012-10-13 18:29:42', 42, 0, '0000-00-00 00:00:00', '2012-06-11 21:25:00', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 31, 4, '', '', 1, 53, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(288, 141, 'Info Slide', 'info-slide', 'The info slide script is a great way to display your content to your customers! It will place a sliding text box over any image on the page. It can be placed inside of content or modules. It will also automatically adjust to any size screen size on window resize. See below for a demonstration.\r\n\r\n\r\n<br /><br />\r\n<div class="blue_box">\r\n<a style="text-decoration:underline" target="_blank" href="http://www.shape5.com/joomla_tutorials.html">\r\nFor a tutorial on how to setup this script be sure to view the Vertex Guide on our Tutorials page.</a>\r\n</div>\r\n\r\n<br />\r\n\r\n<div class="s5_is" style="float:left; width:31%; margin-right:15px; margin-bottom:15px">\r\n	<img alt="" src="http://www.shape5.com/demo/images/general/lazyload/lazy_load1.jpg"></img>\r\n	<div class="s5_is_slide">\r\n	<h3>Example Slide</h3>\r\n	This is dummy text. You can add any text or html markup here.\r\n	</div>\r\n</div>\r\n\r\n<div class="s5_is" style="float:left; width:31%; margin-right:15px; margin-bottom:15px">\r\n	<img alt="" src="http://www.shape5.com/demo/images/general/lazyload/lazy_load2.jpg"></img>\r\n	<div class="s5_is_slide">\r\n	<h3>Example Slide</h3>\r\n	This is dummy text. You can add any text or html markup here.\r\n	</div>\r\n</div>\r\n\r\n<div class="s5_is" style="float:left; width:31%; margin-right:15px; margin-bottom:15px">\r\n	<img alt="" src="http://www.shape5.com/demo/images/general/lazyload/lazy_load3.jpg"></img>\r\n	<div class="s5_is_slide">\r\n	<h3>Example Slide</h3>\r\n	This is dummy text. You can add any text or html markup here.\r\n	</div>\r\n</div>\r\n\r\n<div class="s5_is" style="float:left; width:31%; margin-right:15px; margin-bottom:15px">\r\n	<img alt="" src="http://www.shape5.com/demo/images/general/lazyload/lazy_load4.jpg"></img>\r\n	<div class="s5_is_slide">\r\n	<h3>Example Slide</h3>\r\n	This is dummy text. You can add any text or html markup here.\r\n	</div>\r\n</div>\r\n\r\n<div class="s5_is" style="float:left; width:31%; margin-right:15px; margin-bottom:15px">\r\n	<img alt="" src="http://www.shape5.com/demo/images/general/lazyload/lazy_load5.jpg"></img>\r\n	<div class="s5_is_slide">\r\n	<h3>Example Slide</h3>\r\n	This is dummy text. You can add any text or html markup here.\r\n	</div>\r\n</div>\r\n\r\n<div class="s5_is" style="float:left; width:31%; margin-right:15px; margin-bottom:15px">\r\n	<img alt="" src="http://www.shape5.com/demo/images/general/lazyload/lazy_load6.jpg"></img>\r\n	<div class="s5_is_slide">\r\n	<h3>Example Slide</h3>\r\n	This is dummy text. You can add any text or html markup here.\r\n	</div>\r\n</div>\r\n\r\n<div class="s5_is" style="float:left; width:31%; margin-right:15px; margin-bottom:15px">\r\n	<img alt="" src="http://www.shape5.com/demo/images/general/lazyload/lazy_load7.jpg"></img>\r\n	<div class="s5_is_slide">\r\n	<h3>Example Slide</h3>\r\n	This is dummy text. You can add any text or html markup here.\r\n	</div>\r\n</div>\r\n\r\n<div class="s5_is" style="float:left; width:31%; margin-right:15px; margin-bottom:15px">\r\n	<img alt="" src="http://www.shape5.com/demo/images/general/lazyload/lazy_load8.jpg"></img>\r\n	<div class="s5_is_slide">\r\n	<h3>Example Slide</h3>\r\n	This is dummy text. You can add any text or html markup here.\r\n	</div>\r\n</div>\r\n\r\n<div class="s5_is" style="float:left; width:31%; margin-right:15px; margin-bottom:15px">\r\n	<img alt="" src="http://www.shape5.com/demo/images/general/lazyload/lazy_load9.jpg"></img>\r\n	<div class="s5_is_slide">\r\n	<h3>Example Slide</h3>\r\n	This is dummy text. You can add any text or html markup here.\r\n	</div>\r\n</div>\r\n\r\n\r\n\r\n\r\n\r\n<div style="clear:both"></div>\r\n\r\n<br/>\r\n\r\n\r\n\r\n\r\n\r\n \r\n\r\n\r\n<div class="blue_box">\r\nI like what I see! I want to <a href="http://www.shape5.com/join-now.html" target="_top"><strong>JOIN TODAY</strong></a>. </div>\r\n', '', 1, 8, '2012-06-11 21:25:29', 589, '', '2012-06-25 19:54:14', 42, 0, '0000-00-00 00:00:00', '2012-06-11 21:25:29', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 15, 3, '', '', 1, 19, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', '');
INSERT INTO `#__content` (`id`, `asset_id`, `title`, `alias`, `introtext`, `fulltext`, `state`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`, `featured`, `language`, `xreference`) VALUES
(289, 142, 'Hide Divs, Content, and Modules', 'hide-divs-and-modules', 'One of the biggest obstacles to overcome when designing a responsive layout site is that not all content, images and extensions were designed to work with responsive layouts. That means that sometimes you need the ability to hide a specific element on only certain sized screens, so that something doesn''t break the site''s layout and everything looks proportionate. We''ve made that all possible and very easy to do for you with hiding classes! There are three main ways to hide content on different size screens, and they are documented below. Please note that these classes are only enabled when the responsive layout is enabled.\r\n<br /><br />\r\n<div class="blue_box">\r\n<a style="text-decoration:underline" target="_blank" href="http://www.shape5.com/joomla_tutorials.html">\r\nBe sure to visit our Tutorials page and download our Responsive Best Practices guide for useful responsive layout tips.</a>\r\n</div>\r\n<br /><br />\r\n<h3>Hide Sections of the Template via the Template Configuration</h3>\r\nThis is the simplest way to hide an area of the template is to use the template interface to easily select areas of the template that you want to hide on tablet sized screens (970px and less) or mobile screens (580px or less). Simply select the area that you want to hide and the Vertex framework takes care of the rest! These fields do work independent of each other, so if you want to hide something on both tablet and mobile sized screens you must select the same area on both fields.\r\n<br /><br />\r\n<img class="padded" src="http://www.shape5.com/demo/images/general/hide_divs1.png"></img>\r\n<br /><br />\r\nIMPORTANT - If you turn off a column position such as right or right_inset something else must be in the same column or the layout will not work. For example you can turn off right_inset and keep right, but you cannot turn off both unless something is publihsed to right_top or right_bottom as well.\r\n\r\n\r\n<br /><br />\r\n<h3>Hide Specific Modules via the Hide Classes</h3>\r\nIf you have only a specific module that you would like to hide at certain screen sizes, and not an entire section of the template, this is the best approach. A hide class is a class that can be applied to any element on the page and hides that particular element at certain screen sizes. Classes range in 100px increments for large screens and 50px increments for small screens. <strong>Below are some examples, and at the very bottom of this page there is a list of all the available hide classes.</strong> Use these sparingly if you can. As a recommendation, the primary target of these classes should focus on tablet and mobile sized screens. Wide screen monitors vary in size so it''s much harder to use these classes correctly for large monitors. Tablet and mobile devices are much more consistent in size so it is much easier to apply the smaller hide classes.\r\n<br /><br />\r\nFor example, say you want to hide a specific module when the screen sizes reaches 900px wide, and remain hidden for any screen below 900px. Simply add class=hide_900 to the title of the module like this:\r\n<br /><br />\r\n<img class="padded" src="http://www.shape5.com/demo/images/general/hide_divs2.png"></img>\r\n<br /><br />\r\nThe class is simply put into the title of the module. There must be a space just before class= , and don''t worry, the class area of the title won''t actually show on the live site, it''s only shown in the backend. It must be entered exactly as shown above. The title can be published or unpublished, it does not matter which. Simply adding the classes to the title will apply the classes to the entire module.\r\n<br /><br />\r\nWhat if you want it to hide the module only for a certain range? That''s easy just add _only to the end of the class name. hide_900_only will only hide that element from 900px to the next increment in the hide classes, which is 850px. So it will only be hidden from 850px to 900px. You can also add multiple classes to the title like this class=hide_900_only hide_850_only which will apply both classes to the module.\r\n<br /><br />\r\nWhat if you want to hide the module and then show it again later? That''s simple, use show_ in the class instead of hide_. This will make the module show for the specified size no matter what other settings are on the module. So if you want to hide the module from 1000px and below, but you want to show it again later then do something like the following class=hide_1000 show_600. This will hide the module from 600px to 1000px.\r\n<br /><br />\r\nIs there a more simple way? Yes, of course, the above directions are for experienced users who want to tweak their content for every available screen size. If you don''t want to mess around with specific window sizes simply use the following classes instead, which have preset screen sizes applied to them:\r\n<br /><br />\r\nhide_wide_screen<br />\r\nhide_standard_screen<br />\r\nhide_large_tablet<br />\r\nhide_small_tablet<br />\r\nhide_mobile<br />\r\nshow_wide_screen<br />\r\nshow_standard_screen<br />\r\nshow_large_tablet<br />\r\nshow_small_tablet<br />\r\nshow_mobile<br />\r\n\r\n\r\n<br />\r\n<h3>Hide Specific Content via the Hide Classes</h3>\r\nIf you have only specific content or images within an article or module that you want to hide then use the same hide classes described above, but wrap that specific content inside of the class instead of applying it to the entire module. For example, in the image below, the third paragraph will hide at 900px and then show again at 700px.\r\n\r\n<br /><br />\r\n<img class="padded" src="http://www.shape5.com/demo/images/general/hide_divs3.png"></img>\r\n<br /><br />\r\n\r\n\r\n\r\n\r\n<h3>Available Hide Classes</h3>\r\nAll the available hide classes are listed below. Note there is a break at 970px and 580px to accommodate tablet and mobile sized screens.\r\n\r\n<br /><br />@media screen and (max-width: 1600px){<br />    .hide_1600 {<br />    display:none;<br />    }<br />}    <br /><br />@media screen and (min-width:1500px) and (max-width: 1600px){<br />    .hide_1600_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 1600px){<br />    .show_1600 {<br />    display:inline;<br />    }<br />}    <br /><br />@media screen and (min-width:1500px) and (max-width: 1600px){<br />    .show_1600_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (max-width: 1500px){<br />    .hide_1500 {<br />    display:none;<br />    }<br />}    <br /><br />@media screen and (min-width:1400px) and (max-width: 1500px){<br />    .hide_1500_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 1500px){<br />    .show_1500 {<br />    display:inline;<br />    }<br />}    <br /><br />@media screen and (min-width:1400px) and (max-width: 1500px){<br />    .show_1500_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (max-width: 1400px){<br />    .hide_1400 {<br />    display:none;<br />    }<br />}    <br /><br />@media screen and (min-width:1300px) and (max-width: 1400px){<br />    .hide_1400_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 1400px){<br />    .show_1400 {<br />    display:inline;<br />    }<br />}    <br /><br />@media screen and (min-width:1300px) and (max-width: 1400px){<br />    .show_1400_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (max-width: 1300px){<br />    .hide_1300 {<br />    display:none;<br />    }<br />}    <br /><br />@media screen and (min-width:1200px) and (max-width: 1300px){<br />    .hide_1300_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 1300px){<br />    .show_1300 {<br />    display:inline;<br />    }<br />}    <br /><br />@media screen and (min-width:1200px) and (max-width: 1300px){<br />    .show_1300_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (max-width: 1200px){<br />    .hide_1200 {<br />    display:none;<br />    }<br />}    <br /><br />@media screen and (min-width:1100px) and (max-width: 1200px){<br />    .hide_1200_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 1200px){<br />    .show_1200 {<br />    display:inline;<br />    }<br />}    <br /><br />@media screen and (min-width:1100px) and (max-width: 1200px){<br />    .show_1200_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (max-width: 1100px){<br />    .hide_1100 {<br />    display:none;<br />    }<br />}    <br /><br />@media screen and (min-width:1000px) and (max-width: 1100px){<br />    .hide_1100_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 1100px){<br />    .show_1100 {<br />    display:inline;<br />    }<br />}    <br /><br />@media screen and (min-width:1000px) and (max-width: 1100px){<br />    .show_1100_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (max-width: 1000px){<br />    .hide_1000 {<br />    display:none;<br />    }<br />}    <br /><br />@media screen and (min-width:900px) and (max-width: 1000px){<br />    .hide_1000_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 1000px){<br />    .show_1000 {<br />    display:inline;<br />    }<br />}    <br /><br />@media screen and (min-width:900px) and (max-width: 1000px){<br />    .show_1000_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (max-width: 970px){<br />    .hide_970 {<br />    display:none;<br />    }<br />}    <br /><br />@media screen and (min-width:900px) and (max-width: 970px){<br />    .hide_970_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 970px){<br />    .show_970 {<br />    display:inline;<br />    }<br />}    <br /><br />@media screen and (min-width:900px) and (max-width: 970px){<br />    .show_970_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (max-width: 900px){<br />    .hide_900 {<br />    display:none;<br />    }<br />}    <br /><br />@media screen and (min-width:850px) and (max-width: 900px){<br />    .hide_900_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 900px){<br />    .show_900 {<br />    display:inline;<br />    }<br />}    <br /><br />@media screen and (min-width:850px) and (max-width: 900px){<br />    .show_900_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (max-width: 850px){<br />    .hide_850 {<br />    display:none;<br />    }<br />}    <br /><br />@media screen and (min-width:800px) and (max-width: 850px){<br />    .hide_850_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 850px){<br />    .show_850 {<br />    display:inline;<br />    }<br />}    <br /><br />@media screen and (min-width:800px) and (max-width: 850px){<br />    .show_850_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (max-width: 800px){<br />    .hide_800 {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (min-width:750px) and (max-width: 800px){<br />    .hide_800_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 800px){<br />    .show_800 {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (min-width:750px) and (max-width: 800px){<br />    .show_800_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (max-width: 750px){<br />    .hide_750 {<br />    display:none;<br />    }<br />}    <br /><br />@media screen and (min-width:700px) and (max-width: 750px){<br />    .hide_750_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 750px){<br />    .show_750 {<br />    display:inline;<br />    }<br />}    <br /><br />@media screen and (min-width:700px) and (max-width: 750px){<br />    .show_750_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (max-width: 700px){<br />    .hide_700 {<br />    display:none;<br />    }<br />}    <br /><br />@media screen and (min-width:650px) and (max-width: 700px){<br />    .hide_700_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 700px){<br />    .show_700 {<br />    display:inline;<br />    }<br />}    <br /><br />@media screen and (min-width:650px) and (max-width: 700px){<br />    .show_700_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (max-width: 650px){<br />    .hide_650 {<br />    display:none;<br />    }<br />}    <br /><br />@media screen and (min-width:600px) and (max-width: 650px){<br />    .hide_650_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 650px){<br />    .show_650 {<br />    display:inline;<br />    }<br />}    <br /><br />@media screen and (min-width:600px) and (max-width: 650px){<br />    .show_650_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (max-width: 600px){<br />    .hide_600 {<br />    display:none;<br />    }<br />}    <br /><br />@media screen and (min-width:580px) and (max-width: 600px){<br />    .hide_600_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 600px){<br />    .show_600 {<br />    display:inline;<br />    }<br />}    <br /><br />@media screen and (min-width:580px) and (max-width: 600px){<br />    .show_600_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (max-width: 579px){<br />    .hide_580 {<br />    display:none;<br />    }<br />}    <br /><br />@media screen and (min-width:550px) and (max-width: 579px){<br />    .hide_580_only {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 579px){<br />    .show_580 {<br />    display:inline;<br />    }<br />}    <br /><br />@media screen and (min-width:550px) and (max-width: 579px){<br />    .show_580_only {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (min-width:1300px) and (max-width: 50000px){<br />    .hide_wide_screen {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (min-width:971px) and (max-width: 1299px){<br />    .hide_standard_screen {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (min-width:750px) and (max-width: 970px){<br />    .hide_large_tablet {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (min-width:580px) and (max-width: 750px){<br />    .hide_small_tablet {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (min-width:580px) and (max-width: 750px){<br />    .hide_small_tablet {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (max-width: 579px){<br />    .hide_mobile {<br />    display:none;<br />    }<br />}<br /><br />@media screen and (min-width:1300px) and (max-width: 50000px){<br />    .show_wide_screen {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (min-width:971px) and (max-width: 1299px){<br />    .show_standard_screen {<br />    display:inline;<br />    }<br />}<br /><br />@media screen and (min-width:750px) and (max-width: 970px){<br />    .show_large_tablet {<br />    display:inline !important;<br />    }<br />}<br /><br />@media screen and (min-width:580px) and (max-width: 750px){<br />    .show_small_tablet {<br />    display:inline !important;<br />    }<br />}<br /><br />@media screen and (max-width: 579px){<br />    .show_mobile {<br />    display:inline !important;<br />    }<br />}\r\n\r\n<br /><br />\r\n\r\n\r\n\r\n<p><br /></p>\r\n<div class="blue_box"><strong>I like what I see! I want to <a href="http://www.shape5.com/join-now.html" target="_top">JOIN TODAY</a>.</strong></div>\r\n<br />', '', 1, 8, '2012-06-11 21:26:08', 589, '', '2012-06-25 19:54:14', 42, 0, '0000-00-00 00:00:00', '2012-06-11 21:26:08', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 23, 2, '', '', 1, 23, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(290, 143, 'Built In File Compression', 'built-in-file-compression', '<p>Increase speed and performance by compressing core template CSS and Javascript files to much smaller sizes than the original! Enabling compression is a great way to boost your site''s performance. It simply combines css and js into consolidated files. This reduces the downloads sizes and reduces the numbers of calls to your server, to dramatically help your site''s overall performance. No data is lost during this process, just simply made smaller. Please note that this compression will only compress core template files, not third party files or files from extensions.</p>\r\n<p><br /> <img class="padded" src="http://www.shape5.com/demo/images/general/file_compression.jpg" border="0" alt="" /></p>\r\n<div style="clear: both;"> </div>\r\n<p><br /><br /></p>\r\n<div class="red_box"><span class="alert">Note: Because this feature uses cached versions of your javascript and css this plugin should not be used while developing your site and should only be enabled after you have completed your site. <br /><br /> Gzip must be installed on your server and enabled in PHP in order to function.</span></div>\r\n<p> </p>\r\n<p><strong><span style="font-size: large;">See It In Action!</span></strong></p>\r\n<p>Without Compression Enabled:</p>\r\n<p><img class="padded" src="http://www.shape5.com/demo/images/general/compression_without.png" border="0" /></p>\r\n<p>With Compression nabled:</p>\r\n<p><img class="padded" src="http://www.shape5.com/demo/images/general/compression_with.png" border="0" /></p>\r\n<p> </p>\r\n<div class="blue_box"><strong>I like what I see! I want to <a href="http://www.shape5.com/join-now.html" target="_top">JOIN TODAY</a>.</strong></div>\r\n<p> </p>', '', 1, 8, '2012-06-11 21:26:24', 589, '', '2012-06-25 19:54:14', 42, 0, '0000-00-00 00:00:00', '2012-06-11 21:26:24', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 12, 1, '', '', 1, 13, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(291, 150, 'Stock Photography', 'stock-photography', 'All content and images shown on this site is for demo, presentation purposes only. This site is intended to exemplify a live website and does not make any claim of any kind to the validity of non-Shape5 content, images or posts published. Stock photography and icons were purchased from <a href="http://www.shutterstock.com" target="_blank">shutterstock.com</a> for this demo only, and is not included with this template. You may not use these items for your own use without first purchasing them from their copyright owner. Links will be provided for some images if you wish to purchase them from their copyright owners. ', '', 1, 8, '2012-06-30 12:33:15', 589, '', '2012-08-13 20:13:04', 42, 0, '0000-00-00 00:00:00', '2012-06-30 12:33:15', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 3, 0, '', '', 1, 5, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(296, 156, 'Beautiful Design and Flexbile Features', 'beautiful-design-and-flexbile-features', '<img alt="" src="images/article.jpg" style="width:200px;margin-bottom:10px" class="padded" />\r\n\r\nThe Shape5 New Vision template is simply a work of art! This template is built off of the responsive Vertex framework, which will allow your site to adapt to any screen size automatically! You get to control the sizes of modules, body width, effects, and much more through the easy to use interface.\r\n<br /><br />\r\nNeed a custom color scheme? This template comes with two custom highlight colors and a custom font selector so you can adjust your website''s appearance you need. The two colored backgrounds at the top and bottom of this page, as well as links and titles are all controlled through the highlight colors.\r\n\r\n<span class="hide_800 show_mobile">\r\nIn addition to a great template you will also receive included customizations for the S5 Image and Content Fader and S5 Tab Show modules, both which match this template perfectly and can be demo''d on this page. Don''t forget to read each page under the main menu to find out all the great features of this template!\r\n</span>\r\n\r\n<br />\r\n', '\r\n.', 1, 20, '2012-10-10 19:34:03', 589, '', '2012-10-14 16:47:42', 42, 0, '0000-00-00 00:00:00', '2012-10-10 19:34:03', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 34, 0, '', '', 1, 0, '{"robots":"","author":"","rights":"","xreference":""}', 1, '*', '');

-- --------------------------------------------------------

--
-- Table structure for table `#__contentitem_tag_map`
--

DROP TABLE IF EXISTS `#__contentitem_tag_map`;
CREATE TABLE IF NOT EXISTS `#__contentitem_tag_map` (
  `type_alias` varchar(255) NOT NULL DEFAULT '',
  `core_content_id` int(10) unsigned NOT NULL COMMENT 'PK from the core content table',
  `content_item_id` int(11) NOT NULL COMMENT 'PK from the content type table',
  `tag_id` int(10) unsigned NOT NULL COMMENT 'PK from the tag table',
  `tag_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Date of most recent save for this tag-item',
  `type_id` mediumint(8) NOT NULL COMMENT 'PK from the content_type table',
  UNIQUE KEY `uc_ItemnameTagid` (`type_id`,`content_item_id`,`tag_id`),
  KEY `idx_tag_type` (`tag_id`,`type_id`),
  KEY `idx_date_id` (`tag_date`,`tag_id`),
  KEY `idx_tag` (`tag_id`),
  KEY `idx_type` (`type_id`),
  KEY `idx_core_content_id` (`core_content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Maps items from content tables to tags';

-- --------------------------------------------------------

--
-- Table structure for table `#__content_frontpage`
--

DROP TABLE IF EXISTS `#__content_frontpage`;
CREATE TABLE IF NOT EXISTS `#__content_frontpage` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `#__content_frontpage`
--

INSERT INTO `#__content_frontpage` (`content_id`, `ordering`) VALUES
(6, 13),
(9, 15),
(30, 16),
(44, 14),
(45, 12),
(246, 11),
(247, 10),
(248, 9),
(249, 8),
(250, 7),
(251, 6),
(253, 5),
(254, 4),
(285, 3),
(286, 2),
(296, 1);

-- --------------------------------------------------------

--
-- Table structure for table `#__content_rating`
--

DROP TABLE IF EXISTS `#__content_rating`;
CREATE TABLE IF NOT EXISTS `#__content_rating` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `rating_sum` int(10) unsigned NOT NULL DEFAULT '0',
  `rating_count` int(10) unsigned NOT NULL DEFAULT '0',
  `lastip` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__core_log_searches`
--

DROP TABLE IF EXISTS `#__core_log_searches`;
CREATE TABLE IF NOT EXISTS `#__core_log_searches` (
  `search_term` varchar(128) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




-- --------------------------------------------------------

--
-- Table structure for table `#__content_types`
--

DROP TABLE IF EXISTS `#__content_types`;
CREATE TABLE IF NOT EXISTS `#__content_types` (
  `type_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_title` varchar(255) NOT NULL DEFAULT '',
  `type_alias` varchar(255) NOT NULL DEFAULT '',
  `table` varchar(255) NOT NULL DEFAULT '',
  `rules` text NOT NULL,
  `field_mappings` text NOT NULL,
  `router` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`type_id`),
  KEY `idx_alias` (`type_alias`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10000 ;

--
-- Dumping data for table `#__content_types`
--

INSERT INTO `#__content_types` (`type_id`, `type_title`, `type_alias`, `table`, `rules`, `field_mappings`, `router`) VALUES
(1, 'Article', 'com_content.article', '{"special":{"dbtable":"#__content","key":"id","type":"Content","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__core_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":[{"core_content_item_id":"id","core_title":"title","core_state":"state","core_alias":"alias","core_created_time":"created","core_modified_time":"modified","core_body":"introtext", "core_hits":"hits","core_publish_up":"publish_up","core_publish_down":"publish_down","core_access":"access", "core_params":"attribs", "core_featured":"featured", "core_metadata":"metadata", "core_language":"language", "core_images":"images", "core_urls":"urls", "core_version":"version", "core_ordering":"ordering", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"catid", "core_xreference":"xreference", "asset_id":"asset_id"}], "special": [{"fulltext":"fulltext"}]}', 'ContentHelperRoute::getArticleRoute'),
(2, 'Weblink', 'com_weblinks.weblink', '{"special":{"dbtable":"#__weblinks","key":"id","type":"Weblink","prefix":"WeblinksTable","config":"array()"},"common":{"dbtable":"#__core_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":[{"core_content_item_id":"id","core_title":"title","core_state":"state","core_alias":"alias","core_created_time":"created","core_modified_time":"modified","core_body":"description", "core_hits":"hits","core_publish_up":"publish_up","core_publish_down":"publish_down","core_access":"access", "core_params":"params", "core_featured":"featured", "core_metadata":"metadata", "core_language":"language", "core_images":"images", "core_urls":"urls", "core_version":"version", "core_ordering":"ordering", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"catid", "core_xreference":"xreference", "asset_id":"null"}], "special": []}', 'WeblinksHelperRoute::getWeblinkRoute'),
(3, 'Contact', 'com_contact.contact', '{"special":{"dbtable":"#__contact_details","key":"id","type":"Contact","prefix":"ContactTable","config":"array()"},"common":{"dbtable":"#__core_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":[{"core_content_item_id":"id","core_title":"name","core_state":"published","core_alias":"alias","core_created_time":"created","core_modified_time":"modified","core_body":"address", "core_hits":"hits","core_publish_up":"publish_up","core_publish_down":"publish_down","core_access":"access", "core_params":"params", "core_featured":"featured", "core_metadata":"metadata", "core_language":"language", "core_images":"image", "core_urls":"webpage", "core_version":"version", "core_ordering":"ordering", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"catid", "core_xreference":"xreference", "asset_id":"null"}], "special": [{"con_position":"con_position","suburb":"suburb","state":"state","country":"country","postcode":"postcode","telephone":"telephone","fax":"fax","misc":"misc","email_to":"email_to","default_con":"default_con","user_id":"user_id","mobile":"mobile","sortname1":"sortname1","sortname2":"sortname2","sortname3":"sortname3"}]}', 'ContactHelperRoute::getContactRoute'),
(4, 'Newsfeed', 'com_newsfeeds.newsfeed', '{"special":{"dbtable":"#__newsfeeds","key":"id","type":"Newsfeed","prefix":"NewsfeedsTable","config":"array()"},"common":{"dbtable":"#__core_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":[{"core_content_item_id":"id","core_title":"name","core_state":"published","core_alias":"alias","core_created_time":"created","core_modified_time":"modified","core_body":"description", "core_hits":"hits","core_publish_up":"publish_up","core_publish_down":"publish_down","core_access":"access", "core_params":"params", "core_featured":"featured", "core_metadata":"metadata", "core_language":"language", "core_images":"images", "core_urls":"link", "core_version":"version", "core_ordering":"ordering", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"catid", "core_xreference":"xreference", "asset_id":"null"}], "special": [{"numarticles":"numarticles","cache_time":"cache_time","rtl":"rtl"}]}', 'NewsfeedsHelperRoute::getNewsfeedRoute'),
(5, 'User', 'com_users.user', '{"special":{"dbtable":"#__users","key":"id","type":"User","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__core_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":[{"core_content_item_id":"id","core_title":"name","core_state":"null","core_alias":"username","core_created_time":"registerdate","core_modified_time":"lastvisitDate","core_body":"null", "core_hits":"null","core_publish_up":"null","core_publish_down":"null","access":"null", "core_params":"params", "core_featured":"null", "core_metadata":"null", "core_language":"null", "core_images":"null", "core_urls":"null", "core_version":"null", "core_ordering":"null", "core_metakey":"null", "core_metadesc":"null", "core_catid":"null", "core_xreference":"null", "asset_id":"null"}], "special": [{}]}', 'UsersHelperRoute::getUserRoute'),
(6, 'Article Category', 'com_content.category', '{"special":{"dbtable":"#__categories","key":"id","type":"Category","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__core_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":[{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"null", "core_metadata":"metadata", "core_language":"language", "core_images":"null", "core_urls":"null", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"parent_id", "core_xreference":"null", "asset_id":"asset_id"}], "special": [{"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path","extension":"extension","note":"note"}]}', 'ContentHelperRoute::getCategoryRoute'),
(7, 'Contact Category', 'com_contact.category', '{"special":{"dbtable":"#__categories","key":"id","type":"Category","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__core_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":[{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"null", "core_metadata":"metadata", "core_language":"language", "core_images":"null", "core_urls":"null", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"parent_id", "core_xreference":"null", "asset_id":"asset_id"}], "special": [{"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path","extension":"extension","note":"note"}]}', 'ContactHelperRoute::getCategoryRoute'),
(8, 'Newsfeeds Category', 'com_newsfeeds.category', '{"special":{"dbtable":"#__categories","key":"id","type":"Category","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__core_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":[{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"null", "core_metadata":"metadata", "core_language":"language", "core_images":"null", "core_urls":"null", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"parent_id", "core_xreference":"null", "asset_id":"asset_id"}], "special": [{"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path","extension":"extension","note":"note"}]}', 'NewsfeedsHelperRoute::getCategoryRoute'),
(9, 'Weblinks Category', 'com_weblinks.category', '{"special":{"dbtable":"#__categories","key":"id","type":"Category","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__core_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":[{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"null", "core_metadata":"metadata", "core_language":"language", "core_images":"null", "core_urls":"null", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"parent_id", "core_xreference":"null", "asset_id":"asset_id"}], "special": [{"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path","extension":"extension","note":"note"}]}', 'WeblinksHelperRoute::getCategoryRoute'),
(10, 'Tag', 'com_tags.tag', '{"special":{"dbtable":"#__tags","key":"tag_id","type":"Tag","prefix":"TagsTable","config":"array()"},"common":{"dbtable":"#__core_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":[{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"featured", "core_metadata":"metadata", "core_language":"language", "core_images":"images", "core_urls":"urls", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"null", "core_xreference":"null", "asset_id":"null"}], "special": [{"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path"}]}', 'TagsHelperRoute::getTagRoute');


-- --------------------------------------------------------

--
-- Table structure for table `#__extensions`
--

DROP TABLE IF EXISTS `#__extensions`;
CREATE TABLE IF NOT EXISTS `#__extensions` (
  `extension_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `type` varchar(20) NOT NULL,
  `element` varchar(100) NOT NULL,
  `folder` varchar(100) NOT NULL,
  `client_id` tinyint(3) NOT NULL,
  `enabled` tinyint(3) NOT NULL DEFAULT '1',
  `access` int(10) unsigned DEFAULT NULL,
  `protected` tinyint(3) NOT NULL DEFAULT '0',
  `manifest_cache` text NOT NULL,
  `params` text NOT NULL,
  `custom_data` text NOT NULL,
  `system_data` text NOT NULL,
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) DEFAULT '0',
  `state` int(11) DEFAULT '0',
  PRIMARY KEY (`extension_id`),
  KEY `element_clientid` (`element`,`client_id`),
  KEY `element_folder_clientid` (`element`,`folder`,`client_id`),
  KEY `extension` (`type`,`element`,`folder`,`client_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10050 ;

--
-- Dumping data for table `#__extensions`
--

INSERT INTO `#__extensions` (`extension_id`, `name`, `type`, `element`, `folder`, `client_id`, `enabled`, `access`, `protected`, `manifest_cache`, `params`, `custom_data`, `system_data`, `checked_out`, `checked_out_time`, `ordering`, `state`) VALUES
(1, 'com_mailto', 'component', 'com_mailto', '', 0, 1, 1, 1, '{"legacy":false,"name":"com_mailto","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_MAILTO_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(2, 'com_wrapper', 'component', 'com_wrapper', '', 0, 1, 1, 1, '{"legacy":false,"name":"com_wrapper","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_WRAPPER_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(3, 'com_admin', 'component', 'com_admin', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_admin","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_ADMIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(4, 'com_banners', 'component', 'com_banners', '', 1, 1, 1, 0, '{"legacy":false,"name":"com_banners","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_BANNERS_XML_DESCRIPTION","group":""}', '{"purchase_type":"3","track_impressions":"0","track_clicks":"0","metakey_prefix":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(5, 'com_cache', 'component', 'com_cache', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_cache","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_CACHE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(6, 'com_categories', 'component', 'com_categories', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_categories","type":"component","creationDate":"December 2007","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_CATEGORIES_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(7, 'com_checkin', 'component', 'com_checkin', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_checkin","type":"component","creationDate":"Unknown","author":"Joomla! Project","copyright":"(C) 2005 - 2008 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_CHECKIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(8, 'com_contact', 'component', 'com_contact', '', 1, 1, 1, 0, '{"legacy":false,"name":"com_contact","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_CONTACT_XML_DESCRIPTION","group":""}', '{"contact_layout":"_:default","show_contact_category":"hide","show_contact_list":"0","presentation_style":"plain","show_name":"1","show_position":"1","show_email":"0","show_street_address":"1","show_suburb":"1","show_state":"1","show_postcode":"1","show_country":"1","show_telephone":"1","show_mobile":"1","show_fax":"1","show_webpage":"1","show_misc":"1","show_image":"1","image":"","allow_vcard":"0","show_articles":"0","show_profile":"0","show_links":"0","linka_name":"","linkb_name":"","linkc_name":"","linkd_name":"","linke_name":"","contact_icons":"0","icon_address":"","icon_email":"","icon_telephone":"","icon_mobile":"","icon_fax":"","icon_misc":"","category_layout":"_:default","show_category_title":"1","show_description":"1","show_description_image":"0","maxLevel":"-1","show_empty_categories":"0","show_subcat_desc":"1","show_cat_items":"1","show_base_description":"1","maxLevelcat":"-1","show_empty_categories_cat":"0","show_subcat_desc_cat":"1","show_cat_items_cat":"1","show_pagination_limit":"1","show_headings":"1","show_position_headings":"1","show_email_headings":"0","show_telephone_headings":"1","show_mobile_headings":"0","show_fax_headings":"0","show_suburb_headings":"1","show_state_headings":"1","show_country_headings":"1","show_pagination":"2","show_pagination_results":"1","initial_sort":"ordering","captcha":"","show_email_form":"1","show_email_copy":"1","banned_email":"","banned_subject":"","banned_text":"","validate_session":"1","custom_reply":"0","redirect":"","show_feed_link":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(9, 'com_cpanel', 'component', 'com_cpanel', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_cpanel","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_CPANEL_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10, 'com_installer', 'component', 'com_installer', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_installer","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_INSTALLER_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(11, 'com_languages', 'component', 'com_languages', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_languages","type":"component","creationDate":"2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_LANGUAGES_XML_DESCRIPTION","group":""}', '{"administrator":"en-GB","site":"en-GB"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(12, 'com_login', 'component', 'com_login', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_login","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_LOGIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(13, 'com_media', 'component', 'com_media', '', 1, 1, 0, 1, '{"legacy":false,"name":"com_media","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_MEDIA_XML_DESCRIPTION","group":""}', '{"upload_extensions":"bmp,csv,doc,gif,ico,jpg,jpeg,odg,odp,ods,odt,pdf,png,ppt,swf,txt,xcf,xls,BMP,CSV,DOC,GIF,ICO,JPG,JPEG,ODG,ODP,ODS,ODT,PDF,PNG,PPT,SWF,TXT,XCF,XLS","upload_maxsize":"10","file_path":"images","image_path":"images","restrict_uploads":"1","allowed_media_usergroup":"3","check_mime":"1","image_extensions":"bmp,gif,jpg,png","ignore_extensions":"","upload_mime":"image\\/jpeg,image\\/gif,image\\/png,image\\/bmp,application\\/x-shockwave-flash,application\\/msword,application\\/excel,application\\/pdf,application\\/powerpoint,text\\/plain,application\\/x-zip","upload_mime_illegal":"text\\/html","enable_flash":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(14, 'com_menus', 'component', 'com_menus', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_menus","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_MENUS_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(15, 'com_messages', 'component', 'com_messages', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_messages","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_MESSAGES_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(16, 'com_modules', 'component', 'com_modules', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_modules","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_MODULES_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(17, 'com_newsfeeds', 'component', 'com_newsfeeds', '', 1, 1, 1, 0, '{"legacy":false,"name":"com_newsfeeds","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_NEWSFEEDS_XML_DESCRIPTION","group":""}', '{"show_feed_image":"1","show_feed_description":"1","show_item_description":"1","feed_word_count":"0","show_headings":"1","show_name":"1","show_articles":"0","show_link":"1","show_description":"1","show_description_image":"1","display_num":"","show_pagination_limit":"1","show_pagination":"1","show_pagination_results":"1","show_cat_items":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(18, 'com_plugins', 'component', 'com_plugins', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_plugins","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_PLUGINS_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(19, 'com_search', 'component', 'com_search', '', 1, 1, 1, 0, '{"legacy":false,"name":"com_search","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_SEARCH_XML_DESCRIPTION","group":""}', '{"enabled":"0","show_date":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(20, 'com_templates', 'component', 'com_templates', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_templates","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_TEMPLATES_XML_DESCRIPTION","group":""}', '{"template_positions_display":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(21, 'com_weblinks', 'component', 'com_weblinks', '', 1, 1, 1, 0, '{"legacy":false,"name":"com_weblinks","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_WEBLINKS_XML_DESCRIPTION","group":""}', '{"show_comp_description":"1","comp_description":"","show_link_hits":"1","show_link_description":"1","show_other_cats":"0","show_headings":"0","show_numbers":"0","show_report":"1","count_clicks":"1","target":"0","link_icons":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(22, 'com_content', 'component', 'com_content', '', 1, 1, 0, 1, '{"legacy":false,"name":"com_content","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_CONTENT_XML_DESCRIPTION","group":""}', '{"article_layout":"_:default","show_title":"1","link_titles":"1","show_intro":"1","show_category":"1","link_category":"1","show_parent_category":"0","link_parent_category":"0","show_author":"1","link_author":"0","show_create_date":"0","show_modify_date":"0","show_publish_date":"1","show_item_navigation":"1","show_vote":"0","show_readmore":"1","show_readmore_title":"1","readmore_limit":"100","show_icons":"1","show_print_icon":"1","show_email_icon":"1","show_hits":"1","show_noauth":"0","category_layout":"_:blog","show_category_title":"0","show_description":"0","show_description_image":"0","maxLevel":"1","show_empty_categories":"0","show_no_articles":"1","show_subcat_desc":"1","show_cat_num_articles":"0","show_base_description":"1","maxLevelcat":"-1","show_empty_categories_cat":"0","show_subcat_desc_cat":"1","show_cat_num_articles_cat":"1","num_leading_articles":"1","num_intro_articles":"4","num_columns":"2","num_links":"4","multi_column_order":"0","orderby_pri":"order","orderby_sec":"rdate","order_date":"published","show_pagination_limit":"1","filter_field":"hide","show_headings":"1","list_show_date":"0","date_format":"","list_show_hits":"1","list_show_author":"1","show_pagination":"2","show_pagination_results":"1","show_feed_link":"1","feed_summary":"0","filters":{"1":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"6":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"7":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"2":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"3":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"4":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"5":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"10":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"12":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"8":{"filter_type":"BL","filter_tags":"","filter_attributes":""}}}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(23, 'com_config', 'component', 'com_config', '', 1, 1, 0, 1, '{"legacy":false,"name":"com_config","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_CONFIG_XML_DESCRIPTION","group":""}', '{"filters":{"1":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"6":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"7":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"2":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"3":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"4":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"5":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"8":{"filter_type":"NONE","filter_tags":"","filter_attributes":""}}}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(24, 'com_redirect', 'component', 'com_redirect', '', 1, 1, 0, 1, '{"legacy":false,"name":"com_redirect","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_REDIRECT_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(25, 'com_users', 'component', 'com_users', '', 1, 1, 0, 1, '{"legacy":false,"name":"com_users","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_USERS_XML_DESCRIPTION","group":""}', '{"allowUserRegistration":"0","new_usertype":"2","useractivation":"1","frontend_userparams":"1","mailSubjectPrefix":"","mailBodySuffix":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(27, 'com_finder', 'component', 'com_finder', '', 1, 1, 0, 0, '', '{"show_description":"1","description_length":255,"allow_empty_query":"0","show_url":"1","show_advanced":"1","expand_advanced":"0","show_date_filters":"0","highlight_terms":"1","opensearch_name":"","opensearch_description":"","batch_size":"50","memory_table_limit":30000,"title_multiplier":"1.7","text_multiplier":"0.7","meta_multiplier":"1.2","path_multiplier":"2.0","misc_multiplier":"0.3","stemmer":"porter_en"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(28, 'com_joomlaupdate', 'component', 'com_joomlaupdate', '', 1, 1, 0, 1, '{"legacy":false,"name":"com_joomlaupdate","type":"component","creationDate":"February 2012","author":"Joomla! Project","copyright":"(C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.2","description":"COM_JOOMLAUPDATE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(29, 'com_tags', 'component', 'com_tags', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_tags","type":"component","creationDate":"March 2013","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_TAGS_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(100, 'PHPMailer', 'library', 'phpmailer', '', 0, 1, 1, 1, '{"legacy":false,"name":"PHPMailer","type":"library","creationDate":"2001","author":"PHPMailer","copyright":"(c) 2001-2003, Brent R. Matzelle, (c) 2004-2009, Andy Prevost. All Rights Reserved., (c) 2010-2012, Jim Jagielski. All Rights Reserved.","authorEmail":"jimjag@gmail.com","authorUrl":"https:\\/\\/code.google.com\\/a\\/apache-extras.org\\/p\\/phpmailer\\/","version":"5.2.1","description":"LIB_PHPMAILER_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(101, 'SimplePie', 'library', 'simplepie', '', 0, 1, 1, 1, '{"legacy":false,"name":"SimplePie","type":"library","creationDate":"2004","author":"SimplePie","copyright":"Copyright (c) 2004-2009, Ryan Parman and Geoffrey Sneddon","authorEmail":"","authorUrl":"http:\\/\\/simplepie.org\\/","version":"1.2","description":"LIB_SIMPLEPIE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(102, 'phputf8', 'library', 'phputf8', '', 0, 1, 1, 1, '{"legacy":false,"name":"phputf8","type":"library","creationDate":"2006","author":"Harry Fuecks","copyright":"Copyright various authors","authorEmail":"hfuecks@gmail.com","authorUrl":"http:\\/\\/sourceforge.net\\/projects\\/phputf8","version":"0.5","description":"LIB_PHPUTF8_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(103, 'Joomla! Platform', 'library', 'joomla', '', 0, 1, 1, 1, '{"legacy":false,"name":"Joomla! Platform","type":"library","creationDate":"2008","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"http:\\/\\/www.joomla.org","version":"12.2","description":"LIB_JOOMLA_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(200, 'mod_articles_archive', 'module', 'mod_articles_archive', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_articles_archive","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters.\\n\\t\\tAll rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_ARTICLES_ARCHIVE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(201, 'mod_articles_latest', 'module', 'mod_articles_latest', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_articles_latest","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_LATEST_NEWS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(202, 'mod_articles_popular', 'module', 'mod_articles_popular', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_articles_popular","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_POPULAR_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(203, 'mod_banners', 'module', 'mod_banners', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_banners","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_BANNERS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(204, 'mod_breadcrumbs', 'module', 'mod_breadcrumbs', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_breadcrumbs","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_BREADCRUMBS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(205, 'mod_custom', 'module', 'mod_custom', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_custom","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_CUSTOM_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(206, 'mod_feed', 'module', 'mod_feed', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_feed","type":"module","creationDate":"July 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_FEED_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(207, 'mod_footer', 'module', 'mod_footer', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_footer","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_FOOTER_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(208, 'mod_login', 'module', 'mod_login', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_login","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_LOGIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(209, 'mod_menu', 'module', 'mod_menu', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_menu","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_MENU_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(210, 'mod_articles_news', 'module', 'mod_articles_news', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_articles_news","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_ARTICLES_NEWS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(211, 'mod_random_image', 'module', 'mod_random_image', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_random_image","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_RANDOM_IMAGE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(212, 'mod_related_items', 'module', 'mod_related_items', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_related_items","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_RELATED_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(213, 'mod_search', 'module', 'mod_search', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_search","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_SEARCH_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(214, 'mod_stats', 'module', 'mod_stats', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_stats","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_STATS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(215, 'mod_syndicate', 'module', 'mod_syndicate', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_syndicate","type":"module","creationDate":"May 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_SYNDICATE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(216, 'mod_users_latest', 'module', 'mod_users_latest', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_users_latest","type":"module","creationDate":"December 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_USERS_LATEST_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(217, 'mod_weblinks', 'module', 'mod_weblinks', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_weblinks","type":"module","creationDate":"July 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_WEBLINKS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(218, 'mod_whosonline', 'module', 'mod_whosonline', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_whosonline","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_WHOSONLINE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(219, 'mod_wrapper', 'module', 'mod_wrapper', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_wrapper","type":"module","creationDate":"October 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_WRAPPER_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(220, 'mod_articles_category', 'module', 'mod_articles_category', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_articles_category","type":"module","creationDate":"February 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_ARTICLES_CATEGORY_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(221, 'mod_articles_categories', 'module', 'mod_articles_categories', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_articles_categories","type":"module","creationDate":"February 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_ARTICLES_CATEGORIES_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(222, 'mod_languages', 'module', 'mod_languages', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_languages","type":"module","creationDate":"February 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_LANGUAGES_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(223, 'mod_finder', 'module', 'mod_finder', '', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(300, 'mod_custom', 'module', 'mod_custom', '', 1, 1, 1, 1, '{"legacy":false,"name":"mod_custom","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_CUSTOM_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(301, 'mod_feed', 'module', 'mod_feed', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_feed","type":"module","creationDate":"July 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_FEED_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(302, 'mod_latest', 'module', 'mod_latest', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_latest","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_LATEST_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(303, 'mod_logged', 'module', 'mod_logged', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_logged","type":"module","creationDate":"January 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_LOGGED_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(304, 'mod_login', 'module', 'mod_login', '', 1, 1, 1, 1, '{"legacy":false,"name":"mod_login","type":"module","creationDate":"March 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_LOGIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(305, 'mod_menu', 'module', 'mod_menu', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_menu","type":"module","creationDate":"March 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_MENU_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(306, 'mod_online', 'module', 'mod_online', '', 1, 1, 1, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(307, 'mod_popular', 'module', 'mod_popular', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_popular","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_POPULAR_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(308, 'mod_quickicon', 'module', 'mod_quickicon', '', 1, 1, 1, 1, '{"legacy":false,"name":"mod_quickicon","type":"module","creationDate":"Nov 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_QUICKICON_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(309, 'mod_status', 'module', 'mod_status', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_status","type":"module","creationDate":"Feb 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_STATUS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(310, 'mod_submenu', 'module', 'mod_submenu', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_submenu","type":"module","creationDate":"Feb 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_SUBMENU_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(311, 'mod_title', 'module', 'mod_title', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_title","type":"module","creationDate":"Nov 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_TITLE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(312, 'mod_toolbar', 'module', 'mod_toolbar', '', 1, 1, 1, 1, '{"legacy":false,"name":"mod_toolbar","type":"module","creationDate":"Nov 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_TOOLBAR_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(313, 'mod_multilangstatus', 'module', 'mod_multilangstatus', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_multilangstatus","type":"module","creationDate":"September 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_MULTILANGSTATUS_XML_DESCRIPTION","group":""}', '{"cache":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(314, 'mod_version', 'module', 'mod_version', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_version","type":"module","creationDate":"January 2012","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_VERSION_XML_DESCRIPTION","group":""}', '{"format":"short","product":"1","cache":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(315, 'mod_stats_admin', 'module', 'mod_stats_admin', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_stats_admin","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_STATS_XML_DESCRIPTION","group":""}', '{"serverinfo":"0","siteinfo":"0","counter":"0","increase":"0","cache":"1","cache_time":"900","cachemode":"static"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(316, 'mod_tags_popular', 'module', 'mod_tags_popular', '', 0, 1, 1, 0, '{"name":"mod_tags_popular","type":"module","creationDate":"January 2013","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.1.0","description":"MOD_TAGS_POPULAR_XML_DESCRIPTION","group":""}', '{"maximum":"5","timeframe":"alltime","owncache":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(317, 'mod_tags_similar', 'module', 'mod_tags_similar', '', 0, 1, 1, 0, '{"name":"mod_tags_similar","type":"module","creationDate":"January 2013","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.1.0","description":"MOD_TAGS_SIMILAR_XML_DESCRIPTION","group":""}', '{"maximum":"5","matchtype":"any","owncache":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(400, 'plg_authentication_gmail', 'plugin', 'gmail', 'authentication', 0, 0, 1, 0, '{"legacy":false,"name":"plg_authentication_gmail","type":"plugin","creationDate":"February 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_GMAIL_XML_DESCRIPTION","group":""}', '{"applysuffix":"0","suffix":"","verifypeer":"1","user_blacklist":""}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(401, 'plg_authentication_joomla', 'plugin', 'joomla', 'authentication', 0, 1, 1, 1, '{"legacy":false,"name":"plg_authentication_joomla","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_AUTH_JOOMLA_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(402, 'plg_authentication_ldap', 'plugin', 'ldap', 'authentication', 0, 0, 1, 0, '{"legacy":false,"name":"plg_authentication_ldap","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_LDAP_XML_DESCRIPTION","group":""}', '{"host":"","port":"389","use_ldapV3":"0","negotiate_tls":"0","no_referrals":"0","auth_method":"bind","base_dn":"","search_string":"","users_dn":"","username":"admin","password":"bobby7","ldap_fullname":"fullName","ldap_email":"mail","ldap_uid":"uid"}', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(404, 'plg_content_emailcloak', 'plugin', 'emailcloak', 'content', 0, 1, 1, 0, '{"legacy":false,"name":"plg_content_emailcloak","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_CONTENT_EMAILCLOAK_XML_DESCRIPTION","group":""}', '{"mode":"1"}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(405, 'plg_content_geshi', 'plugin', 'geshi', 'content', 0, 0, 1, 0, '{"legacy":false,"name":"plg_content_geshi","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"","authorUrl":"qbnz.com\\/highlighter","version":"3.0.0","description":"PLG_CONTENT_GESHI_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(406, 'plg_content_loadmodule', 'plugin', 'loadmodule', 'content', 0, 1, 1, 0, '{"legacy":false,"name":"plg_content_loadmodule","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_LOADMODULE_XML_DESCRIPTION","group":""}', '{"style":"none"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(407, 'plg_content_pagebreak', 'plugin', 'pagebreak', 'content', 0, 1, 1, 0, '{"legacy":false,"name":"plg_content_pagebreak","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_CONTENT_PAGEBREAK_XML_DESCRIPTION","group":""}', '{"title":"1","multipage_toc":"1","showall":"1"}', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(408, 'plg_content_pagenavigation', 'plugin', 'pagenavigation', 'content', 0, 1, 1, 0, '{"legacy":false,"name":"plg_content_pagenavigation","type":"plugin","creationDate":"January 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_PAGENAVIGATION_XML_DESCRIPTION","group":""}', '{"position":"1"}', '', '', 0, '0000-00-00 00:00:00', 5, 0),
(409, 'plg_content_vote', 'plugin', 'vote', 'content', 0, 1, 1, 0, '{"legacy":false,"name":"plg_content_vote","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_VOTE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 6, 0),
(410, 'plg_editors_codemirror', 'plugin', 'codemirror', 'editors', 0, 1, 1, 1, '{"legacy":false,"name":"plg_editors_codemirror","type":"plugin","creationDate":"28 March 2011","author":"Marijn Haverbeke","copyright":"","authorEmail":"N\\/A","authorUrl":"","version":"1.0","description":"PLG_CODEMIRROR_XML_DESCRIPTION","group":""}', '{"linenumbers":"0","tabmode":"indent"}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(411, 'plg_editors_none', 'plugin', 'none', 'editors', 0, 1, 1, 1, '{"legacy":false,"name":"plg_editors_none","type":"plugin","creationDate":"August 2004","author":"Unknown","copyright":"","authorEmail":"N\\/A","authorUrl":"","version":"3.0.0","description":"PLG_NONE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(412, 'plg_editors_tinymce', 'plugin', 'tinymce', 'editors', 0, 1, 1, 0, '{"legacy":false,"name":"plg_editors_tinymce","type":"plugin","creationDate":"2005-2012","author":"Moxiecode Systems AB","copyright":"Moxiecode Systems AB","authorEmail":"N\\/A","authorUrl":"tinymce.moxiecode.com\\/","version":"3.5.6","description":"PLG_TINY_XML_DESCRIPTION","group":""}', '{"mode":"1","skin":"0","compressed":"0","cleanup_startup":"0","cleanup_save":"2","entity_encoding":"raw","lang_mode":"0","lang_code":"en","text_direction":"ltr","content_css":"1","content_css_custom":"","relative_urls":"1","newlines":"0","invalid_elements":"script,applet,iframe","extended_elements":"","toolbar":"top","toolbar_align":"left","html_height":"550","html_width":"750","element_path":"1","fonts":"1","paste":"1","searchreplace":"1","insertdate":"1","format_date":"%Y-%m-%d","inserttime":"1","format_time":"%H:%M:%S","colors":"1","table":"1","smilies":"1","media":"1","hr":"1","directionality":"1","fullscreen":"1","style":"1","layer":"1","xhtmlxtras":"1","visualchars":"1","nonbreaking":"1","template":"1","blockquote":"1","wordcount":"1","advimage":"1","advlink":"1","autosave":"1","contextmenu":"1","inlinepopups":"1","safari":"0","custom_plugin":"","custom_button":""}', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(413, 'plg_editors-xtd_article', 'plugin', 'article', 'editors-xtd', 0, 1, 1, 1, '{"legacy":false,"name":"plg_editors-xtd_article","type":"plugin","creationDate":"October 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_ARTICLE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(414, 'plg_editors-xtd_image', 'plugin', 'image', 'editors-xtd', 0, 1, 1, 0, '{"legacy":false,"name":"plg_editors-xtd_image","type":"plugin","creationDate":"August 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_IMAGE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(415, 'plg_editors-xtd_pagebreak', 'plugin', 'pagebreak', 'editors-xtd', 0, 1, 1, 0, '{"legacy":false,"name":"plg_editors-xtd_pagebreak","type":"plugin","creationDate":"August 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_EDITORSXTD_PAGEBREAK_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(416, 'plg_editors-xtd_readmore', 'plugin', 'readmore', 'editors-xtd', 0, 1, 1, 0, '{"legacy":false,"name":"plg_editors-xtd_readmore","type":"plugin","creationDate":"March 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_READMORE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(417, 'plg_search_categories', 'plugin', 'categories', 'search', 0, 1, 1, 0, '{"legacy":false,"name":"plg_search_categories","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SEARCH_CATEGORIES_XML_DESCRIPTION","group":""}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(418, 'plg_search_contacts', 'plugin', 'contacts', 'search', 0, 1, 1, 0, '{"legacy":false,"name":"plg_search_contacts","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SEARCH_CONTACTS_XML_DESCRIPTION","group":""}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(419, 'plg_search_content', 'plugin', 'content', 'search', 0, 1, 1, 0, '{"legacy":false,"name":"plg_search_content","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SEARCH_CONTENT_XML_DESCRIPTION","group":""}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(420, 'plg_search_newsfeeds', 'plugin', 'newsfeeds', 'search', 0, 1, 1, 0, '{"legacy":false,"name":"plg_search_newsfeeds","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SEARCH_NEWSFEEDS_XML_DESCRIPTION","group":""}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(421, 'plg_search_weblinks', 'plugin', 'weblinks', 'search', 0, 1, 1, 0, '{"legacy":false,"name":"plg_search_weblinks","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SEARCH_WEBLINKS_XML_DESCRIPTION","group":""}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(422, 'plg_system_languagefilter', 'plugin', 'languagefilter', 'system', 0, 0, 1, 1, '{"legacy":false,"name":"plg_system_languagefilter","type":"plugin","creationDate":"July 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SYSTEM_LANGUAGEFILTER_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 1, 0);
INSERT INTO `#__extensions` (`extension_id`, `name`, `type`, `element`, `folder`, `client_id`, `enabled`, `access`, `protected`, `manifest_cache`, `params`, `custom_data`, `system_data`, `checked_out`, `checked_out_time`, `ordering`, `state`) VALUES
(423, 'plg_system_p3p', 'plugin', 'p3p', 'system', 0, 1, 1, 0, '{"legacy":false,"name":"plg_system_p3p","type":"plugin","creationDate":"September 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_P3P_XML_DESCRIPTION","group":""}', '{"headers":"NOI ADM DEV PSAi COM NAV OUR OTRo STP IND DEM"}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(424, 'plg_system_cache', 'plugin', 'cache', 'system', 0, 0, 1, 1, '{"legacy":false,"name":"plg_system_cache","type":"plugin","creationDate":"February 2007","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_CACHE_XML_DESCRIPTION","group":""}', '{"browsercache":"0","cachetime":"15"}', '', '', 0, '0000-00-00 00:00:00', 9, 0),
(425, 'plg_system_debug', 'plugin', 'debug', 'system', 0, 1, 1, 0, '{"legacy":false,"name":"plg_system_debug","type":"plugin","creationDate":"December 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_DEBUG_XML_DESCRIPTION","group":""}', '{"profile":"1","queries":"1","memory":"1","language_files":"1","language_strings":"1","strip-first":"1","strip-prefix":"","strip-suffix":""}', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(426, 'plg_system_log', 'plugin', 'log', 'system', 0, 1, 1, 1, '{"legacy":false,"name":"plg_system_log","type":"plugin","creationDate":"April 2007","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_LOG_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 5, 0),
(427, 'plg_system_redirect', 'plugin', 'redirect', 'system', 0, 1, 1, 1, '{"legacy":false,"name":"plg_system_redirect","type":"plugin","creationDate":"April 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_REDIRECT_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 6, 0),
(428, 'plg_system_remember', 'plugin', 'remember', 'system', 0, 1, 1, 1, '{"legacy":false,"name":"plg_system_remember","type":"plugin","creationDate":"April 2007","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_REMEMBER_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 7, 0),
(429, 'plg_system_sef', 'plugin', 'sef', 'system', 0, 1, 1, 0, '{"legacy":false,"name":"plg_system_sef","type":"plugin","creationDate":"December 2007","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SEF_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 8, 0),
(430, 'plg_system_logout', 'plugin', 'logout', 'system', 0, 1, 1, 1, '{"legacy":false,"name":"plg_system_logout","type":"plugin","creationDate":"April 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SYSTEM_LOGOUT_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(431, 'plg_user_contactcreator', 'plugin', 'contactcreator', 'user', 0, 0, 1, 0, '{"legacy":false,"name":"plg_user_contactcreator","type":"plugin","creationDate":"August 2009","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_CONTACTCREATOR_XML_DESCRIPTION","group":""}', '{"autowebpage":"","category":"34","autopublish":"0"}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(432, 'plg_user_joomla', 'plugin', 'joomla', 'user', 0, 1, 1, 0, '{"legacy":false,"name":"plg_user_joomla","type":"plugin","creationDate":"December 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2009 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_USER_JOOMLA_XML_DESCRIPTION","group":""}', '{"autoregister":"1"}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(433, 'plg_user_profile', 'plugin', 'profile', 'user', 0, 0, 1, 0, '{"legacy":false,"name":"plg_user_profile","type":"plugin","creationDate":"January 2008","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_USER_PROFILE_XML_DESCRIPTION","group":""}', '{"register-require_address1":"1","register-require_address2":"1","register-require_city":"1","register-require_region":"1","register-require_country":"1","register-require_postal_code":"1","register-require_phone":"1","register-require_website":"1","register-require_favoritebook":"1","register-require_aboutme":"1","register-require_tos":"1","register-require_dob":"1","profile-require_address1":"1","profile-require_address2":"1","profile-require_city":"1","profile-require_region":"1","profile-require_country":"1","profile-require_postal_code":"1","profile-require_phone":"1","profile-require_website":"1","profile-require_favoritebook":"1","profile-require_aboutme":"1","profile-require_tos":"1","profile-require_dob":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(434, 'plg_extension_joomla', 'plugin', 'joomla', 'extension', 0, 1, 1, 1, '{"legacy":false,"name":"plg_extension_joomla","type":"plugin","creationDate":"May 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_EXTENSION_JOOMLA_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(435, 'plg_content_joomla', 'plugin', 'joomla', 'content', 0, 1, 1, 0, '{"legacy":false,"name":"plg_content_joomla","type":"plugin","creationDate":"November 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_CONTENT_JOOMLA_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(436, 'plg_system_languagecode', 'plugin', 'languagecode', 'system', 0, 0, 1, 0, '{"legacy":false,"name":"plg_system_languagecode","type":"plugin","creationDate":"November 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SYSTEM_LANGUAGECODE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 10, 0),
(437, 'plg_quickicon_joomlaupdate', 'plugin', 'joomlaupdate', 'quickicon', 0, 1, 1, 1, '{"legacy":false,"name":"plg_quickicon_joomlaupdate","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_QUICKICON_JOOMLAUPDATE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(438, 'plg_quickicon_extensionupdate', 'plugin', 'extensionupdate', 'quickicon', 0, 1, 1, 1, '{"legacy":false,"name":"plg_quickicon_extensionupdate","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_QUICKICON_EXTENSIONUPDATE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(439, 'plg_captcha_recaptcha', 'plugin', 'recaptcha', 'captcha', 0, 1, 1, 0, '{"legacy":false,"name":"plg_captcha_recaptcha","type":"plugin","creationDate":"December 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_CAPTCHA_RECAPTCHA_XML_DESCRIPTION","group":""}', '{"public_key":"","private_key":"","theme":"clean"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(440, 'plg_system_highlight', 'plugin', 'highlight', 'system', 0, 1, 1, 0, '', '{}', '', '', 0, '0000-00-00 00:00:00', 7, 0),
(441, 'plg_content_finder', 'plugin', 'finder', 'content', 0, 0, 1, 0, '{"legacy":false,"name":"plg_content_finder","type":"plugin","creationDate":"December 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"1.7.0","description":"PLG_CONTENT_FINDER_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(442, 'plg_finder_categories', 'plugin', 'categories', 'finder', 0, 1, 1, 0, '', '{}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(443, 'plg_finder_contacts', 'plugin', 'contacts', 'finder', 0, 1, 1, 0, '', '{}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(444, 'plg_finder_content', 'plugin', 'content', 'finder', 0, 1, 1, 0, '', '{}', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(445, 'plg_finder_newsfeeds', 'plugin', 'newsfeeds', 'finder', 0, 1, 1, 0, '', '{}', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(446, 'plg_finder_weblinks', 'plugin', 'weblinks', 'finder', 0, 1, 1, 0, '', '{}', '', '', 0, '0000-00-00 00:00:00', 5, 0),
(447, 'plg_finder_tags', 'plugin', 'tags', 'finder', 0, 1, 1, 0, '{"name":"plg_finder_tags","type":"plugin","creationDate":"February 2013","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_FINDER_TAGS_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(500, 'atomic', 'template', 'atomic', '', 0, 1, 1, 0, '{"legacy":false,"name":"atomic","type":"template","creationDate":"10\\/10\\/09","author":"Ron Severdia","copyright":"Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.","authorEmail":"contact@kontentdesign.com","authorUrl":"http:\\/\\/www.kontentdesign.com","version":"2.5.0","description":"TPL_ATOMIC_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(502, 'bluestork', 'template', 'bluestork', '', 1, 1, 1, 0, '{"legacy":false,"name":"bluestork","type":"template","creationDate":"07\\/02\\/09","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"TPL_BLUESTORK_XML_DESCRIPTION","group":""}', '{"useRoundedCorners":"1","showSiteName":"0","textBig":"0","highContrast":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(503, 'beez_20', 'template', 'beez_20', '', 0, 1, 1, 0, '{"legacy":false,"name":"beez_20","type":"template","creationDate":"25 November 2009","author":"Angie Radtke","copyright":"Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.","authorEmail":"a.radtke@derauftritt.de","authorUrl":"http:\\/\\/www.der-auftritt.de","version":"2.5.0","description":"TPL_BEEZ2_XML_DESCRIPTION","group":""}', '{"wrapperSmall":"53","wrapperLarge":"72","sitetitle":"","sitedescription":"","navposition":"center","templatecolor":"nature"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(504, 'hathor', 'template', 'hathor', '', 1, 1, 1, 0, '{"legacy":false,"name":"hathor","type":"template","creationDate":"May 2010","author":"Andrea Tarr","copyright":"Copyright (C) 2005 - 2013 Open Source Matters, Inc. All rights reserved.","authorEmail":"hathor@tarrconsulting.com","authorUrl":"http:\\/\\/www.tarrconsulting.com","version":"3.0.0","description":"TPL_HATHOR_XML_DESCRIPTION","group":""}', '{"showSiteName":"0","colourChoice":"0","boldText":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(505, 'beez5', 'template', 'beez5', '', 0, 1, 1, 0, '{"legacy":false,"name":"beez5","type":"template","creationDate":"21 May 2010","author":"Angie Radtke","copyright":"Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.","authorEmail":"a.radtke@derauftritt.de","authorUrl":"http:\\/\\/www.der-auftritt.de","version":"2.5.0","description":"TPL_BEEZ5_XML_DESCRIPTION","group":""}', '{"wrapperSmall":"53","wrapperLarge":"72","sitetitle":"","sitedescription":"","navposition":"center","html5":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(600, 'English (United Kingdom)', 'language', 'en-GB', '', 0, 1, 1, 1, '{"legacy":false,"name":"English (United Kingdom)","type":"language","creationDate":"2008-03-15","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.3","description":"en-GB site language","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(601, 'English (United Kingdom)', 'language', 'en-GB', '', 1, 1, 1, 1, '{"legacy":false,"name":"English (United Kingdom)","type":"language","creationDate":"2008-03-15","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.3","description":"en-GB administrator language","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(700, 'files_joomla', 'file', 'joomla', '', 0, 1, 1, 1, '{"name":"files_joomla","type":"file","creationDate":"April 2013","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.1.1","description":"FILES_JOOMLA_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10000, 'Our Poll', 'module', 'mod_poll', '', 0, 1, 1, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10002, 'Popular Articles', 'module', 'mod_mostread', '', 0, 1, 1, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10003, 'Archive', 'module', 'mod_archive', '', 0, 1, 1, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10004, 'Sections', 'module', 'mod_sections', '', 0, 1, 1, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10014, 'Our Latest News', 'module', 'mod_latestnews', '', 0, 1, 1, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10015, 'S5 Accordion Menu', 'module', 'mod_s5_accordion_menu', '', 0, 1, 1, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10016, 'Register', 'module', 'mod_s5_register', '', 0, 1, 1, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10017, 'Featured News', 'module', 'mod_newsflash', '', 0, 1, 1, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10021, 'VirtueMart Product Snapshot', 'plugin', 'vmproductsnapshots', '', 0, 1, 1, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10022, 'Virtuemart Extended Search Plugin', 'plugin', 'vmxsearch.plugin', '', 0, 1, 1, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10029, 'System - S5 Flex Menu', 'plugin', 'S5FlexMenu', 'system', 0, 1, 1, 0, '{"legacy":false,"name":"System - S5 Flex Menu","type":"plugin","creationDate":"June 2011","author":"Shape5.com","copyright":"This Plugin is released under the GNU\\/GPL License","authorEmail":"contact@shape5.com","authorUrl":"www.shape5.com","version":"1.0","description":"The S5 Flex Menu system is a very powerful plugin that provides functionality far beyond the standard Joomla menu system.","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10031, 'PKG_JOOMLA', 'package', 'pkg_joomla', '', 0, 1, 1, 1, '{"legacy":false,"name":"PKG_JOOMLA","type":"package","creationDate":"2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"http:\\/\\/www.joomla.org","version":"2.5.0","description":"PKG_JOOMLA_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10039, 'S5 Box', 'module', 'mod_s5_box', '', 0, 1, 0, 0, '{"legacy":false,"name":"S5 Box","type":"module","creationDate":"September 2009","author":"Shape5.com","copyright":"Copyright (C) 2005 - 2008 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"The S5 Box allows you to display any module in lightbox style popup activated by a class name.  Choose either Mootools or Javascript library.  It can display up to 10 S5 Box''s by simply adding a class name to any HTML element and a module position to your template XML file. Check out the tutorial on http:\\/\\/www.shape5.com\\/demo\\/elegance\\/s5_box\\/ for more information.","group":""}', '{"":"Use the settings below to alter the width of the S5 Box''s be sure to publish a module to each corresponding position for the box to be enabled. Please visit the following url for a tutorial http:\\/\\/www.shape5.com\\/demo\\/elegance\\/s5_box\\/","@spacer":"","s5_jsversion":"mootools","s5_boxeffect":"elastic","s5boxwidth1":"35","s5boxwidth2":"35","s5boxwidth3":"35","s5boxwidth4":"35","s5boxwidth5":"35","s5boxwidth6":"35","s5boxwidth7":"35","s5boxwidth8":"35","s5boxwidth9":"35","s5boxwidth10":"35","moduleclass_sfx":"-s5_box"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10040, 'S5 Image and Content Fader v3', 'module', 'mod_s5_image_and_content_fader', '', 0, 1, 0, 0, '{"legacy":false,"name":"S5 Image and Content Fader v3","type":"module","creationDate":"July 2010","author":"Shape5.com","copyright":"","authorEmail":"contact@shape5.com","authorUrl":"www.shape5.com","version":"3.0.0","description":"This module is responsive ready!  It will display images of any url and user defined conent in one of 4 effect transitions.  Choose between actual size and stretch for your images and enter in pixels or percentages for your width, great for responsive\\/fluid websites!  Powered by Mootools but if you experience conflicts you can enable legacy S5 Effects mode (contains less features than Mootools version).  ","group":""}', '{"pretext":"","moduleclass_sfx":"","height":"183px","width":"482px","s5stretchimage":"actualsize","s5pixelwidth":"0px","background":"","jslibrary":"mootools","jseffect":"fade","s5_dropdowntext":"Open Gallery","s5_delay":"9000","s5_hidecar":"truee","s5_hidebut":"truee","s5_hidetext":"truee","title1":"","title2":"","title3":"","title4":"","title5":"","title6":"","title7":"","title8":"","title9":"","title10":"","picture1":"","picture1link":"","picture1text":"","picture2":"","picture2link":"","picture2text":"","picture3":"","picture3link":"","picture3text":"","picture4":"","picture4link":"","picture4text":"","picture5":"","picture5link":"","picture5text":"","picture6":"","picture6link":"","picture6text":"","picture7":"","picture7link":"","picture7text":"","picture8":"","picture8link":"","picture8text":"","picture9":"","picture9link":"","picture9text":"","picture10":"","picture10link":"","picture10text":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10044, 'S5 Tab Show', 'module', 'mod_s5_tabshow', '', 0, 1, 0, 0, '{"legacy":false,"name":"S5 Tab Show","type":"module","creationDate":"November 2008","author":"Shape5.com","copyright":"","authorEmail":"contact@shape5.com","authorUrl":"www.shape5.com","version":"1.6.0","description":"This module will display up to 10 Joomla modules in various styles with tabs.","group":""}', '{"s5_width":"310","s5_buttonheight":"27px","s5_lineheight":"2.2em","s5_buttoncolor":"transparent","s5_buttonimage":"..\\/modules\\/mod_s5_tabshow\\/s5_tabshow\\/s5_tab_show_nonactive.png","s5_hovercolor":"#FFFFFF","s5_hoverimage":"..\\/modules\\/mod_s5_tabshow\\/s5_tabshow\\/s5_tab_show_active.png","s5_fontcolor":"#000000","s5_javascript":"mootools","s5_mootoolsmouse":"mouse","s5_effectsani":"fade","s5_effectmouse":"mouse","text1line":"Tab 1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10045, 'new_vision', 'template', 'new_vision', '', 0, 1, 1, 0, '{"legacy":false,"name":"new_vision","type":"template","creationDate":"October 2012","author":"Shape5.com","copyright":"Shape5","authorEmail":"contact@shape5.com","authorUrl":"http:\\/\\/www.shape5.com","version":"1.0","description":"\\n\\t\\n\\t<h1>Shape 5 - New Vision<\\/h1>\\n\\n\\t<br\\/>\\n\\t<img src=\\"..\\/templates\\/new_vision\\/template_thumbnail.png\\" align=\\"left\\" hspace=\\"10\\" style=\\"padding-right:10px;\\"\\/>\\n\\tThis template is for members of the Shape 5 Joomla Template Club only, it is not free or open to the public domain.  <br \\/><br \\/>\\n\\tFor tutorials pertaining to this template and additional information check out:<br \\/> <a href=\\"http:\\/\\/www.shape5.com\\/demo\\/new_vision\\">New Vision Demo<\\/a>\\n\\t<br \\/>\\n\\t<a href=\\"http:\\/\\/www.shape5.com\\/joomla_tutorials.html\\">Joomla and Vertex Tutorials<\\/a>\\n\\t<br \\/>\\n\\t<br \\/><a target=\\"_blank\\" href=\\"http:\\/\\/www.shape5.com\\">Click here<\\/a> to visit Shape5.com\\n\\t<br \\/><br \\/>\\n\\t<div class=\\"vertex-admin-logoback\\"><div class=\\"vertex-admin-logo\\"><\\/div><\\/div>\\n\\t<br \\/><br \\/>\\n\\tPowered by a comprehensive template blue print<br\\/><br\\/>\\n\\t<a target=\\"_blank\\" href=\\"http:\\/\\/www.shape5.com\\/joomla\\/framework\\/vertex_framework.html\\">Read more about Vertex here<\\/a> \\n\\t\\n\\t\\n\\t\\n\\t","group":""}', '{"settings":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10047, 'isis', 'template', 'isis', '', 1, 1, 1, 0, '{"legacy":false,"name":"isis","type":"template","creationDate":"3\\/30\\/2012","author":"Kyle Ledbetter","copyright":"Copyright (C) 2005 - 2013 Open Source Matters, Inc. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"","version":"1.0","description":"TPL_ISIS_XML_DESCRIPTION","group":""}', '{"templateColor":"","logoFile":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10048, 'protostar', 'template', 'protostar', '', 0, 1, 1, 0, '{"legacy":false,"name":"protostar","type":"template","creationDate":"4\\/30\\/2012","author":"Kyle Ledbetter","copyright":"Copyright (C) 2005 - 2013 Open Source Matters, Inc. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"","version":"1.0","description":"TPL_PROTOSTAR_XML_DESCRIPTION","group":""}', '{"templateColor":"","logoFile":"","googleFont":"1","googleFontName":"Open+Sans","fluidContainer":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10049, 'beez3', 'template', 'beez3', '', 0, 1, 1, 0, '{"legacy":false,"name":"beez3","type":"template","creationDate":"25 November 2009","author":"Angie Radtke","copyright":"Copyright (C) 2005 - 2013 Open Source Matters, Inc. All rights reserved.","authorEmail":"a.radtke@derauftritt.de","authorUrl":"http:\\/\\/www.der-auftritt.de","version":"3.0.0","description":"TPL_BEEZ3_XML_DESCRIPTION","group":""}', '{"wrapperSmall":"53","wrapperLarge":"72","sitetitle":"","sitedescription":"","navposition":"center","templatecolor":"nature"}', '', '', 0, '0000-00-00 00:00:00', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `#__finder_filters`
--

DROP TABLE IF EXISTS `#__finder_filters`;
CREATE TABLE IF NOT EXISTS `#__finder_filters` (
  `filter_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT '1',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL,
  `created_by_alias` varchar(255) NOT NULL,
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `map_count` int(10) unsigned NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  `params` mediumtext,
  PRIMARY KEY (`filter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `#__finder_links`
--

DROP TABLE IF EXISTS `#__finder_links`;
CREATE TABLE IF NOT EXISTS `#__finder_links` (
  `link_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `route` varchar(255) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `indexdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `md5sum` varchar(32) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `state` int(5) DEFAULT '1',
  `access` int(5) DEFAULT '0',
  `language` varchar(8) NOT NULL,
  `publish_start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `list_price` double unsigned NOT NULL DEFAULT '0',
  `sale_price` double unsigned NOT NULL DEFAULT '0',
  `type_id` int(11) NOT NULL,
  `object` mediumblob NOT NULL,
  PRIMARY KEY (`link_id`),
  KEY `idx_type` (`type_id`),
  KEY `idx_title` (`title`),
  KEY `idx_md5` (`md5sum`),
  KEY `idx_url` (`url`(75)),
  KEY `idx_published_list` (`published`,`state`,`access`,`publish_start_date`,`publish_end_date`,`list_price`),
  KEY `idx_published_sale` (`published`,`state`,`access`,`publish_start_date`,`publish_end_date`,`sale_price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `#__finder_links_terms0`
--

DROP TABLE IF EXISTS `#__finder_links_terms0`;
CREATE TABLE IF NOT EXISTS `#__finder_links_terms0` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__finder_links_terms1`
--

DROP TABLE IF EXISTS `#__finder_links_terms1`;
CREATE TABLE IF NOT EXISTS `#__finder_links_terms1` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__finder_links_terms2`
--

DROP TABLE IF EXISTS `#__finder_links_terms2`;
CREATE TABLE IF NOT EXISTS `#__finder_links_terms2` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__finder_links_terms3`
--

DROP TABLE IF EXISTS `#__finder_links_terms3`;
CREATE TABLE IF NOT EXISTS `#__finder_links_terms3` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__finder_links_terms4`
--

DROP TABLE IF EXISTS `#__finder_links_terms4`;
CREATE TABLE IF NOT EXISTS `#__finder_links_terms4` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__finder_links_terms5`
--

DROP TABLE IF EXISTS `#__finder_links_terms5`;
CREATE TABLE IF NOT EXISTS `#__finder_links_terms5` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__finder_links_terms6`
--

DROP TABLE IF EXISTS `#__finder_links_terms6`;
CREATE TABLE IF NOT EXISTS `#__finder_links_terms6` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__finder_links_terms7`
--

DROP TABLE IF EXISTS `#__finder_links_terms7`;
CREATE TABLE IF NOT EXISTS `#__finder_links_terms7` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__finder_links_terms8`
--

DROP TABLE IF EXISTS `#__finder_links_terms8`;
CREATE TABLE IF NOT EXISTS `#__finder_links_terms8` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__finder_links_terms9`
--

DROP TABLE IF EXISTS `#__finder_links_terms9`;
CREATE TABLE IF NOT EXISTS `#__finder_links_terms9` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__finder_links_termsa`
--

DROP TABLE IF EXISTS `#__finder_links_termsa`;
CREATE TABLE IF NOT EXISTS `#__finder_links_termsa` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__finder_links_termsb`
--

DROP TABLE IF EXISTS `#__finder_links_termsb`;
CREATE TABLE IF NOT EXISTS `#__finder_links_termsb` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__finder_links_termsc`
--

DROP TABLE IF EXISTS `#__finder_links_termsc`;
CREATE TABLE IF NOT EXISTS `#__finder_links_termsc` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__finder_links_termsd`
--

DROP TABLE IF EXISTS `#__finder_links_termsd`;
CREATE TABLE IF NOT EXISTS `#__finder_links_termsd` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__finder_links_termse`
--

DROP TABLE IF EXISTS `#__finder_links_termse`;
CREATE TABLE IF NOT EXISTS `#__finder_links_termse` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__finder_links_termsf`
--

DROP TABLE IF EXISTS `#__finder_links_termsf`;
CREATE TABLE IF NOT EXISTS `#__finder_links_termsf` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__finder_taxonomy`
--

DROP TABLE IF EXISTS `#__finder_taxonomy`;
CREATE TABLE IF NOT EXISTS `#__finder_taxonomy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `state` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `access` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ordering` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `state` (`state`),
  KEY `ordering` (`ordering`),
  KEY `access` (`access`),
  KEY `idx_parent_published` (`parent_id`,`state`,`access`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `#__finder_taxonomy`
--

INSERT INTO `#__finder_taxonomy` (`id`, `parent_id`, `title`, `state`, `access`, `ordering`) VALUES
(1, 0, 'ROOT', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `#__finder_taxonomy_map`
--

DROP TABLE IF EXISTS `#__finder_taxonomy_map`;
CREATE TABLE IF NOT EXISTS `#__finder_taxonomy_map` (
  `link_id` int(10) unsigned NOT NULL,
  `node_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`node_id`),
  KEY `link_id` (`link_id`),
  KEY `node_id` (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__finder_terms`
--

DROP TABLE IF EXISTS `#__finder_terms`;
CREATE TABLE IF NOT EXISTS `#__finder_terms` (
  `term_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` float unsigned NOT NULL DEFAULT '0',
  `soundex` varchar(75) NOT NULL,
  `links` int(10) NOT NULL DEFAULT '0',
  `language` char(3) NOT NULL DEFAULT '',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `idx_term` (`term`),
  KEY `idx_term_phrase` (`term`,`phrase`),
  KEY `idx_stem_phrase` (`stem`,`phrase`),
  KEY `idx_soundex_phrase` (`soundex`,`phrase`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `#__finder_terms_common`
--

DROP TABLE IF EXISTS `#__finder_terms_common`;
CREATE TABLE IF NOT EXISTS `#__finder_terms_common` (
  `term` varchar(75) NOT NULL,
  `language` varchar(3) NOT NULL,
  KEY `idx_word_lang` (`term`,`language`),
  KEY `idx_lang` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `#__finder_terms_common`
--

INSERT INTO `#__finder_terms_common` (`term`, `language`) VALUES
('a', 'en'),
('about', 'en'),
('after', 'en'),
('ago', 'en'),
('all', 'en'),
('am', 'en'),
('an', 'en'),
('and', 'en'),
('ani', 'en'),
('any', 'en'),
('are', 'en'),
('aren''t', 'en'),
('as', 'en'),
('at', 'en'),
('be', 'en'),
('but', 'en'),
('by', 'en'),
('for', 'en'),
('from', 'en'),
('get', 'en'),
('go', 'en'),
('how', 'en'),
('if', 'en'),
('in', 'en'),
('into', 'en'),
('is', 'en'),
('isn''t', 'en'),
('it', 'en'),
('its', 'en'),
('me', 'en'),
('more', 'en'),
('most', 'en'),
('must', 'en'),
('my', 'en'),
('new', 'en'),
('no', 'en'),
('none', 'en'),
('not', 'en'),
('noth', 'en'),
('nothing', 'en'),
('of', 'en'),
('off', 'en'),
('often', 'en'),
('old', 'en'),
('on', 'en'),
('onc', 'en'),
('once', 'en'),
('onli', 'en'),
('only', 'en'),
('or', 'en'),
('other', 'en'),
('our', 'en'),
('ours', 'en'),
('out', 'en'),
('over', 'en'),
('page', 'en'),
('she', 'en'),
('should', 'en'),
('small', 'en'),
('so', 'en'),
('some', 'en'),
('than', 'en'),
('thank', 'en'),
('that', 'en'),
('the', 'en'),
('their', 'en'),
('theirs', 'en'),
('them', 'en'),
('then', 'en'),
('there', 'en'),
('these', 'en'),
('they', 'en'),
('this', 'en'),
('those', 'en'),
('thus', 'en'),
('time', 'en'),
('times', 'en'),
('to', 'en'),
('too', 'en'),
('true', 'en'),
('under', 'en'),
('until', 'en'),
('up', 'en'),
('upon', 'en'),
('use', 'en'),
('user', 'en'),
('users', 'en'),
('veri', 'en'),
('version', 'en'),
('very', 'en'),
('via', 'en'),
('want', 'en'),
('was', 'en'),
('way', 'en'),
('were', 'en'),
('what', 'en'),
('when', 'en'),
('where', 'en'),
('whi', 'en'),
('which', 'en'),
('who', 'en'),
('whom', 'en'),
('whose', 'en'),
('why', 'en'),
('wide', 'en'),
('will', 'en'),
('with', 'en'),
('within', 'en'),
('without', 'en'),
('would', 'en'),
('yes', 'en'),
('yet', 'en'),
('you', 'en'),
('your', 'en'),
('yours', 'en');

-- --------------------------------------------------------

--
-- Table structure for table `#__finder_tokens`
--

DROP TABLE IF EXISTS `#__finder_tokens`;
CREATE TABLE IF NOT EXISTS `#__finder_tokens` (
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` float unsigned NOT NULL DEFAULT '1',
  `context` tinyint(1) unsigned NOT NULL DEFAULT '2',
  `language` char(3) NOT NULL DEFAULT '',
  KEY `idx_word` (`term`),
  KEY `idx_context` (`context`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__finder_tokens_aggregate`
--

DROP TABLE IF EXISTS `#__finder_tokens_aggregate`;
CREATE TABLE IF NOT EXISTS `#__finder_tokens_aggregate` (
  `term_id` int(10) unsigned NOT NULL,
  `map_suffix` char(1) NOT NULL,
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `term_weight` float unsigned NOT NULL,
  `context` tinyint(1) unsigned NOT NULL DEFAULT '2',
  `context_weight` float unsigned NOT NULL,
  `total_weight` float unsigned NOT NULL,
  `language` char(3) NOT NULL DEFAULT '',
  KEY `token` (`term`),
  KEY `keyword_id` (`term_id`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__finder_types`
--

DROP TABLE IF EXISTS `#__finder_types`;
CREATE TABLE IF NOT EXISTS `#__finder_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `mime` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `#__languages`
--

DROP TABLE IF EXISTS `#__languages`;
CREATE TABLE IF NOT EXISTS `#__languages` (
  `lang_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `lang_code` char(7) NOT NULL,
  `title` varchar(50) NOT NULL,
  `title_native` varchar(50) NOT NULL,
  `sef` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `description` varchar(512) NOT NULL,
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `sitename` varchar(1024) NOT NULL DEFAULT '',
  `published` int(11) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lang_id`),
  UNIQUE KEY `idx_sef` (`sef`),
  UNIQUE KEY `idx_image` (`image`),
  UNIQUE KEY `idx_langcode` (`lang_code`),
  KEY `idx_ordering` (`ordering`),
  KEY `idx_access` (`access`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `#__languages`
--

INSERT INTO `#__languages` (`lang_id`, `lang_code`, `title`, `title_native`, `sef`, `image`, `description`, `metakey`, `metadesc`, `sitename`, `published`, `access`, `ordering`) VALUES
(1, 'en-GB', 'English (UK)', 'English (UK)', 'en', 'en', '', '', '', '', 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `#__menu`
--

DROP TABLE IF EXISTS `#__menu`;
CREATE TABLE IF NOT EXISTS `#__menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menutype` varchar(24) NOT NULL COMMENT 'The type of menu this item belongs to. FK to #__menu_types.menutype',
  `title` varchar(255) NOT NULL COMMENT 'The display title of the menu item.',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT 'The SEF alias of the menu item.',
  `note` varchar(255) NOT NULL DEFAULT '',
  `path` varchar(1024) NOT NULL COMMENT 'The computed path of the menu item based on the alias field.',
  `link` varchar(1024) NOT NULL COMMENT 'The actually link the menu item refers to.',
  `type` varchar(16) NOT NULL COMMENT 'The type of link: Component, URL, Alias, Separator',
  `published` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'The published state of the menu link.',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '1' COMMENT 'The parent menu item in the menu tree.',
  `level` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The relative level in the tree.',
  `component_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to #__extensions.id',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to #__users.id',
  `checked_out_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'The time the menu item was checked out.',
  `browserNav` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'The click behaviour of the link.',
  `access` int(10) unsigned DEFAULT NULL,
  `img` varchar(255) NOT NULL COMMENT 'The image of the menu item.',
  `template_style_id` int(10) unsigned NOT NULL DEFAULT '0',
  `params` text NOT NULL COMMENT 'JSON encoded data for the menu item.',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `home` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Indicates if this menu item is the home or default page.',
  `language` char(7) NOT NULL DEFAULT '',
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_client_id_parent_id_alias_language` (`client_id`,`parent_id`,`alias`,`language`),
  KEY `idx_componentid` (`component_id`,`menutype`,`published`,`access`),
  KEY `idx_menutype` (`menutype`),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_alias` (`alias`),
  KEY `idx_path` (`path`(255)),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=267 ;

--
-- Dumping data for table `#__menu`
--

INSERT INTO `#__menu` (`id`, `menutype`, `title`, `alias`, `note`, `path`, `link`, `type`, `published`, `parent_id`, `level`, `component_id`, `checked_out`, `checked_out_time`, `browserNav`, `access`, `img`, `template_style_id`, `params`, `lft`, `rgt`, `home`, `language`, `client_id`) VALUES
(1, '', 'Menu_Item_Root', 'root', '', '', '', '', 1, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, 0, '', 0, '', 0, 281, 0, '*', 0),
(2, 'menu', 'com_banners', 'Banners', '', 'Banners', 'index.php?option=com_banners', 'component', 0, 1, 1, 4, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners', 0, '', 1, 10, 0, '*', 1),
(3, 'menu', 'com_banners', 'Banners', '', 'Banners/Banners', 'index.php?option=com_banners', 'component', 0, 2, 2, 4, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners', 0, '', 2, 3, 0, '*', 1),
(4, 'menu', 'com_banners_categories', 'Categories', '', 'Banners/Categories', 'index.php?option=com_categories&extension=com_banners', 'component', 0, 2, 2, 6, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners-cat', 0, '', 4, 5, 0, '*', 1),
(5, 'menu', 'com_banners_clients', 'Clients', '', 'Banners/Clients', 'index.php?option=com_banners&view=clients', 'component', 0, 2, 2, 4, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners-clients', 0, '', 6, 7, 0, '*', 1),
(6, 'menu', 'com_banners_tracks', 'Tracks', '', 'Banners/Tracks', 'index.php?option=com_banners&view=tracks', 'component', 0, 2, 2, 4, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners-tracks', 0, '', 8, 9, 0, '*', 1),
(7, 'menu', 'com_contact', 'Contacts', '', 'Contacts', 'index.php?option=com_contact', 'component', 0, 1, 1, 8, 0, '0000-00-00 00:00:00', 0, 0, 'class:contact', 0, '', 11, 16, 0, '*', 1),
(8, 'menu', 'com_contact', 'Contacts', '', 'Contacts/Contacts', 'index.php?option=com_contact', 'component', 0, 7, 2, 8, 0, '0000-00-00 00:00:00', 0, 0, 'class:contact', 0, '', 12, 13, 0, '*', 1),
(9, 'menu', 'com_contact_categories', 'Categories', '', 'Contacts/Categories', 'index.php?option=com_categories&extension=com_contact', 'component', 0, 7, 2, 6, 0, '0000-00-00 00:00:00', 0, 0, 'class:contact-cat', 0, '', 14, 15, 0, '*', 1),
(10, 'menu', 'com_messages', 'Messaging', '', 'Messaging', 'index.php?option=com_messages', 'component', 0, 1, 1, 15, 0, '0000-00-00 00:00:00', 0, 0, 'class:messages', 0, '', 17, 22, 0, '*', 1),
(11, 'menu', 'com_messages_add', 'New Private Message', '', 'Messaging/New Private Message', 'index.php?option=com_messages&task=message.add', 'component', 0, 10, 2, 15, 0, '0000-00-00 00:00:00', 0, 0, 'class:messages-add', 0, '', 18, 19, 0, '*', 1),
(12, 'menu', 'com_messages_read', 'Read Private Message', '', 'Messaging/Read Private Message', 'index.php?option=com_messages', 'component', 0, 10, 2, 15, 0, '0000-00-00 00:00:00', 0, 0, 'class:messages-read', 0, '', 20, 21, 0, '*', 1),
(13, 'menu', 'com_newsfeeds', 'News Feeds', '', 'News Feeds', 'index.php?option=com_newsfeeds', 'component', 0, 1, 1, 17, 0, '0000-00-00 00:00:00', 0, 0, 'class:newsfeeds', 0, '', 23, 28, 0, '*', 1),
(14, 'menu', 'com_newsfeeds_feeds', 'Feeds', '', 'News Feeds/Feeds', 'index.php?option=com_newsfeeds', 'component', 0, 13, 2, 17, 0, '0000-00-00 00:00:00', 0, 0, 'class:newsfeeds', 0, '', 24, 25, 0, '*', 1),
(15, 'menu', 'com_newsfeeds_categories', 'Categories', '', 'News Feeds/Categories', 'index.php?option=com_categories&extension=com_newsfeeds', 'component', 0, 13, 2, 6, 0, '0000-00-00 00:00:00', 0, 0, 'class:newsfeeds-cat', 0, '', 26, 27, 0, '*', 1),
(16, 'menu', 'com_redirect', 'Redirect', '', 'Redirect', 'index.php?option=com_redirect', 'component', 0, 1, 1, 24, 0, '0000-00-00 00:00:00', 0, 0, 'class:redirect', 0, '', 37, 38, 0, '*', 1),
(17, 'menu', 'com_search', 'Search', '', 'Search', 'index.php?option=com_search', 'component', 0, 1, 1, 19, 0, '0000-00-00 00:00:00', 0, 0, 'class:search', 0, '', 29, 30, 0, '*', 1),
(18, 'menu', 'com_weblinks', 'Weblinks', '', 'Weblinks', 'index.php?option=com_weblinks', 'component', 0, 1, 1, 21, 0, '0000-00-00 00:00:00', 0, 0, 'class:weblinks', 0, '', 31, 36, 0, '*', 1),
(19, 'menu', 'com_weblinks_links', 'Links', '', 'Weblinks/Links', 'index.php?option=com_weblinks', 'component', 0, 18, 2, 21, 0, '0000-00-00 00:00:00', 0, 0, 'class:weblinks', 0, '', 32, 33, 0, '*', 1),
(20, 'menu', 'com_weblinks_categories', 'Categories', '', 'Weblinks/Categories', 'index.php?option=com_categories&extension=com_weblinks', 'component', 0, 18, 2, 6, 0, '0000-00-00 00:00:00', 0, 0, 'class:weblinks-cat', 0, '', 34, 35, 0, '*', 1),
(21, 'menu', 'com_finder', 'Smart Search', '', 'Smart Search', 'index.php?option=com_finder', 'component', 0, 1, 1, 27, 0, '0000-00-00 00:00:00', 0, 0, 'class:finder', 0, '', 39, 40, 0, '*', 1),
(22, 'menu', 'com_joomlaupdate', 'Joomla! Update', '', 'Joomla! Update', 'index.php?option=com_joomlaupdate', 'component', 0, 1, 1, 28, 0, '0000-00-00 00:00:00', 0, 0, 'class:joomlaupdate', 0, '', 43, 44, 0, '*', 1),
(23, 'main', 'com_tags', 'Tags', '', 'Tags', 'index.php?option=com_tags', 'component', 0, 1, 1, 29, 0, '0000-00-00 00:00:00', 0, 1, 'class:tags', 0, '', 45, 46, 0, '', 1),
(102, 'mainmenu', 'Home', 'home-mainmenu-1', '', 'home-mainmenu-1', 'index.php?option=com_content&view=featured', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"featured_categories":[""],"layout_type":"blog","num_leading_articles":"0","num_intro_articles":"6","num_columns":"1","num_links":"0","multi_column_order":"1","orderby_pri":"","orderby_sec":"rdate","order_date":"","show_pagination":"2","show_pagination_results":"1","show_title":"1","link_titles":"1","show_intro":"","show_category":"0","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"0","link_author":"","show_create_date":"1","show_modify_date":"0","show_publish_date":"0","show_item_navigation":"","show_vote":"","show_readmore":"","show_readmore_title":"0","show_icons":"","show_print_icon":"0","show_email_icon":"0","show_hits":"0","show_noauth":"","show_feed_link":"1","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"Welcome to the Frontpage!","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"Return Home","s5_group_child":"0"}', 111, 112, 1, '*', 0),
(103, 'mainmenu', 'News', 'news-mainmenu-2', '', 'features-mainmenu-47/joomla-stuff-mainmenu-26/news-mainmenu-2', 'index.php?option=com_content&view=category&layout=blog&id=7', 'component', 1, 109, 3, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu_image":"","show_page_title":1,"pageclass_sfx":"","back_button":"","description_sec":1,"description_sec_image":1,"orderby":"","other_cat_show_section":1,"empty_cat_show_section":0,"show_category_description":1,"description_cat_image":1,"show_categories":1,"show_empty_categories":0,"show_cat_num_articles":1,"cat_show_description":1,"date_format":"","show_date":"","show_author":"","show_hits":"","show_headings":1,"show_item_navigation":1,"order_select":1,"show_pagination_limit":1,"display_num":50,"filter":1,"filter_type":"title","unpublished":1,"show_title":1,"show_page_heading":"0"}', 219, 220, 0, '*', 0),
(104, 'mainmenu', 'Search', 'search-mainmenu-5', '', 'features-mainmenu-47/joomla-stuff-mainmenu-26/search-mainmenu-5', 'index.php?option=com_search', 'component', 1, 109, 3, 19, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu_image":"","pageclass_sfx":"","back_button":"","show_page_title":1,"page_title":"","show_title":1,"show_page_heading":"0"}', 217, 218, 0, '*', 0),
(105, 'mainmenu', 'News Feeds', 'news-feeds-mainmenu-7', '', 'features-mainmenu-47/joomla-stuff-mainmenu-26/news-feeds-mainmenu-7', 'index.php?option=com_newsfeeds&view=categories', 'component', 1, 109, 3, 17, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu_image":"","pageclass_sfx":"","back_button":"","show_page_title":1,"page_title":"","other_cat_show_section":1,"show_categories":1,"cat_show_description":1,"show_cat_num_articles":1,"show_description":1,"description_text":"","image":-1,"image_align":"right","show_headings":1,"name":1,"articles":1,"num_links":0,"feed_image":1,"feed_descr":1,"item_descr":1,"word_count":0,"show_title":1,"show_page_heading":"0"}', 221, 222, 0, '*', 0),
(106, 'mainmenu', 'Wrapper', 'wrapper-mainmenu-8', '', 'features-mainmenu-47/joomla-stuff-mainmenu-26/wrapper-mainmenu-8', 'index.php?option=com_wrapper&view=wrapper', 'component', 1, 109, 3, 2, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"url":"http:\\/\\/getfirebug.com\\/","scrolling":"auto","width":"100%","height":"600","height_auto":"0","add_scheme":"1","frameborder":"1","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"","s5_group_child":"0"}', 229, 230, 0, '*', 0),
(107, 'mainmenu', 'Blog', 'blog-mainmenu-9', '', 'features-mainmenu-47/joomla-stuff-mainmenu-26/links-mainmenu-23/blog-mainmenu-9', 'index.php?option=com_content&view=category&layout=blog&id=2', 'component', 0, 108, 4, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu_image":"","pageclass_sfx":"","back_button":"","page_title":"A blog of all sections with no images","show_page_title":1,"num_leading_articles":0,"num_intro_articles":6,"num_columns":2,"num_links":4,"orderby_pri":"","orderby_sec":"","show_pagination":2,"show_pagination_results":1,"image":0,"show_description":0,"show_description_image":0,"show_category":0,"category_num_links":0,"show_title":1,"link_titles":"","show_readmore":"","show_vote":"","show_author":"","show_create_show_date":"","show_modify_show_date":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","unpublished":0,"sectionid":0,"show_page_heading":"0"}', 224, 225, 0, '*', 0),
(108, 'mainmenu', 'Links', 'links-mainmenu-23', '', 'features-mainmenu-47/joomla-stuff-mainmenu-26/links-mainmenu-23', 'index.php?option=com_weblinks&view=categories', 'component', 1, 109, 3, 21, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu_image":"","pageclass_sfx":"","back_button":"","show_page_title":1,"page_title":"","show_headings":1,"show_hits":"","item_show_description":1,"other_cat_show_section":1,"show_categories":1,"show_description":1,"description_text":"","image":-1,"image_align":"right","weblink_icons":"","show_title":1,"show_page_heading":"0"}', 223, 226, 0, '*', 0),
(109, 'mainmenu', 'J! Stuff', 'joomla-stuff-mainmenu-26', '', 'features-mainmenu-47/joomla-stuff-mainmenu-26', 'javascript:;', 'url', 1, 119, 2, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"images\\/stories\\/joomla.png","menu_text":1,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"Default Joomla Items","s5_group_child":"0"}', 216, 231, 0, '*', 0),
(110, 'mainmenu', 'Typography', 'typography-mainmenu-27', '', 'features-mainmenu-47/style-and-layout-options/typography-mainmenu-27', 'index.php?option=com_content&view=article&id=12', 'component', 1, 178, 3, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":1,"link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 245, 246, 0, '*', 0),
(111, 'mainmenu', 'S5 Flex Menu', 's5-flex-menu-1360', '', 'extensions/s5-flex-menu-1360', 'index.php?option=com_content&view=article&id=13', 'component', 1, 134, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"1","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0,"s5_load_mod":"0","s5_columns":"2","s5_subtext":"Advanced Menu System","s5_group_child":"0"}', 138, 171, 0, '*', 0),
(112, 'mainmenu', 'Drop Down Menu', 'sample-menu', '', 'extensions/s5-flex-menu-1360/sample-menu', 'javascript:;', 'url', 1, 111, 3, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"images\\/stories\\/application_put.png","menu_text":1,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"Unlimited Level Options","s5_group_child":"0"}', 139, 152, 0, '*', 0),
(113, 'mainmenu', 'Dummy Item', 'dummy-item-mainmenu-33', '', 'extensions/s5-flex-menu-1360/sample-menu/dummy-item-mainmenu-33', 'javascript:;', 'url', 1, 112, 4, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu_image":"","show_title":1,"show_page_title":1,"show_page_heading":"0"}', 140, 141, 0, '*', 0),
(114, 'mainmenu', 'Dummy Item', 'dummy-item-mainmenu-34', '', 'extensions/s5-flex-menu-1360/sample-menu/dummy-item-mainmenu-34', 'javascript:;', 'url', 1, 112, 4, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu_image":"","show_title":1,"show_page_title":1,"show_page_heading":"0"}', 142, 143, 0, '*', 0),
(115, 'mainmenu', 'Dummy Item', 'dummy-item-mainmenu-35', '', 'extensions/s5-flex-menu-1360/sample-menu/dummy-item-mainmenu-35', 'javascript:;', 'url', 1, 112, 4, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu_image":"","show_title":1,"show_page_title":1,"show_page_heading":"0"}', 144, 151, 0, '*', 0),
(116, 'mainmenu', 'Dummy Item', 'dummy-item-mainmenu-36', '', 'extensions/s5-flex-menu-1360/sample-menu/dummy-item-mainmenu-35/dummy-item-mainmenu-36', 'javascript:;', 'url', 1, 115, 5, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu_image":"","show_title":1,"show_page_title":1,"show_page_heading":"0"}', 145, 146, 0, '*', 0),
(117, 'mainmenu', 'Dummy Item', 'dummy-item-mainmenu-37', '', 'extensions/s5-flex-menu-1360/sample-menu/dummy-item-mainmenu-35/dummy-item-mainmenu-37', 'javascript:;', 'url', 1, 115, 5, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu_image":"","show_title":1,"show_page_title":1,"show_page_heading":"0"}', 147, 148, 0, '*', 0),
(118, 'mainmenu', 'Dummy Item', 'dummy-item-mainmenu-38', '', 'extensions/s5-flex-menu-1360/sample-menu/dummy-item-mainmenu-35/dummy-item-mainmenu-38', 'javascript:;', 'url', 1, 115, 5, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu_image":"","show_title":1,"show_page_title":1,"show_page_heading":"0"}', 149, 150, 0, '*', 0),
(119, 'mainmenu', 'Features', 'features-mainmenu-47', '', 'features-mainmenu-47', 'javascript:;', 'url', 1, 1, 1, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"s5_load_mod":"0","s5_columns":"2","s5_subtext":"What''s Included","s5_group_child":"0"}', 185, 262, 0, '*', 0),
(120, 'mainmenu', 'Tutorials', 'tutorials-mainmenu-48', '', 'tutorials-mainmenu-48', 'javascript:;', 'url', 1, 1, 1, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"s5_load_mod":0,"s5_columns":1,"s5_subtext":"Find Help Here","s5_group_child":0,"menu_image":"","show_page_heading":"0"}', 263, 278, 0, '*', 0),
(121, 'mainmenu', '98 Module Positions', '98-module-positions', '', 'features-mainmenu-47/template-features/98-module-positions', 'index.php?option=com_content&view=article&id=14', 'component', 1, 135, 3, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"1","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"Thousands of Layout Options","s5_group_child":"0"}', 197, 198, 0, '*', 0),
(122, 'mainmenu', 'Contact Us', 'contact-us', '', 'features-mainmenu-47/joomla-stuff-mainmenu-26/contact-us', 'index.php?option=com_contact&view=contact&id=2', 'component', 1, 109, 3, 8, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"presentation_style":"plain","show_contact_category":"","show_contact_list":"0","show_name":"","show_position":"","show_email":"","show_street_address":"","show_suburb":"","show_state":"","show_postcode":"","show_country":"","show_telephone":"","show_mobile":"","show_fax":"","show_webpage":"","show_misc":"","show_image":"","allow_vcard":"","show_articles":"","show_links":"","linka_name":"","linkb_name":"","linkc_name":"","linkd_name":"","linke_name":"","show_email_form":"","show_email_copy":"","banned_email":"","banned_subject":"","banned_text":"","validate_session":"","custom_reply":"","redirect":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"","s5_group_child":"0"}', 227, 228, 0, '*', 0),
(123, 'mainmenu', 'Site Shaper Available', 'site-shaper-available', '', 'features-mainmenu-47/style-and-layout-options/site-shaper-available', 'index.php?option=com_content&view=article&id=39', 'component', 1, 178, 3, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"s5_load_mod":0,"s5_columns":1,"s5_subtext":"","s5_group_child":0,"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 239, 240, 0, '*', 0),
(124, 'mainmenu', 'Site Shaper Setup', 'site-shaper-setup', '', 'tutorials-mainmenu-48/site-shaper-setup', 'index.php?option=com_content&view=article&id=39', 'component', 1, 120, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"s5_load_mod":0,"s5_columns":1,"s5_subtext":"Site Shapers Are Highly Recommended","s5_group_child":0,"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 266, 267, 0, '*', 0),
(125, 'mainmenu', 'Setting Up Module Styles', 'setting-up-module-styles', '', 'tutorials-mainmenu-48/setting-up-module-styles', 'index.php?option=com_content&view=article&id=14', 'component', 1, 120, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 15, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 270, 271, 0, '*', 0),
(126, 'mainmenu', 'Fluid and Fixed Layouts', 'fluid-and-fixed-layouts', '', 'features-mainmenu-47/style-and-layout-options/fluid-and-fixed-layouts', 'index.php?option=com_content&view=article&id=24', 'component', 1, 178, 3, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 249, 250, 0, '*', 0),
(127, 'mainmenu', 'Tool Tips Enabled', 'tool-tips-enabled', '', 'features-mainmenu-47/template-features/tool-tips-enabled', 'index.php?option=com_content&view=article&id=37', 'component', 1, 135, 3, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 203, 204, 0, '*', 0),
(129, 'mainmenu', 'Installing The Template', 'installing-the-template', '', 'tutorials-mainmenu-48/installing-the-template', 'index.php?option=com_content&view=article&id=17', 'component', 1, 120, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 268, 269, 0, '*', 0),
(130, 'mainmenu', 'Configuring The Template', 'configuring-the-template', '', 'tutorials-mainmenu-48/configuring-the-template', 'index.php?option=com_content&view=article&id=18', 'component', 1, 120, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 272, 273, 0, '*', 0),
(131, 'mainmenu', 'Search and Menus Setup', 'search-and-menus-setup', '', 'tutorials-mainmenu-48/search-and-menus-setup', 'index.php?option=com_content&view=article&id=36', 'component', 1, 120, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 274, 275, 0, '*', 0),
(134, 'mainmenu', 'Extensions', 'extensions', '', 'extensions', 'javascript:;', 'url', 1, 1, 1, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"s5_load_mod":0,"s5_columns":2,"s5_subtext":"Tools and Modules","s5_group_child":0,"menu_image":"","show_page_heading":"0"}', 127, 172, 0, '*', 0),
(135, 'mainmenu', 'Vertex Template Features', 'template-features', '', 'features-mainmenu-47/template-features', 'javascript:;', 'url', 1, 119, 2, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"images\\/stories\\/application_split.png","menu_text":1,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"Powerful Template Settings","s5_group_child":"1"}', 190, 215, 0, '*', 0),
(136, 'mainmenu', 'LTR Language', 'ltr-language', '', 'features-mainmenu-47/style-and-layout-options/ltr-language', '?lang=ltr', 'url', 1, 178, 3, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"","s5_group_child":"0"}', 257, 258, 0, '*', 0),
(137, 'mainmenu', 'RTL Language', 'rtl-language', '', 'features-mainmenu-47/style-and-layout-options/rtl-language', '?lang=rtl', 'url', 1, 178, 3, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"","s5_group_child":"0"}', 259, 260, 0, '*', 0),
(138, 'mainmenu', 'SEO Optimized', 'seo-optimized', '', 'features-mainmenu-47/template-features/seo-optimized', 'index.php?option=com_content&view=article&id=173', 'component', 1, 135, 3, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 199, 200, 0, '*', 0),
(139, 'second-menu', 'About us', 'about-us', '', 'about-us', 'index.php?option=com_content&view=article&id=208', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 85, 86, 0, '*', 0),
(140, 'second-menu', 'FAQs', 'faqs', '', 'faqs', 'index.php?option=com_content&view=article&id=208', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 87, 88, 0, '*', 0),
(141, 'second-menu', 'News', 'news', '', 'news', 'index.php?option=com_content&view=article&id=208', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 99, 100, 0, '*', 0),
(142, 'second-menu', 'Blog', 'blog', '', 'blog', 'index.php?option=com_content&view=article&id=208', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 107, 108, 0, '*', 0),
(143, 'mainmenu', 'Multibox Enabled', 'multibox-enabled', '', 'features-mainmenu-47/template-features/multibox-enabled', 'index.php?option=com_content&view=article&id=195', 'component', 1, 135, 3, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 205, 206, 0, '*', 0),
(145, 'mainmenu', 'Template Specific Features', 'template-specific-features', '', 'features-mainmenu-47/template-specific-features', 'index.php?option=com_content&view=article&id=197', 'component', 1, 119, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"images\\/stories\\/color_wheel.png","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"Options Specific To This Template","s5_group_child":"0"}', 188, 189, 0, '*', 0),
(146, 'mainmenu', 'Google Fonts Enabled', 'google-fonts-enabled', '', 'features-mainmenu-47/style-and-layout-options/google-fonts-enabled', 'index.php?option=com_content&view=article&id=204', 'component', 1, 178, 3, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"s5_load_mod":0,"s5_columns":1,"s5_subtext":"","s5_group_child":0,"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 241, 242, 0, '*', 0),
(149, 'mainmenu', 'Page, Row and Column Widths', 'page-row-and-column-widths', '', 'features-mainmenu-47/style-and-layout-options/page-row-and-column-widths', 'index.php?option=com_content&view=article&id=24', 'component', 1, 178, 3, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 243, 244, 0, '*', 0),
(150, 'mainmenu', 'Mobile Device Ready', 'mobile-device-ready', '', 'features-mainmenu-47/template-features/mobile-device-ready', 'index.php?option=com_content&view=article&id=287', 'component', 1, 135, 3, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"","s5_group_child":"0"}', 201, 202, 0, '*', 0),
(151, 'second-menu', 'Home', 'home', '', '', 'index.php?Itemid=', 'alias', 1, 0, 1, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu_item":1,"aliasoptions":1,"show_page_heading":"0"}', 0, 0, 0, '*', 0),
(152, 'mainmenu', 'CSS Tableless Overrides', 'css-tableless-overrides', '', 'features-mainmenu-47/style-and-layout-options/css-tableless-overrides', 'index.php?option=com_content&view=article&id=212', 'component', 1, 178, 3, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 247, 248, 0, '*', 0),
(153, 'mainmenu', 'S5 Box', 's5-box', '', 'extensions/s5-box', 'index.php?option=com_content&view=article&id=146', 'component', 1, 134, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"s5_load_mod":0,"s5_columns":1,"s5_subtext":"Popup Box for Login","s5_group_child":0,"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 132, 133, 0, '*', 0),
(154, 'mainmenu', 'S5 Login and Register Setup', 's5-login-and-register-setup', '', 'tutorials-mainmenu-48/s5-login-and-register-setup', 'index.php?option=com_content&view=article&id=146', 'component', 1, 120, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 276, 277, 0, '*', 0),
(155, 'mainmenu', 'S5 Accordion Menu', 's5-accordion-menu', '', 'extensions/s5-accordion-menu', 'index.php?option=com_content&view=article&id=143', 'component', 1, 134, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"s5_load_mod":0,"s5_columns":1,"s5_subtext":"Accordion Column Menu","s5_group_child":0,"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 130, 131, 0, '*', 0),
(156, 'second-menu', 'Site Map', 'site-map', '', 'site-map', 'index.php?option=com_content&view=article&id=208', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 121, 122, 0, '*', 0),
(157, 'second-menu', 'Site Terms', 'site-terms', '', 'site-terms', 'index.php?option=com_content&view=article&id=208', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 179, 180, 0, '*', 0),
(158, 'Bottom-Menu-1', 'Our Latest Updates', 'updates-25678', '', 'updates-25678', 'index.php?option=com_content&view=article&id=208', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"s5_load_mod":0,"s5_columns":1,"s5_subtext":"","s5_group_child":0,"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 77, 78, 0, '*', 0),
(159, 'Bottom-Menu-1', 'The Newest Gallery', 'addons-10607', '', 'addons-10607', 'index.php?option=com_content&view=article&id=208', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"s5_load_mod":0,"s5_columns":1,"s5_subtext":"","s5_group_child":0,"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 93, 94, 0, '*', 0),
(160, 'Bottom-Menu-1', 'Knowledge Base', 'knowledge-base', '', 'knowledge-base', 'index.php?option=com_content&view=article&id=208', 'component', 0, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 109, 110, 0, '*', 0),
(161, 'Bottom-Menu-1', 'Simply Great Designs', 'designs-9852', '', 'designs-9852', 'index.php?option=com_content&view=article&id=208', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"s5_load_mod":0,"s5_columns":1,"s5_subtext":"","s5_group_child":0,"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 173, 174, 0, '*', 0),
(162, 'Bottom-Menu-2', 'Careers', 'careers-23301', '', 'careers-23301', 'index.php?option=com_content&view=article&id=208', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 279, 280, 0, '*', 0),
(163, 'Bottom-Menu-2', 'Our Forum', 'our-forum-30554', '', 'our-forum-30554', 'index.php?option=com_content&view=article&id=208', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 89, 90, 0, '*', 0),
(164, 'Bottom-Menu-2', 'Listings', 'listings-28043', '', 'listings-28043', 'index.php?option=com_content&view=article&id=208', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 101, 102, 0, '*', 0),
(165, 'Bottom-Menu-2', 'Community', 'community', '', 'community', 'index.php?option=com_content&view=article&id=208', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 119, 120, 0, '*', 0),
(166, 'Bottom-Menu-1', 'Learn More About Us', 'learn-more-11880', '', 'learn-more-11880', 'index.php?option=com_content&view=article&id=208', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"s5_load_mod":0,"s5_columns":1,"s5_subtext":"","s5_group_child":0,"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 125, 126, 0, '*', 0),
(167, 'Bottom-Menu-2', 'Learn How', 'learn-how-8833', '', 'learn-how-8833', 'index.php?option=com_content&view=article&id=208', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 177, 178, 0, '*', 0),
(168, 'Bottom-Menu-1', 'Mobile', 'mobile', '', 'mobile', 'index.php?option=com_content&view=article&id=208', 'component', 0, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"s5_load_mod":0,"s5_columns":1,"s5_subtext":"","s5_group_child":0,"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 81, 82, 0, '*', 0),
(169, 'Bottom-Menu-4', 'Affiliates', 'affiliates', '', 'affiliates', 'index.php?option=com_content&view=article&id=208', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"s5_load_mod":0,"s5_columns":1,"s5_subtext":"","s5_group_child":0,"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 75, 76, 0, '*', 0),
(170, 'Bottom-Menu-1', 'Specials', 'specials', '', 'specials', 'index.php?option=com_content&view=article&id=208', 'component', 0, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"s5_load_mod":0,"s5_columns":1,"s5_subtext":"","s5_group_child":0,"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 97, 98, 0, '*', 0),
(171, 'Bottom-Menu-4', 'Supplies', 'supplies', '', 'supplies', 'index.php?option=com_content&view=article&id=208', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"s5_load_mod":0,"s5_columns":1,"s5_subtext":"","s5_group_child":0,"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 95, 96, 0, '*', 0),
(172, 'Bottom-Menu-2', 'Where To', 'where-to', '', 'where-to', 'index.php?option=com_content&view=article&id=208', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"s5_load_mod":0,"s5_columns":1,"s5_subtext":"","s5_group_child":0,"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 83, 84, 0, '*', 0),
(173, 'Bottom-Menu-4', 'Careers', 'careers', '', 'careers', 'index.php?option=com_content&view=article&id=208', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 91, 92, 0, '*', 0),
(174, 'Bottom-Menu-4', 'Our Forum', 'our-forum', '', 'our-forum', 'index.php?option=com_content&view=article&id=208', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 123, 124, 0, '*', 0);
INSERT INTO `#__menu` (`id`, `menutype`, `title`, `alias`, `note`, `path`, `link`, `type`, `published`, `parent_id`, `level`, `component_id`, `checked_out`, `checked_out_time`, `browserNav`, `access`, `img`, `template_style_id`, `params`, `lft`, `rgt`, `home`, `language`, `client_id`) VALUES
(175, 'Bottom-Menu-4', 'Listings', 'listings', '', 'listings', 'index.php?option=com_content&view=article&id=208', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 79, 80, 0, '*', 0),
(176, 'Bottom-Menu-4', 'Designs', 'designs', '', 'designs', 'index.php?option=com_content&view=article&id=208', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 103, 104, 0, '*', 0),
(177, 'Bottom-Menu-2', 'Learn How', 'learn-how', '', 'learn-how', 'index.php?option=com_content&view=article&id=208', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"s5_load_mod":0,"s5_columns":1,"s5_subtext":"","s5_group_child":0,"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 105, 106, 0, '*', 0),
(178, 'mainmenu', 'Continued Vertex Features', 'style-and-layout-options', '', 'features-mainmenu-47/style-and-layout-options', '', 'separator', 1, 119, 2, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu_image":"images\\/stories\\/application_view_tile.png","menu_text":1,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"More Great S5 Vertex Options","s5_group_child":"1"}', 234, 261, 0, '*', 0),
(179, 'mainmenu', 'Fixed Side Tabs', 'fixed-side-tabs', '', 'features-mainmenu-47/style-and-layout-options/fixed-side-tabs', 'index.php?option=com_content&view=article&id=214', 'component', 1, 178, 3, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 251, 252, 0, '*', 0),
(180, 'second-menu', 'Learn More', 'learn-more', '', 'learn-more', 'index.php?option=com_content&view=article&id=208', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 181, 182, 0, '*', 0),
(181, 'second-menu', 'Updates', 'updates', '', 'updates', 'index.php?option=com_content&view=article&id=208', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 183, 184, 0, '*', 0),
(182, 'mainmenu', 'S5 Flex Menu', 's5-flex-menu', '', 'extensions/s5-flex-menu', 'index.php?option=com_content&view=article&id=13', 'component', 0, 134, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"Advanced Menu System","s5_group_child":"0"}', 128, 129, 0, '*', 0),
(183, 'mainmenu', 'Grouped Child Menu', 'sample-grouped-child-menu', '', 'extensions/s5-flex-menu-1360/sample-grouped-child-menu', '', 'separator', 1, 111, 3, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu_image":"images\\/stories\\/application_side_boxes.png","menu_text":1,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"Group Children Together","s5_group_child":"1"}', 155, 168, 0, '*', 0),
(184, 'mainmenu', 'Dummy Sample Link 1', 'dummy-link-1', '', 'extensions/s5-flex-menu-1360/sample-grouped-child-menu/dummy-link-1', '', 'separator', 1, 183, 4, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"s5_load_mod":0,"s5_columns":1,"s5_subtext":"","s5_group_child":0,"menu_image":"","show_page_heading":"0"}', 158, 159, 0, '*', 0),
(185, 'mainmenu', 'Dummy Sample Link 2', 'dummy-link-2', '', 'extensions/s5-flex-menu-1360/sample-grouped-child-menu/dummy-link-2', '', 'separator', 1, 183, 4, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"s5_load_mod":0,"s5_columns":1,"s5_subtext":"","s5_group_child":0,"menu_image":"","show_page_heading":"0"}', 156, 157, 0, '*', 0),
(186, 'mainmenu', 'Dummy Sample Link 3', 'dummy-link-3', '', 'extensions/s5-flex-menu-1360/sample-grouped-child-menu/dummy-link-3', '', 'separator', 1, 183, 4, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"s5_load_mod":0,"s5_columns":1,"s5_subtext":"","s5_group_child":0,"menu_image":"","show_page_heading":"0"}', 160, 161, 0, '*', 0),
(187, 'mainmenu', 'Dummy Sample Link 4', 'dummy-link-4', '', 'extensions/s5-flex-menu-1360/sample-grouped-child-menu/dummy-link-4', '', 'separator', 1, 183, 4, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"s5_load_mod":0,"s5_columns":1,"s5_subtext":"","s5_group_child":0,"menu_image":"","show_page_heading":"0"}', 162, 163, 0, '*', 0),
(188, 'mainmenu', 'Dummy Sample Link 5', 'dummy-link-5', '', 'extensions/s5-flex-menu-1360/sample-grouped-child-menu/dummy-link-5', '', 'separator', 1, 183, 4, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"s5_load_mod":0,"s5_columns":1,"s5_subtext":"","s5_group_child":0,"menu_image":"","show_page_heading":"0"}', 164, 165, 0, '*', 0),
(189, 'mainmenu', 'Dummy Sample Link 6', 'dummy-link-6', '', 'extensions/s5-flex-menu-1360/sample-grouped-child-menu/dummy-link-6', '', 'separator', 1, 183, 4, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"s5_load_mod":0,"s5_columns":1,"s5_subtext":"","s5_group_child":0,"menu_image":"","show_page_heading":"0"}', 166, 167, 0, '*', 0),
(190, 'mainmenu', 'Menu Module Example', 'menu-module-example', '', 'extensions/s5-flex-menu-1360/menu-module-example', '', 'separator', 1, 111, 3, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu_image":"images\\/stories\\/cog_edit.png","menu_text":1,"s5_load_mod":"1","s5_position":"s5_menu1","s5_columns":"1","s5_subtext":"Publish Any Module to Any Menu","s5_group_child":"1"}', 153, 154, 0, '*', 0),
(191, 'mainmenu', 'Menu With No Menu Icon', 'item-with-menu-icon', '', 'extensions/s5-flex-menu-1360/item-with-menu-icon', '', 'separator', 1, 111, 3, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"s5_load_mod":0,"s5_columns":1,"s5_subtext":"Standard Sub Menu Link","s5_group_child":0,"menu_image":"","show_page_heading":"0"}', 169, 170, 0, '*', 0),
(192, 'mainmenu', 'Menu Scroll To', 'menu-scroll-to', '', 'features-mainmenu-47/template-features/menu-scroll-to', 'index.php?option=com_content&view=article&id=227', 'component', 1, 135, 3, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"s5_load_mod":0,"s5_columns":1,"s5_subtext":"","show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 209, 210, 0, '*', 0),
(193, 'mainmenu', 'IE7 and 8 CSS3 Support', 'ie7-and-8-css3-support', '', 'features-mainmenu-47/style-and-layout-options/ie7-and-8-css3-support', 'index.php?option=com_content&view=article&id=228', 'component', 1, 178, 3, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"s5_load_mod":0,"s5_columns":1,"s5_subtext":"","s5_group_child":0,"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 253, 254, 0, '*', 0),
(195, 'mainmenu', 'S5 Vertex Framework', 'shape-5-vertex-framework', '', 'features-mainmenu-47/shape-5-vertex-framework', 'http://www.shape5.com/joomla/framework/vertex_framework.html', 'url', 1, 119, 2, 0, 0, '0000-00-00 00:00:00', 1, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"images\\/stories\\/application_link.png","menu_text":1,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"Lear More About Vertex","s5_group_child":"0"}', 186, 187, 0, '*', 0),
(196, 'Bottom-Menu-4', 'Addons', 'addons', '', 'addons', 'index.php?option=com_content&view=article&id=208', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 175, 176, 0, '*', 0),
(197, 'mainmenu', 'Hide Article Component Area', 'hide-article-component-area', '', 'features-mainmenu-47/template-features/hide-article-component-area', 'index.php?option=com_content&view=article&id=231', 'component', 1, 135, 3, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"s5_load_mod":0,"s5_columns":1,"s5_subtext":"","s5_group_child":0,"show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 211, 212, 0, '*', 0),
(198, 'mainmenu', 'Lazy Load Enabled', 'lazy-load-enabled', '', 'features-mainmenu-47/template-features/lazy-load-enabled', 'index.php?option=com_content&view=article&id=230', 'component', 1, 135, 3, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"s5_load_mod":0,"s5_columns":1,"s5_subtext":"","show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 207, 208, 0, '*', 0),
(200, 'mainmenu', 'Drop Down Panel', 'drop-down-panel', '', 'features-mainmenu-47/template-features/drop-down-panel', 'index.php?option=com_content&view=article&id=233', 'component', 1, 135, 3, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"s5_load_mod":0,"s5_columns":1,"s5_subtext":"","show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 213, 214, 0, '*', 0),
(202, 'mainmenu', 'S5 Tab Show', 's5-tab-show', '', 'extensions/s5-tab-show', 'index.php?option=com_content&view=article&id=110', 'component', 1, 134, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"Organize Your Site''s Content","s5_group_child":"0"}', 134, 135, 0, '*', 0),
(203, 'mainmenu', 'Joomla and Vertex Tutorials', 'joomla-tutorials-12070', '', 'features-mainmenu-47/joomla-tutorials-12070', 'http://www.shape5.com/joomla_tutorials.html', 'url', 1, 119, 2, 0, 0, '0000-00-00 00:00:00', 1, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"images\\/stories\\/help.png","menu_text":1,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"Download Vertex and Joomla Tutorials","s5_group_child":"0"}', 232, 233, 0, '*', 0),
(204, 'mainmenu', 'Joomla and Vertex Tutorials', 'joomla-tutorials', '', 'tutorials-mainmenu-48/joomla-tutorials', 'http://www.shape5.com/joomla_tutorials.html', 'url', 1, 120, 2, 0, 0, '0000-00-00 00:00:00', 1, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"images\\/stories\\/help.png","menu_text":1,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"Download Vertex and Joomla Tutorials","s5_group_child":"0"}', 264, 265, 0, '*', 0),
(205, 'mainmenu', '3rd Party Component Compatible', '3rd-party-component-compatible', '', 'features-mainmenu-47/style-and-layout-options/3rd-party-component-compatible', 'index.php?option=com_content&view=article&id=255', 'component', 1, 178, 3, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"s5_load_mod":0,"s5_columns":1,"s5_subtext":"","show_noauth":"","show_title":"","link_titles":"","show_intro":"","show_section":"","link_section":"","show_category":"","link_category":"","show_author":"","show_create_date":"","show_modify_date":"","show_item_navigation":"","show_readmore":"","show_vote":"","show_icons":"","show_pdf_icon":"","show_print_icon":"","show_email_icon":"","show_hits":"","feed_summary":"","page_title":"","show_page_title":1,"pageclass_sfx":"","menu_image":"","secure":0,"show_page_heading":"0"}', 255, 256, 0, '*', 0),
(206, 'mainmenu', 'S5 Image and Content Fader', 's5-image-and-content-fader', '', 'extensions/s5-image-and-content-fader', 'index.php?option=com_content&view=article&id=256', 'component', 1, 134, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"Image Rotating Extension","s5_group_child":"0"}', 136, 137, 0, '*', 0),
(208, 'top-bottom-menu', 'Home', '2012-02-13-19-31-19', '', '2012-02-13-19-31-19', 'index.php?Itemid=', 'alias', 1, 1, 1, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"aliasoptions":"102","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"","s5_group_child":"0"}', 41, 42, 0, '*', 0),
(209, 'top-bottom-menu', 'About Us', 'about', '', 'about', 'index.php?option=com_content&view=article&id=276', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"","s5_group_child":"0"}', 45, 46, 0, '*', 0),
(210, 'top-bottom-menu', 'FAQs', 'faq', '', 'faq', 'index.php?option=com_content&view=article&id=276', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"","s5_group_child":"0"}', 47, 48, 0, '*', 0),
(211, 'top-bottom-menu', 'News', 'new', '', 'new', 'index.php?option=com_content&view=article&id=276', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"","s5_group_child":"0"}', 49, 50, 0, '*', 0),
(212, 'top-bottom-menu', 'Blog', 'blogs', '', 'blogs', 'index.php?option=com_content&view=article&id=276', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"","s5_group_child":"0"}', 51, 52, 0, '*', 0),
(213, 'top-bottom-menu', 'Lookup', 'lookup', '', 'lookup', 'index.php?option=com_content&view=article&id=277', 'component', 0, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"","s5_group_child":"0"}', 53, 54, 0, '*', 0),
(214, 'top-bottom-menu', 'Site Terms', 'terms', '', 'terms', 'index.php?option=com_content&view=article&id=208', 'component', 0, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"","s5_group_child":"0"}', 55, 56, 0, '*', 0),
(215, 'top-bottom-menu', 'Directions', 'directions', '', 'directions', 'index.php?option=com_content&view=article&id=208', 'component', 0, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"","s5_group_child":"0"}', 57, 58, 0, '*', 0),
(216, 'top-bottom-menu', 'Updates', 'update', '', 'update', 'index.php?option=com_content&view=article&id=208', 'component', 0, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"","s5_group_child":"0"}', 59, 60, 0, '*', 0),
(223, 'mainmenu', 'Responsive', '2012-08-14-15-04-20', '', '2012-08-14-15-04-20', 'index.php?Itemid=', 'alias', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"aliasoptions":"248","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"s5_load_mod":"0","s5_position":"s5_menu2","s5_columns":"1","s5_subtext":"Responsive Layout","s5_group_child":"0"}', 113, 118, 0, '*', 0),
(247, 'mainmenu', 'Hide Content and Modules', 'hide-content-and-modules', '', 'features-mainmenu-47/template-features/hide-content-and-modules', 'index.php?option=com_content&view=article&id=289', 'component', 1, 135, 3, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"","s5_group_child":"0"}', 193, 194, 0, '*', 0),
(248, 'mainmenu', 'Responsive Layout', 'responsive-layout', '', 'features-mainmenu-47/template-features/responsive-layout', 'index.php?option=com_content&view=article&id=287', 'component', 1, 135, 3, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"Adapt to Any Screen Size","s5_group_child":"1"}', 191, 192, 0, '*', 0),
(249, 'mainmenu', 'Info Slide Enabled', 'info-slide-enabled', '', 'features-mainmenu-47/template-features/info-slide-enabled', 'index.php?option=com_content&view=article&id=288', 'component', 1, 135, 3, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"","s5_group_child":"0"}', 195, 196, 0, '*', 0),
(250, 'mainmenu', 'File Compression', 'file-compression', '', 'features-mainmenu-47/style-and-layout-options/file-compression', 'index.php?option=com_content&view=article&id=290', 'component', 1, 178, 3, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"","s5_group_child":"0"}', 235, 236, 0, '*', 0),
(251, 'mainmenu', 'Fixed Width', '2012-06-11-23-22-43', '', '2012-08-14-15-04-20/2012-06-11-23-22-43', '?body_width=960&fixed_fluid=px', 'url', -2, 223, 2, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"View a Fixed Width Demo With Responsive","s5_group_child":"0"}', 114, 115, 0, '*', 0),
(252, 'mainmenu', 'Fluid Width', '2012-06-11-23-23-29', '', '2012-08-14-15-04-20/2012-06-11-23-23-29', '?body_width=94&fixed_fluid=%', 'url', -2, 223, 2, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"View a Fluid Width Demo With Responsive","s5_group_child":"0"}', 116, 117, 0, '*', 0),
(253, 'mainmenu', 'Stock Photography', 'stock-photography', '', 'features-mainmenu-47/style-and-layout-options/stock-photography', 'index.php?option=com_content&view=article&id=291', 'component', 1, 178, 3, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"","s5_group_child":"0"}', 237, 238, 0, '*', 0),
(260, 'top-bottom-menu', 'Sample', 'sample', '', 'sample', 'index.php?option=com_content&view=article&id=276', 'component', -2, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"","s5_group_child":"0"}', 61, 62, 0, '*', 0),
(261, 'top-menu', 'Home', '2012-10-12-14-57-11', '', '2012-10-12-14-57-11', 'index.php?Itemid=', 'alias', 1, 1, 1, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"aliasoptions":"208","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"","s5_group_child":"0"}', 63, 64, 0, '*', 0),
(262, 'top-menu', 'About Us', '2012-10-12-14-58-02', '', '2012-10-12-14-58-02', 'index.php?Itemid=', 'alias', 1, 1, 1, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"aliasoptions":"209","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"","s5_group_child":"0"}', 65, 66, 0, '*', 0),
(263, 'top-menu', 'FAQs', '2012-10-12-14-58-18', '', '2012-10-12-14-58-18', 'index.php?Itemid=', 'alias', 1, 1, 1, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"aliasoptions":"210","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"","s5_group_child":"0"}', 67, 68, 0, '*', 0),
(264, 'top-menu', 'News', '2012-10-12-14-58-45', '', '2012-10-12-14-58-45', 'index.php?Itemid=', 'alias', 1, 1, 1, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"aliasoptions":"211","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"","s5_group_child":"0"}', 69, 70, 0, '*', 0),
(265, 'top-menu', 'Blog', '2012-10-12-14-59-04', '', '2012-10-12-14-59-04', 'index.php?Itemid=', 'alias', 1, 1, 1, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"aliasoptions":"212","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"","s5_group_child":"0"}', 71, 72, 0, '*', 0),
(266, 'top-menu', 'Home (6)', '2012-10-12-14-57-16', '', '2012-10-12-14-57-16', 'index.php?Itemid=', 'alias', -2, 1, 1, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"aliasoptions":"208","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"s5_load_mod":"0","s5_columns":"1","s5_subtext":"","s5_group_child":"0"}', 73, 74, 0, '*', 0);

-- --------------------------------------------------------

--
-- Table structure for table `#__menu_types`
--

DROP TABLE IF EXISTS `#__menu_types`;
CREATE TABLE IF NOT EXISTS `#__menu_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menutype` varchar(24) NOT NULL,
  `title` varchar(48) NOT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_menutype` (`menutype`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `#__menu_types`
--

INSERT INTO `#__menu_types` (`id`, `menutype`, `title`, `description`) VALUES
(1, 'mainmenu', 'Main Menu', 'The main menu for the site'),
(2, 'top-bottom-menu', 'Bottom Menu', ''),
(9, 'top-menu', 'Top Menu', '');

-- --------------------------------------------------------

--
-- Table structure for table `#__messages`
--

DROP TABLE IF EXISTS `#__messages`;
CREATE TABLE IF NOT EXISTS `#__messages` (
  `message_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id_from` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id_to` int(10) unsigned NOT NULL DEFAULT '0',
  `folder_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `priority` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` text NOT NULL,
  PRIMARY KEY (`message_id`),
  KEY `useridto_state` (`user_id_to`,`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `#__messages_cfg`
--

DROP TABLE IF EXISTS `#__messages_cfg`;
CREATE TABLE IF NOT EXISTS `#__messages_cfg` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `cfg_name` varchar(100) NOT NULL DEFAULT '',
  `cfg_value` varchar(255) NOT NULL DEFAULT '',
  UNIQUE KEY `idx_user_var_name` (`user_id`,`cfg_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__modules`
--

DROP TABLE IF EXISTS `#__modules`;
CREATE TABLE IF NOT EXISTS `#__modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `position` varchar(50) NOT NULL DEFAULT '',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `module` varchar(50) DEFAULT NULL,
  `access` int(10) unsigned DEFAULT NULL,
  `showtitle` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `published` (`published`,`access`),
  KEY `newsfeeds` (`module`,`published`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=174 ;

--
-- Dumping data for table `#__modules`
--

INSERT INTO `#__modules` (`id`, `title`, `note`, `content`, `ordering`, `position`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `published`, `module`, `access`, `showtitle`, `params`, `client_id`, `language`) VALUES
(2, 'Login', '', '', 1, 'login', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_login', 1, 1, '', 1, '*'),
(3, 'Popular Articles', '', '', 3, 'cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_popular', 3, 1, '{"count":"5","catid":"","user_id":"0","layout":"_:default","moduleclass_sfx":"","cache":"0","automatic_title":"1"}', 1, '*'),
(4, 'Recently Added Articles', '', '', 4, 'cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_latest', 3, 1, '{"count":"5","ordering":"c_dsc","catid":"","user_id":"0","layout":"_:default","moduleclass_sfx":"","cache":"0","automatic_title":"1"}', 1, '*'),
(6, 'Unread Messages', '', '', 1, 'header', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_unread', 3, 1, '', 1, '*'),
(7, 'Online Users', '', '', 2, 'header', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_online', 3, 1, '', 1, '*'),
(8, 'Toolbar', '', '', 1, 'toolbar', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_toolbar', 3, 1, '', 1, '*'),
(9, 'Quick Icons', '', '', 1, 'icon', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_quickicon', 3, 1, '', 1, '*'),
(10, 'Logged-in Users', '', '', 2, 'cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_logged', 3, 1, '{"count":"5","name":"1","layout":"_:default","moduleclass_sfx":"","cache":"0","automatic_title":"1"}', 1, '*'),
(12, 'Admin Menu', '', '', 1, 'menu', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 3, 1, '{"layout":"","moduleclass_sfx":"","shownew":"1","showhelp":"1","cache":"0"}', 1, '*'),
(13, 'Admin Submenu', '', '', 1, 'submenu', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_submenu', 3, 1, '', 1, '*'),
(14, 'User Status', '', '', 2, 'status', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_status', 3, 1, '', 1, '*'),
(15, 'Title', '', '', 1, 'title', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_title', 3, 1, '', 1, '*'),
(19, 'Main Menu', '', '', 1, 'right', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_menu', 1, 1, '{"menutype":"mainmenu","startLevel":"1","endLevel":"0","showAllChildren":"0","tag_id":"","class_sfx":"","window_open":"","layout":"_:default","moduleclass_sfx":"-background","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(21, 'Login', '', '', 1, 'login', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_login', 1, 1, '{"pretext":"","posttext":"","login":"","logout":"","greeting":"1","name":"0","usesecure":"0","layout":"_:default","moduleclass_sfx":"","cache":"0"}', 0, '*'),
(22, 'Statistics', '', '', 9, 'right', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_stats', 1, 1, '{"serverinfo":"1","siteinfo":"1","counter":"1","increase":"0","moduleclass_sfx":"","cache":"0","cache_time":"900"}', 0, '*'),
(23, 'Guests Online', '', '', 11, 'right', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_whosonline', 1, 1, '{"showmode":"0","layout":"_:default","moduleclass_sfx":"","cache":"0","filter_groups":"0"}', 0, '*'),
(24, 'Popular Articles', '', '', 1, 'bottom_row3_2', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_articles_popular', 1, 1, '{"catid":[""],"count":"4","show_front":"1","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(25, 'Archive', '', '', 2, 'left', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_articles_archive', 1, 1, '{"count":10,"moduleclass_sfx":"-blue tester","cache":1}', 0, '*'),
(26, 'Sections', '', '', 4, 'left', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_sections', 1, 1, '{"count":"5","moduleclass_sfx":"","cache":"1","cache_time":"900"}', 0, '*'),
(27, 'Related Items', '', '', 7, 'left', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_related_items', 1, 1, '{}', 0, '*'),
(28, 'Search', '', '', 1, 'right', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_search', 1, 1, '{"label":"","width":"50","text":"","button":"","button_pos":"right","imagebutton":"","button_text":"Find","opensearch":"1","opensearch_title":"","set_itemid":"212","layout":"_:default","moduleclass_sfx":"-highlight","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(29, 'Random Image', '', '', 5, 'left', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_random_image', 1, 1, '{"type":"jpg","folder":"","link":"","width":"","height":"","moduleclass_sfx":"","cache":"0","cache_time":"900"}', 0, '*'),
(30, 'Banners', '', '', 1, 'banner', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_banners', 1, 0, '{"target":"1","count":"1","cid":"1","catid":"13","tag_search":"0","ordering":"random","header_text":"","footer_text":"","moduleclass_sfx":"","cache":"1","cache_time":"15"}', 0, '*'),
(31, 'Wrapper', '', '', 4, 'bottom_row_1', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_wrapper', 1, 1, '{"moduleclass_sfx":"","url":"","scrolling":"auto","width":"100%","height":"200","height_auto":"1","add":"1","target":"","cache":"0","cache_time":"900"}', 0, '*'),
(32, 'Feed Display', '', '', 1, 'above_body_2', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_feed', 1, 1, '{"rssurl":"","rssrtl":"0","rsstitle":"1","rssdesc":"1","rssimage":"1","rssitems":"3","rssitemdesc":"1","word_count":"0","layout":"_:default","moduleclass_sfx":"","cache":"0","cache_time":"15"}', 0, '*'),
(33, 'Breadcrumbs', '', '', 1, 'breadcrumb', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_breadcrumbs', 1, 1, '{"showHere":"0","showHome":"1","homeText":"Home","showLast":"1","separator":"","layout":"_:default","moduleclass_sfx":"","cache":"0","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(34, 'Syndication', '', '', 3, 'left', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_syndicate', 1, 1, '{"cache":"0","text":"Feed Entries","format":"rss","moduleclass_sfx":""}', 0, '*'),
(35, 'Advertisement', '', '', 6, 'left', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_banners', 1, 1, '{"target":"1","count":"4","cid":"0","catid":"14","tag_search":"0","ordering":"0","header_text":"Featured Links:","footer_text":"<a href=\\"http:\\/\\/www.joomla.org\\">Ads by Joomla!<\\/a>","moduleclass_sfx":"_text","cache":"0","cache_time":"900"}', 0, '*'),
(37, 'Our Latest News', '', '', 2, 'bottom_row3_3', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_articles_latest', 1, 1, '{"catid":["20","7","8","2"],"count":"6","show_featured":"","ordering":"c_dsc","user_id":"0","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"_:static"}', 0, '*'),
(38, 'S5 Accordion', '', '', 2, 'right', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_s5_accordion_menu', 1, 1, '{"menutype":"mainmenu","parentlinks":"1","startLevel":"1","endLevel":"0","showAllChildren":"1","class_sfx":"","window_open":"","layout":"_:default","moduleclass_sfx":"-dark_title","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(41, 'Top Row1 Modules', '', 'This is an example of a module published to the top_row_1 row. This row contains 6 modules, read below for a full description.', 1, 'top_row1_1', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(42, 'Top Row2 Modules', '', 'This is an example of a module published to the top_row_2 row. This row contains 6 modules, read below for a full description.', 0, 'top_row2_1', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"moduleclass_sfx":""}', 0, '*'),
(43, 'Top Row3 Modules', '', '<p>This is an example of a module published to the top_row_3 row. This row contains 6 modules, read below for a full description.</p>', 3, 'top_row3_1', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"moduleclass_sfx":""}', 0, '*'),
(44, 'Bottom Row1 Modules', '', 'This is an example of a module published to the bottom_row_1 row. This row contains 6 modules, read above for a full description.', 4, 'bottom_row1_1', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"moduleclass_sfx":""}', 0, '*'),
(45, 'Bottom Row2 Modules', '', 'This is an example of a module published to the bottom_row_2 row. This row contains 6 modules, read above for a full description.', 0, 'bottom_row2_1', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"moduleclass_sfx":""}', 0, '*'),
(46, 'Bottom Row3 Modules', '', 'This is an example of a module published to the bottom_row_3 row. This row contains 6 modules, read above for a full description.', 1, 'bottom_row3_1', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"moduleclass_sfx":""}', 0, '*'),
(51, 'Right', '', 'This is an example of a module published to the right position. There are also left, insets, rows, etc. positions and many others, be sure to read the full description. This is the default style that will appear for most module positions in the white body area.', 5, 'right', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(52, 'Right Inset', '', 'This is an example of a module published to the right_inset position. There is also a left_inset position and many others, be sure to read the full description.', 1, 'right_inset', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(53, 'Register', '', '', 1, 'register', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_s5_register', 1, 1, '{"moduleclass_sfx":""}', 0, '*'),
(54, 'Demo Information', '', 'All content and images shown on this site is for demo, presentation  purposes only. This site is intended to exemplify a live website and does not make any claim of any kind to the validity of non-Shape5 content, images or posts published. Stock photography was purchased from <a href="http://www.shutterstock.com" target="_blank">shutterstock.com</a> for this demo only, and is not included with this template. You may not use these images for your own use without purchase. Links will be provided for some images if you wish to purchase them from their copyright owners.\r\n', 1, 'bottom_row3_1', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(55, 'Site Shaper Available', '', 'Do you need a website up and running quickly? Then a site shaper is just what you are looking for. A Site Shaper is a quick and easy way to get your site looking just like our demo in just minutes Make an exact copy of this demo with very little effort, except stock photography. <a href="index.php/tutorials-mainmenu-48/site-shaper-setup">Learn More...</a>\r\n', 1, 'bottom_row3_1', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(56, 'Bottom Menu', '', '', 1, 'bottom_menu', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 1, 1, '{"menutype":"top-bottom-menu","startLevel":"1","endLevel":"1","showAllChildren":"0","tag_id":"","class_sfx":"","window_open":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(58, 'Featured News', '', '', 0, 'right_inset', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_articles_news', 1, 0, '{"layout":"vertical","image":"0","link_titles":"1","showLastSeparator":"0","item_title":"1","moduleclass_sfx":"","cache":"0","cache_time":"900","catid":["22"],"item_heading":"h4","count":"5","ordering":"a.publish_up","cachemode":"itemid"}', 0, '*'),
(62, 'S5 Flex Menu Sample Module', '', '<div style="width:182px;font-size:0.85em"><div style="float:left"><img style="width:72px" src="http://www.shape5.com/demo/images/multibox3.jpg" alt="" /></div>This is a sample module to showcase the functionality of the S5 Flex Menu system. This menu system contains up to 40 module positions and you can publish any module to any of these positions under any menu item.</div>', 1, 's5_menu1', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 0, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(66, 'Sample Drop Down Module', '', 'This is an example of a module published to the drop_down row. This row contains 6 modules. To enable the drop down simple publish any module to any of the drop_down_x positions.', 0, 'drop_down_1', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"moduleclass_sfx":""}', 0, '*'),
(67, 'Banner Position', '', 'This is a custom html module published to the ''banner'' position with the suffix -style1 applied.', 2, 'banner', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"moduleclass_sfx":"-style1"}', 0, '*'),
(79, 'Multilanguage status', '', '', 1, 'status', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_multilangstatus', 3, 1, '{"layout":"_:default","moduleclass_sfx":"","cache":"0"}', 1, '*'),
(80, 'Joomla Version', '', '', 1, 'footer', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_version', 3, 1, '{"format":"short","product":"1","layout":"_:default","moduleclass_sfx":"","cache":"0"}', 1, '*'),
(81, 'Search', '', '', 5, 'right', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_finder', 1, 0, '{"searchfilter":"","show_autosuggest":"1","show_advanced":"0","layout":"_:default","moduleclass_sfx":"-highlight","field_size":28,"alt_label":"","show_label":"1","label_pos":"top","show_button":"0","button_pos":"right","opensearch":"1","opensearch_title":""}', 0, '*'),
(111, 'S5 Box', '', '', 1, 'bottom_menu', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_s5_box', 1, 1, '{"s5_jsversion":"jquery","s5_boxeffect":"elastic","s5boxwidth1":"35","s5boxwidth2":"35","s5boxwidth3":"35","s5boxwidth4":"35","s5boxwidth5":"35","s5boxwidth6":"35","s5boxwidth7":"35","s5boxwidth8":"35","s5boxwidth9":"35","s5boxwidth10":"35","moduleclass_sfx":"-s5_box"}', 0, '*'),
(112, 'S5 Image and Content Fader v3', '', '', 1, 'custom_1', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_s5_image_and_content_fader', 1, 0, '{"pretext":"","moduleclass_sfx":"","height":"430px","width":"100%","s5stretchimage":"stretch","s5pixelwidth":"0px","background":"212121","jslibrary":"mootools","jseffect":"continuoushorizontal","s5_dropdowntext":"Open Gallery","s5_delay":"7000","s5_hidecar":"falsee","s5_hidebut":"truee","s5_hidetext":"truee","title1":"Discover The Power","title2":"Responsive Layout","title3":"Powerful Flex Menu","title4":"","title5":"","title6":"","title7":"","title8":"","title9":"","title10":"","picture1":"images\\/iacf1.jpg","picture1link":"index.php\\/features-mainmenu-47\\/template-specific-features","picture1text":"Of A Shape5 Vertex Template!\\r\\n<a href=\\"index.php\\/features-mainmenu-47\\/template-specific-features\\">Read More...<\\/a>","picture2":"images\\/iacf2.jpg","picture2link":"index.php\\/features-mainmenu-47\\/template-features\\/responsive-layout","picture2text":"Adapt Your Site To Any Screen!\\r\\n<a href=\\"index.php\\/features-mainmenu-47\\/template-features\\/responsive-layout\\">Read More...<\\/a>","picture3":"images\\/iacf3.jpg","picture3link":"index.php\\/extensions\\/s5-flex-menu-1360","picture3text":"Beautiful And Easy To Use Menu!\\r\\n<a href=\\"index.php\\/extensions\\/s5-flex-menu-1360\\">Read More...<\\/a>","picture4":"","picture4link":"","picture4text":"","picture5":"","picture5link":"","picture5text":"","picture6":"","picture6link":"","picture6text":"","picture7":"","picture7link":"","picture7text":"","picture8":"","picture8link":"","picture8text":"","picture9":"","picture9link":"","picture9text":"","picture10":"","picture10link":"","picture10text":""}', 0, '*'),
(146, 'Contact Us', '', 'Aenean quis mollis augue. Mauris condimentum, erat in suscipit pretium, libero \r\nodio tempus magna, quis.Condi ipsum lorem iaculis.\r\n<br /><br />\r\n<img src="images/phone.png" alt="" style="float:left;margin-right:10px" /><span style="float:left">555-555-1212</span>\r\n<br />\r\n<div style="clear:both;width:10px;height:5px"></div>\r\n<img src="images/email.png" alt="" style="float:left;margin-right:10px" /><span style="float:left">noreply@shape5.com</span>', 1, 'bottom_row3_3', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(147, 'S5 Tab Show', '', '', 1, 'bottom_row1_1', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_s5_tabshow', 1, 0, '{"pretext":"","moduleclass_sfx":"","s5_width":"1000","s5_buttonheight":"27px","s5_lineheight":"2.2em","s5_buttoncolor":"transparent","s5_buttonimage":"..\\/modules\\/mod_s5_tabshow\\/s5_tabshow\\/s5_tab_show_nonactive.png","s5_hovercolor":"#FFFFFF","s5_hoverimage":"..\\/modules\\/mod_s5_tabshow\\/s5_tabshow\\/s5_tab_show_active.png","s5_fontcolor":"#000000","s5_javascript":"mootools","s5_mootoolsmouse":"mouse","s5_effectsani":"fade","s5_effectmouse":"mouse","text1line":"Who We Are","text2line":"More About Us","text3line":"","text4line":"","text5line":"","text6line":"","text7line":"","text8line":"","text9line":"","text10line":""}', 0, '*'),
(148, 'Tab 1', '', '<div class="tab_left">\r\n<div class="tab_left_inner">\r\n\r\n	<h2>We Work Hard To Please You</h2>\r\n	\r\n	<span>\r\n	Lorem ipsum dolor sit amet, consec tetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Pha sellus porta. Fusce suscipit varius mi.\r\n	<br /><br />\r\n	Cum sociis natoque penatibus et magnis dis parturient montes, na scetur ridiculus mus. Nulla dui. Fusce feugiat malesuada odio. Morbi nunc odio, gravida at, cursus nec, luctus a, lorem. Maecenas tris tique orci ac sem.\r\n	</span>\r\n	<br />\r\n	<br />\r\n	<br />\r\n	<a href="index.php/component/content/article?id=277" class="s5_readon">Learn More</a>\r\n	\r\n	<div style="clear:both"></div>\r\n\r\n</div>\r\n</div>\r\n\r\n<div class="tab_right">\r\n\r\n	<div class="tab_row1">\r\n	<div class="tab_row1_inner">\r\n		<div class="tab_box1">\r\n			<div class="tab_box">\r\n				<img src="images/tab1.png" alt="" />\r\n				<div style="clear:both"></div>\r\n			</div>\r\n		</div>\r\n	\r\n		<div class="tab_box2">\r\n			<div class="tab_box">\r\n				<img src="images/tab2.png" alt="" />\r\n				<div style="clear:both"></div>\r\n			</div>\r\n		</div>\r\n		<div style="clear:both"></div>\r\n	</div>\r\n	</div>\r\n	\r\n	<div class="tab_row2">\r\n	<div class="tab_row2_inner">\r\n		<div class="tab_box3">\r\n			<div class="tab_box">\r\n				<img src="images/tab3.png" alt="" />\r\n				<div style="clear:both"></div>\r\n			</div>\r\n		</div>\r\n		\r\n		<div class="tab_box4">\r\n			<div class="tab_box">\r\n				<img src="images/tab4.png" alt="" />\r\n				<div style="clear:both"></div>\r\n			</div>\r\n		</div>\r\n		<div style="clear:both"></div>\r\n	</div>\r\n	</div>\r\n\r\n	<div style="clear:both"></div>\r\n\r\n</div>', 1, 's5_tab1', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(149, 'Tab 2', '', '<div class="tab_text1">\r\n	<img class="padded" src="images/tab2_image1.jpg" style="float:left;width:44%;margin-bottom:10px" alt="" />\r\n	<span>\r\n	Lorem ipsum dolor sit amet, consec tetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Pha sellus porta. Fusce suscipit varius mi.\r\n	<br /><br />\r\n	Cum sociis natoque penatibus et magnis dis parturient montes, na scetur ridiculus mus. Nulla dui. Fusce feugiat malesuada odio. Morbi nunc odio, gravida at, cursus nec, luctus a, lorem. Maecenas tris tique orci ac sem. Cum sociis natoque penatibus et magnis dis parturient montes, na scetur ridiculus mus. Nulla dui. Fusce feugiat malesuada odio. Morbi nunc odio, gravida at, cursus.\r\n	</span>\r\n	<br />\r\n	<br />\r\n	<a href="index.php/component/content/article?id=277" class="s5_readon">Read More</a>\r\n</div>\r\n\r\n<div class="tab_text2">\r\n	<img class="padded" src="images/tab2_image2.jpg" style="float:left;width:44%;margin-bottom:10px" alt="" />\r\n	<span>\r\nLorem ipsum dolor sit amet, consec tetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Pha sellus porta. Fusce suscipit varius mi.\r\n<br /><br />\r\nCum sociis natoque penatibus et magnis dis parturient montes, na scetur ridiculus mus. Nulla dui. Fusce feugiat malesuada odio. Morbi nunc odio, gravida at, cursus nec, luctus a, lorem. Maecenas tris tique orci ac sem. Cum sociis natoque penatibus et magnis dis parturient montes, na scetur ridiculus mus. Nulla dui. Fusce feugiat malesuada odio. Morbi nunc odio, gravida at, cursus.\r\n	</span>\r\n	<br />\r\n	<br />\r\n	<a href="index.php/component/content/article?id=277" class="s5_readon">Read More</a>\r\n</div>', 1, 's5_tab2', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(152, '-background', '', 'This is the -background module style and can be applied to most most module positions.', 5, 'right', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"-background","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(158, '-highlight', '', 'This is the -highlight module style and can be applied to most most module positions.', 5, 'right', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"-highlight","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(159, 'Homepage Custom3 Module', '', '<span style="width:67%;display:block;margin-left:auto;margin-right:auto;font-size:1.7em;text-align:center;line-height:166%">\r\nNew Vision is built off of the <span class="s5_highlight">Shape5 Vertex Framework,</span> giving you\r\n<span style="color:#7E7E7E">the ultimate control of your website.   </span><a target="_blank" class="s5_readon" href="http://www.shape5.com/joomla/framework/vertex_framework.html">More...</a>\r\n</span>', 1, 'custom_3', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 0, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(160, 'Bottom Row - We Are Here To Help', '', '<img src="images/row1.jpg" alt="" style="margin:0px;margin-bottom:20px" class="padded" />\r\n<span style="clear:both;display:block"></span>\r\n<h3 class="font_highlight">We Are Here To Help</h3>\r\n<br />\r\n<span style="font-size:0.85em">\r\nLorem ipsum dolor sit amet, mei quod intellegam an, vix quodsi tamquam tractat et quo dolor ipsum este.\r\n<br /><br />\r\nEstudesu usandae Itaque earumum reruhit enetura sapientemi delectuuut reic magnis partur ient montes.\r\n</span>\r\n<br /><br />\r\n<a class="readon" href="index.php?option=com_content&view=article&id=277">Read More...</a>', 1, 'bottom_row2_1', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 0, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(161, 'Bottom Row - Easy Business Plans', '', '<img src="images/row2.jpg" alt="" style="margin:0px;margin-bottom:20px" class="padded" />\r\n<span style="clear:both;display:block"></span>\r\n<h3 class="font_highlight">Easy Business Plans</h3>\r\n<br />\r\n<span style="font-size:0.85em">\r\nEstudesu usandae Itaque earumum reruhit enetura sapientemi delectuuut reic magnis partur ient montes.\r\n<br /><br />\r\nLorem ipsum dolor sit amet, mei quod intellegam an, vix quodsi tamquam tractat et quo dolor ipsum este.\r\n</span>\r\n<br /><br />\r\n<a class="readon" href="index.php?option=com_content&view=article&id=277">Read More...</a>', 1, 'bottom_row2_2', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 0, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(162, 'Bottom Row - Years Of Experience', '', '<img src="images/row3.jpg" alt="" style="margin:0px;margin-bottom:20px" class="padded" />\r\n<span style="clear:both;display:block"></span>\r\n<h3 class="font_highlight">Years Of Experience</h3>\r\n<br />\r\n<span style="font-size:0.85em">\r\nLorem ipsum dolor sit amet, mei quod intellegam an, vix quodsi tamquam tractat et quo dolor ipsum este.\r\n<br /><br />\r\nEstudesu usandae Itaque earumum reruhit enetura sapientemi delectuuut reic magnis partur ient montes.\r\n</span>\r\n<br /><br />\r\n<a class="readon" href="index.php?option=com_content&view=article&id=277">Read More...</a>', 1, 'bottom_row2_3', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 0, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(163, 'Bottom Row - Ready When You Are', '', '<img src="images/row4.jpg" alt="" style="margin:0px;margin-bottom:20px" class="padded" />\r\n<span style="clear:both;display:block"></span>\r\n<h3 class="font_highlight">Ready When You Are</h3>\r\n<br />\r\n<span style="font-size:0.85em">\r\nEstudesu usandae Itaque earumum reruhit enetura sapientemi delectuuut reic magnis partur ient montes.\r\n<br /><br />\r\nLorem ipsum dolor sit amet, mei quod intellegam an, vix quodsi tamquam tractat et quo dolor ipsum este.\r\n</span>\r\n<br /><br />\r\n<a class="readon" href="index.php?option=com_content&view=article&id=277">Read More...</a>', 1, 'bottom_row2_4', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 0, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(164, 'Top Menu', '', '', 1, 'top_menu', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 1, 1, '{"menutype":"top-menu","startLevel":"1","endLevel":"1","showAllChildren":"0","tag_id":"","class_sfx":"","window_open":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(165, 'Upcoming Events', '', '11.10.2012\r\n<br /><br />\r\nProin magna mi, porttitor eget loboris sit amet, bibendum id orci. Nam arius mollis.\r\n<br /><br />\r\n12.15.2012\r\n<br /><br />\r\nSuspendisse in ipsum ut magna pharetra aliquet non sodales velit. Proin pellenesque.', 2, 'bottom_row3_2', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(167, 'Custom 3', '', 'This is the custom_3 position.', 1, 'custom_3', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(168, 'Custom 2', '', 'This is the custom_2 position.', 1, 'custom_2', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(169, 'Custom_1', '', 'This row also contains a custom_1 position which shows below the top_row1 positions. We do not recommend publishing other modules to this row when custom_1 is used. Custom_1 is meant specifically for the Image and Content Fader module only. There are several settings for this in the template configuration as well.', 2, 'top_row1_1', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(170, '-dark_title', '', 'This is the -dark_title module style and can be applied to most most module positions.', 5, 'right', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"-dark_title","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(171, '-highlight_title', '', 'This is the -highlight_title module style and can be applied to most most module positions.', 5, 'right', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"-highlight_title","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(172, '-highlight_full', '', 'This is the -highlight_full module style and can be applied to most most module positions.', 5, 'right', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"-highlight_full","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(173, '-dark_full', '', 'This is the -dark_full module style and can be applied to most most module positions.', 5, 'right', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"-dark_full","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*');

-- --------------------------------------------------------

--
-- Table structure for table `#__modules_menu`
--

DROP TABLE IF EXISTS `#__modules_menu`;
CREATE TABLE IF NOT EXISTS `#__modules_menu` (
  `moduleid` int(11) NOT NULL DEFAULT '0',
  `menuid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`moduleid`,`menuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `#__modules_menu`
--

INSERT INTO `#__modules_menu` (`moduleid`, `menuid`) VALUES
(1, 0),
(2, 0),
(3, 0),
(4, 0),
(6, 0),
(7, 0),
(8, 0),
(9, 0),
(10, 0),
(12, 0),
(13, 0),
(14, 0),
(15, 0),
(16, 0),
(17, 0),
(18, 0),
(19, 0),
(21, 0),
(22, 0),
(23, 110),
(23, 111),
(23, 122),
(23, 123),
(23, 126),
(23, 145),
(23, 146),
(23, 154),
(23, 179),
(23, 182),
(23, 206),
(24, -222),
(24, -221),
(24, -220),
(24, -216),
(24, -215),
(24, -214),
(24, -213),
(24, -212),
(24, -211),
(24, -210),
(24, -209),
(24, -208),
(24, -125),
(24, -121),
(25, 0),
(26, 0),
(28, 102),
(28, 110),
(28, 123),
(28, 124),
(28, 145),
(28, 146),
(28, 149),
(28, 150),
(28, 198),
(28, 223),
(28, 247),
(28, 248),
(30, 0),
(31, 0),
(31, 1),
(32, 0),
(33, 0),
(34, 0),
(35, 102),
(37, -125),
(37, -121),
(38, -202),
(38, -125),
(38, -121),
(39, -125),
(39, -121),
(40, 0),
(41, 121),
(41, 125),
(42, 121),
(42, 125),
(43, 121),
(43, 125),
(44, 121),
(44, 125),
(45, 121),
(45, 125),
(46, 121),
(46, 125),
(51, 121),
(51, 125),
(52, 121),
(52, 125),
(53, 0),
(54, -125),
(54, -121),
(55, -125),
(55, -121),
(56, 0),
(58, 102),
(62, 0),
(66, 121),
(66, 125),
(66, 200),
(67, 121),
(67, 125),
(79, 0),
(80, 0),
(81, 0),
(97, -125),
(97, -121),
(99, -125),
(99, -121),
(111, 0),
(112, 102),
(112, 206),
(121, -125),
(121, -121),
(146, -125),
(146, -121),
(147, 102),
(147, 202),
(148, 0),
(149, 0),
(152, 121),
(152, 125),
(158, 121),
(158, 125),
(159, 102),
(160, 102),
(161, 102),
(162, 102),
(163, 102),
(164, 0),
(165, -125),
(165, -121),
(167, 121),
(167, 125),
(168, 121),
(168, 125),
(169, 121),
(169, 125),
(170, 121),
(170, 125),
(171, 121),
(171, 125),
(172, 121),
(172, 125),
(173, 121),
(173, 125),
(248, 1),
(249, 1),
(258, 1),
(259, 1),
(590, 1),
(590, 2),
(590, 5),
(590, 7),
(590, 8),
(590, 23),
(590, 26),
(590, 27),
(590, 28),
(590, 32),
(590, 33),
(590, 34),
(590, 35),
(590, 36),
(590, 37),
(590, 38),
(590, 47),
(590, 48),
(590, 81),
(590, 88),
(590, 89),
(590, 93),
(590, 96),
(590, 97),
(590, 99),
(590, 100),
(590, 113),
(590, 120),
(590, 129),
(590, 141),
(590, 142),
(590, 201),
(590, 202),
(590, 207),
(590, 210),
(590, 211),
(590, 213),
(590, 214),
(590, 225),
(590, 226),
(590, 228),
(590, 230),
(590, 233),
(590, 234),
(590, 250),
(590, 252),
(590, 259),
(590, 264),
(590, 266),
(590, 268),
(590, 269),
(590, 270),
(590, 275),
(590, 276),
(590, 277),
(590, 278),
(590, 279),
(590, 280),
(590, 281),
(590, 282),
(590, 283),
(590, 284),
(590, 285),
(590, 286),
(590, 287),
(590, 288),
(590, 289),
(590, 290),
(590, 291),
(590, 292),
(590, 293),
(590, 294),
(590, 295);

-- --------------------------------------------------------

--
-- Table structure for table `#__molajotools_customperms`
--

DROP TABLE IF EXISTS `#__molajotools_customperms`;
CREATE TABLE IF NOT EXISTS `#__molajotools_customperms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `path` varchar(255) NOT NULL,
  `perms` varchar(4) DEFAULT '0644',
  UNIQUE KEY `id` (`id`),
  KEY `path` (`path`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `#__newsfeeds`
--

DROP TABLE IF EXISTS `#__newsfeeds`;
CREATE TABLE IF NOT EXISTS `#__newsfeeds` (
  `catid` int(11) NOT NULL DEFAULT '0',
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `link` varchar(200) NOT NULL DEFAULT '',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `numarticles` int(10) unsigned NOT NULL DEFAULT '1',
  `cache_time` int(10) unsigned NOT NULL DEFAULT '3600',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rtl` tinyint(4) NOT NULL DEFAULT '0',
  `access` int(10) unsigned DEFAULT NULL,
  `language` char(7) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `metadata` text NOT NULL,
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `description` text NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `images` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`published`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `#__newsfeeds`
--

INSERT INTO `#__newsfeeds` (`catid`, `id`, `name`, `alias`, `link`, `published`, `numarticles`, `cache_time`, `checked_out`, `checked_out_time`, `ordering`, `rtl`, `access`, `language`, `params`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `metakey`, `metadesc`, `metadata`, `xreference`, `publish_up`, `publish_down`, `description`, `version`, `hits`, `images`) VALUES
(29, 1, 'Joomla! Announcements', 'joomla-official-news', 'http://feeds.joomla.org/JoomlaAnnouncements', 1, 5, 3600, 0, '0000-00-00 00:00:00', 1, 0, 1, '*', '', '0000-00-00 00:00:00', 589, '', '0000-00-00 00:00:00', 0, '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 1, 0, ''),
(29, 2, 'Joomla! Core Team Blog', 'joomla-core-team-blog', 'http://feeds.joomla.org/JoomlaCommunityCoreTeamBlog', 1, 5, 3600, 0, '0000-00-00 00:00:00', 2, 0, 1, '*', '', '0000-00-00 00:00:00', 589, '', '0000-00-00 00:00:00', 0, '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 1, 0, ''),
(29, 3, 'Joomla! Community Magazine', 'joomla-community-magazine', 'http://feeds.joomla.org/JoomlaMagazine', 1, 20, 3600, 0, '0000-00-00 00:00:00', 3, 0, 1, '*', '', '0000-00-00 00:00:00', 589, '', '0000-00-00 00:00:00', 0, '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 1, 0, ''),
(29, 4, 'Joomla! Developer News', 'joomla-developer-news', 'http://feeds.joomla.org/JoomlaDeveloper', 1, 5, 3600, 0, '0000-00-00 00:00:00', 4, 0, 1, '*', '', '0000-00-00 00:00:00', 589, '', '0000-00-00 00:00:00', 0, '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 1, 0, ''),
(29, 5, 'Joomla! Security News', 'joomla-security-news', 'http://feeds.joomla.org/JoomlaSecurityNews', 1, 5, 3600, 0, '0000-00-00 00:00:00', 5, 0, 1, '*', '', '0000-00-00 00:00:00', 589, '', '0000-00-00 00:00:00', 0, '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 1, 0, ''),
(30, 6, 'Free Software Foundation Blogs', 'free-software-foundation-blogs', 'http://www.fsf.org/blogs/RSS', 1, 5, 3600, 0, '0000-00-00 00:00:00', 4, 0, 1, '*', '', '0000-00-00 00:00:00', 589, '', '0000-00-00 00:00:00', 0, '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 1, 0, ''),
(30, 7, 'Free Software Foundation', 'free-software-foundation', 'http://www.fsf.org/news/RSS', 1, 5, 3600, 62, '2008-09-14 00:24:25', 3, 0, 1, '*', '', '0000-00-00 00:00:00', 589, '', '0000-00-00 00:00:00', 0, '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 1, 0, ''),
(30, 8, 'Software Freedom Law Center Blog', 'software-freedom-law-center-blog', 'http://www.softwarefreedom.org/feeds/blog/', 1, 5, 3600, 0, '0000-00-00 00:00:00', 2, 0, 1, '*', '', '0000-00-00 00:00:00', 589, '', '0000-00-00 00:00:00', 0, '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 1, 0, ''),
(30, 9, 'Software Freedom Law Center News', 'software-freedom-law-center', 'http://www.softwarefreedom.org/feeds/news/', 1, 5, 3600, 0, '0000-00-00 00:00:00', 1, 0, 1, '*', '', '0000-00-00 00:00:00', 589, '', '0000-00-00 00:00:00', 0, '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 1, 0, ''),
(30, 10, 'Open Source Initiative Blog', 'open-source-initiative-blog', 'http://www.opensource.org/blog/feed', 1, 5, 3600, 0, '0000-00-00 00:00:00', 5, 0, 1, '*', '', '0000-00-00 00:00:00', 589, '', '0000-00-00 00:00:00', 0, '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 1, 0, ''),
(31, 11, 'PHP News and Announcements', 'php-news-and-announcements', 'http://www.php.net/feed.atom', 1, 5, 3600, 62, '2008-09-14 00:25:37', 1, 0, 1, '*', '', '0000-00-00 00:00:00', 589, '', '0000-00-00 00:00:00', 0, '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 1, 0, ''),
(31, 12, 'Planet MySQL', 'planet-mysql', 'http://www.planetmysql.org/rss20.xml', 1, 5, 3600, 62, '2008-09-14 00:25:51', 2, 0, 1, '*', '', '0000-00-00 00:00:00', 589, '', '0000-00-00 00:00:00', 0, '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 1, 0, ''),
(31, 13, 'Linux Foundation Announcements', 'linux-foundation-announcements', 'http://www.linuxfoundation.org/press/rss20.xml', 1, 5, 3600, 62, '2008-09-14 00:26:11', 3, 0, 1, '*', '', '0000-00-00 00:00:00', 589, '', '0000-00-00 00:00:00', 0, '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 1, 0, ''),
(31, 14, 'Mootools Blog', 'mootools-blog', 'http://feeds.feedburner.com/mootools-blog', 1, 5, 3600, 62, '2008-09-14 00:26:51', 4, 0, 1, '*', '', '0000-00-00 00:00:00', 589, '', '0000-00-00 00:00:00', 0, '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 1, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `#__overrider`
--

DROP TABLE IF EXISTS `#__overrider`;
CREATE TABLE IF NOT EXISTS `#__overrider` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `constant` varchar(255) NOT NULL,
  `string` text NOT NULL,
  `file` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `#__redirect_links`
--

DROP TABLE IF EXISTS `#__redirect_links`;
CREATE TABLE IF NOT EXISTS `#__redirect_links` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `old_url` varchar(255) DEFAULT NULL,
  `new_url` varchar(255) DEFAULT NULL,
  `referer` varchar(150) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(4) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_link_old` (`old_url`),
  KEY `idx_link_modifed` (`modified_date`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=40 ;

--
-- Dumping data for table `#__redirect_links`
--

INSERT INTO `#__redirect_links` (`id`, `old_url`, `new_url`, `referer`, `comment`, `hits`, `published`, `created_date`, `modified_date`) VALUES
(1, 'http://localhost/cyan/jupgrade/index.php/extensions/images/fd_image1.jpg', '', 'http://localhost/cyan/jupgrade/index.php/extensions/s5-frontpage-display', '', 0, 0, '2012-02-13 16:46:25', '0000-00-00 00:00:00'),
(2, 'http://localhost/cyan/jupgrade/index.php/extensions/images/fd_active.png', '', 'http://localhost/cyan/jupgrade/index.php/extensions/s5-frontpage-display', '', 0, 0, '2012-02-13 16:46:25', '0000-00-00 00:00:00'),
(3, 'http://localhost/cyan/jupgrade/index.php/extensions/images/fd_inactive.png', '', 'http://localhost/cyan/jupgrade/index.php/extensions/s5-frontpage-display', '', 0, 0, '2012-02-13 16:46:25', '0000-00-00 00:00:00'),
(4, 'http://localhost/cyan/jupgrade/index.php/extensions/images/fd_image2.jpg', '', 'http://localhost/cyan/jupgrade/index.php/extensions/s5-frontpage-display', '', 0, 0, '2012-02-13 16:46:35', '0000-00-00 00:00:00'),
(5, 'http://localhost/cyan/jupgrade/index.php/extensions/images/fd_image3.jpg', '', 'http://localhost/cyan/jupgrade/index.php/extensions/s5-frontpage-display', '', 0, 0, '2012-02-13 16:46:40', '0000-00-00 00:00:00'),
(6, 'http://localhost/cyan/jupgrade/index.php/images/fd_active.png', '', 'http://localhost/cyan/jupgrade/index.php/extensions/s5-frontpage-display', '', 0, 0, '2012-02-13 18:49:36', '0000-00-00 00:00:00'),
(7, 'http://localhost/cyan/jupgrade/index.php/images/fd_inactive.png', '', 'http://localhost/cyan/jupgrade/index.php/extensions/s5-frontpage-display', '', 0, 0, '2012-02-13 18:49:44', '0000-00-00 00:00:00'),
(8, 'http://localhost/cyan/jupgrade/index.php/extensions/.images/fd_active.png', '', 'http://localhost/cyan/jupgrade/index.php/extensions/s5-frontpage-display', '', 0, 0, '2012-02-13 18:50:50', '0000-00-00 00:00:00'),
(9, 'http://localhost/sports/index.php/modules/mod_s5_box/images/internet_explorer/borderTopRight.png', '', 'http://localhost/sports/index.php/s5-flex-menu-1360', '', 0, 0, '2012-04-03 19:11:07', '0000-00-00 00:00:00'),
(10, 'http://localhost/sports/index.php/modules/mod_s5_box/images/internet_explorer/borderMiddleLeft.png', '', 'http://localhost/sports/index.php/s5-flex-menu-1360', '', 0, 0, '2012-04-03 19:11:07', '0000-00-00 00:00:00'),
(11, 'http://localhost/sports/index.php/modules/mod_s5_box/images/internet_explorer/borderBottomLeft.png', '', 'http://localhost/sports/index.php/s5-flex-menu-1360', '', 0, 0, '2012-04-03 19:11:07', '0000-00-00 00:00:00'),
(12, 'http://localhost/sports/index.php/modules/mod_s5_box/images/internet_explorer/borderBottomCenter.png', '', 'http://localhost/sports/index.php/s5-flex-menu-1360', '', 0, 0, '2012-04-03 19:11:07', '0000-00-00 00:00:00'),
(13, 'http://localhost/sports/index.php/modules/mod_s5_box/images/internet_explorer/borderMiddleRight.png', '', 'http://localhost/sports/index.php/s5-flex-menu-1360', '', 0, 0, '2012-04-03 19:11:07', '0000-00-00 00:00:00'),
(14, 'http://localhost/sports/index.php/modules/mod_s5_box/images/internet_explorer/borderBottomRight.png', '', 'http://localhost/sports/index.php/s5-flex-menu-1360', '', 0, 0, '2012-04-03 19:11:07', '0000-00-00 00:00:00'),
(15, 'http://localhost/sports/index.php/modules/mod_s5_box/images/internet_explorer/borderTopLeft.png', '', 'http://localhost/sports/index.php/s5-flex-menu-1360', '', 0, 0, '2012-04-03 19:11:08', '0000-00-00 00:00:00'),
(16, 'http://localhost/sports/index.php/modules/mod_s5_box/images/internet_explorer/borderTopCenter.png', '', 'http://localhost/sports/index.php/s5-flex-menu-1360', '', 0, 0, '2012-04-03 19:11:08', '0000-00-00 00:00:00'),
(17, 'http://localhost/sports/index.php/templates/sports_nation/css/PIE.htc', '', '', '', 0, 0, '2012-04-03 19:11:16', '0000-00-00 00:00:00'),
(18, 'http://localhost/sports/index.php/extensions/index.php', '', 'http://localhost/sports/index.php/extensions/s5-flex-menu', '', 0, 0, '2012-04-05 13:14:06', '0000-00-00 00:00:00'),
(19, 'http://localhost/sports/index.php/tutorials-mainmenu-48/index.php', '', 'http://localhost/sports/index.php/tutorials-mainmenu-48/installing-the-template', '', 0, 0, '2012-04-08 02:53:36', '0000-00-00 00:00:00'),
(20, 'http://localhost/sports/index.php/blogs', '', 'http://localhost/sports/', '', 0, 0, '2012-04-10 20:26:39', '0000-00-00 00:00:00'),
(21, 'http://localhost/sports/index.php/component/content/article/2-uncategorised/index.php', '', 'http://localhost/sports/index.php/component/content/article/2-uncategorised/276-sample-content', '', 0, 0, '2012-04-11 16:13:04', '0000-00-00 00:00:00'),
(22, 'http://localhost/corporate/index.php/features-mainmenu-47/template-features/index.php', '', 'http://localhost/corporate/index.php/features-mainmenu-47/template-features/multibox-enabled', '', 0, 0, '2012-06-06 16:28:26', '0000-00-00 00:00:00'),
(23, 'http://localhost/corporate/index.php/features-mainmenu-47/style-and-layout-options/templates/corporate_response/css/PIE.htc', '', '', '', 0, 0, '2012-06-07 13:41:23', '0000-00-00 00:00:00'),
(24, 'http://localhost/corporate/index.php/extensions/index.php', '', 'http://localhost/corporate/index.php/extensions/s5-cssjs-compressor', '', 0, 0, '2012-06-10 14:55:39', '0000-00-00 00:00:00'),
(25, 'http://localhost/corporate/index.php/features-mainmenu-47/joomla-stuff-mainmenu-26/index.php', '', 'http://localhost/corporate/index.php/features-mainmenu-47/joomla-stuff-mainmenu-26/contact-us', '', 0, 0, '2012-06-11 18:28:13', '0000-00-00 00:00:00'),
(26, 'http://localhost/modern/index.php/features-mainmenu-47/joomla-stuff-mainmenu-26/www', '', 'http://localhost/modern/index.php/features-mainmenu-47/joomla-stuff-mainmenu-26/wrapper-mainmenu-8', '', 1, 0, '2012-08-08 13:43:00', '0000-00-00 00:00:00'),
(27, 'http://localhost/modern/index.php/sample', '', 'http://localhost/modern/', '', 1, 0, '2012-08-13 15:50:37', '0000-00-00 00:00:00'),
(28, 'http://localhost/modern/index.php/features-mainmenu-47/template-features/95-module-positions', '', 'http://localhost/modern/index.php/features-mainmenu-47/template-features/info-slide-enabled', '', 1, 0, '2012-08-13 19:46:25', '0000-00-00 00:00:00'),
(29, 'http://localhost/newvision/index.php/modules/mod_s5_box/images/internet_explorer/borderBottomLeft.png', '', 'http://localhost/newvision/index.php/s5-flex-menu-1360', '', 15, 0, '2012-10-08 22:10:27', '0000-00-00 00:00:00'),
(30, 'http://localhost/newvision/index.php/modules/mod_s5_box/images/internet_explorer/borderTopRight.png', '', 'http://localhost/newvision/index.php/s5-flex-menu-1360', '', 15, 0, '2012-10-08 22:10:27', '0000-00-00 00:00:00'),
(31, 'http://localhost/newvision/index.php/modules/mod_s5_box/images/internet_explorer/borderMiddleLeft.png', '', 'http://localhost/newvision/index.php/s5-flex-menu-1360', '', 15, 0, '2012-10-08 22:10:27', '0000-00-00 00:00:00'),
(32, 'http://localhost/newvision/index.php/modules/mod_s5_box/images/internet_explorer/borderTopLeft.png', '', 'http://localhost/newvision/index.php/s5-flex-menu-1360', '', 15, 0, '2012-10-08 22:10:27', '0000-00-00 00:00:00'),
(33, 'http://localhost/newvision/index.php/modules/mod_s5_box/images/internet_explorer/borderTopCenter.png', '', 'http://localhost/newvision/index.php/s5-flex-menu-1360', '', 15, 0, '2012-10-08 22:10:27', '0000-00-00 00:00:00'),
(34, 'http://localhost/newvision/index.php/modules/mod_s5_box/images/internet_explorer/borderMiddleRight.png', '', 'http://localhost/newvision/index.php/s5-flex-menu-1360', '', 15, 0, '2012-10-08 22:10:27', '0000-00-00 00:00:00'),
(35, 'http://localhost/newvision/index.php/modules/mod_s5_box/images/internet_explorer/borderBottomRight.png', '', 'http://localhost/newvision/index.php/s5-flex-menu-1360', '', 15, 0, '2012-10-08 22:10:28', '0000-00-00 00:00:00'),
(36, 'http://localhost/newvision/index.php/modules/mod_s5_box/images/internet_explorer/borderBottomCenter.png', '', 'http://localhost/newvision/index.php/s5-flex-menu-1360', '', 15, 0, '2012-10-08 22:10:28', '0000-00-00 00:00:00'),
(37, 'http://localhost/newvision/index.php/s5-flex-menu-1360', '', '', '', 1, 0, '2012-10-10 15:23:11', '0000-00-00 00:00:00'),
(38, 'http://localhost/newvision/index.php/features-mainmenu-47/template-features/index.php', '', 'http://localhost/newvision/index.php/features-mainmenu-47/template-features/94-module-positions', '', 11, 0, '2012-10-12 12:50:02', '0000-00-00 00:00:00'),
(39, 'http://localhost/newvision/index.php/features-mainmenu-47/index.php', '', 'http://localhost/newvision/index.php/features-mainmenu-47/template-specific-features', '', 4, 0, '2012-10-13 20:58:05', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `#__responses`
--

DROP TABLE IF EXISTS `#__responses`;
CREATE TABLE IF NOT EXISTS `#__responses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `parent_id` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set parent.',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `level` int(11) unsigned NOT NULL COMMENT 'The cached level in the nested tree.',
  `extension` varchar(50) NOT NULL DEFAULT '' COMMENT 'Joomla! Extension that this response',
  `content_id` int(10) unsigned NOT NULL COMMENT 'Response to Primary Key for Content',
  `content_title` varchar(255) NOT NULL DEFAULT 'Resposne to Primary Key Content Title',
  `catid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Response to Content Category ID',
  `response_type` tinyint(3) NOT NULL DEFAULT '0' COMMENT '1: Comment 2: Content Rating 3: Social Bookmark 4: Poll Response 5: Email Subscription Response 6: Statistical Log 7: Trackback',
  `title` varchar(255) NOT NULL DEFAULT 'Response Title',
  `alias` varchar(255) NOT NULL DEFAULT 'Response Alias',
  `textual_response` mediumtext NOT NULL COMMENT 'Textual Response to Content',
  `numeric_response` int(11) NOT NULL DEFAULT '0' COMMENT 'Numeric Resposne to Content',
  `linked_response` varchar(255) NOT NULL DEFAULT '' COMMENT 'Linked Response to Content',
  `subscription_response` varchar(255) NOT NULL DEFAULT '' COMMENT 'Email Subscription to Content',
  `state` tinyint(3) NOT NULL DEFAULT '0' COMMENT 'State',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Created Date and Time',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Created By User ID, if Member',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '' COMMENT 'Created By Alias',
  `created_by_email` varchar(255) NOT NULL DEFAULT '' COMMENT 'Created By Email Address',
  `created_by_website` varchar(255) NOT NULL DEFAULT '' COMMENT 'Created By Website',
  `created_by_ip_address` varchar(10) NOT NULL DEFAULT '' COMMENT 'Created By IP Address',
  `created_by_referer` varchar(10) NOT NULL DEFAULT '' COMMENT 'Created By Referer',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Modified Date and Time',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Modified By User ID',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Checked Out User ID',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Checked Out Date and Time',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Publish Up Date and Time',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Publish Down Date and Time',
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if response item is featured.',
  `language` char(7) NOT NULL COMMENT 'The language code for the response.',
  `ordering` int(11) NOT NULL DEFAULT '0' COMMENT 'Ordering within the Content Item.',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`state`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_extension` (`extension`,`content_id`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `#__schemas`
--

DROP TABLE IF EXISTS `#__schemas`;
CREATE TABLE IF NOT EXISTS `#__schemas` (
  `extension_id` int(11) NOT NULL,
  `version_id` varchar(20) NOT NULL,
  PRIMARY KEY (`extension_id`,`version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `#__schemas`
--

INSERT INTO `#__schemas` (`extension_id`, `version_id`) VALUES
(700, '3.1.1');

-- --------------------------------------------------------

--
-- Table structure for table `#__session`
--

DROP TABLE IF EXISTS `#__session`;
CREATE TABLE IF NOT EXISTS `#__session` (
  `session_id` varchar(200) NOT NULL DEFAULT '',
  `client_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `guest` tinyint(4) unsigned DEFAULT '1',
  `time` varchar(14) DEFAULT '',
  `data` mediumtext,
  `userid` int(11) DEFAULT '0',
  `username` varchar(150) DEFAULT '',
  PRIMARY KEY (`session_id`),
  KEY `userid` (`userid`),
  KEY `time` (`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `#__session`
--

INSERT INTO `#__session` (`session_id`, `client_id`, `guest`, `time`, `data`, `userid`, `username`) VALUES
('9rdvo92obfc5e57orc7khkig11', 1, 0, '1368885427', '__default|a:8:{s:15:"session.counter";i:9;s:19:"session.timer.start";i:1368885406;s:18:"session.timer.last";i:1368885424;s:17:"session.timer.now";i:1368885425;s:22:"session.client.browser";s:72:"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:20.0) Gecko/20100101 Firefox/20.0";s:8:"registry";O:9:"JRegistry":1:{s:7:"\\0\\0\\0data";O:8:"stdClass":2:{s:11:"application";O:8:"stdClass":1:{s:4:"lang";s:0:"";}s:13:"com_installer";O:8:"stdClass":2:{s:7:"message";s:0:"";s:17:"extension_message";s:0:"";}}}s:4:"user";O:5:"JUser":24:{s:9:"\\0\\0\\0isRoot";b:1;s:2:"id";s:3:"589";s:4:"name";s:10:"Super User";s:8:"username";s:5:"admin";s:5:"email";s:19:"slkfjlfs@dslkfj.com";s:8:"password";s:65:"705bc470d6a28cac7a3121893d14e442:z3vcExz66uPkxX4JgSyPgOVhMOyzi6BB";s:14:"password_clear";s:0:"";s:5:"block";s:1:"0";s:9:"sendEmail";s:1:"1";s:12:"registerDate";s:19:"2013-05-18 13:56:14";s:13:"lastvisitDate";s:19:"0000-00-00 00:00:00";s:10:"activation";s:1:"0";s:6:"params";s:0:"";s:6:"groups";a:1:{i:8;s:1:"8";}s:5:"guest";i:0;s:13:"lastResetTime";s:19:"0000-00-00 00:00:00";s:10:"resetCount";s:1:"0";s:10:"\\0\\0\\0_params";O:9:"JRegistry":1:{s:7:"\\0\\0\\0data";O:8:"stdClass":0:{}}s:14:"\\0\\0\\0_authGroups";a:2:{i:0;i:1;i:1;i:8;}s:14:"\\0\\0\\0_authLevels";a:4:{i:0;i:1;i:1;i:1;i:2;i:2;i:3;i:3;}s:15:"\\0\\0\\0_authActions";N;s:12:"\\0\\0\\0_errorMsg";N;s:10:"\\0\\0\\0_errors";a:0:{}s:3:"aid";i:0;}s:13:"session.token";s:32:"918db5dcbe4c6b1c8662392575cff7e6";}', 589, 'admin'),
('fs21halh6dr4u1l12cbvs6qme7', 0, 1, '1368885391', '__default|a:7:{s:15:"session.counter";i:1;s:19:"session.timer.start";i:1368885390;s:18:"session.timer.last";i:1368885390;s:17:"session.timer.now";i:1368885390;s:22:"session.client.browser";s:72:"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:20.0) Gecko/20100101 Firefox/20.0";s:8:"registry";O:9:"JRegistry":1:{s:7:"\\0\\0\\0data";O:8:"stdClass":0:{}}s:4:"user";O:5:"JUser":24:{s:9:"\\0\\0\\0isRoot";b:0;s:2:"id";i:0;s:4:"name";N;s:8:"username";N;s:5:"email";N;s:8:"password";N;s:14:"password_clear";s:0:"";s:5:"block";N;s:9:"sendEmail";i:0;s:12:"registerDate";N;s:13:"lastvisitDate";N;s:10:"activation";N;s:6:"params";N;s:6:"groups";a:1:{i:0;i:1;}s:5:"guest";i:1;s:13:"lastResetTime";N;s:10:"resetCount";N;s:10:"\\0\\0\\0_params";O:9:"JRegistry":1:{s:7:"\\0\\0\\0data";O:8:"stdClass":0:{}}s:14:"\\0\\0\\0_authGroups";a:1:{i:0;i:1;}s:14:"\\0\\0\\0_authLevels";a:2:{i:0;i:1;i:1;i:1;}s:15:"\\0\\0\\0_authActions";N;s:12:"\\0\\0\\0_errorMsg";N;s:10:"\\0\\0\\0_errors";a:0:{}s:3:"aid";i:0;}}', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `#__tags`
--

DROP TABLE IF EXISTS `#__tags`;
CREATE TABLE IF NOT EXISTS `#__tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0',
  `level` int(10) unsigned NOT NULL DEFAULT '0',
  `path` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `metadesc` varchar(1024) NOT NULL COMMENT 'The meta description for the page.',
  `metakey` varchar(1024) NOT NULL COMMENT 'The meta keywords for the page.',
  `metadata` varchar(2048) NOT NULL COMMENT 'JSON encoded metadata properties.',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `images` text NOT NULL,
  `urls` text NOT NULL,
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `tag_idx` (`published`,`access`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_path` (`path`),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_alias` (`alias`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `#__tags`
--

INSERT INTO `#__tags` (`id`, `parent_id`, `lft`, `rgt`, `level`, `path`, `title`, `alias`, `note`, `description`, `published`, `checked_out`, `checked_out_time`, `access`, `params`, `metadesc`, `metakey`, `metadata`, `created_user_id`, `created_time`, `created_by_alias`, `modified_user_id`, `modified_time`, `images`, `urls`, `hits`, `language`, `version`, `publish_up`, `publish_down`) VALUES
(1, 0, 0, 1, 0, '', 'ROOT', 'root', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{}', '', '', '', 0, '2011-01-01 00:00:01', '', 0, '0000-00-00 00:00:00', '', '', 0, '*', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `#__tag_content`
--

DROP TABLE IF EXISTS `#__tag_content`;
CREATE TABLE IF NOT EXISTS `#__tag_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `tag_id` int(10) unsigned NOT NULL COMMENT 'Tag to Primary Key for Content',
  `extension` varchar(50) NOT NULL DEFAULT '' COMMENT 'Joomla! Extension associated with this Tag',
  `content_id` int(10) unsigned NOT NULL COMMENT 'Tag to Primary Key for Content',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`tag_id`),
  KEY `idx_extension` (`extension`,`content_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

-- --------------------------------------------------------

--
-- Table structure for table `#__template_styles`
--

DROP TABLE IF EXISTS `#__template_styles`;
CREATE TABLE IF NOT EXISTS `#__template_styles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `template` varchar(50) NOT NULL DEFAULT '',
  `client_id` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `home` char(7) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_template` (`template`),
  KEY `idx_home` (`home`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `#__template_styles`
--

INSERT INTO `#__template_styles` (`id`, `template`, `client_id`, `home`, `title`, `params`) VALUES
(2, 'bluestork', 1, '0', 'Bluestork - Default', '{"useRoundedCorners":"1","showSiteName":"0"}'),
(3, 'atomic', 0, '0', 'Atomic - Default', '{}'),
(4, 'beez_20', 0, '0', 'Beez2 - Default', '{"wrapperSmall":"53","wrapperLarge":"72","logo":"images\\/joomla_black.gif","sitetitle":"Joomla!","sitedescription":"Open Source Content Management","navposition":"left","templatecolor":"personal","html5":"0"}'),
(5, 'hathor', 1, '0', 'Hathor - Default', '{"showSiteName":"0","colourChoice":"","boldText":"0"}'),
(6, 'beez5', 0, '0', 'Beez5 - Default-Fruit Shop', '{"wrapperSmall":"53","wrapperLarge":"72","logo":"images\\/sampledata\\/fruitshop\\/fruits.gif","sitetitle":"Matuna Market ","sitedescription":"Fruit Shop Sample Site","navposition":"left","html5":"0"}'),
(8, 'ja_purity', 0, '0', 'ja_purity', ''),
(9, 'rhuk_milkyway', 0, '0', 'rhuk_milkyway', ''),
(17, 'test', 0, '0', 'test - Default', '{"settings":""}'),
(18, 'new_vision', 0, '1', 'new_vision - Default', '{"settings":""}'),
(20, 'protostar', 0, '0', 'protostar - Default', '{"templateColor":"","logoFile":"","googleFont":"1","googleFontName":"Open+Sans","fluidContainer":"0"}'),
(21, 'isis', 1, '1', 'isis - Default', '{"templateColor":"","logoFile":""}'),
(22, 'beez3', 0, '0', 'beez3 - Default', '{"wrapperSmall":53,"wrapperLarge":72,"logo":"","sitetitle":"","sitedescription":"","navposition":"center","bootstrap":"","templatecolor":"nature","headerImage":"","backgroundcolor":"#eee"}');

-- --------------------------------------------------------

--
-- Table structure for table `#__ucm_content`
--

DROP TABLE IF EXISTS `#__ucm_content`;
CREATE TABLE IF NOT EXISTS `#__ucm_content` (
  `core_content_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `core_type_alias` varchar(255) NOT NULL DEFAULT '' COMMENT 'FK to the content types table',
  `core_title` varchar(255) NOT NULL,
  `core_alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `core_body` mediumtext NOT NULL,
  `core_state` tinyint(1) NOT NULL DEFAULT '0',
  `core_checked_out_time` varchar(255) NOT NULL DEFAULT '',
  `core_checked_out_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `core_access` int(10) unsigned NOT NULL DEFAULT '0',
  `core_params` text NOT NULL,
  `core_featured` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `core_metadata` varchar(2048) NOT NULL COMMENT 'JSON encoded metadata properties.',
  `core_created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `core_created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `core_created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `core_modified_user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Most recent user that modified',
  `core_modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `core_language` char(7) NOT NULL,
  `core_publish_up` datetime NOT NULL,
  `core_publish_down` datetime NOT NULL,
  `core_content_item_id` int(10) unsigned DEFAULT NULL COMMENT 'ID from the individual type table',
  `asset_id` int(10) unsigned DEFAULT NULL COMMENT 'FK to the #__assets table.',
  `core_images` text NOT NULL,
  `core_urls` text NOT NULL,
  `core_hits` int(10) unsigned NOT NULL DEFAULT '0',
  `core_version` int(10) unsigned NOT NULL DEFAULT '1',
  `core_ordering` int(11) NOT NULL DEFAULT '0',
  `core_metakey` text NOT NULL,
  `core_metadesc` text NOT NULL,
  `core_catid` int(10) unsigned NOT NULL DEFAULT '0',
  `core_xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `core_type_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`core_content_id`),
  KEY `tag_idx` (`core_state`,`core_access`),
  KEY `idx_access` (`core_access`),
  KEY `idx_alias` (`core_alias`),
  KEY `idx_language` (`core_language`),
  KEY `idx_title` (`core_title`),
  KEY `idx_modified_time` (`core_modified_time`),
  KEY `idx_created_time` (`core_created_time`),
  KEY `idx_content_type` (`core_type_alias`),
  KEY `idx_core_modified_user_id` (`core_modified_user_id`),
  KEY `idx_core_checked_out_user_id` (`core_checked_out_user_id`),
  KEY `idx_core_created_user_id` (`core_created_user_id`),
  KEY `idx_core_type_id` (`core_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Contains core content data in name spaced fields' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `#__updates`
--

DROP TABLE IF EXISTS `#__updates`;
CREATE TABLE IF NOT EXISTS `#__updates` (
  `update_id` int(11) NOT NULL AUTO_INCREMENT,
  `update_site_id` int(11) DEFAULT '0',
  `extension_id` int(11) DEFAULT '0',
  `name` varchar(100) DEFAULT '',
  `description` text NOT NULL,
  `element` varchar(100) DEFAULT '',
  `type` varchar(20) DEFAULT '',
  `folder` varchar(20) DEFAULT '',
  `client_id` tinyint(3) DEFAULT '0',
  `version` varchar(10) DEFAULT '',
  `data` text NOT NULL,
  `detailsurl` text NOT NULL,
  `infourl` text NOT NULL,
  PRIMARY KEY (`update_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Available Updates' AUTO_INCREMENT=50 ;

--
-- Dumping data for table `#__updates`
--

INSERT INTO `#__updates` (`update_id`, `update_site_id`, `extension_id`, `name`, `description`, `element`, `type`, `folder`, `client_id`, `version`, `data`, `detailsurl`, `infourl`) VALUES
(1, 3, 0, 'Romanian', '', 'pkg_ro-RO', 'package', '', 0, '3.1.1.2', '', 'http://update.joomla.org/language/details3/ro-RO_details.xml', ''),
(2, 3, 0, 'Flemish', '', 'pkg_nl-BE', 'package', '', 0, '3.1.1.1', '', 'http://update.joomla.org/language/details3/nl-BE_details.xml', ''),
(3, 3, 0, 'Chinese Traditional', '', 'pkg_zh-TW', 'package', '', 0, '3.1.0.1', '', 'http://update.joomla.org/language/details3/zh-TW_details.xml', ''),
(4, 3, 0, 'French', '', 'pkg_fr-FR', 'package', '', 0, '3.1.1.1', '', 'http://update.joomla.org/language/details3/fr-FR_details.xml', ''),
(5, 3, 0, 'Galician', '', 'pkg_gl-ES', 'package', '', 0, '3.0.2.2', '', 'http://update.joomla.org/language/details3/gl-ES_details.xml', ''),
(6, 3, 0, 'German', '', 'pkg_de-DE', 'package', '', 0, '3.1.1.1', '', 'http://update.joomla.org/language/details3/de-DE_details.xml', ''),
(7, 3, 0, 'Hebrew', '', 'pkg_he-IL', 'package', '', 0, '3.1.1.1', '', 'http://update.joomla.org/language/details3/he-IL_details.xml', ''),
(8, 3, 0, 'Hungarian', '', 'pkg_hu-HU', 'package', '', 0, '3.1.1.1', '', 'http://update.joomla.org/language/details3/hu-HU_details.xml', ''),
(9, 3, 0, 'Afrikaans', '', 'pkg_af-ZA', 'package', '', 0, '3.1.1.1', '', 'http://update.joomla.org/language/details3/af-ZA_details.xml', ''),
(10, 3, 0, 'Arabic Unitag', '', 'pkg_ar-AA', 'package', '', 0, '3.1.1.1', '', 'http://update.joomla.org/language/details3/ar-AA_details.xml', ''),
(11, 3, 0, 'Belarusian', '', 'pkg_be-BY', 'package', '', 0, '3.0.2.1', '', 'http://update.joomla.org/language/details3/be-BY_details.xml', ''),
(12, 3, 0, 'Bulgarian', '', 'pkg_bg-BG', 'package', '', 0, '3.0.3.1', '', 'http://update.joomla.org/language/details3/bg-BG_details.xml', ''),
(13, 3, 0, 'Catalan', '', 'pkg_ca-ES', 'package', '', 0, '3.1.0.1', '', 'http://update.joomla.org/language/details3/ca-ES_details.xml', ''),
(14, 3, 0, 'Chinese Simplified', '', 'pkg_zh-CN', 'package', '', 0, '3.1.1.2', '', 'http://update.joomla.org/language/details3/zh-CN_details.xml', ''),
(15, 3, 0, 'Croatian', '', 'pkg_hr-HR', 'package', '', 0, '3.1.1.1', '', 'http://update.joomla.org/language/details3/hr-HR_details.xml', ''),
(16, 3, 0, 'Danish', '', 'pkg_da-DK', 'package', '', 0, '3.1.1.1', '', 'http://update.joomla.org/language/details3/da-DK_details.xml', ''),
(17, 3, 0, 'Dutch', '', 'pkg_nl-NL', 'package', '', 0, '3.1.1.1', '', 'http://update.joomla.org/language/details3/nl-NL_details.xml', ''),
(18, 3, 0, 'English AU', '', 'pkg_en-AU', 'package', '', 0, '3.1.0.1', '', 'http://update.joomla.org/language/details3/en-AU_details.xml', ''),
(19, 3, 0, 'English US', '', 'pkg_en-US', 'package', '', 0, '3.1.0.1', '', 'http://update.joomla.org/language/details3/en-US_details.xml', ''),
(20, 3, 0, 'Estonian', '', 'pkg_et-EE', 'package', '', 0, '3.0.2.1', '', 'http://update.joomla.org/language/details3/et-EE_details.xml', ''),
(21, 3, 0, 'Italian', '', 'pkg_it-IT', 'package', '', 0, '3.1.1.1', '', 'http://update.joomla.org/language/details3/it-IT_details.xml', ''),
(22, 3, 0, 'Japanese', '', 'pkg_ja-JP', 'package', '', 0, '3.1.1.1', '', 'http://update.joomla.org/language/details3/ja-JP_details.xml', ''),
(23, 3, 0, 'Korean', '', 'pkg_ko-KR', 'package', '', 0, '3.1.0.1', '', 'http://update.joomla.org/language/details3/ko-KR_details.xml', ''),
(24, 3, 0, 'Kurdish Sorani', '', 'pkg_ckb-IQ', 'package', '', 0, '3.0.2.1', '', 'http://update.joomla.org/language/details3/ckb-IQ_details.xml', ''),
(25, 3, 0, 'Latvian', '', 'pkg_lv-LV', 'package', '', 0, '3.1.0.1', '', 'http://update.joomla.org/language/details3/lv-LV_details.xml', ''),
(26, 3, 0, 'Macedonian', '', 'pkg_mk-MK', 'package', '', 0, '3.1.0.1', '', 'http://update.joomla.org/language/details3/mk-MK_details.xml', ''),
(27, 3, 0, 'Norwegian Bokmal', '', 'pkg_nb-NO', 'package', '', 0, '3.1.1.1', '', 'http://update.joomla.org/language/details3/nb-NO_details.xml', ''),
(28, 3, 0, 'Persian', '', 'pkg_fa-IR', 'package', '', 0, '3.1.1.1', '', 'http://update.joomla.org/language/details3/fa-IR_details.xml', ''),
(29, 3, 0, 'Polish', '', 'pkg_pl-PL', 'package', '', 0, '3.1.1.1', '', 'http://update.joomla.org/language/details3/pl-PL_details.xml', ''),
(30, 3, 0, 'Portuguese', '', 'pkg_pt-PT', 'package', '', 0, '3.0.2.2', '', 'http://update.joomla.org/language/details3/pt-PT_details.xml', ''),
(31, 3, 0, 'Russian', '', 'pkg_ru-RU', 'package', '', 0, '3.0.3.1', '', 'http://update.joomla.org/language/details3/ru-RU_details.xml', ''),
(32, 3, 0, 'Scottish Gaelic', '', 'pkg_gd-GB', 'package', '', 0, '3.1.0.1', '', 'http://update.joomla.org/language/details3/gd-GB_details.xml', ''),
(33, 3, 0, 'Slovak', '', 'pkg_sk-SK', 'package', '', 0, '3.1.0.1', '', 'http://update.joomla.org/language/details3/sk-SK_details.xml', ''),
(34, 3, 0, 'Swedish', '', 'pkg_sv-SE', 'package', '', 0, '3.1.0.1', '', 'http://update.joomla.org/language/details3/sv-SE_details.xml', ''),
(35, 3, 0, 'Syriac', '', 'pkg_sy-IQ', 'package', '', 0, '3.0.3.1', '', 'http://update.joomla.org/language/details3/sy-IQ_details.xml', ''),
(36, 3, 0, 'Tamil', '', 'pkg_ta-IN', 'package', '', 0, '3.1.1.1', '', 'http://update.joomla.org/language/details3/ta-IN_details.xml', ''),
(37, 3, 0, 'Thai', '', 'pkg_th-TH', 'package', '', 0, '3.1.0.1', '', 'http://update.joomla.org/language/details3/th-TH_details.xml', ''),
(38, 3, 0, 'Turkish', '', 'pkg_tr-TR', 'package', '', 0, '3.1.0.1', '', 'http://update.joomla.org/language/details3/tr-TR_details.xml', ''),
(39, 3, 0, 'Ukrainian', '', 'pkg_uk-UA', 'package', '', 0, '3.0.2.1', '', 'http://update.joomla.org/language/details3/uk-UA_details.xml', ''),
(40, 3, 0, 'Uyghur', '', 'pkg_ug-CN', 'package', '', 0, '3.0.2.1', '', 'http://update.joomla.org/language/details3/ug-CN_details.xml', ''),
(41, 3, 0, 'Portuguese Brazil', '', 'pkg_pt-BR', 'package', '', 0, '3.0.3.1', '', 'http://update.joomla.org/language/details3/pt-BR_details.xml', ''),
(42, 3, 0, 'Serbian Latin', '', 'pkg_sr-YU', 'package', '', 0, '3.1.0.1', '', 'http://update.joomla.org/language/details3/sr-YU_details.xml', ''),
(43, 3, 0, 'Spanish', '', 'pkg_es-ES', 'package', '', 0, '3.1.0.1', '', 'http://update.joomla.org/language/details3/es-ES_details.xml', ''),
(44, 3, 0, 'Bosnian', '', 'pkg_bs-BA', 'package', '', 0, '3.1.1.1', '', 'http://update.joomla.org/language/details3/bs-BA_details.xml', ''),
(45, 3, 0, 'Serbian Cyrillic', '', 'pkg_sr-RS', 'package', '', 0, '3.1.0.1', '', 'http://update.joomla.org/language/details3/sr-RS_details.xml', ''),
(46, 3, 0, 'Vietnamese', '', 'pkg_vi-VN', 'package', '', 0, '3.0.3.1', '', 'http://update.joomla.org/language/details3/vi-VN_details.xml', ''),
(47, 3, 0, 'Bahasa Indonesia', '', 'pkg_id-ID', 'package', '', 0, '3.0.3.1', '', 'http://update.joomla.org/language/details3/id-ID_details.xml', ''),
(48, 3, 0, 'Finnish', '', 'pkg_fi-FI', 'package', '', 0, '3.1.0.1', '', 'http://update.joomla.org/language/details3/fi-FI_details.xml', ''),
(49, 3, 0, 'Swahili', '', 'pkg_sw-KE', 'package', '', 0, '3.1.0.1', '', 'http://update.joomla.org/language/details3/sw-KE_details.xml', '');

-- --------------------------------------------------------

--
-- Table structure for table `#__update_sites`
--

DROP TABLE IF EXISTS `#__update_sites`;
CREATE TABLE IF NOT EXISTS `#__update_sites` (
  `update_site_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '',
  `type` varchar(20) DEFAULT '',
  `location` text NOT NULL,
  `enabled` int(11) DEFAULT '0',
  `last_check_timestamp` bigint(20) DEFAULT '0',
  PRIMARY KEY (`update_site_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Update Sites' AUTO_INCREMENT=4 ;

--
-- Dumping data for table `#__update_sites`
--

INSERT INTO `#__update_sites` (`update_site_id`, `name`, `type`, `location`, `enabled`, `last_check_timestamp`) VALUES
(1, 'Joomla Core', 'collection', 'http://update.joomla.org/core/list.xml', 1, 1368885413),
(2, 'Joomla Extension Directory', 'collection', 'http://update.joomla.org/jed/list.xml', 0, 0),
(3, 'Accredited Joomla! Translations', 'collection', 'http://update.joomla.org/language/translationlist_3.xml', 1, 1368885413);

-- --------------------------------------------------------

--
-- Table structure for table `#__update_sites_extensions`
--

DROP TABLE IF EXISTS `#__update_sites_extensions`;
CREATE TABLE IF NOT EXISTS `#__update_sites_extensions` (
  `update_site_id` int(11) NOT NULL DEFAULT '0',
  `extension_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`update_site_id`,`extension_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Links extensions to update sites';

--
-- Dumping data for table `#__update_sites_extensions`
--

INSERT INTO `#__update_sites_extensions` (`update_site_id`, `extension_id`) VALUES
(1, 700),
(2, 700),
(3, 600);

-- --------------------------------------------------------

--
-- Table structure for table `#__usergroups`
--

DROP TABLE IF EXISTS `#__usergroups`;
CREATE TABLE IF NOT EXISTS `#__usergroups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Adjacency List Reference Id',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `title` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_usergroup_parent_title_lookup` (`parent_id`,`title`),
  KEY `idx_usergroup_title_lookup` (`title`),
  KEY `idx_usergroup_adjacency_lookup` (`parent_id`),
  KEY `idx_usergroup_nested_set_lookup` (`lft`,`rgt`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `#__usergroups`
--

INSERT INTO `#__usergroups` (`id`, `parent_id`, `lft`, `rgt`, `title`) VALUES
(1, 0, 1, 16, 'Public'),
(2, 1, 6, 13, 'Registered'),
(3, 2, 7, 12, 'Author'),
(4, 3, 8, 11, 'Editor'),
(5, 4, 9, 10, 'Publisher'),
(6, 1, 2, 5, 'Manager'),
(7, 6, 3, 4, 'Administrator'),
(8, 1, 14, 15, 'Super Users');

-- --------------------------------------------------------

--
-- Table structure for table `#__users`
--

DROP TABLE IF EXISTS `#__users`;
CREATE TABLE IF NOT EXISTS `#__users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(150) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  `block` tinyint(4) NOT NULL DEFAULT '0',
  `sendEmail` tinyint(4) DEFAULT '0',
  `registerDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastvisitDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activation` varchar(100) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  `lastResetTime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Date of last password reset',
  `resetCount` int(11) NOT NULL DEFAULT '0' COMMENT 'Count of password resets since lastResetTime',
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`),
  KEY `idx_block` (`block`),
  KEY `username` (`username`),
  KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=705 ;



DROP TABLE IF EXISTS `#__user_notes`;
CREATE TABLE IF NOT EXISTS `#__user_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(100) NOT NULL DEFAULT '',
  `body` text NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_user_id` int(10) unsigned NOT NULL,
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `review_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_category_id` (`catid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `#__user_profiles`
--

DROP TABLE IF EXISTS `#__user_profiles`;
CREATE TABLE IF NOT EXISTS `#__user_profiles` (
  `user_id` int(11) NOT NULL,
  `profile_key` varchar(100) NOT NULL,
  `profile_value` varchar(255) NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `idx_user_id_profile_key` (`user_id`,`profile_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Simple user profile storage table';

-- --------------------------------------------------------

--
-- Table structure for table `#__user_usergroup_map`
--

DROP TABLE IF EXISTS `#__user_usergroup_map`;
CREATE TABLE IF NOT EXISTS `#__user_usergroup_map` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Foreign Key to #__users.id',
  `group_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Foreign Key to #__usergroups.id',
  PRIMARY KEY (`user_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `#__viewlevels`;
CREATE TABLE IF NOT EXISTS `#__viewlevels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `title` varchar(100) NOT NULL DEFAULT '',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rules` varchar(5120) NOT NULL COMMENT 'JSON encoded access control.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_assetgroup_title_lookup` (`title`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `#__viewlevels`
--

INSERT INTO `#__viewlevels` (`id`, `title`, `ordering`, `rules`) VALUES
(1, 'Public', 0, '[1]'),
(2, 'Registered', 1, '[6,2,8]'),
(3, 'Special', 2, '[6,3,8]');

-- --------------------------------------------------------

--
-- Table structure for table `#__weblinks`
--

DROP TABLE IF EXISTS `#__weblinks`;
CREATE TABLE IF NOT EXISTS `#__weblinks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(11) NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `url` varchar(250) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `hits` int(11) NOT NULL DEFAULT '0',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `access` int(11) NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  `language` char(7) NOT NULL DEFAULT '',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `metadata` text NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if link is featured.',
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `images` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`state`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_featured_catid` (`featured`,`catid`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `#__weblinks`
--

INSERT INTO `#__weblinks` (`id`, `catid`, `title`, `alias`, `url`, `description`, `hits`, `state`, `checked_out`, `checked_out_time`, `ordering`, `access`, `params`, `language`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `metakey`, `metadesc`, `metadata`, `featured`, `xreference`, `publish_up`, `publish_down`, `version`, `images`) VALUES
(1, 32, 'Joomla!', 'joomla', 'http://www.joomla.org', 'Home of Joomla!', 3, 1, 0, '0000-00-00 00:00:00', 1, 1, '{"target":0}', '', '0000-00-00 00:00:00', 589, '', '0000-00-00 00:00:00', 0, '', '', '', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, ''),
(2, 32, 'php.net', 'php', 'http://www.php.net', 'The language that Joomla! is developed in', 8, 1, 0, '0000-00-00 00:00:00', 3, 1, '{}', '', '0000-00-00 00:00:00', 589, '', '0000-00-00 00:00:00', 0, '', '', '', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, ''),
(3, 32, 'MySQL', 'mysql', 'http://www.mysql.com', 'The database that Joomla! uses', 1, 1, 0, '0000-00-00 00:00:00', 5, 1, '{}', '', '0000-00-00 00:00:00', 589, '', '0000-00-00 00:00:00', 0, '', '', '', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, ''),
(4, 32, 'OpenSourceMatters', 'opensourcematters', 'http://www.opensourcematters.org', 'Home of OSM', 11, 1, 0, '0000-00-00 00:00:00', 2, 1, '{"target":0}', '', '0000-00-00 00:00:00', 589, '', '0000-00-00 00:00:00', 0, '', '', '', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, ''),
(5, 32, 'Joomla! - Forums', 'joomla-forums', 'http://forum.joomla.org', 'Joomla! Forums', 4, 1, 0, '0000-00-00 00:00:00', 4, 1, '{"target":0}', '', '0000-00-00 00:00:00', 589, '', '0000-00-00 00:00:00', 0, '', '', '', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, ''),
(6, 32, 'Ohloh Tracking of Joomla!', 'ohloh-tracking-of-joomla', 'http://www.ohloh.net/projects/20', 'Objective reports from Ohloh about Joomla''s development activity. Joomla! has some star developers with serious kudos.', 1, 1, 0, '0000-00-00 00:00:00', 6, 1, '{"target":0}', '', '0000-00-00 00:00:00', 589, '', '0000-00-00 00:00:00', 0, '', '', '', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
