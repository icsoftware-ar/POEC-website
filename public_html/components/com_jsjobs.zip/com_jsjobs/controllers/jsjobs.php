<?php
/**
 * @Copyright Copyright (C) 2009-2011
 * @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
 + Created by:          Ahmad Bilal
 * Company:		Buruj Solutions
 + Contact:		www.burujsolutions.com , ahmad@burujsolutions.com
 * Created on:	Jan 11, 2009
 ^
 + Project: 		JS Jobs
 * File Name:	controllers/jsjobs.php
 ^ 
 * Description: Controller class for application data
 ^ 
 * History:		NONE
 ^ 
 */
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

class JSJobsControllerJsjobs extends JControllerLegacy
{

	function __construct()
	{
		$user	=& JFactory::getUser();
		if ($user->guest) { // redirect user if not login
			$link = 'index.php?option=com_user';
			$this->setRedirect($link);
		} 

		parent :: __construct();
	}
	function unsubscribeJobAlertSetting (){
		$data = JRequest :: get('post');
		$email = $data['contactemail'];
		global $mainframe;
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->unSubscribeJobAlert($email);
		if($return_value ==1){
			$msg = JText :: _('JS_YOU_UNSUBSCRIBE_SUCCESSFULLY_JOBALERT');
		}elseif($return_value == 3){
			$msg = JText :: _('JS_YOU_ENTER_INCORRECT_EMAIL_JOBALERT');
		}else{
			$msg = JText :: _('JS_ERROR_UNSUBSCRIBE_JOBALERT');
		}

		$link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=jobalertsetting&Itemid='.$Itemid;
		$this->setRedirect(JRoute::_($link), $msg);
	}
	
	function addtofeaturedresumes()
	{
		global $mainframe;
		
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$Itemid =  JRequest::getVar('Itemid');

		$user	=& JFactory::getUser();
		$uid=$user->id;
		$resumeid =  JRequest::getVar('rd','');	
		
		$return_value = $model->storeFeaturedResume($uid,$resumeid);
		if ($return_value == 1)	{
			$msg = JText :: _('JS_FEATURED_RESUME_SAVED');
		}else if ($return_value == 2){
			$msg = JText :: _('JS_FILL_REQ_FIELDS');
		}else if ($return_value == 3){
			$msg = JText :: _('JS_RESUME_NOT_EXIST');
		}else if ($return_value == 5){
			$msg = JText :: _('JS_CAN_NOT_ADD_NEW_FEATURED_RESUME');
		}else if ($return_value == 6){
			$msg = JText :: _('JS_ALREADY_ADDED_FEATURED_RESUME');
		}else{
			$msg = JText :: _('JS_ERROR_SAVING_FEATURED_RESUME');
		}

		$link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=myresumes&Itemid='.$Itemid;
                //$this->setRedirect($link, $msg);
		$this->setRedirect(JRoute::_($link), $msg);
	}
	
	function addtogoldresumes() 
	{
		global $mainframe;
		
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$Itemid =  JRequest::getVar('Itemid');

		$user	=& JFactory::getUser();
		$uid=$user->id;
		$resumeid =  JRequest::getVar('rd','');	
		
		$return_value = $model->storeGoldResume($uid,$resumeid);
		if ($return_value == 1)	{
			$msg = JText :: _('JS_GOLD_RESUME_SAVED');
		}else if ($return_value == 2){
			$msg = JText :: _('JS_FILL_REQ_FIELDS');
		}else if ($return_value == 3){
			$msg = JText :: _('JS_RESUME_NOT_EXIST');
		}else if ($return_value == 5){
			$msg = JText :: _('JS_CAN_NOT_ADD_NEW_GOLD_RESUME');
		}else if ($return_value == 6){
			$msg = JText :: _('JS_ALREADY_ADDED_GOLD_RESUME');
		}else{
			$msg = JText :: _('JS_ERROR_SAVING_GOLD_RESUME');
		}

		$link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=myresumes&Itemid='.$Itemid;
		//$this->setRedirect($link, $msg);
		$this->setRedirect(JRoute::_($link), $msg);
	}
	
	
	
	
	function addtofeaturedcompany() 
	{
		global $mainframe;
		
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$Itemid =  JRequest::getVar('Itemid');

		$user	=& JFactory::getUser();
		$uid=$user->id;
		$companyid =  JRequest::getVar('md','');	
		$packageid =  JRequest::getVar('pk','');	
		$return_value = $model->storeFeaturedCompany($uid, $companyid);
                if ($return_value == 1)	{
			$msg = JText :: _('JS_FEATURED_COMPANY_SAVED');
		}else if ($return_value == 2){
			$msg = JText :: _('JS_FILL_REQ_FIELDS');
		}else if ($return_value == 3){
			$msg = JText :: _('JS_CMPANY_NOT_EXIST');
		}else if ($return_value == 5){
			$msg = JText :: _('JS_CAN_NOT_ADD_NEW_FEATURED_COMPANY');
		}else if ($return_value == 6){
			$msg = JText :: _('JS_ALREADY_ADDED_FEATURED_COMPANY');
		}else{
			$msg = JText :: _('JS_ERROR_SAVING_FEATURED_COMPANY');
		}

		$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=mycompanies&Itemid='.$Itemid;
		//$this->setRedirect($link, $msg);
		$this->setRedirect(JRoute::_($link), $msg);
	}
	
	function addtogoldcompany() 
	{
		global $mainframe;
		
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$Itemid =  JRequest::getVar('Itemid');

		$user	=& JFactory::getUser();
		$uid=$user->id;
		$companyid =  JRequest::getVar('md','');	
		$packageid =  JRequest::getVar('pk','');	
		$return_value = $model->storeGoldCompany($uid, $companyid);
		if ($return_value == 1)	{
			$msg = JText :: _('JS_GOLD_COMPANY_SAVED');
		}else if ($return_value == 2){
			$msg = JText :: _('JS_FILL_REQ_FIELDS');
		}else if ($return_value == 3){
			$msg = JText :: _('JS_COMPANY_NOT_EXIST');
		}else if ($return_value == 5){
			$msg = JText :: _('JS_CAN_NOT_ADD_NEW_GOLD_COMPANY');
		}else if ($return_value == 6){
			$msg = JText :: _('JS_ALREADY_ADDED_GOLD_COMPANY');
		}else{
			$msg = JText :: _('JS_ERROR_SAVING_GOLD_COMPANY');
		}

		$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=mycompanies&Itemid='.$Itemid;
		//$this->setRedirect($link, $msg);
		$this->setRedirect(JRoute::_($link), $msg);
	}
	
	
	function addtofeaturedjobs() //save employer package
	{
		global $mainframe;
		
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$Itemid =  JRequest::getVar('Itemid');

		$user	=& JFactory::getUser();
		$uid=$user->id;
		$jobid =  JRequest::getVar('oi','');	
		
		$return_value = $model->storeFeaturedJobs($uid, $jobid);
                if ($return_value == 1)	{
			$msg = JText :: _('JS_FEATURED_JOB_SAVED');
		}else if ($return_value == 2){
			$msg = JText :: _('JS_FILL_REQ_FIELDS');
		}else if ($return_value == 3){
			$msg = JText :: _('JS_JOB_NOT_APPROVED');
		}else if ($return_value == 5){
			$msg = JText :: _('JS_CAN_NOT_ADD_NEW_FEATURED_JOB');
		}else if ($return_value == 6){
			$msg = JText :: _('JS_ALREADY_ADDED_FEATURED_JOB');
		}else{
			$msg = JText :: _('JS_ERROR_SAVING_FEATURED_JOB');
		}

		$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=myjobs&Itemid='.$Itemid;
		//$this->setRedirect($link, $msg);
		$this->setRedirect(JRoute::_($link), $msg);
	}
	function addtogoldjobs() 
	{
		global $mainframe;
		
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$Itemid =  JRequest::getVar('Itemid');
		
		$user	=& JFactory::getUser();
		$uid=$user->id;
		$jobid =  JRequest::getVar('oi','');	
		
		$return_value = $model->storeGoldJobs($uid, $jobid);
		if ($return_value == 1)	{
			$msg = JText :: _('JS_GOLD_JOB_SAVED');
		}else if ($return_value == 2){
			$msg = JText :: _('JS_FILL_REQ_FIELDS');
		}else if ($return_value == 3){
			$msg = JText :: _('JS_JOB_NOT_APPROVED');
		}else if ($return_value == 5){
			$msg = JText :: _('JS_CAN_NOT_ADD_NEW_GOLD_JOB');
		}else if ($return_value == 6){
			$msg = JText :: _('JS_ALREADY_ADDED_GOLD_JOB');
		}else{
			$msg = JText :: _('JS_ERROR_SAVING_GOLD_JOB');
		}

		$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=myjobs&Itemid='.$Itemid;
		//$this->setRedirect($link, $msg);
		$this->setRedirect(JRoute::_($link), $msg);
	}
	function saveemployerpayment() //save employer payment
	{
		global $mainframe;
                $data = JRequest :: get('post');
                $packageid = $data['packageid'];

                ?>
                <div width="100%" align="center">
                <br><br><br><h2>Please wait</h2>
                
                <img src="components/com_jsjobs/images/working.gif" border="0" >
                </div>
                <?php

                $reser_med = date('misyHdmy');
                $reser_med = md5($reser_med);
                $reser_med = md5($reser_med);
                $reser_med1 = substr($reser_med,0,5);
                $reser_med2 .= substr($reser_med,7,13);
                $string = md5(time());
                $string = md5(time());
                $reser_start =	substr($string,0,3);
                $reser_end = substr($string,3,2);
                $reference = $reser_start.$reser_med1.$reser_med2.$reser_end;
                $_SESSION['jsjobs_rfd_emppack'] = $reference;


		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$Itemid =  JRequest::getVar('Itemid');
		
		$return_value = $model->storeEmployerPackageHistory($reference,0,$data);
		if ($return_value == 1)	{
			$msg = JText :: _('JS_PACKAGE_SAVED');
                        $this->redirectforpayment(1,$packageid,$reference);
                        //$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=purchasehistory&Itemid='.$Itemid;
		}else if ($return_value == 2){
			$msg = JText :: _('JS_FILL_REQ_FIELDS');
                        $link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=package_buynow&Itemid='.$Itemid;
                        $this->setRedirect(JRoute::_($link), $msg);
		}else if ($return_value == 5){
			$msg = JText :: _('JS_CAN_NOT_GET_FREE_PACKAGE_MORE_THEN_ONCE');
                        $link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=packages&Itemid='.$Itemid;
        		$this->setRedirect(JRoute::_($link), $msg);
		}else{
			$msg = JText :: _('JS_ERROR_SAVING_PACKAGE');
                        $link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=package_buynow&Itemid='.$Itemid;
                        $this->setRedirect(JRoute::_($link), $msg);
		}
                //$this->setRedirect($link, $msg);


	}

        function redirectforpayment($packagefor,$packageid,$reference)
        {
			
            $model = $this->getModel('jsjobs', 'JSJobsModel');
            $Itemid =  JRequest::getVar('Itemid');
            
            $host = $_SERVER['HTTP_HOST'];
            $self = $_SERVER['PHP_SELF'];
            $url = "http://$host$self";

            $result = $model->getConfigByFor('payment');
            if ($packagefor == 1) $package = $model->getEmployerPackageInfoById($packageid); // employer
            elseif ($packagefor == 2) $package = $model->getJobSeekerPackageInfoById($packageid); // jobseeker
            if(isset($package) == false){
		$msg = JText :: _('JS_ERROR_SAVING_PACKAGE');
                if ($packagefor == 1) $link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=package_buynow&Itemid='.$Itemid;
                elseif ($packagefor == 2) $link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=package_buynow&Itemid='.$Itemid;
                //$this->setRedirect($link, $msg);
		$this->setRedirect(JRoute::_($link), $msg);

            }
            $defaultmsg = JText :: _('JS_PACKAGE_SAVED');
            if ($packagefor == 1) $defaultlink = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=purchasehistory&Itemid='.$Itemid;
            elseif ($packagefor == 2) $defaultlink = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=purchasehistory&Itemid='.$Itemid;

            $purpose = $package->name;
            if ($package->price != 0){
               $curdate = date('Y-m-d H:i:s');
                if (($package->discountstartdate <= $curdate) && ($package->discountenddate >= $curdate)){
                     if($package->discounttype == 1){
                         $discountamount = ($package->price * $package->discount)/100;
                          $amount = $package->price - $discountamount;

                     }else{
                         $amount = $package->price - $package->discount;

                     }
                }else $amount = $package->price;
            }else{
        	$msg = JText :: _('JS_PACKAGE_SAVED');
                if ($packagefor == 1) $link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=purchasehistory&Itemid='.$Itemid;
                elseif ($packagefor == 2) $link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=purchasehistory&Itemid='.$Itemid;
                //$this->setRedirect($link, $msg);
		$this->setRedirect(JRoute::_($link), $msg);

            }
            
            if ($packagefor == 1) $sopping_url = $url.'?option=com_jsjobs&view=employer&layout=packages&Itemid='. $Itemid;
            elseif ($packagefor == 2) $sopping_url = $url.'?option=com_jsjobs&view=jobseeker&layout=packages&Itemid='. $Itemid;

            if( $result['payment_method'] == 'paypal'){ //paypal
                $paypal_account= $result['payment_paypalaccount'];
                $currency_code= $result['payment_currency'];
                $successeful_url = $url.'?option=com_jsjobs&task=confirmpaymnt&for='.$packagefor.'&fr='.$reference.'&Itemid='. $Itemid;
                $cancel_url= $result['payment_cancelurl'];
                $show_description= $result['payment_showdescription'];
                $description= $result['payment_description'];
                $testmode = $result['payment_test_mode'];
                if( $result['payment_showfooter'] == '1') $show_footer= 'show_footer';
                else  $show_footer= 'hide_footer';

                if ($testmode == '1') $act = "https://www.sandbox.paypal.com/cgi-bin/webscr";
                      else $act = "https://www.paypal.com/cgi-bin/webscr"; ?>
                <form action="<?php echo $act; ?>" method="post" name="adminForm" >
                <input type="hidden" name="business" value="<?php echo $paypal_account; ?>">
                <input type="hidden" name="cmd" value="_cart">
                <input type="hidden" name="add" value="1">
                <input type="hidden" name="item_name" value="<?php echo $purpose; ?>">
                <input type="hidden" name="amount" value="<?php echo $amount; ?>">
                <input type="hidden" name="currency_code" value="<?php echo $currency_code; ?>">
                <input type="hidden" name="return" value="<?php echo $successeful_url; ?>">
                <input type="hidden" name="notify_url" value="<?php echo $successeful_url; ?>">
                <input type="hidden" name="cancel_return" value="<?php echo $cancel_url; ?>">
                <input type="hidden" name="rm" value="2">
                <input type="hidden" name="shopping_url" value="<?php echo $sopping_url; ?>"><!-- Display the payment button. -->
                            <script language=Javascript>
                                    //document.adminForm.shopping_url.value = window.location.href;
                                    document.adminForm.submit();
                            </script>
                </form>
            <?php
            }elseif( $result['payment_method'] == 'fastspring'){ //fast spring
                if ($package->fastspringlink) $this->setRedirect($package->fastspringlink); // not empty
                else $this->setRedirect(JRoute::_($defaultlink), $defaultmsgmsg);
            }elseif( $result['payment_method'] == 'authorizenet'){ //authorize.net
                //<form name="PrePage" method = "post" action = "https://scotest.authorize.net/payment/CatalogPayment.aspx">
                ?>
                    <form name="PrePage" method = "post" action = "https://Simplecheckout.authorize.net/payment/CatalogPayment.aspx">
                    <input type = "hidden" name = "LinkId" value ="<?php echo $package->otherpaymentlink; ?>" />
                    <script language=Javascript>
                            document.PrePage.submit();
                    </script>
                </form>
                <?php
            }elseif( $result['payment_method'] == 'pagseguro'){ //pagseguro ?>
                    <form name="pagseguro"  method="post" action="https://pagseguro.uol.com.br/checkout/checkout.jhtml">
                    <input type="hidden" name="email_cobranca" value="<?php echo $result['pagseguro_email']; ?>">
                    <input type="hidden" name="tipo" value="CP">
                    <input type="hidden" name="moeda" value="BRL">

                    <input type="hidden" name="item_id_1" value="1">
                    <input type="hidden" name="item_descr_1" value="<?php echo $package->title; ?>">
                    <input type="hidden" name="item_quant_1" value="1">
                    <input type="hidden" name="item_valor_1" value="<?php echo number_format($amount, 2); ?>">
                    <input type="hidden" name="item_frete_1" value="0">
                    <input type="hidden" name="item_peso_1" value="0">


                    <input type="hidden" name="tipo_frete" value="EN">
                <script language=Javascript>
                        document.pagseguro.submit();
                </script>
                    </form>
            <?php
            }elseif( $result['payment_method'] == '2checkout'){ //2checkout
                if($package->otherpaymentlink) $this->setRedirect($package->otherpaymentlink); // not empty
                else $this->setRedirect(JRoute::_($defaultlink), $defaultmsgmsg);
            }elseif( $result['payment_method'] == 'other'){ //other
                if($package->otherpaymentlink) $this->setRedirect($package->otherpaymentlink); // not empty
                else $this->setRedirect(JRoute::_($defaultlink), $defaultmsgmsg);
            }else{
		$this->setRedirect(JRoute::_($defaultlink), $defaultmsgmsg);
            }

        }

        function confirmpaymnt() //confirm paypal payment
        {
            $model = $this->getModel('jsjobs', 'JSJobsModel');
            $Itemid =  JRequest::getVar('Itemid');
            $result = $model->getConfigByFor('payment');
                // paypal code

		if ($_GET['fr'] != "") {
			$referenceid = $_GET['fr'];
		}
		if ($_GET['for'] != "") $for = $_GET['for'];
		$req = 'cmd=_notify-synch';

		if ($_GET['tx'] != "")
			$tx_token = $_GET['tx'];
		if (isset($_SESSION['jsjobs_rq_session'])) $_SESSION['jsjobs_rq_session']='';

		$auth_token = $result['payment_authtoken'];
		$req .= "&tx=$tx_token&at=$auth_token";

		// post back to PayPal system to validate
		$header .= "POST /cgi-bin/webscr HTTP/1.0\r\n";
		$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
		$header .= "Content-Length: " . strlen($req) . "\r\n\r\n";
		$testmode = $result['payment_test_mode'];
		if ($testmode == '1') $act = "www.sandbox.paypal.com";
		  else $act = "www.paypal.com";
		//$fp = fsockopen ("$act", 80, $errno, $errstr, 30);
		$fp = fsockopen('ssl://'.$act,"443",$err_num,$err_str,30);

		// If possible, securely post back to paypal using HTTPS
		// Your PHP server will need to be SSL enabled
		// $fp = fsockopen ('ssl://www.paypal.com', 443, $errno, $errstr, 30);

		if (!$fp) {
			// HTTP ERROR
		} else {
			fputs ($fp, $header . $req);
			// read the body data
			$res = '';
			$headerdone = false;
			while (!feof($fp)) {
				$line = fgets ($fp, 1024);
				if (strcmp($line, "\r\n") == 0) {
					// read the header
					$headerdone = true;
				}
				else if ($headerdone)
				{
					// header has been read. now read the contents
					$res .= $line;
				}
			}

			// parse the data
			$lines = explode("\n", $res);
			$keyarray = array();
			$paypalstatus = $lines[0];
			$date = date('Y-m-d H:i:s');
			$status = 1;
			if (strcmp ($lines[0], "SUCCESS") == 0) {
				for ($i=1; $i<count($lines);$i++){
					list($key,$val) = explode("=", $lines[$i]);
					$keyarray[urldecode($key)] = urldecode($val);
				}
				// check the payment_status is Completed
				// check that txn_id has not been previously processed
				// check that receiver_email is your Primary PayPal email
				// check that payment_amount/payment_currency are correct
				// process payment
				$firstname = $keyarray['first_name'];
				$lastname = $keyarray['last_name'];
				$itemname = $keyarray['item_name'];
				$amount = $keyarray['payment_gross'];
				$email = $keyarray['payer_email'];

				$itemname = $keyarray['item_name1'];

                            if ($for == 1)$return_value =  $model->updateEmployerPackageHistory($firstname,$lastname, $email, $amount, $referenceid, $tx_token, $date, $paypalstatus,$status);
                            elseif ($for == 2)$return_value =  $model->updateJobSeekerPackageHistory($firstname,$lastname, $email, $amount, $referenceid, $tx_token, $date, $paypalstatus,$status);

				$msg = JText :: _('JS_THNAK_YOU_TO_BUY_PACKAGE');
                if ($for == 1) $link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=purchasehistory&Itemid='.$Itemid;
                elseif ($for == 2) $link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=purchasehistory&Itemid='.$Itemid;
			}
			else if (strcmp ($lines[0], "FAIL") == 0) {
				$msg = JText :: _('JS_WE_ARE_UNABLE_TO_VERIFY_PAYMENT');
                if ($for == 1) $link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=purchasehistory&Itemid='.$Itemid;
                elseif ($for == 2) $link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=purchasehistory&Itemid='.$Itemid;
			}


		}

		fclose ($fp);
		$this->setRedirect(JRoute::_($link), $msg);

        }

        function savejobseekerpayment() //save job seeker payment
	{
		global $mainframe;
                $data = JRequest :: get('post');
                $packageid = $data['packageid'];

                ?>
                <div width="100%" align="center">
                <br><br><br><h2>Please wait</h2>

                <img src="components/com_jsjobs/images/working.gif" border="0" >
                </div>
                <?php

                $reser_med = date('misyHdmy');
                $reser_med = md5($reser_med);
                $reser_med = md5($reser_med);
                $reser_med1 = substr($reser_med,0,5);
                $reser_med2 .= substr($reser_med,7,13);
                $string = md5(time());
                $string = md5(time());
                $reser_start =	substr($string,0,3);
                $reser_end = substr($string,3,2);
                $reference = $reser_start.$reser_med1.$reser_med2.$reser_end;
                $_SESSION['jsjobs_rfd_emppack'] = $reference;


		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$Itemid =  JRequest::getVar('Itemid');
		
		
                $return_value = $model->storeJobSeekerPackageHistory($reference,0,$data);
		if ($return_value == 1)	{
                        $this->redirectforpayment(2,$packageid,$reference);
			$msg = JText :: _('JS_PACKAGE_SAVED');
                        //$link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=purchasehistory&Itemid='.$Itemid;
		}else if ($return_value == 2){
			$msg = JText :: _('JS_FILL_REQ_FIELDS');
                        $link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=packages&Itemid='.$Itemid;
        		$this->setRedirect(JRoute::_($link), $msg);
		}else if ($return_value == 5){
			$msg = JText :: _('JS_CAN_NOT_GET_FREE_PACKAGE_MORE_THEN_ONCE');
                        $link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=packages&Itemid='.$Itemid;
        		$this->setRedirect(JRoute::_($link), $msg);
		}else{
			$msg = JText :: _('JS_ERROR_SAVING_PACKAGE');
                        $link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=packages&Itemid='.$Itemid;
        		$this->setRedirect(JRoute::_($link), $msg);
		}
		//$this->setRedirect($link, $msg);
		//$this->setRedirect(JRoute::_($link), $msg);
		
	}

	function jobapply()
	{
		global $mainframe;
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$session = &JFactory::getSession();
		$uid = &JRequest::getString('uid','none');
		
		$Itemid =  JRequest::getVar('Itemid');

		$return_value = $model->jobapply();
		if ($return_value == 1)	{
			$msg = JText :: _('APPLICATION_APPLIED');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=myappliedjobs&uid='.$uid.'&Itemid='.$Itemid;
		}else if ($return_value == 3){
			$msg = JText :: _('JS_ALREADY_APPLY_JOB');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=myappliedjobs&Itemid='.$Itemid;
		}else{
			$msg = JText :: _('ERROR_APPLING_APPLICATION');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=myappliedjobs&uid='.$uid.'&Itemid='.$Itemid;
		}
		///final redirect
		$this->setRedirect($link, $msg);
	}
/* STRAT EXPORT RESUMES */
	function exportresume(){
		$jobid =  JRequest::getVar('bd');
		$model =  $this->getModel('jsjobs','JSJobsModel');
		$return_value = $model->setExport($jobid);
		if($return_value == true){
			// Push the report now!
			$msg = JText ::_('JS_RESUME_EXPORT');
			$name = 'export-resume';
			header("Content-type: application/octet-stream");
			header("Content-Disposition: attachment; filename=".$name.".xls");
			header("Pragma: no-cache");
			header("Expires: 0");
			header("Lacation: excel.htm?id=yes");
			print $return_value ;
			die();   
			
		}else{
			//echo $return_value ;
			$msg = JText ::_('JS_RESUME_NOT_EXPORT');
		}		
		$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=job_appliedapplications&bd='.$jobid;
		$this->setRedirect($link, $msg);
	}
/* END EXPORT RESUMES */
	
	function showImage(){
   }
	

	function savejob() //save job
	{
		global $mainframe;
		
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$session = &JFactory::getSession();
		$uid = &JRequest::getString('uid','none');
		
		$Itemid =  JRequest::getVar('Itemid');
		
		$return_value = $model->storeJob();
		if ($return_value == 1)	{
			$msg = JText :: _('JOB_SAVED');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=myjobs&Itemid='.$Itemid;
		}else if ($return_value == 2){
			$msg = JText :: _('JS_FILL_REQ_FIELDS');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=formjob&Itemid='.$Itemid;
		}else if ($return_value == 11){ // start date not in oldate
			$msg = JText :: _('JS_START_DATE_NOT_OLD_DATE');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=formjob&Itemid='.$Itemid;
		}else if ($return_value == 12){
			$msg = JText :: _('JS_START_DATE_NOT_LESS_STOP_DATE');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=formjob&Itemid='.$Itemid;
		}else{
			$msg = JText :: _('ERROR_SAVING_JOB');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=myjobs&Itemid='.$Itemid;
		}
		//$this->setRedirect($link, $msg);
		$this->setRedirect(JRoute::_($link), $msg);
	}

	function savejobvisitor() //save company and job for visitor
	{
		global $mainframe;
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$session = &JFactory::getSession();
		$uid = &JRequest::getString('uid','none');

		$Itemid =  JRequest::getVar('Itemid');

		$return_value = $model->storeCompanyJobForVisitor();
		$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=controlpanel&Itemid='.$Itemid;
		if ($return_value == 1)	{ 
			$msg = JText :: _('JOB_SAVED');
		}elseif($return_value == 5){
			$msg = JText :: _('JS_ERROR_LOGO_SIZE_LARGER');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=formjob_visitor&Itemid='.$Itemid;
		}elseif($return_value == 2){
			$msg = JText :: _('JS_ERROR_INCORRECT_CAPTCHA_CODE');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=formjob_visitor&Itemid='.$Itemid;
		}else{	
			$msg = JText :: _('ERROR_SAVING_JOB');
		}
		//$this->setRedirect($link, $msg);
		$this->setRedirect(JRoute::_($link), $msg);

	}

	function savecompany() //save company
	{
		global $mainframe;
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$session = &JFactory::getSession();
		$uid = &JRequest::getString('uid','none');
		
		$Itemid =  JRequest::getVar('Itemid');
		
		$return_value = $model->storeCompany();
		$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=mycompanies&Itemid='.$Itemid;
		if ($return_value == 1)	{ $msg = JText :: _('COMPANY_SAVED');
		}else if ($return_value == 2){	
			$msg = JText :: _('JS_FILL_REQ_FIELDS');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=formcompany&Itemid='.$Itemid;
		}else if ($return_value == 5){ 
			$msg = JText :: _('JS_ERROR_LOGO_SIZE_LARGER');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=formcompany&Itemid='.$Itemid;
		}else{	$msg = JText :: _('ERROR_SAVING_COMPANY');
		}
		//$this->setRedirect($link, $msg);
		$this->setRedirect(JRoute::_($link), $msg);

	}
    function savejobalertsetting() //save company
	{
		global $mainframe;
                $data = JRequest:: get('post');
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		
		$Itemid =  JRequest::getVar('Itemid');
		$return_value = $model->storeJobAlertSetting();
		$link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=jobalertsetting&Itemid='.$Itemid;
		if ($return_value == 1)	{ $msg = JText :: _('JS_JOB_ALERT_SETTING_SAVED');}
                else if ($return_value == 2){	$msg = JText :: _('JS_FILL_REQ_FIELDS'); }
                else if ($return_value == 3){	$msg = JText :: _('JS_EMAIL_ALREADY_EXISTS'); }
                else{	$msg = JText :: _('JS_ERROR_SAVING_JOB_ALERT_SETTING');	}
                //echo '<br>'.$return_value;
		$this->setRedirect(JRoute::_($link), $msg);

	}
        function saveresumecomments() // save resume comments
	{
		global $mainframe;
		$data = JRequest :: get('post');
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$return_value = $model->storeResumeComments();
		$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=job_appliedapplications&bd='.$data['jobid'];
		if ($return_value == 1)	$msg = JText :: _('JS_RESUME_COMMENTS_SAVE');
		else	$msg = JText :: _('JS_ERROR_SAVING_RESUME_RESUME_COMMENTS');
		
		$this->setRedirect(JRoute::_($link), $msg);
		//$this->setRedirect($link, $msg);

	}
        function getresumecomments()  {
            global $mainframe;
			
			$mainframe = &JFactory::getApplication();
            $user	=& JFactory::getUser();
            $jobapplyid=JRequest::getVar( 'jobapplyid');
            $model = $this->getModel('jsjobs', 'JSJobsModel');
            $returnvalue = $model->getResumeCommentsAJAX($user->id,$jobapplyid);

            echo $returnvalue;
            $mainframe->close();
        }
        function saveresumerating()  {
            global $mainframe;
			$mainframe = &JFactory::getApplication();
            $user=& JFactory::getUser();
            $uid=$user->id;
            $ratingid=JRequest::getVar( 'ratingid');
            $jobid=JRequest::getVar( 'jobid');
            $resumeid=JRequest::getVar( 'resumeid');
            $newrating=JRequest::getVar( 'newrating');
            $model = $this->getModel('jsjobs', 'JSJobsModel');
            $returnvalue = $model->storeResumeRating($uid,$ratingid,$jobid,$resumeid,$newrating);

            echo $returnvalue;
            $mainframe->close();
        }
        function savefolder() // save folder
	{
		global $mainframe;

		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$Itemid =  JRequest::getVar('Itemid');

		$return_value = $model->storeFolder();
		$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=myfolders&Itemid='.$Itemid;
		if ($return_value == 1)	{ $msg = JText :: _('JS_FOLDER_SAVED');
		}else if ($return_value == 2){
			$msg = JText :: _('JS_FILL_REQ_FIELDS');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=formfolder&Itemid='.$Itemid;
		}elseif($return_value == 3){
                    $msg = JText::_('JS_FOLDER_ALREADY_EXIST');
		}else{	$msg = JText :: _('ERROR_SAVING_FOLDERS');
		}
		//$this->setRedirect($link, $msg);
		$this->setRedirect(JRoute::_($link), $msg);

	}
        function saveresumefolder() // save folder
	{
		global $mainframe;
		$data = JRequest :: get('post');
		$model = $this->getModel('jsjobs', 'JSJobsModel');
                $Itemid =  JRequest::getVar('Itemid');

		$return_value = $model->storeFolderResume();
		$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=job_appliedapplications&bd='.$data['jobid'].'&Itemid='.$Itemid;
		if ($return_value == 1)	{ $msg = JText :: _('JS_RESUME_FOLDER_SAVED');
		}elseif($return_value == 3){
                    $msg = JText::_('JS_RESUME_ALREADY_EXISTS_IN_FOLDER' );
		}else{	$msg = JText :: _('ERROR_SAVING_FOLDERS');
		}
		$this->setRedirect(JRoute::_($link), $msg);
                
	}

	function saveresume()
	{
		global $mainframe;
		
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$session = &JFactory::getSession();
		$user	=& JFactory::getUser();
		$uid=$user->id;
		$Itemid =  JRequest::getVar('Itemid');

                if ($uid){
                    $return_value = $model->storeResume('');
                }else{
                    $visitor = $session->get('jsjob_jobapply');
                    $return_value = $model->storeResume($visitor['bi']);
                }
		if ($return_value == 1)	{
			$msg = JText :: _('EMP_APP_SAVED');
                        if ($uid) $link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=myresumes&Itemid='.$Itemid;
                        else{
                            $visitor['visitor'] = '';
                            $visitor['bi'] = '';
                            $session->set('jsjob_jobapply', $visitor);
                            $link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=controlpanel&Itemid='.$Itemid;
                        }
		}else if ($return_value == 2){
			$msg = JText :: _('JS_FILL_REQ_FIELDS');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=formresume&Itemid='.$Itemid;
		}else if ($return_value == 6){ // file type mismatch
			$msg = JText :: _('JS_FILE_TYPE_ERROR');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=myresumes&Itemid='.$Itemid;
		}else if ($return_value == 7){ // photo file size 
			$msg = JText :: _('JS_ERROR_PHOTO_SIZE_LARGER');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=formresume&Itemid='.$Itemid;
		}else if ($return_value == 8){ // captcha error 
			$msg = JText :: _('JS_ERROR_INCORRECT_CAPTCHA_CODE');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=formresume&Itemid='.$Itemid;
		}else{
			$msg = JText :: _('ERROR_SAVING_EMP_APP');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=myresumes&uid='.$uid.'&Itemid='.$Itemid;
		}
		//$this->setRedirect($link, $msg);
		$this->setRedirect(JRoute::_($link), $msg);
	}

function savedepartment() //save department
	{
		global $mainframe;
		
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$session = &JFactory::getSession();
		$uid = &JRequest::getString('uid','none');
		
		$Itemid =  JRequest::getVar('Itemid');
		
		$return_value = $model->storeDepartment();
		if ($return_value == 1)	{
			$msg = JText :: _('JS_DEPARTMENT_SAVED');
		}else if ($return_value == 2){
			$msg = JText :: _('JS_FILL_REQ_FIELDS');
		}else{
			$msg = JText :: _('JS_ERROR_SAVING_DEPARTMENT');
		}
		$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=mydepartments&Itemid='.$Itemid;
		//$this->setRedirect($link, $msg);
		$this->setRedirect(JRoute::_($link), $msg);
	}
	function saveshortlistcandiate() //save shortlist candidate
	{
		global $mainframe;

		$model = $this->getModel('jsjobs', 'JSJobsModel');
		
		$Itemid =  JRequest::getVar('Itemid');
		$user	=& JFactory::getUser();
		$uid = $user->id;
		$data = JRequest :: get('post');
                $jobid=$data['jobid'];
                //echo 'ac '.$data['action'];
		if($data['action'] == 1){ // short list
                    $return_value = $model->storeShortListCandidate($uid);
                    if ($return_value == 1) $msg = JText :: _('JS_SHORT_LIST_CANDIDATE_SAVED');
                    elseif ($return_value == 2) $msg = JText :: _('JS_FILL_REQ_FIELDS');
                    elseif ($return_value == 3) $msg = JText :: _('JS_ALLREADY_SHORTLIST_THIS_CANDIDATE');
                    else $msg = JText :: _($return_value.'JS_ERROR_SAVING_SHORT_LIST_CANDIDATE');
                    $link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=job_appliedapplications&bd='.$jobid.'&Itemid='.$Itemid;
                }elseif($data['action'] == 2){ // send message
                    $link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=send_message&bd='.$data['jobid'].'&rd='.$data['resumeid'].'&vm=1&Itemid='.$Itemid;
                }
		//$this->setRedirect($link, $msg);
		$this->setRedirect(JRoute::_($link), $msg);
	}

        function savemessage() //save message
	{
		$model = $this->getModel('jsjobs', 'JSJobsModel');

		$Itemid =  JRequest::getVar('Itemid');
		$user	=& JFactory::getUser();
		$uid = $user->id;
                $data = JRequest :: get('post');
                $return_value = $model->storeMessage($uid);
                if ($return_value == 1) $msg = JText :: _('JS_MESSAGE_SAVED');
                elseif ($return_value == 2) $msg = JText :: _('JS_MESSAGE_SAVED_AND_WAITING_FOR_APPROVAL');
                elseif ($return_value == 4) $msg = JText :: _('WE_UNABLE_TO_SEND_EMAIL');
                elseif ($return_value == 5) $msg = JText :: _('JS_JOB_SEEKER_NOT_MEMBER_SYSTEM_CANNOT_SEND_MESSAGE');
                elseif ($return_value == 6) $msg = JText :: _('JS_EMPLOYER_NOT_MEMBER_SYSTEM_CANNOT_SEND_MESSAGE');
                else $msg = JText :: _($return_value.'JS_ERROR_SAVING_MESSAGE');
                    //$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=job_appliedapplications&bd='.$jobid.'&Itemid='.$Itemid;
                $link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=send_message&bd='.$data['jobid'].'&rd='.$data['resumeid'].'&vm='.$data['vm'].'&Itemid='.$Itemid;
		$this->setRedirect(JRoute::_($link), $msg);
	}


	function jobtypes()
	{
		global $mainframe;
		$mainframe = &JFactory::getApplication();
		$model = $this->getModel('jsjobs', 'JSJobsModel');
	     $id=JRequest::getVar( 'id');
	     $val=JRequest::getVar( 'val');
	    $fild=JRequest::getVar( 'fild');

		$return_value = $model->jobTypes($id, $val, $fild);
		echo $return_value;
		$mainframe->close();
	}

	function savenewinjsjobs() //save new in jsjobs
	{
		global $mainframe;
		
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$session = &JFactory::getSession();
		$uid = &JRequest::getString('uid','none');
		
		$Itemid =  JRequest::getVar('Itemid');
		$data = JRequest :: get('post');
		$usertype = $data['usertype'];
		
		$return_value = $model->storeNewinJSJobs();
		$_SESSION['jsuserrole'] = null;
		$session = JFactory::getSession();
		$session->set('jsjobconfig_dft', '');
		$session->set('jsjobcur_usr', '');
		
		if ($usertype == 1) // employer
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=controlpanel&Itemid='.$Itemid;
		elseif ($usertype == 2 )// job seeker
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=controlpanel&Itemid='.$Itemid;
                if ($return_value == 1)	{
			$msg = JText :: _('JS_SAVE_SETTINGS');
		}else{
			$msg = JText :: _('JS_ERROR_SAVING_SETTING');
		}
		$this->setRedirect($link, $msg);
		//$this->setRedirect(JRoute::_($link), $msg);
	}

	function savecoverletter() //save cover letter
	{
		global $mainframe;
		
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$session = &JFactory::getSession();
		$uid = &JRequest::getString('uid','none');
		
		$Itemid =  JRequest::getVar('Itemid');
		
		$return_value = $model->storeCoverLetter();
		if ($return_value == 1)	{
			$msg = JText :: _('JS_COVER_LETTER_SAVED');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=mycoverletters&Itemid='.$Itemid;
		}else if ($return_value == 2){
			$msg = JText :: _('JS_FILL_REQ_FIELDS');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=formcoverletter&Itemid='.$Itemid;
		}else{
			$msg = JText :: _('JS_ERROR_SAVING_COVER_LETTER');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=formcoverletter&Itemid='.$Itemid;
		}
		$this->setRedirect($link, $msg);
		//$this->setRedirect(JRoute::_($link), $msg);
	}

	function savefilter() //save filter
	{
		global $mainframe;
		
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$session = &JFactory::getSession();
		$uid = &JRequest::getString('uid','none');
		
		$Itemid =  JRequest::getVar('Itemid');
		$data = JRequest :: get('post');
		$link = $data['formaction'];
		$return_value = $model->storeFilter();
		
		if ($return_value == 1)	{
			$_SESSION['jsuserfilter'] ='';
                        if (isset($_SESSION['jsuserfilter'])) unset($_SESSION['jsuserfilter']);
			$msg = JText :: _('JS_FILTER_SAVED');
		}else{
			$msg = JText :: _('JS_ERROR_SAVING_FILTER');
		}
		//$this->setRedirect($link, $msg);
		$this->setRedirect(JRoute::_($link), $msg);
	}

	function savejobsearch() //save job search
	{
		global $mainframe;
		
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$session = &JFactory::getSession();
		$uid = &JRequest::getString('uid','none');
		
		$Itemid =  JRequest::getVar('Itemid');
		$data = JRequest :: get('post');
		$user	=& JFactory::getUser();

		$data['uid'] = $user->id;
		$data['jobtitle'] = $_SESSION['jobsearch_title'];	
		$data['category']= $_SESSION['jobsearch_jobcategory'];
		$data['jobtype']= $_SESSION['jobsearch_jobtype'];
		$data['jobstatus']= $_SESSION['jobsearch_jobstatus'];
		$data['heighesteducation']= $_SESSION['jobsearch_heighestfinisheducation'];
		$data['salaryrange']= $_SESSION['jobsearch_jobsalaryrange'];
		$data['shift']= $_SESSION['jobsearch_shift'];	
		$data['experience']= $_SESSION['jobsearch_experience'];	
		$data['durration']= $_SESSION['jobsearch_durration'];	
		$data['startpublishing']= $_SESSION['jobsearch_startpublishing'];	
		$data['stoppublishing']= $_SESSION['jobsearch_stoppublishing'];	
		$data['company']= $_SESSION['jobsearch_company'];	
		$data['country_istext']= 0;
		$data['country']= $_SESSION['jobsearch_country'];
		$data['state_istext']= 0;
		$data['state']= $_SESSION['jobsearch_state'];
		$data['county_istext']= 0;
		$data['county']= $_SESSION['jobsearch_county'];
		$data['city_istext']= 0;
		$data['city']= $_SESSION['jobsearch_city'];
		$data['zipcode_istext']= 0;
		$data['zipcode']= $_SESSION['jobsearch_zipcode'];
		$data['created']= date('Y-m-d H:i:s');
		$data['status']= 1;

//		$link = $data['formaction'];
		$return_value = $model->storeJobSearch($data);
		
		if ($return_value == 1)	{
			$msg = JText :: _('JS_SEARCH_SAVED');
		}elseif ($return_value == 3){
			$msg = JText :: _('JS_LIMIT_EXCEED_OR_ADMIN_BLOCK_THIS');
		}else{
			$msg = JText :: _('JS_ERROR_SAVING_SEARCH');
		}
		// final redirect
		$link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=job_searchresults&Itemid='.$Itemid;
		//$this->setRedirect($link, $msg);
		$this->setRedirect(JRoute::_($link), $msg);
	}

	function saveresumesearch() //save resume search
	{
		global $mainframe;
		
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$session = &JFactory::getSession();
		$uid = &JRequest::getString('uid','none');
		
		$Itemid =  JRequest::getVar('Itemid');
		$data = JRequest :: get('post');
		$user	=& JFactory::getUser();

		$data['uid'] = $user->id;
		$data['application_title'] = $_SESSION['resumesearch_title'];
		$data['nationality'] = $_SESSION['resumesearch_nationality'];
		$data['gender'] = $_SESSION['resumesearch_gender'];
		$data['iamavailable'] = $_SESSION['resumesearch_iamavailable'];
		$data['category'] = $_SESSION['resumesearch_jobcategory'];
		$data['jobtype'] = $_SESSION['resumesearch_jobtype'];
		$data['salaryrange'] = $_SESSION['resumesearch_jobsalaryrange'];
		$data['education'] = $_SESSION['resumesearch_heighestfinisheducation'];
		$data['experience'] = $_SESSION['resumesearch_experience'];
		$data['created']= date('Y-m-d H:i:s');
		$data['status']= 1;

//		$link = $data['formaction'];
		$return_value = $model->storeResumeSearch($data);
		
		if ($return_value == 1)	{
			$msg = JText :: _('JS_SEARCH_SAVED');
		}elseif ($return_value == 3){
			$msg = JText :: _('JS_LIMIT_EXCEED_OR_ADMIN_BLOCK_THIS');
		}else{
			$msg = JText :: _('JS_ERROR_SAVING_SEARCH');
		}
		// final redirect
		$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=resume_searchresults&Itemid='.$Itemid;
		//$this->setRedirect($link, $msg);
		$this->setRedirect(JRoute::_($link), $msg);
	}

	function deletefilter() //delete filter
	{
		global $mainframe;
		
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$session = &JFactory::getSession();
		$uid = &JRequest::getString('uid','none');
		
		$Itemid =  JRequest::getVar('Itemid');
		$data = JRequest :: get('post');
		$link = $data['formaction'];
		$return_value = $model->deleteUserFilter();
		
		if ($return_value == 1)	{
			$_SESSION['jsuserfilter'] ='';
			$msg = JText :: _('JS_FILTER_DELETED');
		}else{
			$msg = JText :: _('JS_ERROR_DELETING_FILTER');
		}
		//$this->setRedirect($link, $msg);
		$this->setRedirect(JRoute::_($link), $msg);
	}

	function jobshifts()
	{
		global $mainframe;
		$mainframe = &JFactory::getApplication();
		$model = $this->getModel('jsjobs', 'JSJobsModel');
	     $id=JRequest::getVar( 'id');
	     $val=JRequest::getVar( 'val');
	     $fild=JRequest::getVar( 'fild');

		$return_value = $model->jobShifts($id, $val, $fild);
		echo $return_value;
		$mainframe->close();
	}

	function deletejobsearch() //delete job search
	{
		global $mainframe;
		
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$session = &JFactory::getSession();
		$user	=& JFactory::getUser();
		$uid=$user->id;
		
		$Itemid =  JRequest::getVar('Itemid');
		
		$data = JRequest :: get('post');
		$link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=my_jobsearches&Itemid='.$Itemid;
		$searchid =  JRequest::getVar('js');
		$return_value = $model->deleteJobSearch($searchid, $uid);
		
		if ($return_value == 1)	{
			$msg = JText :: _('JS_SEARCH_DELETED');
		}elseif ($return_value == 2){
			$msg = JText :: _('JS_NOT_YOUR_SEARCH');
		}else{
			$msg = JText :: _('JS_ERROR_DELETING_SEARCH');
		}
		//$this->setRedirect($link, $msg);
		$this->setRedirect(JRoute::_($link), $msg);
	}

	function deleteresumesearch() //delete resume search
	{
		global $mainframe;
		
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$session = &JFactory::getSession();
		$user	=& JFactory::getUser();
		$uid=$user->id;
		
		$Itemid =  JRequest::getVar('Itemid');
		
		$data = JRequest :: get('post');
		$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=my_resumesearches&Itemid='.$Itemid;
		$searchid =  JRequest::getVar('rs');
		$return_value = $model->deleteResumeSearch($searchid, $uid);
		
		if ($return_value == 1)	{
			$msg = JText :: _('JS_SEARCH_DELETED');
		}elseif ($return_value == 2){
			$msg = JText :: _('JS_NOT_YOUR_SEARCH');
		}else{
			$msg = JText :: _('JS_ERROR_DELETING_SEARCH');
		}
		//$this->setRedirect($link, $msg);
		$this->setRedirect(JRoute::_($link), $msg);
	}

	function deletecoverletter() //delete cover letter
	{
		global $mainframe;
		
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$session = &JFactory::getSession();
		$user	=& JFactory::getUser();
		$uid=$user->id;
		
		$Itemid =  JRequest::getVar('Itemid');
		
		$coverletterid =  JRequest::getVar('cl');
		$return_value = $model->deleteCoverLetter($coverletterid, $uid);
		if ($return_value == 1)	{
			$msg = JText :: _('JS_COVER_LETTER_DELETED');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=mycoverletters&Itemid='.$Itemid;
		}elseif ($return_value == 2){
			$msg = JText :: _('JS_NOT_YOUR_COVER_LETTER');
		}else{
			$msg = JText :: _('JS_ERROR_DELETEING_COVER_LETTER');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=formcoverletter&Itemid='.$Itemid;
		}
		//$this->setRedirect($link, $msg);
		$this->setRedirect(JRoute::_($link), $msg);
	}

	function deleteresume() //delete resume
	{
		global $mainframe;
		
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$session = &JFactory::getSession();
		$user	=& JFactory::getUser();
		$uid=$user->id;
		
		$Itemid =  JRequest::getVar('Itemid');
		
		$resumeid =  JRequest::getVar('rd');

		$return_value = $model->deleteResume($resumeid, $uid);
		if ($return_value == 1)	{
			$msg = JText :: _('JS_RESUME_DELETED');
			
		}elseif ($return_value == 2){
			$msg = JText :: _('JS_RESUME_INUSE_CANNOT_DELETE');
			
		}elseif ($return_value == 3){
			$msg = JText :: _('JS_NOT_YOUR_RESUME');
			
		}else{
			$msg = JText :: _('JS_ERROR_DELETEING_RESUME');
			
		}
		$link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=myresumes&Itemid='.$Itemid;
		//$this->setRedirect($link, $msg);
		$this->setRedirect(JRoute::_($link), $msg);
	}
	
	
	

	function deletejob() //delete job
	{
		global $mainframe;
		
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$session = &JFactory::getSession();
		$user	=& JFactory::getUser();
		$uid=$user->id;
		
		$Itemid =  JRequest::getVar('Itemid');
		
		$jobid =  JRequest::getVar('bd');
		$vis_email =  JRequest::getVar('email');
		$vis_jobid =  JRequest::getVar('jobid');

		$return_value = $model->deleteJob($jobid, $uid,$vis_email,$vis_jobid);
		if ($return_value == 1)	{
			$msg = JText :: _('JS_JOB_DELETED');
            if(($vis_email == '') || ($jobid == '')) $link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=myjobs&Itemid='.$Itemid;
            else $link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=myjobs&email='.$vis_email.'&jobid='.$vis_jobid.'&Itemid='.$Itemid;
		}elseif ($return_value == 2){
			$msg = JText :: _('JS_JOB_INUSE_CANNOT_DELETE');
			if(($vis_email == '') || ($jobid == '')) $link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=myjobs&Itemid='.$Itemid;
			else $link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=myjobs&email='.$vis_email.'&jobid='.$vis_jobid.'&Itemid='.$Itemid;
		}elseif ($return_value == 3){
			$msg = JText :: _('JS_NOT_YOUR_JOB');
			if(($vis_email == '') || ($jobid == '')) $link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=myjobs&Itemid='.$Itemid;
			else $link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=myjobs&email='.$vis_email.'&jobid='.$vis_jobid.'&Itemid='.$Itemid;
		}else{
			$msg = JText :: _('JS_ERROR_DELETEING_JOB');
			if(($vis_email == '') || ($jobid == '')) $link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=myjobs&Itemid='.$Itemid;
			else $link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=myjobs&email='.$vis_email.'&jobid='.$vis_jobid.'&Itemid='.$Itemid;
		}
		//$this->setRedirect($link, $msg);
		$this->setRedirect(JRoute::_($link), $msg);
	}

function deletedepartment() //delete department
	{
		global $mainframe;
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$session = &JFactory::getSession();
		$user	=& JFactory::getUser();
		$uid=$user->id;
		
		$Itemid =  JRequest::getVar('Itemid');
		
		$departmentid =  JRequest::getVar('pd');
		
		$return_value = $model->deleteDepartment($departmentid, $uid);
		if ($return_value == 1)	{
			$msg = JText :: _('JS_DEPARTMENT_DELETED');
			
		}elseif ($return_value == 2){
			$msg = JText :: _('JS_DEPARTMENT_CANNOT_DELETE');
			
		}elseif ($return_value == 3){
			$msg = JText :: _('JS_NOT_YOUR_DEPARTMENT');
			
		}else{
			$msg = JText :: _('JS_ERROR_DELETING_DEPARTMENT');
			
		}
		$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=mydepartments&Itemid='.$Itemid;
		//$this->setRedirect($link, $msg);
		$this->setRedirect(JRoute::_($link), $msg);
	}




	function deletecompany() //delete company
	{
		global $mainframe;
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$session = &JFactory::getSession();
		$user	=& JFactory::getUser();
		$uid=$user->id;
		
		$Itemid =  JRequest::getVar('Itemid');
		
		$companyid =  JRequest::getVar('md');
		
		$return_value = $model->deleteCompany($companyid, $uid);
		if ($return_value == 1)	{
			$msg = JText :: _('JS_COMPANY_DELETED');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=mycompanies&Itemid='.$Itemid;
		}elseif ($return_value == 2){
			$msg = JText :: _('JS_COMPANY_CANNOT_DELETE');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=mycompanies&Itemid='.$Itemid;
		}elseif ($return_value == 3){
			$msg = JText :: _('JS_NOT_YOUR_COMPANY');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=mycompanies&Itemid='.$Itemid;
		}else{
			$msg = JText :: _('JS_ERROR_DELETING_COMPANY');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=mycompanies&Itemid='.$Itemid;
		}
		//$this->setRedirect($link, $msg);
		$this->setRedirect(JRoute::_($link), $msg);
	}

	function deletefolder() //delete folder
	{
		global $mainframe;
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$session = &JFactory::getSession();
		$user	=& JFactory::getUser();
		$uid=$user->id;
		
		$Itemid =  JRequest::getVar('Itemid');

		$folderid =  JRequest::getVar('fd');

		$return_value = $model->deleteFolder($folderid, $uid);
		if ($return_value == 1)	{
			$msg = JText :: _('JS_FOLDER_DELETED');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=myfolders&Itemid='.$Itemid;
		}elseif ($return_value == 2){
			$msg = JText :: _('JS_FOLDER_CANNOT_DELETE');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=myfolders&Itemid='.$Itemid;
		}elseif ($return_value == 3){
			$msg = JText :: _('JS_NOT_YOUR_FOLDER');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=myfolders&Itemid='.$Itemid;
		}else{
			$msg = JText :: _('JS_ERROR_DELETING_FOLDER');
			$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=myfolders&Itemid='.$Itemid;
		}
		//$this->setRedirect($link, $msg);
		$this->setRedirect(JRoute::_($link), $msg);
	}

	function listaddressdata()
	  { 
		 global $mainframe;
		$mainframe = &JFactory::getApplication();

	     $data=JRequest::getVar( 'data');
	     $val=JRequest::getVar( 'val');
		
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$returnvalue = $model->listAddressData($data, $val);
		
		echo $returnvalue;
		$mainframe->close();
	  }

	function listsearchaddressdata()
	  { 
		 global $mainframe;
		$mainframe = &JFactory::getApplication();

	     $data=JRequest::getVar( 'data');
	     $val=JRequest::getVar( 'val');
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$returnvalue = $model->listSearchAddressData($data, $val);
		
		echo $returnvalue;
		$mainframe->close();
	  }

	function listfilteraddressdata()
	  { 
		 global $mainframe;
		$mainframe = &JFactory::getApplication();

	     $data=JRequest::getVar( 'data');
	     $val=JRequest::getVar( 'val');
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$returnvalue = $model->listFilterAddressData($data, $val);
		
		echo $returnvalue;
		$mainframe->close();
	  }

	function listmodsearchaddressdata()
	  { 
		 global $mainframe;
		$mainframe = &JFactory::getApplication();
	     $data=JRequest::getVar( 'data');
	     $val=JRequest::getVar( 'val');
	     $for=JRequest::getVar( 'for');
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$returnvalue = $model->listModuleSearchAddressData($data, $val, $for);
		
		echo $returnvalue;
		$mainframe->close();
	  }

	function listempaddressdata()
	  { 
		 global $mainframe;
		$mainframe = &JFactory::getApplication();
		 
	     $name=JRequest::getVar( 'name');
	     $myname=JRequest::getVar( 'myname');
	     $nextname=JRequest::getVar( 'nextname');

	     $data=JRequest::getVar( 'data');
	     $val=JRequest::getVar( 'val');

		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$returnvalue = $model->listEmpAddressData($name, $myname, $nextname, $data, $val);
		
		echo $returnvalue;
		$mainframe->close();
	  }
	
	function listdepartments()
	{ 
		global $mainframe;
		$mainframe = &JFactory::getApplication();

		$val=JRequest::getVar( 'val');
		
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$returnvalue = $model->listDepartments($val);
		
		echo $returnvalue;
		$mainframe->close();
	}
	function listsubcategories()
	{
		global $mainframe;
		$mainframe = &JFactory::getApplication();

		$val=JRequest::getVar( 'val');

		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$returnvalue = $model->listSubCategories($val);

		echo $returnvalue;
		$mainframe->close();
	}
	function listsubcategoriesforsearch()
	{
		global $mainframe;
		$mainframe = &JFactory::getApplication();

		$val=JRequest::getVar( 'val');
		$modulecall=JRequest::getVar( 'md');

		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$returnvalue = $model->listSubCategoriesForSearch($val);
                if($modulecall){
                    if($modulecall == 1){
                        $return = JText::_('JS_SUB_CATEGORY')."<br>".$returnvalue;
                        $returnvalue = $return;
                    }
                }

		echo $returnvalue;
		$mainframe->close();
	}
	
        function getresumedetail()
        {
            global $mainframe;
            $mainframe = &JFactory::getApplication();

            $user =& JFactory::getUser();
            $uid=$user->id;
            $jobid=JRequest::getVar( 'jobid');
            $resumeid=JRequest::getVar( 'resumeid');

            $model = $this->getModel('jsjobs', 'JSJobsModel');
            $returnvalue = $model->getResumeDetail($uid, $jobid, $resumeid);

            echo $returnvalue;
            $mainframe->close();
        }
        function getmyforlders()  {
            global $mainframe;
			$mainframe = &JFactory::getApplication();

            $user=& JFactory::getUser();
            $uid=$user->id;
            $jobid=JRequest::getVar( 'jobid');
            $resumeid=JRequest::getVar( 'resumeid');
            $applyid=JRequest::getVar( 'applyid');

            $model = $this->getModel('jsjobs', 'JSJobsModel');
            $returnvalue = $model->getMyFoldersAJAX($uid, $jobid, $resumeid,$applyid);

            echo $returnvalue;
            $mainframe->close();
        }
	function getaddressdata()
	{
		global $mainframe;
		$mainframe = &JFactory::getApplication();
		$val=JRequest::getVar( 'val');

		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$returnvalue = $model->getAddressData($val);

		echo json_encode($returnvalue);
		$mainframe->close();
	}

	function getcopyjob()
	{
		global $mainframe;
		$mainframe = &JFactory::getApplication();
		$val=JRequest::getVar( 'val');

		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$returnvalue = $model->getCopyJob($val);

		echo $returnvalue;
		$mainframe->close();
	}
	function sendtofriend()
	{
		global $mainframe;
		$mainframe = &JFactory::getApplication();
		$val = json_decode(JRequest::getVar('val'),true);

		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$returnvalue = $model->sendToFriend($val);
		
		echo $returnvalue;
		$mainframe->close();
	}
	function sendjobalert(){
		global $mainframe;
		$mainframe = &JFactory::getApplication();
		$ck = JRequest::getVar('ck');
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$result = $model->sendJobAlertByAlertType($ck);
		echo $returnvalue;
		$mainframe->close();
	}

	function checkuserdetail()
	{
		global $mainframe;
		$mainframe = &JFactory::getApplication();
		$val=JRequest::getVar( 'val');
		$for=JRequest::getVar( 'fr');
		
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$returnvalue = $model->checkUserDetail($val,$for);

		echo $returnvalue;
		$mainframe->close();
	}
	
	function listfiltersubcategories()
	{
		global $mainframe;
		$mainframe = &JFactory::getApplication();

		$val=JRequest::getVar( 'val');

		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$returnvalue = $model->listFilterSubCategories($val);

		echo $returnvalue;
		$mainframe->close();
	}


	function display()
	{
		$document = & JFactory :: getDocument();
		$viewName = JRequest :: getVar('view', 'resume');
		$layoutName = JRequest :: getVar('layout', 'jobcat');
		$viewType = $document->getType();
		$model = $this->getModel('jsjobs', 'JSJobsModel');
		$view = & $this->getView($viewName, $viewType);
		if (!JError :: isError($model))
		{
			$view->setModel($model, true);
		}
		$view->setLayout($layoutName);
		$view->display();
	}
}
?>
