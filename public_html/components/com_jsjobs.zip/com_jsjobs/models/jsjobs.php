<?php
/**
 * @Copyright Copyright (C) 2009-2011
 * @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
 + Created by:          Ahmad Bilal
 * Company:		Buruj Solutions
 + Contact:		www.burujsolutions.com , ahmad@burujsolutions.com
 * Created on:	Jan 11, 2009
 ^
 + Project: 		JS Jobs
 * File Name:	models/jsjobs.php
 ^ 
 * Description: Model class for jsjobs data
 ^ 
 * History:		NONE
 ^ 
 */

defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.model');
jimport('joomla.html.html');

$option = JRequest :: getVar('option', 'com_jsjobs');


class JSJobsModelJsjobs extends JModelLegacy
{
	var $_id = null;
	var $_uid = null;
	var $_job = null;
	var $_application = null;
	var $_applications = array();
	var $_options = null;
	var $_empoptions = null;
	var $_searchoptions = null;
	var $_config = null;
	var $_jobtype = null;
	var $_jobstatus = null;
	var $_heighesteducation = null;
	var $_shifts = null;
	var $_defaultcountry = null;
	var $_defaultcurrency = null;
	var $_job_editor = null;
	var $_comp_editor = null;
	var $_filterlists = null;
	var $_careerlevels = null;
	var $_experiences = null;
	var $_ages = null;
	var $_careerlevel = null;
	var $_countries = null;
	var $_jobsalaryrange = null;
    var $_jversion = null;
	
	function __construct()
	{
		parent :: __construct();
		$user	=& JFactory::getUser();
		$this->_arv = "/\aseofm/rvefli/ctvrnaa/kme/\rfer";
		$this->_ptr = "/\blocalh";
        $version = new JVersion;
        $joomla = $version->getShortVersion();
        $this->_jversion = substr($joomla,0,3);
	}
// Search Start
	function &getJobSearch($uid,$title,$jobcategory,$jobsubcategory,$jobtype,$jobstatus,$currency,$salaryrangefrom,$salaryrangeto,$salaryrangetype
							,$shift, $experience, $durration, $startpublishing, $stoppublishing
							,$company,$country,$state,$county,$city,$zipcode,$longitude,$latitude,$radius,$radius_length_type,$keywords,$sortby,$limit,$limitstart)
	{

		if (isset($uid)) if (is_numeric($uid) == false) return false;
		if ($jobcategory != '') if (is_numeric($jobcategory) == false) return false;
		if ($jobsubcategory != '') if (is_numeric($jobsubcategory) == false) return false;
		if ($jobtype != '') if (is_numeric($jobtype) == false) return false;
		if ($jobstatus != '') if (is_numeric($jobstatus) == false) return false;
		//if ($jobsalaryrange != '') if (is_numeric($jobsalaryrange) == false) return false;
		if ($salaryrangefrom != '')if (is_numeric($salaryrangefrom) == false) return false;
		if ($salaryrangeto != '')if (is_numeric($salaryrangeto) == false) return false;
		if ($salaryrangetype != '')if (is_numeric($salaryrangetype) == false) return false;
		//if ($education != '') if (is_numeric($education) == false) return false;
		if ($shift != '') if (is_numeric($shift) == false) return false;
		if ($company != '') if (is_numeric($company) == false) return false;
		if ($currency != '') if (is_numeric($currency) == false) return false;
		
		$db = &$this->getDBO();
		if (($this->_jversion == '1.5') || ($this->_jversion == '2.5')) $state = $db->getEscaped( $state, true ); else $state = $db->escape( $state, true );
		if (($this->_jversion == '1.5') || ($this->_jversion == '2.5')) $county = $db->getEscaped( $county, true ); else $county = $db->escape( $county, true );
		if (($this->_jversion == '1.5') || ($this->_jversion == '2.5')) $city = $db->getEscaped( $city, true ); else $city = $db->escape( $city, true );

		if(! isset($this->_config)){
			$this->getConfig('');
		}
		foreach ($this->_config as $conf){
			if ($conf->configname == 'filter_address_fields_width')
				$address_fields_width = $conf->configvalue;
				if ($conf->configname == 'date_format') $dateformat = $conf->configvalue;
		}

		
		if ($startpublishing != ''){
	                if($dateformat == 'm-d-Y'){
	                    $arr = explode('-', $startpublishing);
	                    $startpublishing =  $arr[0].'/'.$arr[1].'/'.$arr[2];
	                }elseif($dateformat == 'd-m-Y'){
	                    $arr = explode('-', $startpublishing);
	                    $startpublishing =  $arr[2].'-'.$arr[1].'-'.$arr[0];
	                }
			 $startpublishing =  date('Y-m-d',strtotime($startpublishing));
		}		 
		if ($stoppublishing != ''){
	                if($dateformat == 'm-d-Y'){
	                    $arr = explode('-', $stoppublishing);
	                    $stoppublishing =  $arr[0].'/'.$arr[1].'/'.$arr[2];
	                }elseif($dateformat == 'd-m-Y'){
	                    $arr = explode('-', $stoppublishing);
	                    $stoppublishing =  $arr[2].'-'.$arr[1].'-'.$arr[0];
	                }
			 $stoppublishing =  date('Y-m-d',strtotime($stoppublishing));
		}
		if ($uid){
                    $query = "SELECT package.savejobsearch, package.packageexpireindays, payment.created
                    FROM `#__js_job_jobseekerpackages` AS package
                    JOIN `#__js_job_jobseekerpaymenthistory` AS payment ON payment.packageid = package.id
                    WHERE payment.uid = ".$uid."
                    AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
                    AND payment.transactionverified = 1 AND payment.status = 1";
                    $db->setQuery($query);
                    $jobs = $db->loadObjectList();
                    $canview = 0;

                    foreach($jobs AS $job){
                            if ($job->savejobsearch == 1){
                                       $canview = 1;
                                       break;
                            }else $canview = 0;
                    }
                }else $canview = 1; // visitor case

		$result = array();
		$searchjobconfig = $this->getConfigByFor('searchjob');

		$listjobconfig = $this->getConfigByFor('listjob');

                if($keywords){// For keyword Search
                    $keywords = explode(' ',$keywords);
                    $length = count($keywords);
                    if($length <= 5){// For Limit keywords to 5
                        $i = $length;
                    }else{
                        $i = 5;
                    }
                    for($j = 0;$j<$i;$j++){
                        $keys[] = " job.metakeywords Like '%$keywords[$j]%'";
                    }
                }
        //for radius search
        switch($radius_length_type){
			case "m":$radiuslength = 6378137;break;
			case "km":$radiuslength = 6378.137;break;
			case "mile":$radiuslength = 3963.191;break;
			case "nacmiles":$radiuslength = 3441.596;break;
		}
		$selectdistance = " ";
        if($longitude != '' && $latitude != '' && $radius != ''){
			//$radiussearch = " acos((sin(PI()*$latitude/180)*sin(PI()*job.latitude/180))+(cos(PI()*$latitude/180)*cos(PI()*job.latitude/180)*cose(PI()*job.longitude/180 - PI()*$longitude/180)))*$radiuslength <= $radius";
			$radiussearch = " acos((SIN( PI()* $latitude /180 )*SIN( PI()*job.latitude/180 ))+(cos(PI()* $latitude /180)*COS( PI()*job.latitude/180) *COS(PI()*job.longitude/180-PI()* $longitude /180)))* $radiuslength <= $radius";
			$selectdistance = " ,acos((sin(PI()*$latitude/180)*sin(PI()*job.latitude/180))+(cos(PI()*$latitude/180)*cos(PI()*job.latitude/180)*cose(PI()*job.longitude/180 - PI()*$longitude/180)))*$radiuslength AS distance ";
		}

		$wherequery = '';
                $issalary = '';
		if ($title != '') $wherequery .= " AND job.title LIKE '%".str_replace("'","",$db->Quote($title))."%'";
		if ($jobcategory != '') $wherequery .= " AND job.jobcategory = ".$jobcategory;
		if (isset($keys)) $wherequery .= " AND ( ".  implode(' OR ', $keys)." )";
		if ($jobsubcategory != '') $wherequery .= " AND job.subcategoryid = ".$jobsubcategory;
		if ($jobtype != '') $wherequery .= " AND job.jobtype = ".$jobtype;
		if ($jobstatus != '') $wherequery .= " AND job.jobstatus = ".$jobstatus;
		if ($salaryrangefrom != ''){
			$salaryrangefromJoin = " 
									JOIN `#__js_job_salaryrange` AS salaryrangef ON salaryrangef.id = ".$salaryrangefrom;
			$wherequery .= " AND salaryrangefrom.rangestart >= salaryrangef.rangestart ";
			$issalary = 1;
		}
		if ($salaryrangeto != ''){
			$salaryrangetoJoin = " 
									JOIN `#__js_job_salaryrange` AS salaryranget ON salaryranget.id = ".$salaryrangeto;
			$wherequery .= " AND salaryrangeto.rangeend <= salaryranget.rangeend ";
			$issalary = 1;
		}
		if (($issalary != '') && ($salaryrangetype != '')){
			$wherequery .= " AND job.salaryrangetype = ".$salaryrangetype;
		}
		//if ($education != '') $wherequery .= " AND job.heighestfinisheducation = ".$education;
		if ($shift != '') $wherequery .= " AND job.shift = ".$shift;
		if ($experience != '') $wherequery .= " AND job.experience LIKE ".$db->Quote($experience);
		if ($durration != '') $wherequery .= " AND job.duration LIKE ".$db->Quote($durration);
		if ($startpublishing != '') $wherequery .= " AND job.startpublishing >= ".$db->Quote($startpublishing);
		if ($stoppublishing != '') $wherequery .= " AND job.stoppublishing <= ".$db->Quote($stoppublishing);
		if ($company != '') $wherequery .= " AND job.companyid = ".$company;
		if ($country != '') $wherequery .= " AND job.country = country.code AND country.code LIKE ".$db->Quote($country);
		//if ($state != '') $wherequery .= " AND job.state = state.code AND (state.code = ".$db->Quote($state)." OR LOWER(state.name) LIKE ".$db->Quote( '%'.$db->getEscaped( $state, true ).'%', false )." ) ";
		if ($state != '') $wherequery .= " AND (LOWER(job.state) LIKE ".$db->Quote( '%'. $state.'%', false )." ) ";
		//if ($county != '') $wherequery .= " AND job.county = county.code AND (county.code = ".$db->Quote($county)." OR LOWER(county.name) LIKE ".$db->Quote( '%'.$db->getEscaped( $county, true ).'%', false )." ) ";
		if ($county != '') $wherequery .= " AND (LOWER(job.county) LIKE ".$db->Quote( '%'. $county.'%', false )." ) ";
		//if ($city != '') $wherequery .= " AND job.city = city.code AND (city.code = ".$db->Quote($city)." OR LOWER(city.name) LIKE ".$db->Quote( '%'.$db->getEscaped( $city, true ).'%', false )." ) ";
		if ($city != '') $wherequery .= " AND  (LOWER(job.city) LIKE ".$db->Quote( '%'. $city.'%', false )." ) ";
		if ($zipcode != '') $wherequery .= " AND job.zipcode = ".$db->Quote($zipcode);
		if(isset($radiussearch) && $radiussearch != '') $wherequery .= " AND $radiussearch";

		$curdate = date('Y-m-d H:i:s');
		$query = "SELECT count(job.id) FROM `#__js_job_jobs` AS job 
					JOIN `#__js_job_categories` AS cat ON job.jobcategory = cat.id
					LEFT JOIN `#__js_job_salaryrange` AS salaryrangefrom ON job.salaryrangefrom = salaryrangefrom.id
					LEFT JOIN `#__js_job_salaryrange` AS salaryrangeto ON job.salaryrangeto = salaryrangeto.id";
                        if ($salaryrangefrom != '') $query .= $salaryrangefromJoin;
                        if ($salaryrangeto != '') $query .= $salaryrangetoJoin;
                        //$query .= " , `#__js_job_categories` AS cat ";
			if ($country != '') $query .= " LEFT JOIN `#__js_job_countries` AS country ON job.country = country.code ";
			if ($state != '') $query .= " LEFT JOIN `#__js_job_states` AS state ON job.state = state.code ";
			if ($county != '') $query .= " LEFT JOIN `#__js_job_counties` AS county ON job.county = county.code ";
			if ($city != '') $query .= " LEFT JOIN `#__js_job_cities` AS city ON job.city = city.code ";
			if ($currency != '') $query .= " LEFT JOIN `#__js_job_currencies` AS currency ON job.currencyid = currency.id ";
			
			//if ($country != '') $query .= " , `#__js_job_countries` AS country ";
			//if ($state != '') $query .= " , `#__js_job_states` AS state ";
			//if ($county != '') $query .= " , `#__js_job_counties` AS county ";
			//if ($city != '') $query .= " , `#__js_job_cities` AS city ";
			$query .= "	WHERE job.status = 1
				AND job.startpublishing <= " . $db->Quote($curdate) . " AND job.stoppublishing >= " . $db->Quote($curdate);
		$query .= $wherequery;
		$db->setQuery($query);
		$total = $db->loadResult();
		if ( $total <= $limitstart ) $limitstart = 0;
		$query = "SELECT job.*, cat.cat_title, jobtype.title AS jobtypetitle, jobstatus.title AS jobstatustitle
				, salaryrangefrom.rangestart AS salaryfrom, salaryrangeto.rangeend AS salaryend, country.name AS countryname
				, company.name AS companyname, company.url, salaryrangetype.title AS salaytype
				, (SELECT COUNT(goldjob.id) FROM `#__js_job_goldjobs` AS goldjob 
					JOIN `#__js_job_employerpackages` AS package ON package.id = goldjob.packageid
					WHERE goldjob.jobid = job.id AND goldjob.status = 1 AND DATE_ADD(goldjob.created,INTERVAL package.goldjobsexpireindays DAY) >= CURDATE() ) AS isgold
				, (SELECT COUNT(featuredjob.id) FROM `#__js_job_featuredjobs` AS featuredjob 
					JOIN `#__js_job_employerpackages` AS package ON package.id = featuredjob.packageid
					WHERE featuredjob.jobid = job.id AND featuredjob.status = 1 AND DATE_ADD(featuredjob.created,INTERVAL package.featuredjobsexpireindays DAY) >= CURDATE() ) AS isfeatured
				,(TO_DAYS( CURDATE() ) - To_days( job.startpublishing ) ) AS jobdays";
                                if ($state != '') $query .= " ,state.name AS statename ";
                                if ($county != '') $query .= " ,county.name AS countyname ";
                                if ($city != '') $query .= " ,city.name AS cityname ";
                                if ($currency != '') $query .= " ,currency.symbol AS symbol ";

		$query .= "	FROM `#__js_job_jobs` AS job
				JOIN `#__js_job_categories` AS cat ON job.jobcategory = cat.id
				JOIN `#__js_job_jobtypes` AS jobtype ON job.jobtype = jobtype.id
				JOIN `#__js_job_jobstatus` AS jobstatus ON job.jobstatus = jobstatus.id
				LEFT JOIN `#__js_job_companies` AS company ON job.companyid = company.id
				LEFT JOIN `#__js_job_countries` AS country ON job.country = country.code
				LEFT JOIN `#__js_job_salaryrange` AS salaryrangefrom ON job.salaryrangefrom = salaryrangefrom.id
				LEFT JOIN `#__js_job_salaryrange` AS salaryrangeto ON job.salaryrangeto = salaryrangeto.id
				LEFT JOIN `#__js_job_salaryrangetypes` AS salaryrangetype ON job.salaryrangetype = salaryrangetype.id";
                                if ($salaryrangefrom != '') $query .= $salaryrangefromJoin;
                                if ($salaryrangeto != '') $query .= $salaryrangetoJoin;
			if ($state != '') $query .= " LEFT JOIN `#__js_job_states` AS state ON job.state = state.code ";
			if ($county != '') $query .= " LEFT JOIN `#__js_job_counties` AS county ON job.county = county.code ";
			if ($city != '') $query .= " LEFT JOIN `#__js_job_cities` AS city ON job.city = city.code ";
			if ($currency != '') $query .= " LEFT JOIN `#__js_job_currencies` AS currency ON job.currencyid = currency.id ";
			
//				$query .= " , `#__js_job_categories` AS cat ";
			//if ($country != '') $query .= " , `#__js_job_countries` AS country2 ";
			//if ($state != '') $query .= " , `#__js_job_states` AS state ";
//			if ($county != '') $query .= " , `#__js_job_counties` AS county ";
//			if ($city != '') $query .= " , `#__js_job_cities` AS city ";
//			$query .= "WHERE job.jobcategory = cat.id AND job.status = 1
			$query .= " WHERE job.status = 1
						AND job.startpublishing <= " . $db->Quote($curdate) . " AND job.stoppublishing >= " . $db->Quote($curdate);
			if ($currency != '')
			$query .= " AND job.currencyid = " . $currency ;				
		$query .= $wherequery;
		$query .= " ORDER BY  ".$sortby;
		$db->setQuery($query, $limitstart, $limit);
		$this->_applications = $db->loadObjectList();

                $packageexpiry = $this->getJobSeekerPackageExpiry($uid);
                if($packageexpiry == 1){ //package expire or user not login
                    $listjobconfigs = array();
                    $listjobconfigs['lj_title'] = $listjobconfig['visitor_lj_title'];
                    $listjobconfigs['lj_category'] = $listjobconfig['visitor_lj_category'];
                    $listjobconfigs['lj_jobtype'] = $listjobconfig['visitor_lj_jobtype'];
                    $listjobconfigs['lj_jobstatus'] = $listjobconfig['visitor_lj_jobstatus'];
                    $listjobconfigs['lj_company'] = $listjobconfig['visitor_lj_company'];
                    $listjobconfigs['lj_companysite'] = $listjobconfig['visitor_lj_companysite'];
                    $listjobconfigs['lj_country'] = $listjobconfig['visitor_lj_country'];
                    $listjobconfigs['lj_state'] = $listjobconfig['visitor_lj_state'];
                    $listjobconfigs['lj_county'] = $listjobconfig['visitor_lj_county'];
                    $listjobconfigs['lj_city'] = $listjobconfig['visitor_lj_city'];
                    $listjobconfigs['lj_salary'] = $listjobconfig['visitor_lj_salary'];
                    $listjobconfigs['lj_created'] = $listjobconfig['visitor_lj_created'];
                    $listjobconfigs['lj_noofjobs'] = $listjobconfig['visitor_lj_noofjobs'];
                    $listjobconfigs['lj_description'] = $listjobconfig['visitor_lj_description'];
                    $listjobconfigs['lj_shortdescriptionlenght'] = $listjobconfig['lj_shortdescriptionlenght'];
                    $listjobconfigs['lj_joblistingstyle'] = $listjobconfig['lj_joblistingstyle'];
                }else $listjobconfigs = $listjobconfig; // user

                $result[0] = $this->_applications;
		$result[1] = $total;
		$result[2]=$listjobconfigs;
		$result[3]=$searchjobconfig;
		$result[4]=$canview;
		return $result;
	}

	function &getResumeSearch($uid,$title,$name,$nationality,$gender,$iamavailable,$jobcategory,$jobsubcategory,$jobtype,$jobstatus,$currency,$jobsalaryrange,$education
								, $experience,$sortby,$limit,$limitstart )
	{
		$db = &$this->getDBO();
		if (($this->_jversion == '1.5') || ($this->_jversion == '2.5')) $name = $db->getEscaped( $name, true ); else $name = $db->escape( $name, true );

		if (is_numeric($uid) == false) return false;
		if (($uid == 0) || ($uid == '')) return false;

		$query = "SELECT  package.resumesearch
				FROM `#__js_job_employerpackages` AS package
				JOIN `#__js_job_employerpaymenthistory` AS payment ON payment.packageid = package.id
				WHERE payment.uid = ".$uid."
				AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
				AND payment.transactionverified = 1 AND payment.status = 1";
		//echo $query;
		$db->setQuery($query);
		$results = $db->loadObjectList();
		$cansearch = 0;
		foreach($results AS $result){
			if($result->resumesearch != -1){
				$cansearch += $result->resumesearch;
			}
		}
		if($cansearch == 0){ $result = false;return $result;}
		
		//if ($nationality != '') $wherequery .= " AND resume.nationality = ".$db->Quote($nationality);
		if ($gender != '') if( is_numeric($gender) == false) return false;
		if ($iamavailable != '') if( is_numeric($iamavailable) == false) return false;
		if ($jobcategory != '') if( is_numeric($jobcategory) == false) return false;
		if ($jobsubcategory != '') if( is_numeric($jobsubcategory) == false) return false;
		if ($jobtype != '') if( is_numeric($jobtype) == false) return false;
		if ($jobsalaryrange != '') if( is_numeric($jobsalaryrange) == false) return false;
		if ($education != '') if( is_numeric($education) == false) return false;
		if ($currency != '') if( is_numeric($currency) == false) return false;
                $query = "SELECT package.saveresumesearch, package.packageexpireindays, payment.created
		FROM `#__js_job_employerpackages` AS package
		JOIN `#__js_job_employerpaymenthistory` AS payment ON payment.packageid = package.id
		WHERE payment.uid = ".$uid."
		AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()";
		$db->setQuery($query);
		$jobs = $db->loadObjectList();
                $canview = 0;
		foreach($jobs AS $job){
			if ($job->saveresumesearch == 1){
				   $canview = 1;
				   break;
			}else $canview = 0;
		}

		$result = array();
		$searchresumeconfig = $this->getConfigByFor('searchresume');
		$wherequery = '';
		if ($title != '') $wherequery .= " AND resume.application_title LIKE '%".str_replace("'","",$db->Quote($title))."%'";
		if ($name!= '') {
			$wherequery .= " AND (";
				$wherequery .= " LOWER(resume.first_name) LIKE ".$db->Quote( '%'. $name.'%', false );
				$wherequery .= " OR LOWER(resume.last_name) LIKE ".$db->Quote( '%'. $name.'%', false );
				$wherequery .= " OR LOWER(resume.middle_name) LIKE ".$db->Quote( '%'. $name.'%', false );
			$wherequery .= " )";
		}

		if ($nationality != '') $wherequery .= " AND resume.nationality = ".$db->Quote($nationality);
		if ($gender != '') $wherequery .= " AND resume.gender = ".$gender;
		if ($iamavailable != '') $wherequery .= " AND resume.iamavailable = ".$iamavailable;
		if ($jobcategory != '') $wherequery .= " AND resume.job_category = ".$jobcategory;
		if ($jobsubcategory != '') $wherequery .= " AND resume.job_subcategory = ".$jobsubcategory;
		if ($jobtype != '') $wherequery .= " AND resume.jobtype = ".$jobtype;
		if ($jobsalaryrange != '') $wherequery .= " AND resume.jobsalaryrange = ".$jobsalaryrange;
		if ($education != '') $wherequery .= " AND resume.heighestfinisheducation = ".$education;
		if ($experience != '') $wherequery .= " AND resume.total_experience LIKE ".$db->Quote($experience);

		$query = "SELECT count(resume.id) FROM `#__js_job_resume` AS resume, `#__js_job_categories` AS cat
				WHERE resume.job_category = cat.id AND resume.status = 1 AND resume.searchable = 1  ";
		$query .= $wherequery;
		$db->setQuery($query);
		$total = $db->loadResult();
		if ( $total <= $limitstart ) $limitstart = 0;

                $query = "SELECT  resume.*, cat.cat_title, jobtype.title AS jobtypetitle
								, salary.rangestart, salary.rangeend , country.name AS countryname
								, city.name AS cityname,county.name AS countyname,state.name AS statename
								, currency.symbol as symbol	

				FROM `#__js_job_resume` AS resume
				JOIN `#__js_job_jobtypes` AS jobtype ON resume.jobtype = jobtype.id
				LEFT JOIN `#__js_job_salaryrange` AS salary ON resume.jobsalaryrange = salary.id
				LEFT JOIN `#__js_job_countries` AS country ON resume.employer_country = country.code
				LEFT JOIN `#__js_job_states` AS state ON resume.employer_state= state.code
				LEFT JOIN `#__js_job_counties` AS county ON resume.employer_county= county.code
				LEFT JOIN `#__js_job_cities` AS city ON resume.employer_city= city.code
				LEFT JOIN `#__js_job_currencies` AS currency ON currency.id = resume.currencyid AND resume.currencyid = " .$currency." 

				, `#__js_job_categories` AS cat ";
			$query .= "WHERE resume.job_category = cat.id AND resume.status = 1 AND resume.searchable = 1";
		$query .= $wherequery;
		$query .= " ORDER BY  ".$sortby;
		$db->setQuery($query, $limitstart, $limit);

		$result[0] = $db->loadObjectList();
		$result[1] = $total;
		$result[2] = $searchresumeconfig;
		$result[3] = $canview;
		return $result;
	}
	function &getResumeByCategoryId($uid,$jobcategory,$sortby,$limit,$limitstart)
	{
		$db = &$this->getDBO();

		if (is_numeric($uid) == false) return false;
		if (is_numeric($jobcategory) == false) return false;
		if (($uid == 0) || ($uid == '')) return false;

		$result = array();
		$query = "SELECT count(resume.id) FROM `#__js_job_resume` AS resume, `#__js_job_categories` AS cat
				WHERE cat.id = ".$jobcategory." AND resume.status = 1 AND resume.searchable = 1  ";
		$db->setQuery($query);
		$total = $db->loadResult();
		if ( $total <= $limitstart ) $limitstart = 0;
		$searchresumeconfig = $this->getConfigByFor('searchresume');

		$query = "SELECT  resume.*, cat.cat_title, jobtype.title AS jobtypetitle
						, salary.rangestart, salary.rangeend , country.name AS countryname
						, city.name AS cityname,county.name AS countyname,state.name AS statename
						, currency.symbol as symbol	
				FROM `#__js_job_resume` AS resume
				JOIN `#__js_job_categories` AS cat ON resume.job_category = cat.id
				JOIN `#__js_job_jobtypes` AS jobtype ON resume.jobtype = jobtype.id
				LEFT JOIN `#__js_job_salaryrange` AS salary ON resume.jobsalaryrange = salary.id
				LEFT JOIN `#__js_job_countries` AS country ON resume.employer_country = country.code
				LEFT JOIN `#__js_job_states` AS state ON resume.employer_state= state.code
				LEFT JOIN `#__js_job_counties` AS county ON resume.employer_county= county.code
				LEFT JOIN `#__js_job_cities` AS city ON resume.employer_city= city.code
				LEFT JOIN `#__js_job_currencies` AS currency ON currency.id = resume.currencyid ";
			$query .= " WHERE cat.id = ".$jobcategory." AND resume.status = 1 AND resume.searchable = 1";
		$query .= " ORDER BY  ".$sortby;
		$db->setQuery($query, $limitstart, $limit);
		$resume = $db->loadObjectList();
		//for categroy title
		$query = "SELECT cat_title FROM `#__js_job_categories` WHERE id = ".$jobcategory;
		$db->setQuery($query);
		$cat_title = $db->loadResult();
		
		$result[0] = $resume;
		$result[1] = $total;
		$result[2] = $searchresumeconfig;
		$result[3] = $cat_title;
		$result[4] = $jobcategory;
		return $result;
	}

// Search End
/* STRAT EXPORT RESUMES */
	function setExport($jobid){
		$db = &$this->getDBO();
		if (is_numeric($jobid) == false) return false;
		if (($jobid == 0) || ($jobid == '')) return false;
		//for job title
		$query = "SELECT title FROM `#__js_job_jobs` WHERE id = ".$jobid;
		$db->setQuery($query);
		$jobtitle = $db->loadResult();

		$result = $this->getExportResumes($jobid);
		$result = $db->loadAssocList();
		if(!$result){
			$this->setError($this->_db->getErrorMsg());
			//echo $this->_db->getErrorMsg();
			return false;
		}else{
			$result = $this->makeArrayForExport($result);
			// Empty data vars
			$data = "" ;
			// We need tabbed data
			$sep = "\t";
			$fields = (array_keys($result[0]));
			// Count all fields(will be the collumns
			$columns = count($fields);
			$data .= "Job Title".$sep.$jobtitle."\n";
			// Put the name of all fields to $out.
			for ($i = 0; $i < $columns; $i++) {
				$data .= $fields[$i].$sep;
			}
			$data .= "\n";
			// Counting rows and push them into a for loop
			for($k=0; $k < count( $result ); $k++) {
				$row = $result[$k];
				$line = '';
				// Now replace several things for MS Excel
				foreach ($row as $value) {
					$value = str_replace('"', '""', $value);
					$line .= '"' . $value . '"' . "\t";
				}
				$data .= trim($line)."\n";
			}
			$data = str_replace("\r","",$data);
			// If count rows is nothing show o records.
			if (count( $result ) == 0) {
				$data .= "\n(0) Records Found!\n";
			}
			return $data;
		}
	}
	function makeArrayForExport($result){
		foreach($result as $r){
			$myarr['Application Title'] = $r['application_title'];
			$myarr['First Name'] = $r['first_name'];
			$myarr['Last Name'] = $r['last_name'];
			$myarr['Middle Name'] = $r['middle_name'];
			$myarr['Range Start'] = $r['rangestart'];
			$myarr['Heighest Education Title'] = $r['heighesteducationtitle'];
			if($r['gender'] == 1) $myarr['Gender'] =  JText::_('JS_MALE'); elseif($r['gender'] == 2) $myarr['Gender'] = JText::_('JS_FEMALE');else $myarr['Gender'] = JText::_('JS_DOES_NOT_MATTER');
			$myarr['Email Address'] = $r['email_address'];
			$myarr['Home Phone'] = $r['home_phone'];
			$myarr['Work Phone'] = $r['work_phone'];
			$myarr['Cell'] = $r['cell'];
			$myarr['I\'am Available'] = $r['iamavailable'];
			if($r['searchable'] == 1) $myarr['Searchable'] = JText::_('JS_YES');else $myarr['Searchable'] = JText::_('JS_NO');
			$myarr['Job Category'] = $r['categorytitle'];
			$myarr['Job Salaryrange'] = $r['rangestart'].'-'.$r['rangeend'];
			$myarr['Jobtype'] = $r['jobtypetitle'];
			if($r['address_city2']) $myarr['Address City'] =$r['address_city2']; else $myarr['Address City'] =$r['address_city'];
			if($r['address_county2']) $myarr['Address County'] = $r['address_county2']; else $myarr['Address County'] = $r['address_county'];
			if($r['address_state2']) $myarr['Address State'] = $r['address_state2']; else $myarr['Address State'] = $r['address_state'];
			if($r['address_country2']) $myarr['Address Country'] = $r['address_country2']; else $myarr['Address Country'] = $r['address_country'];
			$myarr['Address Zipcode'] = $r['address_zipcode'];
			$myarr['Address'] = $r['address'];
			$myarr['Institute'] = $r['institute'];
			if($r['institute_city2']) $myarr['Institute City'] = $r['institute_city2']; else $myarr['Institute City'] = $r['institute_city'];
			if($r['institute_county2']) $myarr['Institute County'] = $r['institute_county2']; else $myarr['Institute County'] = $r['institute_county'];
			if($r['institute_state2']) $myarr['Institute State'] = $r['institute_state2']; else $myarr['Institute State'] = $r['institute_state'];
			if($r['institute_country2']) $myarr['Institute Country'] = $r['institute_country2']; else $myarr['Institute Country'] = $r['institute_country'];
			$myarr['Institute_address'] = $r['institute_address'];
			$myarr['Institute Certificate Name'] = $r['institute_certificate_name'];
			$myarr['Institute Study Area'] = $r['institute_study_area'];
			$myarr['Employer'] = $r['employer'];
			$myarr['Employer Position'] = $r['employer_position'];
			$myarr['Employer Resp'] = $r['employer_resp'];
			$myarr['Employer Pay Upon Leaving'] = $r['employer_pay_upon_leaving'];
			$myarr['Employer Supervisor'] = $r['employer_supervisor'];
			$myarr['Employer From Date'] = $r['employer_from_date'];
			$myarr['Employer To Date'] = $r['employer_to_date'];
			$myarr['Employer Leave Reason'] = $r['employer_leave_reason'];
			if($r['employer_city2']) $myarr['Employer City'] = $r['employer_city2']; else $myarr['Employer City'] = $r['employer_city'];
			if($r['employer_county2']) $myarr['Employer County'] = $r['employer_county2']; else $myarr['Employer County'] = $r['employer_county'];
			if($r['employer_state2']) $myarr['Employer State'] = $r['employer_state2']; else $myarr['Employer State'] = $r['employer_state'];
			if($r['employer_country2']) $myarr['Employer Country'] = $r['employer_country2']; else $myarr['Employer Country'] = $r['employer_country'];
			$myarr['Employer Zip'] = $r['employer_zip'];
			$myarr['Employer Phone'] = $r['employer_phone'];
			$myarr['Employer Address'] = $r['employer_address'];
			$myarr['Institute-1'] = $r['institute1'];
			if($r['institute1_city2']) $myarr['Institute-1 City'] = $r['institute1_city2']; else $myarr['Institute-1 city'] = $r['institute1_city'];
			if($r['institute1_county2']) $myarr['Institute-1 County'] = $r['institute1_county2']; else $myarr['Institute-1 County'] = $r['institute1_county'];
			if($r['institute1_state2']) $myarr['Institute-1 State'] = $r['institute1_state2']; else $myarr['Institute-1 State'] = $r['institute1_state'];
			if($r['institute1_country2']) $myarr['Institute-1 Country'] = $r['institute1_country2']; else $myarr['Institute-1 Country'] = $r['institute1_country'];
			$myarr['Institute-1 Address'] = $r['institute1_address'];
			$myarr['Institute-1 Certificate Name'] = $r['institute1_certificate_name'];
			$myarr['Institute-2'] = $r['institute2'];
			if($r['institute2_city2']) $myarr['Institute-2 City'] = $r['institute2_city2']; else $myarr['Institute-2 City'] = $r['institute2_city'];
			if($r['institute2_county2']) $myarr['Institute-2 County'] = $r['institute2_county2']; else $myarr['Institute-2 County'] = $r['institute2_county'];
			if($r['institute2_state2']) $myarr['Institute-2 State'] = $r['institute2_state2']; else $myarr['Institute-2 State'] = $r['institute2_state'];
			if($r['institute2_country2']) $myarr['Institute-2 Country'] = $r['institute2_country2']; else $myarr['Institute-2 Country'] = $r['institute2_country'];
			$myarr['Institute-2 Address'] = $r['institute2_address'];
			$myarr['Institute-2 Certificate Name'] = $r['institute2_certificate_name'];
			$myarr['Institute-2 Study Area'] = $r['institute2_study_area'];
			$myarr['Institute-3'] = $r['institute3'];
			if($r['institute3_city2']) $myarr['Institute-3 City'] = $r['institute3_city2']; else $myarr['Institute-3 City'] = $r['institute3_city'];
			if($r['institute3_county2']) $myarr['Institute-3 County'] = $r['institute3_county2']; else $myarr['Institute-3 County'] = $r['institute3_county'];
			if($r['institute3_state2']) $myarr['Institute-3 State'] = $r['institute3_state2']; else $myarr['Institute-3 State'] = $r['institute3_state'];
			if($r['institute3_country2']) $myarr['Institute-3 Country'] = $r['institute3_country2']; else $myarr['Institute-3 Country'] = $r['institute3_country'];
			$myarr['Institute-3 Address'] = $r['institute3_address'];
			$myarr['Institute-3 Study Area'] = $r['institute3_study_area'];
			$myarr['Employer-1'] = $r['employer1'];
			$myarr['Employer-1 Position'] = $r['employer1_position'];
			$myarr['Employer-1 Resp'] = $r['employer1_resp'];
			$myarr['Employer-1 Pay Upon Leaving'] = $r['employer1_pay_upon_leaving'];
			$myarr['Employer-1 Supervisor'] = $r['employer1_supervisor'];
			$myarr['Employer-1 From Date'] = $r['employer1_from_date'];
			$myarr['Employer-1 To Date'] = $r['employer1_to_date'];
			if($r['employer1_city2']) $myarr['Employer-1 City'] = $r['employer1_city2']; else $myarr['Employer-1 City'] = $r['employer1_city'];
			if($r['employer1_county2']) $myarr['Employer-1 County'] = $r['employer1_county2']; else $myarr['Employer-1 County'] = $r['employer1_county'];
			if($r['employer1_state2']) $myarr['Employer-1 State'] = $r['employer1_state2']; else $myarr['Employer-1 State'] = $r['employer1_state'];
			if($r['employer1_country2']) $myarr['Employer-1 Country'] = $r['employer1_country2']; else $myarr['Employer-1 Country'] = $r['employer1_country'];
			$myarr['Employer-1 Zip'] = $r['employer1_zip'];
			$myarr['Employer-1 Phone'] = $r['employer1_phone'];
			$myarr['Employer-1 Address'] = $r['employer1_address'];
			$myarr['Employer-2'] = $r['employer2'];
			$myarr['Employer-2 Position'] = $r['employer2_position'];
			$myarr['Employer-2 Resp'] = $r['employer2_resp'];
			$myarr['Employer-2 Pay Upon Leaving'] = $r['employer2_pay_upon_leaving'];
			$myarr['Employer-2 Supervisor'] = $r['employer2_supervisor'];
			$myarr['Employer-2 From Date'] = $r['employer2_from_date'];
			$myarr['Employer-2 To Date'] = $r['employer2_to_date'];
			$myarr['Employer-2 Leave Reason'] = $r['employer2_leave_reason'];
			if($r['employer2_city2']) $myarr['Employer-2 City'] = $r['employer2_city2']; else $myarr['Employer-2 City'] = $r['employer2_city'];
			if($r['employer2_county2']) $myarr['Employer-2 County'] = $r['employer2_county2']; else $myarr['Employer-2 County'] = $r['employer2_county'];
			if($r['employer2_state2']) $myarr['Employer-2 State'] = $r['employer2_state2']; else $myarr['Employer-2 State'] = $r['employer2_state'];
			if($r['employer2_country2']) $myarr['Employer-2 Country'] = $r['employer2_country2']; else $myarr['Employer-2 Country'] = $r['employer2_country'];
			$myarr['Employer-2 Zip'] = $r['employer2_zip'];
			$myarr['Employer-2 Address'] = $r['employer2_address'];
			$myarr['Employer-2 Phone'] = $r['employer2_phone'];
			$myarr['Employer-3'] = $r['employer3'];
			$myarr['Employer-3 Position'] = $r['employer3_position'];
			$myarr['Employer-3 Resp'] = $r['employer3_resp'];
			$myarr['Employer-3 Pay Upon Leaving'] = $r['employer3_pay_upon_leaving'];
			$myarr['Employer-3 Supervisor'] = $r['employer3_supervisor'];
			$myarr['Employer-3 From Date'] = $r['employer3_from_date'];
			$myarr['Employer-3 To Date'] = $r['employer3_to_date'];
			$myarr['Employer-3 Leave Reason'] = $r['employer3_leave_reason'];
			if($r['employer3_city2']) $myarr['Employer-3 City'] = $r['employer3_city2']; else $myarr['Employer-3 City'] = $r['employer3_city'];
			if($r['employer3_county2']) $myarr['Employer-3 County'] = $r['employer3_county2']; else $myarr['Employer-3 County'] = $r['employer3_county'];
			if($r['employer3_state2']) $myarr['Employer-3 State'] = $r['employer3_state2']; else $myarr['Employer-3 State'] = $r['employer3_state'];
			if($r['employer3_country2']) $myarr['Employer-3 Country'] = $r['employer3_country2']; else $myarr['Employer-3 Country'] = $r['employer3_country'];
			$myarr['Employer-3 Zip'] = $r['employer3_zip'];
			$myarr['Employer-3 Phone'] = $r['employer3_phone'];
			$myarr['Langugage Reading'] = $r['langugage_reading'];
			$myarr['Langugage Writing'] = $r['langugage_writing'];
			$myarr['Langugage Undarstanding'] = $r['langugage_undarstanding'];
			$myarr['Langugage Where Learned'] = $r['langugage_where_learned'];
			$myarr['Language-1'] = $r['language1'];
			$myarr['Langugage-1 Reading'] = $r['langugage1_reading'];
			$myarr['Langugage-1 Writing'] = $r['langugage1_writing'];
			$myarr['Langugage-1 Undarstanding'] = $r['langugage1_undarstanding'];
			$myarr['Langugage-1 Where Learned'] = $r['langugage1_where_learned'];
			$myarr['Language-2'] = $r['language2'];
			$myarr['Langugage-2 Reading'] = $r['langugage2_reading'];
			$myarr['Langugage-2 Writing'] = $r['langugage2_writing'];
			$myarr['Langugage-2 Undarstanding'] = $r['langugage2_undarstanding'];
			$myarr['Langugage-2 Where Learned'] = $r['langugage2_where_learned'];
			$myarr['Language-3'] = $r['language3'];
			$myarr['Langugage-3 Reading'] = $r['langugage3_reading'];
			$myarr['Langugage-3 Writing'] = $r['langugage3_writing'];
			$myarr['Langugage-3 Undarstanding'] = $r['langugage3_undarstanding'];
			$myarr['Langugage-3 Where Learned'] = $r['langugage3_where_learned'];
			if($r['date_start'] != '0000-00-00 00:00:00' || $r['date_start'] != '') $myarr['Date Start'] = $r['date_start'];else $myarr['Date Start'] ='';
			if($r['date_of_birth'] != '0000-00-00 00:00:00' || $r['date_of_birth'] != '') $myarr['Date Of Birth'] = $r['date_of_birth'];else $myarr['Date Of Birth'] ='';
			$myarr['Desired Salary'] = $r['desired_salary'];
			$myarr['Can Work'] = $r['can_work'];
			$myarr['Available'] = $r['available'];
			$myarr['Unalailable'] = $r['unalailable'];
			$myarr['Total Experience'] = $r['totalexperience'];
			$myarr['Skills'] = $r['skills'];
			$myarr['Driving License'] = $r['driving_license'];
			$myarr['License No'] = $r['license_no'];
			$myarr['License Country'] = $r['license_country'];
			$myarr['Reference'] = $r['reference'];
			$myarr['Reference Name'] = $r['reference_name'];
			if($r['reference_city2']) $myarr['Reference City'] = $r['reference_city2']; else $myarr['Reference City'] = $r['reference_city'];
			if($r['reference_county2']) $myarr['Reference County'] = $r['reference_county2']; else $myarr['Reference County'] = $r['reference_county'];
			if($r['reference_state2']) $myarr['Reference State'] = $r['reference_state2']; else $myarr['Reference State'] = $r['reference_state'];
			if($r['reference_country2']) $myarr['Reference Country'] = $r['reference_country2']; else $myarr['Reference Country'] = $r['reference_country'];
			$myarr['Reference Zipcode'] = $r['reference_zipcode'];
			$myarr['Reference Address'] = $r['reference_address'];
			$myarr['Reference Phone'] = $r['reference_phone'];
			$myarr['Reference Relation'] = $r['reference_relation'];
			$myarr['Reference Years'] = $r['reference_years'];
			$myarr['Reference-1'] = $r['reference1'];
			$myarr['Reference-1 Name'] = $r['reference1_name'];
			if($r['reference1_city2']) $myarr['Reference-1 City'] = $r['reference1_city2']; else $myarr['Reference-1 City'] = $r['reference1_city'];
			if($r['reference1_county2']) $myarr['Reference-1 County'] = $r['reference1_county2']; else $myarr['Reference-1 County'] = $r['reference1_county'];
			if($r['reference1_state2']) $myarr['Reference-1 State'] = $r['reference1_state2']; else $myarr['Reference-1 State'] = $r['reference1_state'];
			if($r['reference1_country2']) $myarr['Reference-1 Country'] = $r['reference1_country2']; else $myarr['Reference-1 Country'] = $r['reference1_country'];
			$myarr['Reference-1 Address'] = $r['reference1_address'];
			$myarr['Reference-1 Phone'] = $r['reference1_phone'];
			$myarr['Reference-1 Relation'] = $r['reference1_relation'];
			$myarr['Reference-1 Years'] = $r['reference1_years'];
			$myarr['Reference-2'] = $r['reference2'];
			$myarr['Reference-2 Name'] = $r['reference2_name'];
			$myarr['Reference-2 Country'] = $r['reference2_country'];
			$myarr['Reference-2 State'] = $r['reference2_state'];
			$myarr['Reference-2 County'] = $r['reference2_county'];
			$myarr['Reference-2 City'] = $r['reference2_city'];
			$myarr['Reference-2 Address'] = $r['reference2_address'];
			$myarr['Reference-2 Phone'] = $r['reference2_phone'];
			$myarr['Reference-2 Relation'] = $r['reference2_relation'];
			$myarr['Reference-2 Years'] = $r['reference2_years'];
			$myarr['Reference-3'] = $r['reference3'];
			$myarr['Reference-3 Name'] = $r['reference3_name'];
			$myarr['Reference-3 Country'] = $r['reference3_country'];
			$myarr['Reference-3 State'] = $r['reference3_state'];
			$myarr['Reference-3 County'] = $r['reference3_county'];
			$myarr['Reference-3 City'] = $r['reference3_city'];
			$myarr['Reference-3 Address'] = $r['reference3_address'];
			$myarr['Reference-3 Phone'] = $r['reference3_phone'];
			$myarr['Reference-3 Relation'] = $r['reference3_relation'];
			$myarr['Reference-3 Years'] = $r['reference3_years'];
			if($r['address1_city2']) $myarr['Address-1 City'] = $r['address1_city2']; else $myarr['Address-1 City'] = $r['address1_city'];
			if($r['address1_county2']) $myarr['Address-1 County'] = $r['address1_county2']; else $myarr['Address-1 County'] = $r['address1_county'];
			if($r['address1_state2']) $myarr['Address-1 State'] = $r['address1_state2']; else $myarr['Address-1 State'] = $r['address1_state'];
			if($r['address1_country2']) $myarr['Address-1 Country'] = $r['address1_country2']; else $myarr['Address-1 Country'] = $r['address1_country'];
			$myarr['Address-1 Zipcode'] = $r['address1_zipcode'];
			$myarr['Address-1'] = $r['address1'];
			if($r['address2_city2']) $myarr['Address-2 City'] = $r['address2_city2']; else $myarr['Address-2 City'] = $r['address2_city'];
			if($r['address2_county2']) $myarr['Address-2 County'] = $r['address2_county2']; else $myarr['Address-2 County'] = $r['address2_county'];
			if($r['address2_state2']) $myarr['Address-2 State'] = $r['address2_state2']; else $myarr['Address-2 State'] = $r['address2_state'];
			if($r['address2_country2']) $myarr['Address-2 Country'] = $r['address2_country2']; else $myarr['Address-2 Country'] = $r['address2_country'];
			$myarr['Address-2 Zipcode'] = $r['address2_zipcode'];
			$myarr['Address-2'] = $r['address2'];
			$myarr['Reference-1 Zipcode'] = $r['reference1_zipcode'];
			$myarr['Reference-2 Zipcode'] = $r['reference2_zipcode'];
			$myarr['Reference-3 Zipcode'] = $r['reference3_zipcode'];
			$myarr['Apply Date'] = $r['apply_date'];
			$myarr['Comments'] = $r['comments'];

			$returnvalue[] = $myarr;

		}
		return $returnvalue;

	}
/* END EXPORT RESUMES */
        function getExportResumes($jobid){
            $db = &$this->getDBO();
            $query = "SELECT resume.*,applyjob.apply_date AS apply_date,applyjob.comments AS comments,cat.cat_title AS categorytitle,salary.rangestart AS rangestart,salary.rangeend AS rangeend,jobtype.title AS jobtypetitle,heighesteducation.title AS heighesteducationtitle,
                            nationality_country.name AS nationalitycountry,address_city.name AS address_city2,address_county.name AS address_county2,address_state.name AS address_state2,
                            address_country.name AS address_country2,address1_city.name AS address1_city2,address1_county.name AS address1_county2,address1_state.name AS address1_state2,
                            address1_country.name AS address1_country2,address2_city.name AS address2_city2,address2_county.name AS address2_county2,address2_state.name AS address2_state2,
                            address2_country.name AS address2_country2,institute_city.name AS institute_city2,institute_county.name AS institute_county2,institute_state.name AS institute_state2,
                            institute_country.name AS institute_country2,institute1_city.name AS institute1_city2,institute1_county.name AS institute1_county2,institute1_state.name AS institute1_state2,
                            institute1_country.name AS institute1_country2,institute2_city.name AS institute2_city2,institute2_county.name AS institute2_county2,institute2_state.name AS institute2_state2,
                            institute2_country.name AS institute2_country2,institute3_city.name AS institute3_city2,institute3_county.name AS institute3_county2,institute3_state.name AS institute3_state2,
                            institute3_country.name AS institute3_country2,employer_city.name AS employer_city2,employer_county.name AS employer_county2,employer_state.name AS employer_state2,
                            employer_country.name AS employer_country2,employer1_city.name AS employer1_city2,employer1_county.name AS employer1_county2,employer1_state.name AS employer1_state2,
                            employer1_country.name AS employer1_country2,employer2_city.name AS employer2_city2,employer2_county.name AS employer2_county2,employer2_state.name AS employer2_state2,
                            employer2_country.name AS employer2_country2,employer3_city.name AS employer3_city2,employer3_county.name AS employer3_county2,employer3_state.name AS employer3_state2,
                            employer3_country.name AS employer3_country2,reference_city.name AS reference_city2,reference_county.name AS reference_county2,reference_state.name AS reference_state2,
                            reference_country.name AS reference_country2,reference1_city.name AS reference1_city2,reference1_county.name AS reference1_county2,reference1_state.name AS reference1_state2,
                            reference1_country.name AS reference1_country2,resume.id AS id,resume.uid AS uid,resume.application_title AS application_title,resume.first_name AS first_name,
                            resume.last_name AS last_name,resume.middle_name AS middle_name,resume.gender AS gender,resume.email_address AS email_address,resume.home_phone AS home_phone,resume.work_phone AS work_phone,
                            resume.cell AS cell,resume.nationality AS iamavailable,resume.searchable AS searchable,resume.photo AS photo,resume.job_category AS job_category,resume.jobsalaryrange AS jobsalaryrange,
                            resume.jobtype AS jobtype,resume.heighestfinisheducation AS heighestfinisheducation,resume.address_country AS address_country,resume.address_state AS address_state,resume.address_city AS address_city,
                            resume.address_zipcode AS address_zipcode,resume.address AS address,resume.institute AS institute,resume.institute_country AS institute_country,resume.institute_state AS institute_state,
                            resume.institute_county AS institute_county,resume.institute_city AS institute_city,resume.institute_address AS institute_address,resume.institute_certificate_name AS institute_certificate_name,
                            resume.institute_study_area AS institute_study_area,resume.employer AS employer,resume.employer_position AS employer_position,resume.employer_resp AS employer_resp,resume.employer_pay_upon_leaving AS employer_pay_upon_leaving,
                            resume.employer_supervisor AS employer_supervisor,resume.employer_from_date AS employer_from_date,resume.employer_to_date AS employer_to_date,resume.employer_leave_reason AS employer_leave_reason,resume.employer_country AS employer_country,
                            resume.employer_state AS employer_state,resume.employer_county AS employer_county,resume.employer_city AS employer_city,resume.employer_zip AS employer_zip,resume.employer_phone AS employer_phone,resume.employer_address AS employer_address,
                            resume.institute1 AS institute1,resume.institute1_country AS institute1_country,resume.institute1_state AS institute1_state,resume.institute1_county AS institute1_county,resume.institute1_city AS institute1_city,resume.institute1_address AS institute1_address,
                            resume.institute1_certificate_name AS institute1_certificate_name,resume.institute1_study_area AS institute2,resume.institute2_country AS institute2_country,resume.institute2_state AS institute2_state,resume.institute2_county AS institute2_county,resume.institute2_city AS institute2_city,
                            resume.institute2_address AS institute2_address,resume.institute2_certificate_name AS institute2_certificate_name,resume.institute2_study_area AS institute2_study_area,resume.institute3 AS institute3,resume.institute3_country AS institute3_country,resume.institute3_state AS institute3_state,
                            resume.institute3_county AS institute3_county,resume.institute3_city AS institute3_city,resume.institute3_address AS institute3_address,resume.institute3_study_area AS institute3_study_area,resume.institute3_certificate_name AS employer1,resume.employer1_position AS employer1_position,
                            resume.employer1_resp AS employer1_resp,resume.employer1_pay_upon_leaving AS employer1_pay_upon_leaving,resume.employer1_supervisor AS employer1_supervisor,resume.employer1_from_date AS employer1_from_date,resume.employer1_to_date AS employer1_to_date,resume.employer1_leave_reason AS employer1_country,
                            resume.employer1_state AS employer1_state,resume.employer1_county AS employer1_county,resume.employer1_city AS employer1_city,resume.employer1_zip AS employer1_zip,resume.employer1_phone AS employer1_phone,resume.employer1_address AS employer1_address,resume.employer2 AS employer2,resume.employer2_position AS employer2_position,
                            resume.employer2_resp AS employer2_resp,resume.employer2_pay_upon_leaving AS employer2_pay_upon_leaving,resume.employer2_supervisor AS employer2_supervisor,resume.employer2_from_date AS employer2_from_date,resume.employer2_to_date AS employer2_to_date,resume.employer2_leave_reason AS employer2_leave_reason,resume.employer2_country AS employer2_country,
                            resume.employer2_state AS employer2_state,resume.employer2_county AS employer2_county,resume.employer2_city AS employer2_city,resume.employer2_zip AS employer2_zip,resume.employer2_address AS employer2_address,resume.employer2_phone AS employer2_phone,resume.employer3 AS employer3,resume.employer3_position AS employer3_position,resume.employer3_resp AS employer3_resp,
                            resume.employer3_pay_upon_leaving AS employer3_pay_upon_leaving,resume.employer3_supervisor AS employer3_supervisor,resume.employer3_from_date AS employer3_from_date,resume.employer3_to_date AS employer3_to_date,resume.employer3_leave_reason AS employer3_leave_reason,resume.employer3_country AS employer3_country,resume.employer3_state AS employer3_state,resume.employer3_county AS employer3_county,
                            resume.employer3_city AS employer3_city,resume.employer3_zip AS employer3_zip,resume.employer3_address AS employer3_phone,resume.langugage_reading AS langugage_reading,resume.langugage_writing AS langugage_writing,resume.langugage_undarstanding AS langugage_undarstanding,resume.langugage_where_learned AS langugage_where_learned,resume.language1 AS language1,
                            resume.langugage1_reading AS langugage1_reading,resume.langugage1_writing AS langugage1_writing,resume.langugage1_undarstanding AS langugage1_undarstanding,resume.langugage1_where_learned AS langugage1_where_learned,resume.language2 AS language2,resume.langugage2_reading AS langugage2_reading,resume.langugage2_writing AS langugage2_writing,resume.langugage2_undarstanding AS langugage2_undarstanding,
                            resume.langugage2_where_learned AS langugage2_where_learned,resume.language3 AS language3,resume.langugage3_reading AS langugage3_reading,resume.langugage3_writing AS langugage3_writing,resume.langugage3_undarstanding AS langugage3_undarstanding,resume.langugage3_where_learned AS langugage3_where_learned,resume.date_start AS date_start,resume.desired_salary AS desired_salary,resume.can_work AS can_work,
                            resume.available AS available,resume.unalailable AS unalailable,resume.total_experience AS total_experience,resume.skills AS skills,resume.driving_license AS driving_license,resume.license_no AS license_no,resume.license_country AS license_country,resume.reference AS reference,resume.reference_name AS reference_name,resume.reference_country AS reference_country,resume.reference_state AS reference_state,
                            resume.reference_county AS reference_county,resume.reference_city AS reference_city,resume.reference_zipcode AS reference_zipcode,resume.reference_address AS reference_address,resume.reference_phone AS reference_phone,resume.reference_relation AS reference_relation,resume.reference_years AS reference_years,resume.reference1 AS reference1,resume.reference1_name AS reference1_name,
                            resume.reference1_country AS reference1_country,resume.reference1_state AS reference1_state,resume.reference1_county AS reference1_city,resume.reference1_address AS reference1_address,resume.reference1_phone AS reference1_phone,resume.reference1_relation AS reference1_relation,resume.reference1_years AS reference1_years,resume.reference2 AS reference2,resume.reference2_name AS reference2_name,
                            resume.reference2_country AS reference2_country,resume.reference2_state AS reference2_state,resume.reference2_county AS reference2_county,resume.reference2_city AS reference2_city,resume.reference2_address AS reference2_address,resume.reference2_phone AS reference2_phone,resume.reference2_relation AS reference2_relation,resume.reference2_years AS reference2_years,resume.reference3 AS reference3,
                            resume.reference3_name AS reference3_name,resume.reference3_country AS reference3_country,resume.reference3_state AS reference3_state,resume.reference3_county AS reference3_county,resume.reference3_city AS reference3_city,resume.reference3_address AS reference3_address,resume.reference3_phone AS reference3_phone,
                            resume.reference3_relation AS reference3_relation,resume.reference3_years AS reference3_years,resume.address1_country AS address1_country,resume.address1_state AS address1_state,resume.address1_county AS address1_county,resume.address1_city AS address1_city,resume.address1_zipcode AS address1_zipcode,
                            resume.address1 AS address1,resume.address2_country AS address2_country,resume.address2_state AS address2_state,resume.address2_county AS address2_county,resume.address2_city AS address2_city,resume.address2_zipcode AS address2_zipcode,resume.address2 AS address2,resume.reference1_zipcode AS reference1_zipcode,resume.reference2_zipcode AS reference2_zipcode,resume.reference3_zipcode AS reference3_zipcode,resume.packageid AS packageid,resume.paymenthistoryid AS paymenthistoryid,resume.status AS status,
                            totalexperience.title AS totalexperience
                                FROM `#__js_job_resume` AS resume
                                JOIN `#__js_job_categories` AS cat ON resume.job_category = cat.id
                                JOIN `#__js_job_jobtypes` AS jobtype ON resume.jobtype = jobtype.id
                                JOIN `#__js_job_jobapply` AS applyjob ON applyjob.jobid = ".$jobid."
                                LEFT JOIN `#__js_job_experiences` AS totalexperience ON resume.total_experience = totalexperience.id
                                LEFT JOIN `#__js_job_heighesteducation` AS heighesteducation ON resume.heighestfinisheducation = heighesteducation.id
                                LEFT JOIN `#__js_job_countries` AS nationality_country ON resume.nationality = nationality_country.code
                                LEFT JOIN `#__js_job_salaryrange` AS salary ON resume.jobsalaryrange = salary.id
                                LEFT JOIN `#__js_job_cities` AS address_city ON resume.address_city = address_city.code
                                LEFT JOIN `#__js_job_counties` AS address_county ON resume.address_county = address_county.code
                                LEFT JOIN `#__js_job_states` AS address_state ON resume.address_state = address_state.code
                                LEFT JOIN `#__js_job_countries` AS address_country ON resume.address_country = address_country.code
                                LEFT JOIN `#__js_job_cities` AS address1_city ON resume.address1_city = address1_city.code
                                LEFT JOIN `#__js_job_counties` AS address1_county ON resume.address1_county = address1_county.code
                                LEFT JOIN `#__js_job_states` AS address1_state ON resume.address1_state = address1_state.code
                                LEFT JOIN `#__js_job_countries` AS address1_country ON resume.address1_country = address1_country.code
                                LEFT JOIN `#__js_job_cities` AS address2_city ON resume.address2_city = address2_city.code
                                LEFT JOIN `#__js_job_counties` AS address2_county ON resume.address2_county = address2_county.code
                                LEFT JOIN `#__js_job_states` AS address2_state ON resume.address2_state = address2_state.code
                                LEFT JOIN `#__js_job_countries` AS address2_country ON resume.address2_country = address2_country.code
                                LEFT JOIN `#__js_job_cities` AS institute_city ON resume.institute_city = institute_city.code
                                LEFT JOIN `#__js_job_counties` AS institute_county ON resume.institute_county = institute_county.code
                                LEFT JOIN `#__js_job_states` AS institute_state ON resume.institute_state = institute_state.code
                                LEFT JOIN `#__js_job_countries` AS institute_country ON resume.institute_country = institute_country.code
                                LEFT JOIN `#__js_job_cities` AS  institute1_city ON resume.institute1_city = institute1_city.code
                                LEFT JOIN `#__js_job_counties` AS institute1_county ON resume.institute1_county = institute1_county.code
                                LEFT JOIN `#__js_job_states` AS institute1_state ON resume.institute1_state = institute1_state.code
                                LEFT JOIN `#__js_job_countries` AS institute1_country ON resume.institute1_country = institute1_country.code
                                LEFT JOIN `#__js_job_cities` AS institute2_city ON resume.institute2_city = institute2_city.code
                                LEFT JOIN `#__js_job_counties` AS institute2_county ON resume.institute2_county = institute2_county.code
                                LEFT JOIN `#__js_job_states` AS institute2_state ON resume.institute2_state = institute2_state.code
                                LEFT JOIN `#__js_job_countries` AS institute2_country ON resume.institute2_country = institute2_country.code
                                LEFT JOIN `#__js_job_cities` AS institute3_city ON resume.institute3_city = institute3_city.code
                                LEFT JOIN `#__js_job_counties` AS institute3_county ON resume.institute3_county = institute3_county.code
                                LEFT JOIN `#__js_job_states` AS institute3_state ON resume.institute3_state = institute3_state.code
                                LEFT JOIN `#__js_job_countries` AS institute3_country ON resume.institute3_country = institute3_country.code
                                LEFT JOIN `#__js_job_cities` AS employer_city ON resume.employer_city = employer_city.code
                                LEFT JOIN `#__js_job_counties` AS employer_county ON resume.employer_county = employer_county.code
                                LEFT JOIN `#__js_job_states` AS employer_state ON resume.employer_state = employer_state.code
                                LEFT JOIN `#__js_job_countries` AS employer_country ON resume.employer_country = employer_country.code
                                LEFT JOIN `#__js_job_cities` AS employer1_city ON resume.employer1_city = employer1_city.code
                                LEFT JOIN `#__js_job_counties` AS employer1_county ON resume.employer1_county = employer1_county.code
                                LEFT JOIN `#__js_job_states` AS employer1_state ON resume.employer1_state = employer1_state.code
                                LEFT JOIN `#__js_job_countries` AS employer1_country ON resume.employer1_country = employer1_country.code
                                LEFT JOIN `#__js_job_cities` AS employer2_city ON resume.employer2_city = employer2_city.code
                                LEFT JOIN `#__js_job_counties` AS employer2_county ON resume.employer2_county = employer2_county.code
                                LEFT JOIN `#__js_job_states` AS employer2_state ON resume.employer2_state = employer2_state.code
                                LEFT JOIN `#__js_job_countries` AS employer2_country ON resume.employer2_country = employer2_country.code
                                LEFT JOIN `#__js_job_cities` AS employer3_city ON resume.employer3_city = employer3_city.code
                                LEFT JOIN `#__js_job_counties` AS employer3_county ON resume.employer3_county = employer3_county.code
                                LEFT JOIN `#__js_job_states` AS employer3_state ON resume.employer3_state = employer3_state.code
                                LEFT JOIN `#__js_job_countries` AS employer3_country ON resume.employer3_country = employer3_country.code
                                LEFT JOIN `#__js_job_cities` AS reference_city ON resume.reference_city = reference_city.code
                                LEFT JOIN `#__js_job_counties` AS reference_county ON resume.reference_county = reference_county.code
                                LEFT JOIN `#__js_job_states` AS reference_state ON resume.reference_state = reference_state.code
                                LEFT JOIN `#__js_job_countries` AS reference_country ON resume.reference_country = reference_country.code
                                LEFT JOIN `#__js_job_cities` AS reference1_city ON resume.reference1_city = reference1_city.code
                                LEFT JOIN `#__js_job_counties` AS reference1_county ON resume.reference1_county = reference1_county.code
                                LEFT JOIN `#__js_job_states` AS reference1_state ON resume.reference1_state = reference1_state.code
                                LEFT JOIN `#__js_job_countries` AS reference1_country ON resume.reference1_country = reference1_country.code
                                WHERE resume.id = applyjob.cvid";
            $db->setQuery($query);
            $resume = $db->loadObject();
            return $resume;
        }
	function getMyStats_Employer($uid)
	{
		if (is_numeric($uid) == false) return false;
		if (($uid == 0) || ($uid == '')) return false;

                $db = &$this->getDBO();
		$results=array();
		
                // companies
                $query = "SELECT package.companiesallow,package.jobsallow,package.featuredcompaines
                    ,package.goldcompanies,package.goldjobs,package.featuredjobs
                    FROM #__js_job_employerpaymenthistory AS payment
                    JOIN #__js_job_employerpackages AS package ON package.id = payment.packageid
                    WHERE payment.uid = ".$uid."
                    AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
                    AND payment.transactionverified = 1 AND payment.status = 1";
		$db->setQuery($query);
		$packages = $db->loadObjectList();
		if(empty($packages))
		{
			$query = "SELECT package.id, package.resumeallow,package.title AS packagetitle, package.packageexpireindays, payment.id AS paymentid
							 , (TO_DAYS( CURDATE() ) - To_days( payment.created ) ) AS packageexpiredays
							FROM `#__js_job_employerpackages` AS package
							JOIN `#__js_job_employerpaymenthistory` AS payment ON payment.packageid = package.id
							WHERE payment.uid = ".$uid." 
							AND payment.transactionverified = 1 AND payment.status = 1 ORDER BY payment.created DESC";
			$db->setQuery($query);
			$packagedetail = $db->loadObjectList();
			
			$results[12] = false;
			$results[13] = $packagedetail;

                $query = "SELECT package.resumeallow,package.coverlettersallow,package.featuredresume,package.goldresume
                    FROM #__js_job_employerpackages AS package
                    JOIN #__js_job_employerpaymenthistory AS payment ON package.id = payment.packageid
                    WHERE payment.uid = ".$uid."
                    AND payment.transactionverified = 1 AND payment.status = 1";
		$db->setQuery($query);
		$packages = $db->loadObjectList();
		}
		$companiesunlimited = 0;
                $unlimitedjobs = 0;
                $unlimitedfeaturedcompaines = 0;
                $unlimitedgoldcompanies = 0;
                $unlimitedgoldjobs = 0;
                $unlimitedfeaturedjobs = 0;
				$jobsallow =0;
				$companiesallow =0;
				$goldcompaniesallow = 0;
				$goldjobsallow = 0;
				$featuredcompainesallow = 0;
				$featuredjobsallow =0;
		if(!empty($packages)){
			foreach($packages AS $package){
						if($companiesunlimited == 0){
							if ($package->companiesallow != -1) {
									$companiesallow = $companiesallow + $package->companiesallow;
							}else $companiesunlimited = 1;
						}
						if($unlimitedjobs == 0){
							if ($package->jobsallow != -1) {
									$jobsallow = $jobsallow + $package->jobsallow;
							}else $unlimitedjobs = 1;
						}
						if($unlimitedfeaturedcompaines == 0){
				if ($package->featuredcompaines != -1) {
									$featuredcompainesallow = $featuredcompainesallow + $package->featuredcompaines;
							}else $unlimitedfeaturedcompaines = 1;
						}
						if($unlimitedgoldcompanies == 0){
				if ($package->goldcompanies != -1) {
									$goldcompaniesallow = $goldcompaniesallow + $package->goldcompanies;
							}else $unlimitedgoldcompanies = 1;
						}
						if($unlimitedgoldjobs == 0){
							if ($package->goldjobs != -1) {
									$goldjobsallow = $goldjobsallow + $package->goldjobs;
							}else $unlimitedgoldjobs = 1;
						}
						if($unlimitedfeaturedjobs == 0){
				if ($package->featuredjobs != -1) {
									$featuredjobsallow = $featuredjobsallow + $package->featuredjobs;
							}else $unlimitedfeaturedjobs = 1;
						}

			}
		}

                //companies
                $query = "SELECT COUNT(company.id) FROM #__js_job_companies AS company WHERE  uid = ".$uid;
		$db->setQuery($query);
		$totalcompanies = $db->loadResult();
		
                //jobs
                $query = "SELECT COUNT(id) FROM #__js_job_jobs WHERE uid = ".$uid;
		$db->setQuery($query);
		$totaljobs = $db->loadResult();

                //featured companies
                $query = "SELECT COUNT(id) FROM #__js_job_featuredcompanies WHERE uid = ".$uid;
		$db->setQuery($query);
		$totalfeaturedcompanies = $db->loadResult();
		
                //gold companies
                $query = "SELECT COUNT(id) FROM #__js_job_goldcompanies WHERE uid = ".$uid;
		$db->setQuery($query);
		$totalgoldcompanies = $db->loadResult();
		
                //gold jobs
                $query = "SELECT COUNT(id) FROM #__js_job_goldjobs WHERE uid = ".$uid;
		$db->setQuery($query);
		$totalgoldjobs = $db->loadResult();
		
                //featured jobs
                $query = "SELECT COUNT(id) FROM #__js_job_featuredjobs WHERE uid = ".$uid;
		$db->setQuery($query);
		$totalfeaturedjobs = $db->loadResult();
		
            if($companiesunlimited == 0)  $results[0]=$companiesallow;
            elseif($companiesunlimited == 1)$results[0] = -1;
            $results[1]=$totalcompanies;
		
            if($unlimitedjobs == 0) $results[2] = $jobsallow;
            elseif($unlimitedjobs == 1) $results[2] = -1;
            $results[3]=$totaljobs;
		
            if($unlimitedfeaturedcompaines == 0) $results[4]=$featuredcompainesallow;
            elseif($unlimitedfeaturedcompaines == 1)$results[4] = -1;
            $results[5]=$totalfeaturedcompanies;
		
            if($unlimitedgoldcompanies == 0) $results[6]=$goldcompaniesallow;
            elseif($unlimitedgoldcompanies == 1) $results[6] = -1;
            $results[7] = $totalgoldcompanies;
		
            if($unlimitedgoldjobs == 0) $results[8]=$goldjobsallow;
            elseif($unlimitedgoldjobs == 1) $results[8] = -1;
            $results[9]=$totalgoldjobs;
		
            if($unlimitedfeaturedjobs == 0) $results[10]=$featuredjobsallow;
            elseif($unlimitedfeaturedjobs == 1) $results[10] = -1;
            $results[11]=$totalfeaturedjobs;
        
		
            return  $results;
			
		
	}
	
        function getMyStats_JobSeeker($uid)
	{
		if (is_numeric($uid) == false) return false;
		if (($uid == 0) || ($uid == '')) return false;

                $db = &$this->getDBO();
		$results=array();

                // resume
                $query = "SELECT package.resumeallow,package.coverlettersallow,package.featuredresume,package.goldresume
                    FROM #__js_job_jobseekerpackages AS package
                    JOIN #__js_job_jobseekerpaymenthistory AS payment ON package.id = payment.packageid
                    WHERE payment.uid = ".$uid."
                    AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
                    AND payment.transactionverified = 1 AND payment.status = 1";
		$db->setQuery($query);
		$packages = $db->loadObjectList();
		if(empty($packages))
		{
			$query = "SELECT package.id, package.resumeallow,package.title AS packagetitle, package.packageexpireindays, payment.id AS paymentid
							 , (TO_DAYS( CURDATE() ) - To_days( payment.created ) ) AS packageexpiredays
							FROM `#__js_job_jobseekerpackages` AS package
							JOIN `#__js_job_jobseekerpaymenthistory` AS payment ON payment.packageid = package.id
							WHERE payment.uid = ".$uid." 
							AND payment.transactionverified = 1 AND payment.status = 1 ORDER BY payment.created DESC";
			$db->setQuery($query);
			$packagedetail = $db->loadObjectList();
			
			$results[8] = false;
			$results[9] = $packagedetail;

                $query = "SELECT package.resumeallow,package.coverlettersallow,package.featuredresume,package.goldresume
                    FROM #__js_job_jobseekerpackages AS package
                    JOIN #__js_job_jobseekerpaymenthistory AS payment ON package.id = payment.packageid
                    WHERE payment.uid = ".$uid."
                    AND payment.transactionverified = 1 AND payment.status = 1";
		$db->setQuery($query);
		$packages = $db->loadObjectList();
		}
                $unlimitedresume = 0;
                $unlimitedfeaturedresume = 0;
                $unlimitedgoldresume = 0;
                $unlimitedcoverletters = 0;
		foreach($packages AS $package){
                    if($unlimitedresume == 0){
                        if ($package->resumeallow != -1) {
                            $resumeallow = "";
                            $resumeallow = $resumeallow + $package->resumeallow;
                        }else $unlimitedresume = 1;
                    }
                    if($unlimitedfeaturedresume == 0){
			if ($package->featuredresume != -1) {
                                $featuredresumeallow ="";
                                $featuredresumeallow = $featuredresumeallow + $package->featuredresume;
                        }else $unlimitedfeaturedresume = 1;
                    }
                    if($unlimitedgoldresume == 0){
			if ($package->goldresume != -1) {
                                $goldresumeallow ="";
                                $goldresumeallow = $goldresumeallow + $package->goldresume;
                        }else $unlimitedgoldcompanies = 1;
                    }
                    if($unlimitedcoverletters == 0){
                        if ($package->coverlettersallow != -1){
                                $coverlettersallow = "";
                                $coverlettersallow = $coverlettersallow + $package->coverlettersallow;
                        }else $unlimitedcoverletters = 1;
                    }
		}

                //resume
                $query = "SELECT COUNT(id) FROM #__js_job_resume WHERE  uid = ".$uid;
		$db->setQuery($query);
		$totalresume = $db->loadResult();

                //featured resume
                $query = "SELECT COUNT(id) FROM #__js_job_featuredresumes WHERE uid = ".$uid;
		$db->setQuery($query);
		$totalfeaturedresume = $db->loadResult();

                //gold resume
                $query = "SELECT COUNT(id) FROM #__js_job_goldresumes WHERE uid = ".$uid;
		$db->setQuery($query);
		$totalgoldresume = $db->loadResult();

                //cover letter
                $query = "SELECT COUNT(id) FROM #__js_job_coverletters WHERE uid = ".$uid;
		$db->setQuery($query);
		$totalcoverletters = $db->loadResult();


            if($unlimitedresume == 0)  $results[0]=$resumeallow;
            elseif($unlimitedresume == 1)$results[0] = -1;
            $results[1]=$totalresume;

            if($unlimitedfeaturedresume == 0) $results[2]=$featuredresumeallow;
            elseif($unlimitedfeaturedresume == 1)$results[2] = -1;
            $results[3]=$totalfeaturedresume;

            if($unlimitedgoldresume == 0) $results[4]=$goldresumeallow;
            elseif($unlimitedgoldresume == 1) $results[4] = -1;
            $results[5] = $totalgoldresume;

            if($unlimitedcoverletters == 0) $results[6]=$coverlettersallow;
            elseif($unlimitedcoverletters == 1) $results[6] = -1;
            $results[7]=$totalcoverletters;

            return  $results;


	}
	

	function &getMyCompanies($u_id,$limit,$limitstart)
	{
		$result = array();
		$db = &$this->getDBO();

		if (is_numeric($u_id) == false) return false;
		if (($u_id == 0) || ($u_id == '')) return false;
		$query = "SELECT count(company.id)
                        FROM `#__js_job_companies` AS company
                        WHERE company.uid = ".$u_id;
		$db->setQuery($query);
		$total = $db->loadResult();
		if ( $total <= $limitstart ) $limitstart = 0;

                $query = "SELECT company.*, cat.cat_title
					, (SELECT COUNT(goldcompany.id) FROM `#__js_job_goldcompanies` AS goldcompany
						JOIN `#__js_job_employerpackages` AS package ON package.id = goldcompany.packageid
						WHERE goldcompany.companyid = company.id AND goldcompany.status = 1 AND DATE_ADD(goldcompany.created,INTERVAL package.goldcompaniesexpireindays DAY) >= CURDATE() ) AS isgold
					, (SELECT COUNT(featuredcompany.id) FROM `#__js_job_featuredcompanies` AS featuredcompany
						JOIN `#__js_job_employerpackages` AS package ON package.id = featuredcompany.packageid
						WHERE featuredcompany.companyid = company.id AND featuredcompany.status = 1 AND DATE_ADD(featuredcompany.created,INTERVAL package.featuredcompaniesexpireindays DAY) >= CURDATE() ) AS isfeatured
					FROM `#__js_job_companies` AS company
					JOIN `#__js_job_categories` AS cat ON company.category = cat.id
					WHERE company.uid = ".$u_id;
		$db->setQuery($query, $limitstart, $limit);
		$result[0] = $db->loadObjectList();
		$result[1] = $total;

		return $result;
	}
        function &getMyDepartments($u_id,$limit,$limitstart)
	{
		$result = array();
		$db = &$this->getDBO();
		
		if (is_numeric($u_id) == false) return false;
		if (($u_id == 0) || ($u_id == '')) return false;
		$query = "SELECT count(department.id) 
                        FROM `#__js_job_departments` AS department
                        WHERE department.uid = ".$u_id;
		$db->setQuery($query);
		$total = $db->loadResult();
		if ( $total <= $limitstart ) $limitstart = 0;

                $query = "SELECT department.*, company.name as companyname
			FROM `#__js_job_departments` AS department 
			JOIN `#__js_job_companies` AS company ON company.id = department.companyid
			WHERE department.uid = ".$u_id;
		$db->setQuery($query, $limitstart, $limit);
		$result[0] = $db->loadObjectList();
		$result[1] = $total;
		
		return $result;
	}

	function &getMyJobs($u_id,$sortby,$limit,$limitstart,$vis_email,$jobid)
	{
		$result = array();
		$db = &$this->getDBO();

		if (is_numeric($u_id) == false) return false;
		//if (($u_id == 0) || ($u_id == '')) return false; Close for visitor jobs
                if(($vis_email == '') || ($jobid == ''))
                    if (($u_id == 0) || ($u_id == '')) return false; //check if not visitor
		$listjobconfig = $this->getConfigByFor('listjob');
                //visitor jobs
                if(isset($jobid) && ($jobid != '')){// if the jobid and email address is valid or not
                    $query = "SELECT job.companyid
                                FROM `#__js_job_jobs` AS job
                                WHERE job.jobid = ".$db->quote($jobid);
                    $db->setQuery($query);
                    $companyid = $db->loadResult();
                    if(!$companyid) return false;
                    $query = "SELECT count(company.id)
                                FROM `#__js_job_companies` AS company
                                WHERE company.id = ".$companyid;
                    $db->setQuery($query);
                    $company = $db->loadResult();
                    if($company == 0) return false;// means no company exist
                }
                
                if(isset($vis_email) && ($vis_email != '')){
                    $query = "SELECT count(job.id)
                                FROM `#__js_job_companies` AS company
                                JOIN `#__js_job_jobs` AS job ON job.companyid = company.id
                                WHERE company.contactemail = ".$db->quote($vis_email);
                }else{
                    $query = "SELECT count(job.id)
                                FROM `#__js_job_jobs` AS job
                                WHERE job.uid = ".$u_id;
                }
		$db->setQuery($query);
		$total = $db->loadResult();
		if ( $total <= $limitstart ) $limitstart = 0;

                if((isset($vis_email) && isset($jobid)) && ($vis_email != '' && $jobid != '')){
                    $query = "SELECT job.*, cat.cat_title,'visitor' AS visitor,company.contactemail AS contactemail
                                , jobtype.title AS jobtypetitle, jobstatus.title AS jobstatustitle
                                , company.name AS companyname, company.url
                                , salaryfrom.rangestart, salaryto.rangeend, country.name AS countryname
                                FROM `#__js_job_companies` AS company
                                JOIN `#__js_job_jobs` AS job ON job.companyid = company.id
                                JOIN `#__js_job_jobtypes` AS jobtype ON job.jobtype = jobtype.id
                                JOIN `#__js_job_jobstatus` AS jobstatus ON job.jobstatus = jobstatus.id
                                JOIN `#__js_job_categories` AS cat ON cat.id = job.jobcategory
								LEFT JOIN `#__js_job_salaryrange` AS salaryfrom ON job.salaryrangefrom = salaryfrom.id
								LEFT JOIN `#__js_job_salaryrange` AS salaryto ON job.salaryrangeto = salaryto.id
                                LEFT JOIN `#__js_job_countries` AS country ON job.country = country.code
                                WHERE company.contactemail = ".$db->quote($vis_email)." ORDER BY  ".$sortby;
                }else{
                    $query = "SELECT job.*, cat.cat_title
                                , jobtype.title AS jobtypetitle, jobstatus.title AS jobstatustitle
                                , company.name AS companyname, company.url
                                , salaryfrom.rangestart, salaryto.rangeend, country.name AS countryname
								, (SELECT COUNT(goldjob.id) FROM `#__js_job_goldjobs` AS goldjob 
									JOIN `#__js_job_employerpackages` AS package ON package.id = goldjob.packageid
									WHERE goldjob.jobid = job.id AND goldjob.status = 1 AND DATE_ADD(goldjob.created,INTERVAL package.goldjobsexpireindays DAY) >= CURDATE() ) AS isgold
								, (SELECT COUNT(featuredjob.id) FROM `#__js_job_featuredjobs` AS featuredjob 
									JOIN `#__js_job_employerpackages` AS package ON package.id = featuredjob.packageid
									WHERE featuredjob.jobid = job.id AND featuredjob.status = 1 AND DATE_ADD(featuredjob.created,INTERVAL package.featuredjobsexpireindays DAY) >= CURDATE() ) AS isfeatured
                                FROM `#__js_job_jobs` AS job
                                JOIN `#__js_job_jobtypes` AS jobtype ON job.jobtype = jobtype.id
                                JOIN `#__js_job_jobstatus` AS jobstatus ON job.jobstatus = jobstatus.id
                                LEFT JOIN `#__js_job_companies` AS company ON job.companyid = company.id
								LEFT JOIN `#__js_job_salaryrange` AS salaryfrom ON job.salaryrangefrom = salaryfrom.id
								LEFT JOIN `#__js_job_salaryrange` AS salaryto ON job.salaryrangeto = salaryto.id
                                LEFT JOIN `#__js_job_countries` AS country ON job.country = country.code
                                , `#__js_job_categories` AS cat
                                WHERE job.jobcategory = cat.id AND job.uid = ".$u_id." ORDER BY  ".$sortby;
                }
		$db->setQuery($query, $limitstart, $limit);
		$this->_applications = $db->loadObjectList();
		$result[0] = $this->_applications;
		$result[1] = $total;
		$result[2] = $listjobconfig;
		
		return $result;
	}

	function &getJobforForm($job_id, $uid,$vis_jobid,$visitor)
	{   
		$db = &$this->getDBO();
		if (is_numeric($uid) == false) return false;
		if (($job_id != '') && ($job_id != 0)){
			if (is_numeric($job_id) == false) return false;
			$query = "SELECT job.*, cat.cat_title, salary.rangestart, salary.rangeend
			FROM `#__js_job_jobs` AS job 
			JOIN `#__js_job_categories` AS cat ON job.jobcategory = cat.id 
			LEFT JOIN `#__js_job_salaryrange` AS salary ON job.jobsalaryrange = salary.id 
			LEFT JOIN `#__js_job_currencies` AS currency On currency.id = job.currencyid
			WHERE job.id = ".$job_id." AND job.uid = ".$uid;
			$db->setQuery($query);
			$this->_job = $db->loadObject();
		}
                // Getting data for visitor job
		if (isset($vis_jobid) && ($vis_jobid != '')){
			$query = "SELECT job.*, cat.cat_title, salary.rangestart, salary.rangeend
			FROM `#__js_job_jobs` AS job
			JOIN `#__js_job_categories` AS cat ON job.jobcategory = cat.id
			LEFT JOIN `#__js_job_salaryrange` AS salary ON job.jobsalaryrange = salary.id
			LEFT JOIN `#__js_job_currencies` AS currency On currency.id = job.currencyid
			WHERE job.jobid = ".$db->quote($vis_jobid);
			$db->setQuery($query);
			$this->_job = $db->loadObject();
		}
		if (isset($visitor) && ($visitor == 1))
			$fieldOrdering = $this->getFieldsOrdering(12);
		else
			$fieldOrdering = $this->getFieldsOrdering(2);

		foreach($fieldOrdering AS $field){
			switch($field->field){
				case "gender" : if($field->required == 1) $gernderreq = "required"; else $gernderreq = ""; break;
			}
		}
		$countries = $this->getCountries('');
		if (empty($visitor))
			$companies = $this->getCompanies($uid);
            
                $categories = $this->getCategories('');
                if ( isset($this->_job) ){
			$states = $this->getStates($this->_job->country, '');
			$counties = $this->getCounties($this->_job->state, '');
			$cities = $this->getCities($this->_job->county, '');
		if (empty($visitor))
			$lists['companies'] = JHTML::_('select.genericList', $companies , 'companyid', 'class="inputbox required" '. '', 'value', 'text', $this->_job->companyid);
			$lists['departments'] = JHTML::_('select.genericList', $this->getDepartmentsByCompanyId($this->_job->companyid,'') , 'departmentid', 'class="inputbox" '. '', 'value', 'text', $this->_job->departmentid);

			$lists['jobcategory'] = JHTML::_('select.genericList', $categories, 'jobcategory', 'class="inputbox" '. 'onChange="fj_getsubcategories(\'fj_subcategory\', this.value)"', 'value', 'text', $this->_job->jobcategory);
			$lists['subcategory'] = JHTML::_('select.genericList', $this->getSubCategoriesforCombo($this->_job->jobcategory,JText::_('JS_SUB_CATEGORY'),''), 'subcategoryid', 'class="inputbox" '. '', 'value', 'text', $this->_job->subcategoryid);
			$lists['jobtype'] = JHTML::_('select.genericList', $this->getJobType(''), 'jobtype', 'class="inputbox" '. '', 'value', 'text', $this->_job->jobtype);
			$lists['jobstatus'] = JHTML::_('select.genericList', $this->getJobStatus(''), 'jobstatus', 'class="inputbox required" '. '', 'value', 'text', $this->_job->jobstatus);
			$lists['heighesteducation'] = JHTML::_('select.genericList', $this->getHeighestEducation(''), 'heighestfinisheducation', 'class="inputbox" '. '', 'value', 'text', $this->_job->heighestfinisheducation);
			$lists['shift'] = JHTML::_('select.genericList', $this->getShift(''), 'shift', 'class="inputbox" '. '', 'value', 'text', $this->_job->shift);

			$lists['educationminimax'] = JHTML::_('select.genericList', $this->getMiniMax(''), 'educationminimax', 'class="inputbox" '. '', 'value', 'text', $this->_job->educationminimax);
			$lists['education'] = JHTML::_('select.genericList', $this->getHeighestEducation(''), 'educationid', 'class="inputbox" '. '', 'value', 'text', $this->_job->educationid);
			$lists['minimumeducationrange'] = JHTML::_('select.genericList', $this->getHeighestEducation(JText::_('JS_MINIMUM')), 'mineducationrange', 'class="inputbox" '. '', 'value', 'text', $this->_job->mineducationrange);
			$lists['maximumeducationrange'] = JHTML::_('select.genericList', $this->getHeighestEducation(JText::_('JS_MAXIMUM')), 'maxeducationrange', 'class="inputbox" '. '', 'value', 'text', $this->_job->maxeducationrange);

			$lists['salaryrangefrom'] = JHTML::_('select.genericList', $this->getJobSalaryRange(JText::_('JS_FROM'),1,'from'), 'salaryrangefrom', 'class="inputbox" '. '', 'value', 'text', $this->_job->salaryrangefrom);
			$lists['salaryrangeto'] = JHTML::_('select.genericList', $this->getJobSalaryRange(JText::_('JS_TO'),1,'to'), 'salaryrangeto', 'class="inputbox" '. '', 'value', 'text', $this->_job->salaryrangeto);
			$lists['salaryrangetypes'] = JHTML::_('select.genericList', $this->getSalaryRangeTypes(''), 'salaryrangetype', 'class="inputbox" '. '', 'value', 'text', $this->_job->salaryrangetype);

			$lists['country'] = JHTML::_('select.genericList', $countries, 'country','class="inputbox required" '.'onChange="dochange(\'state\', this.value);"', 'value', 'text', $this->_job->country);
			if ( isset($states[1]) ) if ($states[1] != '')$lists['state'] = JHTML::_('select.genericList', $states, 'state', 'class="inputbox" '. 'onChange="dochange(\'county\', this.value);"', 'value', 'text', $this->_job->state);
			if ( isset($counties[1]) ) if ($counties[1] != '')$lists['county'] = JHTML::_('select.genericList', $counties, 'county', 'class="inputbox" '. 'onChange="dochange(\'city\', this.value);"', 'value', 'text', $this->_job->county);
			if ( isset($cities[1]) ) if ($cities[1] != '')$lists['city'] = JHTML::_('select.genericList', $cities, 'city', 'class="inputbox" '. 'onChange=""', 'value', 'text', $this->_job->city);
			
			$lists['agefrom'] = JHTML::_('select.genericList', $this->getAges(JText::_('JS_FROM')), 'agefrom', 'class="inputbox" '. '', 'value', 'text', $this->_job->agefrom);
			$lists['ageto'] = JHTML::_('select.genericList', $this->getAges(JText::_('JS_TO')), 'ageto', 'class="inputbox" '. '', 'value', 'text', $this->_job->ageto);
			$lists['experienceminimax'] = JHTML::_('select.genericList', $this->getMiniMax(''), 'experienceminimax', 'class="inputbox" '. '', 'value', 'text', $this->_job->experienceminimax);
			$lists['experience'] = JHTML::_('select.genericList', $this->getExperiences(JText::_('JS_SELECT')), 'experienceid', 'class="inputbox" '. '', 'value', 'text', $this->_job->experienceid);
			$lists['minimumexperiencerange'] = JHTML::_('select.genericList', $this->getExperiences(JText::_('JS_MINIMUM')), 'minexperiencerange', 'class="inputbox" '. '', 'value', 'text', $this->_job->minexperiencerange);
			$lists['maximumexperiencerange'] = JHTML::_('select.genericList', $this->getExperiences(JText::_('JS_MAXIMUM')), 'maxexperiencerange', 'class="inputbox" '. '', 'value', 'text', $this->_job->maxexperiencerange);
			
			$lists['gender'] = JHTML::_('select.genericList', $this->getGender(JText::_('JS_DOES_NOT_MATTER')), 'gender', 'class="inputbox '.$gernderreq.'" '. '', 'value', 'text', $this->_job->gender);
			$lists['careerlevel'] = JHTML::_('select.genericList', $this->getCareerLevel(JText::_('JS_SELECT')), 'careerlevel', 'class="inputbox" '. '', 'value', 'text', $this->_job->careerlevel);
			$lists['workpermit'] = JHTML::_('select.genericList', $this->getCountries(JText::_('JS_SELECT')), 'workpermit', 'class="inputbox" '. '', 'value', 'text', $this->_job->workpermit);
			$lists['requiredtravel'] = JHTML::_('select.genericList', $this->getRequiredTravel(JText::_('JS_SELECT')), 'requiredtravel', 'class="inputbox" '. '', 'value', 'text', $this->_job->requiredtravel);
			$lists['sendemail'] = JHTML::_('select.genericList', $this->getSendEmail(), 'sendemail', 'class="inputbox" '. '', 'value', 'text', $this->_job->sendemail);
			$lists['currencyid'] = JHTML::_('select.genericList', $this->getCurrency(), 'currencyid', 'class="inputbox" '. '', 'value', 'text', $this->_job->currencyid);
			
		}else{
			if(! isset($this->_config)){ $this->getConfig('');}	
			if(isset($this->_defaultcountry))$states = $this->getStates($this->_defaultcountry, '');
			if(isset($companies[0]))$lists['companies'] = JHTML::_('select.genericList', $companies, 'companyid', 'class="inputbox required" '.'onChange="getdepartments(\'department\', this.value)"'. '', 'value', 'text', '');
			if(isset($companies[0]['value']))$lists['departments'] = JHTML::_('select.genericList', $this->getDepartmentsByCompanyId($companies[0]['value'],'') , 'departmentid', 'class="inputbox" '. '', 'value', 'text', '');

			$lists['jobcategory'] = JHTML::_('select.genericList', $categories, 'jobcategory', 'class="inputbox" ' . 'onChange="fj_getsubcategories(\'fj_subcategory\', this.value)"', 'value', 'text', '');
			$lists['subcategory'] = JHTML::_('select.genericList', $this->getSubCategoriesforCombo($categories[0]['value'],JText::_('JS_SUB_CATEGORY'),''), 'subcategoryid', 'class="inputbox" '. '', 'value', 'text', '');
			$lists['jobtype'] = JHTML::_('select.genericList', $this->getJobType(''), 'jobtype', 'class="inputbox" '. '', 'value', 'text', '');
			$lists['jobstatus'] = JHTML::_('select.genericList', $this->getJobStatus(''), 'jobstatus', 'class="inputbox required" '. '', 'value', 'text', '');
			$lists['shift'] = JHTML::_('select.genericList', $this->getShift(''), 'shift', 'class="inputbox" '. '', 'value', 'text', '');

			$lists['educationminimax'] = JHTML::_('select.genericList', $this->getMiniMax(''), 'educationminimax', 'class="inputbox" '. '', 'value', 'text', '');
			$lists['education'] = JHTML::_('select.genericList', $this->getHeighestEducation(''), 'educationid', 'class="inputbox" '. '', 'value', 'text', '');
			$lists['minimumeducationrange'] = JHTML::_('select.genericList', $this->getHeighestEducation(JText::_('JS_MINIMUM')), 'mineducationrange', 'class="inputbox" '. '', 'value', 'text', '');
			$lists['maximumeducationrange'] = JHTML::_('select.genericList', $this->getHeighestEducation(JText::_('JS_MAXIMUM')), 'maxeducationrange', 'class="inputbox" '. '', 'value', 'text', '');


			$lists['salaryrangefrom'] = JHTML::_('select.genericList', $this->getJobSalaryRange(JText::_('JS_FROM'),1,'from'), 'salaryrangefrom', 'class="inputbox" '. '', 'value', 'text', '');
			$lists['salaryrangeto'] = JHTML::_('select.genericList', $this->getJobSalaryRange(JText::_('JS_TO'),1,'to'), 'salaryrangeto', 'class="inputbox" '. '', 'value', 'text', '');
			$lists['salaryrangetypes'] = JHTML::_('select.genericList', $this->getSalaryRangeTypes(''), 'salaryrangetype', 'class="inputbox" '. '', 'value', 'text', '2');

			$lists['country'] = JHTML::_('select.genericList', $countries, 'country','class="inputbox required" '.'onChange="dochange(\'state\', this.value);"', 'value', 'text', $this->_defaultcountry);
			if ( isset($states[1]) ) if ($states[1] != '')$lists['state'] = JHTML::_('select.genericList', $states, 'state', 'class="inputbox" '. 'onChange="dochange(\'county\', this.value);"', 'value', 'text', '');
			if ( isset($counties[1]) ) if ($counties[1] != '')$lists['county'] = JHTML::_('select.genericList', $counties, 'county', 'class="inputbox" '. 'onChange="dochange(\'city\', this.value);"', 'value', 'text', '');
			if ( isset($cities[1]) ) if ($cities[1] != '')$lists['city'] = JHTML::_('select.genericList', $cities, 'city', 'class="inputbox" '. 'onChange=""', 'value', 'text', '');
			
			$lists['agefrom'] = JHTML::_('select.genericList', $this->getAges(JText::_('JS_FROM')), 'agefrom', 'class="inputbox" '. '', 'value', 'text','' );
			$lists['ageto'] = JHTML::_('select.genericList', $this->getAges(JText::_('JS_TO')), 'ageto', 'class="inputbox" '. '', 'value', 'text','' );
			$lists['experienceminimax'] = JHTML::_('select.genericList', $this->getMiniMax(''), 'experienceminimax', 'class="inputbox" '. '', 'value', 'text', '');
			$lists['experience'] = JHTML::_('select.genericList', $this->getExperiences(JText::_('JS_SELECT')), 'experienceid', 'class="inputbox" '. '', 'value', 'text', '');
			$lists['minimumexperiencerange'] = JHTML::_('select.genericList', $this->getExperiences(JText::_('JS_MINIMUM')), 'minexperiencerange', 'class="inputbox" '. '', 'value', 'text', '');
			$lists['maximumexperiencerange'] = JHTML::_('select.genericList', $this->getExperiences(JText::_('JS_MAXIMUM')), 'maxexperiencerange', 'class="inputbox" '. '', 'value', 'text', '');

			$lists['gender'] = JHTML::_('select.genericList', $this->getGender(JText::_('JS_DOES_NOT_MATTER')), 'gender', 'class="inputbox" '.$gernderreq.'" '. '', 'value', 'text', '');
			$lists['careerlevel'] = JHTML::_('select.genericList', $this->getCareerLevel(JText::_('JS_SELECT')), 'careerlevel', 'class="inputbox" '. '', 'value', 'text', '');
			$lists['workpermit'] = JHTML::_('select.genericList', $this->getCountries(JText::_('JS_SELECT')), 'workpermit', 'class="inputbox" '. '', 'value', 'text', $this->_defaultcountry);
			$lists['requiredtravel'] = JHTML::_('select.genericList', $this->getRequiredTravel(JText::_('JS_SELECT')), 'requiredtravel', 'class="inputbox" '. '', 'value', 'text', '');
			$lists['sendemail'] = JHTML::_('select.genericList', $this->getSendEmail(), 'sendemail', 'class="inputbox" '. '', 'value', 'text', '$this->_job->sendemail','');
			$lists['currencyid'] = JHTML::_('select.genericList', $this->getCurrency(), 'currencyid', 'class="inputbox" '. '', 'value', 'text', '');
		}
		
		$result[0] = $this->_job;
		$result[1] = $lists;
		if (isset($visitor) && ($visitor == 1))
			$result[2] = $this->getUserFields(12, $vis_jobid); // job fields , ref id
		else
			$result[2] = $this->getUserFields(2, $job_id); // job fields , ref id
		$result[3] = $fieldOrdering; // job fields
		if ($job_id){ // not new
			$canaddreturn = $this->canAddNewJob($uid);
                        $result[4] =  1;
                        $result[5] =  $canaddreturn[1]; // package id
                }else{ // new
			$canaddreturn = $this->canAddNewJob($uid);
                        $result[4] =  $canaddreturn[0]; // can add
                        $result[5] =  $canaddreturn[1]; // package id
                }
        if(isset($uid) && $uid != 0)
			$result[6] = $this->getAllPackagesByUid($uid,$job_id);
		return $result;
	}
	function getAllPackagesByUid($uid,$job_id){
			if(!is_numeric($uid)) return false;
			$db = $this->getDbo();
			$query = "SELECT payment.id AS paymentid, payment.packagetitle AS packagetitle, package.id AS packageid, package.jobsallow, package.enforcestoppublishjob, package.enforcestoppublishjobvalue, package.enforcestoppublishjobtype
						, package.featuredjobs AS featuredjobs,package.goldjobs AS goldjobs, (SELECT COUNT(id) FROM #__js_job_jobs WHERE packageid = package.id AND paymenthistoryid = payment.id AND uid = ".$uid.") AS jobavail
						, (SELECT COUNT(id) FROM `#__js_job_featuredjobs` WHERE uid = ".$uid." AND packageid = package.id ) AS availfeaturedjobs
						, (SELECT COUNT(id) FROM `#__js_job_goldjobs` WHERE uid = ".$uid." AND packageid = package.id ) AS availgoldjobs
						FROM #__js_job_employerpaymenthistory AS payment
						JOIN #__js_job_employerpackages AS package ON package.id = payment.packageid
						WHERE uid = ".$uid."
						AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
						AND payment.transactionverified = 1 AND payment.status = 1";
			$db->setQuery($query);
			$result = $db->loadObjectList();
			$count = count($result);//check packages more then once or not
			if(isset($job_id) && $job_id != ''){
				$query = "SELECT packageid,paymenthistoryid FROM `#__js_job_jobs` WHERE id = ".$job_id;
				$db->setQuery($query);
				$job = $db->loadObject();
			}
			if($count > 1){
				$packagecombo = '<select name="package" onChange="Javascript: changeDate(this.value);">';
				$packagecombo .= "<option value=''>".JText::_('JS_SELECT_PACKAGE')."</option>";
				foreach($result AS $package){
					if($package->jobsallow != -1)
						$jobleft = ($package->jobsallow - $package->jobavail).' '.JText::_('JS_JOBS_LEFT');
					else $jobleft = JText::_('JS_UNLIMITED_JOBS');
					if($package->enforcestoppublishjob == 1){
						switch($package->enforcestoppublishjobtype){
							case 1:$timetype = JText::_('JS_DAYS');break;
							case 2:$timetype = JText::_('JS_WEEKS');break;
							case 3:$timetype = JText::_('JS_MONTHS');break;
						}
						$jobduration = $package->enforcestoppublishjobvalue.' '.$timetype;
					}else{
						$jobduration = JText::_('JS_MANAUL_SELECT');
					}
					$title = '"'.$package->packagetitle.'"  '.$jobleft.', '.JText::_('JS_JOB_DURATION').' '.$jobduration;
					if(isset($job) && $job->packageid == $package->packageid && $job->paymenthistoryid == $package->paymentid){
						$packagecombo .= "<option value='$package->packageid' selected=\"selected\">$title</option>";
					}else{
						$packagecombo .= "<option value='$package->packageid'>$title</option>";
					}
					$packagedetail["$package->packageid"] = $package; 
				}
				$packagecombo .= "</select>";
				$return[0] = $packagecombo;
				$return[1] = $packagedetail;
			}elseif($count == 1) $return = false;
			elseif($count == 0) $return = 2;//no package
			return $return;
			
	}
	function &getCurrency(){
		
		$db = & JFactory :: getDBO();
		if(! isset($this->_defaultcurrency)) $this->_defaultcurrency = $this->getDefaultCurrency();
		$q = "SELECT * FROM `#__js_job_currencies` WHERE status = 1 AND id = " .$this->_defaultcurrency ;
		$db->setQuery($q);
		$defaultcurrency = $db->loadObject();
		$combobox=array();
		$combobox[] =  array('value' => $defaultcurrency->id,'text' => JText::_($defaultcurrency->symbol));		

		$q = "SELECT * FROM `#__js_job_currencies` WHERE status = 1 AND id != ".$defaultcurrency->id ;
		$db->setQuery($q);
		$allcurrency = $db->loadObjectList();
		if(!empty($allcurrency)){
			foreach($allcurrency as $currency){
				$combobox[] =  array('value' => $currency->id,'text' => JText::_($currency->symbol));		
			}
		}
		return $combobox;
	}
	function getDefaultCurrency(){
		$db = & JFactory :: getDBO();
		$q = "SELECT id FROM `#__js_job_currencies` AS id WHERE id.default = 1";
		$db->setQuery($q);
		$defaultValue = $db->loadResult();
		if(!$defaultValue){ 
			$q = "SELECT id FROM " .$db->nameQuote('#__js_job_currencies') ;
			$db->setQuery($q);
			$defaultValue = $db->loadResult();
		}
		return $defaultValue;
		
	}
	function canAddNewJob($uid) 
	{
		$db = &$this->getDBO();
		if($uid) if (is_numeric($uid) == false) return false;
		$returnvalue = array();
		$packagedetail = array();
		if (($uid == 0) || ($uid == '')){ $returnvalue[0] = false; $returnvalue[1] = $packagedetail; return $returnvalue; }
		$query = "SELECT package.id, package.jobsallow, package.packageexpireindays, payment.id AS paymentid, payment.created
                         , package.enforcestoppublishjob, package.enforcestoppublishjobvalue, package.enforcestoppublishjobtype
                        FROM `#__js_job_employerpackages` AS package
                        JOIN `#__js_job_employerpaymenthistory` AS payment ON payment.packageid = package.id
                        WHERE payment.uid = ".$uid."
                        AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
                        AND payment.transactionverified = 1 AND payment.status = 1";
		//echo $query;
		$db->setQuery($query);
		$jobs = $db->loadObjectList();
		if(empty($jobs))
		{
			$query = "SELECT package.id, package.jobsallow,package.title AS packagetitle, package.packageexpireindays, payment.id AS paymentid
							 , package.enforcestoppublishjob, package.enforcestoppublishjobvalue, package.enforcestoppublishjobtype
							 , (TO_DAYS( CURDATE() ) - To_days( payment.created ) ) AS packageexpiredays
							FROM `#__js_job_employerpackages` AS package
							JOIN `#__js_job_employerpaymenthistory` AS payment ON payment.packageid = package.id
							WHERE payment.uid = ".$uid." 
							AND payment.transactionverified = 1 AND payment.status = 1 ORDER BY payment.created DESC";
			$db->setQuery($query);
			$packagedetail = $db->loadObjectList();
			$return_value[0] = false;
			$return_value[1] = $packagedetail;
			return $return_value;
		}
		$unlimited = 0;
		foreach($jobs AS $job){
			if($unlimited == 0){
				if ($job->jobsallow != -1){
                                        $jobsallow = "";
					$jobsallow = $job->jobsallow + $jobsallow;
				}else{
                                    $unlimited = 1;
                                    $packagedetail[0] = $job->id;
                                    $packagedetail[1] = $job->paymentid;
                                    $packagedetail[2] = $job->enforcestoppublishjob;
                                    $packagedetail[3] = $job->enforcestoppublishjobvalue;
                                    $packagedetail[4] = $job->enforcestoppublishjobtype;
                                }
			}	
		}
		if ($unlimited == 0){
                    if ($jobsallow == 0) { $returnvalue[0] = false; $returnvalue[1] = $packagedetail; return $returnvalue; } //can not add new job
			$query = "SELECT COUNT(jobs.id) AS totaljobs
			FROM `#__js_job_jobs` AS jobs
			WHERE jobs.uid = ".$uid;
			$db->setQuery($query);
			$totlajob = $db->loadResult();

			if ($jobsallow <= $totlajob) { $returnvalue[0] = false; $returnvalue[1] = $packagedetail; return $returnvalue; } //can not add new job
			else{
                            $query = "SELECT payment.id AS paymentid, package.id, package.jobsallow, package.enforcestoppublishjob, package.enforcestoppublishjobvalue, package.enforcestoppublishjobtype
                                        , (SELECT COUNT(id) FROM #__js_job_jobs WHERE packageid = package.id AND paymenthistoryid = payment.id AND uid = ".$uid.") AS jobavail
                                        FROM #__js_job_employerpaymenthistory AS payment
                                        JOIN #__js_job_employerpackages AS package ON package.id = payment.packageid
                                        WHERE uid = ".$uid."
                                        AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
                                        AND payment.transactionverified = 1 AND payment.status = 1 ";
                            //echo $query;
                            $db->setQuery($query);
                            $packages = $db->loadObjectList();
                            foreach($packages AS $package){
                                    if($package->jobsallow > $package->jobavail){
                                        $packagedetail[0] = $package->id;
                                        $packagedetail[1] = $package->paymentid;
                                        $packagedetail[2] = $package->enforcestoppublishjob;
                                        $packagedetail[3] = $package->enforcestoppublishjobvalue;
                                        $packagedetail[4] = $package->enforcestoppublishjobtype;
                                    }
                            }
                            $returnvalue[0] = true;
                            $returnvalue[1] = $packagedetail;
                            return $returnvalue;
                        }
			
		}elseif ($unlimited == 1) { $returnvalue[0] = true; $returnvalue[1] = $packagedetail; return $returnvalue; } // unlimited

		$returnvalue[0] = false; $returnvalue[1] = $packagedetail; return $returnvalue;
	}
	
	function canAddNewCompany($uid) 
	{
		$db = &$this->getDBO();
		if($uid) if (is_numeric($uid) == false) return false;
		$returnvalue = array();
		$packagedetail = array();
		if (($uid == 0) || ($uid == '')) { $returnvalue[0] = false; $returnvalue[1] = $packagedetail; return $returnvalue; }
		
		$query = "SELECT package.id AS packageid, package.companiesallow, package.packageexpireindays, payment.id AS paymentid, payment.created
                        FROM `#__js_job_employerpackages` AS package
                        JOIN `#__js_job_employerpaymenthistory` AS payment ON payment.packageid = package.id
                        WHERE payment.uid = ".$uid."
                        AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
                        AND payment.transactionverified = 1 AND payment.status = 1";
		$db->setQuery($query);
		$companies = $db->loadObjectList();
		if(empty($companies))
		{
			$query = "SELECT package.id, package.jobsallow,package.title AS packagetitle, package.packageexpireindays, payment.id AS paymentid
							 , package.enforcestoppublishjob, package.enforcestoppublishjobvalue, package.enforcestoppublishjobtype
							 , (TO_DAYS( CURDATE() ) - To_days( payment.created ) ) AS packageexpiredays
							FROM `#__js_job_employerpackages` AS package
							JOIN `#__js_job_employerpaymenthistory` AS payment ON payment.packageid = package.id
							WHERE payment.uid = ".$uid." 
							AND payment.transactionverified = 1 AND payment.status = 1 ORDER BY payment.created DESC";
			$db->setQuery($query);
			$packagedetail = $db->loadObjectList();
			
			$return_value[0] = false;
			$return_value[1] = $packagedetail;
			return $return_value;
		}
		$unlimited = 0;
		foreach($companies AS $company){
			if($unlimited == 0){
				if ($company->companiesallow != -1){
                                        $companiesallow = "";
					$companiesallow = $companiesallow + $company->companiesallow;
				}else{
                                    $unlimited = 1;
                                    $packagedetail[0] = $company->packageid;
                                    $packagedetail[1] = $company->paymentid;
                                }
			}	
		}
		if ($unlimited == 0){
        		if ($companiesallow == 0) { $returnvalue[0] = false; $returnvalue[1] = $packagedetail; return $returnvalue; } //can not add new company
			$query = "SELECT COUNT(company.id) AS totalcompanies
			FROM `#__js_job_companies` AS company
			WHERE company.uid = ".$uid;
			$db->setQuery($query);
			$totalcompanies = $db->loadResult();
			
			if ($companiesallow <= $totalcompanies) { $returnvalue[0] = false; $returnvalue[1] = $packagedetail; return $returnvalue; } //can not add new company
			else{
                            $query = "SELECT payment.id AS paymentid, package.id, package.companiesallow,package.jobsallow
                                        , (SELECT COUNT(id) FROM #__js_job_companies WHERE packageid = package.id AND paymenthistoryid = payment.id AND uid = ".$uid.") AS jobavail
                                        FROM #__js_job_employerpaymenthistory AS payment
                                        JOIN #__js_job_employerpackages AS package ON package.id = payment.packageid
                                        WHERE payment.uid = ".$uid."
                                        AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
                                        AND payment.transactionverified = 1 AND payment.status = 1";
                            //echo $query;
                            $db->setQuery($query);
                            $packages = $db->loadObjectList();
                            foreach($packages AS $package){
                                    if($package->jobsallow > $package->jobavail){
                                        $packagedetail[0] = $package->id;
                                        $packagedetail[1] = $package->paymentid;
                                    }
                            }
                            $returnvalue[0] = true;
                            $returnvalue[1] = $packagedetail;
                            return $returnvalue;
                        }
			
		}elseif ($unlimited == 1) { $returnvalue[0] = true; $returnvalue[1] = $packagedetail; return $returnvalue; } // unlimited
		
		return 0;
	}
	function canAddNewFolder($uid)
	{
		$db = &$this->getDBO();
		if (is_numeric($uid) == false) return false;
		$returnvalue = array();
                $packagedetail = array();
		if (($uid == 0) || ($uid == '')) { $returnvalue[0] = false; $returnvalue[1] = $packagedetail; return $returnvalue; }

		$query = "SELECT package.id AS packageid, package.folders, package.packageexpireindays, payment.id AS paymentid, payment.created
                        FROM `#__js_job_employerpackages` AS package
                        JOIN `#__js_job_employerpaymenthistory` AS payment ON payment.packageid = package.id
                        WHERE payment.uid = ".$uid."
                        AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
                        AND payment.transactionverified = 1 AND payment.status = 1";
		$db->setQuery($query);
		$companies = $db->loadObjectList();
		$unlimited = 0;
		foreach($companies AS $company){
			if($unlimited == 0){
				if ($company->folders != -1){
                                        $folders = "";
					$folders = $folders + $company->folders;
				}else{
                                    $unlimited = 1;
                                    $packagedetail[0] = $company->packageid;
                                    $packagedetail[1] = $company->paymentid;
                                }
			}
		}
		if ($unlimited == 0){
        		if ($folders == 0) { $returnvalue[0] = false; $returnvalue[1] = $packagedetail; return $returnvalue; } //can not add new folder
			$query = "SELECT COUNT(folder.id) AS totalfolders
			FROM `#__js_job_folders` AS folder
			WHERE folder.uid = ".$uid;
			$db->setQuery($query);
			$totalfolders = $db->loadResult();

			if ($folders <= $totalfolders) { $returnvalue[0] = false; $returnvalue[1] = $packagedetail; return $returnvalue; } //can not add new folder
			else{
                            $query = "SELECT payment.id AS paymentid, package.id, package.folders
                                        , (SELECT COUNT(id) FROM #__js_job_folders WHERE packageid = package.id AND paymenthistoryid = payment.id AND uid = ".$uid.") AS folderavail
                                        FROM #__js_job_employerpaymenthistory AS payment
                                        JOIN #__js_job_employerpackages AS package ON package.id = payment.packageid
                                        WHERE payment.uid = ".$uid."
                                        AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
                                        AND payment.transactionverified = 1 AND payment.status = 1";
                            //echo $query;
                            $db->setQuery($query);
                            $packages = $db->loadObjectList();
                            foreach($packages AS $package){
                                    if($package->folders > $package->folderavail){
                                        $packagedetail[0] = $package->id;
                                        $packagedetail[1] = $package->paymentid;
                                    }
                            }
                            $returnvalue[0] = true;
                            $returnvalue[1] = $packagedetail;
                            return $returnvalue;
                        }

		}elseif ($unlimited == 1) { $returnvalue[0] = true; $returnvalue[1] = $packagedetail; return $returnvalue; } // unlimited

		return 0;
	}

	function canSetJobAlert($uid)
	{
		$db = &$this->getDBO();
		if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
		$query = "SELECT package.id AS packageid, package.jobalertsetting, package.packageexpireindays, payment.id AS paymentid, payment.created
                        FROM `#__js_job_jobseekerpackages` AS package
                        JOIN `#__js_job_jobseekerpaymenthistory` AS payment ON payment.packageid = package.id
                        WHERE payment.uid = ".$uid."
                        AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
                        AND payment.transactionverified = 1 AND payment.status = 1";
		$db->setQuery($query);
              // echo '<br>'.$query;
		$packages = $db->loadObjectList();
		$allow = 0;
		if(isset($packages)){
			foreach($packages AS $pack){
				if ($pack->jobalertsetting == 1) $allow = 1 ;
			}
		}	
		return $allow;
	}

	function canAddNewGoldCompany($uid) 
	{
		$db = &$this->getDBO();
		
		if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;

		$query = "SELECT package.goldcompanies, package.packageexpireindays, payment.created
                        FROM `#__js_job_employerpackages` AS package
                        JOIN `#__js_job_employerpaymenthistory` AS payment ON payment.packageid = package.id
                        WHERE payment.uid = ".$uid."
                        AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
                        AND payment.transactionverified = 1";
		$db->setQuery($query);
		$companies = $db->loadObjectList();
		$unlimited = 0;
		foreach($companies AS $company){
			if($unlimited == 0){
				if ($company->goldcompanies != -1){
					$goldcompanies .= $company->goldcompanies;
				}else $unlimited = 1;
			}	
		}
		
		if ($unlimited == 0){
                        if ($goldcompanies == 0) return 0; //can not add new gold company

			$query = "SELECT COUNT(company.id) 
			FROM `#__js_job_goldcompanies` AS company
			WHERE company.uid = ".$uid;
			$db->setQuery($query);
			$totalcompanies = $db->loadResult();
			
			if ($goldcompanies <= $totalcompanies) return 0; //can not add new job
			else return 1;
			
		}elseif ($unlimited == 1) return 1; // unlimited
		
		return 0;
	}

        function canAddNewFeaturedCompany($uid)
	{
		$db = &$this->getDBO();
		
		if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;

		$query = "SELECT package.featuredcompaines, package.packageexpireindays, payment.created
                        FROM `#__js_job_employerpackages` AS package
                        JOIN `#__js_job_employerpaymenthistory` AS payment ON payment.packageid = package.id
                        WHERE payment.uid = ".$uid."
                        AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
                        AND payment.transactionverified = 1";
		$db->setQuery($query);
		$companies = $db->loadObjectList();
		$unlimited = 0;
		foreach($companies AS $company){
			if($unlimited == 0){
				if ($company->featuredcompaines != -1){
					$featuredcompaines .= $company->featuredcompaines;
				}else $unlimited = 1;
			}	
		}
		if ($unlimited == 0){
                    if ($featuredcompaines == 0) return 0; //can not add new job
			$query = "SELECT COUNT(company.id) 
			FROM `#__js_job_featuredcompanies` AS company
			WHERE company.uid = ".$uid;
			$db->setQuery($query);
			$totalcompanies = $db->loadResult();
			
			if ($featuredcompaines <= $totalcompanies) return 0; //can not add new company
			else return 1;
			
		}elseif ($unlimited == 1) return 1; // unlimited
		
		return 0;
	}

	
	function canAddNewFeaturedJob($uid) 
	{
		$db = &$this->getDBO();
		
		if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;

		$query = "SELECT package.featuredjobs, package.packageexpireindays, payment.created
		FROM `#__js_job_employerpackages` AS package
		JOIN `#__js_job_employerpaymenthistory` AS payment ON payment.packageid = package.id
		WHERE payment.uid = ".$uid." 
		AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE() 
		AND payment.transactionverified = 1";
		//echo $query;
		$db->setQuery($query);
		$jobs = $db->loadObjectList();
		$unlimited = 0;
		foreach($jobs AS $job){
			if($unlimited == 0){
				if ($job->featuredjobs != -1){
					$featuredjobs = $featuredjobs + $job->featuredjobs;
				}else $unlimited = 1;
			}	
		}
		if ($unlimited == 0){
                    if ($featuredjobs == 0) return 0; //can not add new job
			$query = "SELECT COUNT(job.id) 
			FROM `#__js_job_featuredjobs` AS job
			WHERE job.uid = ".$uid;
			$db->setQuery($query);
			$totaljobs = $db->loadResult();
			
			if ($featuredjobs <= $totaljobs) return 0; //can not add new job
			else return 1;
			
		}elseif ($unlimited == 1) return 1; // unlimited
		
		return 0;
	}


	function canAddNewGoldJob($uid) 
	{
		$db = &$this->getDBO();
		
		if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;

		$query = "SELECT package.goldjobs, package.packageexpireindays, payment.created
		FROM `#__js_job_employerpackages` AS package
		JOIN `#__js_job_employerpaymenthistory` AS payment ON payment.packageid = package.id
		WHERE payment.uid = ".$uid." 
		AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE() 
		AND payment.transactionverified = 1";
		//echo $query;
		$db->setQuery($query);
		$jobs = $db->loadObjectList();
		$unlimited = 0;
		foreach($jobs AS $job){
			if($unlimited == 0){
				if ($job->goldjobs != -1){
					$goldjobs .= $job->goldjobs;
				}else $unlimited = 1;
			}	
		}
		if ($unlimited == 0){
        		if ($goldjobs == 0) return 0; //can not add new job
		
			$query = "SELECT COUNT(job.id) 
			FROM `#__js_job_goldjobs` AS job
			WHERE job.uid = ".$uid;
			$db->setQuery($query);
			$totaljobs = $db->loadResult();
			
			if ($goldjobs <= $totaljobs) return 0; //can not add new job
			else return 1;
			
		}elseif ($unlimited == 1) return 1; // unlimited
		
		return 0;
	}


	
	function canAddNewResume($uid) 
	{
		$db = &$this->getDBO();
		if($uid) if ((is_numeric($uid) == false)) return false;

                $returnvalue = array();
                $packagedetail = array();
                if (($uid == 0) || ($uid == '')){ $returnvalue[0] = false; $returnvalue[1] = $packagedetail; return $returnvalue; }
		$query = "SELECT package.id, package.resumeallow, package.packageexpireindays, payment.id AS paymentid, payment.created
		FROM `#__js_job_jobseekerpackages` AS package
		JOIN `#__js_job_jobseekerpaymenthistory` AS payment ON payment.packageid = package.id
		WHERE payment.uid = ".$uid."
		AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
		AND payment.transactionverified = 1 AND payment.status = 1";
		$db->setQuery($query);
		$resumes = $db->loadObjectList();
		if(empty($resumes))
		{
			$query = "SELECT package.id, package.resumeallow,package.title AS packagetitle, package.packageexpireindays, payment.id AS paymentid
							 , (TO_DAYS( CURDATE() ) - To_days( payment.created ) ) AS packageexpiredays
							FROM `#__js_job_jobseekerpackages` AS package
							JOIN `#__js_job_jobseekerpaymenthistory` AS payment ON payment.packageid = package.id
							WHERE payment.uid = ".$uid." 
							AND payment.transactionverified = 1 AND payment.status = 1 ORDER BY payment.created DESC";
			$db->setQuery($query);
			$packagedetail = $db->loadObjectList();
			
			$return_value[0] = false;
			$return_value[1] = $packagedetail;
			return $return_value;
		}
		$unlimited = 0;
                $resumeallow = 0;
		foreach($resumes AS $resume){
			if($unlimited == 0){
				if ($resume->resumeallow != -1){
					$resumeallow = $resume->resumeallow + $resumeallow;
				}else{
                                    $unlimited = 1;
                                }
                                    $packagedetail[0] = $resume->id;
                                    $packagedetail[1] = $resume->paymentid;
			}
		}
		if ($unlimited == 0){
			if ($resumeallow == 0) { $returnvalue[0] = false; $returnvalue[1] = $packagedetail; return $returnvalue; } //can not add new resume
			$query = "SELECT COUNT(resume.id) AS totalresumes
			FROM `#__js_job_resume` AS resume
			WHERE resume.uid = ".$uid;
			$db->setQuery($query);
			$totalresume = $db->loadResult();

			if ($resumeallow <= $totalresume) { $returnvalue[0] = false; $returnvalue[1] = $packagedetail; return $returnvalue; } //can not add new resume
			else{
                            $query = "SELECT payment.id AS paymentid, package.id, package.resumeallow
                                        , (SELECT COUNT(id) FROM #__js_job_resume WHERE packageid = package.id AND paymenthistoryid = payment.id AND uid = ".$uid.") AS resumeavail
                                        FROM #__js_job_jobseekerpaymenthistory AS payment
                                        JOIN #__js_job_jobseekerpackages AS package ON package.id = payment.packageid
                                        WHERE uid = ".$uid."
                                        AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
                                        AND payment.transactionverified = 1 AND payment.status = 1 ";
                            //echo $query;
                            $db->setQuery($query);
                            $packages = $db->loadObjectList();
                            foreach($packages AS $package){
                                    if($package->resumeallow > $package->resumeavail){
                                        $packagedetail[0] = $package->id;
                                        $packagedetail[1] = $package->paymentid;
                                    }
                            }
                            $returnvalue[0] = true;
                            $returnvalue[1] = $packagedetail;
                            return $returnvalue;
                        }

		}elseif ($unlimited == 1) { $returnvalue[0] = true; $returnvalue[1] = $packagedetail; return $returnvalue; } // unlimited

		$returnvalue[0] = false; $returnvalue[1] = $packagedetail; return $returnvalue;

        }

	function canAddNewCoverLetter($uid) 
	{
		$db = &$this->getDBO();
		if($uid) if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
		$returnvalue = array();
                $packagedetail = array();
                if (($uid == 0) || ($uid == '')){ $returnvalue[0] = false; $returnvalue[1] = $packagedetail; return $returnvalue; }
		$query = "SELECT package.id, package.coverlettersallow, package.packageexpireindays, payment.id AS paymentid, payment.created
		FROM `#__js_job_jobseekerpackages` AS package
		JOIN `#__js_job_jobseekerpaymenthistory` AS payment ON payment.packageid = package.id
		WHERE payment.uid = ".$uid."
		AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
		AND payment.transactionverified = 1 AND payment.status = 1";
		//echo $query;
		$db->setQuery($query);
		$resumes = $db->loadObjectList();
		if(empty($resumes))
		{
			$query = "SELECT package.id, package.resumeallow,package.title AS packagetitle, package.packageexpireindays, payment.id AS paymentid
							 , (TO_DAYS( CURDATE() ) - To_days( payment.created ) ) AS packageexpiredays
							FROM `#__js_job_jobseekerpackages` AS package
							JOIN `#__js_job_jobseekerpaymenthistory` AS payment ON payment.packageid = package.id
							WHERE payment.uid = ".$uid." 
							AND payment.transactionverified = 1 AND payment.status = 1 ORDER BY payment.created DESC";
			$db->setQuery($query);
			$packagedetail = $db->loadObjectList();
			
			$return_value[0] = false;
			$return_value[1] = $packagedetail;
			return $return_value;
		}
		$unlimited = 0;
                $coverlettersallow = 0;
		foreach($resumes AS $resume){
			if($unlimited == 0){
				if ($resume->coverlettersallow != -1){
					$coverlettersallow = $resume->coverlettersallow + $coverlettersallow;
				}else{
                                    $unlimited = 1;
                                    $packagedetail[0] = $resume->id;
                                    $packagedetail[1] = $resume->paymentid;
                                }
			}
		}
		if ($unlimited == 0){
                    if ($coverlettersallow == 0) { $returnvalue[0] = false; $returnvalue[1] = $packagedetail; return $returnvalue; } //can not add new resume
			$query = "SELECT COUNT(coverletter.id) AS totalcoverletters
			FROM `#__js_job_coverletters` AS coverletter
			WHERE coverletter.uid = ".$uid;
			$db->setQuery($query);
			$totalcoverletters = $db->loadResult();
                        //echo '<br>to '.$totlajob;
                        //echo '<br>al '.$jobsallow;

			if ($coverlettersallow <= $totalcoverletters) { $returnvalue[0] = false; $returnvalue[1] = $packagedetail; return $returnvalue; } //can not add new resume
			else{
                            $query = "SELECT payment.id AS paymentid, package.id, package.coverlettersallow
                                        , (SELECT COUNT(id) FROM #__js_job_coverletters WHERE packageid = package.id AND paymenthistoryid = payment.id AND uid = ".$uid.") AS coverlettersavail
                                        FROM #__js_job_jobseekerpaymenthistory AS payment
                                        JOIN #__js_job_jobseekerpackages AS package ON package.id = payment.packageid
                                        WHERE uid = ".$uid."
                                        AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
                                        AND payment.transactionverified = 1 AND payment.status = 1 ";
                            //echo $query;
                            $db->setQuery($query);
                            $packages = $db->loadObjectList();
                            foreach($packages AS $package){
                                    if($package->coverlettersallow > $package->coverlettersavail){
                                        $packagedetail[0] = $package->id;
                                        $packagedetail[1] = $package->paymentid;
                                    }
                            }
                            $returnvalue[0] = true;
                            $returnvalue[1] = $packagedetail;
                            return $returnvalue;
                        }

		}elseif ($unlimited == 1) { $returnvalue[0] = true; $returnvalue[1] = $packagedetail; return $returnvalue; } // unlimited

		$returnvalue[0] = false; $returnvalue[1] = $packagedetail; return $returnvalue;

        }

	function &getCompanybyIdforForm($id, $uid,$visitor,$vis_email,$jobid)
	{
		$db = &$this->getDBO();
		if (is_numeric($uid) == false) return false;
		if (($id != '') && ($id != 0)){
			if (is_numeric($id) == false) return false;
			$query = "SELECT company.*
			FROM `#__js_job_companies` AS company 
			WHERE company.id = ".$id;
			$db->setQuery($query);
			$company = $db->loadObject();
		}
        if (isset($vis_email) && ($vis_email != '') && ($jobid != '')){
			$query = "SELECT company.*
			FROM `#__js_job_jobs` AS job
			JOIN `#__js_job_companies` AS company ON company.id = job.companyid
			WHERE job.jobid = ".$db->quote($jobid)." AND company.contactemail = ".$db->quote($vis_email);
			$db->setQuery($query);
			$company = $db->loadObject();
		}

		$countries = $this->getCountries('');
                if(isset($visitor) && $visitor == 1){
                    if ( isset($company) ){
                            $states = $this->getStates($company->country, '');
                            $counties = $this->getCounties($company->state, '');
                            $cities = $this->getCities($company->county, '');
                            $lists['jobcategory'] = JHTML::_('select.genericList', $this->getCategories(''), 'companycategory', 'class="inputbox required" '. '', 'value', 'text', $company->category);
                            $lists['country'] = JHTML::_('select.genericList', $countries, 'companycountry','class="inputbox required" '.'onChange="dochangecompany(\'company_state\', this.value)"', 'value', 'text', $company->country);
                            if ( isset($states[1]) ) if ($states[1] != '')$lists['state'] = JHTML::_('select.genericList', $states, 'companystate', 'class="inputbox" '. 'onChange="dochangecompany(\'company_county\', this.value)"', 'value', 'text', $company->state);
                            if ( isset($counties[1]) ) if ($counties[1] != '')$lists['county'] = JHTML::_('select.genericList', $counties, 'companycounty', 'class="inputbox" '. 'onChange="dochangecompany(\'company_city\', this.value)"', 'value', 'text', $company->county);
                            if ( isset($cities[1]) ) if ($cities[1] != '')$lists['city'] = JHTML::_('select.genericList', $cities, 'companycity', 'class="inputbox" '. '', 'value', 'text', $company->city);
                    }else{
                            if(! isset($this->_config)){ $this->getConfig('');}
							$comapnies = $this->getCompanies($uid);
                            if(isset($this->_defaultcountry))$states = $this->getStates($this->_defaultcountry, '');
                            $lists['jobcategory'] = JHTML::_('select.genericList', $this->getCategories(''), 'companycategory', 'class="inputbox required" '. '', 'value', 'text', '');
                            if(isset($comapnies[0]))$lists['companies'] = JHTML::_('select.genericList', $this->getCompanies($uid), 'companycompany', 'class="inputbox required" '. '', 'value', 'text', '');
                            $lists['country'] = JHTML::_('select.genericList', $countries, 'companycountry','class="inputbox required" '.'onChange="dochangecompany(\'company_state\', this.value)"', 'value', 'text', $this->_defaultcountry);
                            if ( isset($states[1]) ) if ($states[1] != '')$lists['state'] = JHTML::_('select.genericList', $states, 'companystate', 'class="inputbox" '. 'onChange="dochangecompany(\'company_county\', this.value)"', 'value', 'text', '');
                            if ( isset($counties[1]) ) if ($counties[1] != '')$lists['county'] = JHTML::_('select.genericList', $counties, 'companycounty', 'class="inputbox" '. 'onChange="dochangecompany(\'company_city\', this.value)"', 'value', 'text', '');
                            if ( isset($cities[1]) ) if ($cities[1] != '')$lists['city'] = JHTML::_('select.genericList', $cities, 'companycity', 'class="inputbox" '. '', 'value', 'text', '');
                    }

                }else{
                    if ( isset($company) ){
                            $states = $this->getStates($company->country, '');
                            $counties = $this->getCounties($company->state, '');
                            $cities = $this->getCities($company->county, '');
                            $lists['jobcategory'] = JHTML::_('select.genericList', $this->getCategories(''), 'category', 'class="inputbox required" '. '', 'value', 'text', $company->category);
                            $lists['country'] = JHTML::_('select.genericList', $countries, 'country','class="inputbox required" '.'onChange="dochange(\'state\', this.value)"', 'value', 'text', $company->country);
                            if ( isset($states[1]) ) if ($states[1] != '')$lists['state'] = JHTML::_('select.genericList', $states, 'state', 'class="inputbox" '. 'onChange="dochange(\'county\', this.value)"', 'value', 'text', $company->state);
                            if ( isset($counties[1]) ) if ($counties[1] != '')$lists['county'] = JHTML::_('select.genericList', $counties, 'county', 'class="inputbox" '. 'onChange="dochange(\'city\', this.value)"', 'value', 'text', $company->county);
                            if ( isset($cities[1]) ) if ($cities[1] != '')$lists['city'] = JHTML::_('select.genericList', $cities, 'city', 'class="inputbox" '. '', 'value', 'text', $company->city);
                    }else{
                            if(! isset($this->_config)){ $this->getConfig('');}
                            if(isset($this->_defaultcountry))$states = $this->getStates($this->_defaultcountry, '');
                            $lists['jobcategory'] = JHTML::_('select.genericList', $this->getCategories(''), 'category', 'class="inputbox required" '. '', 'value', 'text', '');
                            $lists['companies'] = JHTML::_('select.genericList', $this->getCompanies($uid), 'company', 'class="inputbox required" '. '', 'value', 'text', '');
                            $lists['country'] = JHTML::_('select.genericList', $countries, 'country','class="inputbox required" '.'onChange="dochange(\'state\', this.value)"', 'value', 'text', $this->_defaultcountry);
                            if ( isset($states[1]) ) if ($states[1] != '')$lists['state'] = JHTML::_('select.genericList', $states, 'state', 'class="inputbox" '. 'onChange="dochange(\'county\', this.value)"', 'value', 'text', '');
                            if ( isset($counties[1]) ) if ($counties[1] != '')$lists['county'] = JHTML::_('select.genericList', $counties, 'county', 'class="inputbox" '. 'onChange="dochange(\'city\', this.value)"', 'value', 'text', '');
                            if ( isset($cities[1]) ) if ($cities[1] != '')$lists['city'] = JHTML::_('select.genericList', $cities, 'city', 'class="inputbox" '. '', 'value', 'text', '');
                    }
                }
		if (isset($company)) $result[0] = $company; else $result[0] = null;
		$result[1] = $lists;
//		$result[2] = $this->getUserFields(1, $company->id); // company fields, id
		if(isset($visitor) && $visitor == 1){
			$result[2] = $this->getUserFields(11, $id); // company fields, id
			$result[3] = $this->getFieldsOrdering(11); // company fields
		}else{
			$result[2] = $this->getUserFields(1, $id); // company fields, id
			$result[3] = $this->getFieldsOrdering(1); // company fields
		}
		
		if ($id) // not new
			$result[4] = 1;
		else{ // new
			$returnvalue = $this->canAddNewCompany($uid);
			$result[4] = $returnvalue[0];
			$result[5] = $returnvalue[1];
		}

		return $result;
	}

        function sendJobAlertJobseeker($jobid){
            $db = &$this->getDBO();
		if ((is_numeric($jobid) == false) || ($jobid == 0) || ($jobid == '')) return false;
            $query = "SELECT job.title,job.jobcategory, category.cat_title AS categorytitle, subcategory.title AS subcategorytitle
                            ,subcategory.id AS subcategoryid, job.country, job.state, job.county, job.city
                            , country.name as countryname, state.name as statename, county.name as countyname, city.name as cityname
                            , job.metakeywords AS keywords

                        FROM `#__js_job_jobs` AS job
                        JOIN `#__js_job_categories` AS category ON job.jobcategory  = category.id
                        LEFT JOIN `#__js_job_subcategories` AS subcategory ON job.subcategoryid = subcategory.categoryid
                         JOIN `#__js_job_countries` AS country ON job.country = country.code
                        LEFT JOIN `#__js_job_states` AS state ON job.state = state.code
                        LEFT JOIN `#__js_job_counties` AS county ON job.county = county.code
                        LEFT JOIN `#__js_job_cities` AS city ON job.city = city.code
                        WHERE job.id = ".$jobid;
           // echo '<br>'.$query;
            $db->setQuery($query);
            $job = $db->loadObject();
            if(isset($job->keywords)){
				$keywords = explode(' ',$job->keywords);
				$metakeywords = array();
				foreach($keywords AS $keyword){
					$metakeywords[] = " jobalert.keywords LIKE LOWER('%".$keyword."%')";
				}
				$metakeywords[] = " jobalert.keywords = '' OR jobalert.keywords IS NULL";
			}
            $countryquery = "(SELECT jobalert.contactemail
                            FROM `#__js_job_jobalertsetting` AS jobalert
                            WHERE jobalert.categoryid = ".$job->jobcategory." 
							AND LOWER(jobalert.country) = LOWER(".$db->quote($job->country) .")";
                if($job->subcategoryid) $countryquery .= " AND jobalert.subcategoryid = ".$db->quote($job->subcategoryid);
                if($job->state) $countryquery .= " AND LOWER(jobalert.state) != LOWER(".$db->quote($job->state).")";
                if($job->county) $countryquery .= " AND LOWER(jobalert.county) != LOWER(".$db->quote($job->county).")";
                if($job->city) $countryquery .= " AND LOWER(jobalert.city) != LOWER(".$db->quote($job->city).")";
                if($job->keywords) $countryquery .= " AND ( ".implode(' OR ', $metakeywords)." )";
            $countryquery .= ")";
            $query = $countryquery;
            if($job->state){
                $statequery = "(SELECT jobalert.contactemail
                                FROM `#__js_job_jobalertsetting` AS jobalert
                                WHERE jobalert.categoryid = ".$job->jobcategory." 
								AND LOWER(jobalert.country) = LOWER(".$db->quote($job->country) .")";
					if($job->subcategoryid) $statequery .= " AND jobalert.subcategoryid = ".$db->quote($job->subcategoryid);
                    if($job->state) $statequery .= " AND LOWER(jobalert.state) = LOWER(".$db->quote($job->state).")";
                    if($job->county) $statequery .= " AND LOWER(jobalert.county) != LOWER(".$db->quote($job->county).")";
                    if($job->city) $statequery .= " AND LOWER(jobalert.city) != LOWER(".$db->quote($job->city).")";
					if($job->keywords) $statequery .= " AND ( ".implode(' OR ', $metakeywords)." )";
                $statequery .= ")";
               $query .= " UNION " . $statequery;
            }
            if($job->county){
                $countyquery = "(SELECT jobalert.contactemail
                                FROM `#__js_job_jobalertsetting` AS jobalert
                                WHERE jobalert.categoryid = ".$job->jobcategory." 
								AND LOWER(jobalert.country) = LOWER(".$db->quote($job->country) .")";
					if($job->subcategoryid) $countyquery .= " AND jobalert.subcategoryid = ".$db->quote($job->subcategoryid);
                    if($job->state) $countyquery .= " AND LOWER(jobalert.state) = LOWER(".$db->quote($job->state).")";
                    if($job->county) $countyquery .= " AND LOWER(jobalert.county) = LOWER(".$db->quote($job->county).")";
                    if($job->city) $countyquery .= " AND LOWER(jobalert.city) != LOWER(".$db->quote($job->city).")";
					if($job->keywords) $countyquery .= " AND ( ".implode(' OR ', $metakeywords)." )";
                $countyquery .= ")";
               $query .= " UNION " . $countyquery;
            }
            if($job->city){
                $cityquery = "(SELECT jobalert.contactemail
                                FROM `#__js_job_jobalertsetting` AS jobalert
                                WHERE jobalert.categoryid = ".$job->jobcategory." 
								AND LOWER(jobalert.country) = LOWER(".$db->quote($job->country) .")";
					if($job->subcategoryid) $cityquery .= " AND jobalert.subcategoryid = ".$db->quote($job->subcategoryid);
                    if($job->state) $cityquery .= " AND LOWER(jobalert.state) = LOWER(".$db->quote($job->state).")";
                    if($job->county) $cityquery .= " AND LOWER(jobalert.county) = LOWER(".$db->quote($job->county).")";
                    if($job->city) $cityquery .= " AND LOWER(jobalert.city) = LOWER(".$db->quote($job->city).")";
					if($job->keywords) $cityquery .= " AND ( ".implode(' OR ', $metakeywords)." )";
                $cityquery .= ")";
               $query .= " UNION " . $cityquery;
            }
            //echo '<br>'.$query;
            $db->setQuery($query);
            $result = $db->loadObjectList();
			
			if (isset($result)){
	            foreach ($result AS $email){
	                $bcc[] = $email->contactemail;
	                //echo '<br>'.$email->contactemail;
	            }
			}else exit;
			
            $comma = '';
            if($job->cityname) {$location = $comma.$job->cityname; $comma = ', ';}
            elseif($job->city) {$location = $comma.$job->city; $comma = ', ';}
            if($job->countyname) {$location = $comma.$job->countyname; $comma = ', ';}
            elseif($job->county) {$location = $comma.$job->county; $comma = ', ';}
            if($job->statename) {$location = $comma.$job->statename; $comma = ', ';}
            elseif($job->state) {$location = $comma.$job->state; $comma = ', ';}
            $location .= $comma.$job->countryname;
            $msgSubject = 'New Job';
            $query = "SELECT template.* FROM `#__js_job_emailtemplates` AS template	WHERE template.templatefor = 'job-alert'";
            $db->setQuery( $query );
            $template = $db->loadObject();
            $msgSubject = $template->subject;
            $msgBody = $template->body;

			$mail_jobs='<table width="100%" cellpadding="10px" cellspacing="0">
						<tr>
							<th>'.JText::_('JS_JOB_TITLE').'</th>
							<th>'.JText::_('JS_JOB_CATEGORY').'</th>
							<th>'.JText::_('JS_JOB_SUBCATEGORY').'</th>
							<th>'.JText::_('JS_JOB_LOCATION').'</th>
						</tr>';
			$path = JURI::root().'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=view_job&vj=5&oi='.$job->id.'&Itemid=105';
			$mail_jobs .= '<tr>
							<td><a href="'.$path.'" target="_blank">'.$job->title.'</a></td>
							<td>'.$job->categorytitle.'</td>
							<td>'.$job->subcategorytitle.'</td>
							<td>'.$location.'</td>
						</tr>';
			$mail_jobs .= '</table>';
			$msgBody = str_replace('{SHOW_JOBS}', $mail_jobs, $msgBody);

			$config = $this->getConfigByFor('email');

            $message =& JFactory::getMailer();
            $message->addRecipient($config['mailfromaddress']); //to email
            
            //$message->addCC($cc);
            $message->addBCC($bcc);

            $message->setSubject($msgSubject);
            $message->setBody($msgBody);
            $sender = array( $config['mailfromaddress'], $config['mailfromname']);
            $message->setSender($sender);

            $message->IsHTML(true);
            //print_r($bcc) ;
            //echo '<br>'.$msgBody;
            $sent = $message->send();
			//echo '<br>Error sending email: ' . $sent->message;
            return $result;
        }
        function sendMessageEmail($messageid){
            $db = &$this->getDBO();
			if ((is_numeric($messageid) == false) || ($messageid == 0) || ($messageid == '')) return false;
            $query = "SELECT job.title as jobtitle
                        , resume.application_title as resumetitle, resume.email_address as jobseekeremail
                        , company.name as companyname, company.contactemail as employeremail
                        , message.subject, message.message, message.employerid, message.sendby
                        ,empuser.name as employername
                        ,jsuser.name as jobseekername
                    FROM `#__js_job_messages` AS message
                    JOIN `#__js_job_jobs` AS job ON job.id = message.jobid
                    JOIN `#__js_job_resume` AS resume ON resume.id = message.resumeid
                    JOIN `#__js_job_companies` AS company ON company.id = job.companyid
                    JOIN `#__users` AS empuser ON job.uid = empuser.id
                    JOIN `#__users` AS jsuser ON resume.uid = jsuser.id
                    WHERE message.id = ".$messageid;
            //echo '<br>'.$query;
            $db->setQuery( $query );
            $message = $db->loadObject();
            if($message){
                    $query = "SELECT template.* FROM `#__js_job_emailtemplates` AS template	WHERE template.templatefor = 'message-email'";
                    $db->setQuery( $query );
                    $template = $db->loadObject();
                    $msgSubject = $template->subject;
                    $msgBody = $template->body;
                    $msgSubject = str_replace('{COMPANY_NAME}', $message->companyname, $msgSubject);
                    $msgSubject = str_replace('{EMPLOYER_NAME}', $message->employername, $msgSubject);
                    if ($message->employerid == $message->sendby){ // send by employer
                        $msgBody = str_replace('{NAME}', $message->jobseekername, $msgBody);
                        $msgBody = str_replace('{SENDER_NAME}', $message->employername, $msgBody);
                        $to = $message->jobseekeremail;
                    }else{
                        $msgBody = str_replace('{NAME}', $message->employername, $msgBody);
                        $msgBody = str_replace('{SENDER_NAME}', $message->jobseekername, $msgBody);
                        $to = $message->employeremail;
                    }
                    $msgBody = str_replace('{JOB_TITLE}', $message->jobtitle, $msgBody);
                    $msgBody = str_replace('{COMPANY_NAME}', $message->companyname, $msgBody);
                    $msgBody = str_replace('{RESUME_TITLE}', $message->resumetitle, $msgBody);

                    $config = $this->getConfigByFor('email');

                    $message =& JFactory::getMailer();
                    $sender = array( $config['mailfromaddress'], $config['mailfromname']);
                    $message->setSender($sender);
                    $message->addRecipient($to); //to email
                    //$recipient = array( 'person1@domain.com', 'person2@domain.com', 'person3@domain.com' );
                    //$message->addCC($cc);
                    $message->addBCC($bcc);
                    $message->setSubject($msgSubject);
                    $message->setBody($msgBody);
                    $message->IsHTML(true);
                    //print_r($bcc) ;
                    //echo '<br>'.$msgSubject;
                    //echo '<br>'.$msgBody;
                    $sent = $message->send();
                    return 1;
            }else{
                return 4;
            }
        }
	function &getJobAlertbyUidforForm($uid)
	{
		$db = &$this->getDBO();
		if($uid) if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
		if(! isset($this->_config)){
			$this->getConfig('');
		}	
		foreach ($this->_config as $conf){
			if ($conf->configname == 'overwrite_jobalert_settings')
				$overwrite_jobalert_settings = $conf->configvalue;
		}
		$jobalert =  $overwrite_jobalert_settings;
		if($jobalert == 0){
                $jobalert = $this->canSetJobAlert($uid);
		}
		if ($jobalert == 1){
			if (is_numeric($uid) == false) return false;
			if ($uid != 0){
	           	$query = "SELECT jobset.*
	                FROM `#__js_job_jobalertsetting` AS jobset
					WHERE jobset.uid = ".$uid;
						$db->setQuery($query);
				$setting = $db->loadObject();
			}
			$countries = $this->getCountries('');
				$alerttype = $this->getAlerttype('', '');
	                $categories = $this->getCategories('');
	                if(isset($setting)){
				$states = $this->getStates($setting->country, '');
				$counties = $this->getCounties($setting->state, '');
				$cities = $this->getCities($setting->county, '');
				if($setting->categoryid) $categoryid = $setting->categoryid; else $categoryid = $categories[0]['value'];
				if($setting->subcategoryid) $subcategoryid = $setting->subcategoryid; else $subcategoryid = '';
				
				$lists['jobcategory'] = JHTML::_('select.genericList', $categories, 'categoryid', 'class="inputbox" ' . 'onChange="fj_getsubcategories(\'fj_subcategory\', this.value)"', 'value', 'text', $categoryid);
				$lists['subcategory'] = JHTML::_('select.genericList', $this->getSubCategoriesforCombo($categoryid,JText::_('JS_SUB_CATEGORY'),''), 'subcategoryid', 'class="inputbox" '. '', 'value', 'text', $subcategoryid );
				$lists['country'] = JHTML::_('select.genericList', $countries, 'country','class="inputbox required" '.'onChange="dochange(\'state\', this.value)"', 'value', 'text', $setting->country);
				$lists['alerttype'] = JHTML::_('select.genericList', $alerttype, 'alerttype','class="inputbox required" '.'', 'value', 'text', $setting->alerttype);
				if ( isset($states[1]) ) if ($states[1] != '')$lists['state'] = JHTML::_('select.genericList', $states, 'state', 'class="inputbox" '. 'onChange="dochange(\'county\', this.value)"', 'value', 'text', $setting->state);
				if ( isset($counties[1]) ) if ($counties[1] != '')$lists['county'] = JHTML::_('select.genericList', $counties, 'county', 'class="inputbox" '. 'onChange="dochange(\'city\', this.value)"', 'value', 'text', $setting->county);
				if ( isset($cities[1]) ) if ($cities[1] != '')$lists['city'] = JHTML::_('select.genericList', $cities, 'city', 'class="inputbox" '. '', 'value', 'text', $setting->city);
	                }else{
				if(! isset($this->_config)){ $this->getConfig('');}
				if(isset($this->_defaultcountry))$states = $this->getStates($this->_defaultcountry, '');
				$lists['jobcategory'] = JHTML::_('select.genericList', $categories, 'categoryid', 'class="inputbox" ' . 'onChange="fj_getsubcategories(\'fj_subcategory\', this.value)"', 'value', 'text', '');
				$lists['subcategory'] = JHTML::_('select.genericList', $this->getSubCategoriesforCombo($categories[0]['value'],JText::_('JS_SUB_CATEGORY'),''), 'subcategoryid', 'class="inputbox" '. '', 'value', 'text', '');
				$lists['country'] = JHTML::_('select.genericList', $countries, 'country','class="inputbox required" '.'onChange="dochange(\'state\', this.value)"', 'value', 'text', $this->_defaultcountry);
				$lists['alerttype'] = JHTML::_('select.genericList', $alerttype, 'alerttype','class="inputbox required" '.'', 'value', 'text', '');
	            if ( isset($states[1]) ) if ($states[1] != '')$lists['state'] = JHTML::_('select.genericList', $states, 'state', 'class="inputbox" '. 'onChange="dochange(\'county\', this.value)"', 'value', 'text', '');
				if ( isset($counties[1]) ) if ($counties[1] != '')$lists['county'] = JHTML::_('select.genericList', $counties, 'county', 'class="inputbox" '. 'onChange="dochange(\'city\', this.value)"', 'value', 'text', '');
				if ( isset($cities[1]) ) if ($cities[1] != '')$lists['city'] = JHTML::_('select.genericList', $cities, 'city', 'class="inputbox" '. '', 'value', 'text', '');
	                }
		}		
		if(isset($setting)) $result[0] = $setting;
		$result[1] = $lists;
		$result[2] = $jobalert;
		return $result;
	}
	function &getFolderResumebyFolderId($uid,$folderid,$sortby,$limit,$limitstart)
	{
		$db = &$this->getDBO();
		if($uid) if((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
		if (is_numeric($folderid) == false) return false;
		$result = array();
                if (is_numeric($folderid) == false) return false;
           	$query = "SELECT COUNT(folderresume.id)
                FROM `#__js_job_folderresumes` AS folderresume
		JOIN `#__js_job_resume` AS resume ON folderresume.resumeid = resume.id
				WHERE folderresume.folderid = ".$folderid."
                                AND resume.published = 1 ";
                //if($jobid) $query .= " AND folderresume.jobid = ".$jobid;
		$db->setQuery($query);
		$total = $db->loadResult();
		//$limit = $limit ? $limit : 5;
                if ( $total <= $limitstart ) $limitstart = 0;
		$query = "SELECT  apply.comments,apply.id, cat.cat_title ,apply.apply_date, jobtype.title AS jobtypetitle
                        , app.id AS appid, app.first_name, app.last_name, app.email_address, app.jobtype,app.gender
                        ,app.total_experience, app.jobsalaryrange, salary.rangestart, salary.rangeend
                        ,rating.id AS ratingid, rating.rating
                        ,app.address_city, app.address_county, app.address_state
                        ,country.name AS countryname,state.name AS statename
                        ,county.name AS countyname,city.name AS cityname
                        FROM `#__js_job_resume` AS app
                        JOIN `#__js_job_jobtypes` AS jobtype ON app.jobtype = jobtype.id
                        JOIN `#__js_job_categories` AS cat ON app.job_category = cat.id
                        JOIN `#__js_job_jobapply` AS apply  ON apply.cvid = app.id
                        LEFT JOIN  `#__js_job_resumerating` AS rating ON (app.id=rating.resumeid AND apply.jobid=rating.jobid)
                        LEFT JOIN  `#__js_job_salaryrange` AS salary ON app.jobsalaryrange=salary.id
                        LEFT JOIN  `#__js_job_folderresumes` AS fres ON (app.id=fres.resumeid AND apply.jobid=fres.jobid)
                        LEFT JOIN `#__js_job_countries` AS country ON app.address_country  = country.code
                        LEFT JOIN `#__js_job_states` AS state ON app.address_state = state.code
                        LEFT JOIN `#__js_job_counties` AS county ON app.address_county  = county.code
                        LEFT JOIN `#__js_job_cities` AS city ON app.address_city = city.code
		WHERE fres.folderid = ".$folderid;
                //echo '<br>'.$query;
		$db->setQuery($query, $limitstart, $limit);
		$folderresume = $db->loadObjectList();
                $result[0] = $folderresume ;
		$result[1] = $total;
		return $result;
	}

	function &getMyFolders($uid, $limit,$limitstart)
	{
		$result = array();
		$db = &$this->getDBO();

		if (is_numeric($uid) == false) return false;
		if (($uid == 0) || ($uid == '')) return false;
		$query = "SELECT count(folder.id)
                        FROM `#__js_job_folders` AS folder
                        WHERE folder.uid = ".$uid;
		$db->setQuery($query);
		$total = $db->loadResult();
		if ( $total <= $limitstart ) $limitstart = 0;

                $query = "SELECT folder.*
                                , ( SELECT count(id) FROM `#__js_job_folderresumes` WHERE folder.id = folderid) AS noofresume
			FROM `#__js_job_folders` AS folder
			WHERE folder.uid = ".$uid;
		$db->setQuery($query, $limitstart, $limit);
		//echo '<br>'.$query;
                $result[0] = $db->loadObjectList();
		$result[1] = $total;

		return $result;
	}
	function &getFolderDetail($uid,$fid)
	{
		$result = array();
		$db = &$this->getDBO();

		if (is_numeric($uid) == false) return false;
		if(!is_numeric($fid)) return false;
		if (($uid == 0) || ($uid == '')) return false;
		$query = "SELECT folder.*
			FROM `#__js_job_folders` AS folder
			WHERE folder.uid = ".$uid." AND folder.id = ".$fid;
		$db->setQuery($query);
		//echo '<br>'.$query;
		$result = $db->loadObject();
		return $result;
	}

        function getMyJobsForCombo( $uid,$title ) {
                $db =& JFactory::getDBO();
                $query = "SELECT  id, title FROM `#__js_job_jobs` WHERE jobstatus = 1 AND uid = ".$uid." ORDER BY title ASC ";
                $db->setQuery( $query );
                $rows = $db->loadObjectList();
                if ($db->getErrorNum()) {
                    echo $db->stderr();
                    return false;
                }
                $jobs = array();
                if($title)
                    $jobs[] =  array('value' => JText::_(''),'text' => $title);
                foreach($rows  as $row)	{
                    $jobs[] =  array('value' => $row->id,'text' => $row->title);
                }
                return $jobs;
        }

	function &getFolderbyIdforForm($id, $uid)
	{
		$db = &$this->getDBO();
		if (is_numeric($uid) == false) return false;
		if (($id != '') && ($id != 0)){
			if (is_numeric($id) == false) return false;
			$query = "SELECT folder.*
			FROM `#__js_job_folders` AS folder
			WHERE folder.id = ".$id;
			$db->setQuery($query);
			$folder = $db->loadObject();
		}

		if (isset($folder)) $result[0] = $folder; else $result[0] = null;
		if ($id) // not new
			$result[1] = 1;
		else{ // new
			$returnvalue = $this->canAddNewFolder($uid);
			$result[1] = $returnvalue[0];
			$result[2] = $returnvalue[1];
                }

		return $result;
	}

	function &getJobCat($cmbfiltercountry,$cmbfilterstate,$cmbfiltercounty,$cmbfiltercity
						,$txtfiltercountry,$txtfilterstate,$txtfiltercounty,$txtfiltercity
						,$filterjobsalaryrange,$filterheighesteducation,$filterjobcategory,$filterjobsubcategory,$filterjobtype 
						,$txtfilterlongitude,$txtfilterlatitude,$txtfilterradius,$cmbfilterradiustype
						)
	{
		if ($filterjobtype != '') if (is_numeric($filterjobtype) == false) return false;
		if ($filterjobsalaryrange != '') if (is_numeric($filterjobsalaryrange) == false) return false;
		if ($filterheighesteducation != '') if (is_numeric($filterheighesteducation) == false) return false;

		if(!$cmbfiltercountry) $cmbfiltercountry = $txtfiltercountry;
		if(!$cmbfilterstate) $cmbfilterstate = $txtfilterstate;
		if(!$cmbfiltercounty) $cmbfiltercounty = $txtfiltercounty;
		if(!$cmbfiltercity) $cmbfiltercity = $txtfiltercity;
		
		$db = &$this->getDBO();

		if(! isset($this->_config)){
			$this->getConfig('');
		}	
		foreach ($this->_config as $conf){
			if ($conf->configname == 'filter_address_fields_width')
				$address_fields_width = $conf->configvalue;
			if ($conf->configname == 'defaultcountry')
				$defaultcountry = $conf->configvalue;
			if ($conf->configname == 'hidecountry')
				$hidecountry = $conf->configvalue;
		}
		//if(!$defaultcountry) $defaultcountry = 'PK';
		//if(!$cmbfiltercountry) $cmbfiltercountry = $defaultcountry;
        //for radius search
        switch($cmbfilterradiustype){
			case "m":$radiuslength = 6378137;break;
			case "km":$radiuslength = 6378.137;break;
			case "mile":$radiuslength = 3963.191;break;
			case "nacmiles":$radiuslength = 3441.596;break;
		}
		$selectdistance = " ";
        if($txtfilterlongitude != '' && $txtfilterlatitude != '' && $txtfilterradius != ''){
			//$radiussearch = " acos((sin(PI()*$latitude/180)*sin(PI()*job.latitude/180))+(cos(PI()*$latitude/180)*cos(PI()*job.latitude/180)*cose(PI()*job.longitude/180 - PI()*$longitude/180)))*$radiuslength <= $radius";
			$radiussearch = " acos((SIN( PI()* $txtfilterlatitude /180 )*SIN( PI()*job.latitude/180 ))+(cos(PI()* $txtfilterlatitude /180)*COS( PI()*job.latitude/180) *COS(PI()*job.longitude/180-PI()* $txtfilterlongitude /180)))* $radiuslength <= $txtfilterradius";
			//$selectdistance = " ,acos((sin(PI()*$latitude/180)*sin(PI()*job.latitude/180))+(cos(PI()*$latitude/180)*cos(PI()*job.latitude/180)*cose(PI()*job.longitude/180 - PI()*$longitude/180)))*$radiuslength AS distance ";
		}
		$wherequery = '';
		if ($cmbfiltercountry != '') $wherequery .= " AND job.country = ".$db->Quote($cmbfiltercountry);
		elseif ($txtfiltercountry != '') $wherequery .= " AND country.name LIKE ".$db->Quote($txtfiltercountry);
		//elseif ($txtfiltercountry != '') $wherequery .= " AND country.name LIKE ".$db->Quote('%'.$db->getEscaped( $txtfiltercountry, true ).'%', false);
		if ($cmbfilterstate != '') $wherequery .= " AND job.state = ".$db->Quote($cmbfilterstate);
		elseif ($txtfilterstate != '') $wherequery .= " AND state.name LIKE ".$db->Quote($txtfilterstate);
		if ($cmbfiltercounty != '') $wherequery .= " AND job.county = ".$db->Quote($cmbfiltercounty);
		elseif ($txtfiltercounty != '') $wherequery .= " AND county.name LIKE ".$db->Quote($txtfiltercounty);
		if ($cmbfiltercity != '') $wherequery .= " AND job.city = ".$db->Quote($cmbfiltercity);
		elseif ($txtfiltercity != '') $wherequery .= " AND city.name LIKE ".$db->Quote($txtfiltercity);
		
		if ($filterjobcategory != '') $wherequery .= " AND job.jobcategory = ".$filterjobcategory;
		if ($filterjobsubcategory != '') $wherequery .= " AND job.subcategoryid = ".$filterjobsubcategory;
		if ($filterjobtype != '') $wherequery .= " AND job.jobtype = ".$filterjobtype;
		if ($filterjobsalaryrange != '') $wherequery .= " AND job.jobsalaryrange = ".$filterjobsalaryrange;
		if ($filterheighesteducation != '') $wherequery .= " AND job.heighestfinisheducation = ".$filterheighesteducation;
		if(isset($radiussearch)) $wherequery .= " AND $radiussearch";

		$curdate = date('Y-m-d H:i:s');
		$inquery =  " (SELECT COUNT(job.id) from `#__js_job_jobs` AS job WHERE cat.id = job.jobcategory AND job.status = 1 AND job.startpublishing <= " . $db->Quote($curdate) . " AND job.stoppublishing >= " . $db->Quote($curdate);
		$inquery .= $wherequery. " ) as catinjobs";

		$query =  "SELECT  DISTINCT cat.id, cat.cat_title, ";
		$query .= $inquery;
		$query .=  " FROM `#__js_job_categories` AS cat 
					LEFT JOIN `#__js_job_jobs` AS job ON cat.id = job.jobcategory
					LEFT JOIN `#__js_job_countries` AS country ON job.country = country.code 
					LEFT JOIN `#__js_job_states` AS state ON job.state = state.code 
					LEFT JOIN `#__js_job_counties` AS county ON job.county = county.code 
					LEFT JOIN `#__js_job_cities` AS city ON job.city = city.code 
					WHERE cat.isactive = 1 ";
		$query .=  " ORDER BY cat.cat_title ";
		$db->setQuery($query);
		$this->_applications = $db->loadObjectList();

		$jobtype = $this->getJobType(JText::_('JS_SELECT_JOB_TYPE'));
		$jobstatus = $this->getJobStatus(JText::_('JS_SELECT_JOB_STATUS'));
		$heighesteducation = $this->getHeighestEducation(JText::_('JS_SELECT_EDUCATION'));

		$jobcategories[] =  array('value' => '','text' => JText::_('JS_ALL_CATEGORIES'));
		$job_categories = $jobcategories;
		$job_subcategories =  $jobcategories;
			
		$job_salaryrange = $this->getJobSalaryRange(JText::_('JS_SELECT_SALARY'),'','');
		if($hidecountry != 1)$countries = $this->getCountries(JText::_('JS_SELECT_COUNTRY'));
		if($cmbfiltercountry != '') $states = $this->getStates($cmbfiltercountry, JText::_('JS_SELECT_STATE'));
		if ($cmbfilterstate != '') $counties = $this->getCounties($cmbfilterstate, JText::_('JS_SELECT_COUNTY'));
		if ($cmbfiltercounty != '') $cities = $this->getCities($cmbfiltercounty, JText::_('JS_SELECT_CITY'));
		
		
		if($hidecountry != 1)$filterlists['country'] = JHTML::_('select.genericList', $countries, 'cmbfilter_country','class="inputbox" style="width:'.$address_fields_width.'px;" '.'onChange="filter_dochange(\'filter_state\', this.value)"', 'value', 'text', $cmbfiltercountry);
		if ( isset($states[1]) ) if ($states[1] != '') $filterlists['state'] = JHTML::_('select.genericList', $states, 'cmbfilter_state', 'class="inputbox"  style="width:'.$address_fields_width.'px;"'. 'onChange="filter_dochange(\'filter_county\', this.value)"', 'value', 'text', $cmbfilterstate);
		if ( isset($counties[1]) ) if ($counties[1] != '') $filterlists['county'] = JHTML::_('select.genericList', $counties, 'cmbfilter_county', 'class="inputbox"  style="width:'.$address_fields_width.'px;" '. 'onChange="filter_dochange(\'filter_city\', this.value)"', 'value', 'text', $cmbfiltercounty);
		if ( isset($cities[1]) ) if ($cities[1] != '') $filterlists['city'] = JHTML::_('select.genericList', $cities, 'cmbfilter_city', 'class="inputbox"  style="width:'.$address_fields_width.'px;" '. '', 'value', 'text', $cmbfiltercity);

		$filterlists['jobcategory'] = JHTML::_('select.genericList', $job_categories, 'filter_jobcategory', 'class="inputbox" '. 'onChange="fj_getsubcategories(\'td_jobsubcategory\',this.value);"', 'value', 'text', $filterjobcategory);
		$filterlists['jobsubcategory'] = JHTML::_('select.genericList', $job_subcategories, 'filter_jobsubcategory', 'class="inputbox" '. '', 'value', 'text', $filterjobsubcategory);
		$filterlists['jobsalaryrange'] = JHTML::_('select.genericList', $job_salaryrange, 'filter_jobsalaryrange', 'class="inputbox" '. '', 'value', 'text', $filterjobsalaryrange);
		$filterlists['jobtype'] = JHTML::_('select.genericList', $jobtype, 'filter_jobtype', 'class="inputbox" '. '', 'value', 'text', $filterjobtype);
		$filterlists['heighestfinisheducation'] = JHTML::_('select.genericList', $heighesteducation, 'filter_heighesteducation', 'class="inputbox" '. '', 'value', 'text', $filterheighesteducation);

		$filtervalues['state'] = $txtfilterstate;
		$filtervalues['county'] = $txtfiltercounty;
		$filtervalues['city'] = $txtfiltercity;
		$filtervalues['radius'] = $txtfilterradius;
		$filtervalues['longitude'] = $txtfilterlongitude;
		$filtervalues['latitude'] = $txtfilterlatitude;
		
		$result[0] = $this->_applications;
		$result[1] = '';
		$result[2] = $filterlists;
		$result[3] = $filtervalues;
		
		return $result;
	}
	
	function &getUserFields($fieldfor, $id)
	{
		$db = &$this->getDBO();
		//if (isset($id) == false) return false;
		$result;
		//if (is_numeric($id) == false) return $result;
		$field = array();
		$result = array();
		$query =  "SELECT  * FROM `#__js_job_userfields` 
					WHERE published = 1 AND fieldfor = ". $fieldfor;
		$db->setQuery($query);
		$rows = $db->loadObjectList();
		
		$i = 0;
		foreach ($rows as $row){
			$field[0] = $row;
			if ($id != ""){
				$query =  "SELECT  * FROM `#__js_job_userfield_data` WHERE referenceid = ".$id." AND field = ". $row->id;
				$db->setQuery($query);
				$data = $db->loadObject();
				$field[1] = $data;
			}
			if ($row->type == "select"){
				$query =  "SELECT  * FROM `#__js_job_userfieldvalues` WHERE field = ". $row->id;
				$db->setQuery($query);
				$values = $db->loadObjectList();
				$field[2] = $values;
			}
			$result[] = $field;
			$i++;
		}
		return $result;
	}
	
	function &getUserFieldsForView($fieldfor, $id)
	{
		$db = &$this->getDBO();
		//if (isset($id) == false) return false;
		$result;
		//if (is_numeric($id) == false) return $result;
		$field = array();
		$result = array();
		$query =  "SELECT  * FROM `#__js_job_userfields` 
					WHERE published = 1 AND fieldfor = ". $fieldfor;
		$db->setQuery($query);
		$rows = $db->loadObjectList();
		
		$i = 0;
		foreach ($rows as $row){
			$field[0] = $row;
			if ($id != ""){
				$query =  "SELECT  * FROM `#__js_job_userfield_data` WHERE referenceid = ".$id." AND field = ". $row->id;
				$db->setQuery($query);
				$data = $db->loadObject();
				$field[1] = $data;
			}
			if ($row->type == "select"){
				if(isset($id) && $id != ""){//if id is not empty
					$query =  "SELECT  fieldvalue.* FROM `#__js_job_userfield_data` AS fielddata
								JOIN `#__js_job_userfieldvalues` AS fieldvalue ON fieldvalue.id = fielddata.data
								WHERE fielddata.field = ". $row->id." AND fielddata.referenceid = ".$id;
				}else{//general
					$query =  "SELECT  value.* FROM `#__js_job_userfieldvalues` AS value WHERE value.field = ". $row->id;
				}
				/*
				$query =  "SELECT  value.* FROM `#__js_job_userfieldvalues` value
				JOIN `#__js_job_userfield_data` udata ON udata.data = value.id
				WHERE value.field = ". $row->id;
				*/
				$db->setQuery($query);
				$value = $db->loadObject();
				$field[2] = $value;
			}
			$result[] = $field;
			$i++;
		}
		return $result;
	}
	
	function &getFieldsOrdering($fieldfor)
	{
		$db = &$this->getDBO();
		$query =  "SELECT  * FROM `#__js_job_fieldsordering` 
					WHERE published = 1 AND fieldfor =  ". $fieldfor
					." ORDER BY ordering";
		$db->setQuery($query);
		$fields = $db->loadObjectList();
		return $fields;
	}
	
	function &getJobsbyCategory($uid,$cat_id,$cmbfiltercountry,$cmbfilterstate,$cmbfiltercounty,$cmbfiltercity
										,$txtfiltercountry,$txtfilterstate,$txtfiltercounty,$txtfiltercity
										,$filterjobsalaryrange,$filterheighesteducation,$filterjobcategory,$filterjobsubcategory,$filterjobtype 
										,$txtfilterlongitude,$txtfilterlatitude,$txtfilterradius,$cmbfilterradiustype
										,$sortby,$limit,$limitstart)



	{

		if(!$cmbfiltercountry) $cmbfiltercountry = $txtfiltercountry;
		if(!$cmbfilterstate) $cmbfilterstate = $txtfilterstate;
		if(!$cmbfiltercounty) $cmbfiltercounty = $txtfiltercounty;
		if(!$cmbfiltercity) $cmbfiltercity = $txtfiltercity;

		$db = &$this->getDBO();
		$result = array();
		if (is_numeric($cat_id) == false) return false;
		if ($filterjobtype != '') if (is_numeric($filterjobtype) == false) return false;
		if ($filterjobsalaryrange != '') if (is_numeric($filterjobsalaryrange) == false) return false;
		if ($filterheighesteducation != '') if (is_numeric($filterheighesteducation) == false) return false;

		if(! isset($this->_config)){
			$this->getConfig('');
		}	
		foreach ($this->_config as $conf){
			if ($conf->configname == 'filter_address_fields_width')
				$address_fields_width = $conf->configvalue;
			if ($conf->configname == 'defaultcountry')
				$defaultcountry = $conf->configvalue;
			if ($conf->configname == 'hidecountry')
				$hidecountry = $conf->configvalue;
			if ($conf->configname == 'noofgoldjobsinlisting')
				$noofgoldjobs = $conf->configvalue;
			if ($conf->configname == 'nooffeaturedjobsinlisting')
				$nooffeaturedjobs = $conf->configvalue;
			if ($conf->configname == 'showgoldjobsinlistjobs')
				$showgoldjobs = $conf->configvalue;
			if ($conf->configname == 'showfeaturedjobsinlistjobs')
				$showfeaturedjobs = $conf->configvalue;
		}
		//if(!$defaultcountry) $defaultcountry = 'PK';
		//if(!$cmbfiltercountry) $cmbfiltercountry = $defaultcountry;
		$listjobconfig = $this->getConfigByFor('listjob');
        //for radius search
        switch($cmbfilterradiustype){
			case "m":$radiuslength = 6378137;break;
			case "km":$radiuslength = 6378.137;break;
			case "mile":$radiuslength = 3963.191;break;
			case "nacmiles":$radiuslength = 3441.596;break;
		}
		$selectdistance = " ";
        if($txtfilterlongitude != '' && $txtfilterlatitude != '' && $txtfilterradius != ''){
			//$radiussearch = " acos((sin(PI()*$latitude/180)*sin(PI()*job.latitude/180))+(cos(PI()*$latitude/180)*cos(PI()*job.latitude/180)*cose(PI()*job.longitude/180 - PI()*$longitude/180)))*$radiuslength <= $radius";
			$radiussearch = " acos((SIN( PI()* $txtfilterlatitude /180 )*SIN( PI()*job.latitude/180 ))+(cos(PI()* $txtfilterlatitude /180)*COS( PI()*job.latitude/180) *COS(PI()*job.longitude/180-PI()* $txtfilterlongitude /180)))* $radiuslength <= $txtfilterradius";
			//$selectdistance = " ,acos((sin(PI()*$latitude/180)*sin(PI()*job.latitude/180))+(cos(PI()*$latitude/180)*cos(PI()*job.latitude/180)*cose(PI()*job.longitude/180 - PI()*$longitude/180)))*$radiuslength AS distance ";
		}
		$wherequery = '';
		if ($cmbfiltercountry != '') $wherequery .= " AND job.country = ".$db->Quote($cmbfiltercountry);
		elseif ($txtfiltercountry != '') $wherequery .= " AND country.name LIKE ".$db->Quote($txtfiltercountry);
		if ($cmbfilterstate != '') $wherequery .= " AND job.state = ".$db->Quote($cmbfilterstate);
		elseif ($txtfilterstate != '') $wherequery .= " AND state.name LIKE ".$db->Quote($txtfilterstate);
		if ($cmbfiltercounty != '') $wherequery .= " AND job.county = ".$db->Quote($cmbfiltercounty);
		elseif ($txtfiltercounty != '') $wherequery .= " AND county.name LIKE ".$db->Quote($txtfiltercounty);
		if ($cmbfiltercity != '') $wherequery .= " AND job.city = ".$db->Quote($cmbfiltercity);
		elseif ($txtfiltercity != '') $wherequery .= " AND city.name LIKE ".$db->Quote($txtfiltercity);

		//if ($filterjobcategory != '') $wherequery .= " AND job.jobcategory = ".$filterjobcategory;
		if ($filterjobsubcategory != '') $wherequery .= " AND job.subcategoryid = ".$filterjobsubcategory;
		if ($filterjobtype != '') $wherequery .= " AND job.jobtype = ".$filterjobtype;
		//if ($filterjobsalaryrange != '') $wherequery .= " AND job.jobsalaryrange = ".$filterjobsalaryrange;
		if ($filterheighesteducation != '') $wherequery .= " AND job.heighestfinisheducation = ".$filterheighesteducation;
		if(isset($radiussearch)) $wherequery .= " AND $radiussearch";

		$curdate = date('Y-m-d H:i:s');
                // sub categories query
                if ($listjobconfig['subcategories'] == 1) {
                    $inquery =  " (SELECT COUNT(job.id) from `#__js_job_jobs` AS job WHERE subcat.id = job.subcategoryid AND job.status = 1 AND job.startpublishing <= " . $db->Quote($curdate) . " AND job.stoppublishing >= " . $db->Quote($curdate);
                    $inquery .= $wherequery. " ) as jobsinsubcat";

                    $query =  "SELECT  DISTINCT subcat.id, subcat.title, ";
                    $query .= $inquery;
                    $query .=  " FROM `#__js_job_subcategories` AS subcat
                                            LEFT JOIN `#__js_job_jobs` AS job ON subcat.id = job.subcategoryid
                                            LEFT JOIN `#__js_job_countries` AS country ON job.country = country.code
                                            LEFT JOIN `#__js_job_states` AS state ON job.state = state.code
                                            LEFT JOIN `#__js_job_counties` AS county ON job.county = county.code
                                            LEFT JOIN `#__js_job_cities` AS city ON job.city = city.code
                                            WHERE subcat.status = 1 AND categoryid = ".$cat_id;
                    $query .=  " ORDER BY subcat.title ";
                    //echo '<br> SQL '.$query;
                    $db->setQuery($query);
                    $subcategories = $db->loadObjectList();
                }
                // end sub categories

                $query = "SELECT COUNT(job.id) FROM `#__js_job_jobs` AS job
				JOIN `#__js_job_categories` AS cat ON job.jobcategory = cat.id
				LEFT JOIN `#__js_job_salaryrange` AS salary ON job.jobsalaryrange = salary.id 
				LEFT JOIN `#__js_job_countries` AS country ON job.country = country.code 
				LEFT JOIN `#__js_job_states` AS state ON job.state = state.code 
				LEFT JOIN `#__js_job_counties` AS county ON job.county = county.code 
				LEFT JOIN `#__js_job_cities` AS city ON job.city = city.code 
				WHERE job.jobcategory = cat.id AND job.status = 1  AND cat.id = ".$cat_id." 
				AND job.startpublishing <= " . $db->Quote($curdate) . " AND job.stoppublishing >= " . $db->Quote($curdate);
		$query .= $wherequery;
		$db->setQuery($query);
		$total = $db->loadResult();

		if ( $total <= $limitstart ) $limitstart = 0;
                if ($total != 0){
                    $query = "SELECT job.*, cat.cat_title, jobtype.title AS jobtype, jobstatus.title AS jobstatus
                                            , company.id AS companyid, company.name AS companyname, company.url
											, salaryfrom.rangestart AS salaryfrom, salaryto.rangeend AS salaryto, salarytype.title AS salaytype
                                            , country.name AS countryname, state.name AS statename, county.name AS countyname, city.name AS cityname ,currency.symbol
                                            ,(TO_DAYS( CURDATE() ) - To_days( job.startpublishing ) ) AS jobdays
                                    FROM `#__js_job_jobs` AS job
                                    JOIN `#__js_job_categories` AS cat ON job.jobcategory = cat.id
                                    JOIN `#__js_job_jobtypes` AS jobtype ON job.jobtype = jobtype.id
                                    JOIN `#__js_job_jobstatus` AS jobstatus ON job.jobstatus = jobstatus.id
                                    LEFT JOIN `#__js_job_companies` AS company ON job.companyid = company.id
                                    LEFT JOIN `#__js_job_salaryrange` AS salaryfrom ON job.salaryrangefrom = salaryfrom.id
                                    LEFT JOIN `#__js_job_salaryrange` AS salaryto ON job.salaryrangeto = salaryto.id
                                    LEFT JOIN `#__js_job_salaryrangetypes` AS salarytype ON job.salaryrangetype = salarytype.id
                                    LEFT JOIN `#__js_job_countries` AS country ON job.country = country.code
                                    LEFT JOIN `#__js_job_states` AS state ON job.state = state.code
                                    LEFT JOIN `#__js_job_counties` AS county ON job.county = county.code
                                    LEFT JOIN `#__js_job_cities` AS city ON job.city = city.code
                                    LEFT JOIN `#__js_job_currencies` AS currency ON currency.id = job.currencyid
                                    WHERE job.status = 1  AND cat.id = ".$cat_id ."
                                    AND job.startpublishing <= " . $db->Quote($curdate) . " AND job.stoppublishing >= " . $db->Quote($curdate);

                    $query .= $wherequery." ORDER BY  ".$sortby;
                    //echo '<br> SQL '.$query;
                    $db->setQuery($query, $limitstart, $limit);
                    $jobs = $db->loadObjectList();
                }else{
                    $query = "SELECT cat.cat_title
                                    FROM `#__js_job_categories` AS cat
                                    WHERE cat.id = ".$cat_id;
                    $db->setQuery($query);
                    $category = $db->loadObject();
                }
		//for goldjobs
		if($showgoldjobs == 1){
		if($noofgoldjobs != 0)
		{
			$goldjoblimit = ($limitstart/$limit)*$noofgoldjobs;
			$query = "SELECT job.*, cat.cat_title, jobtype.title AS jobtype, jobstatus.title AS jobstatus
					, company.id AS companyid, company.name AS companyname, company.url 
					, salaryfrom.rangestart AS salaryfrom, salaryto.rangeend AS salaryto, salarytype.title AS salaytype
					, country.name AS countryname,city.name AS cityname,county.name AS countyname,state.name AS statename , currency.symbol
					,(TO_DAYS( CURDATE() ) - To_days( job.startpublishing ) ) AS jobdays
				FROM `#__js_job_jobs` AS job
				JOIN `#__js_job_categories` AS cat ON job.jobcategory = cat.id
				JOIN `#__js_job_jobtypes` AS jobtype ON job.jobtype = jobtype.id
				JOIN `#__js_job_jobstatus` AS jobstatus ON job.jobstatus = jobstatus.id
				JOIN `#__js_job_goldjobs` AS gjob ON gjob.jobid = job.id 
				JOIN `#__js_job_employerpackages` AS package ON package.id = gjob.packageid
				LEFT JOIN `#__js_job_companies` AS company ON job.companyid = company.id 
				LEFT JOIN `#__js_job_salaryrange` AS salaryfrom ON job.salaryrangefrom = salaryfrom.id
				LEFT JOIN `#__js_job_salaryrange` AS salaryto ON job.salaryrangeto = salaryto.id
				LEFT JOIN `#__js_job_salaryrangetypes` AS salarytype ON job.salaryrangetype = salarytype.id
				LEFT JOIN `#__js_job_countries` AS country ON job.country = country.code 
				LEFT JOIN `#__js_job_states` AS state ON job.state = state.code 
				LEFT JOIN `#__js_job_counties` AS county ON job.county = county.code 
				LEFT JOIN `#__js_job_cities` AS city ON job.city = city.code 
				LEFT JOIN `#__js_job_currencies` AS currency ON job.currencyid = currency.id 
				WHERE job.status = 1 AND job.id = gjob.jobid
				AND job.startpublishing <= " . $db->Quote($curdate) . " AND job.stoppublishing >= " . $db->Quote($curdate)."
				AND gjob.status = 1 AND DATE_ADD(gjob.created,INTERVAL package.goldjobsexpireindays DAY) >= CURDATE()";
			$db->setQuery($query,$goldjoblimit,$noofgoldjobs);
			$goldjobs = $db->loadObjectList();
		}
		}else $goldjobs = array();

		//for featuredjob
		if($showfeaturedjobs == 1){
		if($nooffeaturedjobs != 0)
		{
			$featuredjoblimit = ($limitstart/$limit)*$nooffeaturedjobs;
			$query = "SELECT job.*, cat.cat_title, jobtype.title AS jobtype, jobstatus.title AS jobstatus
					, company.id AS companyid, company.name AS companyname, company.url 
					, salaryfrom.rangestart AS salaryfrom, salaryto.rangeend AS salaryto, salarytype.title AS salaytype
					, country.name AS countryname,city.name AS cityname,county.name AS countyname,state.name AS statename , currency.symbol
					,(TO_DAYS( CURDATE() ) - To_days( job.startpublishing ) ) AS jobdays
				FROM `#__js_job_jobs` AS job
				JOIN `#__js_job_categories` AS cat ON job.jobcategory = cat.id
				JOIN `#__js_job_jobtypes` AS jobtype ON job.jobtype = jobtype.id
				JOIN `#__js_job_jobstatus` AS jobstatus ON job.jobstatus = jobstatus.id
				JOIN `#__js_job_featuredjobs` AS fjob ON fjob.jobid = job.id 
				JOIN `#__js_job_employerpackages` AS package ON package.id = fjob.packageid
				LEFT JOIN `#__js_job_companies` AS company ON job.companyid = company.id 
				LEFT JOIN `#__js_job_salaryrange` AS salaryfrom ON job.salaryrangefrom = salaryfrom.id
				LEFT JOIN `#__js_job_salaryrange` AS salaryto ON job.salaryrangeto = salaryto.id
				LEFT JOIN `#__js_job_salaryrangetypes` AS salarytype ON job.salaryrangetype = salarytype.id
				LEFT JOIN `#__js_job_countries` AS country ON job.country = country.code 
				LEFT JOIN `#__js_job_states` AS state ON job.state = state.code 
				LEFT JOIN `#__js_job_counties` AS county ON job.county = county.code 
				LEFT JOIN `#__js_job_cities` AS city ON job.city = city.code 
				LEFT JOIN `#__js_job_currencies` AS currency ON job.currencyid = currency.id 
				WHERE job.status = 1 AND job.id = fjob.jobid
				AND job.startpublishing <= " . $db->Quote($curdate) . " AND job.stoppublishing >= " . $db->Quote($curdate)."
				AND fjob.status = 1 AND DATE_ADD(fjob.created,INTERVAL package.featuredjobsexpireindays DAY) >= CURDATE()";
				
			$db->setQuery($query,$featuredjoblimit,$nooffeaturedjobs);
			$featuredjobs = $db->loadObjectList();
		}
		}else $featuredjobs = array();

		$jobtype = $this->getJobType(JText::_('JS_SELECT_JOB_TYPE'));
		$jobstatus = $this->getJobStatus(JText::_('JS_SELECT_JOB_STATUS'));
		$heighesteducation = $this->getHeighestEducation(JText::_('JS_SELECT_EDUCATION'));

		$job_categories = $this->getCategories(JText::_('JS_SELECT_CATEGORY'));
		if($cat_id == 0 || $cat_id == '') $flt_jobcatid = 1; else $flt_jobcatid = $cat_id;
		$job_subcategories = $this->getSubCategoriesforCombo($flt_jobcatid,JText::_('JS_SELECT_CATEGORY'),$value='');
		$job_salaryrange = $this->getJobSalaryRange(JText::_('JS_SELECT_SALARY'),'','');
		if($hidecountry != 1)$countries = $this->getCountries(JText::_('JS_SELECT_COUNTRY'));
		if($cmbfiltercountry != '') $states = $this->getStates($cmbfiltercountry, JText::_('JS_SELECT_STATE'));
		if ($cmbfilterstate != '') $counties = $this->getCounties($cmbfilterstate, JText::_('JS_SELECT_COUNTY'));
		if ($cmbfiltercounty != '') $cities = $this->getCities($cmbfiltercounty, JText::_('JS_SELECT_CITY'));
		
		
		if($hidecountry != 1)$filterlists['country'] = JHTML::_('select.genericList', $countries, 'cmbfilter_country','class="inputbox"  style="width:'.$address_fields_width.'px;" '.'onChange="filter_dochange(\'filter_state\', this.value)"', 'value', 'text', $cmbfiltercountry);
		if ( isset($states[1]) ) if ($states[1] != '') $filterlists['state'] = JHTML::_('select.genericList', $states, 'cmbfilter_state', 'class="inputbox"  style="width:'.$address_fields_width.'px;" '. 'onChange="filter_dochange(\'filter_county\', this.value)"', 'value', 'text', $cmbfilterstate);
		if ( isset($counties[1]) ) if ($counties[1] != '') $filterlists['county'] = JHTML::_('select.genericList', $counties, 'cmbfilter_county', 'class="inputbox"  style="width:'.$address_fields_width.'px;" '. 'onChange="filter_dochange(\'filter_city\', this.value)"', 'value', 'text', $cmbfiltercounty);
		if ( isset($cities[1]) ) if ($cities[1] != '') $filterlists['city'] = JHTML::_('select.genericList', $cities, 'cmbfilter_city', 'class="inputbox"  style="width:'.$address_fields_width.'px;" '. '', 'value', 'text', $cmbfiltercity);
		
		$filterlists['jobcategory'] = JHTML::_('select.genericList', $job_categories, 'filter_jobcategory', 'class="inputbox" '. 'onChange="fj_getsubcategories(\'td_jobsubcategory\',this.value);"', 'value', 'text', $cat_id);
		$filterlists['jobsubcategory'] = JHTML::_('select.genericList', $job_subcategories, 'filter_jobsubcategory', 'class="inputbox" '. '', 'value', 'text', $filterjobsubcategory);
		$filterlists['jobsalaryrange'] = JHTML::_('select.genericList', $job_salaryrange, 'filter_jobsalaryrange', 'class="inputbox" '. '', 'value', 'text', $filterjobsalaryrange);
		$filterlists['jobtype'] = JHTML::_('select.genericList', $jobtype, 'filter_jobtype', 'class="inputbox" '. '', 'value', 'text', $filterjobtype);
		$filterlists['heighestfinisheducation'] = JHTML::_('select.genericList', $heighesteducation, 'filter_heighesteducation', 'class="inputbox" '. '', 'value', 'text', $filterheighesteducation);

		$filtervalues['state'] = $txtfilterstate;
		$filtervalues['county'] = $txtfiltercounty;
		$filtervalues['city'] = $txtfiltercity;
		$filtervalues['radius'] = $txtfilterradius;
		$filtervalues['longitude'] = $txtfilterlongitude;
		$filtervalues['latitude'] = $txtfilterlatitude;
		
                $packageexpiry = $this->getJobSeekerPackageExpiry($uid);
                if($packageexpiry == 1){ //package expire or user not login
                   $listjobconfigs = array();
                    $listjobconfigs['lj_title'] = $listjobconfig['visitor_lj_title'];
                    $listjobconfigs['lj_category'] = $listjobconfig['visitor_lj_category'];
                    $listjobconfigs['lj_jobtype'] = $listjobconfig['visitor_lj_jobtype'];
                    $listjobconfigs['lj_jobstatus'] = $listjobconfig['visitor_lj_jobstatus'];
                    $listjobconfigs['lj_company'] = $listjobconfig['visitor_lj_company'];
                    $listjobconfigs['lj_companysite'] = $listjobconfig['visitor_lj_companysite'];
                    $listjobconfigs['lj_country'] = $listjobconfig['visitor_lj_country'];
                    $listjobconfigs['lj_state'] = $listjobconfig['visitor_lj_state'];
                    $listjobconfigs['lj_county'] = $listjobconfig['visitor_lj_county'];
                    $listjobconfigs['lj_city'] = $listjobconfig['visitor_lj_city'];
                    $listjobconfigs['lj_salary'] = $listjobconfig['visitor_lj_salary'];
                    $listjobconfigs['lj_created'] = $listjobconfig['visitor_lj_created'];
                    $listjobconfigs['lj_noofjobs'] = $listjobconfig['visitor_lj_noofjobs'];
                    $listjobconfigs['subcategories'] = $listjobconfig['subcategories'];
                    $listjobconfigs['subcategories_all'] = $listjobconfig['subcategories_all'];
                    $listjobconfigs['subcategories_colsperrow'] = $listjobconfig['subcategories_colsperrow'];
                    $listjobconfigs['subcategoeis_max_hight'] = $listjobconfig['subcategoeis_max_hight'];
                    $listjobconfigs['lj_description'] = $listjobconfig['visitor_lj_description'];
                    $listjobconfigs['lj_shortdescriptionlenght'] = $listjobconfig['lj_shortdescriptionlenght'];
                    $listjobconfigs['lj_joblistingstyle'] = $listjobconfig['lj_joblistingstyle'];
                }else $listjobconfigs = $listjobconfig; // user

                 if(isset($jobs))$result[0] = $jobs;
		$result[1] = $total;
		$result[2] = $filterlists;
		$result[3] = $filtervalues;
		$result[4] = $listjobconfigs;
		$result[5] = $subcategories;
		if(isset($category)) $result[6] = $category;
		$result[7] = $goldjobs;
		$result[8] = $featuredjobs;
		
		return $result;
	}
	function &getJobsbySubCategory($uid,$subcat_id,$cmbfiltercountry,$cmbfilterstate,$cmbfiltercounty,$cmbfiltercity
										,$txtfiltercountry,$txtfilterstate,$txtfiltercounty,$txtfiltercity
										,$filterjobsalaryrange,$filterheighesteducation,$filterjobcategory,$filterjobsubcategory,$filterjobtype
										,$txtfilterlongitude,$txtfilterlatitude,$txtfilterradius,$cmbfilterradiustype
										,$sortby,$limit,$limitstart)
	{

		if(!$cmbfiltercountry) $cmbfiltercountry = $txtfiltercountry;
		if(!$cmbfilterstate) $cmbfilterstate = $txtfilterstate;
		if(!$cmbfiltercounty) $cmbfiltercounty = $txtfiltercounty;
		if(!$cmbfiltercity) $cmbfiltercity = $txtfiltercity;

		$db = &$this->getDBO();
		$result = array();
		if (is_numeric($subcat_id) == false) return false;
		if ($filterjobtype != '') if (is_numeric($filterjobtype) == false) return false;
		if ($filterjobsalaryrange != '') if (is_numeric($filterjobsalaryrange) == false) return false;
		if ($filterheighesteducation != '') if (is_numeric($filterheighesteducation) == false) return false;

		if(! isset($this->_config)){
			$this->getConfig('');
		}
		foreach ($this->_config as $conf){
			if ($conf->configname == 'filter_address_fields_width')
				$address_fields_width = $conf->configvalue;
			if ($conf->configname == 'noofgoldjobsinlisting')
				$noofgoldjobs = $conf->configvalue;
			if ($conf->configname == 'nooffeaturedjobsinlisting')
				$nooffeaturedjobs = $conf->configvalue;
			if ($conf->configname == 'showgoldjobsinlistjobs')
				$showgoldjobs = $conf->configvalue;
			if ($conf->configname == 'showfeaturedjobsinlistjobs')
				$showfeaturedjobs = $conf->configvalue;
		}
		$listjobconfig = $this->getConfigByFor('listjob');
        //for radius search
        switch($cmbfilterradiustype){
			case "m":$radiuslength = 6378137;break;
			case "km":$radiuslength = 6378.137;break;
			case "mile":$radiuslength = 3963.191;break;
			case "nacmiles":$radiuslength = 3441.596;break;
		}
		$selectdistance = " ";
        if($txtfilterlongitude != '' && $txtfilterlatitude != '' && $txtfilterradius != ''){
			//$radiussearch = " acos((sin(PI()*$latitude/180)*sin(PI()*job.latitude/180))+(cos(PI()*$latitude/180)*cos(PI()*job.latitude/180)*cose(PI()*job.longitude/180 - PI()*$longitude/180)))*$radiuslength <= $radius";
			$radiussearch = " acos((SIN( PI()* $txtfilterlatitude /180 )*SIN( PI()*job.latitude/180 ))+(cos(PI()* $txtfilterlatitude /180)*COS( PI()*job.latitude/180) *COS(PI()*job.longitude/180-PI()* $txtfilterlongitude /180)))* $radiuslength <= $txtfilterradius";
			//$selectdistance = " ,acos((sin(PI()*$latitude/180)*sin(PI()*job.latitude/180))+(cos(PI()*$latitude/180)*cos(PI()*job.latitude/180)*cose(PI()*job.longitude/180 - PI()*$longitude/180)))*$radiuslength AS distance ";
		}
		$wherequery = '';
		if ($cmbfiltercountry != '') $wherequery .= " AND job.country = ".$db->Quote($cmbfiltercountry);
		elseif ($txtfiltercountry != '') $wherequery .= " AND country.name LIKE ".$db->Quote($txtfiltercountry);
		if ($cmbfilterstate != '') $wherequery .= " AND job.state = ".$db->Quote($cmbfilterstate);
		elseif ($txtfilterstate != '') $wherequery .= " AND state.name LIKE ".$db->Quote($txtfilterstate);
		if ($cmbfiltercounty != '') $wherequery .= " AND job.county = ".$db->Quote($cmbfiltercounty);
		elseif ($txtfiltercounty != '') $wherequery .= " AND county.name LIKE ".$db->Quote($txtfiltercounty);
		if ($cmbfiltercity != '') $wherequery .= " AND job.city = ".$db->Quote($cmbfiltercity);
		elseif ($txtfiltercity != '') $wherequery .= " AND city.name LIKE ".$db->Quote($txtfiltercity);

		//if ($filterjobcategory != '') $wherequery .= " AND job.jobcategory = ".$filterjobcategory;
		if ($filterjobtype != '') $wherequery .= " AND job.jobtype = ".$filterjobtype;
		//if ($filterjobsalaryrange != '') $wherequery .= " AND job.jobsalaryrange = ".$filterjobsalaryrange;
		if ($filterheighesteducation != '') $wherequery .= " AND job.heighestfinisheducation = ".$filterheighesteducation;
		if(isset($radiussearch)) $wherequery .= " AND $radiussearch";

		$curdate = date('Y-m-d H:i:s');

                $query = "SELECT COUNT(job.id) FROM `#__js_job_jobs` AS job
				JOIN `#__js_job_categories` AS cat ON job.jobcategory = cat.id
				JOIN `#__js_job_subcategories` AS subcat ON job.subcategoryid = subcat.id
				LEFT JOIN `#__js_job_salaryrange` AS salary ON job.jobsalaryrange = salary.id
				LEFT JOIN `#__js_job_countries` AS country ON job.country = country.code
				LEFT JOIN `#__js_job_states` AS state ON job.state = state.code
				LEFT JOIN `#__js_job_counties` AS county ON job.county = county.code
				LEFT JOIN `#__js_job_cities` AS city ON job.city = city.code
				WHERE job.status = 1  AND subcat.id = ".$subcat_id."
				AND job.startpublishing <= " . $db->Quote($curdate) . " AND job.stoppublishing >= " . $db->Quote($curdate);
		$query .= $wherequery;
		$db->setQuery($query);
		$total = $db->loadResult();

		if ( $total <= $limitstart ) $limitstart = 0;

                if ($total != 0){
                    $query = "SELECT job.*, cat.id as cat_id,cat.cat_title, subcat.title as subcategory, jobtype.title AS jobtype, jobstatus.title AS jobstatus
                                            , company.id AS companyid, company.name AS companyname, company.url
											, salaryfrom.rangestart AS salaryfrom, salaryto.rangeend AS salaryto, salarytype.title AS salaytype
                                            , country.name AS countryname, state.name AS statename, county.name AS countyname, city.name AS cityname ,currency.symbol
                                            ,(TO_DAYS( CURDATE() ) - To_days( job.startpublishing ) ) AS jobdays
                                    FROM `#__js_job_jobs` AS job
                                    JOIN `#__js_job_categories` AS cat ON job.jobcategory = cat.id
                                    JOIN `#__js_job_subcategories` AS subcat ON job.subcategoryid = subcat.id
                                    JOIN `#__js_job_jobtypes` AS jobtype ON job.jobtype = jobtype.id
                                    JOIN `#__js_job_jobstatus` AS jobstatus ON job.jobstatus = jobstatus.id
                                    LEFT JOIN `#__js_job_companies` AS company ON job.companyid = company.id
                                    LEFT JOIN `#__js_job_salaryrange` AS salaryfrom ON job.salaryrangefrom = salaryfrom.id
                                    LEFT JOIN `#__js_job_salaryrange` AS salaryto ON job.salaryrangeto = salaryto.id
                                    LEFT JOIN `#__js_job_salaryrangetypes` AS salarytype ON job.salaryrangetype = salarytype.id
                                    LEFT JOIN `#__js_job_countries` AS country ON job.country = country.code
                                    LEFT JOIN `#__js_job_states` AS state ON job.state = state.code
                                    LEFT JOIN `#__js_job_counties` AS county ON job.county = county.code
                                    LEFT JOIN `#__js_job_cities` AS city ON job.city = city.code
                                    LEFT JOIN `#__js_job_currencies` AS currency ON currency.id = job.currencyid
                                    WHERE job.status = 1  AND subcat.id = ".$subcat_id ."
                                    AND job.startpublishing <= " . $db->Quote($curdate) . " AND job.stoppublishing >= " . $db->Quote($curdate);

                    $query .= $wherequery." ORDER BY  ".$sortby;
                }else{
                    $query = "SELECT cat.id as cat_id, cat.cat_title, subcat.title as subcategory
                                    FROM `#__js_job_categories` AS cat
                                    JOIN `#__js_job_subcategories` AS subcat ON subcat.categoryid = cat.id
                                    WHERE subcat.id = ".$subcat_id;

                }
		$db->setQuery($query, $limitstart, $limit);
		$this->_applications = $db->loadObjectList();

		//for goldjobs
		if($showgoldjobs == 1){
		if($noofgoldjobs != 0)
		{
			$goldjoblimit = ($limitstart/$limit)*$noofgoldjobs;
			$query = "SELECT job.*, cat.cat_title, jobtype.title AS jobtype, jobstatus.title AS jobstatus
					, company.id AS companyid, company.name AS companyname, company.url 
					, salaryfrom.rangestart AS salaryfrom, salaryto.rangeend AS salaryto, salarytype.title AS salaytype
					, country.name AS countryname,city.name AS cityname,county.name AS countyname,state.name AS statename , currency.symbol
					,(TO_DAYS( CURDATE() ) - To_days( job.startpublishing ) ) AS jobdays
				FROM `#__js_job_jobs` AS job
				JOIN `#__js_job_categories` AS cat ON job.jobcategory = cat.id
				JOIN `#__js_job_jobtypes` AS jobtype ON job.jobtype = jobtype.id
				JOIN `#__js_job_jobstatus` AS jobstatus ON job.jobstatus = jobstatus.id
				JOIN `#__js_job_goldjobs` AS gjob ON gjob.jobid = job.id 
				JOIN `#__js_job_employerpackages` AS package ON package.id = gjob.packageid
				LEFT JOIN `#__js_job_companies` AS company ON job.companyid = company.id 
				LEFT JOIN `#__js_job_salaryrange` AS salaryfrom ON job.salaryrangefrom = salaryfrom.id
				LEFT JOIN `#__js_job_salaryrange` AS salaryto ON job.salaryrangeto = salaryto.id
				LEFT JOIN `#__js_job_salaryrangetypes` AS salarytype ON job.salaryrangetype = salarytype.id
				LEFT JOIN `#__js_job_countries` AS country ON job.country = country.code 
				LEFT JOIN `#__js_job_states` AS state ON job.state = state.code 
				LEFT JOIN `#__js_job_counties` AS county ON job.county = county.code 
				LEFT JOIN `#__js_job_cities` AS city ON job.city = city.code 
				LEFT JOIN `#__js_job_currencies` AS currency ON job.currencyid = currency.id 
				WHERE job.status = 1 AND job.id = gjob.jobid
				AND job.startpublishing <= " . $db->Quote($curdate) . " AND job.stoppublishing >= " . $db->Quote($curdate)."
				AND goldjob.status = 1 AND DATE_ADD(gjob.created,INTERVAL package.goldjobsexpireindays DAY) >= CURDATE()";
			$db->setQuery($query,$goldjoblimit,$noofgoldjobs);
			$goldjobs = $db->loadObjectList();
		}
		}else $goldjobs = array();

		//for featuredjob
		if($showfeaturedjobs == 1){
		if($nooffeaturedjobs != 0)
		{
			$featuredjoblimit = ($limitstart/$limit)*$nooffeaturedjobs;
			$query = "SELECT job.*, cat.cat_title, jobtype.title AS jobtype, jobstatus.title AS jobstatus
					, company.id AS companyid, company.name AS companyname, company.url 
					, salaryfrom.rangestart AS salaryfrom, salaryto.rangeend AS salaryto, salarytype.title AS salaytype
					, country.name AS countryname,city.name AS cityname,county.name AS countyname,state.name AS statename , currency.symbol
					,(TO_DAYS( CURDATE() ) - To_days( job.startpublishing ) ) AS jobdays
				FROM `#__js_job_jobs` AS job
				JOIN `#__js_job_categories` AS cat ON job.jobcategory = cat.id
				JOIN `#__js_job_jobtypes` AS jobtype ON job.jobtype = jobtype.id
				JOIN `#__js_job_jobstatus` AS jobstatus ON job.jobstatus = jobstatus.id
				JOIN `#__js_job_featuredjobs` AS fjob ON fjob.jobid = job.id 
				JOIN `#__js_job_employerpackages` AS package ON package.id = fjob.packageid
				LEFT JOIN `#__js_job_companies` AS company ON job.companyid = company.id 
				LEFT JOIN `#__js_job_salaryrange` AS salaryfrom ON job.salaryrangefrom = salaryfrom.id
				LEFT JOIN `#__js_job_salaryrange` AS salaryto ON job.salaryrangeto = salaryto.id
				LEFT JOIN `#__js_job_salaryrangetypes` AS salarytype ON job.salaryrangetype = salarytype.id
				LEFT JOIN `#__js_job_countries` AS country ON job.country = country.code 
				LEFT JOIN `#__js_job_states` AS state ON job.state = state.code 
				LEFT JOIN `#__js_job_counties` AS county ON job.county = county.code 
				LEFT JOIN `#__js_job_cities` AS city ON job.city = city.code 
				LEFT JOIN `#__js_job_currencies` AS currency ON job.currencyid = currency.id 
				WHERE job.status = 1 AND job.id = fjob.jobid
				AND job.startpublishing <= " . $db->Quote($curdate) . " AND job.stoppublishing >= " . $db->Quote($curdate)."
				AND fjob.status = 1 AND DATE_ADD(fjob.created,INTERVAL package.featuredjobsexpireindays DAY) >= CURDATE()";
				
			$db->setQuery($query,$featuredjoblimit,$nooffeaturedjobs);
			$featuredjobs = $db->loadObjectList();
		}
		}else $featuredjobs = array();

		$jobtype = $this->getJobType(JText::_('JS_SELECT_JOB_TYPE'));
		$jobstatus = $this->getJobStatus(JText::_('JS_SELECT_JOB_STATUS'));
		$heighesteducation = $this->getHeighestEducation(JText::_('JS_SELECT_EDUCATION'));
		if($filterjobcategory)
			$categoryid = $filterjobcategory;
		else $categoryid = $this->_applications[0]->cat_id;
		$job_categories = $this->getCategories(JText::_('JS_SELECT_CATEGORY'));
		$job_subcategories = $this->getSubCategoriesforCombo($categoryid,JText::_('JS_SELECT_CATEGORY'),$value='');
		$job_salaryrange = $this->getJobSalaryRange(JText::_('JS_SELECT_SALARY'),'','');
		$countries = $this->getCountries(JText::_('JS_SELECT_COUNTRY'));
		if($cmbfiltercountry != '') $states = $this->getStates($cmbfiltercountry, JText::_('JS_SELECT_STATE'));
		if ($cmbfilterstate != '') $counties = $this->getCounties($cmbfilterstate, JText::_('JS_SELECT_COUNTY'));
		if ($cmbfiltercounty != '') $cities = $this->getCities($cmbfiltercounty, JText::_('JS_SELECT_CITY'));


		$filterlists['country'] = JHTML::_('select.genericList', $countries, 'cmbfilter_country','class="inputbox"  style="width:'.$address_fields_width.'px;" '.'onChange="filter_dochange(\'filter_state\', this.value)"', 'value', 'text', $cmbfiltercountry);
		if ( isset($states[1]) ) if ($states[1] != '') $filterlists['state'] = JHTML::_('select.genericList', $states, 'cmbfilter_state', 'class="inputbox"  style="width:'.$address_fields_width.'px;" '. 'onChange="filter_dochange(\'filter_county\', this.value)"', 'value', 'text', $cmbfilterstate);
		if ( isset($counties[1]) ) if ($counties[1] != '') $filterlists['county'] = JHTML::_('select.genericList', $counties, 'cmbfilter_county', 'class="inputbox"  style="width:'.$address_fields_width.'px;" '. 'onChange="filter_dochange(\'filter_city\', this.value)"', 'value', 'text', $cmbfiltercounty);
		if ( isset($cities[1]) ) if ($cities[1] != '') $filterlists['city'] = JHTML::_('select.genericList', $cities, 'cmbfilter_city', 'class="inputbox"  style="width:'.$address_fields_width.'px;" '. '', 'value', 'text', $cmbfiltercity);

		$filterlists['jobcategory'] = JHTML::_('select.genericList', $job_categories, 'filter_jobcategory', 'class="inputbox" '. 'onChange=fj_getsubcategories(\'td_jobsubcategory\',this.value);', 'value', 'text', $categoryid);
		$filterlists['jobsubcategory'] = JHTML::_('select.genericList', $job_subcategories, 'filter_jobsubcategory', 'class="inputbox" '. '', 'value', 'text', $subcat_id);
		$filterlists['jobsalaryrange'] = JHTML::_('select.genericList', $job_salaryrange, 'filter_jobsalaryrange', 'class="inputbox" '. '', 'value', 'text', $filterjobsalaryrange);
		$filterlists['jobtype'] = JHTML::_('select.genericList', $jobtype, 'filter_jobtype', 'class="inputbox" '. '', 'value', 'text', $filterjobtype);
		$filterlists['heighestfinisheducation'] = JHTML::_('select.genericList', $heighesteducation, 'filter_heighesteducation', 'class="inputbox" '. '', 'value', 'text', $filterheighesteducation);

		$filtervalues['state'] = $txtfilterstate;
		$filtervalues['county'] = $txtfiltercounty;
		$filtervalues['city'] = $txtfiltercity;
		$filtervalues['radius'] = $txtfilterradius;
		$filtervalues['longitude'] = $txtfilterlongitude;
		$filtervalues['latitude'] = $txtfilterlatitude;

                $packageexpiry = $this->getJobSeekerPackageExpiry($uid);
                if($packageexpiry == 1){ //package expire or user not login
                   $listjobconfigs = array();
                    $listjobconfigs['lj_title'] = $listjobconfig['visitor_lj_title'];
                    $listjobconfigs['lj_category'] = $listjobconfig['visitor_lj_category'];
                    $listjobconfigs['lj_jobtype'] = $listjobconfig['visitor_lj_jobtype'];
                    $listjobconfigs['lj_jobstatus'] = $listjobconfig['visitor_lj_jobstatus'];
                    $listjobconfigs['lj_company'] = $listjobconfig['visitor_lj_company'];
                    $listjobconfigs['lj_companysite'] = $listjobconfig['visitor_lj_companysite'];
                    $listjobconfigs['lj_country'] = $listjobconfig['visitor_lj_country'];
                    $listjobconfigs['lj_state'] = $listjobconfig['visitor_lj_state'];
                    $listjobconfigs['lj_county'] = $listjobconfig['visitor_lj_county'];
                    $listjobconfigs['lj_city'] = $listjobconfig['visitor_lj_city'];
                    $listjobconfigs['lj_salary'] = $listjobconfig['visitor_lj_salary'];
                    $listjobconfigs['lj_created'] = $listjobconfig['visitor_lj_created'];
                    $listjobconfigs['lj_noofjobs'] = $listjobconfig['visitor_lj_noofjobs'];
                    $listjobconfigs['subcategories'] = $listjobconfig['subcategories'];
                    $listjobconfigs['subcategories_all'] = $listjobconfig['subcategories_all'];
                    $listjobconfigs['subcategories_colsperrow'] = $listjobconfig['subcategories_colsperrow'];
                    $listjobconfigs['subcategoeis_max_hight'] = $listjobconfig['subcategoeis_max_hight'];
                    $listjobconfigs['lj_description'] = $listjobconfig['visitor_lj_description'];
                    $listjobconfigs['lj_shortdescriptionlenght'] = $listjobconfig['lj_shortdescriptionlenght'];
                    $listjobconfigs['lj_joblistingstyle'] = $listjobconfig['lj_joblistingstyle'];
                }else $listjobconfigs = $listjobconfig; // user

                $result[0] = $this->_applications;
		$result[1] = $total;
		$result[2] = $filterlists;
		$result[3] = $filtervalues;
		$result[4] = $listjobconfigs;
		$result[5] = $goldjobs;
		$result[6] = $featuredjobs;

		return $result;
	}

	function &getJobsbyCompany($companyid,$cmbfiltercountry,$cmbfilterstate,$cmbfiltercounty,$cmbfiltercity
										,$txtfiltercountry,$txtfilterstate,$txtfiltercounty,$txtfiltercity
										,$filterjobsalaryrange,$filterheighesteducation,$filterjobtype 
										,$filterjobcategory
										,$sortby,$limit,$limitstart)
	{

		if(!$cmbfiltercountry) $cmbfiltercountry = $txtfiltercountry;
		if(!$cmbfilterstate) $cmbfilterstate = $txtfilterstate;
		if(!$cmbfiltercounty) $cmbfiltercounty = $txtfiltercounty;
		if(!$cmbfiltercity) $cmbfiltercity = $txtfiltercity;

		$db = &$this->getDBO();
		$result = array();
		if (is_numeric($companyid) == false) return false;
		if ($filterjobcategory != '') if (is_numeric($filterjobcategory) == false) return false;
		if ($filterjobtype != '') if (is_numeric($filterjobtype) == false) return false;
		if ($filterjobsalaryrange != '') if (is_numeric($filterjobsalaryrange) == false) return false;
		if ($filterheighesteducation != '') if (is_numeric($filterheighesteducation) == false) return false;

		if(! isset($this->_config)){
			$this->getConfig('');
		}	
		foreach ($this->_config as $conf){
			if ($conf->configname == 'filter_address_fields_width')
				$address_fields_width = $conf->configvalue;
		}
		$wherequery = '';
		if ($cmbfiltercountry != '') $wherequery .= " AND job.country = ".$db->Quote($cmbfiltercountry);
		elseif ($txtfiltercountry != '') $wherequery .= " AND country.name LIKE ".$db->Quote($txtfiltercountry);
		if ($cmbfilterstate != '') $wherequery .= " AND job.state = ".$db->Quote($cmbfilterstate);
		elseif ($txtfilterstate != '') $wherequery .= " AND state.name LIKE ".$db->Quote($txtfilterstate);
		if ($cmbfiltercounty != '') $wherequery .= " AND job.county = ".$db->Quote($cmbfiltercounty);
		elseif ($txtfiltercounty != '') $wherequery .= " AND county.name LIKE ".$db->Quote($txtfiltercounty);
		if ($cmbfiltercity != '') $wherequery .= " AND job.city = ".$db->Quote($cmbfiltercity);
		elseif ($txtfiltercity != '') $wherequery .= " AND city.name LIKE ".$db->Quote($txtfiltercity);

		if ($filterjobcategory != '') $wherequery .= " AND job.jobcategory = ".$filterjobcategory;
		if ($filterjobtype != '') $wherequery .= " AND job.jobtype = ".$filterjobtype;
		if ($filterjobsalaryrange != '') $wherequery .= " AND job.jobsalaryrange = ".$filterjobsalaryrange;
		if ($filterheighesteducation != '') $wherequery .= " AND job.heighestfinisheducation = ".$filterheighesteducation;

		$curdate = date('Y-m-d H:i:s');

		$query = "SELECT COUNT(job.id) FROM `#__js_job_jobs` AS job
				JOIN `#__js_job_categories` AS cat ON job.jobcategory = cat.id
				LEFT JOIN `#__js_job_salaryrange` AS salary ON job.jobsalaryrange = salary.id 
				LEFT JOIN `#__js_job_countries` AS country ON job.country = country.code 
				LEFT JOIN `#__js_job_states` AS state ON job.state = state.code 
				LEFT JOIN `#__js_job_counties` AS county ON job.county = county.code 
				LEFT JOIN `#__js_job_cities` AS city ON job.city = city.code 
				WHERE job.jobcategory = cat.id AND job.status = 1  AND job.companyid = ".$companyid ." 
				AND job.startpublishing <= " . $db->Quote($curdate) . " AND job.stoppublishing >= " . $db->Quote($curdate);
                $query .= $wherequery;
		$db->setQuery($query);
		$total = $db->loadResult();

		//$limit = $limit ? $limit : 5;
                if ( $total <= $limitstart ) $limitstart = 0;
		
		$query = "SELECT job.*, cat.cat_title, company.name AS companyname, company.url, jobtype.title AS jobtype, jobstatus.title AS jobstatus
					, salary.rangestart, salary.rangeend, country.name AS countryname
				FROM `#__js_job_jobs` AS job
				JOIN `#__js_job_categories` AS cat ON job.jobcategory = cat.id
				JOIN `#__js_job_companies` AS company ON job.companyid = company.id
				JOIN `#__js_job_jobtypes` AS jobtype ON job.jobtype = jobtype.id
				JOIN `#__js_job_jobstatus` AS jobstatus ON job.jobstatus = jobstatus.id
				LEFT JOIN `#__js_job_salaryrange` AS salary ON job.jobsalaryrange = salary.id 
				LEFT JOIN `#__js_job_countries` AS country ON job.country = country.code 
				LEFT JOIN `#__js_job_states` AS state ON job.state = state.code 
				LEFT JOIN `#__js_job_counties` AS county ON job.county = county.code 
				LEFT JOIN `#__js_job_cities` AS city ON job.city = city.code 
				WHERE job.status = 1 AND job.companyid = ".$companyid ." 
				AND job.startpublishing <= " . $db->Quote($curdate) . " AND job.stoppublishing >= " . $db->Quote($curdate);
			
		$query .= $wherequery." ORDER BY  ".$sortby;
		$db->setQuery($query, $limitstart, $limit);
		$this->_applications = $db->loadObjectList();

		$jobtype = $this->getJobType(JText::_('JS_SELECT_JOB_TYPE'));
		$jobstatus = $this->getJobStatus(JText::_('JS_SELECT_JOB_STATUS'));
		$heighesteducation = $this->getHeighestEducation(JText::_('JS_SELECT_EDUCATION'));

		$job_categories = $this->getCategories(JText::_('JS_SELECT_CATEGORY'));
		$job_salaryrange = $this->getJobSalaryRange(JText::_('JS_SELECT_SALARY'),'','');
		$countries = $this->getCountries(JText::_('JS_SELECT_COUNTRY'));
		if($cmbfiltercountry != '') $states = $this->getStates($cmbfiltercountry, JText::_('JS_SELECT_STATE'));
		if ($cmbfilterstate != '') $counties = $this->getCounties($cmbfilterstate, JText::_('JS_SELECT_COUNTY'));
		if ($cmbfiltercounty != '') $cities = $this->getCities($cmbfiltercounty, JText::_('JS_SELECT_CITY'));
		
		
		$filterlists['country'] = JHTML::_('select.genericList', $countries, 'cmbfilter_country','class="inputbox"  style="width:'.$address_fields_width.'px;" '.'onChange="filter_dochange(\'filter_state\', this.value)"', 'value', 'text', $cmbfiltercountry);
		if ( isset($states[1]) ) if ($states[1] != '') $filterlists['state'] = JHTML::_('select.genericList', $states, 'cmbfilter_state', 'class="inputbox"  style="width:'.$address_fields_width.'px;" '. 'onChange="filter_dochange(\'filter_county\', this.value)"', 'value', 'text', $cmbfilterstate);
		if ( isset($counties[1]) ) if ($counties[1] != '') $filterlists['county'] = JHTML::_('select.genericList', $counties, 'cmbfilter_county', 'class="inputbox"  style="width:'.$address_fields_width.'px;" '. 'onChange="filter_dochange(\'filter_city\', this.value)"', 'value', 'text', $cmbfiltercounty);
		if ( isset($cities[1]) ) if ($cities[1] != '') $filterlists['city'] = JHTML::_('select.genericList', $cities, 'cmbfilter_city', 'class="inputbox"  style="width:'.$address_fields_width.'px;" '. '', 'value', 'text', $cmbfiltercity);

		$filterlists['jobcategory'] = JHTML::_('select.genericList', $job_categories, 'filter_jobcategory', 'class="inputbox" '. '', 'value', 'text', $filterjobcategory);
		$filterlists['jobsalaryrange'] = JHTML::_('select.genericList', $job_salaryrange, 'filter_jobsalaryrange', 'class="inputbox" '. '', 'value', 'text', $filterjobsalaryrange);
		$filterlists['jobtype'] = JHTML::_('select.genericList', $jobtype, 'filter_jobtype', 'class="inputbox" '. '', 'value', 'text', $filterjobtype);
		$filterlists['heighestfinisheducation'] = JHTML::_('select.genericList', $heighesteducation, 'filter_heighesteducation', 'class="inputbox" '. '', 'value', 'text', $filterheighesteducation);

		$filtervalues['state'] = $txtfilterstate;
		$filtervalues['county'] = $txtfiltercounty;
		$filtervalues['city'] = $txtfiltercity;
		
		$result[0] = $this->_applications;
		$result[1] = $total;
		$result[2] = $filterlists;
		$result[3] = $filtervalues;
		
		return $result;
	}

        function &getActiveJobsByCompany($uid,$companyid,$cmbfiltercountry,$cmbfilterstate,$cmbfiltercounty,$cmbfiltercity
											,$txtfiltercountry,$txtfilterstate,$txtfiltercounty,$txtfiltercity
											,$filterjobsalaryrange,$filterheighesteducation,$filterjobcategory,$filterjobsubcategory,$filterjobtype,$sortby
											,$txtfilterlongitude,$txtfilterlatitude,$txtfilterradius,$cmbfilterradiustype
											 ,$limit,$limitstart)
	{
		$db = &$this->getDBO();
		$result = array();
		if (is_numeric($companyid) == false) return false;
		if ($filterjobcategory != '') if (is_numeric($filterjobcategory) == false) return false;
		if ($filterjobtype != '') if (is_numeric($filterjobtype) == false) return false;
		if ($filterjobsalaryrange != '') if (is_numeric($filterjobsalaryrange) == false) return false;
		if ($filterheighesteducation != '') if (is_numeric($filterheighesteducation) == false) return false;


		if(!$cmbfiltercountry) $cmbfiltercountry = $txtfiltercountry;
		if(!$cmbfilterstate) $cmbfilterstate = $txtfilterstate;
		if(!$cmbfiltercounty) $cmbfiltercounty = $txtfiltercounty;
		if(!$cmbfiltercity) $cmbfiltercity = $txtfiltercity;
		
		if(! isset($this->_config)){
			$this->getConfig('');
		}	
		foreach ($this->_config as $conf){
			if ($conf->configname == 'filter_address_fields_width')
				$address_fields_width = $conf->configvalue;
		}
		$listjobconfig=$this->getConfigByFor('listjob');
        //for radius search
        switch($cmbfilterradiustype){
			case "m":$radiuslength = 6378137;break;
			case "km":$radiuslength = 6378.137;break;
			case "mile":$radiuslength = 3963.191;break;
			case "nacmiles":$radiuslength = 3441.596;break;
		}
		$selectdistance = " ";
        if($txtfilterlongitude != '' && $txtfilterlatitude != '' && $txtfilterradius != ''){
			//$radiussearch = " acos((sin(PI()*$latitude/180)*sin(PI()*job.latitude/180))+(cos(PI()*$latitude/180)*cos(PI()*job.latitude/180)*cose(PI()*job.longitude/180 - PI()*$longitude/180)))*$radiuslength <= $radius";
			$radiussearch = " acos((SIN( PI()* $txtfilterlatitude /180 )*SIN( PI()*job.latitude/180 ))+(cos(PI()* $txtfilterlatitude /180)*COS( PI()*job.latitude/180) *COS(PI()*job.longitude/180-PI()* $txtfilterlongitude /180)))* $radiuslength <= $txtfilterradius";
			//$selectdistance = " ,acos((sin(PI()*$latitude/180)*sin(PI()*job.latitude/180))+(cos(PI()*$latitude/180)*cos(PI()*job.latitude/180)*cose(PI()*job.longitude/180 - PI()*$longitude/180)))*$radiuslength AS distance ";
		}

		$wherequery = '';
		if ($cmbfiltercountry != '') $wherequery .= " AND job.country = ".$db->Quote($cmbfiltercountry);
		elseif ($txtfiltercountry != '') $wherequery .= " AND country.name LIKE ".$db->Quote($txtfiltercountry);
		if ($cmbfilterstate != '') $wherequery .= " AND job.state = ".$db->Quote($cmbfilterstate);
		elseif ($txtfilterstate != '') $wherequery .= " AND state.name LIKE ".$db->Quote($txtfilterstate);
		if ($cmbfiltercounty != '') $wherequery .= " AND job.county = ".$db->Quote($cmbfiltercounty);
		elseif ($txtfiltercounty != '') $wherequery .= " AND county.name LIKE ".$db->Quote($txtfiltercounty);
		if ($cmbfiltercity != '') $wherequery .= " AND job.city = ".$db->Quote($cmbfiltercity);
		elseif ($txtfiltercity != '') $wherequery .= " AND city.name LIKE ".$db->Quote($txtfiltercity);

		if ($filterjobcategory != '') $wherequery .= " AND job.jobcategory = ".$filterjobcategory;
		if ($filterjobsubcategory != '') $wherequery .= " AND job.subcategoryid = ".$filterjobsubcategory;
		if ($filterjobtype != '') $wherequery .= " AND job.jobtype = ".$filterjobtype;
		if ($filterjobsalaryrange != '') $wherequery .= " AND job.jobsalaryrange = ".$filterjobsalaryrange;
		if ($filterheighesteducation != '') $wherequery .= " AND job.heighestfinisheducation = ".$filterheighesteducation;
		if(isset($radiussearch)) $wherequery .= " AND $radiussearch";

		$curdate = date('Y-m-d H:i:s');

                $query = "SELECT COUNT(job.id) FROM `#__js_job_jobs` AS job
				JOIN `#__js_job_categories` AS cat ON job.jobcategory = cat.id
				LEFT JOIN `#__js_job_salaryrange` AS salary ON job.jobsalaryrange = salary.id 
				LEFT JOIN `#__js_job_countries` AS country ON job.country = country.code 
				LEFT JOIN `#__js_job_states` AS state ON job.state = state.code 
				LEFT JOIN `#__js_job_counties` AS county ON job.county = county.code 
				LEFT JOIN `#__js_job_cities` AS city ON job.city = city.code 
				WHERE job.jobcategory = cat.id AND job.status = 1  AND job.companyid = ".$companyid ." 
				AND job.startpublishing <= " . $db->Quote($curdate) . " AND job.stoppublishing >= " . $db->Quote($curdate);
                $query .= $wherequery;
		$db->setQuery($query);
		$total = $db->loadResult();

		//$limit = $limit ? $limit : 5;
                if ( $total <= $limitstart ) $limitstart = 0;
		
		$query = "SELECT job.*, cat.cat_title, company.name AS companyname, company.url, jobtype.title AS jobtype, jobstatus.title AS jobstatus
					, salaryfrom.rangestart AS salaryfrom, salaryto.rangeend AS salaryto, country.name AS countryname,salarytype.title AS salarytype,currency.symbol
					,(TO_DAYS( CURDATE() ) - To_days( job.startpublishing ) ) AS jobdays
				FROM `#__js_job_jobs` AS job
				JOIN `#__js_job_categories` AS cat ON job.jobcategory = cat.id
				JOIN `#__js_job_companies` AS company ON job.companyid = company.id
				JOIN `#__js_job_jobtypes` AS jobtype ON job.jobtype = jobtype.id
				JOIN `#__js_job_jobstatus` AS jobstatus ON job.jobstatus = jobstatus.id
				LEFT JOIN `#__js_job_salaryrange` AS salaryfrom ON job.salaryrangefrom = salaryfrom.id 
				LEFT JOIN `#__js_job_salaryrange` AS salaryto ON job.salaryrangeto = salaryto.id 
				LEFT JOIN `#__js_job_salaryrangetypes` AS salarytype ON job.salaryrangetype = salarytype.id 
				LEFT JOIN `#__js_job_countries` AS country ON job.country = country.code 
				LEFT JOIN `#__js_job_states` AS state ON job.state = state.code 
				LEFT JOIN `#__js_job_counties` AS county ON job.county = county.code 
				LEFT JOIN `#__js_job_cities` AS city ON job.city = city.code 
				LEFT JOIN `#__js_job_currencies` AS currency ON job.currencyid = currency.id 
				WHERE job.jobcategory = cat.id AND job.status = 1  AND job.companyid = ".$companyid ." 
				AND job.startpublishing <= " . $db->Quote($curdate) . " AND job.stoppublishing >= " . $db->Quote($curdate);
							
		$query .= $wherequery." ORDER BY  ".$sortby;
		$db->setQuery($query, $limitstart, $limit);
		$this->_applications = $db->loadObjectList();

		$jobtype = $this->getJobType(JText::_('JS_SELECT_JOB_TYPE'));
		$jobstatus = $this->getJobStatus(JText::_('JS_SELECT_JOB_STATUS'));
		$heighesteducation = $this->getHeighestEducation(JText::_('JS_SELECT_EDUCATION'));

		$job_categories = $this->getCategories(JText::_('JS_SELECT_CATEGORY'));
		if($filterjobcategory == '') $categoryid = 1; else $categoryid = $filterjobcategory;
		$job_subcategories = $this->getSubCategoriesforCombo($categoryid,JText::_('JS_SELECT_CATEGORY'),$value = '');
		$job_salaryrange = $this->getJobSalaryRange(JText::_('JS_SELECT_SALARY'),'','');
		$countries = $this->getCountries(JText::_('JS_SELECT_COUNTRY'));
		if($cmbfiltercountry != '') $states = $this->getStates($cmbfiltercountry, JText::_('JS_SELECT_STATE'));
		if ($cmbfilterstate != '') $counties = $this->getCounties($cmbfilterstate, JText::_('JS_SELECT_COUNTY'));
		if ($cmbfiltercounty != '') $cities = $this->getCities($cmbfiltercounty, JText::_('JS_SELECT_CITY'));
		
		
		$filterlists['country'] = JHTML::_('select.genericList', $countries, 'cmbfilter_country','class="inputbox"  style="width:'.$address_fields_width.'px;" '.'onChange="filter_dochange(\'filter_state\', this.value)"', 'value', 'text', $cmbfiltercountry);
		if ( isset($states[1]) ) if ($states[1] != '') $filterlists['state'] = JHTML::_('select.genericList', $states, 'cmbfilter_state', 'class="inputbox"  style="width:'.$address_fields_width.'px;" '. 'onChange="filter_dochange(\'filter_county\', this.value)"', 'value', 'text', $cmbfilterstate);
		if ( isset($counties[1]) ) if ($counties[1] != '') $filterlists['county'] = JHTML::_('select.genericList', $counties, 'cmbfilter_county', 'class="inputbox"  style="width:'.$address_fields_width.'px;" '. 'onChange="filter_dochange(\'filter_city\', this.value)"', 'value', 'text', $cmbfiltercounty);
		if ( isset($cities[1]) ) if ($cities[1] != '') $filterlists['city'] = JHTML::_('select.genericList', $cities, 'cmbfilter_city', 'class="inputbox"  style="width:'.$address_fields_width.'px;" '. '', 'value', 'text', $cmbfiltercity);

		$filterlists['jobcategory'] = JHTML::_('select.genericList', $job_categories, 'filter_jobcategory', 'class="inputbox" '. 'onChange=fj_getsubcategories(\'td_jobsubcategory\',this.value);', 'value', 'text', $filterjobcategory);
		$filterlists['jobsubcategory'] = JHTML::_('select.genericList', $job_subcategories, 'filter_jobsubcategory', 'class="inputbox" '. '', 'value', 'text', $filterjobsubcategory);
		$filterlists['jobsalaryrange'] = JHTML::_('select.genericList', $job_salaryrange, 'filter_jobsalaryrange', 'class="inputbox" '. '', 'value', 'text', $filterjobsalaryrange);
		$filterlists['jobtype'] = JHTML::_('select.genericList', $jobtype, 'filter_jobtype', 'class="inputbox" '. '', 'value', 'text', $filterjobtype);
		$filterlists['heighestfinisheducation'] = JHTML::_('select.genericList', $heighesteducation, 'filter_heighesteducation', 'class="inputbox" '. '', 'value', 'text', $filterheighesteducation);

		$filtervalues['state'] = $txtfilterstate;
		$filtervalues['county'] = $txtfiltercounty;
		$filtervalues['city'] = $txtfiltercity;
		$filtervalues['radius'] = $txtfilterradius;
		$filtervalues['longitude'] = $txtfilterlongitude;
		$filtervalues['latitude'] = $txtfilterlatitude;
		
                $packageexpiry = $this->getJobSeekerPackageExpiry($uid);
                if($packageexpiry == 1){ //package expire or user not login
                    $listjobconfigs = array();
                    $listjobconfigs['lj_title'] = $listjobconfig['visitor_lj_title'];
                    $listjobconfigs['lj_category'] = $listjobconfig['visitor_lj_category'];
                    $listjobconfigs['lj_jobtype'] = $listjobconfig['visitor_lj_jobtype'];
                    $listjobconfigs['lj_jobstatus'] = $listjobconfig['visitor_lj_jobstatus'];
                    $listjobconfigs['lj_company'] = $listjobconfig['visitor_lj_company'];
                    $listjobconfigs['lj_companysite'] = $listjobconfig['visitor_lj_companysite'];
                    $listjobconfigs['lj_country'] = $listjobconfig['visitor_lj_country'];
                    $listjobconfigs['lj_state'] = $listjobconfig['visitor_lj_state'];
                    $listjobconfigs['lj_county'] = $listjobconfig['visitor_lj_county'];
                    $listjobconfigs['lj_city'] = $listjobconfig['visitor_lj_city'];
                    $listjobconfigs['lj_salary'] = $listjobconfig['visitor_lj_salary'];
                    $listjobconfigs['lj_created'] = $listjobconfig['visitor_lj_created'];
                    $listjobconfigs['lj_noofjobs'] = $listjobconfig['visitor_lj_noofjobs'];
                }else $listjobconfigs = $listjobconfig; // user

                $result[0] = $this->_applications;
		$result[1] = $total;
		$result[2] = $filterlists;
		$result[3] = $filtervalues;
		$result[4]=$listjobconfigs;
		
		return $result;
	}

	function &getCompanybyId($companyid)
	{
		$db = &$this->getDBO();
		if (is_numeric($companyid) == false) return false;
		$query = "SELECT company.*, cat.cat_title, country.name AS countryname, state.name AS statename
					, county.name AS countyname, city.name AS cityname
		FROM `#__js_job_companies` AS company
		JOIN `#__js_job_categories` AS cat ON company.category = cat.id
		LEFT JOIN `#__js_job_countries` AS country ON company.country = country.code
		LEFT JOIN `#__js_job_states` AS state ON company.state = state.code
		LEFT JOIN `#__js_job_counties` AS county ON company.county = county.code
		LEFT JOIN `#__js_job_cities` AS city ON company.city = city.code
		WHERE  company.id = " . $companyid;
		$db->setQuery($query);
		$result[0] = $db->loadObject();

		$query = "UPDATE `#__js_job_companies` SET hits = hits+1 WHERE id = ".$companyid;
		
		$db->setQuery( $query );
		if (!$db->query()) {
			//return false;
		}
		if($result[0]->uid == 0 || $result[0]->uid == '') $fieldfor = 11;
		else $fieldfor = 1;
		$result[2] = $this->getUserFieldsForView($fieldfor, $companyid); // company fields, id
		$result[3] = $this->getFieldsOrdering($fieldfor); // company fields
		return $result;
	}

	function &getListNewestJobs($uid, $cmbfiltercountry,$cmbfilterstate,$cmbfiltercounty,$cmbfiltercity
											,$txtfiltercountry,$txtfilterstate,$txtfiltercounty,$txtfiltercity
											,$filterjobsalaryrange,$filterheighesteducation,$filterjobcategory,$filterjobsubcategory,$filterjobtype
											,$txtfilterlongitude,$txtfilterlatitude,$txtfilterradius,$cmbfilterradiustype
											,$limit,$limitstart){
		if($uid) if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
		if ($filterjobtype != '') if (is_numeric($filterjobtype) == false) return false;
		if ($filterjobsalaryrange != '') if (is_numeric($filterjobsalaryrange) == false) return false;
		if ($filterheighesteducation != '') if (is_numeric($filterheighesteducation) == false) return false;
		if ($filterjobcategory != '') if (is_numeric($filterjobcategory) == false) return false;

		if(!$cmbfiltercountry) $cmbfiltercountry = $txtfiltercountry;
		if(!$cmbfilterstate) $cmbfilterstate = $txtfilterstate;
		if(!$cmbfiltercounty) $cmbfiltercounty = $txtfiltercounty;
		if(!$cmbfiltercity) $cmbfiltercity = $txtfiltercity;

        $db = &$this->getDBO();
		$result = array();
		if(! isset($this->_config)){
			$this->getConfig('');
		}	
		foreach ($this->_config as $conf){
			if ($conf->configname == 'filter_address_fields_width')
				$address_fields_width = $conf->configvalue;
			if ($conf->configname == 'filter_cat_jobtype_fields_width')
				$cat_jobtype_fields_width = $conf->configvalue;
			if ($conf->configname == 'defaultcountry')
				$defaultcountry = $conf->configvalue;
			if ($conf->configname == 'hidecountry')
				$hidecountry = $conf->configvalue;
			if ($conf->configname == 'noofgoldjobsinlisting')
				$noofgoldjobs = $conf->configvalue;
			if ($conf->configname == 'nooffeaturedjobsinlisting')
				$nooffeaturedjobs = $conf->configvalue;
			if ($conf->configname == 'showgoldjobsinnewestjobs')
				$showgoldjobs = $conf->configvalue;
			if ($conf->configname == 'showfeaturedjobsinnewestjobs')
				$showfeaturedjobs = $conf->configvalue;
		}
		//if(!$defaultcountry) $defaultcountry = 'PK';
		//if(!$cmbfiltercountry) $cmbfiltercountry = $defaultcountry;
		$listjobconfig = $this->getConfigByFor('listjob');
        //for radius search
        switch($cmbfilterradiustype){
			case "m":$radiuslength = 6378137;break;
			case "km":$radiuslength = 6378.137;break;
			case "mile":$radiuslength = 3963.191;break;
			case "nacmiles":$radiuslength = 3441.596;break;
		}
		$selectdistance = " ";
        if($txtfilterlongitude != '' && $txtfilterlatitude != '' && $txtfilterradius != ''){
			//$radiussearch = " acos((sin(PI()*$latitude/180)*sin(PI()*job.latitude/180))+(cos(PI()*$latitude/180)*cos(PI()*job.latitude/180)*cose(PI()*job.longitude/180 - PI()*$longitude/180)))*$radiuslength <= $radius";
			$radiussearch = " acos((SIN( PI()* $txtfilterlatitude /180 )*SIN( PI()*job.latitude/180 ))+(cos(PI()* $txtfilterlatitude /180)*COS( PI()*job.latitude/180) *COS(PI()*job.longitude/180-PI()* $txtfilterlongitude /180)))* $radiuslength <= $txtfilterradius";
			//$selectdistance = " ,acos((sin(PI()*$latitude/180)*sin(PI()*job.latitude/180))+(cos(PI()*$latitude/180)*cos(PI()*job.latitude/180)*cose(PI()*job.longitude/180 - PI()*$longitude/180)))*$radiuslength AS distance ";
		}
		
		$wherequery = '';
		if ($cmbfiltercountry != '') $wherequery .= " AND job.country = ".$db->Quote($cmbfiltercountry);
		elseif ($txtfiltercountry != '') $wherequery .= " AND country.name LIKE ".$db->Quote($txtfiltercountry);
		if ($cmbfilterstate != '') $wherequery .= " AND job.state = ".$db->Quote($cmbfilterstate);
		elseif ($txtfilterstate != '') $wherequery .= " AND state.name LIKE ".$db->Quote($txtfilterstate);
		if ($cmbfiltercounty != '') $wherequery .= " AND job.county = ".$db->Quote($cmbfiltercounty);
		elseif ($txtfiltercounty != '') $wherequery .= " AND county.name LIKE ".$db->Quote($txtfiltercounty);
		if ($cmbfiltercity != '') $wherequery .= " AND job.city = ".$db->Quote($cmbfiltercity);
		elseif ($txtfiltercity != '') $wherequery .= " AND city.name LIKE ".$db->Quote($txtfiltercity);
		
		if ($filterjobtype != '') $wherequery .= " AND job.jobtype = ".$filterjobtype;
		if ($filterjobsalaryrange != '') $wherequery .= " AND job.jobsalaryrange = ".$filterjobsalaryrange;
		if ($filterheighesteducation != '') $wherequery .= " AND job.heighestfinisheducation = ".$filterheighesteducation;
		if ($filterjobcategory != '') $wherequery .= " AND job.jobcategory = ".$filterjobcategory;
		if ($filterjobsubcategory != '') $wherequery .= " AND job.subcategoryid = ".$filterjobsubcategory;
		if(isset($radiussearch)) $wherequery .= " AND $radiussearch";
		$curdate = date('Y-m-d H:i:s');

		$query = "SELECT COUNT(job.id) FROM `#__js_job_jobs` AS job
				JOIN `#__js_job_categories` AS cat ON job.jobcategory = cat.id
				LEFT JOIN `#__js_job_salaryrange` AS salary ON job.jobsalaryrange = salary.id 
				LEFT JOIN `#__js_job_countries` AS country ON job.country = country.code 
				LEFT JOIN `#__js_job_states` AS state ON job.state = state.code 
				LEFT JOIN `#__js_job_counties` AS county ON job.county = county.code 
				LEFT JOIN `#__js_job_cities` AS city ON job.city = city.code 
				WHERE job.status = 1
				AND job.startpublishing <= " . $db->Quote($curdate) . " AND job.stoppublishing >= " . $db->Quote($curdate);
		$query .= $wherequery;
		$db->setQuery($query);
		$total = $db->loadResult();
                if ( $total <= $limitstart ) $limitstart = 0;

                $query = "SELECT job.*, cat.cat_title, jobtype.title AS jobtype, jobstatus.title AS jobstatus
					, company.id AS companyid, company.name AS companyname, company.url 
					, salaryfrom.rangestart AS salaryfrom, salaryto.rangeend AS salaryto, salarytype.title AS salaytype
					, country.name AS countryname,city.name AS cityname,county.name AS countyname,state.name AS statename , currency.symbol
					,(TO_DAYS( CURDATE() ) - To_days( job.startpublishing ) ) AS jobdays
				FROM `#__js_job_jobs` AS job
				JOIN `#__js_job_categories` AS cat ON job.jobcategory = cat.id
				JOIN `#__js_job_jobtypes` AS jobtype ON job.jobtype = jobtype.id
				JOIN `#__js_job_jobstatus` AS jobstatus ON job.jobstatus = jobstatus.id
				LEFT JOIN `#__js_job_companies` AS company ON job.companyid = company.id 
				LEFT JOIN `#__js_job_salaryrange` AS salaryfrom ON job.salaryrangefrom = salaryfrom.id
				LEFT JOIN `#__js_job_salaryrange` AS salaryto ON job.salaryrangeto = salaryto.id
				LEFT JOIN `#__js_job_salaryrangetypes` AS salarytype ON job.salaryrangetype = salarytype.id
				LEFT JOIN `#__js_job_countries` AS country ON job.country = country.code 
				LEFT JOIN `#__js_job_states` AS state ON job.state = state.code 
				LEFT JOIN `#__js_job_counties` AS county ON job.county = county.code 
				LEFT JOIN `#__js_job_cities` AS city ON job.city = city.code 
				LEFT JOIN `#__js_job_currencies` AS currency ON job.currencyid = currency.id 
				WHERE job.status = 1  
				AND job.startpublishing <= " . $db->Quote($curdate) . " AND job.stoppublishing >= " . $db->Quote($curdate);
				
		$query .= $wherequery." ORDER BY  job.startpublishing DESC";
                //echo $query;
		$db->setQuery($query, $limitstart, $limit);
		$this->_applications = $db->loadObjectList();
		
		//for goldjobs
		if($showgoldjobs == 1){
		if($noofgoldjobs != 0)
		{
			$goldjoblimit = ($limitstart/$limit)*$noofgoldjobs;
			$query = "SELECT job.*, cat.cat_title, jobtype.title AS jobtype, jobstatus.title AS jobstatus
					, company.id AS companyid, company.name AS companyname, company.url 
					, salaryfrom.rangestart AS salaryfrom, salaryto.rangeend AS salaryto, salarytype.title AS salaytype
					, country.name AS countryname,city.name AS cityname,county.name AS countyname,state.name AS statename , currency.symbol
					,(TO_DAYS( CURDATE() ) - To_days( job.startpublishing ) ) AS jobdays
				FROM `#__js_job_jobs` AS job
				JOIN `#__js_job_categories` AS cat ON job.jobcategory = cat.id
				JOIN `#__js_job_jobtypes` AS jobtype ON job.jobtype = jobtype.id
				JOIN `#__js_job_jobstatus` AS jobstatus ON job.jobstatus = jobstatus.id
				JOIN `#__js_job_goldjobs` AS gjob ON gjob.jobid = job.id 
				JOIN `#__js_job_employerpackages` AS package ON package.id = gjob.packageid
				LEFT JOIN `#__js_job_companies` AS company ON job.companyid = company.id 
				LEFT JOIN `#__js_job_salaryrange` AS salaryfrom ON job.salaryrangefrom = salaryfrom.id
				LEFT JOIN `#__js_job_salaryrange` AS salaryto ON job.salaryrangeto = salaryto.id
				LEFT JOIN `#__js_job_salaryrangetypes` AS salarytype ON job.salaryrangetype = salarytype.id
				LEFT JOIN `#__js_job_countries` AS country ON job.country = country.code 
				LEFT JOIN `#__js_job_states` AS state ON job.state = state.code 
				LEFT JOIN `#__js_job_counties` AS county ON job.county = county.code 
				LEFT JOIN `#__js_job_cities` AS city ON job.city = city.code 
				LEFT JOIN `#__js_job_currencies` AS currency ON job.currencyid = currency.id 
				WHERE job.status = 1 AND job.id = gjob.jobid
				AND job.startpublishing <= " . $db->Quote($curdate) . " AND job.stoppublishing >= " . $db->Quote($curdate)."
				AND gjob.status = 1 AND DATE_ADD(gjob.created,INTERVAL package.goldjobsexpireindays DAY) >= CURDATE()";
			$db->setQuery($query,$goldjoblimit,$noofgoldjobs);
			$goldjobs = $db->loadObjectList();
		}
		}else $goldjobs = array();

		//for featuredjob
		if($showfeaturedjobs == 1){
		if($nooffeaturedjobs != 0)
		{
			$featuredjoblimit = ($limitstart/$limit)*$nooffeaturedjobs;
			$query = "SELECT job.*, cat.cat_title, jobtype.title AS jobtype, jobstatus.title AS jobstatus
					, company.id AS companyid, company.name AS companyname, company.url 
					, salaryfrom.rangestart AS salaryfrom, salaryto.rangeend AS salaryto, salarytype.title AS salaytype
					, country.name AS countryname,city.name AS cityname,county.name AS countyname,state.name AS statename , currency.symbol
					,(TO_DAYS( CURDATE() ) - To_days( job.startpublishing ) ) AS jobdays
				FROM `#__js_job_jobs` AS job
				JOIN `#__js_job_categories` AS cat ON job.jobcategory = cat.id
				JOIN `#__js_job_jobtypes` AS jobtype ON job.jobtype = jobtype.id
				JOIN `#__js_job_jobstatus` AS jobstatus ON job.jobstatus = jobstatus.id
				JOIN `#__js_job_featuredjobs` AS fjob ON fjob.jobid = job.id 
				JOIN `#__js_job_employerpackages` AS package ON package.id = fjob.packageid
				LEFT JOIN `#__js_job_companies` AS company ON job.companyid = company.id 
				LEFT JOIN `#__js_job_salaryrange` AS salaryfrom ON job.salaryrangefrom = salaryfrom.id
				LEFT JOIN `#__js_job_salaryrange` AS salaryto ON job.salaryrangeto = salaryto.id
				LEFT JOIN `#__js_job_salaryrangetypes` AS salarytype ON job.salaryrangetype = salarytype.id
				LEFT JOIN `#__js_job_countries` AS country ON job.country = country.code 
				LEFT JOIN `#__js_job_states` AS state ON job.state = state.code 
				LEFT JOIN `#__js_job_counties` AS county ON job.county = county.code 
				LEFT JOIN `#__js_job_cities` AS city ON job.city = city.code 
				LEFT JOIN `#__js_job_currencies` AS currency ON job.currencyid = currency.id 
				WHERE job.status = 1 AND job.id = fjob.jobid
				AND job.startpublishing <= " . $db->Quote($curdate) . " AND job.stoppublishing >= " . $db->Quote($curdate)."
				AND fjob.status = 1 AND DATE_ADD(fjob.created,INTERVAL package.featuredjobsexpireindays DAY) >= CURDATE()";
				
			$db->setQuery($query,$featuredjoblimit,$nooffeaturedjobs);
			$featuredjobs = $db->loadObjectList();
		}
		}else $featuredjobs = array();

		$jobtype = $this->getJobType(JText::_('JS_SELECT_JOB_TYPE'));
		$jobstatus = $this->getJobStatus(JText::_('JS_SELECT_JOB_STATUS'));
		$heighesteducation = $this->getHeighestEducation(JText::_('JS_SELECT_EDUCATION'));

		$job_categories = $this->getCategories(JText::_('JS_SELECT_CATEGORY'));
		if($filterjobcategory == '')$categoryid = 1; else $categoryid = $filterjobcategory;
		$job_subcategories = $this->getSubCategoriesforCombo($categoryid,JText::_('JS_SELECT_CATEGORY'),$value='');
		$job_salaryrange = $this->getJobSalaryRange(JText::_('JS_SELECT_SALARY'),'','');
		if($hidecountry != 1)$countries = $this->getCountries(JText::_('JS_SELECT_COUNTRY'));
		if($cmbfiltercountry != '') $states = $this->getStates($cmbfiltercountry, JText::_('JS_SELECT_STATE'));
		if ($cmbfilterstate != '') $counties = $this->getCounties($cmbfilterstate, JText::_('JS_SELECT_COUNTY'));
		if ($cmbfiltercounty != '') $cities = $this->getCities($cmbfiltercounty, JText::_('JS_SELECT_CITY'));
		
		
		if($hidecountry != 1)$filterlists['country'] = JHTML::_('select.genericList', $countries, 'cmbfilter_country','class="inputbox"  style="width:'.$address_fields_width.'px;" '.'onChange="filter_dochange(\'filter_state\', this.value)"', 'value', 'text', $cmbfiltercountry);
		if ( isset($states[1]) ) if ($states[1] != '') $filterlists['state'] = JHTML::_('select.genericList', $states, 'cmbfilter_state', 'class="inputbox"  style="width:'.$address_fields_width.'px;" '. 'onChange="filter_dochange(\'filter_county\', this.value)"', 'value', 'text', $cmbfilterstate);
		if ( isset($counties[1]) ) if ($counties[1] != '') $filterlists['county'] = JHTML::_('select.genericList', $counties, 'cmbfilter_county', 'class="inputbox"  style="width:'.$address_fields_width.'px;" '. 'onChange="filter_dochange(\'filter_city\', this.value)"', 'value', 'text', $cmbfiltercounty);
		if ( isset($cities[1]) ) if ($cities[1] != '') $filterlists['city'] = JHTML::_('select.genericList', $cities, 'cmbfilter_city', 'class="inputbox"  style="width:'.$address_fields_width.'px;" '. '', 'value', 'text', $cmbfiltercity);

		$filterlists['jobcategory'] = JHTML::_('select.genericList', $job_categories, 'filter_jobcategory', 'class="inputbox" style="width:'.$cat_jobtype_fields_width.'px;" '. 'onChange=fj_getsubcategories(\'td_jobsubcategory\',this.value);', 'value', 'text', $filterjobcategory);
		$filterlists['jobsubcategory'] = JHTML::_('select.genericList', $job_subcategories, 'filter_jobsubcategory', 'class="inputbox" style="width:'.$cat_jobtype_fields_width.'px;" '. '', 'value', 'text', $filterjobsubcategory);
		$filterlists['jobsalaryrange'] = JHTML::_('select.genericList', $job_salaryrange, 'filter_jobsalaryrange', 'class="inputbox" style="width:'.$cat_jobtype_fields_width.'px;"  '. '', 'value', 'text', $filterjobsalaryrange);
		$filterlists['jobtype'] = JHTML::_('select.genericList', $jobtype, 'filter_jobtype', 'class="inputbox" style="width:'.$cat_jobtype_fields_width.'px;"  '. '', 'value', 'text', $filterjobtype);
		$filterlists['heighestfinisheducation'] = JHTML::_('select.genericList', $heighesteducation, 'filter_heighesteducation', 'class="inputbox" style="width:'.$cat_jobtype_fields_width.'px;"  '. '', 'value', 'text', $filterheighesteducation);

		$filtervalues['state'] = $txtfilterstate;
		$filtervalues['county'] = $txtfiltercounty;
		$filtervalues['city'] = $txtfiltercity;
		$filtervalues['radius'] = $txtfilterradius;
		$filtervalues['longitude'] = $txtfilterlongitude;
		$filtervalues['latitude'] = $txtfilterlatitude;
		
                $packageexpiry = $this->getJobSeekerPackageExpiry($uid);
                if($packageexpiry == 1){ //package expire or user not login
                    $listjobconfigs = array();
                    $listjobconfigs['lj_title'] = $listjobconfig['visitor_lj_title'];
                    $listjobconfigs['lj_category'] = $listjobconfig['visitor_lj_category'];
                    $listjobconfigs['lj_jobtype'] = $listjobconfig['visitor_lj_jobtype'];
                    $listjobconfigs['lj_jobstatus'] = $listjobconfig['visitor_lj_jobstatus'];
                    $listjobconfigs['lj_company'] = $listjobconfig['visitor_lj_company'];
                    $listjobconfigs['lj_companysite'] = $listjobconfig['visitor_lj_companysite'];
                    $listjobconfigs['lj_country'] = $listjobconfig['visitor_lj_country'];
                    $listjobconfigs['lj_state'] = $listjobconfig['visitor_lj_state'];
                    $listjobconfigs['lj_county'] = $listjobconfig['visitor_lj_county'];
                    $listjobconfigs['lj_city'] = $listjobconfig['visitor_lj_city'];
                    $listjobconfigs['lj_salary'] = $listjobconfig['visitor_lj_salary'];
                    $listjobconfigs['lj_created'] = $listjobconfig['visitor_lj_created'];
                    $listjobconfigs['lj_noofjobs'] = $listjobconfig['visitor_lj_noofjobs'];
                    $listjobconfigs['lj_description'] = $listjobconfig['visitor_lj_description'];
                    $listjobconfigs['lj_shortdescriptionlenght'] = $listjobconfig['lj_shortdescriptionlenght'];
                    $listjobconfigs['lj_joblistingstyle'] = $listjobconfig['lj_joblistingstyle'];
                }else $listjobconfigs = $listjobconfig; // user

		$result[0] = $this->_applications;
		$result[1] = $total;
		$result[2] = $filterlists;
		$result[3] = $filtervalues;
		$result[4] = $listjobconfigs;
		$result[5] = $goldjobs;
		$result[6] = $featuredjobs;

		return $result;
	}
	
	function getEmployerPackageExpiry($uid)
        {
                $db = &$this->getDBO();
                if (($uid == 0) || ($uid == '')) return 1;
		$query = "SELECT package.id 
                        FROM `#__js_job_employerpackages` AS package
                        JOIN `#__js_job_employerpaymenthistory` AS payment ON payment.packageid = package.id
                        WHERE payment.uid = ".$uid."
                        AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
                        AND payment.transactionverified = 1 AND payment.status = 1";
		//echo $query;
		$db->setQuery($query);
		$packages = $db->loadObjectList();
                if (isset($packages)) return 0; else return 1;
            
        }

        function getJobSeekerPackageExpiry($uid)
        {
                $db = &$this->getDBO();
                if (($uid == 0) || ($uid == '')) return 1;
		$query = "SELECT package.id
		FROM `#__js_job_jobseekerpackages` AS package
		JOIN `#__js_job_jobseekerpaymenthistory` AS payment ON payment.packageid = package.id
		WHERE payment.uid = ".$uid."
		AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
		AND payment.transactionverified = 1 AND payment.status = 1";
		//echo $query;
		$db->setQuery($query);
		$packages = $db->loadObjectList();
                if (isset($packages)) return 0; else return 1;

        }

        function &getJobbyId($job_id)
	{
		$db = &$this->getDBO();
		if (is_numeric($job_id) == false) return false;

                $query = "SELECT job.*, cat.cat_title, subcat.title as subcategory, company.name as companyname, jobtype.title AS jobtypetitle
				, jobstatus.title AS jobstatustitle, shift.title as shifttitle
				, department.name AS departmentname
				, salaryfrom.rangestart AS salaryfrom, salaryto.rangeend AS salaryto, salarytype.title AS salarytype
				, education.title AS educationtitle ,mineducation.title AS mineducationtitle, maxeducation.title AS maxeducationtitle
				, experience.title AS experiencetitle ,minexperience.title AS minexperiencetitle, maxexperience.title AS maxexperiencetitle
				, country.name AS countryname, state.name AS statename, county.name AS countyname, city.name AS cityname
				, currency.symbol
		FROM `#__js_job_jobs` AS job
		JOIN `#__js_job_categories` AS cat ON job.jobcategory = cat.id
		LEFT JOIN `#__js_job_subcategories` AS subcat ON job.subcategoryid = subcat.id
		JOIN `#__js_job_companies` AS company ON job.companyid = company.id
		JOIN `#__js_job_jobtypes` AS jobtype ON job.jobtype = jobtype.id
		JOIN `#__js_job_jobstatus` AS jobstatus ON job.jobstatus = jobstatus.id
		LEFT JOIN `#__js_job_departments` AS department ON job.departmentid = department.id
		LEFT JOIN `#__js_job_salaryrange` AS salaryfrom ON job.salaryrangefrom = salaryfrom.id
		LEFT JOIN `#__js_job_salaryrange` AS salaryto ON job.salaryrangeto = salaryto.id
		LEFT JOIN `#__js_job_salaryrangetypes` AS salarytype ON job.salaryrangetype = salarytype.id
		LEFT JOIN `#__js_job_heighesteducation` AS education ON job.educationid = education.id
		LEFT JOIN `#__js_job_heighesteducation` AS mineducation ON job.mineducationrange = mineducation.id
		LEFT JOIN `#__js_job_heighesteducation` AS maxeducation ON job.maxeducationrange = maxeducation.id
		LEFT JOIN `#__js_job_experiences` AS experience ON job.experienceid = experience.id
		LEFT JOIN `#__js_job_experiences` AS minexperience ON job.minexperiencerange = minexperience.id
		LEFT JOIN `#__js_job_experiences` AS maxexperience ON job.maxexperiencerange = maxexperience.id
		LEFT JOIN `#__js_job_shifts` AS shift ON job.shift = shift.id
		LEFT JOIN `#__js_job_countries` AS country ON job.country = country.code
		LEFT JOIN `#__js_job_states` AS state ON job.state = state.code
		LEFT JOIN `#__js_job_counties` AS county ON job.county = county.code
		LEFT JOIN `#__js_job_cities` AS city ON job.city = city.code
		LEFT JOIN `#__js_job_currencies`AS currency ON currency.id = job.currencyid
		WHERE  job.id = " . $job_id;
		$db->setQuery($query);
		$this->_application = $db->loadObject();

		$query = "UPDATE `#__js_job_jobs` SET hits = hits + 1 WHERE id = ".$job_id;
		
		$db->setQuery( $query );
		if (!$db->query()) {
			//return false;
		}
		if($this->_application->uid == 0 || $this->_application->uid == '') $fieldfor = 12;
		else $fieldfor = 2;
		$result[0] = $this->_application;
		$result[2] = $this->getUserFieldsForView($fieldfor, $job_id); // company fields, id
		$result[3] = $this->getFieldsOrdering($fieldfor); // company fields
		$result[4] = $this->getConfigByFor('listjob'); // company fields
		//$result[4]=$canviewmap;
		//$result[5]=$canviewvideo;
		return $result;
	}

	function &getJobbyIdforJobApply($job_id)
	{
		$db = &$this->getDBO();
		
		if (is_numeric($job_id) == false) return false;
		$query = "SELECT job.*, cat.cat_title , company.name as companyname, company.url
				, jobtype.title AS jobtypetitle
				, jobstatus.title AS jobstatustitle, shift.title as shifttitle
				, salary.rangestart, salary.rangeend, education.title AS heighesteducationtitle
				, country.name AS countryname, state.name AS statename, county.name AS countyname, city.name AS cityname
		FROM `#__js_job_jobs` AS job
		JOIN `#__js_job_categories` AS cat ON job.jobcategory = cat.id
		JOIN `#__js_job_companies` AS company ON job.companyid = company.id
		JOIN `#__js_job_jobtypes` AS jobtype ON job.jobtype = jobtype.id
		JOIN `#__js_job_jobstatus` AS jobstatus ON job.jobstatus = jobstatus.id
		LEFT JOIN `#__js_job_salaryrange` AS salary ON job.jobsalaryrange = salary.id
		LEFT JOIN `#__js_job_heighesteducation` AS education ON job.heighestfinisheducation = education.id
		LEFT JOIN `#__js_job_shifts` AS shift ON job.shift = shift.id
		LEFT JOIN `#__js_job_countries` AS country ON job.country = country.code
		LEFT JOIN `#__js_job_states` AS state ON job.state = state.code
		LEFT JOIN `#__js_job_counties` AS county ON job.county = county.code
		LEFT JOIN `#__js_job_cities` AS city ON job.city = city.code
		WHERE  job.id = " . $job_id;
		$db->setQuery($query);
		$this->_application = $db->loadObject();
		$result[0] = $this->_application;
		return $result;
	}

	function &getMyResumes($u_id)
	{
		
		$db = &$this->getDBO();
		if($u_id) if ((is_numeric($u_id) == false) || ($u_id == 0) || ($u_id == '')) return false;
		
		$totalresume = 0;

		$query = "SELECT id, application_title, create_date, status 
		FROM `#__js_job_resume` WHERE status = 1 AND uid = ".$u_id;
		$db->setQuery($query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum()) {
			echo $db->stderr();
			return false;
		}
		$resumes = array();
		foreach($rows as $row)	{
			$resumes[] =  array('value' => $row->id, 'text' => $row->application_title);
			$totalresume++;
		}
		
		$myresymes = JHTML::_('select.genericList', $resumes, 'cvid', 'class="inputbox required" '. '', 'value', 'text', '');

                $mycoverletters = $this->getMyCoverLetters($u_id);
		
		$result[0] = $myresymes;
		$result[1] = $totalresume;
                $result[2] = $mycoverletters[0];
		return $result;
	}

    function &getMyCoverLetters($u_id)
	{

		$db = &$this->getDBO();
		if($u_id) if ((is_numeric($u_id) == false) || ($u_id == 0) || ($u_id == '')) return false;
                
                $totalcoverletters = 0;

		$query = "SELECT id, title
		FROM `#__js_job_coverletters` WHERE uid = ".$u_id;
		$db->setQuery($query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum()) {
			echo $db->stderr();
			return false;
		}
		$resumes = array();
		foreach($rows as $row)	{
			$resumes[] =  array('value' => $row->id, 'text' => $row->title);
			$totalcoverletters++;
		}

		$mycoverletters = JHTML::_('select.genericList', $resumes, 'coverletterid', 'class="inputbox required" '. '', 'value', 'text', '');


		$result[0] = $mycoverletters;
		$result[1] = $totalcoverletters;
		return $result;
	}

	function &getMyAppliedJobs($u_id,$sortby,$limit,$limitstart)
	{
		$db = &$this->getDBO();
		if($u_id) if ((is_numeric($u_id) == false) || ($u_id == 0) || ($u_id == '')) return false;
		$result = array();
		$listjobconfig = $this->getConfigByFor('listjob');

		$query = "SELECT COUNT(job.id) FROM `#__js_job_jobs` AS job, `#__js_job_jobapply` AS apply  
		WHERE apply.jobid = job.id AND apply.uid = ".$u_id;
		$db->setQuery($query);
		$total = $db->loadResult();
		if ( $total <= $limitstart ) $limitstart = 0;

		$query = "SELECT job.*, cat.cat_title, apply.apply_date, jobtype.title AS jobtypetitle, jobstatus.title AS jobstatustitle
				, salaryfrom.rangestart AS salaryfrom, salaryto.rangeend AS salaryto, country.name AS countryname,currency.symbol
				, company.name AS companyname, company.url,salarytype.title AS salarytype
				, state.name AS statename, county.name AS countyname, city.name AS cityname
				, (SELECT COUNT(goldjob.id) FROM `#__js_job_goldjobs` AS goldjob 
					JOIN `#__js_job_employerpackages` AS package ON package.id = goldjob.packageid
					WHERE goldjob.jobid = job.id AND goldjob.status = 1 AND DATE_ADD(goldjob.created,INTERVAL package.goldjobsexpireindays DAY) >= CURDATE() ) AS isgold
				, (SELECT COUNT(featuredjob.id) FROM `#__js_job_featuredjobs` AS featuredjob 
					JOIN `#__js_job_employerpackages` AS package ON package.id = featuredjob.packageid
					WHERE featuredjob.jobid = job.id AND featuredjob.status = 1 AND DATE_ADD(featuredjob.created,INTERVAL package.featuredjobsexpireindays DAY) >= CURDATE() ) AS isfeatured
				FROM `#__js_job_jobs` AS job
				JOIN `#__js_job_jobtypes` AS jobtype ON job.jobtype = jobtype.id 
				JOIN `#__js_job_jobstatus` AS jobstatus ON job.jobstatus = jobstatus.id 
				LEFT JOIN `#__js_job_companies` AS company ON job.companyid = company.id 
				LEFT JOIN `#__js_job_salaryrange` AS salaryfrom ON job.salaryrangefrom = salaryfrom.id 
				LEFT JOIN `#__js_job_salaryrange` AS salaryto ON job.salaryrangeto = salaryto.id 
				LEFT JOIN `#__js_job_salaryrangetypes` AS salarytype ON job.salaryrangetype = salarytype.id
				LEFT JOIN `#__js_job_countries` AS country ON job.country = country.code 
				LEFT JOIN `#__js_job_states` AS state ON job.state = state.code
				LEFT JOIN `#__js_job_counties` AS county ON job.county = county.code
				LEFT JOIN `#__js_job_currencies` AS currency ON job.currencyid = currency.id 
				LEFT JOIN `#__js_job_cities` AS city ON job.city = city.code
				, `#__js_job_categories` AS cat
				, `#__js_job_jobapply` AS apply  
		WHERE job.jobcategory = cat.id AND apply.jobid = job.id AND apply.uid = ".$u_id." ORDER BY  ".$sortby;
                //echo '<br>'.$query;
		$db->setQuery($query, $limitstart, $limit);
		$this->_applications = $db->loadObjectList();

		$result[0] = $this->_applications;
		$result[1] = $total;
		$result[2] = $listjobconfig;
		
		return $result;
	}

	function &getJobsAppliedResume($u_id,$sortby,$limit,$limitstart)
	{
		$db = &$this->getDBO();
		if($u_id) if ((is_numeric($u_id) == false) || ($u_id == 0) || ($u_id == '')) return false;
		$result = array();

		$query = "SELECT COUNT(job.id)
		FROM `#__js_job_jobs` AS job, `#__js_job_categories` AS cat 
		WHERE job.jobcategory = cat.id AND job.uid= ".$u_id;
		$db->setQuery($query);
		$total = $db->loadResult();

		//$limit = $limit ? $limit : 5;
                if ( $total <= $limitstart ) $limitstart = 0;

                $query = "SELECT DISTINCT job.*, cat.cat_title , company.name ,jobtype.title AS jobtypetitle, jobstatus.title AS jobstatustitle
				, (SELECT COUNT(apply.id) FROM `#__js_job_jobapply` AS apply WHERE apply.jobid = job.id ) as appinjob
				FROM `#__js_job_jobs` AS job
				JOIN `#__js_job_categories` AS cat ON job.jobcategory = cat.id
				JOIN `#__js_job_jobtypes` AS jobtype ON job.jobtype = jobtype.id
				JOIN `#__js_job_jobstatus` AS jobstatus ON job.jobstatus = jobstatus.id
				JOIN `#__js_job_companies` AS company ON job.companyid = company.id
			WHERE job.uid= ".$u_id." ORDER BY  ".$sortby;
		$db->setQuery($query, $limitstart, $limit);
		$this->_applications = $db->loadObjectList();

		$result[0] = $this->_applications;
		$result[1] = $total;
		
		return $result;
	}
	function &getShortListCandidate($jobid,$sortby,$limit,$limitstart)
	{
		$db = &$this->getDBO();
		if (is_numeric($jobid) == false) return false;
		$result = array();
		$query = "SELECT COUNT(job.id)
		FROM `#__js_job_jobs` AS job 
		JOIN `#__js_job_shortlistcandidates` AS candidate ON job.id=candidate.jobid  
		JOIN `#__js_job_resume` AS resume ON candidate.cvid = resume.id 
		WHERE  job.id=".$jobid;
		$db->setQuery($query);
		$total = $db->loadResult();
                if ( $total <= $limitstart ) $limitstart = 0;
		/*$query ="SELECT job.id, resume.id AS resumeid, job.title,resume.first_name as firstname,resume.last_name as lastname,candidate.created
			 , (SELECT COUNT(apply.id) FROM `#__js_job_jobapply` AS apply WHERE apply.jobid =". $jobid.") as appliedjob
		FROM `#__js_job_jobs` AS job 
		JOIN `#__js_job_shortlistcandidates` AS candidate ON job.id=candidate.jobid  
		JOIN `#__js_job_resume` AS resume ON candidate.cvid = resume.id 
		WHERE  job.id=".$jobid;
		$db->setQuery($query, $limitstart, $limit);
		$this->_applications = $db->loadObjectList();
		$result[0] = $this->_applications;
		$result[1] = $total;
		return $result;*/
		$query = "SELECT apply.comments,apply.id AS jobapplyid ,job.id,job.agefrom,job.ageto, 
		cat.cat_title ,apply.apply_date, apply.resumeview, jobtype.title AS jobtypetitle,
				app.iamavailable, app.id AS appid, app.first_name, app.last_name, app.email_address, 
				app.jobtype,app.gender	,app.total_experience, app.jobsalaryrange,rating.id AS ratingid, rating.rating
				,app.address_city, app.address_county, app.address_state
				,country.name AS countryname,state.name AS statename
				,county.name AS countyname,city.name AS cityname
				, salary.rangestart, salary.rangeend,education.title AS educationtitle
				FROM `#__js_job_jobs` AS job
				JOIN `#__js_job_shortlistcandidates` AS candidate ON job.id=candidate.jobid
				JOIN `#__js_job_jobtypes` AS jobtype ON job.jobtype = jobtype.id
				JOIN `#__js_job_categories` AS cat ON job.jobcategory = cat.id
				JOIN `#__js_job_jobapply` AS apply  ON candidate.cvid = apply.cvid AND candidate.jobid = apply.jobid
				JOIN `#__js_job_resume` AS app ON apply.cvid = app.id
				LEFT JOIN  `#__js_job_resumerating` AS rating ON (app.id=rating.resumeid AND apply.jobid=rating.jobid)
				LEFT JOIN `#__js_job_heighesteducation` AS  education  ON app.heighestfinisheducation=education.id
				LEFT JOIN  `#__js_job_salaryrange` AS salary	ON	app.jobsalaryrange=salary.id
				LEFT JOIN `#__js_job_countries` AS country ON app.address_country  = country.code
				LEFT JOIN `#__js_job_states` AS state ON app.address_state = state.code
				LEFT JOIN `#__js_job_counties` AS county ON app.address_county  = county.code
				LEFT JOIN `#__js_job_cities` AS city ON app.address_city = city.code

		WHERE apply.jobid = ".$jobid." ORDER BY  ".$sortby;
		$db->setQuery($query, $limitstart, $limit);
		$this->_applications = $db->loadObjectList();

		$result[0] = $this->_applications;
		$result[1] = $total;

		return $result;


        }
	function &getMessagesbyJobs($uid,$limit,$limitstart)
	{
		$result = array();
		$db = &$this->getDBO();

		if (is_numeric($uid) == false) return false;
		if (($uid == 0) || ($uid == '')) return false;
		$total=0;
                $query = "SELECT message.id
                            FROM `#__js_job_messages` AS message
                            JOIN `#__js_job_jobs` AS job ON job.id = message.jobid
                            JOIN `#__js_job_companies` AS company ON company.id = job.companyid
                            WHERE message.employerid = ".$uid."
                            GROUP BY message.jobid
                            ";
		$db->setQuery($query);
		$totobj = $db->loadObjectList();
		foreach ($totobj as $obj) $total++;

		if ( $total <= $limitstart ) $limitstart = 0;

                $query = "SELECT message.id, message.jobid, job.title, job.created, company.id as companyid, company.name as companyname
                            ,(SELECT COUNT(id) FROM `#__js_job_messages` WHERE employerid = ".$uid." AND sendby != ".$uid." AND isread = 0) as unread
                            FROM `#__js_job_messages` AS message
                            JOIN `#__js_job_jobs` AS job ON job.id = message.jobid
                            JOIN `#__js_job_companies` AS company ON company.id = job.companyid
                            WHERE message.employerid = ".$uid."
                            GROUP BY message.jobid
                            ORDER BY message.created DESC ";
               // echo $query;
		$db->setQuery($query, $limitstart, $limit);
		$messages = $db->loadObjectList();
		$result[0] = $messages;
		$result[1] = $total;

		return $result;
	}
	function &getMessagesbyJob($uid,$jobid,$limit,$limitstart)
	{
		$result = array();
		$db = &$this->getDBO();

		if (is_numeric($uid) == false) return false;
		if (($uid == 0) || ($uid == '')) return false;
                $query = "SELECT count(message.id)
                        FROM `#__js_job_messages` AS message
                        JOIN `#__js_job_jobs` AS job ON job.id = message.jobid
                        JOIN `#__js_job_resume` AS resume ON resume.id = message.resumeid
                        WHERE message.employerid = ".$uid." AND message.jobid = ".$jobid."
                        GROUP BY message.jobseekerid";
		$db->setQuery($query);
                //echo $query;
		$msgs = $db->loadObjectList();
                $total = 0;
                foreach ($msgs AS $msg) $total ++;
		if ( $total <= $limitstart ) $limitstart = 0;

                $query = "SELECT message.id, message.jobid, message.resumeid, job.title, job.created, resume.id as resumeidid, resume.application_title, resume.first_name, resume.middle_name, resume.last_name
                        ,(SELECT COUNT(id) FROM `#__js_job_messages` WHERE employerid=".$uid." AND message.jobid = ".$jobid." AND sendby != ".$uid." AND isread = 0 AND resume.id = resumeid) as unread
                        FROM `#__js_job_messages` AS message
                        JOIN `#__js_job_jobs` AS job ON job.id = message.jobid
                        JOIN `#__js_job_resume` AS resume ON resume.id = message.resumeid
                        WHERE message.employerid = ".$uid." AND message.jobid = ".$jobid."
                        GROUP BY message.jobseekerid
                        ORDER BY message.created DESC ";
                //echo $query;
		$db->setQuery($query, $limitstart, $limit);
		$messages = $db->loadObjectList();
		$result[0] = $messages;
		$result[1] = $total;

		return $result;
	}
	function &getMessagesbyJobsforJobSeeker($uid,$limit,$limitstart)
	{
		$result = array();
		$db = &$this->getDBO();

		if (is_numeric($uid) == false) return false;
		if (($uid == 0) || ($uid == '')) return false;
		$total = 0;
			   $query = "SELECT message.id
                            FROM `#__js_job_messages` AS message
                            JOIN `#__js_job_jobs` AS job ON job.id = message.jobid
                            JOIN `#__js_job_companies` AS company ON company.id = job.companyid
                            WHERE message.jobseekerid = ".$uid."
                            GROUP BY message.jobid";
		$db->setQuery($query);
		$totobj = $db->loadObjectList();
		foreach ($totobj as $obj) $total++;

		if ( $total <= $limitstart ) $limitstart = 0;

                $query = "SELECT message.id, message.jobid, message.resumeid, job.title, job.created, company.id as companyid, company.name as companyname
                            ,(SELECT COUNT(id) FROM `#__js_job_messages` WHERE jobseekerid = ".$uid." AND sendby != ".$uid." AND jobid = message.jobid AND isread = 0) as unread
                            FROM `#__js_job_messages` AS message
                            JOIN `#__js_job_jobs` AS job ON job.id = message.jobid
                            JOIN `#__js_job_companies` AS company ON company.id = job.companyid
                            WHERE message.jobseekerid = ".$uid."
                            GROUP BY message.jobid
                            ORDER BY message.created DESC ";
               // echo $query;
		$db->setQuery($query, $limitstart, $limit);
		$messages = $db->loadObjectList();
		$result[0] = $messages;
		$result[1] = $total;

		return $result;
	}
	function &getMessagesbyJobResume($uid,$jobid,$resumeid,$limit,$limitstart)
	{
		$result = array();
		$db = &$this->getDBO();

		if (is_numeric($uid) == false) return false;
		if (($uid == 0) || ($uid == '')) return false;
		if (is_numeric($jobid) == false) return false;
		if (is_numeric($resumeid) == false) return false;
		$listjobconfig = $this->getConfigByFor('listjob');
		$query = "SELECT count(message.id)
                        FROM `#__js_job_messages` AS message
                        WHERE message.status = 1 AND message.jobid =".$jobid." AND message.resumeid = ".$resumeid;
		$db->setQuery($query);
		$total = $db->loadResult();
		if ( $total <= $limitstart ) $limitstart = 0;

                $query = "SELECT message.*, job.title, resume.application_title, resume.first_name, resume.middle_name, resume.last_name
                        FROM `#__js_job_messages` AS message
                                JOIN `#__js_job_jobs` AS job ON job.id = message.jobid
				JOIN `#__js_job_resume` AS resume ON resume.id = message.resumeid
                        WHERE message.status = 1 AND message.jobid =".$jobid." AND message.resumeid = ".$resumeid." ORDER BY  message.created DESC";
                //echo $query;
		$db->setQuery($query, $limitstart, $limit);
		$messages = $db->loadObjectList();
                if ($total > 0) $canadd = true;
                else $canadd = $this->canAddMessage($uid);
                if ($canadd){
                    $query = "SELECT job.id as jobid, job.uid as employerid, job.title, resume.id as resumeid, resume.uid as jobseekerid, resume.application_title, resume.first_name, resume.middle_name, resume.last_name
                                    FROM `#__js_job_jobs` AS job
                                    JOIN `#__js_job_resume` AS resume ON resume.id = ".$resumeid."
                                    WHERE job.id = ".$jobid;
               // echo $query;
                    $db->setQuery($query);
                    $summary = $db->loadObject();
                }
		$result[0] = $messages;
		$result[1] = $total;
		$result[2] = $canadd;
                if(isset($summary))
                $result[3] = $summary;

		return $result;
	}
	function canAddMessage($uid)
	{
		$db = &$this->getDBO();

                $returnvalue = array();
                $packagedetail = array();
                if (($uid == 0) || ($uid == '')){ return false; }
		$query = "SELECT package.id, package.messageallow, package.packageexpireindays, payment.id AS paymentid, payment.created
		FROM `#__js_job_employerpackages` AS package
		JOIN `#__js_job_employerpaymenthistory` AS payment ON payment.packageid = package.id
		WHERE payment.uid = ".$uid."
		AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
		AND payment.transactionverified = 1 AND payment.status = 1";
		$db->setQuery($query);
		$packages = $db->loadObjectList();
		$allow = 0;
		foreach($packages AS $package){
			if($allow == 0){
				if ($package->messageallow == 1){
                                    $allow = true;
                                    return true;
                                }
			}
		}
                return $allow;

        }
	function &getJobAppliedResume($u_id,$jobid,$sortby,$limit,$limitstart)
	{
		
		$db = &$this->getDBO();
		if (is_numeric($u_id) == false) return false;
		if (is_numeric($jobid) == false) return false;
		$result = array();
		$query = "SELECT COUNT(job.id)
		FROM `#__js_job_jobs` AS job
		   , `#__js_job_jobapply` AS apply  
		   , `#__js_job_resume` AS app  
		   , `#__js_job_currencies` AS currency  
		   
		WHERE apply.jobid = job.id AND apply.cvid = app.id AND job.currencyid = currency.id AND apply.jobid = ".$jobid;
		$db->setQuery($query);
		$total = $db->loadResult();

		//$limit = $limit ? $limit : 5;
                if ( $total <= $limitstart ) $limitstart = 0;
		
		$query = "SELECT apply.comments,apply.id AS jobapplyid ,job.id,job.agefrom,job.ageto, cat.cat_title ,apply.apply_date, apply.resumeview, jobtype.title AS jobtypetitle,app.iamavailable
				, app.id AS appid, app.first_name, app.last_name, app.email_address, app.jobtype,app.gender
				, app.total_experience, app.jobsalaryrange,rating.id AS ratingid, rating.rating
				, app.address_city, app.address_county, app.address_state ,app.id as resumeid
				, country.name AS countryname,state.name AS statename
				, county.name AS countyname,city.name AS cityname
				, salary.rangestart, salary.rangeend,education.title AS educationtitle
				, currency.symbol AS symbol 
				FROM `#__js_job_jobs` AS job
				JOIN `#__js_job_jobtypes` AS jobtype ON job.jobtype = jobtype.id
				JOIN `#__js_job_categories` AS cat ON job.jobcategory = cat.id
				JOIN `#__js_job_jobapply` AS apply  ON apply.jobid = job.id 
				JOIN `#__js_job_resume` AS app ON apply.cvid = app.id 
				LEFT JOIN  `#__js_job_resumerating` AS rating ON (app.id=rating.resumeid AND apply.jobid=rating.jobid)
				LEFT JOIN `#__js_job_heighesteducation` AS  education  ON app.heighestfinisheducation=education.id
				LEFT OUTER JOIN  `#__js_job_salaryrange` AS salary	ON	app.jobsalaryrange=salary.id
				LEFT JOIN `#__js_job_countries` AS country ON app.address_country  = country.code
				LEFT JOIN `#__js_job_states` AS state ON app.address_state = state.code
				LEFT JOIN `#__js_job_counties` AS county ON app.address_county  = county.code
				LEFT JOIN `#__js_job_cities` AS city ON app.address_city = city.code
				LEFT JOIN `#__js_job_currencies` AS currency ON currency.id = job.currencyid
				
		WHERE apply.jobid = ".$jobid." ORDER BY  ".$sortby;
		$db->setQuery($query, $limitstart, $limit);
		$this->_applications = $db->loadObjectList();
		
		//get job title
		$query = "SELECT title FROM `#__js_job_jobs` WHERE id = ".$jobid;
		$db->setQuery($query);
		$jobtitle = $db->loadResult();

		$result[0] = $this->_applications;
		$result[1] = $total;
		$result[2] = $jobtitle;
		
		return $result;
	}

	function &getMyResumesbyUid($u_id,$sortby,$limit,$limitstart)
	{
		$db = &$this->getDBO();
		if (is_numeric($u_id) == false) return false;
		$result = array();
                $resumeconfig = $this->getConfigByFor('searchresume');
		$query = "SELECT COUNT(id) FROM `#__js_job_resume` WHERE uid  = ".$u_id;
		$db->setQuery($query);
		$total = $db->loadResult();

		//$limit = $limit ? $limit : 5;
                if ( $total <= $limitstart ) $limitstart = 0;
		
		$query = "SELECT resume.* , category.cat_title, jobtype.title AS jobtypetitle, salary.rangestart, salary.rangeend
					, country.name AS countryname,city.name AS cityname,county.name AS countyname,state.name AS statename
					, currency.symbol		
				, (SELECT COUNT(goldresume.id) FROM `#__js_job_goldresumes` AS goldresume 
					JOIN `#__js_job_jobseekerpackages` AS package ON package.id = goldresume.packageid
					WHERE goldresume.resumeid = resume.id AND goldresume.status = 1 AND DATE_ADD(goldresume.created,INTERVAL package.goldresumeexpireindays DAY) >= CURDATE() ) AS isgold
				, (SELECT COUNT(featuredresume.id) FROM `#__js_job_featuredresumes` AS featuredresume 
					JOIN `#__js_job_jobseekerpackages` AS package ON package.id = featuredresume.packageid
					WHERE featuredresume.resumeid = resume.id AND featuredresume.status = 1 AND DATE_ADD(featuredresume.created,INTERVAL package.freaturedresumeexpireindays DAY) >= CURDATE() ) AS isfeatured
					FROM `#__js_job_resume` AS resume
					JOIN  `#__js_job_categories` AS category ON	resume.job_category = category.id
					JOIN  `#__js_job_salaryrange` AS salary	ON	resume.jobsalaryrange = salary.id
					JOIN  `#__js_job_jobtypes` AS jobtype ON resume.jobtype = jobtype.id
				LEFT JOIN `#__js_job_countries` AS country ON resume.employer_country = country.code
				LEFT JOIN `#__js_job_states` AS state ON resume.employer_state= state.code
				LEFT JOIN `#__js_job_counties` AS county ON resume.employer_county= county.code
				LEFT JOIN `#__js_job_cities` AS city ON resume.employer_city= city.code
				LEFT JOIN `#__js_job_currencies` AS currency ON currency.id= resume.currencyid
					WHERE resume.uid  = ".$u_id ."
					ORDER BY ". $sortby;
		$db->setQuery($query);
		$db->setQuery($query, $limitstart, $limit);
		$this->_applications = $db->loadObjectList();

		$result[0] = $this->_applications;
		$result[1] = $total;
		$result[2] = $resumeconfig;
		
		return $result;
	}
	
	function &getUserType($u_id)
	{
		$db = &$this->getDBO();
		if (is_numeric($u_id) == false) return false;
		$query = "SELECT userrole.*, role.rolefor 
			FROM `#__js_job_userroles` AS userrole
			JOIN `#__js_job_roles` AS role ON userrole.role = role.id
			WHERE  uid  = ".$u_id;
		$db->setQuery($query);
		$result[0] = $db->loadObject();
		
		$usertype = array(
			'0' => array('value' => 1,'text' => JText::_('JS_EMPLOYER')),
			'1' => array('value' => 2,'text' => JText::_('JS_JOB_SEEKER')),);
		
		if (isset($result[0]))
			$lists['usertype'] = JHTML::_('select.genericList', $usertype, 'usertype', 'class="inputbox" '. '', 'value', 'text', $result[0]->rolefor);
		else
			$lists['usertype'] = JHTML::_('select.genericList', $usertype, 'usertype', 'class="inputbox" '. '', 'value', 'text', 1);
		$result[1] = $lists;
		
		return $result;
	}

	function &getResumebyId($id, $u_id)
	{
		$db = &$this->getDBO();
		if (is_numeric($u_id) == false) return false;
		if (($id != '') && ($id != 0)){
			if (is_numeric($id) == false) return false;
			$query = "SELECT * FROM `#__js_job_resume` WHERE id = ". $id ." AND uid  = ".$u_id;
				$db->setQuery($query);
			$this->_application = $db->loadObject();
			$result[0] = $this->_application;
		}
		//$result[2] = $this->getUserFields(3, this->_application->id); // company fields, id  USER FIELD NOT FOR RESUME
		if($u_id == 0)
			$result[3] = $this->getFieldsOrdering(13); // resume fields
		else
			$result[3] = $this->getFieldsOrdering(3); // resume fields
		if ($id){ // not new
			$result[4] = 1;
                        $result[5] = null;
                }else{ // new
                    $returnresult = $this->canAddNewResume($u_id);
                    $result[4] = $returnresult[0];
                    $result[5] = $returnresult[1];
                }

		return $result;
	}
	function getYesNo( $title ){
			$db =& JFactory::getDBO();
			$yesno = array();
			if($title)
				$yesno[] =  array('value' => '','text' => $title);

			$yesno[] =  array('value' => 1,	'text' => 'Yes');
			$yesno[] =  array('value' => 0,	'text' => 'No');
			
		return $yesno;	
	}
	function &getDepartmentbyId($departmentid)
	{
		$db = &$this->getDBO();
		if (is_numeric($departmentid) == false) return false;
		$query = "SELECT department.*,company.name as companyname 
					
		FROM `#__js_job_departments` AS department
		JOIN `#__js_job_companies` AS company ON company.id = department.companyid
		WHERE  department.id = " . $departmentid;
		$db->setQuery($query);
		$department = $db->loadObject();

		
		return $department;
	}

	
	function &getDepartmentByIdForForm($departmentid, $uid){
		$db = &$this->getDBO();

		if (is_numeric($uid) == false) return false;
			if (($departmentid != '') && ($departmentid != 0)){
			if (is_numeric($departmentid) == false) return false;
			$query = "SELECT department.*
			FROM `#__js_job_departments` AS department 
			WHERE department.id = ".$departmentid;
			$db->setQuery($query);
			$department = $db->loadObject();
			
		}
                $companies=$this->getCompanies($uid);

                if ( isset($department) ){
                        $lists['companies'] = JHTML::_('select.genericList', $companies , 'companyid', 'class="inputbox required" '. '', 'value', 'text', $department->companyid);

                }else{
                        $lists['companies'] = JHTML::_('select.genericList', $companies , 'companyid', 'class="inputbox required" '. '', 'value', 'text', '');
                }
		if(isset($department))$result[0] = $department;
		$result[1] = $lists;
		
		return $result;
	}
	
	function storeShortListCandidate($uid)
	{
		global $resumedata;
		$data = JRequest :: get('post');
		if (is_numeric($data['resumeid']) == false) return false;
		if (is_numeric($data['jobid']) == false) return false;
		if (is_numeric($uid) == false) return false;
                if ($this->shortListCandidateValidation($uid,$data['jobid'],$data['resumeid']) == false) return 3;
                $row = &$this->getTable('shortlistcandidate');
                $row->uid = $uid;
                $row->jobid = $data['jobid'];
                $row->cvid = $data['resumeid'];
                $row->status = 0;
                $row->created = date('Y-m-d H:i:s');
		if (!$row->check())	{
			$this->setError($this->_db->getErrorMsg());
			return 2;
		}
		if (!$row->store())	{
			$this->setError($this->_db->getErrorMsg());
			echo $this->_db->getErrorMsg();
			return false;
		}
		return true;
	} 
	function shortListCandidateValidation($uid, $jobid, $resumeid)
	{
		$db =& JFactory::getDBO();
		$query = "SELECT COUNT(id) FROM #__js_job_shortlistcandidates
		WHERE  jobid = ".$jobid." AND cvid = ".$resumeid;
		$db->setQuery( $query );
		$result = $db->loadResult();
		if ($result == 0) return true; else return false;
	}

	function storeMessage($uid)
	{
                $data = JRequest :: get('post');
		if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
                if (is_numeric($data['resumeid']) == false) return false;
		if (is_numeric($data['jobid']) == false) return false;
		if (is_numeric($uid) == false) return false;
                $returnvalue = $this->messageValidation($data['jobid'],$data['resumeid']);
                if ($returnvalue != 1) return $returnvalue;
                
                $config = $this->getConfigByFor('messages');

                $data['status'] = $config['message_auto_approve'];
                $conflict = $this->checkString($data['subject'].$data['message']);
                if ($conflict[0] == false){
                    $data['status'] = $config['conflict_message_auto_approve'];
                    $data['isconflict'] = 1;
                    $data['conflictvalue'] = $conflict[1];
                }
                $row = &$this->getTable('message');
		if (!$row->bind($data)){
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
                $row->sendby = $uid;
		if (!$row->check())	{
			$this->setError($this->_db->getErrorMsg());
			return 2;
		}
		if (!$row->store())	{
			$this->setError($this->_db->getErrorMsg());
			echo $this->_db->getErrorMsg();
			return false;
		}
		$returnvalue = $this->sendMessageEmail($row->id);
                //$this->sendMailtoAdmin($row->id,$data['uid'],7);
                if ($row->status == 1){ if($returnvalue == 1)return true; else return 4;
                }elseif ($row->status == 0) return 2;
	}
	function messageValidation($jobid, $resumeid)
	{

		if ((is_numeric($jobid) == false) ||($jobid == 0) || ($jobid == '')) return false;
		if ((is_numeric($resumeid) == false) ||($resumeid == 0) || ($resumeid == '')) return false;
		$db =& JFactory::getDBO();

		$query = "SELECT resume.uid FROM #__js_job_resume AS resume WHERE resume.id = ".$resumeid;
		$db->setQuery( $query );
		$resume = $db->loadObject();
		if(isset($resume)){
                    if($resume->uid) $returnvalue = 1; else return 5;
                }else return 5;

                $query = "SELECT job.uid FROM #__js_job_jobs AS job WHERE job.id = ".$jobid;
		$db->setQuery( $query );
		$job = $db->loadObject();
		if(isset($job)){
                    if($job->uid) $returnvalue = 1; else return 6;
                }else return 6;

                return $returnvalue;
	}
	function checkString($message)
	{
		//$message = 'This info@al-barr.com is testing message';
		//echo $message;
		$email_pattern = '/[^\x00-\x20()<>@,;:\\".[\]\x7f-\xff]+(?:\.[^\x00-\x20()<>@,;:\\".[\]\x7f-\xff]+)*\@[^\x00-\x20()<>@,;:\\".[\]\x7f-\xff]+(?:\.[^\x00-\x20()<>@,;:\\".[\]\x7f-\xff]+)+/';
		$domain_pattern = '@^(?:http://)?([^/]+)@i';
		$regex = '/(?:1(?:[. -])?)?(?:\((?=\d{3}\)))?([2-9]\d{2})(?:(?<=\(\d{3})\))? ?(?:(?<=\d{3})[.-])?([2-9]\d{2})[. -]?(\d{4})(?: (?i:ext)\.? ?(\d{1,5}))?/';
                $retrun = array();
		preg_match($email_pattern, $message, $email);
		if($email[0] !=''){
			//echo '<br> Email '.$email[0];
                        $return[0] = false;
                        $return[1] = $email[0];
			return $return;
		}

		preg_match($domain_pattern,$message, $matches);
		$host = $matches[1];
		//if ($host != ''){
			//echo '<br> host '.$host;
			// get last two segments of host name
			preg_match('/[^.]+\.[^.]+$/', $host, $matches);
			if ($matches[0] != ''){
				//echo "<br>domain name is: {$matches[0]}\n";
                        $return[0] = false;
                        $return[1] = $matches[0];
			return $return;
			}
		//}

		preg_match($regex, $message, $phone);
		if ($phone[0] != ''){
                        $return[0] = false;
                        $return[1] = $phone[0];
			return $return;
		}
                $return[0] = true;
                return $return;
	}
	function &getCompanyInfoById($companyid) // this may not use
	{
		if (is_numeric($companyid) == false) return false;
	
		$db = &$this->getDBO();
		$query="SELECT company.name
		FROM `#__js_job_companies` AS company
		WHERE company.id = " . $companyid;
		$db->setQuery($query);
		$company = $db->loadObject();
		$query = "SELECT count(featuredjobs.id)
				
		FROM `#__js_job_featuredjobs` AS featuredjobs
		JOIN `#__js_job_jobs` AS job ON featuredjobs.jobid = job.id
		JOIN `#__js_job_companies` AS company ON job.companyid = company.id
		LEFT JOIN `#__js_job_countries` AS country ON job.country = country.code
		LEFT JOIN `#__js_job_cities` AS city ON job.city = city.code
		WHERE  job.companyid = " . $companyid;
		$db->setQuery($query);
		$jobs = $db->loadResult();
		
		$query = "SELECT featuredjobs.*,job.created as jobcreated , job.title,company.name as companyname, country.name AS countryname, city.name AS cityname
				
		FROM `#__js_job_featuredjobs` AS featuredjobs
		JOIN `#__js_job_jobs` AS job ON featuredjobs.jobid = job.id
		JOIN `#__js_job_companies` AS company ON job.companyid = company.id
		LEFT JOIN `#__js_job_countries` AS country ON job.country = country.code
		LEFT JOIN `#__js_job_cities` AS city ON job.city = city.code
		WHERE  job.companyid = " . $companyid;
		$db->setQuery($query);
		$info = $db->loadObjectList();
		$result[0]=$info;
		$result[1]=$jobs;
		$result[2]=$company;
		return $result;
		
		
	}
	
	function &getJobDetails($jobid) // this may not use
	{
		if (is_numeric($jobid) == false) return false;

                $db = &$this->getDBO();

		$query = "SELECT job.*, cat.cat_title , company.name as companyname, jobtype.title AS jobtypetitle
				,  shift.title as shifttitle
				, salaryfrom.rangestart AS salaryfrom, salaryto.rangestart AS salaryto, salarytype.title AS salarytype
				,mineducation.title AS mineducationtitle
				, minexperience.title AS minexperiencetitle,agefrom.title AS agefrom,ageto.title AS ageto
				, country.name AS countryname, city.name AS cityname,careerlevel.title AS careerleveltitle
		FROM `#__js_job_jobs` AS job
		JOIN `#__js_job_categories` AS cat ON job.jobcategory = cat.id
		JOIN `#__js_job_companies` AS company ON job.companyid = company.id
		JOIN `#__js_job_jobtypes` AS jobtype ON job.jobtype = jobtype.id
		LEFT JOIN `#__js_job_salaryrange` AS salaryfrom ON job.salaryrangefrom = salaryfrom.id
		LEFT JOIN `#__js_job_salaryrange` AS salaryto ON job.salaryrangeto = salaryto.id
		LEFT JOIN `#__js_job_salaryrangetypes` AS salarytype ON job.salaryrangetype = salarytype.id
		LEFT JOIN `#__js_job_heighesteducation` AS mineducation ON job.mineducationrange = mineducation.id
		LEFT JOIN `#__js_job_experiences` AS minexperience ON job.minexperiencerange = minexperience.id
		LEFT JOIN `#__js_job_shifts` AS shift ON job.shift = shift.id
		LEFT JOIN `#__js_job_countries` AS country ON job.country = country.code
		LEFT JOIN `#__js_job_cities` AS city ON job.city = city.code
		LEFT JOIN `#__js_job_ages` AS ageto ON job.ageto = ageto.id
		LEFT JOIN `#__js_job_ages` AS agefrom ON job.agefrom = agefrom.id
		LEFT JOIN `#__js_job_careerlevels` AS careerlevel ON job.careerlevel = careerlevel.id
		WHERE  job.id = " . $jobid;
		$db->setQuery($query);
		$details = $db->loadObject();
		
		return $details;
	}
	
	function &getAllForDetails($limit,$limitstart) // may not use this function
	{
		$db = &$this->getDBO();
		$result = array();

		/*$query =  "SELECT COUNT(featuredjob.id)
				FROM `#__js_job_featuredjobs` AS featuredjob 
				JOIN `#__js_job_jobs` AS  job ON job.id=featuredjob.jobid
				LEFT JOIN `#__js_job_companies` AS comapny ON comapny.id=job.companyid ";
		$db->setQuery($query);
		$total = $db->loadResult();

		if ( $total <= $limitstart ) $limitstart = 0;*/

		$query = "SELECT featuredjob.*,job.title,comapny.name,comapny.city
				FROM `#__js_job_featuredjobs` AS featuredjob 
				JOIN `#__js_job_jobs` AS  job ON job.id=featuredjob.jobid
				LEFT JOIN `#__js_job_companies` AS comapny ON comapny.id=job.companyid 
				GROUP BY featuredjob.jobid";
		$db->setQuery($query, $limitstart, $limit);
		$jobs = $db->loadObjectList();
		
		
		
		$query = "SELECT goldjob.*,job.title,comapny.name,comapny.city
				FROM `#__js_job_goldjobs` AS goldjob 
				JOIN `#__js_job_jobs` AS  job ON job.id=goldjob.jobid
				LEFT JOIN `#__js_job_companies` AS comapny ON comapny.id=job.companyid 
				GROUP BY goldjob.jobid";
				
		$db->setQuery($query, $limitstart, $limit);
		$goldjobs = $db->loadObjectList();
		$query = "SELECT featuredcompany.*,comapny.name,comapny.city
				FROM `#__js_job_featuredcompanies` AS featuredcompany 
				JOIN `#__js_job_companies` AS comapny ON comapny.id=featuredcompany.companyid 
				GROUP BY featuredcompany.companyid";
		$db->setQuery($query, $limitstart, $limit);
		$featuredcompanies = $db->loadObjectList();
		
		
		
		$query = "SELECT goldcompany.*,comapny.name,comapny.city
				FROM `#__js_job_goldcompanies` AS goldcompany 
				
				JOIN `#__js_job_companies` AS comapny ON comapny.id=goldcompany.companyid 
				GROUP BY goldcompany.companyid";
				
		$db->setQuery($query, $limitstart, $limit);
		$goldcompanies = $db->loadObjectList();
		
		$result[0] = $jobs;
		$result[1] = $goldjobs;
		$result[2] = $featuredcompanies;
		$result[3] = $goldcompanies;
		
		
		return $result;
	}

// Payment System Start
	
	function storeGoldResume($uid,$resumeid)
	{
		global $resumedata;
		if ((is_numeric($uid) == false) ||($uid == 0) || ($uid == '')) return false;
		if ((is_numeric($resumeid) == false) ||($resumeid == 0) || ($resumeid == '')) return false;
		$db = &$this->getDBO();
		$query = "SELECT COUNT(id)
				FROM `#__js_job_resume` 
				WHERE uid = ".$uid." AND id = ".$resumeid." AND status = 1";
		$db->setQuery( $query );
		$resumes = $db->loadResult();
		if($resumes <= 0) return 3;// company not exsit or not approved
		
		if($this->canAddNewGoldResume($uid) == false) return 5; // can not add new gold resume
		
                $query = "SELECT package.id, package.goldresume
                            , (SELECT COUNT(id) FROM #__js_job_goldresumes WHERE packageid = package.id  AND uid = ".$uid.") AS resumeavail
                            FROM #__js_job_jobseekerpaymenthistory AS payment
                            JOIN #__js_job_jobseekerpackages AS package ON package.id = payment.packageid
                            WHERE payment.uid = ".$uid."
                            AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
                            AND payment.transactionverified = 1 AND payment.status = 1";
                //echo $query;
                $db->setQuery($query);
                $packages = $db->loadObjectList();
                foreach($packages AS $package){
			if($unlimited == 0){
                            if ($package->goldresume != -1){
                                if($package->goldresume > $package->resumeavail){
                                    $packageid = $package->id;
                                }
                            }else{
                                $packageid = $package->id;
                                 $unlimited = 1;
                            }
                        }
                }
		$row = &$this->getTable('goldresume');
		$data = JRequest :: get('post');
		$config = $this->getConfigByFor('goldresume');
                $row->uid = $uid;
                $row->resumeid = $resumeid;
                $row->status = $config['goldresume_autoapprove'];
                $row->packageid =$packageid ;
                $row->created = date('Y-m-d H:i:s');

		if (!$row->check())	{
			$this->setError($this->_db->getErrorMsg());
			return 2;
		}
		if ($data['id'] == ''){ // only for new
			$result=$this->GoldResumeValidation($uid, $resumeid);
			if ($result == false) return 6;
		}
		if (!$row->store())	{
			$this->setError($this->_db->getErrorMsg());
			echo $this->_db->getErrorMsg();
			return false;
		}
		return true;
	} 
	
	function GoldResumeValidation($uid, $resumeid)
	{
		
		if ((is_numeric($uid) == false) ||($uid == 0) || ($uid == '')) return false;
		if ((is_numeric($resumeid) == false) ||($resumeid == 0) || ($resumeid == '')) return false;
		$db =& JFactory::getDBO();
		
		$query = "SELECT COUNT(goldresume.id)  
		FROM #__js_job_goldresumes  AS goldresume
		JOIN #__js_job_jobseekerpackages AS package ON package.id=goldresume.packageid
		WHERE goldresume.uid = ".$uid ." AND goldresume.resumeid = ".$resumeid." 
		AND DATE_ADD(goldresume.created,INTERVAL package.goldresumeexpireindays DAY) >= CURDATE()";
		$db->setQuery( $query );
		$result = $db->loadResult();
		if ($result == 0) return true; else return false;
	}
	
	function canAddNewGoldResume($uid)
	{
		$db = &$this->getDBO();
		
		if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;

		$query = "SELECT package.goldresume, package.packageexpireindays, payment.created
		FROM `#__js_job_jobseekerpackages` AS package
		JOIN `#__js_job_jobseekerpaymenthistory` AS payment ON payment.packageid = package.id
		WHERE payment.uid = ".$uid." 
		AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
		AND payment.transactionverified = 1 AND payment.status = 1";
		$db->setQuery($query);
		$resumes = $db->loadObjectList();
		$unlimited = 0;
		foreach($resumes AS $resume){
			if($unlimited == 0){
				if ($resume->goldresume != -1){
					$goldresume = $goldresume + $resume->goldresume;
				}else $unlimited = 1;
			}	
		}
		if ($unlimited == 0){
        		if ($goldresume == 0) return 0; //can not add new job
			$query = "SELECT COUNT(resume.id) 
			FROM `#__js_job_goldresumes` AS resume
			WHERE resume.uid = ".$uid;
			$db->setQuery($query);
			$totalresumes = $db->loadResult();
			
			if ($goldresume <= $totalresumes) return 0; //can not add new job
			else return 1;
			
		}elseif ($unlimited == 1) return 1; // unlimited
		
		return 0;
	}

	function storeFeaturedResume($uid,$resumeid)
	{
		global $resumedata;
		if ((is_numeric($resumeid) == false) ||($resumeid == 0) || ($resumeid == '')) return false;
		if ((is_numeric($uid) == false) ||($uid == 0) || ($uid == '')) return false;
		$db = &$this->getDBO();
		$query = "SELECT COUNT(id)
				FROM `#__js_job_resume` 
				WHERE uid = ".$uid." AND id = ".$resumeid." AND status = 1";
		$db->setQuery( $query );
		$resumes = $db->loadResult();
		if($resumes <= 0) return 3;// company not exsit or not approved
		
		if($this->canAddNewFeaturedResume($uid) == false) return 5; // can not add new gold comapuny

                $query = "SELECT package.id, package.featuredresume
                            , (SELECT COUNT(id) FROM #__js_job_featuredresumes WHERE packageid = package.id  AND uid = ".$uid.") AS resumeavail
                            FROM #__js_job_jobseekerpaymenthistory AS payment
                            JOIN #__js_job_jobseekerpackages AS package ON package.id = payment.packageid
                            WHERE payment.uid = ".$uid."
                            AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
                            AND payment.transactionverified = 1 AND payment.status = 1";
                $db->setQuery($query);
                $packages = $db->loadObjectList();
                foreach($packages AS $package){
			if($unlimited == 0){
                            if ($package->featuredresume != -1){
                                if($package->featuredresume > $package->resumeavail){
                                    $packageid = $package->id;
                                }
                            }else{
                                $packageid = $package->id;
                                 $unlimited = 1;
                            }
                        }
                }
		$row = &$this->getTable('featuredresume');
		$data = JRequest :: get('post');
		$config = $this->getConfigByFor('featuredresume');

                $row->uid = $uid;
                $row->resumeid = $resumeid;
                $row->status = $config['featuredresume_autoapprove'];
                $row->packageid =$packageid ;
                $row->created = date('Y-m-d H:i:s');
		if (!$row->check())	{
			$this->setError($this->_db->getErrorMsg());
			return 2;
		}
		if ($data['id'] == ''){ // only for new
			$result=$this->featuredResumeValidation($uid, $resumeid);
			if ($result == false) return 6;
		}
		if (!$row->store())	{
			$this->setError($this->_db->getErrorMsg());
			echo $this->_db->getErrorMsg();
			return false;
		}
		return true;
	} 
	
	
	function featuredResumeValidation($uid, $resumeid)
	{
		
		if ((is_numeric($uid) == false) ||($uid == 0) || ($uid == '')) return false;
		if ((is_numeric($resumeid) == false) ||($resumeid == 0) || ($resumeid == '')) return false;

                $db =& JFactory::getDBO();
		
		$query = "SELECT COUNT(featuredresume.id)  
		FROM #__js_job_featuredresumes  AS featuredresume
		JOIN #__js_job_jobseekerpackages AS package ON package.id=featuredresume.packageid
		WHERE featuredresume.uid = ".$uid ." AND featuredresume.resumeid = ".$resumeid." 
		AND DATE_ADD(featuredresume.created,INTERVAL package.freaturedresumeexpireindays DAY) >= CURDATE()";
		$db->setQuery( $query );
		$result = $db->loadResult();
		if ($result == 0) return true; else return false;
	}
	
	function canAddNewFeaturedResume($uid) 
	{
		$db = &$this->getDBO();
		
		if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;

		$query = "SELECT package.id, package.featuredresume, package.packageexpireindays, payment.created
		FROM `#__js_job_jobseekerpackages` AS package
		JOIN `#__js_job_jobseekerpaymenthistory` AS payment ON payment.packageid = package.id
		WHERE payment.uid = ".$uid." 
		AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
		AND payment.transactionverified = 1 AND payment.status = 1";
		$db->setQuery($query);
		$resumes = $db->loadObjectList();
		$unlimited = 0;
		foreach($resumes AS $resume){
			if($unlimited == 0){
				if ($resume->featuredresume != -1){
					$featuredresume = $featuredresume + $resume->featuredresume;
				}else $unlimited = 1;
			}	
		}
		
		if ($unlimited == 0){
		if ($featuredresume == 0) return 0; //can not add new job
		
			$query = "SELECT COUNT(resume.id) 
			FROM `#__js_job_featuredresumes` AS resume
			WHERE resume.uid = ".$uid;
			$db->setQuery($query);
			$totalresumes = $db->loadResult();
			
			if ($featuredresume <= $totalresumes) return 0; //can not add new job
			else return 1;
			
		}elseif ($unlimited == 1) return 1; // unlimited
		return 0;
	}
	
	function storeFeaturedCompany($uid,$companyid)
	{
		global $resumedata;
		if ((is_numeric($companyid) == false) ||($companyid == 0) || ($companyid == '')) return false;
		if ((is_numeric($uid) == false) ||($uid == 0) || ($uid == '')) return false;

                $db = &$this->getDBO();
		$query = "SELECT COUNT(id)
				FROM `#__js_job_companies` 
				WHERE uid = ".$uid." AND id = ".$companyid." AND status = 1";
		$db->setQuery( $query );
		$jobs = $db->loadResult();
		if($jobs <= 0) return 3;// company not exsit or not approved
		
		if($this->canAddNewFeaturedCompany($uid) == false) return 5; // can not add new gold comapuny

                $query = "SELECT package.id, package.featuredcompaines
                            , (SELECT COUNT(id) FROM #__js_job_featuredcompanies WHERE packageid = package.id  AND uid = ".$uid.") AS companyavail
                            FROM #__js_job_employerpaymenthistory AS payment
                            JOIN #__js_job_employerpackages AS package ON package.id = payment.packageid
                            WHERE payment.uid = ".$uid."
                            AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
                            AND payment.transactionverified = 1 AND payment.status = 1";
              $db->setQuery($query);
                $packages = $db->loadObjectList();
                foreach($packages AS $package){
			if($unlimited == 0){
                            if ($package->featuredcompaines != -1){
                                if($package->featuredcompaines > $package->companyavail){
                                    $packageid = $package->id;
                                }
                            }else{
                                $packageid = $package->id;
                                 $unlimited = 1;
                            }
                        }
                }
		$row = &$this->getTable('featuredcompany');
		$data = JRequest :: get('post');
		$config = $this->getConfigByFor('featuredcompany');

                $row->uid = $uid;
                $row->companyid = $companyid;
                $row->status = $config['featuredcompany_autoapprove'];
                $row->packageid = $packageid;
                $row->created = date('Y-m-d H:i:s');
		if (!$row->check())	{
			$this->setError($this->_db->getErrorMsg());
			return 2;
		}
		if ($data['id'] == ''){ // only for new
			$result=$this->featuredCompanyValidation($uid, $companyid);
			if ($result == false) return 6;
		}
		
		if (!$row->store())	{
			$this->setError($this->_db->getErrorMsg());
			echo $this->_db->getErrorMsg();
			return false;
		}
		return true;
	} 
	
	function featuredCompanyValidation($uid, $companyid)
	{
		
		if ((is_numeric($uid) == false) ||($uid == 0) || ($uid == '')) return false;
		if ((is_numeric($companyid) == false) ||($companyid == 0) || ($companyid == '')) return false;

                $db =& JFactory::getDBO();
		
		$query = "SELECT COUNT(featuredcompany.id)  
		FROM #__js_job_featuredcompanies  AS featuredcompany
		JOIN #__js_job_employerpackages AS package ON package.id=featuredcompany.packageid
		WHERE featuredcompany.uid = ".$uid ." AND featuredcompany.companyid = ".$companyid." 
		AND DATE_ADD(featuredcompany.created,INTERVAL package.featuredcompaniesexpireindays DAY) >= CURDATE()";
		$db->setQuery( $query );
		$result = $db->loadResult();
		if ($result == 0) return true; else return false;
	}
	
	function storeGoldCompany($uid, $companyid)
	{
		global $resumedata;
		if ((is_numeric($uid) == false) ||($uid == 0) || ($uid == '')) return false;
		if ((is_numeric($companyid) == false) ||($companyid == 0) || ($companyid == '')) return false;
		$db = &$this->getDBO();
		$query = "SELECT COUNT(id)
				FROM `#__js_job_companies` 
				WHERE uid = ".$uid." AND id = ".$companyid." AND status = 1";
		$db->setQuery( $query );
		$jobs = $db->loadResult();
		if($jobs <= 0) return 3;// company not exsit or not approved
		
		if($this->canAddNewGoldCompany($uid) == false) return 5; // can not add new gold comapuny
		
                $query = "SELECT package.id, package.goldcompanies
                            , (SELECT COUNT(id) FROM #__js_job_goldcompanies WHERE packageid = package.id  AND uid = ".$uid.") AS companyavail
                            FROM #__js_job_employerpaymenthistory AS payment
                            JOIN #__js_job_employerpackages AS package ON package.id = payment.packageid
                            WHERE payment.uid = ".$uid."
                            AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
                            AND payment.transactionverified = 1 AND payment.status = 1";
                $db->setQuery($query);
                $packages = $db->loadObjectList();
                foreach($packages AS $package){
			if($unlimited == 0){
                            if ($package->goldcompanies != -1){
                                if($package->goldcompanies > $package->companyavail){
                                    $packageid = $package->id;
                                }
                            }else{
                                $packageid = $package->id;
                                 $unlimited = 1;
                            }
                        }
                }
		$row = &$this->getTable('goldcompany');
		$data = JRequest :: get('post');
		$config = $this->getConfigByFor('goldcompany');

                $row->uid = $uid;
                $row->companyid = $companyid;
                $row->status = $config['goldcompany_autoapprove'];
                $row->packageid =$packageid;
                $row->created = date('Y-m-d H:i:s');
		if (!$row->check())	{
			$this->setError($this->_db->getErrorMsg());
			return 2;
		}
		if ($data['id'] == ''){ // only for new
			$result=$this->goldCompanyValidation($uid, $companyid);
			echo $uid.$companyid;
			if ($result == false) return 6;
		}
		if (!$row->store())	{
			$this->setError($this->_db->getErrorMsg());
			echo $this->_db->getErrorMsg();
			return false;
		}
		return true;
	} 
	
	
	function goldCompanyValidation($uid, $companyid)
	{
		
		if ((is_numeric($uid) == false) ||($uid == 0) || ($uid == '')) return false;
		if ((is_numeric($companyid) == false) ||($companyid == 0) || ($companyid == '')) return false;

                $db =& JFactory::getDBO();
		
		$query = "SELECT COUNT(gold.id)  
		FROM #__js_job_goldcompanies  AS gold
		JOIN #__js_job_employerpackages AS package ON package.id=gold.packageid
		WHERE gold.uid = ".$uid ." AND gold.companyid = ".$companyid." 
		AND DATE_ADD(gold.created,INTERVAL package.goldcompaniesexpireindays DAY) >= CURDATE()";
		$db->setQuery( $query );
		$result = $db->loadResult();
		if ($result == 0) return true; else return false;
	}
	function storeFeaturedJobs($uid, $jobid)
	{
		global $resumedata;
		if ((is_numeric($uid) == false) ||($uid == 0) || ($uid == '')) return false;
		if ((is_numeric($jobid) == false) ||($jobid == 0) || ($jobid == '')) return false;
		$db = &$this->getDBO();
		$query = "SELECT COUNT(id)
				FROM `#__js_job_jobs` 
				WHERE uid = ".$uid." AND id = ".$jobid." AND status = 1";
		$db->setQuery( $query );
		$jobs = $db->loadResult();
		if($jobs <= 0) return 3;// job not exsit or not approved
		if($this->canAddNewFeaturedJob($uid) == false) return 5;
		
                $query = "SELECT package.id, package.featuredjobs
                            , (SELECT COUNT(id) FROM #__js_job_featuredjobs WHERE packageid = package.id  AND uid = ".$uid.") AS jobavail
                            FROM #__js_job_employerpaymenthistory AS payment
                            JOIN #__js_job_employerpackages AS package ON package.id = payment.packageid
                            WHERE payment.uid = ".$uid."
                            AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
                            AND payment.transactionverified = 1 AND payment.status = 1";
               // echo $query;
                $db->setQuery($query);
                $packages = $db->loadObjectList();
                foreach($packages AS $package){
			if($unlimited == 0){
                            if ($package->featuredjobs != -1){
                                if($package->featuredjobs > $package->jobavail){
                                    $packageid = $package->id;
                                }
                            }else{
                                $packageid = $package->id;
                                 $unlimited = 1;
                            }
                        }
                }
/*
                $query = "SELECT package.id,  payment.created
		FROM `#__js_job_employerpackages` AS package
		JOIN `#__js_job_employerpaymenthistory` AS payment ON payment.packageid = package.id
		WHERE payment.uid = ".$uid." 
		AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE() 
		AND payment.transactionverified = 1";
		//echo $query;
		$db->setQuery($query);
		$packages = $db->loadObjectList();
		$unlimited = 0;
		foreach($packages AS $package){
			if($unlimited == 0){
				if ($package->featuredjobs != -1){
					$packageid = $package->id;
				}else{
					$packageid = $package->id;
					 $unlimited = 1;
				}
			}	
		}
*/
		$row = &$this->getTable('featuredjob');
		$data = JRequest :: get('post');
		$config = $this->getConfigByFor('featuredjob');
			
			$row->uid = $uid;
			$row->jobid = $jobid;
			$row->status = $config['featuredjob_autoapprove'];
  			 $row->created = date('Y-m-d H:i:s');
			 $row->packageid=$packageid;
   			//$row->startdate = ;
			//$row->enddate = ;
			//$row->created = date('Y-m-d H:i:s');
	

		if (!$row->check())	{
			$this->setError($this->_db->getErrorMsg());
			return 2;
		}
		if ($data['id'] == ''){ // only for new
			$result=$this->featuredJobValidation($uid, $jobid);
			if ($result == false)
			{
				return 6;
			}
		}
		
		
		if (!$row->store())	{
			$this->setError($this->_db->getErrorMsg());
			echo $this->_db->getErrorMsg();
			return false;
		}
		return true;
	} 
	
	function featuredJobValidation($uid, $jobid)
	{
		
		if ((is_numeric($uid) == false) ||($uid == 0) || ($uid == '')) return false;
		if ((is_numeric($jobid) == false) ||($jobid == 0) || ($jobid == '')) return false;

                $db =& JFactory::getDBO();
		
		$query = "SELECT COUNT(featuredjob.id)  
		FROM #__js_job_featuredjobs  AS featuredjob
		JOIN #__js_job_employerpackages AS package ON package.id=featuredjob.packageid
		WHERE featuredjob.uid = ".$uid ." AND featuredjob.jobid = ".$jobid." 
		AND DATE_ADD(featuredjob.created,INTERVAL package.featuredjobsexpireindays DAY) >= CURDATE()";
	
		
		$db->setQuery( $query );
		$result = $db->loadResult();
		//echo '<br>r'.$result;
		if ($result == 0)
			return true;
		else
			return false;
			
	}
	
	
	function storeGoldJobs($uid, $jobid)
	{
		
		global $resumedata;
		if ((is_numeric($uid) == false) ||($uid == 0) || ($uid == '')) return false;
		if ((is_numeric($jobid) == false) ||($jobid == 0) || ($jobid == '')) return false;
		$db = &$this->getDBO();
		$query = "SELECT COUNT(id)
				FROM `#__js_job_jobs` 
				WHERE uid = ".$uid." AND id = ".$jobid." AND status = 1";

		$db->setQuery( $query );
		$jobs = $db->loadResult();
		if($jobs <= 0) return 3;// job not exsit or not approved
		
		
		if($this->canAddNewGoldJob($uid) == false) return 5; // can not add new gold job
		
                $query = "SELECT package.id, package.goldjobs
                            , (SELECT COUNT(id) FROM #__js_job_goldjobs WHERE packageid = package.id  AND uid = ".$uid.") AS jobavail
                            FROM #__js_job_employerpaymenthistory AS payment
                            JOIN #__js_job_employerpackages AS package ON package.id = payment.packageid
                            WHERE payment.uid = ".$uid."
                            AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
                            AND payment.transactionverified = 1 AND payment.status = 1";
                //echo $query;
                $db->setQuery($query);
                $packages = $db->loadObjectList();
                foreach($packages AS $package){
			if($unlimited == 0){
                            if ($package->goldjobs != -1){
                                if($package->goldjobs > $package->jobavail){
                                    $packageid = $package->id;
                                }
                            }else{
                                $packageid = $package->id;
                                 $unlimited = 1;
                            }
                        }
                }
                /*
		$query = "SELECT package.id,  payment.created
		FROM `#__js_job_employerpackages` AS package
		JOIN `#__js_job_employerpaymenthistory` AS payment ON payment.packageid = package.id
		WHERE payment.uid = ".$uid." 
		AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE() 
		AND payment.transactionverified = 1";
		//echo $query;
		$db->setQuery($query);
		$packages = $db->loadObjectList();
		$unlimited = 0;
		foreach($packages AS $package){
			if($unlimited == 0){
				if ($package->goldjobs != -1){
					$packageid = $package->id;
				}else{
					$packageid = $package->id;
					 $unlimited = 1;
				}
			}	
		}
		*/
		$row = &$this->getTable('goldjob');
		$data = JRequest :: get('post');
		$config = $this->getConfigByFor('goldjob');
			
			$row->uid = $uid;
			$row->jobid = $jobid;
			$row->status = $config['goldjob_autoapprove'];
  			 $row->created = date('Y-m-d H:i:s');
			 $row->packageid=$packageid;
   			//$row->startdate = ;
			//$row->enddate = ;
			//$row->created = date('Y-m-d H:i:s');
	

		if (!$row->check())	{
			$this->setError($this->_db->getErrorMsg());
			return 2;
		}
		
		if ($data['id'] == ''){ // only for new
			$result=$this->goldJobValidation($uid, $jobid);
			if ($result == false)
			{
				return 6;
			}
		}
		
		
		if (!$row->store())	{
			$this->setError($this->_db->getErrorMsg());
			echo $this->_db->getErrorMsg();
			return false;
		}
		return true;
	} 
	
	function goldJobValidation($uid, $jobid)
	{
		
		if ((is_numeric($uid) == false) ||($uid == 0) || ($uid == '')) return false;
		if ((is_numeric($jobid) == false) ||($jobid == 0) || ($jobid == '')) return false;

                $db =& JFactory::getDBO();
		
		$query = "SELECT COUNT(goldjob.id)  
		FROM #__js_job_goldjobs  AS goldjob
		JOIN #__js_job_employerpackages AS package ON package.id=goldjob.packageid
		WHERE goldjob.uid = ".$uid ." AND goldjob.jobid = ".$jobid." 
		AND DATE_ADD(goldjob.created,INTERVAL package.goldjobsexpireindays DAY) >= CURDATE()";
	
		
		$db->setQuery( $query );
		$result = $db->loadResult();
		//echo '<br>r'.$result;
		if ($result == 0)
			return true;
		else
			return false;
			
	}
	
	
	function &getJobSeekerPackages($limit,$limitstart)
	{
		$db = &$this->getDBO();
		$result = array();

		$query = "SELECT COUNT(id) FROM `#__js_job_jobseekerpackages` WHERE status = 1";
		$db->setQuery($query);
		$total = $db->loadResult();

		if ( $total <= $limitstart ) $limitstart = 0;

		$query = "SELECT package.* FROM `#__js_job_jobseekerpackages` AS package WHERE status = 1";
		$db->setQuery($query, $limitstart, $limit);
		$packages = $db->loadObjectList();

		$result[0] = $packages;
		$result[1] = $total;
		
		return $result;
	}

	
	function &getJobSeekerPackageById($packageid)
	{
		if (is_numeric($packageid) == false) return false;
	
		$db = &$this->getDBO();
		


		$query = "SELECT package.* FROM `#__js_job_jobseekerpackages` AS package WHERE id = ".$packageid;
		$db->setQuery($query);
		$package = $db->loadObject();
		
		return $package;
	}
	
	function storeJobSeekerPackageHistory($referenceid,$autoassign,$data)
	{
		global $resumedata;
		$row = &$this->getTable('jobseekerpaymenthistory');

                if ($autoassign == 0) $data = JRequest :: get('post'); // get data from form
		
		if (is_numeric($data['packageid']) == false) return false;
		if (is_numeric($data['uid']) == false) return false;
		$db = &$this->getDBO();
		$result = array();


		$query = "SELECT package.* FROM `#__js_job_jobseekerpackages` AS package WHERE id = ".$data['packageid'];
		//echo $query.'<br/>';
		$db->setQuery($query);
		$package = $db->loadObject();
		if(isset($package)){
			$packageconfig = $this->getConfigByFor('package');
                        $row->uid = $data['uid'];
			$row->packageid = $package->id;
			$row->packagetitle = $package->title;
			$row->packageprice = $package->price;
                        $paidamount = $package->price;
                        $discountamount = 0;

                        if ($package->price != 0){
                           $curdate = date('Y-m-d H:i:s');
                            if (($package->discountstartdate <= $curdate) && ($package->discountenddate >= $curdate)){
                                 if($package->discounttype == 1){ //%
                                     $discountamount = ($package->price * $package->discount)/100;
                                      $paidamount = $package->price - $discountamount;
                                 }else{ // amount
                                     $discountamount = $package->discount;
                                     $paidamount = $package->price - $package->discount;
                                 }
                            }
                            $row->transactionverified = 0;
                            $row->transactionautoverified = 0;
                            $row->status = 1;
                        }else{
                            if($packageconfig['onlyonce_jobseeker_getfreepackage'] == '1'){ // can't get free package more then once
                                $query = "SELECT COUNT(package.id) FROM `#__js_job_jobseekerpackages` AS package
                                    JOIN `#__js_job_jobseekerpaymenthistory` AS payment ON payment.packageid = package.id
                                    WHERE package.price = 0 AND payment.uid = ".$data['uid'];
                                //echo $query.'<br/>';
                                $db->setQuery($query);
                                $freepackage = $db->loadResult();
                                if($freepackage > 0) return 5;// can't get free package more then once
                            }
                            $row->transactionverified = 1;
                            $row->transactionautoverified = 1;
                            $row->status = $packageconfig['jobseeker_freepackage_autoapprove'];
                        }
			$row->discountamount = $discountamount;
			$row->paidamount = $paidamount;

                        $row->discountmessage = $package->discountmessage;
			$row->packagestartdate = $package->discountstartdate;
			$row->packageenddate = $package->discountenddate;
			$row->resumeallow = $package->resumeallow;
			$row->coverlettersallow = $package->coverlettersallow;
			$row->applyjobs = $package->applyjobs;
			$row->jobsearch = $package->jobsearch;
			$row->savejobsearch = $package->savejobsearch;
			$row->featuredresume = $package->featuredresume;
			$row->goldresume = $package->goldresume;
			$row->video = $package->video;
			$row->packageexpireindays = $package->packageexpireindays;
			$row->packageshortdetails = $package->shortdetails;
			$row->packagedescription = $package->description;
			$row->created = date('Y-m-d H:i:s');
                        $row->referenceid = $referenceid;
		}else{ 
                    return false;
                }

		if (!$row->check())	{
			$this->setError($this->_db->getErrorMsg());
			return 2;
		}
		if (!$row->store())	{
			$this->setError($this->_db->getErrorMsg());
			echo $this->_db->getErrorMsg();
			return false;
		}
                 $this->sendMailtoAdmin($row->id,$data['uid'],7);
		return true;
	} 
	
	function &getEmployerPackages($limit,$limitstart)
	{
		$db = &$this->getDBO();
		$result = array();

		$query = "SELECT COUNT(id) FROM `#__js_job_employerpackages` WHERE status = 1";
		$db->setQuery($query);
		$total = $db->loadResult();

		if ( $total <= $limitstart ) $limitstart = 0;

		$query = "SELECT package.* FROM `#__js_job_employerpackages` AS package WHERE status = 1";
		$db->setQuery($query, $limitstart, $limit);
		$packages = $db->loadObjectList();

		$result[0] = $packages;
		$result[1] = $total;
		
		return $result;
	}

	function &getEmployerPackageById($packageid,$uid)
	{
		if (is_numeric($packageid) == false) return false;
		if($uid) if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
		$db = &$this->getDBO();
		$result = array();


		$query = "SELECT package.* FROM `#__js_job_employerpackages` AS package WHERE id = ".$packageid;
		$db->setQuery($query);
		$package = $db->loadObject();
		$lists = '';
		$payment_multicompanies = '' ;

		
		if(! isset($this->_config)){
			$this->getConfig('payment');
		}	
		
		foreach ($this->_config as $conf){
			if ($conf->configname == 'payment_multicompanies')
					$payment_multicompanies = $conf->configvalue;
		}
		//echo '<br> SQL '.$payment_multicompanies;
		if($payment_multicompanies == '0')
		{
			$companies = $this->getCompanies($uid);
			$lists['companies'] = JHTML::_('select.genericList', $companies , 'companyid', 'class="inputbox required" '. '', 'value', 'text', '');	
		}
		$result[0] = $package;
		$result[1] = $payment_multicompanies;
		$result[2] = $lists;
		
		
		return $result;
	}
	
	function &getEmployerPackageInfoById($packageid)
	{
		if (is_numeric($packageid) == false) return false;
		$db = &$this->getDBO();


		$query = "SELECT package.* FROM `#__js_job_employerpackages` AS package WHERE id = ".$packageid;
		$db->setQuery($query);
		$package = $db->loadObject();

		return $package;
	}
	
	function &getJobSeekerPackageInfoById($packageid)
	{
		if (is_numeric($packageid) == false) return false;
		$db = &$this->getDBO();


		$query = "SELECT package.* FROM `#__js_job_jobseekerpackages` AS package WHERE id = ".$packageid;
		$db->setQuery($query);
		$package = $db->loadObject();

		return $package;
	}
	
	
	function storeEmployerPackageHistory($referenceid,$autoassign,$data)
	{
		$row = &$this->getTable('employerpaymenthistory');

                if ($autoassign == 0) $data = JRequest :: get('post'); // get data from form

                if (is_numeric($data['packageid']) == false) return false;
		if (is_numeric($data['uid']) == false) return false;
		$db = &$this->getDBO();
		$result = array();


		$query = "SELECT package.* FROM `#__js_job_employerpackages` AS package WHERE id = ".$data['packageid'];
		//echo $query.'<br/>';
		$db->setQuery($query);
		$package = $db->loadObject();
		if(isset($package)){
			$packageconfig = $this->getConfigByFor('package');
			$row->uid = $data['uid'];
			$row->companyid = $data['companyid'];
			$row->packageid = $data['packageid'];
			
			$row->packagetitle = $package->title;
			$row->packageprice = $package->price;
                        $paidamount = $package->price;
                        $discountamount = 0;

                        if ($package->price != 0){
                           $curdate = date('Y-m-d H:i:s');
                            if (($package->discountstartdate <= $curdate) && ($package->discountenddate >= $curdate)){
                                 if($package->discounttype == 1){ //%
                                     $discountamount = ($package->price * $package->discount)/100;
                                      $paidamount = $package->price - $discountamount;
                                 }else{ // amount
                                     $discountamount = $package->discount;
                                     $paidamount = $package->price - $package->discount;
                                 }
                            }
                            $row->transactionverified = 0;
                            $row->transactionautoverified = 0;
                            $row->status = 1;
                        }else{ //free
                            if($packageconfig['onlyonce_employer_getfreepackage'] == '1'){ // can't get free package more then once
                                $query = "SELECT COUNT(package.id) FROM `#__js_job_employerpackages` AS package
                                    JOIN `#__js_job_employerpaymenthistory` AS payment ON payment.packageid = package.id
                                    WHERE package.price = 0 AND payment.uid = ".$data['uid'];
                                //echo $query.'<br/>';
                                $db->setQuery($query);
                                $freepackage = $db->loadResult();
                                if($freepackage > 0) return 5;// can't get free package more then once
                            }
                            $row->transactionverified = 1;
                            $row->transactionautoverified = 1;
                            $row->status = $packageconfig['employer_freepackage_autoapprove'];
                        }
			$row->discountamount = $discountamount;
			$row->paidamount = $paidamount;
			$row->discountmessage = $package->discountmessage;
			$row->packagediscountstartdate = $package->discountstartdate;
			$row->packagediscountenddate = $package->discountenddate;
			$row->companiesallow = $package->companiesallow;
			$row->jobsallow = $package->jobsallow;
			$row->viewresumeindetails = $package->viewresumeindetails;
			$row->resumesearch = $package->resumesearch;
			$row->saveresumesearch = $package->saveresumesearch;
			$row->featuredcompanies = $package->featuredcompaines;
			$row->goldcompanies = $package->goldcompanies;
			$row->featuredjobs = $package->featuredjobs;
			$row->goldjobs = $package->goldjobs;
			//$row->candidateshortlist = $package->jobseekershortlist;
			$row->video = $package->video;
			$row->map = $package->map;
			$row->packageexpireindays = $package->packageexpireindays;
			$row->packageshortdetails = $package->shortdetails;
			$row->packagedescription = $package->description;
			$row->created = date('Y-m-d H:i:s');
                        $row->referenceid = $referenceid;
		}else{ 
                    return false;
                }

		if (!$row->check())	{
			$this->setError($this->_db->getErrorMsg());
			return 2;
		}
		if (!$row->store())	{
			$this->setError($this->_db->getErrorMsg());
			echo $this->_db->getErrorMsg();
			return false;
		}
                 $this->sendMailtoAdmin($row->id,$data['uid'],6);
		return true;
	} 

        function updateEmployerPackageHistory($firstname,$lastname, $email, $amount, $referenceid
                    , $tx_token, $date, $paypalstatus,$status)
	{
		$db = &$this->getDBO();

                $query = "UPDATE `#__js_job_employerpaymenthistory`
                    SET payer_firstname = ".$db->quote($firstname)."
                    , payer_lastname = ".$db->quote($lastname)."
                    , payer_email = ".$db->quote($email)."
                    , payer_amount = ".$amount."    
                    , payer_tx_token = ".$db->quote($tx_token)."
                    , transactionverified = ".$status."
                    , transactionautoverified = 1
                    , verifieddate = ".$db->quote($date)."
                    , payer_status = ".$db->quote($paypalstatus)."
                    WHERE referenceid = ".$db->quote($referenceid);
               
                $db->setQuery( $query );
                $db->query();

		return true;
	}
        function updateJobSeekerPackageHistory($firstname,$lastname, $email, $amount, $referenceid
                    , $tx_token, $date, $paypalstatus,$status)
	{
		$db = &$this->getDBO();

                $query = "UPDATE `#__js_job_jobseekerpaymenthistory`
                    SET payer_firstname = ".$db->quote($firstname)."
                    , payer_lastname = ".$db->quote($lastname)."
                    , payer_email = ".$db->quote($email)."
                    , payer_amount = ".$amount."
                    , payer_tx_token = ".$db->quote($tx_token)."
                    , transactionverified = ".$status."
                    , transactionautoverified = 1
                    , verifieddate = ".$db->quote($date)."
                    , payer_status = ".$db->quote($paypalstatus)."
                    WHERE referenceid = ".$db->quote($referenceid);
               
                $db->setQuery( $query );
                $db->query();

		return true;
	}

        function &getEmployerPurchaseHistory($uid,$limit,$limitstart)
	{
		if($uid) if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
                
		$db = &$this->getDBO();
		$result = array();

		$query = "SELECT COUNT(id) FROM `#__js_job_employerpaymenthistory` WHERE uid = ".$uid." AND status = 1";
		$db->setQuery($query);
		$total = $db->loadResult();

		if ( $total <= $limitstart ) $limitstart = 0;

		$query = "SELECT purchase.paidamount, purchase.transactionverified,purchase.created
                            ,package.id, package.title,package.companiesallow, package.jobsallow, package.packageexpireindays
                            FROM `#__js_job_employerpaymenthistory` AS purchase
                            JOIN `#__js_job_employerpackages` AS package ON package.id = purchase.packageid
                            WHERE uid = ".$uid." AND purchase.status = 1 ORDER BY purchase.created DESC";
		$db->setQuery($query, $limitstart, $limit);
		$packages = $db->loadObjectList();

		$result[0] = $packages;
		$result[1] = $total;
		
		return $result;
	}
	function &getJobSeekerPurchaseHistory($uid,$limit,$limitstart)
	{
		if($uid) if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
		$db = &$this->getDBO();
		$result = array();

		$query = "SELECT COUNT(id) FROM `#__js_job_jobseekerpaymenthistory` WHERE uid = ".$uid." AND status = 1";;
		$db->setQuery($query);
		$total = $db->loadResult();

		if ( $total <= $limitstart ) $limitstart = 0;

		$query = "SELECT purchase.paidamount,purchase.transactionverified,purchase.created,
						package.id,package.title,package.resumeallow,package.coverlettersallow,package.packageexpireindays
						FROM `#__js_job_jobseekerpaymenthistory` AS purchase 
						JOIN `#__js_job_jobseekerpackages` AS package ON package.id = purchase.packageid
       					WHERE uid = ".$uid." AND purchase.status = 1 ORDER BY purchase.created DESC ";
		$db->setQuery($query, $limitstart, $limit);
		$packages = $db->loadObjectList();

		$result[0] = $packages;
		$result[1] = $total;
		
		return $result;
	}

        //Payment system end
	
	function storeDepartment()
	{
		global $resumedata;
		$row = &$this->getTable('department');
		$data = JRequest :: get('post');


		if ($data['id'] == '') { // only for new 
                    $config = $this->getConfigByFor('department');
                    $data['status'] = $config['department_auto_approve'];
		}
		if (!$row->bind($data)){
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		if (!$row->check())	{
			$this->setError($this->_db->getErrorMsg());
			return 2;
		}
		if (!$row->store())	{
			$this->setError($this->_db->getErrorMsg());
			echo $this->_db->getErrorMsg();
			return false;
		}
		if ($data['id'] == '') $this->sendMailtoAdmin($row->id,$data['uid'],5); //only for new
                return true;
	}
	
	
	
	function &getCoverLetterbyId($id, $u_id)
	{
		$db = &$this->getDBO();
		if($u_id) if($u_id)if ((is_numeric($u_id) == false) || ($u_id == 0) || ($u_id == '')) return false;
		
		if (($id != '') && ($id != 0)){
			if (is_numeric($id) == false) return false;
			$query = "SELECT * FROM `#__js_job_coverletters` WHERE id = ". $id;
				$db->setQuery($query);
			$this->_application = $db->loadObject();
			$result[0] = $this->_application;
		}
		if ($id) // not new
			$result[4] = 1;
		else // new
			if (isset($u_id)) {
				if (is_numeric($u_id) == false) return false;
				$canaddreturnvalue = $this->canAddNewCoverLetter($u_id);
                                $result[4] = $canaddreturnvalue[0];
                                $result[5] = $canaddreturnvalue[1];
			}	
		return $result;
	}

	function &getMyCoverLettersbyUid($u_id,$limit,$limitstart)
	{
		$db = &$this->getDBO();
		if ((is_numeric($u_id) == false) || ($u_id == 0) || ($u_id == '')) return false;
		$result = array();
		$query = "SELECT COUNT(id) FROM `#__js_job_coverletters` WHERE uid  = ".$u_id;
		$db->setQuery($query);
		$total = $db->loadResult();

		//$limit = $limit ? $limit : 5;
                if ( $total <= $limitstart ) $limitstart = 0;
		
		$query = "SELECT letter.* 
					FROM `#__js_job_coverletters` AS letter
					WHERE letter.uid  = ".$u_id ;
		$db->setQuery($query);
		$db->setQuery($query, $limitstart, $limit);

		$result[0] = $db->loadObjectList();
		$result[1] = $total;
		
		return $result;
	}
	
	function &getMyJobSearchesbyUid($u_id,$limit,$limitstart)
	{
		if ((is_numeric($u_id) == false) || ($u_id == 0) || ($u_id == '')) return false;
		$db = &$this->getDBO();
		$result = array();
		$query = "SELECT COUNT(id) FROM `#__js_job_jobsearches` WHERE uid  = ".$u_id;
		$db->setQuery($query);
		$total = $db->loadResult();

		//$limit = $limit ? $limit : 5;
                if ( $total <= $limitstart ) $limitstart = 0;
		
		$query = "SELECT search.* 
					FROM `#__js_job_jobsearches` AS search
					WHERE search.uid  = ".$u_id ;
		$db->setQuery($query);
		$db->setQuery($query, $limitstart, $limit);

		$result[0] = $db->loadObjectList();
		$result[1] = $total;
		
		return $result;
	}
	
	function &getMyResumeSearchesbyUid($u_id,$limit,$limitstart)
	{
		$db = &$this->getDBO();
		if ((is_numeric($u_id) == false) || ($u_id == 0) || ($u_id == '')) return false;
		$result = array();
		$query = "SELECT COUNT(id) FROM `#__js_job_resumesearches` WHERE uid  = ".$u_id;
		$db->setQuery($query);
		$total = $db->loadResult();

		//$limit = $limit ? $limit : 5;
                if ( $total <= $limitstart ) $limitstart = 0;
		
		$query = "SELECT search.* 
					FROM `#__js_job_resumesearches` AS search
					WHERE search.uid  = ".$u_id ;
		$db->setQuery($query);
		$db->setQuery($query, $limitstart, $limit);

		$result[0] = $db->loadObjectList();
		$result[1] = $total;
		
		return $result;
	}
	
	function &getJobSearchebyId($id)
	{
		$db = &$this->getDBO();
		if (is_numeric($id) == false) return false;
		$query = "SELECT search.* 
					FROM `#__js_job_jobsearches` AS search
					WHERE search.id  = ".$id ;
		$db->setQuery($query);
		return $db->loadObject();
	}
	
	function &getResumeSearchebyId($id)
	{
		$db = &$this->getDBO();
		if (is_numeric($id) == false) return false;
		$query = "SELECT search.* 
					FROM `#__js_job_resumesearches` AS search
					WHERE search.id  = ".$id ;
		$db->setQuery($query);
		return $db->loadObject();
	}
	
	
/* this fuction not in use	
	function &getEmpApplicationbyuid($u_id)
	{
		$db = &$this->getDBO();
		$query = "SELECT * FROM `#__js_job_resume` WHERE uid  = ".$u_id;
		echo '<br> sql '.$query;
		$db->setQuery($query);
		$this->_application = $db->loadObject();
		$result[0] = $this->_application;
		//$result[2] = $this->getUserFields(3, this->_application->id); // company fields, id  USER FIELD NOT FOR RESUME
		$result[3] = $this->getFieldsOrdering(3); // resume fields
		return $result;
	}
*/	
	function storeNewinJSJobs()
	{
		global $resumedata;
		$row = &$this->getTable('userrole');
		$data = JRequest :: get('post');
		
		if ($data['id']) return false; // can not edit

		$configs = $this->getConfigByFor('package');
                if ($data['usertype'] == 1) { //employer
                    if($configs['employer_defaultpackage']){ // add this employer package
                        $packagedata['packageid'] = $configs['employer_defaultpackage'];
                        $packagedata['uid'] = $data['uid'];
                        $this->storeEmployerPackageHistory('',1,$packagedata);
                    }
                }else { // job seeker
                    if($configs['jobseeker_defaultpackage']){ // add this jobsseker package
                        $packagedata['packageid'] = $configs['jobseeker_defaultpackage'];
                        $packagedata['uid'] = $data['uid'];
                        $this->storeJobSeekerPackageHistory('',1,$packagedata);
                    }
                }
		
		$data['role'] = $data['usertype'];
		if (!$row->bind($data)){
			$this->setError($this->_db->getErrorMsg());
                        echo $this->_db->getErrorMsg();
			return false;
		}
		if (!$row->check())	{
			$this->setError($this->_db->getErrorMsg());
                        echo $this->_db->getErrorMsg();
			return 2;
		}
		if (!$row->store())	{

			$this->setError($this->_db->getErrorMsg());
                        echo $this->_db->getErrorMsg();
			return false;
		}
		return true;
	}

	function assignDefaultPackage($usertype, $uid){ // this function call from register plugin
		if (is_numeric($uid) == false) return false;
		$db = &$this->getDBO();

		$packageconfig = $this->getConfigByFor('package');
		if ($usertype == 1) { //employer
			if($packageconfig['employer_defaultpackage']){ // add this employer package
				$packageid = $packageconfig['employer_defaultpackage'];

				$query = "SELECT package.* FROM `#__js_job_employerpackages` AS package WHERE id = ".$packageid;
				$db->setQuery($query);
				$package = $db->loadObject();
				if(isset($package)){
					$paidamount = $package->price;

					if($packageconfig['onlyonce_employer_getfreepackage'] == '1'){ // can't get free package more then once
						$query = "SELECT COUNT(package.id) FROM `#__js_job_employerpackages` AS package
							JOIN `#__js_job_employerpaymenthistory` AS payment ON payment.packageid = package.id
							WHERE package.price = 0 AND payment.uid = ".$uid;
						$db->setQuery($query);
						$freepackage = $db->loadResult();
						if($freepackage > 0) return 5;// can't get free package more then once
					}
					$query = 'INSERT INTO `#__js_job_employerpaymenthistory` 
					(uid,packageid,packagetitle,packageprice,transactionverified,transactionautoverified,status,discountamount,paidamount,created)
					VALUES('.$uid.','. $packageid.','.$db->quote($package->title).','.$package->price.',1,1,1,0,'.$paidamount.',now())';
					$db->setQuery( $query );
					$db->query();

					$query = 'SELECT MAX(id) FROM `#__js_job_employerpaymenthistory`';
					$db->setQuery( $query );
					$maxid = $db->loadResult();

					$this->sendMailtoAdmin($maxid,$uid,6);
                }
			}
		}else { // job seeker
			if($packageconfig['jobseeker_defaultpackage']){ // add this jobsseker package
				$packageid = $packageconfig['jobseeker_defaultpackage'];
				$query = "SELECT package.* FROM `#__js_job_jobseekerpackages` AS package WHERE id = ".$packageid;
				$db->setQuery($query);
				$package = $db->loadObject();
				if(isset($package)){
					$paidamount = $package->price;

					if($packageconfig['onlyonce_jobseeker_getfreepackage'] == '1'){ // can't get free package more then once
						$query = "SELECT COUNT(package.id) FROM `#__js_job_jobseekerpackages` AS package
							JOIN `#__js_job_jobseekerpaymenthistory` AS payment ON payment.packageid = package.id
							WHERE package.price = 0 AND payment.uid = ".$uid;
						//echo $query.'<br/>';
						$db->setQuery($query);
						$freepackage = $db->loadResult();
						if($freepackage > 0) return 5;// can't get free package more then once
					}
					$query = 'INSERT INTO `#__js_job_jobseekerpaymenthistory` 
					(uid,packageid,packagetitle,packageprice,transactionverified,transactionautoverified,status,discountamount,paidamount,created)
					VALUES('.$uid.','. $packageid.','.$db->quote($package->title).','.$package->price.',1,1,1,0,'.$paidamount.',now())';
					$db->setQuery( $query );
					$db->query();
					$query = 'SELECT MAX(id) FROM `#__js_job_jobseekerpaymenthistory`';
					$db->setQuery( $query );
					$maxid = $db->loadResult();

					$this->sendMailtoAdmin($maxid,$uid,7);
				}	
			}
		}
		
		return true;
	}

	function &getCurUserAllow($u_id)
	{
		
		if($u_id) if ((is_numeric($u_id) == false) || ($u_id == 0) || ($u_id == '')) return false;
		$db = &$this->getDBO();

		$query = "SELECT * FROM `#__js_job_userallow` WHERE uid= ".$db->Quote($u_id);
		$db->setQuery($query);
		$this->_application = $db->loadObject();
		
		return $this->_application;
	}

	function &getUserRole($u_id)
	{
		if ((is_numeric($u_id) == false) || ($u_id == 0) || ($u_id == '')) return $false;
		$db = &$this->getDBO();
		if ($u_id != 0){

			$query = "SELECT userrole.*, role.* 
					FROM `#__js_job_userroles` AS userrole
					JOIN  `#__js_job_roles` AS role ON	userrole.role = role.id
					WHERE userrole.uid  = ".$u_id;
				$db->setQuery($query);
			$role = $db->loadObject();
		}	
		return $role;
	}

	function &getUserFilter($u_id)
	{
		if($u_id) if ((is_numeric($u_id) == false) || ($u_id == 0) || ($u_id == '')) return false;
		$db = &$this->getDBO();

		$query = "SELECT filter.*
				FROM `#__js_job_filters` AS filter
				WHERE filter.uid  = ".$u_id;
		$db->setQuery($query);
		$userfields = $db->loadObject();
		return $userfields;
	}

	function &getConfig($configfor)
	{
		if (isset($this->_config ) == false){
			$db = &$this->getDBO();

			if($configfor){
				$query = "SELECT * FROM `#__js_job_config` WHERE configfor = ".$db->quote($configfor);
				$db->setQuery($query);
				$this->_config = $db->loadObjectList();
			}else{
				$query = "SELECT * FROM `#__js_job_config` WHERE configfor = 'default'" ;
				$db->setQuery($query);
                               // echo '<br>sql '.$query;
				$this->_config = $db->loadObjectList();
				$ct = $this->_ptr."ost\b/";
				$result = $this->getCurU();
				$cu = $result[2];
				$cvalue = $result[0];
				$evalue = $result[1];
				foreach($this->_config as $conf)
				{
					if ($conf->configname == "defaultcountry")
						$this->_defaultcountry = $conf->configvalue;
					elseif ($conf->configname == "job_editor")
						$this->_job_editor = $conf->configvalue;
					elseif ($conf->configname == "comp_editor")
						$this->_comp_editor = $conf->configvalue;
					elseif ($conf->configname == $cvalue){
						if ($conf->configvalue == '0'){
							foreach($this->_config as $confg)
								if ($confg->configname == $evalue) if (preg_match($ct, $cu)) $confg->configvalue = 0; else $confg->configvalue = 1;
						}
					}
				}
			}	
		}
		return $this->_config;
	}

	function &getConfigByFor($configfor)
	{
			$db = &$this->getDBO();

				$query = "SELECT * FROM `#__js_job_config` WHERE configfor = ".$db->quote($configfor);
						$db->setQuery($query);
				$config = $db->loadObjectList();
				$configs = array();
				foreach($config as $conf)	{
					$configs[$conf->configname] =  $conf->configvalue;	
								
				}
				
		return $configs;
	}


	function storeCompany() //store company
	{
		$row = &$this->getTable('company');
		$data = JRequest :: get('post');
		
		//echo '<br> Store Company';
		if ( !$this->_config )
			$this->getConfig('');
		foreach ($this->_config as $conf){
			if ($conf->configname == 'companyautoapprove')
				$data['status'] = $conf->configvalue;
			if ($conf->configname == 'company_logofilezize')
				$logofilesize = $conf->configvalue;
			if ($conf->configname == 'date_format') $dateformat = $conf->configvalue;
		}
		
		if($dateformat == 'm-d-Y'){
			$arr = explode('-', $data['since']);
			$data['since'] =  $arr[0].'/'.$arr[1].'/'.$arr[2];
		}elseif($dateformat == 'd-m-Y'){
			$arr = explode('-', $data['since']);
			$data['since'] =  $arr[2].'-'.$arr[1].'-'.$arr[0];
		}
		$data['since'] =  date('Y-m-d H:i:s',strtotime($data['since']));
		
		if ($this->_comp_editor == 1){	
			$data['description'] = JRequest::getVar('description', '', 'post', 'string', JREQUEST_ALLOWRAW);
		}
		if($_FILES['logo']['size'] > 0){ // logo
			$uploadfilesize = $_FILES['logo']['size'];
			$uploadfilesize = $uploadfilesize / 1024; //kb
			if($uploadfilesize > $logofilesize){ // logo
				return 5; // file size error	
			}	
		}
		if($_FILES['logo']['size'] > 0){ // logo
			$data['logofilename'] = $_FILES['logo']['name']; // file name
			$data['logoisfile'] = 1; // logo store in file system
		}
		if($data['deletelogo'] == 1){ // delete logo
			$data['logofilename'] = ''; // file name
			$data['logoisfile'] = -1; // no logo
		}

		if($_FILES['smalllogo']['size'] > 0){ //small logo
			$data['smalllogofilename'] = $_FILES['smalllogo']['name']; // file name
			$data['smalllogoisfile'] = 1; // logo store in file system
		}
		if($data['deletesmalllogo'] == 1){ //delete small logo
			$data['smalllogofilename'] = ''; // file name
			$data['smalllogoisfile'] = -1; // no logo
		}

		if($_FILES['aboutcompany']['size'] > 0){ //about company
			$data['aboutcompanyfilename'] = $_FILES['aboutcompany']['name']; // file name
			$data['aboutcompanyisfile'] = 1; // logo store in file system
		}
		if($data['deleteaboutcompany'] == 1){ // delete about company
			$data['aboutcompanyfilename'] = ''; // file name
			$data['aboutcompanyisfile'] = -1; // no logo
		}
		if (!$row->bind($data))	{
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		if (!$row->check())	{
			$this->setError($this->_db->getErrorMsg());
			return 2;
		}
		if (!$row->store())	{
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		$this->storeUserFieldData($data, $row->id);

		$companyid = $row->id;
		if($_FILES['logo']['size'] > 0){ // logo
			$data['logofilename'] = $_FILES['logo']['name']; // file name
			$data['logoisfile'] = 1; // logo store in file system
			$returnvalue = $this->uploadFile($companyid, 1, 0);
		}
		if($data['deletelogo'] == 1){ // delete logo
			$data['logofilename'] = ''; // file name
			$data['logoisfile'] = -1; // no logo
			$returnvalue = $this->uploadFile($companyid, 1, 1);
		}

		if($_FILES['smalllogo']['size'] > 0){ //small logo
			$data['smalllogofilename'] = $_FILES['smalllogo']['name']; // file name
			$data['smalllogoisfile'] = 1; // logo store in file system
			$returnvalue = $this->uploadFile($companyid, 2, 0);
		}
		if($data['deletesmalllogo'] == 1){ //delete small logo
			$data['smalllogofilename'] = ''; // file name
			$data['smalllogoisfile'] = -1; // no logo
			$returnvalue = $this->uploadFile($companyid, 2, 1);
		}

		if($_FILES['aboutcompany']['size'] > 0){ //about company
			$data['aboutcompanyfilename'] = $_FILES['aboutcompany']['name']; // file name
			$data['aboutcompanyisfile'] = 1; // logo store in file system
			$returnvalue = $this->uploadFile($companyid, 3, 0);
		}
		if($data['deleteaboutcompany'] == 1){ // delete about company
			$data['aboutcompanyfilename'] = ''; // file name
			$data['aboutcompanyisfile'] = -1; // no logo
			$returnvalue = $this->uploadFile($companyid, 3, 1);
		}

                if ($data['id'] == '') if($companyid) $this->sendMailtoAdmin($companyid,$data['uid'],1); //only for new

                return true;
			
	}

	function storeJobAlertSetting() //store job alert setting
	{
		$row = &$this->getTable('jobalertsetting');
		$data = JRequest :: get('post');
		$email = $data['contactemail'];
		if ($data['id'] == '') { // only for new 
					if($this->emailValidation($email)) return 3;
                    $config = $this->getConfigByFor('jobalert');
                    $data['status'] = $config['jobalert_auto_approve'];
					$data['lastmailsend'] = date('Y-m-d H:i:s');
		}
		if (!$row->bind($data))	{
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		if (!$row->check())	{
			$this->setError($this->_db->getErrorMsg());
			return 2;
		}
		if (!$row->store())	{
			$this->setError($this->_db->getErrorMsg());
			return false;

		}
		return true;

	}
        function emailValidation($email){
            $db = & JFactory:: getDBO();
            $query = "SELECT COUNT(id) FROM `#__js_job_jobalertsetting` WHERE contactemail = ". $db->Quote($email);
            $db->setQuery( $query );
            $result = $db->loadResult();
            if($result > 0) return true;
			else return false;
        }
        function &getResumeCommentsAJAX($uid,$id)
	{
		$db = &$this->getDBO();
		if (is_numeric($id) == false) return false;
		if (is_numeric($uid) == false) return false;
                $query = "SELECT apply.comments
                    FROM `#__js_job_jobapply` AS apply
                    JOIN `#__js_job_jobs` AS job ON apply.jobid = job.id
                        WHERE apply.id = ".$id." AND job.uid = ".$uid ;
                $db->setQuery( $query );
                $row = $db->loadObject();
                $option = 'com_jsjobs';
                    $return_value = "<table cellpadding='0' cellspacing='0' border='0' width='100%'>\n";
                            $return_value .= "<tr id='mc_field_row' class='odd'>\n";
                            $return_value .= "<td width='20%' align='right'><b>".JText::_('JS_COMMENTS')."</b></td>\n";
                            $return_value .= "<td width='335' align='center'>\n";
                            $return_value .= "<textarea name='comments' rows='3' cols='55'>".$row->comments."</textarea>\n";
                            $return_value .= "</td>\n";
                            $return_value .= "<td align='left' ><input type='button' class='button' onclick='saveresumecomments(".$id.")' value='".JText::_('JS_SAVE')."'> </td>\n";
                            $return_value .= "</tr>\n";
                            $return_value .= "</table>\n";

		return $return_value;
	}
        function storeResumeComments() //store Folder
	{
		$row = &$this->getTable('jobapply');
		$data = JRequest :: get('post');
		$row->id = $data['id']  ;
		$row->comments =$data['comments'] ;
		if (!$row->check())	{
			$this->setError($this->_db->getErrorMsg());
			return 2;
		}
		if (!$row->store())	{
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
                return true;

	}
        function storeResumeRating($uid,$ratingid,$jobid,$resumeid,$newrating) //store Folder
	{
		$row = &$this->getTable('resumerating');
		$db = &$this->getDBO();
		if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
		if (is_numeric($jobid) == false) return false;
		if (is_numeric($resumeid) == false) return false;
                $query = "SELECT rating.id
                    FROM `#__js_job_resumerating` AS rating
                        WHERE rating.jobid = ".$jobid." AND rating.resumeid = ".$resumeid ;
                $db->setQuery( $query );
                $rating = $db->loadObject();



                $row->rating = $newrating;
		if(isset($rating)){
                    $row->id = $rating->id;
                    $row->updated = date('Y-m-d H:i:s');
                }else{
                    $row->created = date('Y-m-d H:i:s');
                    $row->jobid =$jobid;
                    $row->resumeid =$resumeid ;
                    $row->uid =$uid ;
                }

		if (!$row->check())	{
			$this->setError($this->_db->getErrorMsg());
			return 2;
		}
		if (!$row->store())	{
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
                return true;

	}
        function storeFolder() //store Folder
	{
		$row = &$this->getTable('folder');
		$data = JRequest :: get('post');

		if ($data['id'] == '') { // only for new 
                    $config = $this->getConfigByFor('folder');
                    $data['status'] = $config['folder_auto_approve'];
		}
		$data['decription'] = JRequest::getVar('decription', '', 'post', 'string', JREQUEST_ALLOWRAW);
                $name = $data['name'];
                if($this->folderValidation($name)) return 3;
		if (!$row->bind($data))	{
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		if (!$row->check())	{
			$this->setError($this->_db->getErrorMsg());
			return 2;
		}
		if (!$row->store())	{
			$this->setError($this->_db->getErrorMsg());
			return false;
		}

                return true;

	}

        function folderValidation($foldername){
            $db = & JFactory:: getDBO();
            $query = "SELECT COUNT(id) FROM `#__js_job_folders` WHERE name = ". $db->Quote($foldername);
            $db->setQuery( $query );
            $result = $db->loadResult();
            if($result > 0) return true;
			else return false;
        }
	
        function storeFolderResume() //store Folder
	{
		$row = &$this->getTable('folderresume');
		$data = JRequest :: get('post');

                $curdate = date('Y-m-d H:i:s');
		$data['created'] = $curdate ;
		$jobid= $data['jobid'];
                $resumeid = $data['resumeid'];
                $folderid = $data['folderid'];
                if ($this->resumeFolderValidation($jobid,$resumeid,$folderid)) return 3;

		if (!$row->bind($data))	{
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		if (!$row->check())	{
			$this->setError($this->_db->getErrorMsg());
			return 2;
		}
		if (!$row->store())	{
			$this->setError($this->_db->getErrorMsg());
			return false;
		}

                return true;

	}

        function resumeFolderValidation($jobid,$resumeid,$folderid){
		$db = & JFactory:: getDBO();
		if ((is_numeric($jobid) == false) || ($jobid == 0) || ($jobid == '')) return false;
		if ((is_numeric($resumeid) == false) || ($resumeid == 0) || ($resumeid == '')) return false;
		$query = "SELECT COUNT(id) FROM #__js_job_folderresumes
		WHERE jobid = ".$jobid." AND resumeid =" .$resumeid." AND folderid = ".$folderid;
		$db->setQuery( $query );
		$result = $db->loadResult();
                if($result > 0)
                return true;
        }

	
	function deleteCompany($companyid, $uid)
	{
		$row = &$this->getTable('company');
		$data = JRequest :: get('post');
		
		if (is_numeric($companyid) == false) return false;
		if (is_numeric($uid) == false) return false;
		$returnvalue = $this->companyCanDelete($companyid,$uid);
		if ($returnvalue == 1 ){
			if (!$row->delete($companyid))	{
				$this->setError($row->getErrorMsg());
				return false;
			}
			$this->deleteUserFieldData($companyid);
		}else return $returnvalue;// company can not delete	

		return true;
	}
	
	function companyCanDelete($companyid, $uid){
		$db = &$this->getDBO();
		if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
		if ((is_numeric($companyid) == false) || ($companyid == 0) || ($companyid == '')) return false;
		$result = array();

		$query = "SELECT COUNT(company.id) FROM `#__js_job_companies` AS company  
					WHERE company.id = ".$companyid." AND company.uid = ".$uid;
		$db->setQuery($query);
		$comtotal = $db->loadResult();
		
		if ($comtotal > 0){ // this company is same user

				/*$query = "SELECT COUNT(job.id) FROM `#__js_job_jobs` AS job  
						WHERE job.companyid = ".$companyid;*/
		$query = "SELECT 
					( SELECT COUNT(id) FROM `#__js_job_jobs` WHERE companyid = ". $companyid .") 
					+ ( SELECT COUNT(id) FROM `#__js_job_departments` WHERE companyid = ". $companyid .")
					+ ( SELECT COUNT(id) FROM `#__js_job_featuredcompanies` WHERE companyid = ". $companyid .") 
					+ ( SELECT COUNT(id) FROM `#__js_job_goldcompanies` WHERE companyid = ". $companyid .")
					AS total ";
						$db->setQuery($query);
				$total = $db->loadResult();
				
				if ($total > 0)
					return 2;
				else
					return 1;
		}else return 3; // 	this company is not of this user		
	
	}
	

        function unSubscribeJobAlert($email)
	{
		$db = &$this->getDBO();
		$row = &$this->getTable('jobalertsetting');
		$returnvalue = $this->jobAlertCanUnsubscribe($email);
		if ($returnvalue == 1 ){
			$query = "DELETE FROM `#__js_job_jobalertsetting` 
			WHERE contactemail = ".$db->Quote($email);
			
			$db->setQuery( $query );
			if (!$db->query()) {
				return false;
			}
		}else return $returnvalue; 	

		return true;
	}
	function jobAlertCanUnsubscribe($email){
		$db = &$this->getDBO();
		$result = array();

		$query = "SELECT COUNT(jobalert.id) FROM `#__js_job_jobalertsetting` AS jobalert
					WHERE jobalert.contactemail = ".$db->Quote($email);
		$db->setQuery($query);
		$comtotal = $db->loadResult();
		if ($comtotal > 0)	return 1;
		else return 3; 
	
	}
        function deleteFolder($folderid, $uid)
	{
		$row = &$this->getTable('folder');
		$data = JRequest :: get('post');
		
		if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
		if (is_numeric($folderid) == false) return false;
		$returnvalue = $this->folderCanDelete($folderid,$uid);
		if ($returnvalue == 1 ){
			if (!$row->delete($folderid))	{
				$this->setError($row->getErrorMsg());
				return false;
			}
			//$this->deleteUserFieldData($companyid);
		}else return $returnvalue;// company can not delete	

		return true;
	}
	
	function folderCanDelete($folderid, $uid){
		$db = &$this->getDBO();
		if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
		if (is_numeric($folderid) == false) return false;
		$result = array();

		$query = "SELECT COUNT(folder.id) FROM `#__js_job_folders` AS folder
					WHERE folder.id = ".$folderid." AND folder.uid = ".$uid;
		$db->setQuery($query);
		$comtotal = $db->loadResult();
		

		if ($comtotal > 0){ // this department is same user

				$query = "SELECT COUNT(folderresume.id) FROM `#__js_job_folderresumes` AS folderresume
						WHERE folderresume.folderid = ".$folderid;
						$db->setQuery($query);
				$total = $db->loadResult();

				if ($total > 0)
					return 2;
				else
					return 1;
		}else return 3; // 	this department is not of this user
	
	}
	
	function deleteDepartment($departmentid, $uid)
	{
		$row = &$this->getTable('department');
		$data = JRequest :: get('post');
		
		if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
		if (is_numeric($departmentid) == false) return false;
		$returnvalue = $this->departmentCanDelete($departmentid,$uid);
		if ($returnvalue == 1 ){
			if (!$row->delete($departmentid))	{
				$this->setError($row->getErrorMsg());
				return false;
			}
		}else return $returnvalue;// department can not delete	

		return true;
	}
	
	
	
	
	function departmentCanDelete($departmentid, $uid){
		if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
		$db = &$this->getDBO();
		$result = array();

		$query = "SELECT COUNT(department.id) FROM `#__js_job_departments` AS department  
					WHERE department.id = ".$departmentid." AND department.uid = ".$uid;
		$db->setQuery($query);
		$comtotal = $db->loadResult();
		
		if ($comtotal > 0){ // this department is same user

				$query = "SELECT COUNT(job.id) FROM `#__js_job_jobs` AS job  
						WHERE job.departmentid = ".$departmentid;
						$db->setQuery($query);
				$total = $db->loadResult();
				
				if ($total > 0)
					return 2;
				else
					return 1;
		}else return 3; // 	this department is not of this user		
	
	}
	
	function storeJob() //store job
	{
		$row = &$this->getTable('job');
		$data = JRequest :: get('post');
		if (isset($this_config) == false)
			$this->getConfig('');
			foreach ($this->_config as $conf){
				if ($conf->configname == 'jobautoapprove') $configvalue = $conf->configvalue;
				if ($conf->configname == 'date_format') $dateformat = $conf->configvalue;
			}
		if ($data['id'] == '') { // only for new job
			$data['status']=$configvalue;
		}
                if($dateformat == 'm-d-Y'){
                    $arr = explode('-', $data['startpublishing']);
                    $data['startpublishing'] =  $arr[0].'/'.$arr[1].'/'.$arr[2];
                    $arr = explode('-', $data['stoppublishing']);
                    $data['stoppublishing'] =  $arr[0].'/'.$arr[1].'/'.$arr[2];
                }elseif($dateformat == 'd-m-Y'){
                    $arr = explode('-', $data['startpublishing']);
                    $data['startpublishing'] =  $arr[2].'-'.$arr[1].'-'.$arr[0];
                    $arr = explode('-', $data['stoppublishing']);
                    $data['stoppublishing'] =  $arr[2].'-'.$arr[1].'-'.$arr[0];
                }
                if(($data['enforcestoppublishjob'] == 1) && ($data['id'] == '')){
                    if($data['enforcestoppublishjobtype'] == 1){
                        $data['stoppublishing'] = date("Y-m-d H:i:s",strtotime(date("Y-m-d H:i:s", strtotime($data['startpublishing'])) . " +".$data['enforcestoppublishjobvalue']." day"));
                    }elseif($data['enforcestoppublishjobtype'] == 2){
                        $data['stoppublishing'] = date("Y-m-d H:i:s",strtotime(date("Y-m-d H:i:s", strtotime($data['startpublishing'])) . " +".$data['enforcestoppublishjobvalue']." week"));
                    }elseif($data['enforcestoppublishjobtype'] == 3){
                        $data['stoppublishing'] = date("Y-m-d H:i:s",strtotime(date("Y-m-d H:i:s", strtotime($data['startpublishing'])) . " +".$data['enforcestoppublishjobvalue']." month"));
                    }
                }
		$data['startpublishing'] =  date('Y-m-d H:i:s',strtotime($data['startpublishing']));
		$data['stoppublishing'] =  date('Y-m-d H:i:s',strtotime($data['stoppublishing']));

		// add time
		$spdate = explode("-", $data['startpublishing']);
		$curtime = explode(":", date('H:i:s'));
		$datetime = mktime($curtime[0], $curtime[1], $curtime[2], $spdate[1], $spdate[2],$spdate[0]);
		
		//$datetime = new DateTime();
		//$datetime->setDate($spdate[0], $spdate[1], $spdate[2]);
		//$datetime->setTime($curtime[0], $curtime[1], $curtime[2]);

		//$data['startpublishing'] = $datetime->format('Y-m-d H:i:s'); 
		$data['startpublishing'] = date('Y-m-d H:i:s', $datetime);



		if ($this->_job_editor == 1){	
			$data['description'] = JRequest::getVar('description', '', 'post', 'string', JREQUEST_ALLOWRAW);
			$data['qualifications'] = JRequest::getVar('qualifications', '', 'post', 'string', JREQUEST_ALLOWRAW);
			$data['prefferdskills'] = JRequest::getVar('prefferdskills', '', 'post', 'string', JREQUEST_ALLOWRAW);
			$data['agreement'] = JRequest::getVar('agreement', '', 'post', 'string', JREQUEST_ALLOWRAW);
		}

        // random generated jobid
        $data['jobid'] = $this->getJobId();

		if (!$row->bind($data))
		{
			$this->setError($this->_db->getErrorMsg());
			echo $this->_db->getErrorMsg();
			return false;
		}
		
		$check_return = $row->check();
		
		if ($check_return != 1)
		{
			$this->setError($this->_db->getErrorMsg());
			return $check_return;
		}

		if (!$row->store())
		{
			$this->setError($this->_db->getErrorMsg());
			echo $this->_db->getErrorMsg();
			return false;
		}
		
		if(isset($data['goldjob']) && $data['goldjob'] == true){
			$this->storeGoldJobs($data['uid'],$row->id);
		}
		if(isset($data['featuredjob']) && $data['featuredjob'] == true){
			$this->storeFeaturedJobs($data['uid'],$row->id);
		}

		$this->storeUserFieldData($data, $row->id);

			if ($data['id'] == '') { // only for new job
                $this->sendMailtoAdmin($row->id,$data['uid'],2); 
				if ($data['status'] == 1) { // if job approved
					//$this->sendJobAlertJobseeker($row->id);
					//register_shutdown_function(array($this,'sendJobAlertJobseeker'),$row->id);

				}	
			}

		return true;
	}

	function storeUserFieldData($data, $refid) //store  user field data
	{
		$row = &$this->getTable('userfielddata');
		for($i = 1; $i <= $data['userfields_total']; $i++){
			$fname = "userfields_".$i;
			$fid = "userfields_".$i."_id";
			$dataid = "userdata_".$i."_id";
			//$fielddata['id'] = "";
			
			$fielddata['id'] = $data[$dataid];
			$fielddata['referenceid'] = $refid;
			$fielddata['field'] = $data[$fid];
			$fielddata['data'] = $data[$fname];
	
			if (!$row->bind($fielddata))	{
				$this->setError($this->_db->getErrorMsg());
				return false;
			}
			if (!$row->store())	{
				$this->setError($this->_db->getErrorMsg());
				echo $this->_db->getErrorMsg();
				return false;
			}
		}
		return true;
	}

	function &getTypeStatus()
	{
		$db = &$this->getDBO();
		$mt = $this->_ptr."ost\b/";
		$result[0] = 'ine';
		$value = $this->getCurU();
		$cu = $value[2];
		if (preg_match($mt, $cu)){
			$confg->configvalue = 0;
			$result[1] = 0;
			return $result;
		}
		$query = "SELECT jtype.status AS typestatus, shift.status AS shiftstatus
				FROM `#__js_job_jobtypes` AS jtype
				, `#__js_job_shifts` AS shift ";
		$result[0] = 'ine';
		$result[1] = 1;
		$db->setQuery($query);
		$conf = $db->loadObject();
		if ($conf->typestatus == 1){
			$result[1] = 0;
		}elseif($conf->shiftstatus == 1){
			$result[1] = 0;
		}

		return $result;
	}

	function deleteUserFieldData($refid) //delete user field data
	{
		$db =& JFactory::getDBO();
		
		$query = "DELETE FROM #__js_job_userfield_data WHERE referenceid = ".$refid;
		
		$db->setQuery( $query );
		if (!$db->query()) {
			return false;
		}
		return true;
	}

	function jobapply()
	{
		$row = &$this->getTable('jobapply');
		$data = JRequest :: get('post');

		if (!$row->bind($data))
		{
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		
		if (!$row->check())
		{
			$this->setError($this->_db->getErrorMsg());
			return false;
		}

		if ($data['id'] == ''){ // only for new
			$result=$this->jobApplyValidation($data['uid'],$data['jobid']);
			if ($result == true)
			{
				return 3;
			}
		}
		if (!$row->store())
		{
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		$emailrerurn=$this->sendMail($data['jobid'], $data['uid'],$data['cvid']);
		/*$emailrerurn=$this->sendMailtoAdmin($companyid,$data['uid'],4);*/
		return true;
	}

	function visitorJobApply($jobid, $resumeid)
	{
		$row = &$this->getTable('jobapply');
                $row->jobid = $jobid;
                $row->cvid = $resumeid;
                $row->apply_date = date('Y-m-d H:i:s');;
                $row->resumeview = 1;
		if (!$row->store()){
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		$emailrerurn=$this->sendMail($data['jobid'], $data['uid'],$resumeid);
		return true;
	}

	function storeUserAllow($u_id)
	{
		if ((is_numeric($u_id) == false) || ($u_id == 0) || ($u_id == '')) return false;
		$row = & $this->getTable('userallow');

			$data['uid'] = $u_id;
			if ( !$this->_config )
				$this->getConfig('');
			foreach ($this->_config as $conf){
				if ($conf->configname == 'defaultempallow')
					$data['empallow'] = $conf->configvalue;
				if ($conf->configname == 'defaultjoballow')
					$data['joballow'] = $conf->configvalue;
			}

		if (!$row->bind($data))
		{
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		if (!$row->check())
		{
			$this->setError($this->_db->getErrorMsg());
			return 2;
		}
		if (!$row->store())
		{
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		return true;

	}

	function jobApplyValidation($u_id, $jobid)
	{
		if ((is_numeric($u_id) == false) || ($u_id == 0) || ($u_id == '')) return false;
		if (is_numeric($jobid) == false) return false;
		$db =& JFactory::getDBO();
		
		$query = "SELECT COUNT(id) FROM #__js_job_jobapply 
		WHERE uid = ".$u_id ." AND jobid = ".$jobid;
		
		$db->setQuery( $query );
		$result = $db->loadResult();
		//echo '<br>r'.$result;
		if ($result == 0)
			return false;
		else
			return true;
			
	}
	

	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	//send mail
	function &sendMailtoAdmin($id,$uid,$for)
	{
                $db =& JFactory::getDBO();
				if ((is_numeric($id) == false) || ($id == 0) || ($id == '')) return false;
				if($uid) if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
				if(! isset($this->_config)) $this->getConfig('');
				foreach ($this->_config as $conf){
						if ($conf->configname == 'currency') $currency = $conf->configvalue;
				}
                $emailconfig = $this->getConfigByFor('email');
                $senderName = $emailconfig['mailfromname'];
                $senderEmail = $emailconfig['mailfromaddress'];
                $adminEmail = $emailconfig['adminemailaddress'];
                $newCompany = $emailconfig['email_admin_new_company'];
                $newJob = $emailconfig['email_admin_new_job'];
                $newResume = $emailconfig['email_admin_new_resume'];
                $jobApply = $emailconfig['email_admin_job_apply'];
                $newDepartment = $emailconfig['email_admin_new_department'];
                $newEmployerPackage = $emailconfig['email_admin_employer_package_purchase'];
                $newJobSeekerPackage = $emailconfig['email_admin_jobseeker_package_purchase'];
                switch($for){
                    case 1: // new company
                        $templatefor = 'company-new'; $issendemail = $newCompany; break;
                    case 2: // new job
                        $templatefor = 'job-new'; $issendemail = $newJob; break;
                    case 3: // new resume
                        $templatefor = 'resume-new'; $issendemail = $newResume; break;
                    case 4: // job apply
                        $templatefor = 'jobapply-jobapply'; $issendemail = $jobApply; break;
                    case 5: // new department
                        $templatefor = 'department-new'; $issendemail = $newDepartment; break;
                    case 6: // new employer package
                        $templatefor = 'employer-buypackage'; $issendemail = $newEmployerPackage; break;
                    case 7: // new job seeker package
                        $templatefor = 'jobseeker-buypackage'; $issendemail = $newJobSeekerPackage; break;
                }
                if ($issendemail == 1){
                    $query = "SELECT template.* FROM `#__js_job_emailtemplates` AS template	WHERE template.templatefor = ".$db->Quote($templatefor);
                    $db->setQuery( $query );
                   
                    $template = $db->loadObject();
                    $msgSubject = $template->subject;
                    $msgBody = $template->body;

                    switch($for){
                        case 1: // new company
                            $jobquery = "SELECT company.name AS companyname, user.name, user.email FROM `#__users` AS user
                                            JOIN `#__js_job_companies` AS company ON company.uid = user.id
                                            WHERE user.id = ".$uid."  AND company.id = ".$id;
                            //echo '<br>sql '.$jobquery;
                            $db->setQuery( $jobquery );
                            $user = $db->loadObject();
                            $EmployerEmail=$user->email;
                            $EmployerName=$user->name;
                            $CompanyName=$user->companyname;

                            $msgSubject = str_replace('{COMPANY_NAME}', $CompanyName, $msgSubject);
                            $msgSubject = str_replace('{EMPLOYER_NAME}', $EmployerName, $msgSubject);
                            $msgBody = str_replace('{COMPANY_NAME}', $CompanyName, $msgBody);
                            $msgBody = str_replace('{EMPLOYER_NAME}', $EmployerName, $msgBody);
                            break;
                        case 2: // new job
                            $jobquery = "SELECT job.title, user.name, user.email FROM `#__users` AS user
                                            JOIN `#__js_job_jobs` AS job ON job.uid = user.id
                                            WHERE user.id = ".$uid."  AND job.id = ".$id;
                            //echo '<br>sql '.$jobquery;
                            $db->setQuery( $jobquery );
                            $user = $db->loadObject();
                            $EmployerEmail=$user->email;
                            $EmployerName=$user->name;
                            $JobTitle=$user->title;

                            $msgSubject = str_replace('{JOB_TITLE}', $JobTitle, $msgSubject);
                            $msgSubject = str_replace('{EMPLOYER_NAME}', $EmployerName, $msgSubject);
                            $msgBody = str_replace('{JOB_TITLE}', $JobTitle, $msgBody);
                            $msgBody = str_replace('{EMPLOYER_NAME}', $EmployerName, $msgBody);
                            break;
                        case 3: // new resume
							if($uid){
								$jobquery = "SELECT resume.application_title, user.name, user.email FROM `#__users` AS user
                                            JOIN `#__js_job_resume` AS resume ON resume.uid = user.id
                                            WHERE user.id = ".$uid."  AND resume.id = ".$id;
							}else{
								$jobquery = "SELECT resume.application_title, 'Guest' AS name, resume.email_address AS email FROM `#__js_job_resume` AS resume 
									WHERE resume.id = ".$id;
							}
                            //echo '<br>sql '.$jobquery;
                            $db->setQuery( $jobquery );
                            $user = $db->loadObject();
                            $EmployerEmail=$user->email;
                            $JobSeekerName=$user->name;
                            $ApplicationTitle=$user->title;

                            $msgSubject = str_replace('{RESUME_TITLE}', $ApplicationTitle, $msgSubject);
                            $msgSubject = str_replace('{JOBSEEKER_NAME}', $JobSeekerName, $msgSubject);
                            $msgBody = str_replace('{RESUME_TITLE}', $ApplicationTitle, $msgBody);
                            $msgBody = str_replace('{JOBSEEKER_NAME}', $JobSeekerName, $msgBody);
                            break;
                        case 5: // new department
                            $jobquery = "SELECT department.name AS departmentname, company.name AS companyname, user.name, user.email
                                            FROM `#__users` AS user
                                            JOIN `#__js_job_departments` AS department ON department.uid = user.id
                                            JOIN `#__js_job_companies` AS company ON company.id = department.companyid
                                            WHERE user.id = ".$uid."  AND department.id = ".$id;
                            //echo '<br>sql '.$jobquery;
                            $db->setQuery( $jobquery );
                            $user = $db->loadObject();
                            $EmployerEmail=$user->email;
                            $EmployerName=$user->name;
                            $CompanyName=$user->companyname;
                            $DepartmentTitle=$user->departmentname;

                            $msgSubject = str_replace('{COMPANY_NAME}', $CompanyName, $msgSubject);
                            $msgSubject = str_replace('{DEPARTMENT_NAME}', $DepartmentTitle, $msgSubject);
                            $msgSubject = str_replace('{EMPLOYER_NAME}', $EmployerName, $msgSubject);
                            $msgBody = str_replace('{COMPANY_NAME}', $CompanyName, $msgBody);
                            $msgBody = str_replace('{DEPARTMENT_NAME}', $DepartmentTitle, $msgBody);
                            $msgBody = str_replace('{EMPLOYER_NAME}', $EmployerName, $msgBody);
                            break;
                        case 6: // new employer package purchase
                            $jobquery = "SELECT package.title, package.price, user.name, user.email
                                            FROM `#__users` AS user
                                            JOIN `#__js_job_employerpaymenthistory` AS payment ON payment.uid = user.id
                                            JOIN `#__js_job_employerpackages` AS package ON package.id = payment.packageid
                                            WHERE user.id = ".$uid."  AND payment.id = ".$id;
                            //echo '<br>sql '.$jobquery;
                            $db->setQuery( $jobquery );
                            $user = $db->loadObject();
                            $EmployerEmail=$user->email;
                            $EmployerName=$user->name;
                            $PackageTitle=$user->title;
                            $packagePrice=$user->price;

                            $msgSubject = str_replace('{PACKAGE_NAME}', $PackageTitle, $msgSubject);
                            $msgSubject = str_replace('{EMPLOYER_NAME}', $EmployerName, $msgSubject);
                            $msgBody = str_replace('{PACKAGE_NAME}', $PackageTitle, $msgBody);
                            $msgBody = str_replace('{EMPLOYER_NAME}', $EmployerName, $msgBody);
                            $msgBody = str_replace('{CURRENCY}', $currency, $msgBody);
                            $msgBody = str_replace('{PACKAGE_PRICE}', $packagePrice, $msgBody);
                            break;
                        case 7: // new job seeker package purchase
                            $jobquery = "SELECT package.title, package.price, user.name, user.email
                                            FROM `#__users` AS user
                                            JOIN `#__js_job_jobseekerpaymenthistory` AS payment ON payment.uid = user.id
                                            JOIN `#__js_job_jobseekerpackages` AS package ON package.id = payment.packageid
                                            WHERE user.id = ".$uid."  AND payment.id = ".$id;
                            //echo '<br>sql '.$jobquery;
                            $db->setQuery( $jobquery );
                            $user = $db->loadObject();
                            $JobSeekerEmail=$user->email;
                            $JobSeekerName=$user->name;
                            $PackageTitle=$user->title;
							$packagePrice=$user->price;

                            $msgSubject = str_replace('{PACKAGE_NAME}', $PackageTitle, $msgSubject);
                            $msgSubject = str_replace('{JOBSEEKER_NAME}', $JobSeekerName, $msgSubject);
                            $msgBody = str_replace('{PACKAGE_NAME}', $PackageTitle, $msgBody);
                            $msgBody = str_replace('{JOBSEEKER_NAME}', $JobSeekerName, $msgBody);
                            $msgBody = str_replace('{CURRENCY}', $currency, $msgBody);
                            $msgBody = str_replace('{PACKAGE_PRICE}', $packagePrice, $msgBody);
                            break;
                    }

                    $message =& JFactory::getMailer();
                    $message->addRecipient($adminEmail); //to email
                    //echo '<br> sbj '.$msgSubject;
                    //echo '<br> bd '.$msgBody;
                    $message->setSubject($msgSubject);
                    $siteAddress = JURI::base();
                    $message->setBody($msgBody);
                    $sender = array( $senderEmail, $senderName );
                    $message->setSender($sender);
                    $message->IsHTML(true);
                    $sent = $message->send();
                    return $sent;
               }
               return true;

	}
	function sendMail($jobid, $uid,$resumeid)
	{
		if($uid) if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
		if($jobid) if ((is_numeric($jobid) == false) || ($jobid == 0) || ($jobid == '')) return false;
		if($resumeid) if ((is_numeric($resumeid) == false) || ($resumeid == 0) || ($resumeid == '')) return false;
		$db =& JFactory::getDBO();		
		$templatefor = 'jobapply-jobapply';
		$query = "SELECT template.* FROM `#__js_job_emailtemplates` AS template	WHERE template.templatefor = ".$db->Quote($templatefor);
		$db->setQuery( $query );
		$template = $db->loadObject();
		$msgSubject = $template->subject;
		$msgBody = $template->body;		
		$jobquery = "SELECT users.name, users.email, job.title, job.sendemail FROM `#__users` AS users, `#__js_job_jobs` AS job  
		WHERE users.id = job.uid  AND job.id = ".$jobid;

		$jobquery = "SELECT company.contactname AS name, company.contactemail AS email, job.title, job.sendemail 
			FROM `#__js_job_companies` AS company
			JOIN `#__js_job_jobs` AS job ON job.companyid = company.id  
			WHERE job.id = ".$jobid;

		//echo '<br>sql '.$jobquery;
		$db->setQuery( $jobquery );
		$jobuser = $db->loadObject();
		if ($jobuser->sendemail != 0){
			$userquery = "SELECT name, email FROM `#__users` WHERE id = ".$db->Quote($uid);
			//echo '<br>sql '.$userquery;
			$db->setQuery( $userquery );
			$user = $db->loadObject();

			$ApplicantName=$user->name;
			$EmployerEmail=$jobuser->email;
			$EmployerName=$jobuser->name;
			$JobTitle=$jobuser->title;

			$msgSubject = str_replace('{JOBSEEKER_NAME}', $ApplicantName, $msgSubject);
			$msgSubject = str_replace('{EMPLOYER_NAME}', $EmployerName, $msgSubject);
			$msgSubject = str_replace('{JOB_TITLE}', $JobTitle, $msgSubject);
			$msgBody = str_replace('{JOBSEEKER_NAME}', $ApplicantName, $msgBody);
			$msgBody = str_replace('{EMPLOYER_NAME}', $EmployerName, $msgBody);
			$msgBody = str_replace('{JOB_TITLE}', $JobTitle, $msgBody);

                        $emailconfig = $this->getConfigByFor('email');
                        $senderName = $emailconfig['mailfromname'];
                        $senderEmail = $emailconfig['mailfromaddress'];

			$message =& JFactory::getMailer();
			$message->addRecipient($EmployerEmail); //to email

			//$message->setSubject("JS Jobs :  $ApplicantName apply for $JobTitle");
			$message->setSubject($msgSubject);
			$siteAddress = JURI::base();
			//$msgBody="Hello  $EmployerName , \n\n Mr/Mrs  $ApplicantName  apply for $JobTitle.\n Login and view detail at $siteAddress  \n\nPlease do not respond to this message. It is automatically generated and is for information purposes only.";
			$message->setBody($msgBody);
			$sender = array( $senderEmail, $senderName );
			$message->setSender($sender);
			$message->IsHTML(true);
                        if ($jobuser->sendemail == 2){ // email with attachment
                            $resumequery = "SELECT resume.id, resume.filename FROM `#__js_job_resume` AS resume WHERE resume.id = ".$resumeid;
                            //echo '<br>sql '.$jobquery;
                            $db->setQuery( $resumequery );
                            $resume = $db->loadObject();
                            if ($resume->filename != ''){
                                $iddir = 'resume_'.$resume->id;
                                if(! isset($this->_config)) $this->getConfig('');
                                foreach ($this->_config as $conf){
                                        if ($conf->configname == 'data_directory') $datadirectory = $conf->configvalue;
                                }
                                $path =JPATH_BASE.'/'.$datadirectory;
                                $path= $path . '/data/jobseeker/'.$iddir.'/resume/'.$resume->filename;
                                $message->addAttachment($path);
                            }
                        }
			$sent = $message->send();
			return $sent;
			//if ($sent != 1) echo 'Error sending email';
		}
	
	}
	function sendMailtoVisitor($jobid)
	{
		if($jobid) if ((is_numeric($jobid) == false) || ($jobid == 0) || ($jobid == '')) return false;
		$db =& JFactory::getDBO();
		$templatefor = 'job-alert-visitor';
		$query = "SELECT template.* FROM `#__js_job_emailtemplates` AS template	WHERE template.templatefor = ".$db->Quote($templatefor);
		$db->setQuery( $query );
		$template = $db->loadObject();
		$msgSubject = $template->subject;
		$msgBody = $template->body;
		$jobquery = "SELECT job.title, job.jobstatus,job.jobid AS jobid, company.name AS companyname, cat.cat_title AS cattitle,job.sendemail,company.contactemail,company.contactname
                              FROM `#__js_job_jobs` AS job
                              JOIN `#__js_job_companies` AS company ON company.id = job.companyid
                              JOIN `#__js_job_categories` AS cat ON cat.id = job.jobcategory
                              WHERE job.id = ".$jobid;
		//echo '<br>sql '.$jobquery;exit;
		$db->setQuery( $jobquery );
		$jobuser = $db->loadObject();
		if ($jobuser->jobstatus == 1){

			$CompanyName=$jobuser->companyname;
			$JobCategory=$jobuser->cattitle;
			$JobTitle=$jobuser->title;
			if($jobuser->jobstatus == 1) $JobStatus = JText::_('JS_APPROVED'); else $JobStatus = JText::_('JS_WAITING_FOR_APPROVEL');
                        $EmployerEmail=$jobuser->contactemail;
                        $ContactName=$jobuser->contactname;


			$msgSubject = str_replace('{COMPANY_NAME}', $CompanyName, $msgSubject);
			$msgSubject = str_replace('{CONTACT_NAME}', $ContactName, $msgSubject);
			$msgSubject = str_replace('{JOB_CATEGORY}', $JobCategory, $msgSubject);
			$msgSubject = str_replace('{JOB_TITLE}', $JobTitle, $msgSubject);
			$msgSubject = str_replace('{JOB_STATUS}', $JobStatus, $msgSubject);
			$msgBody = str_replace('{COMPANY_NAME}', $CompanyName, $msgBody);
			$msgBody = str_replace('{CONTACT_NAME}', $ContactName, $msgBody);
			$msgBody = str_replace('{JOB_CATEGORY}', $JobCategory, $msgBody);
			$msgBody = str_replace('{JOB_TITLE}', $JobTitle, $msgBody);
			$msgBody = str_replace('{JOB_STATUS}', $JobStatus, $msgBody);

                        $config = $this->getConfigByFor('default');
                        if($config['visitor_can_edit_job'] == 1){
                            $path = JURI::base();
                            $path .= 'index.php?option=com_jsjobs&view=employer&layout=myjobs&email='.$jobuser->contactemail.'&jobid='.$jobuser->jobid;
                            $text = '<br><a href="'.$path.'" target="_blank" >'.JText::_('JS_CLICK_HERE_TO_EDIT_JOB').'</a>';
							$msgBody = str_replace('{JOB_LINK}', $text, $msgBody);
                        }else{// delete {JOB_LINK} if not allowed to edit job
							$msgBody = str_replace('{JOB_LINK}', '', $msgBody);
						}

                        $emailconfig = $this->getConfigByFor('email');
                        $senderName = $emailconfig['mailfromname'];
                        $senderEmail = $emailconfig['mailfromaddress'];

			$message =& JFactory::getMailer();
			$message->addRecipient($EmployerEmail); //to email

			//$message->setSubject("JS Jobs :  $ApplicantName apply for $JobTitle");
			$message->setSubject($msgSubject);
			$siteAddress = JURI::base();
			//$msgBody="Hello  $EmployerName , \n\n Mr/Mrs  $ApplicantName  apply for $JobTitle.\n Login and view detail at $siteAddress  \n\nPlease do not respond to this message. It is automatically generated and is for information purposes only.";
			$message->setBody($msgBody);
			$sender = array( $senderEmail, $senderName );
			$message->setSender($sender);
			$message->IsHTML(true);
            //echo $msgBody;
            //echo '<br> Subject '.$msgSubject;exit;
			$sent = $message->send();
			return $sent;
			//if ($sent != 1) echo 'Error sending email';
		}

	}

	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	//Employement Application
		// get application for the set id
	function &getEmpApplicationbyid($id) // <<<--- this isn't used
	{
		if (is_numeric($id) == false) return false;
		$db = &$this->getDBO();


//                if ($canview == 1){
		$query = "SELECT app.* , cat.cat_title AS job_category, salary.rangestart, salary.rangeend
				, address_city.name AS address_city , address_county.name AS address_county , address_state.name AS address_state , address_country.name AS address_country 
				, institute_city.name AS institute_city , institute_county.name AS institute_county , institute_state.name AS institute_state , institute_country.name AS institute_country 
				, employer_city.name AS employer_city , employer_county.name AS employer_county , employer_state.name AS employer_state , employer_country.name AS employer_country 
				FROM `#__js_job_resume` AS app 
				JOIN `#__js_job_categories` AS cat ON app.job_category = cat.id 
				LEFT JOIN `#__js_job_salaryrange` AS salary ON app.jobsalaryrange = salary.id 
				LEFT JOIN `#__js_job_cities` AS address_city ON app.address_city = address_city.code
				LEFT JOIN `#__js_job_counties` AS address_county ON app.address_county = address_county.code
				LEFT JOIN `#__js_job_states` AS address_state ON app.address_state = address_state.code 
				LEFT JOIN `#__js_job_countries` AS address_country ON app.address_country = address_country.code 
				LEFT JOIN `#__js_job_cities` AS institute_city ON app.institute_city = institute_city.code
				LEFT JOIN `#__js_job_counties` AS institute_county ON app.institute_county = institute_county.code
				LEFT JOIN `#__js_job_states` AS institute_state ON app.institute_state = institute_state.code 
				LEFT JOIN `#__js_job_countries` AS institute_country ON app.institute_country = institute_country.code 
				LEFT JOIN `#__js_job_cities` AS employer_city ON app.employer_city = employer_city.code
				LEFT JOIN `#__js_job_counties` AS employer_county ON app.employer_county = employer_county.code
				LEFT JOIN `#__js_job_states` AS employer_state ON app.employer_state = employer_state.code 
				LEFT JOIN `#__js_job_countries` AS employer_country ON app.employer_country = employer_country.code 
				WHERE app.id = ".$db->Quote($id);
		$db->setQuery($query);
		$this->_application = $db->loadObject();
		return $this->_application;
	}

	function &getResumeViewbyId($uid,$jobid,$id,$myresume)
	{
		
	//if (is_numeric($id) == false) return false;
		if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
		if ($jobid) if (is_numeric($jobid) == false) return false;
		$db = &$this->getDBO();

                if($myresume == 1){
                    
                    $query = "SELECT COUNT(id) FROM #__js_job_resume
                    WHERE uid = ".$uid ." AND id = ".$id;
                   
                    $db->setQuery( $query );
                    $total = $db->loadResult();
                        if ($total == 0)
                            $canview = 0;
                        else
                            $canview = 1;
                        
                }else{
                    $query = "SELECT package.viewresumeindetails, package.packageexpireindays, package.resumesearch, payment.created
                    FROM `#__js_job_employerpackages` AS package
                    JOIN `#__js_job_employerpaymenthistory` AS payment ON payment.packageid = package.id
                    WHERE payment.uid = ".$uid."
                    AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
					AND payment.transactionverified = 1 AND payment.status = 1";
                    //echo $query;
                    $db->setQuery($query);
                    $jobs = $db->loadObjectList();
                    $unlimited = 0;
                    $canview = 0;
                    $resumesearch = 0;

                    foreach($jobs AS $job){
                            if($unlimited == 0){
                                    if ($job->viewresumeindetails != -1){
                                            $viewresumeindetails = "";
                                            $viewresumeindetails = $viewresumeindetails + $job->viewresumeindetails;
                                            $resumesearch = $resumesearch + $job->resumesearch;
                                    }else $unlimited = 1;
                            }
                    }
                    if ($unlimited == 0){
                        if ($viewresumeindetails == 0) $canview = 0; //can not add new job
                            if($jobid != ''){
                                $query = "SELECT SUM(apply.resumeview) AS totalview
                                FROM `#__js_job_jobapply` AS apply
                                WHERE apply.jobid = ".$jobid;
                                $db->setQuery($query);
                                $totalview = $db->loadResult();
                                if ($viewresumeindetails >= $totalview) $canview = 1; //can not add new job
                                else $canview = 0;
                                if ($myresume == 3) $canview = 1; // search resume
                            }else{
                                if($resumesearch > 0)$canview = 1; else $canview = 0;
                            }

                    }elseif ($unlimited == 1) $canview = 1; // unlimited
                }
                if ($canview == 0){ // check already view this resume
                            if($jobid != ''){
                                $query = "SELECT resumeview
                                FROM `#__js_job_jobapply` AS apply
                                WHERE apply.jobid = ".$jobid ." AND cvid = ".$id;

                                $db->setQuery($query);
                                $apply = $db->loadObject();
                                if ($apply->resumeview == 1) $canview = 1; //already view this resume
                                else $canview = 0;
                            }else $canview = 0;

                }
                if ($canview == 1){
						
                        if (is_numeric($id) == false) return false;
                            //echo '<br> Table';

                            $query = "SELECT app.* , cat.cat_title AS categorytitle, salary.rangestart, salary.rangeend, jobtype.title AS jobtypetitle
                                        ,heighesteducation.title AS heighesteducationtitle
                                        , nationality_country.name AS nationalitycountry
                                        , address_city.name AS address_city2 , address_county.name AS address_county2 , address_state.name AS address_state2 , address_country.name AS address_country
                                        , address1_city.name AS address1_city2 , address1_county.name AS address1_county2 , address1_state.name AS address1_state2 , address1_country.name AS address1_country
                                        , address2_city.name AS address2_city2 , address2_county.name AS address2_county2 , address2_state.name AS address2_state2 , address2_country.name AS address2_country
                                        , currency.symbol

                                        FROM `#__js_job_resume` AS app
                                        JOIN `#__js_job_categories` AS cat ON app.job_category = cat.id
                                        JOIN `#__js_job_jobtypes` AS jobtype ON app.jobtype = jobtype.id
                                        LEFT JOIN `#__js_job_heighesteducation` AS heighesteducation ON app.heighestfinisheducation = heighesteducation.id
                                        LEFT JOIN `#__js_job_countries` AS nationality_country ON app.nationality = nationality_country.code
                                        LEFT JOIN `#__js_job_salaryrange` AS salary ON app.jobsalaryrange = salary.id
                                        LEFT JOIN `#__js_job_cities` AS address_city ON app.address_city = address_city.code
                                        LEFT JOIN `#__js_job_counties` AS address_county ON app.address_county = address_county.code
                                        LEFT JOIN `#__js_job_states` AS address_state ON app.address_state = address_state.code
                                        LEFT JOIN `#__js_job_countries` AS address_country ON app.address_country = address_country.code
                                        LEFT JOIN `#__js_job_cities` AS address1_city ON app.address1_city = address1_city.code
                                        LEFT JOIN `#__js_job_counties` AS address1_county ON app.address1_county = address1_county.code
                                        LEFT JOIN `#__js_job_states` AS address1_state ON app.address1_state = address1_state.code
                                        LEFT JOIN `#__js_job_countries` AS address1_country ON app.address1_country = address1_country.code
                                        LEFT JOIN `#__js_job_cities` AS address2_city ON app.address2_city = address2_city.code
                                        LEFT JOIN `#__js_job_counties` AS address2_county ON app.address2_county = address2_county.code
                                        LEFT JOIN `#__js_job_states` AS address2_state ON app.address2_state = address2_state.code
                                        LEFT JOIN `#__js_job_countries` AS address2_country ON app.address2_country = address2_country.code
                                        LEFT JOIN `#__js_job_currencies` AS currency ON currency.id = app.currencyid

                                        WHERE app.id = ". $id ;
                                //echo '<br> sql '.$query;
                                $query2 = "SELECT app.id
                                            , institute_city.name AS institute_city2 , institute_county.name AS institute_county2 , institute_state.name AS institute_state2 , institute_country.name AS institute_country
                                            , institute1_city.name AS institute1_city2 , institute1_county.name AS institute1_county2 , institute1_state.name AS institute1_state2 , institute1_country.name AS institute1_country
                                            , institute2_city.name AS institute2_city2 , institute2_county.name AS institute2_county2 , institute2_state.name AS institute2_state2 , institute2_country.name AS institute2_country
                                            , institute3_city.name AS institute3_city2 , institute3_county.name AS institute3_county2 , institute3_state.name AS institute3_state2 , institute3_country.name AS institute3_country

                                            , employer_city.name AS employer_city2 , employer_county.name AS employer_county2 , employer_state.name AS employer_state2 , employer_country.name AS employer_country
                                            , employer1_city.name AS employer1_city2 , employer1_county.name AS employer1_county2 , employer1_state.name AS employer1_state2 , employer1_country.name AS employer1_country
                                            , employer2_city.name AS employer2_city2 , employer2_county.name AS employer2_county2 , employer2_state.name AS employer2_state2 , employer2_country.name AS employer2_country
                                            , employer3_city.name AS employer3_city2 , employer3_county.name AS employer3_county2 , employer3_state.name AS employer3_state2 , employer3_country.name AS employer3_country

                                            FROM `#__js_job_resume` AS app

                                            LEFT JOIN `#__js_job_cities` AS institute_city ON app.institute_city = institute_city.code
                                            LEFT JOIN `#__js_job_counties` AS institute_county ON app.institute_county = institute_county.code
                                            LEFT JOIN `#__js_job_states` AS institute_state ON app.institute_state = institute_state.code
                                            LEFT JOIN `#__js_job_countries` AS institute_country ON app.institute_country = institute_country.code

                                            LEFT JOIN `#__js_job_cities` AS institute1_city ON app.institute1_city = institute1_city.code
                                            LEFT JOIN `#__js_job_counties` AS institute1_county ON app.institute1_county = institute1_county.code
                                            LEFT JOIN `#__js_job_states` AS institute1_state ON app.institute1_state = institute1_state.code
                                            LEFT JOIN `#__js_job_countries` AS institute1_country ON app.institute1_country = institute1_country.code
                                            LEFT JOIN `#__js_job_cities` AS institute2_city ON app.institute2_city = institute2_city.code
                                            LEFT JOIN `#__js_job_counties` AS institute2_county ON app.institute2_county = institute2_county.code
                                            LEFT JOIN `#__js_job_states` AS institute2_state ON app.institute2_state = institute2_state.code
                                            LEFT JOIN `#__js_job_countries` AS institute2_country ON app.institute2_country = institute2_country.code
                                            LEFT JOIN `#__js_job_cities` AS institute3_city ON app.institute3_city = institute3_city.code
                                            LEFT JOIN `#__js_job_counties` AS institute3_county ON app.institute3_county = institute3_county.code
                                            LEFT JOIN `#__js_job_states` AS institute3_state ON app.institute3_state = institute3_state.code
                                            LEFT JOIN `#__js_job_countries` AS institute3_country ON app.institute3_country = institute3_country.code


                                            LEFT JOIN `#__js_job_cities` AS employer_city ON app.employer_city = employer_city.code
                                            LEFT JOIN `#__js_job_counties` AS employer_county ON app.employer_county = employer_county.code
                                            LEFT JOIN `#__js_job_states` AS employer_state ON app.employer_state = employer_state.code
                                            LEFT JOIN `#__js_job_countries` AS employer_country ON app.employer_country = employer_country.code
                                            LEFT JOIN `#__js_job_cities` AS employer1_city ON app.employer1_city = employer1_city.code
                                            LEFT JOIN `#__js_job_counties` AS employer1_county ON app.employer1_county = employer1_county.code
                                            LEFT JOIN `#__js_job_states` AS employer1_state ON app.employer1_state = employer1_state.code
                                            LEFT JOIN `#__js_job_countries` AS employer1_country ON app.employer1_country = employer1_country.code
                                            LEFT JOIN `#__js_job_cities` AS employer2_city ON app.employer2_city = employer2_city.code
                                            LEFT JOIN `#__js_job_counties` AS employer2_county ON app.employer2_county = employer2_county.code
                                            LEFT JOIN `#__js_job_states` AS employer2_state ON app.employer2_state = employer2_state.code
                                            LEFT JOIN `#__js_job_countries` AS employer2_country ON app.employer2_country = employer2_country.code
                                            LEFT JOIN `#__js_job_cities` AS employer3_city ON app.employer3_city = employer3_city.code
                                            LEFT JOIN `#__js_job_counties` AS employer3_county ON app.employer3_county = employer3_county.code
                                            LEFT JOIN `#__js_job_states` AS employer3_state ON app.employer3_state = employer3_state.code
                                            LEFT JOIN `#__js_job_countries` AS employer3_country ON app.employer3_country = employer3_country.code

                                            WHERE app.id = ". $id ;

							$db->setQuery( 'SET SQL_BIG_SELECTS=1');
							$db->query();

							$db->setQuery($query);
							$resume = $db->loadObject();

                            $db->setQuery($query2);
							$resume2 = $db->loadObject();
							$result[0] = $resume;
							$result[1] = $resume2;
							$result[2] = $this->getResumeViewbyId3($id);
						$coverletter = null;
                        if($myresume != 1){
							if($jobid){
								$query = "UPDATE `#__js_job_jobapply` SET resumeview = 1 WHERE jobid = ".$jobid." AND cvid = ".$id;
								$db->setQuery( $query );
								$db->query();

								//Select the cover letter id
								$query = "SELECT cl.coverletterid,cl.apply_date FROM `#__js_job_jobapply` AS cl WHERE cl.jobid = ".$jobid." AND cl.cvid = ".$id;
								$db->setQuery( $query );
								$coverletter = $db->loadObject();
							}

							$query = "UPDATE `#__js_job_resume` SET hits = hits + 1 WHERE id = ".$id;
						   
							$db->setQuery( $query );
							if (!$db->query()) {
							
									//return false;
							}
						}
                        $result[3] = $this->getFieldsOrdering(3); // resume fields
                        $result[4] = 1; // can view
                        $result[5] = $coverletter;
                }else{
                       $result[4] = 0; // can not view
                }
		return $result;
		
	}

	function &getResumeViewbyId3($id) 
	{
		if (is_numeric($id) == false) return false;
		$db = &$this->getDBO();
		$query = "SELECT app.id
				, reference_city.name AS reference_city2 , reference_county.name AS reference_county2 , reference_state.name AS reference_state2 , reference_country.name AS reference_country 
				, reference1_city.name AS reference1_city2 , reference1_county.name AS reference1_county2 , reference1_state.name AS reference1_state2 , reference1_country.name AS reference1_country 
				, reference2_city.name AS reference2_city2 , reference2_county.name AS reference2_county2 , reference2_state.name AS reference2_state2 , reference2_country.name AS reference2_country 
				, reference3_city.name AS reference3_city2 , reference3_county.name AS reference3_county2 , reference3_state.name AS reference3_state2 , reference3_country.name AS reference3_country 

				FROM `#__js_job_resume` AS app 
				
				

				LEFT JOIN `#__js_job_cities` AS reference_city ON app.reference_city = reference_city.code
				LEFT JOIN `#__js_job_counties` AS reference_county ON app.reference_county = reference_county.code
				LEFT JOIN `#__js_job_states` AS reference_state ON app.reference_state = reference_state.code 
				LEFT JOIN `#__js_job_countries` AS reference_country ON app.reference_country = reference_country.code 
				LEFT JOIN `#__js_job_cities` AS reference1_city ON app.reference1_city = reference1_city.code
				LEFT JOIN `#__js_job_counties` AS reference1_county ON app.reference1_county = reference1_county.code
				LEFT JOIN `#__js_job_states` AS reference1_state ON app.reference1_state = reference1_state.code 
				LEFT JOIN `#__js_job_countries` AS reference1_country ON app.reference1_country = reference1_country.code 
				LEFT JOIN `#__js_job_cities` AS reference2_city ON app.reference2_city = reference2_city.code
				LEFT JOIN `#__js_job_counties` AS reference2_county ON app.reference2_county = reference2_county.code
				LEFT JOIN `#__js_job_states` AS reference2_state ON app.reference2_state = reference2_state.code 
				LEFT JOIN `#__js_job_countries` AS reference2_country ON app.reference2_country = reference2_country.code 
				LEFT JOIN `#__js_job_cities` AS reference3_city ON app.reference3_city = reference3_city.code
				LEFT JOIN `#__js_job_counties` AS reference3_county ON app.reference3_county = reference3_county.code
				LEFT JOIN `#__js_job_states` AS reference3_state ON app.reference3_state = reference3_state.code 
				LEFT JOIN `#__js_job_countries` AS reference3_country ON app.reference3_country = reference3_country.code 

				WHERE app.id = ". $id ;
		$db->setQuery($query);
		$resume = $db->loadObject();
		return $resume;
	}

	function storeCoverLetter()
	{
		global $resumedata;
		$row = &$this->getTable('coverletter');
		$data = JRequest :: get('post');


		if (!$row->bind($data)){
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		if (!$row->check())	{
			$this->setError($this->_db->getErrorMsg());
			return 2;
		}
		if (!$row->store())	{
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		return true;
	}

	function storeFilter()
	{
		global $resumedata;
		$user	=& JFactory::getUser();
		$row = &$this->getTable('filter');
		$data = JRequest :: get('post');

		$data['uid'] = $user->id;
		$data['status'] = 1;
		if (!$row->bind($data)){
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		if ($data['txtfilter_country'] == 'Country') $data['txtfilter_country'] = '';
		if ($data['txtfilter_state'] == 'State') $data['txtfilter_state'] = '';
		if ($data['txtfilter_county'] == 'County') $data['txtfilter_county'] = '';
		if ($data['txtfilter_city'] == 'City') $data['txtfilter_city'] = '';

                if ($data['cmbfilter_country'] != '') { $row->country = $data['cmbfilter_country']; $row->country_istext = 0;}
		elseif ($data['txtfilter_country'] != '') { $row->country = $data['txtfilter_country']; $row->country_istext = 1;}
		if ($data['cmbfilter_state'] != '') { $row->state = $data['cmbfilter_state']; $row->state_istext = 0;}
		elseif ($data['txtfilter_state'] != '') { $row->state = $data['txtfilter_state']; $row->state_istext = 1;}
		if ($data['cmbfilter_county'] != '') { $row->county = $data['cmbfilter_county']; $row->county_istext = 0;}
		elseif ($data['txtfilter_county'] != '') { $row->county = $data['txtfilter_county']; $row->county_istext = 1;}
		if ($data['cmbfilter_city'] != '') { $row->city = $data['cmbfilter_city']; $row->city_istext = 0;}
		elseif ($data['txtfilter_city'] != '') { $row->city = $data['txtfilter_city']; $row->city_istext = 1;}

		//echo 'cat '. $data['filter_jobcategory'];
		$row->category = $data['filter_jobcategory'];
		$row->jobtype = $data['filter_jobtype'];
		$row->salaryrange = $data['filter_jobsalaryrange'];
		$row->heighesteducation = $data['filter_heighesteducation'];

		if (!$row->store())	{
			$this->setError($this->_db->getErrorMsg());
			echo $this->_db->getErrorMsg();
			return false;
		}
		return true;
	}

	function storeJobSearch($data)
	{
		global $resumedata;
		$row = &$this->getTable('jobsearch');
		
		if (!$row->bind($data)){
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		$returnvalue = $this->canAddNewJobSearch($data['uid']);
		if ($returnvalue == 0) return 3; //not allowed save new search
		if (!$row->store())	{
			$this->setError($this->_db->getErrorMsg());
			echo $this->_db->getErrorMsg();
			return false;
		}
		return true;
	}

	function storeResumeSearch($data)
	{
		global $resumedata;
		$row = &$this->getTable('resumesearch');
		//$data = JRequest :: get('post');
		
		$data['date_start'] =  date('Y-m-d H:i:s',strtotime($data['date_start']));
		
		if (!$row->bind($data)){
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		$returnvalue = $this->canAddNewResumeSearch($data['uid']);
		
		if ($returnvalue == 0) return 3; //not allowed save new search
		if (!$row->store())	{
			$this->setError($this->_db->getErrorMsg());
			echo $this->_db->getErrorMsg();
			return false;
		}
		return true;
	}

	function canAddNewJobSearch($uid) 
	{
		if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
		$db = &$this->getDBO();
		$query = "SELECT COUNT(search.id) AS totalsearches, role.savesearchjob
		FROM `#__js_job_roles` AS role
		JOIN `#__js_job_userroles` AS userrole ON userrole.role = role.id
		LEFT JOIN `#__js_job_jobsearches` AS search ON userrole.uid = search.uid 
		WHERE userrole.uid = ".$uid." GROUP BY role.savesearchjob";
		//echo $query;
		$db->setQuery($query);
		$job = $db->loadObject();
		if ($job){
			if ($job->savesearchjob == -1) return 1;
			else{
					if ($job->totalsearch < $job->savesearchjob ) return 1;
					else return 0;
				}
		}
		return 0;
	}

	function canAddNewResumeSearch($uid) 
	{
		if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
		$db = &$this->getDBO();
		$query = "SELECT COUNT(search.id) AS totalsearches, role.savesearchresume
		FROM `#__js_job_roles` AS role
		JOIN `#__js_job_userroles` AS userrole ON userrole.role = role.id
		LEFT JOIN `#__js_job_resumesearches` AS search ON userrole.uid = search.uid 
		WHERE userrole.uid = ".$uid." GROUP BY role.savesearchresume ";
		//echo $query;
		$db->setQuery($query);
		$resume = $db->loadObject();
		if ($resume){
			if ($resume->savesearchresume == -1) return 1;
			else{
					if ($resume->totalsearch < $resume->savesearchresume ) return 1;
					else return 0;
				}
		}
		return 0;
	}

	function deleteUserFilter()
	{
		$row = &$this->getTable('filter');
		$data = JRequest :: get('post');
		
		if (!$row->delete($data['id']))
		{
			$this->setError($row->getErrorMsg());
			return false;
		}

		return true;
	}
	
	function deleteJobSearch($searchid, $uid)
	{
		$db = &$this->getDBO();
		$row = &$this->getTable('jobsearch');

		if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
		if (is_numeric($searchid) == false) return false;

		$query = "SELECT COUNT(search.id) FROM `#__js_job_jobsearches` AS search  
					WHERE search.id = ".$searchid." AND search.uid = ".$uid;
		$db->setQuery($query);
		$searchtotal = $db->loadResult();
		
		if ($searchtotal > 0){ // this search is same user
		
			if (!$row->delete($searchid))
			{
				$this->setError($row->getErrorMsg());
				return false;
			}
		}else return 2;	

		return true;
	}
	
	function deleteResumeSearch($searchid, $uid)
	{
		
		$db = &$this->getDBO();
		$row = &$this->getTable('resumesearch');
		if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
		if (is_numeric($searchid) == false) return false;

		$query = "SELECT COUNT(search.id) FROM `#__js_job_resumesearches` AS search  
					WHERE search.id = ".$searchid." AND search.uid = ".$uid;
		$db->setQuery($query);
		$searchtotal = $db->loadResult();
		
		if ($searchtotal > 0){ // this search is same user
		
			if (!$row->delete($searchid))
			{
				$this->setError($row->getErrorMsg());
				return false;
			}
		}else return 2;	

		return true;
	}
	
	function deleteCoverLetter($coverletterid, $uid)
	{
		$db = &$this->getDBO();
		$row = &$this->getTable('coverletter');
		if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
		if (is_numeric($coverletterid) == false) return false;

		$query = "SELECT COUNT(letter.id) FROM `#__js_job_coverletters` AS letter  
					WHERE letter.id = ".$coverletterid." AND letter.uid = ".$uid;
		$db->setQuery($query);
		$total = $db->loadResult();
		
		if ($total > 0){ // this search is same user
		
			if (!$row->delete($coverletterid))
			{
				$this->setError($row->getErrorMsg());
				return false;
			}
		}else return 2;	

		return true;
	}

	
	function deleteResume($resumeid, $uid)
	{
		$row = &$this->getTable('resume');
		$data = JRequest :: get('post');
		
		if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
		if (is_numeric($resumeid) == false) return false;
		$returnvalue = $this->resumeCanDelete($resumeid, $uid);
		if( $returnvalue == 1){
			if (!$row->delete($resumeid))	{
				$this->setError($row->getErrorMsg());
				return false;
			}
		}else return $returnvalue;	

		return true;
	}

	function deleteJob($jobid, $uid,$vis_email,$vis_jobid)
	{
		$row = &$this->getTable('job');
		//$data = JRequest :: get('post');
                if(($vis_email == '') || ($vis_jobid == '')){ // if jobseeker try to delete their job
                    if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
                    if (is_numeric($jobid) == false) return false;
                }
		$returnvalue = $this->jobCanDelete($jobid, $uid,$vis_email,$vis_jobid);
		if( $returnvalue == 1){
                    if(($vis_email == '') || ($vis_jobid == '')){ // if jobseeker try to delete their job
			if (!$row->delete($jobid)){
				$this->setError($row->getErrorMsg());
				return false;
			}
                    }else{
        		$db = &$this->getDBO();
                        $query = "DELETE FROM `#__js_job_jobs` WHERE jobid = ".$db->quote($vis_jobid);
                        $db->setQuery($query);
                        if(!$db->query()){
                            return false;
                        }
                    }
		}else return $returnvalue;	

		return true;
	}

	function jobCanDelete($jobid, $uid,$vis_email,$vis_jobid){
		if (is_numeric($uid) == false) return false;
		$db = &$this->getDBO();
		if($jobid) if (is_numeric($jobid) == false) return false;
                if((isset($vis_email) && $vis_email != '') && (isset($vis_jobid) && $vis_jobid != ''))
                    $query = "SELECT COUNT(job.id) FROM `#__js_job_jobs` AS job
                                JOIN `#__js_job_companies` AS company ON company.id = job.companyid AND company.contactemail = ".$db->quote($vis_email)."
                                WHERE job.jobid = ".$db->quote($vis_jobid);
                else
                    $query = "SELECT COUNT(job.id) FROM `#__js_job_jobs` AS job
                                WHERE job.id = ".$jobid." AND job.uid = ".$uid;
		$db->setQuery($query);
		$jobtotal = $db->loadResult();
		
		if ($jobtotal > 0){ // this job is same user

                        $query = "SELECT COUNT(apply.id) FROM `#__js_job_jobapply` AS apply
                                    WHERE apply.jobid = ".$jobid;

                        $query = "SELECT
                                    ( SELECT COUNT(id) FROM `#__js_job_jobapply` WHERE jobid = ". $jobid .")
                                    + ( SELECT COUNT(id) FROM `#__js_job_featuredjobs` WHERE jobid = ". $jobid .")
                                    + ( SELECT COUNT(id) FROM `#__js_job_goldjobs` WHERE jobid = ". $jobid .")
                                    + ( SELECT COUNT(id) FROM `#__js_job_shortlistcandidates` WHERE jobid = ". $jobid .")
                                    AS total ";
				$db->setQuery($query);
			$total = $db->loadResult();
				
				if ($total > 0)
					return 2;
				else
					return 1;
		}else return 3; // 	this job is not of this user		
		
		
	}

	function jobEnforceDelete($jobid, $uid){ // this function may not use
		if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
		if (is_numeric($jobid) == false) return false;
		$db = &$this->getDBO();

		$query = "SELECT COUNT(job.id) FROM `#__js_job_jobs` AS job  
					WHERE job.id = ".$jobid." AND job.uid = ".$uid;
		$db->setQuery($query);
		$jobtotal = $db->loadResult();
		
		if ($jobtotal > 0){ // this job is same user

			$query = "DELETE FROM `#__js_job_jobapply` AS apply  
					  WHERE apply.jobid = ".$jobid;
				$db->setQuery($query);
			if (!$db->query()) {
                 return 2; //error while delete job
            }
			return 1;
		}else return 3; // 	this job is not of this user		
	}

	function resumeCanDelete($resumeid, $uid){
		if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
		$db = &$this->getDBO();

		$query = "SELECT COUNT(resume.id) FROM `#__js_job_resume` AS resume  
					WHERE resume.id = ".$resumeid." AND resume.uid = ".$uid;
		$db->setQuery($query);
		$resumetotal = $db->loadResult();
		
		if ($resumetotal > 0){ // this resume is same user
			$query = "SELECT 
					( SELECT COUNT(id) FROM `#__js_job_jobapply` WHERE cvid = ". $resumeid .") 
					+ ( SELECT COUNT(id) FROM `#__js_job_shortlistcandidates` WHERE cvid = ". $resumeid .")
					+ ( SELECT COUNT(id) FROM `#__js_job_featuredresumes` WHERE resumeid = ". $resumeid .") 
					+ ( SELECT COUNT(id) FROM `#__js_job_goldresumes` WHERE resumeid = ". $resumeid .")
					AS total ";
				$db->setQuery($query);
			$total = $db->loadResult();
				
                        if ($total > 0)
                                return 2;
                        else
                                return 1;
		}else return 3; // 	this resume is not of this user		
	}

	
	function storeResume($jobid)
	{
		global $resumedata;
		if($jobid) if ((is_numeric($jobid) == false) || ($jobid == 0) || ($jobid == '')) return false;
		$row = &$this->getTable('resume');
		$resumedata = JRequest :: get('post');
	//	if ( !$resumedata['id'] ){
			if ( !$this->_config )
				$this->getConfig('');
			foreach ($this->_config as $conf){
				if ($conf->configname == 'empautoapprove')
					if ( !$resumedata['id'] ) $resumedata['status'] = $conf->configvalue;
				if ($conf->configname == 'resume_photofilesize')
					$photofilesize = $conf->configvalue;
				if ($conf->configname == 'date_format') $dateformat = $conf->configvalue;
			}
	//	}
		//spam checking
		$config = $this->getConfigByFor('default');
		if($resumedata['uid'] == 0 && $config['resume_captcha'] == 1)
		   if(!$this->performChecks()){
				$result= 8;
				return $result;
	       }


		if($dateformat == 'm-d-Y'){
			if($resumedata['date_start'] != ''){
			$arr = explode('-', $resumedata['date_start']);
			$data['date_start'] =  $arr[0].'/'.$arr[1].'/'.$arr[2];
			}
			if($resumedata['date_of_birth'] != ''){
			$arr = explode('-', $resumedata['date_of_birth']);
			$resumedata['date_of_birth'] =  $arr[0].'/'.$arr[1].'/'.$arr[2];
			}
		}elseif($dateformat == 'd-m-Y'){
			if($resumedata['date_start'] != ''){
			$arr = explode('-', $resumedata['date_start']);
			$resumedata['date_start'] =  $arr[2].'-'.$arr[1].'-'.$arr[0];
			}
			if($resumedata['date_of_birth'] != ''){
			$arr = explode('-', $resumedata['date_of_birth']);
			$resumedata['date_of_birth'] =  $arr[2].'-'.$arr[1].'-'.$arr[0];
			}
		}
		if($resumedata['date_start'] != ''){
			$resumedata['date_start'] =  date('Y-m-d H:i:s',strtotime($resumedata['date_start']));	
		}
		if($resumedata['date_of_birth'] != ''){
			$resumedata['date_of_birth'] =  date('Y-m-d H:i:s',strtotime($resumedata['date_of_birth']));	
		}
	 
		$resumedata['resume'] = JRequest::getVar('resume', '', 'post', 'string', JREQUEST_ALLOWRAW);
		if($_FILES['photo']['size'] > 0){
			$uploadfilesize = $_FILES['photo']['size'];
			$uploadfilesize = $uploadfilesize / 1024; //kb
			if($uploadfilesize > $photofilesize){ // logo
				return 7; // file size error	
			}	
		}		

		if($_FILES['resumefile']['size'] > 0){
			$file_name = $_FILES['resumefile']['name']; // file name
			$file_size = $_FILES['resumefile']['size']; // file size
			$file_type = $_FILES['resumefile']['type']; // mime type of file determined by php

                        $resumedata['filename'] = $file_name;
                        $resumedata['filesize'] = $file_size;
                        $resumedata['filetype'] = $file_type;

			$resumedata['filecontent'] = '';
		}else {
			if ($resumedata['deleteresumefile'] == 1){
				$resumedata['filename'] = '';
				$resumedata['filecontent'] = '';
			}
		}		
		if($_FILES['photo']['size'] > 0){
			$file_name = $_FILES['photo']['name']; // file name
			$resumedata['photo'] = $file_name;
		}else {
			if ($resumedata['deletephoto'] == 1){
				$resumedata['photo'] = '';
			}	
		}
//		if ($returnvalue != 1)
//			return $returnvalue;

		if (!$row->bind($resumedata))
		{
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		
		if (!$row->check())
		{
			$this->setError($this->_db->getErrorMsg());
			return 2;
		}

		if (!$row->store())
		{
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		
		$resumereturnvalue = $this->uploadResume($row->id);
		if($resumereturnvalue != 1){
			$resumedeletedata['id'] = $row->id;		
			$resumedeletedata['filename'] = '';
			$row->bind($resumedeletedata);
			$row->store();
		}
		$returnvalue = $this->uploadPhoto($row->id);
		if($returnvalue != 1){
			$resumedeletedata['id'] = $row->id;		
			$resumedeletedata['photo'] = '';
			$row->bind($resumedeletedata);
			$row->store();
		}
		if($jobid)$returnvalue = $this->visitorJobApply($jobid,$row->id);
		if($resumedata['id'] == '') $this->sendMailtoAdmin($row_id,$data['uid'],3);//only for new

		return $resumereturnvalue;
	}

	function uploadResume($id)
	{

                if (is_numeric($id) == false) return false;
		global $resumedata ;
		$db =& JFactory::getDBO();
		//$resumequery = "SELECT * FROM `#__js_job_resume`
		//WHERE uid = ".$db->Quote($u_id);
		//echo '<br>sql '.$resumequery;
		$iddir = 'resume_'.$id;
                if(! isset($this->_config)) $this->getConfig('');
                foreach ($this->_config as $conf){
                        if ($conf->configname == 'data_directory') $datadirectory = $conf->configvalue;
                }
		if($_FILES['resumefile']['size'] > 0){
			$file_name = $_FILES['resumefile']['name']; // file name
			$file_tmp = $_FILES['resumefile']['tmp_name']; // actual location
			$file_size = $_FILES['resumefile']['size']; // file size
			$file_type = $_FILES['resumefile']['type']; // mime type of file determined by php
			$file_error = $_FILES['resumefile']['error']; // any error!. get reason here

			if( !empty($file_tmp)){	// only MS office and text file is accepted.
				$ext = $this->getExtension($file_name);
				if (($ext != "txt") && ($ext != "doc") && ($ext != "docx") && ($ext != "pdf") && ($ext != "opt") && ($ext != "rtf"))
					return 6; //file type mistmathc
/*
				if( !(($file_type=="application/msword") || ($file_type=="text/plain")) )
				{
					return 6; //file type mistmathc
				}
*/			}

                        $path =JPATH_BASE.'/'.$datadirectory;
			//$path =JPATH_BASE.'/components/com_jsjobs';
			if (!file_exists($path)){ // creating resume directory
				//mkdir($path, 0755);
				$this->makeDir($path);
			}
			$path= $path . '/data';
			if (!file_exists($path)){ // create user directory
				//mkdir($path, 0755);
				$this->makeDir($path);
			}
			$path= $path . '/jobseeker';
			if (!file_exists($path)){ // create user directory
				//mkdir($path, 0755);
				$this->makeDir($path);
			}
			$userpath= $path . '/'.$iddir;
			if (!file_exists($userpath)){ // create user directory
				//mkdir($userpath, 0755);
				$this->makeDir($userpath);
			}
			$userpath= $path . '/'.$iddir.'/resume';
			if (!file_exists($userpath)){ // create user directory
				//mkdir($userpath, 0755);
				$this->makeDir($userpath);
			}
			$files = glob($userpath.'/*.*');
			array_map('unlink', $files);  //delete all file in user directory
			
			move_uploaded_file($file_tmp, $userpath.'/' . $file_name);
			//unlink($file_tmp);
			
//			$resumedata['filename'] = $file_name;
//			$resumedata['filecontent'] = '';
			return 1;
		}else {
			if ($resumedata['deleteresumefile'] == 1){
                                $path =JPATH_BASE.'/'.$datadirectory.'/data/jobseeker';
				//$path =JPATH_BASE.'/components/com_jsjobs/data/jobseeker';
				$userpath= $path . '/'.$iddir.'/resume';
				$files = glob($userpath.'/*.*');
				array_map('unlink', $files);
				$resumedata['filename'] = '';
				$resumedata['filecontent'] = '';
			}else{
//				$db->setQuery( $resumequery );
//				$resume = $db->loadObject();
//				if ( isset($resume) ){ // if already file upload then pick the path
//						$resumedata['filename'] = $resume->filename;
//						$resumedata['filecontent'] = '';
//				}
			}
			return 1;
		}

	}


	function uploadPhoto($id)
	{
		if (is_numeric($id) == false) return false;
		global $resumedata ;
		$db =& JFactory::getDBO();
		$resumequery = "SELECT * FROM `#__js_job_resume`
		WHERE uid = ".$db->Quote($u_id);
		//echo '<br>sql '.$resumequery;
		$iddir = 'resume_'.$id;
                if(! isset($this->_config)) $this->getConfig('');
                foreach ($this->_config as $conf){
                        if ($conf->configname == 'data_directory') $datadirectory = $conf->configvalue;
                }
		if($_FILES['photo']['size'] > 0){
			$file_name = $_FILES['photo']['name']; // file name
			$file_tmp = $_FILES['photo']['tmp_name']; // actual location
			$file_size = $_FILES['photo']['size']; // file size
			$file_type = $_FILES['photo']['type']; // mime type of file determined by php
			$file_error = $_FILES['photo']['error']; // any error!. get reason here

			if( !empty($file_tmp)){	
				$ext = $this->getExtension($file_name);
				if (($ext != "gif") && ($ext != "jpg") && ($ext != "jpeg") && ($ext != "png"))
					return 6; //file type mistmathc
			}

                        $path =JPATH_BASE.'/'.$datadirectory;
			//$path =JPATH_BASE.'/components/com_jsjobs';
			if (!file_exists($path)){ // creating resume directory
				//mkdir($path, 0755);
				$this->makeDir($path);
			}
			$path = $path.'/data';
			if (!file_exists($path)){ // creating resume directory
				//mkdir($path, 0755);
				$this->makeDir($path);
			}
			$path = $path.'/jobseeker';
			if (!file_exists($path)){ // creating resume directory
				//mkdir($path, 0755);
				$this->makeDir($path);
			}
			$userpath= $path . '/'.$iddir;
			if (!file_exists($userpath)){ // create user directory
				//mkdir($userpath, 0755);
				$this->makeDir($userpath);
			}
			$userpath= $path . '/'.$iddir.'/photo';
			if (!file_exists($userpath)){ // create user directory
				//mkdir($userpath, 0755);
				$this->makeDir($userpath);
			}
			$files = glob($userpath.'/*.*');
			array_map('unlink', $files);  //delete all file in user directory
			
			move_uploaded_file($file_tmp, $userpath.'/' . $file_name);
			//unlink($file_tmp);
			
//			$resumedata['photo'] = $file_name;
			return 1;
		}else {
			if ($resumedata['deletephoto'] == 1){
				//$path =JPATH_BASE.'/components/com_jsjobs/data/jobseeker';
                                $path =JPATH_BASE.'/'.$datadirectory.'/data/jobseeker';
				$userpath= $path . '/'.$iddir.'/photo';
				$files = glob($userpath.'/*.*');
				array_map('unlink', $files);
				$resumedata['photo'] = '';
			}else{
//				$db->setQuery( $resumequery );
//				$resume = $db->loadObject();
//				if ( isset($resume) ){ // if already file upload then pick the path
//						$resumedata['photo'] = $resume->filename;
//				}
			}
			return 1;
		}

	}


	function uploadFile($id, $action, $isdeletefile)
	{

                //echo '<br>upload file ';
		if (is_numeric($id) == false) return false;
		$db =& JFactory::getDBO();
		if(! isset($this->_config)) $this->getConfig('');
		foreach ($this->_config as $conf){
			if ($conf->configname == 'data_directory') $datadirectory = $conf->configvalue;
		}
                $path =JPATH_BASE.'/'.$datadirectory;
		if (!file_exists($path)){ // create user directory
			//mkdir($path, 0755);
			$this->makeDir($path);
		}
                //$path =JPATH_BASE.'/components/com_jsjobs';
		$isupload = false;
		$path= $path . '/data';
		if (!file_exists($path)){ // create user directory
			//mkdir($path, 0755);
			$this->makeDir($path);
		}
		$path= $path . '/employer';
		if (!file_exists($path)){ // create user directory
			//mkdir($path, 0755);
			$this->makeDir($path);
		}
		if ($action == 1) { //Company logo
			if($_FILES['logo']['size'] > 0){
				$file_name = $_FILES['logo']['name']; // file name
				$file_tmp = $_FILES['logo']['tmp_name']; // actual location
				
				$ext = $this->getExtension($file_name);
				$ext = strtolower($ext);
				if (($ext != "gif") && ($ext != "jpg") && ($ext != "jpeg") && ($ext != "png"))
					return 6; //file type mistmathc
					
				$userpath= $path . '/comp_'.$id;
				if (!file_exists($userpath)){ // create user directory
					//mkdir($userpath, 0755);
					$this->makeDir($userpath);
				}
				$userpath= $userpath. '/logo';
				if (!file_exists($userpath)){ // create logo directory
					//mkdir($userpath, 0755);
					$this->makeDir($userpath);
				}
				$isupload = true;
			}
		}elseif ($action == 2) { //Company small logo
			if($_FILES['smalllogo']['size'] > 0){
				$file_name = $_FILES['smalllogo']['name']; // file name
				$file_tmp = $_FILES['smalllogo']['tmp_name']; // actual location
				
				$ext = $this->getExtension($file_name);
				$ext = strtolower($ext);
				if (($ext != "gif") && ($ext != "jpg") && ($ext != "jpeg") && ($ext != "png"))
					return 6; //file type mistmathc
					
				$userpath= $path . '/comp_'.$id;
				if (!file_exists($userpath)){ // create user directory
					//mkdir($userpath, 0755);
					$this->makeDir($userpath);
				}
				$userpath= $userpath. '/smalllogo';
				if (!file_exists($userpath)){ // create logo directory
					//mkdir($userpath, 0755);
					$this->makeDir($userpath);
				}
				$isupload = true;
			}
		}elseif ($action == 3) { //About Company
			if($_FILES['aboutcompany']['size'] > 0){
				$file_name = $_FILES['aboutcompany']['name']; // file name
				$file_tmp = $_FILES['aboutcompany']['tmp_name']; // actual location
				
				$ext = $this->getExtension($file_name);
				$ext = strtolower($ext);
				if (($ext != "txt") && ($ext != "doc") && ($ext != "docx") && ($ext != "pdf") && ($ext != "opt") && ($ext != "rtf"))
					return 6; //file type mistmathc
					
				$userpath= $path . '/comp_'.$id;
				if (!file_exists($userpath)){ // create user directory
					//mkdir($userpath, 0755);
					$this->makeDir($userpath);
				}
				$userpath= $userpath. '/aboutcompany';
				if (!file_exists($userpath)){ // create logo directory
					//mkdir($userpath, 0755);
					$this->makeDir($userpath);
				}
				$isupload = true;
			}
	
		
		}
		
		if ($isupload){
			$files = glob($userpath.'/*.*');
			array_map('unlink', $files);  //delete all file in directory
			
			move_uploaded_file($file_tmp, $userpath.'/' . $file_name);
			//unlink($file_tmp);
			
			return 1;
		}else { // DELETE FILES
			if ($action == 1) { // company logo
				if ($isdeletefile == 1){
					$userpath= $path . '/comp_'.$id . '/logo';
					$files = glob($userpath.'/*.*');
					array_map('unlink', $files); // delete all file in the direcoty 
				}
			}elseif ($action == 2) { // company small logo
				if ($isdeletefile == 1){
					$userpath= $path . '/comp_'.$id . '/smalllogo';
					$files = glob($userpath.'/*.*');
					array_map('unlink', $files); // delete all file in the direcoty 
				}
			}elseif ($action == 3) { // about company 
				if ($isdeletefile == 1){
					$userpath= $path . '/comp_'.$id . '/aboutcompany';
					$files = glob($userpath.'/*.*');
					array_map('unlink', $files); // delete all file in the direcoty 
				}
			}
			return 1;
		}

	}

	function &listAddressData($data,$val)
	{
		$db = &$this->getDBO();
		// company used for data to get for visitor  form job
		if ($data=='country' || $data =="company_country") {  // country
			$query  = "SELECT code, name FROM `#__js_job_countries`  WHERE enabled = 'Y' ORDER BY name ASC";
			$db->setQuery($query);
			$result = $db->loadObjectList();

			if (empty($result))	{
                                if($data == 'company_country')
                                    $return_value = "<input class='inputbox' type='text' name='companycountry' size='20' maxlength='100'  />";
                                else
                                    $return_value = "<input class='inputbox' type='text' name='country' id='country' size='20' maxlength='100' onBlur= />";
			}else {
                                if($data == 'company_country')
                                    $return_value = "<select name='company_country' class='inputbox'  onChange=\"dochangecompany('company_state', this.value)\">\n";
                                else
                                    $return_value = "<select name='country' class='inputbox'  onChange=\"dochange('state', this.value);\">\n";

                                $return_value .= "<option value='0'>". JText::_('JS_CHOOSE_COUNTRY') ."</option>\n";

				foreach($result as $row){
			       $return_value .= "<option value=\"$row->code\" >$row->name</option> \n" ;
				}
				$return_value .= "</select>\n";
			}

		}elseif ($data=='state' || $data == 'company_state') {  // states
		    $query  = "SELECT code, name from `#__js_job_states`  WHERE enabled = 'Y' AND countrycode= ".$db->quote($val)." ORDER BY name ASC";
			$db->setQuery($query);
			$result = $db->loadObjectList();
			if (empty($result))	{
                                if($data == 'company_state')
                                    $return_value = "<input class='inputbox' type='text' name='companystate' size='20' maxlength='100'  />";
                                else
                                    $return_value = "<input class='inputbox' type='text' name='state' id='state' size='20' maxlength='100' onBlur= />";
			}else {
                                if($data == 'company_state')
                                    $return_value = "<select name='companystate' class='inputbox'  onChange=\"dochangecompany('company_county', this.value)\">\n";
                                else
                                    $return_value = "<select name='state' id='state'class='inputbox'  onChange=\"dochange('county', this.value);\">\n";
				$return_value .= "<option value='0'>". JText::_('JS_CHOOSE_STATE') ."</option>\n";

				foreach($result as $row){
					   $return_value .= "<option value=\"$row->code\" >$row->name</option> \n" ;
				}
				$return_value .= "</select>\n";
			}
		}elseif ($data=='county' || $data == 'company_county') {  // county
		    $query  = "SELECT code, name from `#__js_job_counties`  WHERE enabled = 'Y' AND statecode= ".$db->quote($val)." ORDER BY name ASC";
			$db->setQuery($query);
			$result = $db->loadObjectList();

			if (empty($result))
			{
                            if($data == 'company_county')
				$return_value = "<input class='inputbox' type='text' name='companycounty' size='20' maxlength='100'  />";
                            else
				$return_value = "<input class='inputbox' type='text' name='county' id='county' size='20' maxlength='100' onBlur= />";
			}else
			{
                            if($data == 'company_county')
				  $return_value = "<select name='companycounty' class='inputbox'  onChange=\"dochangecompany('company_city', this.value)\">\n";
                            else
				  $return_value = "<select name='county' id='county'class='inputbox'  onChange=\"dochange('city', this.value);\">\n";
				  $return_value .= "<option value='0'>". JText::_('JS_CHOOSE_COUNTY') ."</option>\n";
				  
				  
				  foreach($result as $row){
				       $return_value .= "<option value=\"$row->code\" >$row->name</option> \n" ;
				  }
				$return_value .= "</select>\n";
			}


		} elseif ($data=='city' || $data == 'company_city') { // city
		    $query  = "SELECT code, name from `#__js_job_cities`  WHERE enabled = 'Y' AND countycode= ".$db->quote($val)." ORDER BY 'name'";
			$db->setQuery($query);
			$result = $db->loadObjectList();
			//if (mysql_num_rows($result)== 0)
			if (empty($result))
			{
                            if($data == 'company_city')
				$return_value = "<input class='inputbox' type='text' name='companycity' size='20' maxlength='100'  />";
                            else
				$return_value = "<input class='inputbox' type='text' name='city' id='city' size='20' maxlength='100' onBlur= />";
			}else
			{
                            if($data == 'company_city')
				  $return_value = "<select name='company_city' class='inputbox'  onChange=\"dochangecompany('company_zipcode', this.value)\">\n";
                            else
				  $return_value = "<select name='city' id='city'class='inputbox'  onChange=\"\">\n";
				  $return_value .= "<option value='0'>". JText::_('JS_CHOOSE_CITY') ."</option>\n";
				  
				  
				  foreach($result as $row){
				       $return_value .= "<option value=\"$row->code\" >$row->name</option> \n" ;
				  }
				$return_value .= "</select>\n";
			}

		}
		return $return_value;
	}

	function &listSearchAddressData($data,$val)
	{
		$db = &$this->getDBO();

		if ($data=='country') {  // country
                        if($val == -1) $query  = "SELECT code, name FROM `#__js_job_countries` WHERE enabled = 'Y' ORDER BY name ASC";
                        else $query  = "SELECT code, name FROM `#__js_job_countries` WHERE enabled = 'Y' AND code= ".$db->quote($val)." ORDER BY name ASC";
			$db->setQuery($query);
			$result = $db->loadObjectList();

			if (empty($result))	{
				$return_value = "<input class='inputbox' type='text' name='country' size='40' maxlength='100'  />";
			}else {
				$return_value = "<select name='country' class='inputbox' onChange=\"dochange('state', this.value)\">\n";
				$return_value .= "<option value=''>".JText::_('JS_SEARCH_ALL')."</option>\n";

				foreach($result as $row){
			       $return_value .= "<option value=\"$row->code\" >$row->name</option> \n" ;
				}
				$return_value .= "</select>\n";
			}

		}else if ($data=='state') {  // states
		    $query  = "SELECT code, name from `#__js_job_states`  WHERE enabled = 'Y' AND countrycode= ".$db->quote($val)." ORDER BY name ASC";
			$db->setQuery($query);
			$result = $db->loadObjectList();
			if (empty($result))	{
				$return_value = "<input class='inputbox' type='text' name='state' size='40' maxlength='100'  />";
			}else {
				$return_value = "<select name='state' class='inputbox' onChange=\"dochange('county', this.value)\">\n";
				$return_value .= "<option value=''>".JText::_('JS_SEARCH_ALL')."</option>\n";

				foreach($result as $row){
					   $return_value .= "<option value=\"$row->code\" >$row->name</option> \n" ;
				}
				$return_value .= "</select>\n";
			}
		}else if ($data=='county') {  // county
		    $query  = "SELECT code, name from `#__js_job_counties`  WHERE enabled = 'Y' AND statecode= ".$db->quote($val)." ORDER BY name ASC";
			$db->setQuery($query);
			$result = $db->loadObjectList();

			if (empty($result))	{
				$return_value = "<input class='inputbox' type='text' name='county' size='40' maxlength='100'  />";
			}else
			{
				  $return_value = "<select name='county' class='inputbox' onChange=\"dochange('city', this.value)\">\n";
				  $return_value .= "<option value=''>".JText::_('JS_SEARCH_ALL')."</option>\n";
				  
				  
				  foreach($result as $row){
				       $return_value .= "<option value=\"$row->code\" >$row->name</option> \n" ;
				  }
				$return_value .= "</select>\n";
			}


		} else if ($data=='city') { // city
		    $query  = "SELECT code, name from `#__js_job_cities`  WHERE enabled = 'Y' AND countycode= ".$db->quote($val)." ORDER BY 'name'";
			$db->setQuery($query);
			$result = $db->loadObjectList();
			//if (mysql_num_rows($result)== 0)
			if (empty($result))	{
				$return_value = "<input class='inputbox' type='text' name='city' size='40' maxlength='100'  />";
			}else
			{
				  $return_value = "<select name='city' class='inputbox' onChange=\"dochange('zipcode', this.value)\">\n";
				  $return_value .= "<option value=''>".JText::_('JS_SEARCH_ALL')."</option>\n";
				  
				  
				  foreach($result as $row){
				       $return_value .= "<option value=\"$row->code\" >$row->name</option> \n" ;
				  }
				$return_value .= "</select>\n";
			}

		}
		return $return_value;
	}

	function &listModuleSearchAddressData($data,$val,$for)
	{
		$db = &$this->getDBO();
		$methodname = $for.'dochange';
		
		if ($data=='country') {  // country
			$query  = "SELECT code, name FROM `#__js_job_countries` WHERE enabled = 'Y' ORDER BY name ASC";
			$db->setQuery($query);
			$result = $db->loadObjectList();

			if (empty($result))	{
				$return_value = "<input class='inputbox' type='text' name='country' size='27' maxlength='100'  />";
			}else {
				$return_value = "<select name='country' class='inputbox'  onChange=\"$methodname('state', this.value)\">\n";
				$return_value .= "<option value=''>".JText::_('JS_SEARCH_ALL')."</option>\n";

				foreach($result as $row){
			       $return_value .= "<option value=\"$row->code\" >$row->name</option> \n" ;
				}
				$return_value .= "</select>\n";
			}

		}else if ($data=='state') {  // states
		    $query  = "SELECT code, name from `#__js_job_states`  WHERE enabled = 'Y' AND countrycode= ".$db->quote($val)." ORDER BY name ASC";
			$db->setQuery($query);
			$result = $db->loadObjectList();
			if (empty($result))	{
				$return_value = "<input class='inputbox' type='text' name='state' size='27' maxlength='100'  />";
			}else {
				$return_value = "<select name='state' class='inputbox'  onChange=\"$methodname('county', this.value)\">\n";
				$return_value .= "<option value=''>".JText::_('JS_SEARCH_ALL')."</option>\n";

				foreach($result as $row){
					   $return_value .= "<option value=\"$row->code\" >$row->name</option> \n" ;
				}
				$return_value .= "</select>\n";
			}
		}else if ($data=='county') {  // county
		    $query  = "SELECT code, name from `#__js_job_counties`  WHERE enabled = 'Y' AND statecode= ".$db->quote($val)." ORDER BY name ASC";
			$db->setQuery($query);
			$result = $db->loadObjectList();

			if (empty($result))	{
				$return_value = "<input class='inputbox' type='text' name='county' size='27' maxlength='100'  />";
			}else
			{
				  $return_value = "<select name='county' class='inputbox'  onChange=\"$methodname('city', this.value)\">\n";
				  $return_value .= "<option value=''>".JText::_('JS_SEARCH_ALL')."</option>\n";
				  
				  
				  foreach($result as $row){
				       $return_value .= "<option value=\"$row->code\" >$row->name</option> \n" ;
				  }
				$return_value .= "</select>\n";
			}


		} else if ($data=='city') { // city
		    $query  = "SELECT code, name from `#__js_job_cities`  WHERE enabled = 'Y' AND countycode= ".$db->quote($val)." ORDER BY 'name'";
			$db->setQuery($query);
			$result = $db->loadObjectList();
			//if (mysql_num_rows($result)== 0)
			if (empty($result))	{
				$return_value = "<input class='inputbox' type='text' name='city' size='27' maxlength='100'  />";
			}else
			{
				  $return_value = "<select name='city' class='inputbox'  onChange=\"$methodname('zipcode', this.value)\">\n";
				  $return_value .= "<option value=''>".JText::_('JS_SEARCH_ALL')."</option>\n";
				  
				  
				  foreach($result as $row){
				       $return_value .= "<option value=\"$row->code\" >$row->name</option> \n" ;
				  }
				$return_value .= "</select>\n";
			}

		}
		return $return_value;
	}

	function &listFilterAddressData($data,$val)
	{
		$db = &$this->getDBO();

		if(! isset($this->_config)){
			$this->getConfig('');
		}	
		foreach ($this->_config as $conf){
			if ($conf->configname == 'filter_address_fields_width')
				$address_fields_width = $conf->configvalue;
		}

		if ($data=='country') {  // country
			$query  = "SELECT code, name FROM `#__js_job_countries` WHERE enabled = 'Y' ORDER BY name ASC";
			$db->setQuery($query);
			$result = $db->loadObjectList();

			if (empty($result))	{
				$return_value = "<input class='inputbox' style='width:".$address_fields_width."px;color:#808080;' type='text' name='txtfilter_country' size='25' maxlength='50' value='Country' />";
			}else {
				$return_value = "<select name='cmbfilter_country' style='width:".$address_fields_width."px;' onChange=\"filter_dochange('filter_state', this.value)\">\n";
				$return_value .= "<option value=''>".JText::_('JS_SEARCH_ALL')."</option>\n";
				foreach($result as $row){
			       $return_value .= "<option value=\"$row->code\" >$row->name</option> \n" ;
				}
				$return_value .= "</select>\n";
			}

		}else if ($data=='filter_state') {  // states
		    $query  = "SELECT code, name from `#__js_job_states`  WHERE enabled = 'Y' AND countrycode= ".$db->quote($val)." ORDER BY name ASC";
			$db->setQuery($query);
			$result = $db->loadObjectList();
			if (empty($result))	{
				$return_value = "<input class='inputbox' type='text' style='width:".$address_fields_width."px;color:#808080;' name='txtfilter_state' size='25' maxlength='50' value='State' onfocus='if(this.value == \"State\"){this.value = \"\";this.style.color=\"black\";};' onblur='if(this.value == \"\") { this.style.color=\"#808080\";this.value=\"State\";  }' />";
			}else {
				$return_value = "<select name='cmbfilter_state' class='inputbox' style='width:".$address_fields_width."px;' onChange=\"filter_dochange('filter_county', this.value)\">\n";
				$return_value .= "<option value=''>".JText::_('JS_SEARCH_ALL')."</option>\n";

				foreach($result as $row){
					   $return_value .= "<option value=\"$row->code\" >$row->name</option> \n" ;
				}
				$return_value .= "</select>\n";
			}
		}else if ($data=='filter_county') {  // county
		    $query  = "SELECT code, name from `#__js_job_counties`  WHERE enabled = 'Y' AND statecode= ".$db->quote($val)." ORDER BY name ASC";
			$db->setQuery($query);
			$result = $db->loadObjectList();

			if (empty($result))	{
				$return_value = "<input class='inputbox' type='text' style='width:".$address_fields_width."px;color:#808080;' name='txtfilter_county' size='25' maxlength='50' value='County' onfocus='if(this.value == \"County\"){this.value = \"\";this.style.color=\"black\";};' onblur='if(this.value == \"\") { this.style.color=\"#808080\";this.value=\"County\";  }'/>";
			}else
			{
				  $return_value = "<select name='cmbfilter_county' class='inputbox' style='width:".$address_fields_width."px;' onChange=\"filter_dochange('filter_city', this.value)\">\n";
				  $return_value .= "<option value=''>".JText::_('JS_SEARCH_ALL')."</option>\n";
				  foreach($result as $row){
				       $return_value .= "<option value=\"$row->code\" >$row->name</option> \n" ;
				  }
				$return_value .= "</select>\n";
			}

		} else if ($data=='filter_city') { // city
		    $query  = "SELECT code, name from `#__js_job_cities`  WHERE enabled = 'Y' AND countycode= ".$db->quote($val)." ORDER BY 'name'";
			$db->setQuery($query);
			$result = $db->loadObjectList();
			//if (mysql_num_rows($result)== 0)
			if (empty($result))	{
				$return_value = "<input class='inputbox' type='text' style='width:".$address_fields_width."px;color:#808080;' name='txtfilter_city' size='25' maxlength='50' value='City' onfocus='if(this.value == \"City\"){this.value = \"\";this.style.color=\"black\";};' onblur='if(this.value == \"\") { this.style.color=\"#808080\";this.value=\"City\";  }'/>";
			}else
			{
				$return_value = "<select name='cmbfilter_city' class='inputbox' style='width:".$address_fields_width."px;' onChange=\"filter_dochange('zipcode', this.value)\">\n";
				$return_value .= "<option value=''>".JText::_('JS_SEARCH_ALL')."</option>\n";
				foreach($result as $row){
				   $return_value .= "<option value=\"$row->code\" >$row->name</option> \n" ;
				}
				$return_value .= "</select>\n";
			}
		}
		return $return_value;
	}

	function &listEmpAddressData($name, $myname, $nextname, $data, $val)
	{
		$db = &$this->getDBO();

		
		if ($data=='country') {  // country
			$query  = "SELECT code, name FROM `#__js_job_countries`  WHERE enabled = 'Y' ORDER BY name ASC";
			$db->setQuery($query);
			$result = $db->loadObjectList();

			if (empty($result))	{
				$return_value = "<input class='inputbox' type='text' name='$name' size='40' maxlength='100'  />";
			}else {

				$return_value = "<select name='$name' onChange=\"dochange(\"$myname\",'state', this.value)\">\n";
				$return_value .= "<option value='0'>". JText::_('JS_CHOOSE_COUNTRY') ."</option>\n";

				foreach($result as $row){
				   $return_value .= "<option value=\"$row->code\" >$row->name</option> \n" ;
				}
				$return_value .= "</select>\n";
			}

		}else if ($data=='state') {  // states
		    $query  = "SELECT code, name from `#__js_job_states`  WHERE enabled = 'Y' AND countrycode= ".$db->quote($val)." ORDER BY name ASC";
			$db->setQuery($query);

			$result = $db->loadObjectList();
			if (empty($result))	{
				$return_value = "<input class='inputbox' type='text' name='$name' size='40' maxlength='100'  />";
			}else
			{
				$return_value = "<select name='$name' class='inputbox' onChange=\"dochange('$myname','$nextname','','county', this.value)\">\n";
				$return_value .= "<option value='0'>". JText::_('JS_CHOOSE_STATE') ."</option>\n";
				  
				foreach($result as $row){
					   $return_value .= "<option value=\"$row->code\" >$row->name</option> \n" ;
				  }
				$return_value .= "</select>\n";
			}
		}else if ($data=='county') {  // county
		    $query  = "SELECT code, name from `#__js_job_counties`  WHERE enabled = 'Y' AND statecode= ".$db->quote($val)." ORDER BY name ASC";
			$db->setQuery($query);
			$result = $db->loadObjectList();

			if (empty($result))	{
				$return_value = "<input class='inputbox' type='text' name='$name' size='40' maxlength='100'  />";
			}else
			{
				$return_value = "<select name='$name' class='inputbox' onChange=\"dochange('$myname','','','city', this.value)\">\n";
				$return_value .= "<option value='0'>". JText::_('JS_CHOOSE_COUNTY') ."</option>\n";
				  
				foreach($result as $row){
					   $return_value .= "<option value=\"$row->code\" >$row->name</option> \n" ;
				  }
				$return_value .= "</select>\n";
			}


		} else if ($data=='city') { // second dropdown
		    $query  = "SELECT code, name from `#__js_job_cities`  WHERE enabled = 'Y' AND countycode= ".$db->quote($val)." ORDER BY 'name'";
			$db->setQuery($query);
			$result = $db->loadObjectList();
			if (empty($result))	{
				$return_value = "<input class='inputbox' type='text' name='$name' size='40' maxlength='100'  />";
			}else
			{
				$return_value = "<select name='$name' class='inputbox' onChange=\"dochange('zipcode', this.value)\">\n";
				$return_value .= "<option value='0'>". JText::_('JS_CHOOSE_CITY') ."</option>\n";
				  
				foreach($result as $row){
				    $return_value .= "<option value=\"$row->code\" >$row->name</option> \n" ;
				}
				$return_value .= "</select>\n";
			}

		}
		return $return_value;
	}		

	function &listDepartments($val)
	{
		$db = &$this->getDBO();
		
		if (is_numeric($val) == false) return false;
		$query  = "SELECT id, name FROM `#__js_job_departments`  WHERE status = 1 AND companyid = ".$val."
				ORDER BY name ASC";
		$db->setQuery($query);
		$result = $db->loadObjectList();

		if (isset($result)){	
			$return_value = "<select name='departmentid' class='inputbox' >\n";

			foreach($result as $row){
				$return_value .= "<option value=\"$row->id\" >$row->name</option> \n" ;
			}
			$return_value .= "</select>\n";
		}

		return $return_value;
	}
	function &listFilterSubCategories($val)
	{
		$db = &$this->getDBO();

		$query  = "SELECT id, title FROM `#__js_job_subcategories`  WHERE status = 1 AND categoryid = ".$val." ORDER BY title ASC";
		$db->setQuery($query);
		$result = $db->loadObjectList();

		if (isset($result)){
			$return_value = "<select name='filter_jobsubcategory' id='filter_jobsubcategory'  class='inputbox' >\n";
                                $return_value .= "<option value='' >".JText::_('JS_SUB_CATEGORY')."</option> \n" ;
			foreach($result as $row){
				$return_value .= "<option value=\"$row->id\" >$row->title</option> \n" ;
			}
			$return_value .= "</select>\n";
		}
		return $return_value;
	}
	function &listSubCategories($val)
	{
		$db = &$this->getDBO();

		$query  = "SELECT id, title FROM `#__js_job_subcategories`  WHERE status = 1 AND categoryid = ".$val." ORDER BY title ASC";
		$db->setQuery($query);
		$result = $db->loadObjectList();

		if (isset($result)){
			$return_value = "<select name='subcategoryid'  class='inputbox' >\n";
                                $return_value .= "<option value='' >".JText::_('JS_SUB_CATEGORY')."</option> \n" ;
			foreach($result as $row){
				$return_value .= "<option value=\"$row->id\" >$row->title</option> \n" ;
			}
			$return_value .= "</select>\n";
		}
		return $return_value;
	}
	function &listSubCategoriesForSearch($val)
	{
		$db = &$this->getDBO();

		$query  = "SELECT id, title FROM `#__js_job_subcategories`  WHERE status = 1 AND categoryid = ".$val." ORDER BY title ASC";
		$db->setQuery($query);
		$result = $db->loadObjectList();

		if (isset($result)){
			$return_value = "<select name='jobsubcategory' class='inputbox' >\n";
                                $return_value .= "<option value='' >".JText::_('JS_SUB_CATEGORY')."</option> \n" ;
			foreach($result as $row){
				$return_value .= "<option value=\"$row->id\" >$row->title</option> \n" ;
			}
			$return_value .= "</select>\n";
		}
		return $return_value;
	}

	function &getResumeDetail($uid, $jobid, $resumeid)
	{
		if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
		if (is_numeric($jobid) == false) return false;
		if (is_numeric($resumeid) == false) return false;

		$db = &$this->getDBO();
                $canview = 0;

                $query = "SELECT apply.resumeview FROM `#__js_job_jobapply` AS apply
                WHERE apply.jobid = ".$jobid . " AND apply.cvid = ".$resumeid;
                $db->setQuery($query);
                $alreadyview = $db->loadObject();

                if ($alreadyview->resumeview == 1) $canview = 1;//already view this resume
                if ($canview == 0){
                    $query = "SELECT package.viewresumeindetails, package.packageexpireindays, payment.created
                    FROM `#__js_job_employerpackages` AS package
                    JOIN `#__js_job_employerpaymenthistory` AS payment ON payment.packageid = package.id
                    WHERE payment.uid = ".$uid."
                    AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()";
                    //echo $query;
                    $db->setQuery($query);
                    $jobs = $db->loadObjectList();
                    $unlimited = 0;
                    $viewresumeindetails=0;
                    foreach($jobs AS $job){
                            if($unlimited == 0){
                                    if ($job->viewresumeindetails != -1){
                                            $viewresumeindetails = $viewresumeindetails + $job->viewresumeindetails;
                                    }else $unlimited = 1;
                            }
                    }
                    if ($unlimited == 0){
                        if ($viewresumeindetails == 0) $canview = 0; //can not add new job
                            $query = "SELECT SUM(apply.resumeview) AS totalview
                            FROM `#__js_job_jobapply` AS apply
                            WHERE apply.jobid = ".$jobid;
                            //echo $query;
                            $db->setQuery($query);
                            $totalview = $db->loadResult();

                            if ($viewresumeindetails <= $totalview) $canview = 0; //can not add new job
                            else $canview = 1;

                    }elseif ($unlimited == 1) $canview = 1; // unlimited
                }

                if ($canview == 1){
                    $query = "UPDATE `#__js_job_jobapply` SET resumeview = 1 WHERE jobid = ".$jobid." AND cvid = ".$resumeid;
                    $db->setQuery( $query );
                    $db->query();
                    
                    $query = "SELECT apply.apply_date, app.iamavailable
                                    , app.id AS appid, app.first_name, app.last_name, app.email_address ,app.address_county
                                    ,app.jobtype,app.gender,app.institute,app.institute_study_area ,app.address_state ,app.address_city
                                    ,app.total_experience, app.jobsalaryrange,country.name AS countryname,state.name AS statename
                                    ,county.name AS countyname,city.name AS cityname
                                    , salary.rangestart, salary.rangeend,education.title AS educationtitle
                                    FROM `#__js_job_resume` AS app
                                    JOIN `#__js_job_jobapply` AS apply  ON apply.cvid = app.id
                                    LEFT JOIN `#__js_job_heighesteducation` AS  education  ON app.heighestfinisheducation=education.id
                                    LEFT OUTER JOIN  `#__js_job_salaryrange` AS salary	ON	app.jobsalaryrange=salary.id
                                    LEFT JOIN `#__js_job_countries` AS country ON app.address_country  = country.code
                                    LEFT JOIN `#__js_job_states` AS state ON app.address_state = state.code
                                    LEFT JOIN `#__js_job_counties` AS county ON app.address_county  = county.code
                                    LEFT JOIN `#__js_job_cities` AS city ON app.address_city = city.code

                    WHERE app.id = ".$resumeid;
                    //echo '<br> SQL '.$query;
                    $db->setQuery($query);
                    $resume = $db->loadObject();

                    
                    $fieldsordering = $this->getFieldsOrdering(3);// resume fields ordering
                    if (isset($resume)){
						$trclass = array('odd','even');
						$i = 0; // for odd and even rows
                            $return_value = "<div id='resumedetail'>\n";
							$return_value .= "<div id='resumedetailclose'><input type='button' id='button' class='close_button' onclick='clsjobdetail(\"resumedetail_$resume->appid\")' value='X'> </div>\n";
                            $return_value .= "<table cellpadding='0' cellspacing='0' border='0' width='100%'>\n";
						foreach($fieldsordering AS $field){
							switch($field->field){
								case 'heighesteducation':
									if($field->published == 1){
										$return_value .= "<tr id='mc_field_row' class='".$trclass[$i]."'>\n";
										$return_value .= "<td width='40%' ><b>".JText::_('JS_EDUCATION')."</b></td>\n";
										$return_value .= "<td >".$resume->educationtitle." </td>\n";
										$return_value .= "<td ></td>\n";
										$return_value .= "</tr>\n";
										$i = 1 - $i;
									}
								break;
								case 'institute_institute':
									if($field->published == 1){
										$return_value .= "<tr id='mc_field_row' class='".$trclass[$i]."'>\n";
										$return_value .= "<td width='40%' ><b>".JText::_('JS_INSTITUTE')."</b></td>\n";
										$return_value .= "<td >".$resume->institute." </td>\n";
										$return_value .= "<td ></td>\n";
										$return_value .= "</tr>\n";
										$i = 1 - $i;
									}
								break;
								case 'institute_study_area':
									if($field->published == 1){
										$return_value .= "<tr id='mc_field_row' class='".$trclass[$i]."'>\n";
										$return_value .= "<td ><b>".JText::_('JS_STUDY_AREA')."</b></td>\n";
										$return_value .= "<td >".$resume->institute_study_area." </td>\n";
										$return_value .= "<td ></td>\n";
										$return_value .= "</tr>\n";
										$i = 1 - $i;
									}
								break;
								case 'totalexperience':
									if($field->published == 1){
										$return_value .= "<tr id='mc_field_row' class='".$trclass[$i]."'>\n";
										$return_value .= "<td ><b>".JText::_('JS_EXPERIENCE')."</b></td>\n";
										$return_value .= "<td >".$resume->total_experience." </td>\n";
										$return_value .= "<td ></td>\n";
										$return_value .= "</tr>\n";
										$i = 1 - $i;
									}
								break;
								case 'Iamavailable':
									if($field->published == 1){
										$return_value .= "<tr id='mc_field_row' class='".$trclass[$i]."'>\n";
										$return_value .= "<td ><b>".JText::_('JS_I_AM_AVAILABLE')."</b></td>\n";
										if($resume->iamavailable==1) $return_value .= "<td >".JText::_('JS_YES')."</td>\n";
										else $return_value .= "<td >".JText::_('JS_NO')."</td>\n";
										$return_value .= "<td ></td>\n";
										$return_value .= "</tr>\n";
										$i = 1 - $i;
									}
								break;
								case 'address_city':
									if($field->published == 1){
										$return_value .= "<tr id='mc_field_row' class='".$trclass[$i]."'>\n";
										$return_value .= "<td ><b>".JText::_('JS_CITY')."</b></td>\n";
										if($resume->cityname) $return_value .= "<td >".$resume->cityname." </td>\n";
										else $return_value .= "<td >".$resume->address_city." </td>\n";
										$return_value .= "<td ></td>\n";
										$return_value .= "</tr>\n";
										$i = 1 - $i;
									}
								break;
								case 'address_county':
									if($field->published == 1){
										$return_value .= "<tr id='mc_field_row' class='".$trclass[$i]."'>\n";
										$return_value .= "<td ><b>".JText::_('JS_COUNTY')."</b></td>\n";
										if($resume->countyname) $return_value .= "<td >".$resume->countyname." </td>\n";
										else $return_value .= "<td >".$resume->address_county." </td>\n";
										$return_value .= "<td ></td>\n";
										$return_value .= "</tr>\n";
										$i = 1 - $i;
									}
								break;
								case 'address_state':
									if($field->published == 1){
										$return_value .= "<tr id='mc_field_row' class='".$trclass[$i]."'>\n";
										$return_value .= "<td ><b>".JText::_('JS_STATE')."</b></td>\n";
										if($resume->statename) $return_value .= "<td >".$resume->statename." </td>\n";
										else $return_value .= "<td >".$resume->address_state." </td>\n";
										$return_value .= "<td ></td>\n";
										$return_value .= "</tr>\n";
										$i = 1 - $i;
									}
								break;
								case 'address_country':
									if($field->published == 1){
										$return_value .= "<tr id='mc_field_row' class='".$trclass[$i]."'>\n";
										$return_value .= "<td ><b>".JText::_('JS_COUNTRY')."</b></td>\n";
										$return_value .= "<td >".$resume->countryname." </td>\n";
										$return_value .= "<td ></td>\n";
										$return_value .= "</tr>\n";
										$i = 1 - $i;
									}
								break;
							}
						}
                            $return_value .= "<tr>\n";
                            $return_value .= "<td colspan='3' align='center'>\n";
                            $return_value .= "<input type='hidden' name='resumeid' value=".$resumeid." />\n";
                            $return_value .= "</td>\n";
                            $return_value .= "</tr>\n";

                            $return_value .= "</tr>\n";
                            $return_value .= "</table>\n";

                            $return_value .= "</div>\n";
                    }
                }else{
                            $return_value = "<div id='resumedetail'>\n";
                            $return_value .= "<tr><td>\n";
                            $return_value .= "<table cellpadding='0' cellspacing='0' border='0' width='100%'>\n";
                            $return_value .= "<tr class='odd'>\n";
                            $return_value .= "<td ><b>".JText::_('JS_YOU_CAN_NOT_VIEW_RESUME_DETAIL')."</b></td>\n";
                            $return_value .= "<td width='20'><input type='button' class='button' onclick='clsjobdetail(\"resumedetail_$resume->appid\")' value=".JText::_('JS_CLOSE')."> </td>\n";
                            $return_value .= "</tr>\n";
                            $return_value .= "</table>\n";

                            $return_value .= "</div>\n";
                }

		return $return_value;
	}

	function &getMyFoldersAJAX($uid, $jobid, $resumeid,$applyid)
	{
		if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
		if (is_numeric($jobid) == false) return false;
		if (is_numeric($resumeid) == false) return false;
                $option = 'com_jsjobs';
		$db = &$this->getDBO();
                $canview = 0;

                $canadd = $this->canResumeAddintoFolder($uid,$jobid);
                if ($canadd == 1){
                    $myfolders = $this->getMyFoldersForCombo($uid,'');
                    if($myfolders ) $folders = JHTML::_('select.genericList', $myfolders, 'folderid', 'class="inputbox required" '. '', 'value', 'text', '');
                    else $folders = JText::_('YOU_DO_NOT_HAVE_FOLDERS');

                    $return_value = "<table cellpadding='0' cellspacing='0' border='1' width='100%'>\n";
                            $return_value .= "<tr><td>\n";
                            $return_value .= "<table cellpadding='0' cellspacing='0' border='0' width='100%'>\n";
                            $return_value .= "<tr class='odd'>\n";
                            $return_value .= "<td width='30%' align='right' ><b>".JText::_('JS_FOLDER')."</b></td>\n";
                            $return_value .= "<td width='20%'>".$folders." </td>\n";
                            if($myfolders ){
                                $return_value .= "<td  align='left'><input type='button' class='button' onclick='saveaddtofolder(".$jobid.",".$resumeid.")' value='".JText::_('JS_ADD')."'> </td>\n";
                            }
                            $return_value .= "</tr>\n";
                            $return_value .= "</table>\n";
                            $return_value .= "</td></tr>\n";
                            $return_value .= "</table>\n";
                }else{  
                            $return_value = "<table cellpadding='0' cellspacing='0' border='1' width='100%'>\n";
                            $return_value .= "<tr><td>\n";
                            $return_value .= "<table cellpadding='0' cellspacing='0' border='0' width='100%'>\n";
                            $return_value .= "<tr class='odd'>\n";
                            $return_value .= "<td ><b>".JText::_('JS_YOU_DO_NOT_HAVE_RIGHT')."</b></td>\n";
                            $return_value .= "<td width='20'><input type='button' class='button' onclick='clsaddtofolder(\"resumeaction_$applyid\")' value=".JText::_('JS_CLOSE')."> </td>\n";
                            $return_value .= "</tr>\n";
                            $return_value .= "</table>\n";

                            $return_value .= "</td></tr>\n";
                            $return_value .= "</table>\n";


                }

		return $return_value;
	}
        function canResumeAddintoFolder($uid,$jobid){
		if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
		if (is_numeric($jobid) == false) return false;

		$db = &$this->getDBO();
                $canadd = 0;
                $query = "SELECT package.folders, package.packageexpireindays, payment.created
                FROM `#__js_job_employerpackages` AS package
                JOIN `#__js_job_employerpaymenthistory` AS payment ON payment.packageid = package.id
                JOIN `#__js_job_jobs` AS job ON job.packageid = package.id
                WHERE payment.uid = ".$uid." AND job.id = ".$jobid;
                //echo $query;
                $db->setQuery($query);
                $package = $db->loadObject();
                
                if ($package->folders == -1) return 1;
                if ($package->folders > 0) return 1; else return 0;
        }

        function &getEmpOptions()
	{
		if ( !$this->_empoptions )
		{
			$this->_empoptions = array();

		$gender = array(
			'0' => array('value' => 1,'text' => JText::_('JS_MALE')),
			'1' => array('value' => 2,'text' => JText::_('JS_FEMALE')),);

			$job_type = $this->getJobType('');
			$heighesteducation = $this->getHeighestEducation('');
			$job_categories = $this->getCategories('');
			$job_salaryrange = $this->getJobSalaryRange('','','');
			$countries = $this->getCountries('');
			if ( isset($this->_application) ){
                $job_subcategories = $this->getSubCategoriesforCombo($this->_application->job_category, '', $this->_application->job_subcategory);
            }else{
                $job_subcategories = $this->getSubCategoriesforCombo($job_categories[0]['value'], '', '');
            }
			if(isset($this->_application))$address_states = $this->getStates($this->_application->address_country, '');
			if(isset($this->_application))$address_counties = $this->getCounties($this->_application->address_state, '');
			if(isset($this->_application))$address_cities = $this->getCities($this->_application->address_county, '');

			if(isset($this->_application))$institute_states = $this->getStates($this->_application->institute_country, '');
			if(isset($this->_application))$institute_counties = $this->getCounties($this->_application->institute_state, '');
			if(isset($this->_application))$institute_cities = $this->getCities($this->_application->institute_county, '');
			
			if(isset($this->_application))$institute1_states = $this->getStates($this->_application->institute1_country, '');
			if(isset($this->_application))$institute1_counties = $this->getCounties($this->_application->institute1_state, '');
			if(isset($this->_application))$institute1_cities = $this->getCities($this->_application->institute1_county, '');

			if(isset($this->_application))$employer_states = $this->getStates($this->_application->employer_country, '');
			if(isset($this->_application))$employer_counties = $this->getCounties($this->_application->employer_state, '');
			if(isset($this->_application))$employer_cities = $this->getCities($this->_application->employer_county, '');
			
			if ( isset($this->_application) )
			{
				$this->_empoptions['nationality'] = JHTML::_('select.genericList', $countries, 'nationality','class="inputbox" '.'', 'value', 'text', $this->_application->nationality);
				$this->_empoptions['gender'] = JHTML::_('select.genericList', $gender, 'gender','class="inputbox" '.'', 'value', 'text', $this->_application->gender);

				$this->_empoptions['job_category'] = JHTML::_('select.genericList', $job_categories, 'job_category', 'class="inputbox" '. 'onChange="fj_getsubcategories(\'fj_subcategory\', this.value)"', 'value', 'text', $this->_application->job_category);
				$this->_empoptions['job_subcategory'] = JHTML::_('select.genericList', $job_subcategories, 'job_subcategory', 'class="inputbox" '. '', 'value', 'text', $this->_application->job_subcategory);

				$this->_empoptions['address_country'] = JHTML::_('select.genericList', $countries, 'address_country','class="inputbox" '.'onChange="dochange(\'address_state\', \'address_county\',\'address_city\', \'state\', this.value)"', 'value', 'text', $this->_application->address_country);
				if (isset($address_states[1])) if ($address_states[1] != '')$this->_empoptions['address_state'] = JHTML::_('select.genericList', $address_states, 'address_state', 'class="inputbox" '. 'onChange="dochange(\'address_county\, \'address_city\', , this.value)"', 'value', 'text', $this->_application->address_state);
				if (isset($address_counties[1])) if ($address_counties[1] != '')$this->_empoptions['address_county'] = JHTML::_('select.genericList', $address_counties, 'address_county', 'class="inputbox" '. 'onChange="dochange(\'address_city\, , , this.value)"', 'value', 'text', $this->_application->address_county);
				if (isset($address_cities[1])) if ($address_cities[1] != '')$this->_empoptions['address_city'] = JHTML::_('select.genericList', $address_cities, 'address_city', 'class="inputbox" '. '', 'value', 'text', $this->_application->address_city);
				
				$this->_empoptions['address1_country'] = JHTML::_('select.genericList', $countries, 'address1_country','class="inputbox" '.'onChange="dochange(\'address1_state\', \'address1_county\',\'address1_city\',\'state\', this.value)"', 'value', 'text', $this->_application->address1_country);
				$this->_empoptions['address2_country'] = JHTML::_('select.genericList', $countries, 'address2_country','class="inputbox" '.'onChange="dochange(\'address2_state\', \'address2_county\',\'address2_city\',\'state\', this.value)"', 'value', 'text', $this->_application->address2_country);

				$this->_empoptions['institute_country'] = JHTML::_('select.genericList', $countries, 'institute_country','class="inputbox" '.'onChange="dochange(\'institute_state\', \'institute_county\',\'institute_city\', \'state\', this.value)"', 'value', 'text', $this->_application->institute_country);
				if (isset($institute_states[1])) if ($institute_states[1] != '')$this->_empoptions['institute_state'] = JHTML::_('select.genericList', $institute_states, 'institute_state', 'class="inputbox" '. 'onChange="dochange(\'institute_county\, \'institute_city\', , this.value)"', 'value', 'text', $this->_application->institute_state);
				if (isset($institute_counties[1])) if ($institute_counties[1] != '')$this->_empoptions['institute_county'] = JHTML::_('select.genericList', $institute_counties, 'institute_county', 'class="inputbox" '. 'onChange="dochange(\'institute_city\,  , , this.value)"', 'value', 'text', $this->_application->institute_county);
				if (isset($institute_cities[1])) if ($institute_cities[1] != '')$this->_empoptions['institute_city'] = JHTML::_('select.genericList', $institute_cities, 'institute_city', 'class="inputbox" '. '', 'value', 'text', $this->_application->institute_city);

				$this->_empoptions['institute1_country'] = JHTML::_('select.genericList', $countries, 'institute1_country','class="inputbox" '.'onChange="dochange(\'institute1_state\', \'institute1_county\',\'institute1_city\',\'state\', this.value)"', 'value', 'text', $this->_application->institute1_country);
				if (isset($institute1_states[1])) if ($institute1_states[1] != '')$this->_empoptions['institute1_state'] = JHTML::_('select.genericList', $institute1_states, 'institute1_state', 'class="inputbox" '. 'onChange="dochange(\'institute1_county\, \'institute1_city\', , this.value)"', 'value', 'text', $this->_application->institute1_state);
				if (isset($institute1_counties[1])) if ($institute1_counties[1] != '')$this->_empoptions['institute1_county'] = JHTML::_('select.genericList', $institute1_counties, 'institute1_county', 'class="inputbox" '. 'onChange="dochange(\'institute1_city\,  , , this.value)"', 'value', 'text', $this->_application->institute1_county);
				if (isset($institute1_cities[1])) if ($institute1_cities[1] != '')$this->_empoptions['institute1_city'] = JHTML::_('select.genericList', $institute1_cities, 'institute1_city', 'class="inputbox" '. '', 'value', 'text', $this->_application->institute1_city);

				$this->_empoptions['institute2_country'] = JHTML::_('select.genericList', $countries, 'institute2_country','class="inputbox" '.'onChange="dochange(\'institute2_state\', \'institute2_county\',\'institute2_city\',\'state\', this.value)"', 'value', 'text', $this->_application->institute2_country);
				$this->_empoptions['institute3_country'] = JHTML::_('select.genericList', $countries, 'institute3_country','class="inputbox" '.'onChange="dochange(\'institute3_state\', \'institute3_county\',\'institute3_city\',\'state\', this.value)"', 'value', 'text', $this->_application->institute3_country);

				$this->_empoptions['employer_country'] = JHTML::_('select.genericList', $countries, 'employer_country','class="inputbox" '.'onChange="dochange(\'employer_state\', \'employer_county\',\'employer_city\',\'state\', this.value)"', 'value', 'text', $this->_application->employer_country);
				if (isset($employer_states[1])) if ($employer_states[1] != '')$this->_empoptions['employer_state'] = JHTML::_('select.genericList', $employer_states, 'employer_state', 'class="inputbox" '. 'onChange="dochange(\'employer_county\, \'employer_city\', , this.value)"', 'value', 'text', $this->_application->employer_state);
				if (isset($employer_counties[1])) if ($employer_counties[1] != '')$this->_empoptions['employer_county'] = JHTML::_('select.genericList', $employer_counties, 'employer_county', 'class="inputbox" '. 'onChange="dochange(\'employer_city\,  , , this.value)"', 'value', 'text', $this->_application->employer_county);
				if (isset($employer_cities[1])) if ($employer_cities[1] != '')$this->_empoptions['employer_city'] = JHTML::_('select.genericList', $employer_cities, 'employer_city', 'class="inputbox" '. '', 'value', 'text', $this->_application->employer_city);

				$this->_empoptions['employer1_country'] = JHTML::_('select.genericList', $countries, 'employer1_country','class="inputbox" '.'onChange="dochange(\'employer1_state\', \'employer1_county\',\'employer1_city\',\'state\', this.value)"', 'value', 'text', $this->_application->employer1_country);
				$this->_empoptions['employer2_country'] = JHTML::_('select.genericList', $countries, 'employer2_country','class="inputbox" '.'onChange="dochange(\'employer2_state\', \'employer2_county\',\'employer2_city\',\'state\', this.value)"', 'value', 'text', $this->_application->employer2_country);
				$this->_empoptions['employer3_country'] = JHTML::_('select.genericList', $countries, 'employer3_country','class="inputbox" '.'onChange="dochange(\'employer3_state\', \'employer3_county\',\'employer3_city\',\'state\', this.value)"', 'value', 'text', $this->_application->employer3_country);

				$this->_empoptions['reference_country'] = JHTML::_('select.genericList', $countries, 'reference_country','class="inputbox" '.'onChange="dochange(\'reference_state\', \'reference_county\',\'reference_city\',\'state\', this.value)"', 'value', 'text', $this->_application->reference_country);
				$this->_empoptions['reference1_country'] = JHTML::_('select.genericList', $countries, 'reference1_country','class="inputbox" '.'onChange="dochange(\'reference1_state\', \'reference1_county\',\'reference1_city\',\'state\', this.value)"', 'value', 'text', $this->_application->reference1_country);
				$this->_empoptions['reference2_country'] = JHTML::_('select.genericList', $countries, 'reference2_country','class="inputbox" '.'onChange="dochange(\'reference2_state\', \'reference2_county\',\'reference2_city\',\'state\', this.value)"', 'value', 'text', $this->_application->reference2_country);
				$this->_empoptions['reference3_country'] = JHTML::_('select.genericList', $countries, 'reference3_country','class="inputbox" '.'onChange="dochange(\'reference3_state\', \'reference3_county\',\'reference3_city\',\'state\', this.value)"', 'value', 'text', $this->_application->reference3_country);

				$this->_empoptions['jobtype'] = JHTML::_('select.genericList', $job_type, 'jobtype', 'class="inputbox" '. '', 'value', 'text', $this->_application->jobtype);
				$this->_empoptions['heighestfinisheducation'] = JHTML::_('select.genericList', $heighesteducation, 'heighestfinisheducation', 'class="inputbox" '. '', 'value', 'text', $this->_application->heighestfinisheducation);
				$this->_empoptions['jobsalaryrange'] = JHTML::_('select.genericList', $job_salaryrange, 'jobsalaryrange', 'class="inputbox" '. '', 'value', 'text', $this->_application->jobsalaryrange);
				$this->_empoptions['currencyid'] = JHTML::_('select.genericList', $this->getCurrency(), 'currencyid', 'class="inputbox" '. '', 'value', 'text', $this->_application->currencyid);


			}else{
				$this->_empoptions['nationality'] = JHTML::_('select.genericList', $countries, 'nationality','class="inputbox" '.'', 'value', 'text', '');
				$this->_empoptions['gender'] = JHTML::_('select.genericList', $gender, 'gender','class="inputbox" '.'', 'value', 'text', '');

				$this->_empoptions['job_category'] = JHTML::_('select.genericList', $job_categories, 'job_category', 'class="inputbox" '. 'onChange="fj_getsubcategories(\'fj_subcategory\', this.value)"', 'value', 'text', '');
				$this->_empoptions['job_subcategory'] = JHTML::_('select.genericList', $job_subcategories, 'job_subcategory', 'class="inputbox" '. '', 'value', 'text', '');
				
				$this->_empoptions['address_country'] = JHTML::_('select.genericList', $countries, 'address_country','class="inputbox" '.'onChange="dochange(\'address_state\', \'address_county\',\'address_city\', \'state\', this.value)"', 'value', 'text', '');
				//echo '<br> st '.$address_states[1];
				if ( isset($address_states[1]) )if ($address_states[1] != '')$this->_empoptions['address_state'] = JHTML::_('select.genericList', $address_states, 'address_state', 'class="inputbox" '. 'onChange="dochange(\'address_county\, \'address_city\', , this.value)"', 'value', 'text', '');
				if ( isset($address_counties[1]) )if ($address_counties[1] != '')$this->_empoptions['address_county'] = JHTML::_('select.genericList', $address_counties, 'address_county', 'class="inputbox" '. 'onChange="dochange(\'address_city\, , , this.value)"', 'value', 'text', '');
				if ( isset($address_cities[1]) )if ($address_cities[1] != '')$this->_empoptions['address_city'] = JHTML::_('select.genericList', $address_cities, 'address_city', 'class="inputbox" '. '', 'value', 'text', '');
				
				$this->_empoptions['address1_country'] = JHTML::_('select.genericList', $countries, 'address1_country','class="inputbox" '.'onChange="dochange(\'address1_state\', \'address1_county\',\'address1_city\',\'state\', this.value)"', 'value', 'text', '');
				$this->_empoptions['address2_country'] = JHTML::_('select.genericList', $countries, 'address2_country','class="inputbox" '.'onChange="dochange(\'address2_state\', \'address2_county\',\'address2_city\',\'state\', this.value)"', 'value', 'text', '');

				$this->_empoptions['institute_country'] = JHTML::_('select.genericList', $countries, 'institute_country','class="inputbox" '.'onChange="dochange(\'institute_state\', \'institute_county\',\'institute_city\', \'state\', this.value)"', 'value', 'text', '');
				if ( isset($institute_states[1]) )if ($institute_states[1] != '')$this->_empoptions['institute_state'] = JHTML::_('select.genericList', $institute_states, 'institute_state', 'class="inputbox" '. 'onChange="dochange(\'institute_county\, \'institute_city\', , this.value)"', 'value', 'text', '');
				if ( isset($institute_counties[1]) )if ($institute_counties[1] != '')$this->_empoptions['institute_county'] = JHTML::_('select.genericList', $institute_counties, 'institute_county', 'class="inputbox" '. 'onChange="dochange(\'institute_city\,  , , this.value)"', 'value', 'text', '');
				if ( isset($institute_cities[1]) )if ($institute_cities[1] != '')$this->_empoptions['institute_city'] = JHTML::_('select.genericList', $institute_cities, 'institute_city', 'class="inputbox" '. '', 'value', 'text', '');

				$this->_empoptions['institute1_country'] = JHTML::_('select.genericList', $countries, 'institute1_country','class="inputbox" '.'onChange="dochange(\'institute1_state\', \'institute1_county\',\'institute1_city\',\'state\', this.value)"', 'value', 'text', '');
				if (isset($institute1_states[1])) if ($institute1_states[1] != '')$this->_empoptions['institute1_state'] = JHTML::_('select.genericList', $institute1_states, 'institute1_state', 'class="inputbox" '. 'onChange="dochange(\'institute1_county\, \'institute1_city\', , this.value)"', 'value', 'text', '');
				if (isset($institute1_counties[1])) if ($institute1_counties[1] != '')$this->_empoptions['institute1_county'] = JHTML::_('select.genericList', $institute1_counties, 'institute1_county', 'class="inputbox" '. 'onChange="dochange(\'institute1_city\,  , , this.value)"', 'value', 'text', '');
				if (isset($institute1_cities[1])) if ($institute1_cities[1] != '')$this->_empoptions['institute1_city'] = JHTML::_('select.genericList', $institute1_cities, 'institute1_city', 'class="inputbox" '. '', 'value', 'text', '');

				$this->_empoptions['institute2_country'] = JHTML::_('select.genericList', $countries, 'institute2_country','class="inputbox" '.'onChange="dochange(\'institute2_state\', \'institute2_county\',\'institute2_city\',\'state\', this.value)"', 'value', 'text', '');
				$this->_empoptions['institute3_country'] = JHTML::_('select.genericList', $countries, 'institute3_country','class="inputbox" '.'onChange="dochange(\'institute3_state\', \'institute3_county\',\'institute3_city\',\'state\', this.value)"', 'value', 'text', '');

				$this->_empoptions['employer_country'] = JHTML::_('select.genericList', $countries, 'employer_country','class="inputbox" '.'onChange="dochange(\'employer_state\', \'employer_county\',\'employer_city\',\'state\', this.value)"', 'value', 'text', '');
				if ( isset($employer_states[1]) )if ($employer_states[1] != '')$this->_empoptions['employer_state'] = JHTML::_('select.genericList', $employer_states, 'employer_state', 'class="inputbox" '. 'onChange="dochange(\'employer_county\, \'employer_city\', , this.value)"', 'value', 'text', '');
				if ( isset($employer_counties[1]) )if ($employer_counties[1] != '')$this->_empoptions['employer_county'] = JHTML::_('select.genericList', $employer_counties, 'employer_county', 'class="inputbox" '. 'onChange="dochange(\'employer_city\,  , , this.value)"', 'value', 'text', '');
				if ( isset($employer_cities[1]) )if ($employer_cities[1] != '')$this->_empoptions['employer_city'] = JHTML::_('select.genericList', $employer_cities, 'employer_city', 'class="inputbox" '. '', 'value', 'text', '');

				$this->_empoptions['employer1_country'] = JHTML::_('select.genericList', $countries, 'employer1_country','class="inputbox" '.'onChange="dochange(\'employer1_state\', \'employer1_county\',\'employer1_city\',\'state\', this.value)"', 'value', 'text', '');
				$this->_empoptions['employer2_country'] = JHTML::_('select.genericList', $countries, 'employer2_country','class="inputbox" '.'onChange="dochange(\'employer2_state\', \'employer2_county\',\'employer2_city\',\'state\', this.value)"', 'value', 'text', '');
				$this->_empoptions['employer3_country'] = JHTML::_('select.genericList', $countries, 'employer3_country','class="inputbox" '.'onChange="dochange(\'employer3_state\', \'employer3_county\',\'employer3_city\',\'state\', this.value)"', 'value', 'text', '');

				$this->_empoptions['reference_country'] = JHTML::_('select.genericList', $countries, 'reference_country','class="inputbox" '.'onChange="dochange(\'reference_state\', \'reference_county\',\'reference_city\',\'state\', this.value)"', 'value', 'text', '');
				$this->_empoptions['reference1_country'] = JHTML::_('select.genericList', $countries, 'reference1_country','class="inputbox" '.'onChange="dochange(\'reference1_state\', \'reference1_county\',\'reference1_city\',\'state\', this.value)"', 'value', 'text', '');
				$this->_empoptions['reference2_country'] = JHTML::_('select.genericList', $countries, 'reference2_country','class="inputbox" '.'onChange="dochange(\'reference2_state\', \'reference2_county\',\'reference2_city\',\'state\', this.value)"', 'value', 'text', '');
				$this->_empoptions['reference3_country'] = JHTML::_('select.genericList', $countries, 'reference3_country','class="inputbox" '.'onChange="dochange(\'reference3_state\', \'reference3_county\',\'reference3_city\',\'state\', this.value)"', 'value', 'text', '');


				$this->_empoptions['jobtype'] = JHTML::_('select.genericList', $job_type, 'jobtype', 'class="inputbox" '. '', 'value', 'text', '');
				$this->_empoptions['heighestfinisheducation'] = JHTML::_('select.genericList', $heighesteducation, 'heighestfinisheducation', 'class="inputbox" '. '', 'value', 'text', '');
				$this->_empoptions['jobsalaryrange'] = JHTML::_('select.genericList', $job_salaryrange, 'jobsalaryrange', 'class="inputbox" '. '', 'value', 'text', '');
				$this->_empoptions['currencyid'] = JHTML::_('select.genericList', $this->getCurrency(), 'currencyid', 'class="inputbox" '. '', 'value', 'text', '');

			}
		}
		return $this->_empoptions;
	}	
	

	function &getSearchOptions($uid)
	{
		if($uid) if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
		$db = &$this->getDBO();

                if($uid == 0){ //guest
                    $canview=1;
                }else{
                    $query = "SELECT package.jobsearch, package.packageexpireindays, payment.created
                    FROM `#__js_job_jobseekerpackages` AS package
                    JOIN `#__js_job_jobseekerpaymenthistory` AS payment ON payment.packageid = package.id
                    WHERE payment.uid = ".$uid."
                    AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
                    AND payment.transactionverified = 1 AND payment.status = 1";
                    //echo $query;
                    $db->setQuery($query);
                    $jobs = $db->loadObjectList();
                    $canview = 0;
                    if(empty($jobs)) $canview = 1; // for those who not get any role

                    foreach($jobs AS $job){
                            if ($job->jobsearch == 1){
                                       $canview = 1;
                                       break;
                            }else{
                                     $canview = 0;
                            }
                    }
                }
		//echo $query,$canview;
		if($canview == 1){
                    $searchjobconfig = $this->getConfigByFor('searchjob');
		
                    if ( !$this->_searchoptions ){
                            $this->_searchoptions = array();

                            $companies = $this->getAllCompanies(JText::_('JS_SEARCH_ALL'));
                            $job_type = $this->getJobType(JText::_('JS_SEARCH_ALL'));
                            $jobstatus = $this->getJobStatus(JText::_('JS_SEARCH_ALL'));
                            $heighesteducation = $this->getHeighestEducation(JText::_('JS_SEARCH_ALL'));
                            $job_categories = $this->getCategories(JText::_('JS_SEARCH_ALL'));
                            $job_subcategories = $this->getSubCategoriesforCombo($job_categories[1]['value'], JText::_('JS_SEARCH_ALL'),'');
                            $job_salaryrange = $this->getJobSalaryRange(JText::_('JS_SEARCH_ALL'),'','');
                            $shift = $this->getShift(JText::_('JS_SEARCH_ALL'));
							$countries = $this->getCountries('');
							if(! isset($this->_config)){ $this->getConfig('');}	
							if(isset($this->_defaultcountry))$states = $this->getStates($this->_defaultcountry, '');
							$this->_searchoptions['country'] = JHTML::_('select.genericList', $countries, 'country','class="inputbox required" '.'onChange="dochange(\'state\', this.value)"', 'value', 'text', $this->_defaultcountry);
							if ( isset($states[1]) ) if ($states[1] != '')$this->_searchoptions['state'] = JHTML::_('select.genericList', $states, 'state', 'class="inputbox" '. 'onChange="dochange(\'county\', this.value)"', 'value', 'text', '');
							if ( isset($counties[1]) ) if ($counties[1] != '')$this->_searchoptions['county'] = JHTML::_('select.genericList', $counties, 'county', 'class="inputbox" '. 'onChange="dochange(\'city\', this.value)"', 'value', 'text', '');
							if ( isset($cities[1]) ) if ($cities[1] != '')$this->_searchoptions['city'] = JHTML::_('select.genericList', $cities, 'city', 'class="inputbox" '. '', 'value', 'text', '');

							
							
                            $lists['heighesteducation'] = JHTML::_('select.genericList', $this->getHeighestEducation(''), 'heighestfinisheducation', 'class="inputbox" '. '', 'value', 'text', '');
                            $lists['shift'] = JHTML::_('select.genericList', $this->getShift(''), 'shift', 'class="inputbox" '. '', 'value', 'text', '');

                            $this->_searchoptions['educationminimax'] = JHTML::_('select.genericList', $this->getMiniMax(''), 'educationminimax', 'class="inputbox" '. '', 'value', 'text', '');
                            $this->_searchoptions['education'] = JHTML::_('select.genericList', $this->getHeighestEducation(''), 'educationid', 'class="inputbox" '. '', 'value', 'text', '');
                            $lists['minimumeducationrange'] = JHTML::_('select.genericList', $this->getHeighestEducation(JText::_('JS_MINIMUM')), 'mineducationrange', 'class="inputbox" '. '', 'value', 'text', '');
                            $lists['maximumeducationrange'] = JHTML::_('select.genericList', $this->getHeighestEducation(JText::_('JS_MAXIMUM')), 'maxeducationrange', 'class="inputbox" '. '', 'value', 'text', '');

                            $this->_searchoptions['jobsalaryrange'] = JHTML::_('select.genericList', $job_salaryrange, 'jobsalaryrange', 'class="inputbox" '. '', 'value', 'text', '');
                            $this->_searchoptions['salaryrangefrom'] = JHTML::_('select.genericList', $this->getJobSalaryRange(JText::_('JS_FROM'),1,'from'), 'salaryrangefrom', 'class="inputbox" '. '', 'value', 'text', '');
                            $this->_searchoptions['salaryrangeto'] = JHTML::_('select.genericList', $this->getJobSalaryRange(JText::_('JS_TO'),1,'to'), 'salaryrangeto', 'class="inputbox" '. '', 'value', 'text', '');
                            $this->_searchoptions['salaryrangetypes'] = JHTML::_('select.genericList', $this->getSalaryRangeTypes(''), 'salaryrangetype', 'class="inputbox" '. '', 'value', 'text', 2);

                            $this->_searchoptions['companies'] = JHTML::_('select.genericList', $companies, 'company', 'class="inputbox" '. '', 'value', 'text', '');
                            $this->_searchoptions['jobcategory'] = JHTML::_('select.genericList', $job_categories, 'jobcategory', 'class="inputbox" '. 'onChange="fj_getsubcategories(\'fj_subcategory\', this.value)"', 'value', 'text', '');
                            $this->_searchoptions['jobsubcategory'] = JHTML::_('select.genericList', $job_subcategories, 'jobsubcategory', 'class="inputbox" '. '', 'value', 'text', '');
                            $this->_searchoptions['jobstatus'] = JHTML::_('select.genericList', $jobstatus, 'jobstatus', 'class="inputbox" '. '', 'value', 'text', '');
                            $this->_searchoptions['jobtype'] = JHTML::_('select.genericList', $job_type, 'jobtype', 'class="inputbox" '. '', 'value', 'text', '');
                            $this->_searchoptions['heighestfinisheducation'] = JHTML::_('select.genericList', $heighesteducation, 'heighestfinisheducation', 'class="inputbox" '. '', 'value', 'text', '');
                            $this->_searchoptions['shift'] = JHTML::_('select.genericList', $shift, 'shift', 'class="inputbox" '. '', 'value', 'text', '');
                            $this->_searchoptions['currency'] = JHTML::_('select.genericList', $this->getCurrency(), 'currency', 'class="inputbox" '. '', 'value', 'text', '');
                    }
                    $result = array();
                    $result[0] = $this->_searchoptions;
                    $result[1] = $searchjobconfig;
                    $result[2]= $canview;

		}else{
			$result[2]= $canview;
		}
		return $result;
	}	
	
	function &getResumeSearchOptions($uid)
	{
		if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
                $db = &$this->getDBO();

                $query = "SELECT package.resumesearch, package.packageexpireindays, payment.created
		FROM `#__js_job_employerpackages` AS package
		JOIN `#__js_job_employerpaymenthistory` AS payment ON payment.packageid = package.id
		WHERE payment.uid = ".$uid."
		AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
		AND payment.transactionverified = 1 AND payment.status = 1";
		//echo $query;
		$db->setQuery($query);
		$jobs = $db->loadObjectList();
		//$unlimited = 0;
                 $canview = 0;
		foreach($jobs AS $job){
			if ($job->resumesearch == 1){
				   $canview = 1; 
				   break;
			}else{
				 $canview = 0;
			}
		}
		if($canview==1){

			$searchresumeconfig = $this->getConfigByFor('searchresume');

			$gender = array(
			'0' => array('value' => '','text' => JText::_('JS_SEARCH_ALL')),
			'1' => array('value' => 1,'text' => JText::_('JS_MALE')),
			'2' => array('value' => 2,'text' => JText::_('JS_FEMALE')),);

			$nationality = $this->getCountries(JText::_('JS_SEARCH_ALL'));
			$job_type = $this->getJobType(JText::_('JS_SEARCH_ALL'));
			$heighesteducation = $this->getHeighestEducation(JText::_('JS_SEARCH_ALL'));
			$job_categories = $this->getCategories(JText::_('JS_SEARCH_ALL'));
			$job_subcategories = $this->getSubCategoriesforCombo($job_categories[1]['value'], JText::_('JS_SEARCH_ALL'), '');
			$job_salaryrange = $this->getJobSalaryRange(JText::_('JS_SEARCH_ALL'),'','');

			$searchoptions['nationality'] = JHTML::_('select.genericList', $nationality, 'nationality', 'class="inputbox" '. '', 'value', 'text', '');
			$searchoptions['jobcategory'] = JHTML::_('select.genericList', $job_categories, 'jobcategory', 'class="inputbox" '. 'onChange="fj_getsubcategories(\'fj_subcategory\', this.value)"', 'value', 'text', '');
			$searchoptions['jobsubcategory'] = JHTML::_('select.genericList', $job_subcategories, 'jobsubcategory', 'class="inputbox" '. '', 'value', 'text', '');
			$searchoptions['jobsalaryrange'] = JHTML::_('select.genericList', $job_salaryrange, 'jobsalaryrange', 'class="inputbox" '. '', 'value', 'text', '');
			$searchoptions['jobtype'] = JHTML::_('select.genericList', $job_type, 'jobtype', 'class="inputbox" '. '', 'value', 'text', '');
			$searchoptions['heighestfinisheducation'] = JHTML::_('select.genericList', $heighesteducation, 'heighestfinisheducation', 'class="inputbox" '. '', 'value', 'text', '');
			$searchoptions['gender'] = JHTML::_('select.genericList', $gender, 'gender', 'class="inputbox" '. '', 'value', 'text', '');
			$searchoptions['currency'] = JHTML::_('select.genericList', $this->getCurrency(), 'currency', 'class="inputbox" '. '', 'value', 'text', '');
			$result=array();
			$result[0]=$searchoptions;
			
			$result[1]=$searchresumeconfig;
			$result[2]= $canview;
			}else{
			$result[2]= $canview;
			}
		return $result;
	}	
	
	function &getOptions()
	{
		if ( !$this->_options )
		{
			$this->_options = array();
							
			$jobtype = $this->getJobType('');
			$jobstatus = $this->getJobStatus('');
			$heighesteducation = $this->getHeighestEducation('');
		
			$job_categories = $this->getCategories('');
			$job_salaryrange = $this->getJobSalaryRange('','','');
			$countries = $this->getCountries('');
			if ( isset($this->_application) ){
				$states = $this->getStates($this->_application->country, '');
				$counties = $this->getCounties($this->_application->state, '');
				$cities = $this->getCities($this->_application->county, '');
			}

			if ( isset($this->_application) )
			{
				$this->_options['jobcategory'] = JHTML::_('select.genericList', $job_categories, 'jobcategory', 'class="inputbox" '. '', 'value', 'text', $this->_application->jobcategory);
				$this->_options['jobsalaryrange'] = JHTML::_('select.genericList', $job_salaryrange, 'jobsalaryrange', 'class="inputbox" '. '', 'value', 'text', $this->_application->jobsalaryrange);
				$this->_options['country'] = JHTML::_('select.genericList', $countries, 'country','class="inputbox required" '.'onChange="dochange(\'state\', this.value)"', 'value', 'text', $this->_application->country);
				if ( isset($states[1]) ) if ($states[1] != '')$this->_options['state'] = JHTML::_('select.genericList', $states, 'state', 'class="inputbox" '. 'onChange="dochange(\'county\', this.value)"', 'value', 'text', $this->_application->state);
				if ( isset($counties[1]) ) if ($counties[1] != '')$this->_options['county'] = JHTML::_('select.genericList', $counties, 'county', 'class="inputbox" '. 'onChange="dochange(\'city\', this.value)"', 'value', 'text', $this->_application->county);
				if ( isset($cities[1]) ) if ($cities[1] != '')$this->_options['city'] = JHTML::_('select.genericList', $cities, 'city', 'class="inputbox" '. '', 'value', 'text', $this->_application->city);
				$this->_options['jobstatus'] = JHTML::_('select.genericList', $jobstatus, 'jobstatus', 'class="inputbox" '. '', 'value', 'text', $this->_application->jobstatus);
				$this->_options['jobtype'] = JHTML::_('select.genericList', $jobtype, 'jobtype', 'class="inputbox" '. '', 'value', 'text', $this->_application->jobtype);
				$this->_options['heighestfinisheducation'] = JHTML::_('select.genericList', $heighesteducation, 'heighestfinisheducation', 'class="inputbox" '. '', 'value', 'text', $this->_application->heighestfinisheducation);

			}
			else
			{
				$this->_options['jobcategory'] = JHTML::_('select.genericList', $job_categories, 'jobcategory', 'class="inputbox" '. '', 'value', 'text', '');
				$this->_options['jobsalaryrange'] = JHTML::_('select.genericList', $job_salaryrange, 'jobsalaryrange', 'class="inputbox" '. '', 'value', 'text', '');
				$this->_options['country'] = JHTML::_('select.genericList', $countries, 'country','class="inputbox required" '.'onChange="dochange(\'state\', this.value)"', 'value', 'text', '');
				if ( isset($states[1]) ) if ($states[1] != '')$this->_options['state'] = JHTML::_('select.genericList', $states, 'state', 'class="inputbox" '. 'onChange="dochange(\'county\', this.value)"', 'value', 'text', '');
				if ( isset($counties[1]) ) if ($counties[1] != '')$this->_options['county'] = JHTML::_('select.genericList', $counties, 'county', 'class="inputbox" '. 'onChange="dochange(\'city\', this.value)"', 'value', 'text', '');
				if ( isset($cities[1]) ) if ($cities[1] != '')$this->_options['city'] = JHTML::_('select.genericList', $cities, 'city', 'class="inputbox" '. '', 'value', 'text', '');
				$this->_options['jobstatus'] = JHTML::_('select.genericList', $jobstatus, 'jobstatus', 'class="inputbox" '. '', 'value', 'text', '');
				$this->_options['jobtype'] = JHTML::_('select.genericList', $jobtype, 'jobtype', 'class="inputbox" '. '', 'value', 'text', '');
				$this->_options['heighestfinisheducation'] = JHTML::_('select.genericList', $heighesteducation, 'heighestfinisheducation', 'class="inputbox" '. '', 'value', 'text', '');
				
			}
		}
		return $this->_options;
	}	
	
	function &getFilterLists()
	{
		//if ( !$this->_filterlists ){
			$this->_filterlists = array();

			$jobtype = $this->getJobType(JText::_('JS_SELECT_JOB_TYPE'));
		//	$jobtype = $this->getJobType('abc');
			$jobstatus = $this->getJobStatus(JText::_('JS_SELECT_JOB_STATUS'));
			$heighesteducation = $this->getHeighestEducation(JText::_('JS_SELECT_EDUCATION'));

			$job_categories = $this->getCategories(JText::_('JS_SELECT_CATEGORY'));
			$job_salaryrange = $this->getJobSalaryRange(JText::_('JS_SELECT_SALARY'),'','');
			$countries = $this->getCountries('');
			
			//$this->_filterlists['country'] = JHTML::_('select.genericList', $countries, 'cmbfilter_country','class="inputbox" '.'onChange="dochange(\'filter_state\', \'filter_county\',\'filter_city\',\'state\', this.value)"', 'value', 'text', '');
			$this->_filterlists['country'] = JHTML::_('select.genericList', $countries, 'cmbfilter_country','class="inputbox" '.'onChange="dochange(\'filter_state\', this.value)"', 'value', 'text', '');

			$this->_filterlists['jobcategory'] = JHTML::_('select.genericList', $job_categories, 'filter_jobcategory', 'class="inputbox" '. '', 'value', 'text', '');
			$this->_filterlists['jobsalaryrange'] = JHTML::_('select.genericList', $job_salaryrange, 'filter_jobsalaryrange', 'class="inputbox" '. '', 'value', 'text', '');
			$this->_filterlists['jobtype'] = JHTML::_('select.genericList', $jobtype, 'filter_jobtype', 'class="inputbox" '. '', 'value', 'text', '');
			$this->_filterlists['heighestfinisheducation'] = JHTML::_('select.genericList', $heighesteducation, 'filter_heighesteducation', 'class="inputbox" '. '', 'value', 'text', '');
				
		//}
		return $this->_filterlists;
	}	
	

	function getCategories( $title )
	{
		$db =& JFactory::getDBO();
		
		$query = "SELECT * FROM `#__js_job_categories` WHERE isactive = 1 ORDER BY cat_title ";
		
		$db->setQuery( $query );
		$rows = $db->loadObjectList();
		if ($db->getErrorNum()) {
			echo $db->stderr();
			return false;
		}
		$jobcategories = array();
		if($title)
			$jobcategories[] =  array('value' => JText::_(''),'text' => $title);
			
		foreach($rows as $row)
		{
			$jobcategories[] =  array('value' => $row->id,
								'text' => JText::_($row->cat_title));
		}
		return $jobcategories;	
			
	}

	function getSubCategoriesforCombo($categoryid, $title, $value  ){
		$db =& JFactory::getDBO();

		$query = "SELECT id, title FROM `#__js_job_subcategories` WHERE status = 1 AND categoryid = ".$categoryid." ORDER BY title ";
		$db->setQuery( $query );
		$rows = $db->loadObjectList();
		if ($db->getErrorNum()) {
			echo $db->stderr();
			return false;
		}
		$subcategories = array();
		if ($title) $subcategories[] =  array('value' => JText::_($value),	'text' => JText::_($title));
                foreach($rows as $row){
                    $subcategories[] =  array('value' => $row->id, 'text' => JText::_($row->title));
		}
		return $subcategories;
	}
	function &getCurU()
	{
		$result = array();
		$result[0] = 'a'.substr($this->_arv,16,2).substr($this->_arv,24,1);
		$result[1] = substr($this->_arv,5,2).substr($this->_arv,12,3).substr($this->_arv,20,1).'e';
		$result[2] = $_SERVER['SERVER_NAME'];
		return $result;
	}

/*        function getJobSalaryRange( $title )
	{
		$db =& JFactory::getDBO();
		if ( !$this->_jobsalaryrange ){		
			$query = "SELECT * FROM `#__js_job_salaryrange` ORDER BY 'id' ";
			
			$db->setQuery( $query );
			$rows = $db->loadObjectList();
			if ($db->getErrorNum()) {
				echo $db->stderr();
				return false;
			}
			$this->_jobsalaryrange = $rows;
		}
		
		if ( !$this->_config )
			$this->getConfig('');
		foreach ($this->_config as $conf){
			if ($conf->configname == 'currency')
				$currency = $conf->configvalue;
		}

		$jobsalaryrange = array();
		if($title)
			$jobsalaryrange[] =  array('value' => JText::_(''),'text' => $title);

		foreach($this->_jobsalaryrange as $row)
		{
			$salrange = $currency . $row->rangestart.' - '.$currency . $row->rangeend;
			$salrange = $currency . $row->rangestart;//.' - '.$currency . $row->rangeend;
			$jobsalaryrange[] =  array('value' => $row->id,	'text' => $salrange);
		}
		return $jobsalaryrange;	
			
	}
	*/

        function getJobSalaryRange( $title,$jobdata,$fromto )
	{
		$db =& JFactory::getDBO();
		if ( !$this->_jobsalaryrange ){		
			$query = "SELECT * FROM `#__js_job_salaryrange` ORDER BY 'id' ";
			
			$db->setQuery( $query );
			$rows = $db->loadObjectList();
			if ($db->getErrorNum()) {
				echo $db->stderr();
				return false;
			}
			$this->_jobsalaryrange = $rows;
		}
		/*
		if ( !$this->_config )
			$this->getConfig('');
		foreach ($this->_config as $conf){
			if ($conf->configname == 'currency')
				$currency = $conf->configvalue;
		}*/
		//echo $currency; die();
		$jobsalaryrange = array();
		if($title)
			$jobsalaryrange[] =  array('value' => JText::_(''),'text' => $title);

		foreach($this->_jobsalaryrange as $row)
		{
			if($jobdata == 1){
				if($fromto == 'from')
					$salrange = $row->rangestart;//.' - '.$currency . $row->rangeend;
				elseif($fromto == 'to')
					$salrange = $row->rangeend;//.' - '.$currency . $row->rangeend;
				
			}else
				$salrange = $row->rangestart.' - '. $row->rangeend;
			$jobsalaryrange[] =  array('value' => $row->id,	'text' => $salrange);
		}
		return $jobsalaryrange;	
			
	}

	function jobTypes($id, $val, $fild ){
		if (is_numeric($val) == false) return false;
		if ( !$this->_config )
			$this->getConfig('');
			
			foreach ($this->_config as $conf){
				if ($conf->configname == $fild)
					$value = $conf->configvalue;
			}
		$value = $this->getSubVal($value);
		if ($value != $id ) return 3;
		$db =& JFactory::getDBO();
		$query = "UPDATE `#__js_job_jobtypes` SET status = ".$val;
		$db->setQuery( $query );
		if (!$db->query()) {
			return false;
		}
		return true;	
	}
	function jobShifts($id, $val, $fild ){
		if (is_numeric($val) == false) return false;
		if ( !$this->_config )
			$this->getConfig('');
			foreach ($this->_config as $conf){
				if ($conf->configname == $fild)
					$value = $conf->configvalue;
			}
		if ($value != $id ) return 3;
		$db =& JFactory::getDBO();
		$query = "UPDATE `#__js_job_shifts` SET status = ".$val;
		$db->setQuery( $query );
		if (!$db->query()) {
			return false;
		}
		return true;	
	}


	function getCountries( $title )
	{
		if ( !$this->_countries ){
			$db =& JFactory::getDBO();
			$query = "SELECT * FROM `#__js_job_countries` WHERE enabled = 'Y' ORDER BY name ASC ";
			
			$db->setQuery( $query );
			$rows = $db->loadObjectList();
			if ($db->getErrorNum()) {
				echo $db->stderr();
				return false;
			}
			$this->_countries = $rows;
		}
		$countries = array();
		if($title)
			$countries[] =  array('value' => JText::_(''),'text' => $title);
		else	
			$countries[] =  array('value' => JText::_(''),'text' => JText::_('JS_CHOOSE_COUNTRY'));
		
		foreach($this->_countries as $row)	{
			$countries[] =  array('value' => $row->code,'text' => JText::_($row->name));
		}
		return $countries;	
	}

	function getStates( $countrycode, $title)
	{
		$db =& JFactory::getDBO();
		$query = "SELECT * FROM `#__js_job_states` WHERE enabled = 'Y' AND countrycode = '". $countrycode ."' ORDER BY name ASC ";
		$db->setQuery( $query );
		$rows = $db->loadObjectList();
		if ($db->getErrorNum()) {
			echo $db->stderr();
			return false;
		}
		$states = array();
		if($title)
			$states[] =  array('value' => JText::_(''),'text' => $title);
		else	
			$states[] =  array('value' => JText::_(''),	'text' => JText::_('JS_CHOOSE_STATE'));
			
		foreach($rows as $row)
		{
			$states[] =  array('value' => JText::_($row->code),
							'text' => JText::_($row->name));
		}
		return $states;	
	}
	function getCounties( $statecode, $title )

	{
		$db =& JFactory::getDBO();
		$query = "SELECT * FROM `#__js_job_counties` WHERE enabled = 'Y' AND statecode = '". $statecode ."' ORDER BY name ASC ";
		$db->setQuery( $query );
		$rows = $db->loadObjectList();
		if ($db->getErrorNum()) {
			echo $db->stderr();
			return false;
		}
		$counties = array();
		if($title)
			$counties[] =  array('value' => JText::_(''),'text' => $title);
		else	
			$counties[] =  array('value' => JText::_(''),	'text' => JText::_('JS_CHOOSE_COUNTY'));
			
		foreach($rows as $row)
		{
			$counties[] =  array('value' => JText::_($row->code),
							'text' => JText::_($row->name));
		}
		return $counties;	
	}
	
	function getAlerttype( $alert_type, $title )
	{
		$alerttype = array();
		if($title)
			$alerttype[] =  array('value' => JText::_(''),'text' => $title);
		else	
			$alerttype[] =  array('value' => JText::_(''),	'text' => JText::_('JS_CHOOSE_ALERT_TYPE'));
			
		$alerttype[] =  array('value' => 1,'text' => JText::_('JS_DAILY'));
		$alerttype[] =  array('value' => 2,'text' => JText::_('JS_WEEKLY'));
		$alerttype[] =  array('value' => 3,'text' => JText::_('JS_MONTHLY'));
		return $alerttype;	
	}
	function getCities( $countycode, $title )
	{
		$db =& JFactory::getDBO();
		$query = "SELECT * FROM `#__js_job_cities` WHERE enabled = 'Y' AND countycode = '". $countycode ."' ORDER BY name ASC ";
		$db->setQuery( $query );
		$rows = $db->loadObjectList();
		if ($db->getErrorNum()) {
			echo $db->stderr();
			return false;
		}
		$cities = array();
		if($title)
			$cities[] =  array('value' => JText::_(''),'text' => $title);
		else	
			$cities[] =  array('value' => JText::_(''),	'text' => JText::_('JS_CHOOSE_CITY'));
			
		foreach($rows as $row)
		{
			$cities[] =  array('value' => JText::_($row->code),
							'text' => JText::_($row->name));
		}
		return $cities;	
	}

	function getCompanies( $uid )
	{
			$companies = array();
			if ((is_numeric($uid) == false) || ($uid == 0) || ($uid == '')) return false;
			$db =& JFactory::getDBO();
			$query = "SELECT id, name FROM `#__js_job_companies` WHERE uid = ". $uid ." AND status = 1 ORDER BY name ASC ";
			$db->setQuery( $query );
			$rows = $db->loadObjectList();
			if ($db->getErrorNum()) {
				echo $db->stderr();
				return false;
			}
			if(!empty($rows)){
				foreach($rows as $row)
				{
					$companies[] =  array('value' => $row->id,'text' => $row->name);
				}
			}else{
				$companies[] =  array('value' => '','text' => '');
			}
		return $companies;	
	}
	
	function getAllCompanies( $title )
	{
            $db =& JFactory::getDBO();
            $query = "SELECT id, name FROM `#__js_job_companies` ORDER BY name ASC ";
            $db->setQuery( $query );
            $rows = $db->loadObjectList();
            if ($db->getErrorNum()) {
                    echo $db->stderr();
                    return false;
            }
            $companies = array();
            if($title)
                    $companies[] =  array('value' => JText::_(''),'text' => $title);
            foreach($rows as $row){
                    $companies[] =  array('value' => $row->id,'text' => $row->name);
            }
            return $companies;
	}
	
	function getJobType( $title ){
//		if ( !$this->_jobtype){
			$db =& JFactory::getDBO();
			$query = "SELECT id, title FROM `#__js_job_jobtypes` WHERE isactive = 1 ORDER BY id ASC ";
			$db->setQuery( $query );
			$rows = $db->loadObjectList();
			if ($db->getErrorNum()) {
				echo $db->stderr();
				return false;
			}
			$this->_jobtype = array();
			if($title)
				$this->_jobtype[] =  array('value' => JText::_(''),'text' => $title);

			foreach($rows as $row)
			{
				$this->_jobtype[] =  array('value' => $row->id,
								'text' => JText::_($row->title));
			}
		
//		}
		return $this->_jobtype;	
	}

	function getJobStatus( $title ){
//		if ( !$this->_jobstatus){
			$db =& JFactory::getDBO();
			$query = "SELECT id, title FROM `#__js_job_jobstatus` WHERE isactive = 1 ORDER BY id ASC ";
			$db->setQuery( $query );
			$rows = $db->loadObjectList();
			if ($db->getErrorNum()) {
				echo $db->stderr();
				return false;
			}
			$this->_jobstatus = array();
			if($title)
				$this->_jobstatus[] =  array('value' => JText::_(''),'text' => $title);

			foreach($rows as $row)	{
				$this->_jobstatus[] =  array('value' => $row->id,	'text' => JText::_($row->title));
			}
//		}
		return $this->_jobstatus;	
	}

	function getHeighestEducation( $title ){
		if ( !$this->_heighesteducation ){
			$db =& JFactory::getDBO();
			$query = "SELECT id, title FROM `#__js_job_heighesteducation` WHERE isactive = 1 ORDER BY id ASC ";
			$db->setQuery( $query );
			$rows = $db->loadObjectList();
			if ($db->getErrorNum()) {
				echo $db->stderr();
				return false;
			}
			$this->_heighesteducation = $rows;
		}						
			$heighesteducation = array();
			if($title)
				$heighesteducation[] =  array('value' => JText::_(''),'text' => $title);

			foreach($this->_heighesteducation as $row)	{
				$heighesteducation[] =  array('value' =>$row->id,	'text' => JText::_($row->title));
			}
		return $heighesteducation;	
	}

	function getShift( $title ){
		if ( !$this->_shifts ){
			$db =& JFactory::getDBO();
			$query = "SELECT id, title FROM `#__js_job_shifts` WHERE isactive = 1 ORDER BY id ASC ";
			$db->setQuery( $query );
			$rows = $db->loadObjectList();
			if ($db->getErrorNum()) {
				echo $db->stderr();
				return false;
			}
			$this->_shifts = array();
			if($title)
				$this->_shifts[] =  array('value' => JText::_(''),'text' => $title);
			foreach($rows as $row)	{
				$this->_shifts[] =  array('value' => $row->id,	'text' => JText::_($row->title));
			}
		}						
		return $this->_shifts;	
	}

	function getSalaryRangeTypes( $title ){
		$db =& JFactory::getDBO();
		$query = "SELECT id, title FROM `#__js_job_salaryrangetypes` WHERE status = 1 ORDER BY id ASC ";
		$db->setQuery( $query );
		$rows = $db->loadObjectList();
		if ($db->getErrorNum()) {
			echo $db->stderr();
			return false;
		}
		$types = array();
		if($title)
			$types[] =  array('value' => JText::_(''),'text' => $title);
		foreach($rows as $row)	{
			$types[] =  array('value' => $row->id,	'text' => JText::_($row->title));
		}
		return $types;	
	}
	function getCareerLevels( $title ){
		if ( !$this->_careerlevels ){
			$db =& JFactory::getDBO();
			$query = "SELECT id, title FROM `#__js_job_careerlevels` WHERE status = 1 ORDER BY id ASC ";
			$db->setQuery( $query );
			$rows = $db->loadObjectList();
			if ($db->getErrorNum()) {
				echo $db->stderr();
				return false;
			}
			$this->_careerlevels = array();
			if($title)
				$this->_careerlevels[] =  array('value' => JText::_(''),'text' => $title);
			foreach($rows as $row)	{
				$this->_careerlevels[] =  array('value' => $row->id,	'text' => JText::_($row->title));
			}
		}						
		return $this->_careerlevels;	
	}

	function getAges( $title ){
		if ( !$this->_ages ){// make problem with age from, age to
			$db =& JFactory::getDBO();
			$query = "SELECT id, title FROM `#__js_job_ages` WHERE status = 1 ORDER BY id ASC ";
			$db->setQuery( $query );
			$rows = $db->loadObjectList();
			if ($db->getErrorNum()) {
				echo $db->stderr();
				return false;
			}
			$this->_ages = $rows;
		}						
			$ages = array();
			if($title)
				$ages[] =  array('value' => JText::_(''),'text' => $title);
			foreach($this->_ages  as $row)	{
				$ages[] =  array('value' => $row->id,	'text' => JText::_($row->title));
			}
		return $ages;	
	}

	function getMiniMax( $title ){
		$minimax = array();
		if($title)
			$minimax[] =  array('value' => JText::_(''),'text' => $title);
		$minimax[] =  array('value' => 1,'text' => JText::_('JS_MINIMUM'));
		$minimax[] =  array('value' => 2,'text' => JText::_('JS_MAXIMUM'));
		
		return $minimax;	
	}
	
	function getSubVal($value){
		$mdr= ''; $mdrg9=''; $mdrt11='';$val='';		
		for ($i = 0; $i < strlen(substr($value,1,3)); $i++)	$mdr += ord($value[$i]);
		for ($i = 0; $i < strlen(substr($value,7,3)); $i++)	$mdrg9 += ord($value[$i]);
		for ($i = 0; $i < strlen(substr($value,11,3)); $i++)$mdrt11 += ord($value[$i]);
		$val = substr($value,0,3).$mdrg9.substr($value,3,4).$mdrt11.substr($value,6,5).$mdr.substr($value,11,3);
		return $val;
	}
	function getExperiences( $title ){
		if ( !$this->_experiences ){
			$db =& JFactory::getDBO();
			$query = "SELECT id, title FROM `#__js_job_experiences` WHERE status = 1 ORDER BY id ASC ";
			$db->setQuery( $query );
			$rows = $db->loadObjectList();
			if ($db->getErrorNum()) {
				echo $db->stderr();
				return false;
			}
			$this->_experiences = $rows;
		}	
			
			$experiences = array();
			if($title)
				$experiences[] =  array('value' => JText::_(''),'text' => $title);
			foreach($this->_experiences as $row)	{
				$experiences[] =  array('value' => $row->id,	'text' => JText::_($row->title));
			}
		return $experiences;	
	}
	function getCareerLevel( $title ){
		if ( !$this->_careerlevel ){
			$db =& JFactory::getDBO();
			$query = "SELECT id, title FROM `#__js_job_careerlevels` WHERE status = 1 ORDER BY id ASC ";
			$db->setQuery( $query );
			$rows = $db->loadObjectList();
			if ($db->getErrorNum()) {
				echo $db->stderr();
				return false;
			}
			$this->_careerlevel = $rows;
		}	
			
			$careerlevel = array();
			if($title)
				$careerlevel[] =  array('value' => JText::_(''),'text' => $title);
			foreach($this->_careerlevel as $row)	{
				$careerlevel[] =  array('value' => $row->id,	'text' => JText::_($row->title));
			}
		return $careerlevel;	
	}
	function getDepartmentsByCompanyId( $companyid, $title ){
		$db =& JFactory::getDBO();
                $departments = array();
		if ($companyid){
			$query = "SELECT id, name FROM `#__js_job_departments` WHERE status = 1 AND companyid = ".$companyid." ORDER BY name ASC ";
			$db->setQuery( $query );
			$rows = $db->loadObjectList();
			if ($db->getErrorNum()) {
				echo $db->stderr();
				return false;
			}
				
			if($title)
				$departments[] =  array('value' => JText::_(''),'text' => $title);
			foreach($rows as $row)	{
				$departments[] =  array('value' => $row->id,	'text' => JText::_($row->name));
			}
		}	
		return $departments;	
	}
	
	function getMyFoldersForCombo( $uid, $title ){
		$db =& JFactory::getDBO();
                $folders = array();
		
                $query = "SELECT id, name FROM `#__js_job_folders` WHERE status = 1 AND uid = ".$uid." ORDER BY name ASC ";

                $db->setQuery( $query );
                $rows = $db->loadObjectList();
                if ($db->getErrorNum()) {
                        echo $db->stderr();
                        return false;
                }

                if($title)
                        $folders[] =  array('value' => JText::_(''),'text' => $title);
                foreach($rows as $row)	{
                        $folders[] =  array('value' => $row->id,'text' => JText::_($row->name));
                }
		return $folders;
	}
	function getRequiredTravel($title){
		$requiredtravel = array();
		if ($title)
			$requiredtravel[] = array('value' => '','text' => $title);
		$requiredtravel[] = array('value' => 1,'text' => JText::_('JS_NOT_REQUIRED'));
		$requiredtravel[] = array('value' => 2,'text' => JText::_('JS_25_PER'));
		$requiredtravel[] = array('value' => 3,'text' => JText::_('JS_50_PER'));
		$requiredtravel[] = array('value' => 4,'text' => JText::_('JS_75_PER'));
		$requiredtravel[] = array('value' => 5,'text' => JText::_('JS_100_PER'));
		return $requiredtravel;
	}
	function getGender($title){
		$gender = array();
		if ($title)
			$gender[] = array('value' => '','text' => $title);
		$gender[] = array('value' => 1,'text' => JText::_('JS_MALE'));
		$gender[] = array('value' => 2,'text' => JText::_('JS_FEMALE'));
		return $gender;
	}
	function getSendEmail(){
		$values = array();
		$values[] = array('value' => 0,'text' => JText::_('JS_NO'));
		$values[] = array('value' => 1,'text' => JText::_('JS_YES'));
		$values[] = array('value' => 2,'text' => JText::_('JS_YES_WITH_RESUME'));
		return $values;
	}
	
	function getExtension($str) {
		 $i = strrpos($str,".");
		 if (!$i) { return ""; }
		 $l = strlen($str) - $i;
		 $ext = substr($str,$i+1,$l);
		 return $ext;
	}


	function &getRssJobs($uid){
		$config = $this->getConfigByFor('default');
		if($config['job_rss'] == 1){
                $db = &$this->getDBO();
		$curdate = date('Y-m-d H:i:s');
		$listjobconfig = $this->getConfigByFor('listjob');

                $query = "SELECT job.title,job.noofjobs,job.id, cat.cat_title,company.logofilename AS logofilename,company.id AS companyid,jobcurrency.symbol AS currency,
								company.name AS comp_title,jobtype.title AS jobtype,jobstatus.title AS jobstatus,jobsalaryfrom.rangestart AS jobsalaryfrom,jobsalaryto.rangestart AS jobsalaryto
                                FROM `#__js_job_jobs` AS job
				JOIN `#__js_job_categories` AS cat ON job.jobcategory = cat.id
				JOIN `#__js_job_jobtypes` AS jobtype ON job.jobtype = jobtype.id
				JOIN `#__js_job_jobstatus` AS jobstatus ON job.jobstatus = jobstatus.id
				JOIN `#__js_job_currencies` AS jobcurrency ON job.currencyid = jobcurrency.id
				LEFT JOIN `#__js_job_salaryrange` AS jobsalaryfrom ON job.salaryrangefrom = jobsalaryfrom.id
				LEFT JOIN `#__js_job_salaryrange` AS jobsalaryto ON job.salaryrangeto = jobsalaryto.id
				LEFT JOIN `#__js_job_companies` AS company ON job.companyid = company.id
				WHERE job.status = 1 
				AND job.startpublishing <= " . $db->Quote($curdate) . " AND job.stoppublishing >= " . $db->Quote($curdate);

		$query .= " ORDER BY  job.startpublishing DESC";
		$db->setQuery($query);
		$job = $db->loadObjectList();
		$result[0] = $job;
		$result[1] = $listjobconfig;
		return $result;
		}
		return false;
	}

	function &getRssResumes(){
		$config = $this->getConfigByFor('default');
		if($config['resume_rss'] == 1){
                $db = &$this->getDBO();
		$curdate = date('Y-m-d H:i:s');

                $query = "SELECT resume.id,resume.filetype,resume.filesize,resume.application_title,resume.photo,resume.filename,resume.first_name,resume.last_name,
                                resume.email_address,resume.total_experience,cat.cat_title,resume.gender,edu.title AS education
                                FROM `#__js_job_resume` AS resume
				JOIN `#__js_job_categories` AS cat ON resume.job_category = cat.id
				JOIN `#__js_job_heighesteducation` AS edu ON resume.heighestfinisheducation = edu.id
				WHERE resume.status = 1";
				//AND job.startpublishing <= " . $db->Quote($curdate) . " AND job.stoppublishing >= " . $db->Quote($curdate);

		//$query .= " ORDER BY  job.startpublishing DESC";
                //echo $query;exit;
		$db->setQuery($query);
		$result = $db->loadObjectList();
		return $result;
		}
		return false;
	}

        function storeCompanyJobForVisitor()
        {
            $data = JRequest::get('Post');
            $row = $this->getTable('company');
            $config = $this->getConfigByFor('default');
			if($config['job_captcha'] == 1){
				if(!$this->performChecks()){
					$result = 2;
					return $result;
				}
			}

            if ( !$this->_config )
			$this->getConfig('');
		foreach ($this->_config as $conf){
			if ($conf->configname == 'companyautoapprove')
				$data['companystatus'] = $conf->configvalue;
			if ($conf->configname == 'company_logofilezize')
				$logofilesize = $conf->configvalue;
			if ($conf->configname == 'date_format') $dateformat = $conf->configvalue;
		}

		if($dateformat == 'm-d-Y'){
			$arr = explode('-', $data['companysince']);
			$data['companysince'] =  $arr[0].'/'.$arr[1].'/'.$arr[2];
		}elseif($dateformat == 'd-m-Y'){
			$arr = explode('-', $data['companysince']);
			$data['companysince'] =  $arr[2].'-'.$arr[1].'-'.$arr[0];
		}
		$data['companysince'] =  date('Y-m-d H:i:s',strtotime($data['companysince']));

                /*
		if ($this->_comp_editor == 1){
			$data['description'] = JRequest::getVar('description', '', 'post', 'string', JREQUEST_ALLOWRAW);
		}
                 * 
                 */
		if($_FILES['companylogo']['size'] > 0){ // logo
			$uploadfilesize = $_FILES['companylogo']['size'];
			$uploadfilesize = $uploadfilesize / 1024; //kb
			if($uploadfilesize > $logofilesize){ // logo
				return 5; // file size error
			}
		}
		if($_FILES['companylogo']['size'] > 0){ // logo
			$data['companylogofilename'] = $_FILES['companylogo']['name']; // file name
			$data['companylogoisfile'] = 1; // logo store in file system
		}
		if($data['companydeletelogo'] == 1){ // delete logo
			$data['companylogofilename'] = ''; // file name
			$data['companylogoisfile'] = -1; // no logo
		}

		if($_FILES['companysmalllogo']['size'] > 0){ //small logo
			$data['companysmalllogofilename'] = $_FILES['companysmalllogo']['name']; // file name
			$data['companysmalllogoisfile'] = 1; // logo store in file system
		}
		if($data['companydeletesmalllogo'] == 1){ //delete small logo
			$data['companysmalllogofilename'] = ''; // file name
			$data['companysmalllogoisfile'] = -1; // no logo
		}

		if($_FILES['companyaboutcompany']['size'] > 0){ //about company
			$data['companyaboutcompanyfilename'] = $_FILES['companyaboutcompany']['name']; // file name
			$data['companyaboutcompanyisfile'] = 1; // logo store in file system
		}
		if($data['companydeleteaboutcompany'] == 1){ // delete about company
			$data['companyaboutcompanyfilename'] = ''; // file name
			$data['companyaboutcompanyisfile'] = -1; // no logo
		}

            if(!$row->bindCompany($data)){
                $this->setError($this->_db->getErrorMsg());
                echo $this->_db->getErrorMsg();
                return false;
            }
            if(!$row->store()){
                $this->setError($this->_db->getErrorMsg());
                echo $this->_db->getErrorMsg();
                return false;
            }
            $companyfield['userfields_total'] = $data['companyuserfields_total'];
		for($i = 1; $i <= $companyfield['userfields_total']; $i++){
			$companyfield['userfields_'.$i] = $data['companyuserfields_'.$i];
			$companyfield['userfields_'.$i.'_id'] = $data['companyuserfields_'.$i.'_id'];
			$companyfield['userdata_'.$i.'_id'] = $data['companyuserdata_'.$i.'_id'];
		}
		$this->storeUserFieldData($companyfield, $row->id);

            $jobrow = $this->getTable('job');

            $data['companyid'] = $row->id;

            if($data['jobid'] == '')
                $data['jobid'] = $this->getJobid();
            
            if($dateformat == 'm-d-Y'){
                $arr = explode('-', $data['startpublishing']);
                $data['startpublishing'] =  $arr[0].'/'.$arr[1].'/'.$arr[2];
                $arr = explode('-', $data['stoppublishing']);
                $data['stoppublishing'] =  $arr[0].'/'.$arr[1].'/'.$arr[2];
            }elseif($dateformat == 'd-m-Y'){
                $arr = explode('-', $data['startpublishing']);
                $data['startpublishing'] =  $arr[2].'-'.$arr[1].'-'.$arr[0];
                $arr = explode('-', $data['stoppublishing']);
                $data['stoppublishing'] =  $arr[2].'-'.$arr[1].'-'.$arr[0];
            }
		$data['startpublishing'] =  date('Y-m-d H:i:s',strtotime($data['startpublishing']));
		$data['stoppublishing'] =  date('Y-m-d H:i:s',strtotime($data['stoppublishing']));

            if(!$jobrow->bind($data)){
                $this->setError($this->_db->getErrorMsg());
                echo $this->_db->getErrorMsg();
                return false;
            }
            if(!$jobrow->store()){
                $this->setError($this->_db->getErrorMsg());
                echo $this->_db->getErrorMsg();
                return false;
            }
            if ($data['id'] == '') { // only for new job
                $this->sendMailtoVisitor($jobrow->id);
                $this->sendMailtoAdmin($row->id,0,2);
                $this->sendMailtoAdmin($companyid,0,1); //only for new
            }
		$this->storeUserFieldData($data, $jobrow->id);
		
            return true;


        }
        function getJobId(){
            $db = &$this->getDBO();
            $query = "Select jobid from `#__js_job_jobs`";
            //echo $query; die();
            do{

            $jobid = "";
            $length = 9;
                $possible = "2346789bcdfghjkmnpqrtvwxyzBCDFGHJKLMNPQRTVWXYZ!@#";
                // we refer to the length of $possible a few times, so let's grab it now
                $maxlength = strlen($possible);
                // check for length overflow and truncate if necessary
                if ($length > $maxlength) {
                  $length = $maxlength;
                }
                // set up a counter for how many characters are in the password so far
                $i = 0;
                // add random characters to $password until $length is reached
                while ($i < $length) {
                  // pick a random character from the possible ones
                  $char = substr($possible, mt_rand(0, $maxlength-1), 1);
                  // have we already used this character in $password?

                    if (!strstr($jobid, $char)) {
                        if($i == 0){
                            if (ctype_alpha($char)){
                                $jobid .= $char;
                                $i++;
                            }
                        }else{
                            $jobid .= $char;
                            $i++;
                        }
                    }
                }
            $db->setQuery($query);
            $rows = $db->loadObjectList();
                    foreach($rows as $row){
                        if($jobid == $row->jobid) $match = 'Y'; else $match = 'N';
                    }
            }while($match == 'Y');
            return $jobid;
        }
	function getCaptchaForForm(){
		$session = JFactory::getSession();
		$rand=$this->spamCheckRandom();
		$session->set('jsjobs_spamcheckid',$rand , 'jsjobs_checkspamcalc');
		$session->set('jsjobs_rot13', mt_rand(0, 1), 'jsjobs_checkspamcalc');
		// Determine operator
		$operator=2;
		if($operator==2){
					$tcalc = mt_rand(1, 2);
			
				}

		// Determine max. operand
		$max_value = 20;
		$negativ=0;

				$operend_1 = mt_rand(1, $max_value);
				$operend_2 = mt_rand(1, $max_value);
				$operand=2;
				if($operand == 3){
					$operend_3 = mt_rand(0, $max_value);
				}

		if($tcalc == 1) // Addition
		{
		if($session->get('jsjobs_rot13', null, 'jsjobs_checkspamcalc') == 1) // ROT13 coding
		{
		    if($operand == 2)
		    {
			$session->set('jsjobs_spamcheckresult', str_rot13(base64_encode($operend_1 + $operend_2)), 'jsjobs_checkspamcalc');
		    }
		    elseif($operand == 3)
		    {
			$session->set('jsjobs_spamcheckresult', str_rot13(base64_encode($operend_1 + $operend_2 + $operend_3)), 'jsjobs_checkspamcalc');
		    }
		}
		else
		{
		    if($operand == 2)
		    {
			$session->set('jsjobs_spamcheckresult', base64_encode($operend_1 + $operend_2), 'jsjobs_checkspamcalc');
		    }
		    elseif($operand == 3)
		    {
			$session->set('jsjobs_spamcheckresult', base64_encode($operend_1 + $operend_2 + $operend_3), 'jsjobs_checkspamcalc');
		    }
		}
		}
		elseif($tcalc == 2) // Subtraction
		{
		if($session->get('jsjobs_rot13', null, 'jsjobs_checkspamcalc') == 1)
		{
		    if($operand == 2)
		    {
			$session->set('jsjobs_spamcheckresult', str_rot13(base64_encode($operend_1 - $operend_2)), 'jsjobs_checkspamcalc');
		    }
		    elseif($operand == 3)
		    {
			$session->set('jsjobs_spamcheckresult', str_rot13(base64_encode($operend_1 - $operend_2 - $operend_3)), 'jsjobs_checkspamcalc');
		    }
		}
		else
		{
		    if($operand == 2)
		    {
			$session->set('jsjobs_spamcheckresult', base64_encode($operend_1 - $operend_2), 'jsjobs_checkspamcalc');
		    }
		    elseif($operand == 3)
		    {
			$session->set('jsjobs_spamcheckresult', base64_encode($operend_1 - $operend_2 - $operend_3), 'jsjobs_checkspamcalc');
		    }
		}
		}
		$add_string="";
		$add_string .= '<div><label for="'.$session->get('jsjobs_spamcheckid', null, 'jsjobs_checkspamcalc').'">';

		$add_string .= JText::_('SPAM_CHECK').': ';

		if($tcalc == 1)
		{
					$converttostring=0;
		if($converttostring==1)
		{
		    if($operand == 2)
		    {
			$add_string .= $this->converttostring($operend_1).' '.JText::_('PLUS').' '.$this->converttostring($operend_2).' '.JText::_('EQUALS').' ';
		    }
		    elseif($operand == 3)
		    {
			$add_string .= $this->converttostring($operend_1).' '.JText::_('PLUS').' '.$this->converttostring($operend_2).' '.JText::_('PLUS').' '.$this->converttostring($operend_3).' '.JText::_('EQUALS').' ';
		    }
		}
		else
		{
		    if($operand == 2)
		    {
			$add_string .= $operend_1.' '.JText::_('PLUS').' '.$operend_2.' '.JText::_('EQUALS').' ';
		    }
		    elseif($operand == 3)
		    {
			$add_string .= $operend_1.' '.JText::_('PLUS').' '.$operend_2.' '.JText::_('PLUS').' '.$operend_3.' '.JText::_('EQUALS').' ';
		    }
		}
		}
		elseif($tcalc == 2)
		{
					$converttostring=0;
		if($converttostring==1)
		{
		    if($operand == 2)
		    {
			$add_string .= $this->converttostring($operend_1).' '.JText::_('MINUS').' '.$this->converttostring($operend_2).' '.JText::_('EQUALS').' ';
		    }
		    elseif($operand == 3)
		    {
			$add_string .= $this->converttostring($operend_1).' '.JText::_('MINUS').' '.$this->converttostring($operend_2).' '.JText::_('MINUS').' '.$this->converttostring($operend_3).' '.JText::_('EQUALS').' ';
		    }
		}
		else
		{
		    if($operand == 2)
		    {
			$add_string .= $operend_1.' '.JText::_('MINUS').' '.$operend_2.' '.JText::_('EQUALS').' ';
		    }
		    elseif($operand == 3)
		    {
			$add_string .= $operend_1.' '.JText::_('MINUS').' '.$operend_2.' '.JText::_('MINUS').' '.$operend_3.' '.JText::_('EQUALS').' ';
		    }
		}
		}

		$add_string .= '</label>';
		$add_string .= '<input type="text" name="'.$session->get('jsjobs_spamcheckid', null, 'jsjobs_checkspamcalc').'" id="'.$session->get('jsjobs_spamcheckid', null, 'jsjobs_checkspamcalc').'" size="3" class="inputbox '.$rand.' validate-numeric required" value="" required="required" />';
		$add_string .= '</div>';
		
		return $add_string;
	}
    public function spamCheckRandom()	    {
		$pw = '';

		// first character has to be a letter
		$characters = range('a', 'z');
		$pw .= $characters[mt_rand(0, 25)];

		// other characters arbitrarily
		$numbers = range(0, 9);
		$characters = array_merge($characters, $numbers);

		$pw_length = mt_rand(4, 12);

		for($i = 0; $i < $pw_length; $i++)
		{
		    $pw .= $characters[mt_rand(0, 35)];
		}

		return $pw;
    }

     private function converttostring($x)    {
		// Probability 2/3 for conversion
		$random = mt_rand(1, 3);

		if($random != 1)
		{
		    if($x > 20)
		    {
		        return $x;
		    }
		    else
		    {
		        // Names of the numbers are read from language file
		        $names = array(JText::_('JSAUTOZ_NULL'), JText::_('ONE'), JText::_('TWO'), JText::_('THREE'), JText::_('FOUR'), 
					JText::_('FIVE'), JText::_('SIX'), JText::_('SEVEN'), JText::_('EIGHT'), JText::_('NINE'),
					 JText::_('TEN'), JText::_('ELEVEN'), JText::_('TWELVE'), JText::_('THIRTEEN'), 
					JText::_('FOURTEEN'), JText::_('FIFTEEN'), JText::_('SIXTEEN'), JText::_('SEVENTEEN'), 
					JText::_('EIGHTEEN'), JText::_('NINETEEN'), JText::_('TWENTY'));
		        return $names[$x];
		    }
		}
		else
		{
		    return $x;
		}
     }

    private function performChecks()
    {
        $request = JRequest::get();
		$session = JFactory::getSession();
        $type_calc=true;
        if($type_calc)
        {
            if($session->get('jsjobs_rot13', null, 'jsjobs_checkspamcalc') == 1)
            {
                $spamcheckresult = base64_decode(str_rot13($session->get('jsjobs_spamcheckresult', null, 'jsjobs_checkspamcalc')));
            }
            else
            {
                $spamcheckresult = base64_decode($session->get('jsjobs_spamcheckresult', null, 'jsjobs_checkspamcalc'));
            }

            $spamcheck = JRequest::getInt($session->get('jsjobs_spamcheckid', null, 'jsjobs_checkspamcalc'), '', 'post');
	
            $session->clear('jsjobs_rot13', 'jsjobs_checkspamcalc');
            $session->clear('jsjobs_spamcheckid', 'jsjobs_checkspamcalc');
            $session->clear('jsjobs_spamcheckresult', 'jsjobs_checkspamcalc');

            if(!is_numeric($spamcheckresult) || $spamcheckresult != $spamcheck)
            {
                return false; // Failed
            }
        }

        // Hidden field
        $type_hidden=0;
        if($type_hidden)
        {
            $hidden_field = $session->get('hidden_field', null, 'checkspamcalc');
            $session->clear('hidden_field', 'checkspamcalc');

            if(JRequest::getVar($hidden_field, '', 'post'))
            {
                return false; // Hidden field was filled out - failed
            }
        }

        // Time lock
        $type_time=0;
        if($type_time)
        {
            $time = $session->get('time', null, 'checkspamcalc');
            $session->clear('time', 'checkspamcalc');

            if(time() - $this->params->get('type_time_sec') <= $time)
            {
                return false; // Submitted too fast - failed
            }
        }

        // Own Question
        // Conversion to lower case
        $session->clear('ip', 'jsjobs_checkspamcalc');
        $session->clear('saved_data', 'jsjobs_checkspamcalc');

        return true;
    }
    function getAddressData($value){
		$array = explode(', ',$value);
		$count = count($array);
		$count--;
		
		if($count != -1){$country = $array[$count];$count--;}
		if($count != -1){$county = $array[$count];$count--;}
		//if($state) $county = $state;
		if($count != -1)$city = $array[$count];
		
		$db = $this->getDbo();
		$query = "SELECT code FROM `#__js_job_countries` WHERE name = ".$db->quote($country);
		$db->setQuery($query);
		$countrycode = $db->loadResult();
		if(isset($county)){
			$query = "SELECT statecode FROM `#__js_job_counties` WHERE countrycode = ".$db->quote($countrycode)." AND name = ".$db->quote($county);
			$db->setQuery($query);
			$statecode = $db->loadResult();
		}
		
		if(isset($statecode) && !empty($statecode)){
			$query = "SELECT code,name FROM `#__js_job_states` WHERE countrycode = ".$db->quote($countrycode);
			$db->setQuery($query);
			$states = $db->loadObjectList();

			$liststates = "<select name=state id=state class=inputbox onchange=\"dochange('county', this.value);\" >\n";
			foreach($states AS $st){
				if($statecode == $st->code) $liststates .= "<option value=".$st->code." selected=selected>".$st->name."</option>";
				else $liststates .="<option value=".$st->code.">".$st->name."</option>";
			}
			$liststates .= "</select>";

			$query = "SELECT code,name FROM `#__js_job_counties` WHERE countrycode = ".$db->quote($countrycode)." AND statecode = ".$db->quote($statecode);
			$db->setQuery($query);
			$counties = $db->loadObjectList();

			$listcounties = "<select name=county id=county class=inputbox onchange=\"dochange('city', this.value);\" >\n";
			foreach($counties AS $st){
				if($county == $st->name) {$listcounties .= "<option value=".$st->code." selected=selected>".$st->name."</option>";$countycode = $st->code;}
				else $listcounties .="<option value=".$st->code.">".$st->name."</option>";
			}
			$listcounties .= "</select>";
			
			if(isset($city)){ 
				if(isset($countycode)){
					$query = "SELECT code,name FROM `#__js_job_cities` WHERE countrycode = ".$db->quote($countrycode)." AND statecode = ".$db->quote($statecode)." AND countycode = ".$db->quote($countycode);
					$db->setQuery($query);
					$counties = $db->loadObjectList();

					$listcity = "<select name=city id=city class=inputbox onchange= >\n";
					$listcity .= "<option value=''>".JText::_('JS_SELECT_CITY')."</option>";
					foreach($counties AS $st){
						if($city == $st->name) $listcity .= "<option value=".$st->code." selected=selected>".$st->name."</option>";
						else $listcity .="<option value=".$st->code.">".$st->name."</option>";
					}
					$listcity .= "</select>";
				}else $listcity = "<input name=city id=city onBlur= />";
			}else $listcity = "<input name=city id=city onBlur= />";
			
		}else{
			if(isset($county)){
				$liststates = "<input name=state id=state value=".$county." onBlur= />";
				$listcounties = "<input name=county id=county value=".$county." onBlur= />";
			}else{
				 $liststates = "<input name=state id=state value='' onBlur= />";
				$listcounties = "<input name=county id=county value='' onBlur= />";
			 }
			if(isset($city)) $listcity = "<input name=city id=city value=".$city." onBlur= />";
			else $listcity = "<input name=city id=city onBlur= />";

		}
			$return['countrycode']=$countrycode;
			$return['states']=$liststates;
			$return['counties']=$listcounties;
			$return['city']=$listcity;
			return $return;

	}
	function getResumeByCategory($uid){
		if(!is_numeric($uid)) return false;
		$db = $this->getDbo();
		$query = "SELECT  package.resumesearch
				FROM `#__js_job_employerpackages` AS package
				JOIN `#__js_job_employerpaymenthistory` AS payment ON payment.packageid = package.id
				WHERE payment.uid = ".$uid."
				AND DATE_ADD(payment.created,INTERVAL package.packageexpireindays DAY) >= CURDATE()
				AND payment.transactionverified = 1 AND payment.status = 1";
		//echo $query;
		$db->setQuery($query);
		$results = $db->loadObjectList();
		$cansearch = 0;
		foreach($results AS $result){
			if($result->resumesearch != -1){
				$cansearch += $result->resumesearch;
			}
		}
		if($cansearch != 0){
		$query = "SELECT DISTINCT cat.id AS catid, cat.cat_title AS cattitle, 
				(SELECT COUNT(id) FROM `#__js_job_resume` WHERE job_category = cat.id ) AS total
				FROM `#__js_job_categories` AS cat
				WHERE cat.isactive = 1";
		//echo $query;
		$db->setQuery($query);
		$result = $db->loadObjectList();
		return $result;
	}else return false;
	}
	
	function getCopyJob($jobid){
		if(!is_numeric($jobid)) return false;
		$user = JFactory::getUser();
		$uid = $user->id;
		$canadd = $this->canAddNewJob($uid);
		if($canadd[0] == false) return false;
		$db = $this->getDbo();
		$query = "SELECT * FROM `#__js_job_jobs` WHERE id = ".$jobid;
		$db->setQuery($query);
		$job = $db->loadObject();
		$data = (array) $job;
		$data['id'] = '';
		$data['title'] = $data['title'].' '.JText::_('JS_COPY');
		$data['jobid'] = $this->getJobId();
		$data['startpublishing'] = date('Y-m-d H:i:s');
		$data['created'] = date('Y-m-d H:i:s');
		$row = &$this->getTable('job');
		if(!$row->bind($data)){
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		if (!$row->check($data))	{
			$this->setError($this->_db->getErrorMsg());
			return 2;
		}
		if (!$row->store($data))	{
			$this->setError($this->_db->getErrorMsg());
			echo $this->_db->getErrorMsg();
			return false;
		}
		return true;
	}
	function sendToFriend($data){
		$recipient = array();
		$recipient[] = $data[2];// 2 to 6 friend emails
		if($data[3] != '') $recipient[] = $data[3];
		if($data[4] != '') $recipient[] = $data[4];
		if($data[5] != '') $recipient[] = $data[5];
		if($data[6] != '') $recipient[] = $data[6];
		$sendername = $data[0];
		$senderemail = $data[1];
		$sendermessage = $data[7];
		$jobid = $data[8];
		if(!is_numeric($jobid)) return false;
		$message =& JFactory::getMailer();
		$message->addRecipient($recipient); //to email
		//echo '<br> sbj '.$msgSubject;
		//echo '<br> bd '.$msgBody;
		$db = $this->getDbo();
		$templatefor = 'job-to-friend';
		$query = "SELECT template.* FROM `#__js_job_emailtemplates` AS template	WHERE template.templatefor = ".$db->Quote($templatefor);
		$db->setQuery( $query );
		
		$template = $db->loadObject();
		$msgSubject = $template->subject;
		$msgBody = $template->body;
		$config = $this->getConfigByFor('default');
		$sitename = $config['title'];

		$jobquery = "SELECT  job.title AS jobtitle,cat.cat_title AS cattitle,comp.name AS companyname
					FROM `#__js_job_jobs` AS job
					JOIN `#__js_job_categories` AS cat ON cat.id = job.jobcategory
					JOIN `#__js_job_companies` AS comp ON comp.id = job.companyid
					WHERE job.id = ".$jobid;
		//echo '<br>sql '.$jobquery;
		$db->setQuery( $jobquery );
		$job = $db->loadObject();
		$CompanyName=$job->companyname;
		$CategoryTitle=$job->cattitle;
		$JobTitle=$job->jobtitle;
		$siteAddress = JURI::root();
		$link = $siteAddress."index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=view_job&vj=5&oi=".$jobid."&Itemid=105";

		$msgSubject = str_replace('{JOB_TITLE}', $JobTitle, $msgSubject);
		$msgSubject = str_replace('{JOB_CATEGORY}', $CategoryTitle, $msgSubject);
		$msgSubject = str_replace('{SENDER_NAME}', $sendername, $msgSubject);
		$msgSubject = str_replace('{SITE_NAME}', $sitename, $msgSubject);
		$msgSubject = str_replace('{COMPANY_NAME}', $CompanyName, $msgSubject);
		$msgSubject = str_replace('{CLICK_HERE_TO_VISIT}', $link, $msgSubject);
		$msgSubject = str_replace('{SENDER_MESSAGE}', $sendermessage, $msgSubject);

		$msgBody = str_replace('{JOB_TITLE}', $JobTitle, $msgBody);
		$msgBody = str_replace('{JOB_CATEGORY}', $CategoryTitle, $msgBody);
		$msgBody = str_replace('{SENDER_NAME}', $sendername, $msgBody);
		$msgBody = str_replace('{SITE_NAME}', $sitename, $msgBody);
		$msgBody = str_replace('{COMPANY_NAME}', $CompanyName, $msgBody);
		$msgBody = str_replace('{CLICK_HERE_TO_VISIT}', $link, $msgBody);
		$msgBody = str_replace('{SENDER_MESSAGE}', $sendermessage, $msgBody);

		$message->setSubject($msgSubject);
		$message->setBody($msgBody);
		$sender = array( $senderemail, $sendername );
		$message->setSender($sender);
		$message->IsHTML(true);
		if(!$message->send()) $sent = $message->sent(); else $sent = true;
		return $sent;
		
	}
	public function sendJobAlertByAlertType($ck){
		$pass = $this->checkCronKey($ck);
		if($pass == true){
			$this->sendJobAlert(1);//For Daily Subscriber
			$this->sendJobAlert(2);//For Weekly Subscriber
			$this->sendJobAlert(3);//For Monthly Subscriber
		}else return false;
	}
	function checkCronKey($passkey){
			$db = $this->getDbo();
			$query = "SELECT COUNT(configvalue) FROM `#__js_job_config` WHERE configname = ".$db->quote('cron_job_alert_key')." AND configvalue = ".$db->quote($passkey);
			$db->setQuery($query);
			$key = $db->loadResult();
			if($key == 1)return true;
			else return false;
	}
	public function sendJobAlert($alerttype){
		$admin_jobs = '';
		$message =& JFactory::getMailer();
		$config = $this->getConfigByFor('email');
		$db = &$this->getDBO();
		$curdate = date('Y-m-d H:i:s');
            if($alerttype == 1) $days = 1;
            elseif($alerttype == 2) $days = 7;
            elseif($alerttype == 3) $days = 30;

            if($alerttype == 1) $alerttitle = 'Daily';
            elseif($alerttype == 2) $alerttitle = 'Weekly';
            elseif($alerttype == 3) $alerttitle = 'Monthly';

            $query  = "SELECT person.*,user.name AS username 
				FROM `#__js_job_jobalertsetting` AS person
				LEFT JOIN `#__users` AS user ON user.id = person.uid 
				WHERE person.alerttype = ".$alerttype." AND DATE(DATE_ADD(person.lastmailsend,INTERVAL ".$days." DAY)) = CURDATE()";
				//echo '<br>'.$query;
            $db->setQuery($query);
            $persons = $db->loadObjectList();
		if(empty($persons)) return false; // no person were selected for mail
		
		
		foreach($persons AS $person){

				if($alerttype == 1) $wherequery = " DATE(job.startpublishing) = CURDATE()";
				if($alerttype == 2) $wherequery = " job.startpublishing >= DATE_SUB(CURDATE(),INTERVAL 7 DAY)";
				if($alerttype == 3) $wherequery = " job.startpublishing >= DATE_SUB(CURDATE(),INTERVAL 30 DAY)";

				$wherequery = " job.startpublishing BETWEEN '".$person->lastmailsend."' AND '".$curdate."'";


				$metakeywords = array();
				if(isset($person->keywords)){
					$keywords = explode(' ',$person->keywords);
					    $length = count($keywords);
					    if($length <= 5) $i = $length; else $i = 5;
					
					    for($j = 0;$j<$i;$j++){
						$metakeywords[] = " job.metakeywords LIKE LOWER ('%$keywords[$j]%')";
					    }
					$metakeywords[] = " job.metakeywords = '' OR job.metakeywords IS NULL";
				}

				$countryquery = "(SELECT job.*,cat.cat_title AS categorytitle,subcat.title AS subcategorytitle,country.name AS countryname
								FROM `#__js_job_jobs` AS job
								JOIN `#__js_job_categories` AS cat ON cat.id = job.jobcategory
								JOIN `#__js_job_countries` AS country ON country.code = job.country
								LEFT JOIN `#__js_job_subcategories` AS subcat ON subcat.id = job.subcategoryid
								WHERE job.jobcategory = ".$person->categoryid." 
								AND LOWER(job.country) = LOWER(".$db->quote($person->country) .")";
				if($person->subcategoryid) $countryquery .= " AND job.subcategoryid = ".$db->quote($person->subcategoryid);
				if($person->state) $countryquery .= " AND LOWER(job.state) != LOWER(".$db->quote($person->state).")";
				if($person->county) $countryquery .= " AND LOWER(job.county) != LOWER(".$db->quote($person->county).")";
				if($person->city) $countryquery .= " AND LOWER(job.city) != LOWER(".$db->quote($person->city).")";
				if($person->keywords) $countryquery .= " AND ( ".implode(' OR ', $metakeywords)." )";
				$countryquery .= " AND ".$wherequery. ")";
				$query = $countryquery;
				if($person->state){
				$statequery = "(SELECT job.*,cat.cat_title AS categorytitle,subcat.title AS subcategorytitle,country.name AS countryname
								FROM `#__js_job_jobs` AS job
								JOIN `#__js_job_categories` AS cat ON cat.id = job.jobcategory
								JOIN `#__js_job_countries` AS country ON country.code = job.country
								LEFT JOIN `#__js_job_subcategories` AS subcat ON subcat.id = job.subcategoryid
								WHERE job.jobcategory = ".$person->categoryid." 
								AND LOWER(job.country) = LOWER(".$db->quote($person->country) .")";
				if($person->subcategoryid) $statequery .= " AND job.subcategoryid = ".$db->quote($person->subcategoryid);
				if($person->state) $statequery .= " AND LOWER(job.state) = LOWER(".$db->quote($person->state).")";
				if($person->county) $statequery .= " AND LOWER(job.county) != LOWER(".$db->quote($person->county).")";
				if($person->city) $statequery .= " AND LOWER(job.city) != LOWER(".$db->quote($person->city).")";
				if($person->keywords) $statequery .= " AND ( ".implode(' OR ', $metakeywords)." )";
				$statequery .=" AND ".$wherequery. ")";
				$query .= " UNION " . $statequery;
				}
				if($person->county){
				$countyquery = "(SELECT job.*,cat.cat_title AS categorytitle,subcat.title AS subcategorytitle,country.name AS countryname
								FROM `#__js_job_jobs` AS job
								JOIN `#__js_job_categories` AS cat ON cat.id = job.jobcategory
								JOIN `#__js_job_countries` AS country ON country.code = job.country
								LEFT JOIN `#__js_job_subcategories` AS subcat ON subcat.id = job.subcategoryid
								WHERE job.jobcategory = ".$person->categoryid." 
								AND LOWER(job.country) = LOWER(".$db->quote($person->country) .")";
				if($person->subcategoryid) $countyquery .= " AND job.subcategoryid = ".$db->quote($person->subcategoryid);
				if($person->state) $countyquery .= " AND LOWER(job.state) = LOWER(".$db->quote($person->state).")";
				if($person->county) $countyquery .= " AND LOWER(job.county) = LOWER(".$db->quote($person->county).")";
				if($person->city) $countyquery .= " AND LOWER(job.city) != LOWER(".$db->quote($person->city).")";
				if($person->keywords) $countyquery .= " AND ( ".implode(' OR ', $metakeywords)." )";
				$countyquery .=" AND ".$wherequery. ")";
				$query .= " UNION " . $countyquery;
				}
				if($person->city){
				$cityquery = "(SELECT job.*,cat.cat_title AS categorytitle,subcat.title AS subcategorytitle,country.name AS countryname
								FROM `#__js_job_jobs` AS job
								JOIN `#__js_job_categories` AS cat ON cat.id = job.jobcategory
								JOIN `#__js_job_countries` AS country ON country.code = job.country
								LEFT JOIN `#__js_job_subcategories` AS subcat ON subcat.id = job.subcategoryid
							WHERE job.jobcategory = ".$person->categoryid." 
							AND LOWER(job.country) = LOWER(".$db->quote($person->country) .")";
				if($person->subcategoryid) $cityquery .= " AND job.subcategoryid = ".$db->quote($person->subcategoryid);
				if($person->state) $cityquery .= " AND LOWER(job.state) = LOWER(".$db->quote($person->state).")";
				if($person->county) $cityquery .= " AND LOWER(job.county) = LOWER(".$db->quote($person->county).")";
				if($person->city) $cityquery .= " AND LOWER(job.city) = LOWER(".$db->quote($person->city).")";
				if($person->keywords) $cityquery .= " AND ( ".implode(' OR ', $metakeywords)." )";
				$cityquery .=" AND ".$wherequery. ")";
				$query .= " UNION " . $cityquery;
				}

				$cityquery = "(SELECT job.*,cat.cat_title AS categorytitle,subcat.title AS subcategorytitle,country.name AS countryname
								FROM `#__js_job_jobs` AS job
								JOIN `#__js_job_categories` AS cat ON cat.id = job.jobcategory
								JOIN `#__js_job_countries` AS country ON country.code = job.country
								LEFT JOIN `#__js_job_subcategories` AS subcat ON subcat.id = job.subcategoryid
							WHERE job.jobcategory = ".$person->categoryid." 
							AND LOWER(job.country) = LOWER(".$db->quote($person->country) .")";
				if($person->subcategoryid) $cityquery .= " AND job.subcategoryid = ".$db->quote($person->subcategoryid);
				if($person->state) $cityquery .= " AND LOWER(job.state) = LOWER(".$db->quote($person->state).")";
				if($person->county) $cityquery .= " AND LOWER(job.county) = LOWER(".$db->quote($person->county).")";
				if($person->city) $cityquery .= " AND LOWER(job.city) = LOWER(".$db->quote($person->city).")";
				if($person->keywords) $cityquery .= " AND ( ".implode(' OR ', $metakeywords)." )";
				$cityquery .=" AND ".$wherequery. ")";
				$query = $cityquery;

				//echo '<br>'.$query;
				$db->setQuery($query);
				$jobs= $db->loadObjectList();
				
				if(!empty($jobs)){
					$query = "SELECT template.* FROM `#__js_job_emailtemplates` AS template	WHERE template.templatefor = 'job-alert'";
					$db->setQuery( $query );
					$template = $db->loadObject();
					$msgSubject = $template->subject;
					$msgBody = $template->body;
					$message->addRecipient($person->contactemail); //to email
					$mail_jobs='<table width="100%" cellpadding="10px" cellspacing="0">
								<tr>
									<th>'.JText::_('JS_JOB_TITLE').'</th>
									<th>'.JText::_('JS_JOB_CATEGORY').'</th>
									<th>'.JText::_('JS_SUB_CATEGORIES').'</th>
									<th>'.JText::_('JS_JOB_LOCATION').'</th>
								</tr>';
					foreach($jobs AS $job){
						$comma = '';$location = '';
						if(isset($job->cityname) && !empty($job->cityname)) {$location = $comma.$job->cityname; $comma = ', ';}
						elseif($job->city) {$location .= $comma.$job->city; $comma = ', ';}
						if(isset($job->countyname) && !empty($job->cityname)) {$location .= $comma.$job->countyname; $comma = ', ';}
						elseif($job->county) {$location .= $comma.$job->county; $comma = ', ';}
						if(isset($job->statename) && !empty($job->statename)) {$location .= $comma.$job->statename; $comma = ', ';}
						elseif($job->state) {$location .= $comma.$job->state; $comma = ', ';}
						$location .= $comma.$job->countryname;
						$path = JRoute::_(JURI::root().'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=view_job&vj=5&oi='.$job->id.'&Itemid=105');
						$mail_jobs .= '<tr>
										<td><a href="'.$path.'" target="_blank">'.$job->title.'</a></td>
										<td>'.$job->categorytitle.'</td>
										<td>'.$job->subcategorytitle.'</td>
										<td>'.$location.'</td>
									</tr>';
					}
					$mail_jobs .= '</table>';
					$admin_jobs .= $mail_jobs." <br/> To ".$person->username." <br/><br/>";
					$msgBody = str_replace('{JOBSEEKER_NAME}', $person->username, $msgBody);
					$msgBody = str_replace('{JOBS_INFO}', $mail_jobs, $msgBody);
					$message->setSubject($msgSubject);
					$message->setBody($msgBody);
					$sender = array( $config['mailfromaddress'], $config['mailfromname']);
					$message->setSender($sender);

					$message->IsHTML(true);
					$sent = $message->send();
				}
			
				// update last mail send
				$query = "UPDATE `#__js_job_jobalertsetting` SET lastmailsend = '".$curdate."' WHERE id = ".$person->id;
				$db->setQuery( $query );
				$db->query();
				
		} // end of each persons foreach loop
		
		// mail send to admin
		//if($sent ){
			$message1 =& JFactory::getMailer();
			$message1->addRecipient($config['adminemailaddress']); //to email
			$msgSubject = "Job Alert Information";
			$msgBody = "<p>Dear Admin</p><br/>Following jobs was succefully sent.<br/>Alert type: $alerttitle <br />".$admin_jobs;
			$message1->setSubject($msgSubject);
			$message1->setBody($msgBody);
			$sender = array( $config['mailfromaddress'], $config['mailfromname']);
			$message1->setSender($sender);
			$message1->IsHTML(true);
			$sent = $message1->send();
		//}
		
    }
	function makeDir($path){
		if (!file_exists($path)){ // create directory
			mkdir($path, 0755);
			$ourFileName = $path.'/index.html';
			$ourFileHandle = fopen($ourFileName, 'w') or die("can't open file");
			fclose($ourFileHandle);
		}
	}    
	function checkUserDetail($val,$for){
		$db = $this->getDBO();
		$query = "SELECT COUNT(id) FROM `#__users` WHERE $for =".$db->quote($val);
		$db->setQuery($query);
		$total = $db->loadResult();
		return $total;
	}
	
	
}
?>
