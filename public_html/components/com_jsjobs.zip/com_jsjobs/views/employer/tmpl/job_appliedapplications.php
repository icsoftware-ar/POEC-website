<?php
/**
 * @Copyright Copyright (C) 2009-2011
 * @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
 + Created by:          Ahmad Bilal
 * Company:		Buruj Solutions
 + Contact:		www.burujsolutions.com , ahmad@burujsolutions.com
 * Created on:	Jan 11, 2009
 ^
 + Project: 		JS Jobs
 * File Name:	views/employer/tmpl/job_appliedapplications.php
 ^ 
 * Description: template view for my job applied application
 ^ 
 * History:		NONE
 ^ 
 */
 
 defined('_JEXEC') or die('Restricted access');
 JHTML::_('behavior.formvalidation');
 
 global $mainframe;
$version = new JVersion;
$joomla = $version->getShortVersion();
$jversion = substr($joomla,0,3);

 $document =& JFactory::getDocument();
 $document->addStyleSheet('components/com_jsjobs/themes/'.$this->config['theme']);
$document->addStyleSheet('components/com_jsjobs/css/jsjobsresumerating.css');
if(isset($this->resume[0]))$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=job_appliedapplications&bd='.$this->resume[0]->id.'&Itemid='.$this->Itemid;

$actions = array(
	'0' => array('value' => 1,'text' => JText::_('JS_SHORT_LIST')),
	'1' => array('value' => 2,'text' => JText::_('JS_SEND_MESSAGE')),
	'2' => array('value' => 3,'text' => JText::_('JS_FOLDER')),
        '3' => array('value' => 4,'text' => JText::_('JS_COMMENTS'))
        );
$actioncombo = JHTML::_('select.genericList', $actions, 'action', 'class="inputbox" '. '', 'value', 'text', '');
?>

<?php if ($this->config['offline'] == '1'){ ?>
	<div id="toppanel">
		<div id="tp_header" <?php if($this->config['topimage'] == 0) echo 'style="background:none;"';?>>
			<span id="tp_title"><?php echo $this->config['title'];?></span>
		</div>
	</div>
	<div id="errormessagedown"></div>
	<div id="errormessage" class="errormessage">
		<div id="message"><b><?php echo $this->config['offline_text']; ?></b></div>
	</div>
<?php }else{ ?>
	<div id="toppanel">
		<div id="tp_header" <?php if($this->config['topimage'] == 0) echo 'style="background:none;"';?>>
			<span id="tp_title"><?php echo $this->config['title'];?></span>
			<span id="tp_curloc">
				<?php if ($this->config['cur_location'] == 1) {
						echo JText::_('JS_CUR_LOC'); ?> : <a class="curloclnk" href="index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=alljobsappliedapplications&Itemid=<?php echo $this->Itemid; ?>"><?php echo JText::_('JS_APPLIED_RESUME'); ?></a> > <?php echo JText::_('JS_JOB_APPLIED_APPLICATIONS');
				} ?>
			</span>
		</div>
		<div id="tp_links">
			<?php 
			if (sizeof($this->jobseekerlinks) != 0){
				foreach($this->jobseekerlinks as $lnk)	{ ?>
					<a class="<?php if($lnk[2] == 1)echo 'first'; elseif($lnk[2] == -1)echo 'last';  ?>" href="<?php echo $lnk[0]; ?>"><?php echo $lnk[1]; ?></a>
				<?php }
			}
			if (sizeof($this->employerlinks) != 0){
				foreach($this->employerlinks as $lnk)	{ ?>
					<a class="<?php if($lnk[2] == 1)echo 'first'; elseif($lnk[2] == -1)echo 'last';  ?>" href="<?php echo $lnk[0]; ?>"> <?php echo $lnk[1]; ?></a>
				<?php }
			}
			?>
		</div>
		<div id="tp_heading">
			<span id="tp_headingtext">
				<span id="tp_headingtext_left"></span>
				<span id="tp_headingtext_center"><?php echo JText::_('JS_JOB')."[".$this->jobtitle."]".'&nbsp;&nbsp'.JText::_('APPLICATION_APPLIED'); ?></span>
				<span id="tp_headingtext_right"></span>				
			</span>
		</div>
	</div>
<?php
if ($this->resume) {  
if ($this->userrole->rolefor == 1) {  // employer

	if ($this->sortlinks['sortorder'] == 'ASC')
		$img = "components/com_jsjobs/images/sort0.png";
	else
		$img = "components/com_jsjobs/images/sort1.png";
?>
<form action="index.php" method="post" name="adminForm" id="adminForm" >
	<table cellpadding="1" cellspacing="0" border="0" width="100%">
		<?php  $exportlink='index.php?option=com_jsjobs&c=jsjobs&task=exportresume&bd='.$this->jobid;?>
		<tr >
			<td align="right" colspan="8"><a  id="button" class="button minpad"href="<?php echo $exportlink; ?>" ><?php echo JText::_('JS_EXPORT_RESUME'); ?></a></td>
		</tr>
		<tr id="mc_title_row" class="<?php echo $this->theme['sortlinks']; ?>" height="17" valign="center">
			<td id="rl_tdpadding" width="20%" class="sectionheadline"><span id="mc_title_anchor"><a class="mc_title_anchor" href="<?php echo $link?>&sortby=<?php echo $this->sortlinks['name']; ?>"><?php echo JText::_('JS_NAME'); ?></a><span id="anchor"><?php if ($this->sortlinks['sorton'] == 'name') { ?> <img src="<?php echo $img ?>"> <?php } ?></td>
			<td align="center" width="20%" class="sectionheadline"><span id="mc_title_anchor"><a class="mc_title_anchor" href="<?php echo $link?>&sortby=<?php echo $this->sortlinks['gender']; ?>"><?php echo JText::_('JS_GENDER'); ?></a><span id="anchor"><?php if ($this->sortlinks['sorton'] == 'gender') { ?> <img src="<?php echo $img ?>"> <?php } ?></td>
			<td width="20%" align="center" class="sectionheadline"><span id="mc_title_anchor"><a class="mc_title_anchor" href="<?php echo $link?>&sortby=<?php echo $this->sortlinks['jobsalaryrange']; ?>"><?php echo JText::_('JS_SALARY'); ?></a><span id="anchor"><?php if ($this->sortlinks['sorton'] == 'jobsalaryrange') { ?> <img src="<?php echo $img ?>"> <?php } ?></td>
			<td id="rl_tdpadding" width="20%" align="center" class="sectionheadline"><span id="mc_title_anchor"><a class="mc_title_anchor" href="<?php echo $link?>&sortby=<?php echo $this->sortlinks['apply_date']; ?>"><?php echo JText::_('JS_APPLIED_DATE'); ?></a><span id="anchor"><?php if ($this->sortlinks['sorton'] == 'apply_date') { ?> <img src="<?php echo $img ?>"> <?php } ?></td>
			<td id="rl_tdpadding" width="20%" align="center" class="sectionheadline"><span id="mc_title_anchor"><a class="mc_title_anchor" href="<?php echo $link?>&sortby=<?php echo $this->sortlinks['total_experience']; ?>"><?php echo JText::_('JS_EXPERIENCE'); ?></a><span id="anchor"><?php if ($this->sortlinks['sorton'] == 'total_experience') { ?> <img src="<?php echo $img ?>"> <?php } ?></td>
		</tr>
			<?php 
		$tdclass = array($this->theme['odd'], $this->theme['even']);
		$isodd =1;
                $count = 0;
		if ( isset($this->resume) ){
					$totalresume = count($this->resume);
					$resumecount = 0;
                    foreach($this->resume as $app)	{
							$resumecount++;
                            $count++;
                            $isodd = 1 - $isodd; ?>
                        <tr id="mc_field_row" class="<?php echo $tdclass[$isodd]; ?> rs_border <?php if($resumecount == $totalresume) echo 'lastresume';?>">
							<td colspan="7">
							<div id="job_appliedresume">
								<table cellpadding="1" cellspacing="0" border="0" width="100%">
									<tr>
										<td width="20%"><?php if ($app->resumeview == 0) echo '<strong>'; ?><?php echo $app->first_name.' '.$app->last_name; ?><?php if ($app->resumeview == 0) echo '</strong>'; ?></td>
										<td width="20%" align="center"><?php if($app->gender==1) echo JText::_('JS_MALE');
													elseif($app->gender==2) echo JText::_('JS_FEMALE');
													else  echo JText::_('JS_DOES_NOT_MATTER')?></td>
										<td width="20%" align="center"><?php echo $app->symbol . $app->rangestart . ' - ' . $app->symbol.' '. $app->rangeend; ?></td>
										<td width="20%" align="center"><?php echo date($this->config['date_format'],strtotime($app->apply_date)); ?></td>
										<td align="center"><?php echo $app->total_experience;  ?></td>
									</tr>
									<tr>
										<td>
											<strong><?php echo JText::_('JS_COMMENTS'); ?></strong>
										</td>
										<td colspan="2">
											<div>
												<?php echo  $app->comments; ?>
											</div>
										</td>
										<td colspan="2">
											<div>
											<?php
												$id = $app->jobapplyid;
												$percent = 0;
												$stars = '';
												$percent = $app->rating * 20;
												$stars = '-small';
												$html="
													<div class=\"jsjobs-container".$stars."\"".( " style=\"margin-top:5px;\"" ).">
													<ul class=\"jsjobs-stars".$stars."\">
													<li id=\"rating_".$id."\" class=\"current-rating\" style=\"width:".(int)$percent."%;\"></li>
													<li><a href=\"javascript:void(null)\" onclick=\"javascript:setrating('rating_".$id."',1,".(int)$app->ratingid.",".$app->id.",".$app->appid.");\" title=\"".JTEXT::_('Very Poor')."\" class=\"one-star\">1</a></li>
													<li><a href=\"javascript:void(null)\" onclick=\"javascript:setrating('rating_".$id."',2,".(int)$app->ratingid.",".$app->id.",".$app->appid.");\" title=\"".JTEXT::_('Poor')."\" class=\"two-stars\">2</a></li>
													<li><a href=\"javascript:void(null)\" onclick=\"javascript:setrating('rating_".$id."',3,".(int)$app->ratingid.",".$app->id.",".$app->appid.");\" title=\"".JTEXT::_('Regular')."\" class=\"three-stars\">3</a></li>
													<li><a href=\"javascript:void(null)\" onclick=\"javascript:setrating('rating_".$id."',4,".(int)$app->ratingid.",".$app->id.",".$app->appid.");\" title=\"".JTEXT::_('Good')."\" class=\"four-stars\">4</a></li>
													<li><a href=\"javascript:void(null)\" onclick=\"javascript:setrating('rating_".$id."',5,".(int)$app->ratingid.",".$app->id.",".$app->appid.");\" title=\"".JTEXT::_('Very Good')."\" class=\"five-stars\">5</a></li>
													</ul>
													</div>
												";
												$html .="</small></span>";
												echo $html;
											?>
											</div>
										</td>
									</tr>
									<tr>
										<td colspan="2" >
											<strong><?php echo JText::_('JS_LOCATION'); ?></strong>
										</td>
										<td colspan="3" align="left">
											<?php
												if ($app->cityname) { echo $app->cityname; $comma = 1; }
												elseif ($app->address_city) { echo $app->address_city; $comma = 1; }
												if ($app->countyname) { if($comma) echo', '; echo $app->countyname; $comma = 1; }
												elseif ($app->address_county) { if($comma) echo', '; echo $app->address_county; $comma = 1; }
												if ($app->statename) { if($comma) echo', '; echo $app->statename; $comma = 1; }
												elseif ($app->address_state) { if($comma) echo', '; echo $app->address_state; $comma = 1; }
												if ($app->countryname) { if($comma) echo', '; echo $app->countryname; $comma = 1; }
											 ?>
										</td>
									</tr>
									<tr>
										<td colspan="5" align="right">
											<?php echo JText::_('JS_ACTION').'&nbsp;&nbsp;&nbsp;'.JHTML::_('select.genericList', $actions, 'action_'.$count, 'class="inputbox" '. '', 'value', 'text', '');; ?>&nbsp;&nbsp;&nbsp;
											<input type="button" id="button" class="button minpad" onclick="actioncall(<?php echo $app->jobapplyid; ?>,<?php echo $app->id; ?>,<?php echo $app->appid; ?>,'<?php echo "action_$count"; ?>')" value="<?php echo JText::_('JS_GO'); ?>">
											<input type="button" id="button" class="button minpad" onclick='getjobdetail("resumedetail_<?php echo $app->appid; ?>",<?php echo $app->id; ?>,<?php echo $app->appid; ?>)' value="<?php echo JText::_('JS_DETAILS'); ?>">
												<?php $link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=view_resume&vm=2&rd='.$app->appid.'&bd='.$app->id.'&Itemid='.$this->Itemid; ?> 
												<a id="button" class="button minpad" href="<?php echo $link?>"><?php echo JText::_('JS_RESUME');?></a> 
												<?php if($jversion == '1.5' ){ ?>
													<?php $plink = 'index2.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=resume_print&vm=2&rd='.$app->appid.'&bd='.$app->id.'&Itemid='.$this->Itemid; ?> 
													<a  href="<?php echo $plink?>"><img src="components/com_jsjobs/images/print.png"/> </a>
												<?php } ?>
										</td>
									</tr>
									<tr height="5"></tr>
									<tr><td  id="resumeaction_<?php echo $app->jobapplyid; ?>" colspan="5"></td></tr>
									<tr><td  id="resumedetail_<?php echo $app->appid; ?>" colspan="5"></td></tr>
								</table>
							</div>
							</td>
                        </tr>
                    <?php
                    }
		}
		?>
		</table>


			<input type="hidden" name="task" id="task" value="saveshortlistcandiate" />
			<input type="hidden" name="Itemid" id="Itemid" value="<?php echo $this->Itemid; ?>" />
			<input type="hidden" name="jobid" id="jobid" value="<?php echo $app->id; ?>" />
			<input type="hidden" name="resumeid" id="resumeid" value="<?php echo $app->appid; ?>" />
			<input type="hidden" name="id" id="id" value="" />
			<input type="hidden" name="action" id="action" value="" />
			<input type="hidden" name="option" value="<?php echo $this->option; ?>" />
		
		
		
		
		
		
		
		</form>

<form action="<?php echo JRoute::_('index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=job_appliedapplications&bd='.$this->resume[0]->id.'&Itemid='.$this->Itemid); ?>" method="post">
	<div id="jl_pagination">
		<div id="jl_pagination_pageslink">
            <?php echo $this->pagination->getPagesLinks(); ?>
		</div>
		<div id="jl_pagination_box">
			<?php	
				echo JText::_('JS_DISPLAY_#');
				echo $this->pagination->getLimitBox();
            ?>
		</div>
		<div id="jl_pagination_counter">
            <?php echo $this->pagination->getResultsCounter(); ?>
		</div>
	</div>
<script language=Javascript>
function actioncall(jobapplyid,jobid, resumeid, action){
        actionvalue = document.getElementById(action).value;
        if(actionvalue == 3){ // folder
            getfolders('resumeaction_'+jobapplyid,jobid,resumeid,jobapplyid);
        }else if(actionvalue == 4){ // comments
            getresumecomments('resumeaction_'+jobapplyid,jobapplyid);
        }else{
            document.getElementById('resumeid').value=resumeid;
            document.getElementById('action').value=actionvalue;
            document.forms["adminForm"].submit();
        }
}
function setresumeid(resumeid, action){
        document.getElementById('resumeid').value=resumeid;
        document.getElementById('action').value=document.getElementById(action).value;
        document.forms["adminForm"].submit();
}
function saveresumecomments(jobapplyid){
        document.getElementById('id').value=jobapplyid;
        document.getElementById('task').value='saveresumecomments';
        document.forms["adminForm"].submit();
}
function saveaddtofolder(jobid,resumeid){
        document.getElementById('resumeid').value=resumeid;
         document.getElementById('jobid').value=jobid;
        document.getElementById('task').value='saveresumefolder';
        document.forms["adminForm"].submit();
}
function getfolders(src,jobid,resumeid,applyid){
    	//var pagesrc = 'jobdetail_'+src;
	document.getElementById(src).innerHTML="Loading ...";
	var xhr;
	try {  xhr = new ActiveXObject('Msxml2.XMLHTTP');   }
	catch (e)
	{
		try {   xhr = new ActiveXObject('Microsoft.XMLHTTP');    }
		catch (e2)
		{
		  try {  xhr = new XMLHttpRequest();     }
		  catch (e3) {  xhr = false;   }
		}
	 }

	xhr.onreadystatechange = function(){
      if(xhr.readyState == 4 && xhr.status == 200){
        	document.getElementById(src).innerHTML=xhr.responseText; //retuen value

      }
    }

	xhr.open("GET","index.php?option=com_jsjobs&task=getmyforlders&jobid="+jobid+"&resumeid="+resumeid+"&applyid="+applyid,true);
	xhr.send(null);
}
function getresumecomments(src,jobapplyid){
    	//var pagesrc = 'jobdetail_'+src;
	document.getElementById(src).innerHTML="Loading ...";
	var xhr;
	try {  xhr = new ActiveXObject('Msxml2.XMLHTTP');   }
	catch (e)
	{
		try {   xhr = new ActiveXObject('Microsoft.XMLHTTP');    }
		catch (e2)
		{
		  try {  xhr = new XMLHttpRequest();     }
		  catch (e3) {  xhr = false;   }
		}
	 }

	xhr.onreadystatechange = function(){
      if(xhr.readyState == 4 && xhr.status == 200){
        	document.getElementById(src).innerHTML=xhr.responseText; //retuen value

      }
    }
    //alert('abc');
    xhr.open("GET","index.php?option=com_jsjobs&task=getresumecomments&jobapplyid="+jobapplyid,true);
	xhr.send(null);
}
function getjobdetail(src,jobid, resumeid){
    	//var pagesrc = 'jobdetail_'+src;
	document.getElementById(src).innerHTML="Loading ...";
	var xhr;
	try {  xhr = new ActiveXObject('Msxml2.XMLHTTP');   }
	catch (e)
	{
		try {   xhr = new ActiveXObject('Microsoft.XMLHTTP');    }
		catch (e2)
		{
		  try {  xhr = new XMLHttpRequest();     }
		  catch (e3) {  xhr = false;   }
		}
	 }

	xhr.onreadystatechange = function(){
      if(xhr.readyState == 4 && xhr.status == 200){
        	document.getElementById(src).innerHTML=xhr.responseText; //retuen value

      }
    }

	xhr.open("GET","index.php?option=com_jsjobs&task=getresumedetail&jobid="+jobid+"&resumeid="+resumeid,true);
	xhr.send(null);
}

function clsjobdetail(src){
        document.getElementById(src).innerHTML="";

}
function clsaddtofolder(src){
        document.getElementById(src).innerHTML="";
}
function setrating(src,newrating,ratingid,jobid,resumeid){
	var xhr;
	try {  xhr = new ActiveXObject('Msxml2.XMLHTTP');   }
	catch (e)
	{
		try {   xhr = new ActiveXObject('Microsoft.XMLHTTP');    }
		catch (e2)
		{
		  try {  xhr = new XMLHttpRequest();     }
		  catch (e3) {  xhr = false;   }
		}
	 }

	xhr.onreadystatechange = function(){
      if(xhr.readyState == 4 && xhr.status == 200){
               if(xhr.responseText == 1)
                document.getElementById(src).style.width=parseInt(newrating*20)+'%';

      }
    }

	xhr.open("GET","index.php?option=com_jsjobs&task=saveresumerating&ratingid="+ratingid+"&jobid="+jobid+"&resumeid="+resumeid+"&newrating="+newrating,true);
	xhr.send(null);


}

</script>

</form>	
<?php

} else{ // not allowed job posting ?>
	<div id="errormessagedown"></div>
	<div id="errormessage" class="errormessage">
		<div id="message"><b><?php echo JText::_('JS_YOU_ARE_NOT_ALLOWED_TO_VIEW');?></b></div>
	</div>
<?php

}	
}else{ // no result found in this category ?>
	<div id="errormessagedown"></div>
	<div id="errormessage" class="errormessage">
		<div id="message"><b><?php echo JText::_('JS_RESULT_NOT_FOUND');?></b></div>
	</div>
<?php
	
}
}//ol
?>	
<div id="jsjobs_footer"><?php echo eval(base64_decode('aWYoJHRoaXMtPmNvbmZpZ1snZnJfY3JfdHhzaCddKSB7DQplY2hvIA0KJzx0YWJsZSB3aWR0aD0iMTAwJSIgc3R5bGU9InRhYmxlLWxheW91dDpmaXhlZDsiPg0KPHRyPjx0ZCBoZWlnaHQ9IjE1Ij48L3RkPjwvdHI+DQo8dHI+PHRkIHN0eWxlPSJ2ZXJ0aWNhbC1hbGlnbjp0b3A7IiBhbGlnbj0iY2VudGVyIj4NCjxhIGNsYXNzPSJpbWciIHRhcmdldD0iX2JsYW5rIiBocmVmPSJodHRwOi8vd3d3Lmpvb21za3kuY29tIj48aW1nIHNyYz0iaHR0cDovL3d3dy5qb29tc2t5LmNvbS9sb2dvL2pzam9ic2NybG9nby5wbmciPjwvYT4NCjxicj4NCkNvcHlyaWdodCAmY29weTsgMjAwOCAtICcuZGF0ZSgnWScpLicsDQo8c3BhbiBpZD0idGhlbWVhbmNob3IiPiA8YSBjbGFzcz0iYW5jaG9yInRhcmdldD0iX2JsYW5rIiBocmVmPSJodHRwOi8vd3d3LmJ1cnVqc29sdXRpb25zLmNvbSI+QnVydWogU29sdXRpb25zIDwvYT48L3NwYW4+PC90ZD48L3RyPg0KPC90YWJsZT4nOw0KfQ=='));?></div>
