<?php
/**
 * @Copyright Copyright (C) 2009-2011
 * @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
 + Created by:          Ahmad Bilal
 * Company:		Buruj Solutions
 + Contact:		www.burujsolutions.com , ahmad@burujsolutions.com
 * Created on:	Aug 18, 2010
 ^
 + Project: 		JS Jobs
 * File Name:	views/employer/tmpl/successfullogin.php
 ^ 
 * Description: redirect on seccessful login
 ^ 
 * History:		NONE
 ^ 
 */

// code in view class

?>
hello