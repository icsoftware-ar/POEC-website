<?php
/**
 * @Copyright Copyright (C) 2009-2011
 * @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
 + Created by:          Ahmad Bilal
 * Company:		Buruj Solutions
 + Contact:		www.burujsolutions.com , ahmad@burujsolutions.com
 * Created on:	Jan 11, 2009
 ^
 + Project: 		JS Jobs
 * File Name:	views/employer/tmpl/mycompanies.php
 ^ 
 * Description: template view for my companies
 ^ 
 * History:		NONE
 ^ 
 */
 
 defined('_JEXEC') or die('Restricted access');
 
 global $mainframe;
 $link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=my_stats&Itemid='.$this->Itemid;
  $document =& JFactory::getDocument();
   $document->addStyleSheet('components/com_jsjobs/themes/'.$this->config['theme']);
?>

<?php if ($this->config['offline'] == '1'){ ?>
	<div id="toppanel">
		<div id="tp_header" <?php if($this->config['topimage'] == 0) echo 'style="background:none;"';?>>
			<span id="tp_title"><?php echo $this->config['title'];?></span>
		</div>
	</div>
	<div id="errormessagedown"></div>
	<div id="errormessage" class="errormessage">
		<div id="message"><b><?php echo $this->config['offline_text']; ?></b></div>
	</div>
<?php }else{ ?>
	<div id="toppanel">
		<div id="tp_header" <?php if($this->config['topimage'] == 0) echo 'style="background:none;"';?>>
			<span id="tp_title"><?php echo $this->config['title'];?></span>
			<span id="tp_curloc">
				<?php if ($this->config['cur_location'] == 1) {
					echo JText::_('JS_CUR_LOC'); ?> : <?php echo JText::_('JS_MY_STATS');
				} ?>
			</span>
		</div>
		<div id="tp_links">
			<?php 
			if (sizeof($this->jobseekerlinks) != 0){
				foreach($this->jobseekerlinks as $lnk)	{ ?>
					<a class="<?php if($lnk[2] == 1)echo 'first'; elseif($lnk[2] == -1)echo 'last';  ?>" href="<?php echo $lnk[0]; ?>"><?php echo $lnk[1]; ?></a>
				<?php }
			}
			if (sizeof($this->employerlinks) != 0){
				foreach($this->employerlinks as $lnk)	{ ?>
					<a class="<?php if($lnk[2] == 1)echo 'first'; elseif($lnk[2] == -1)echo 'last';  ?>" href="<?php echo $lnk[0]; ?>"> <?php echo $lnk[1]; ?></a>
				<?php }
			}
			?>
		</div>
		<div id="tp_heading">
			<span id="tp_headingtext">
				<span id="tp_headingtext_left"></span>
				<span id="tp_headingtext_center"><?php echo JText::_('JS_MY_STATS');  ?></span>
				<span id="tp_headingtext_right"></span>				
			</span>
		</div>
	</div>
<?php
if ($this->userrole->rolefor == 1) { // employer
	$print = 1;
    $isodd =1;
    $tdclass = array($this->theme['odd'], $this->theme['even']);
if(isset($this->package) && $this->package == false) $print= 0;
?>

	<table cellpadding="0" cellspacing="0" border="0" width="100%" >
		<tr id="mc_title_row" class="<?php echo $this->theme['sortlinks']; ?>" valign="middle" height="16">
                    <td  class="sectionheadline" width="25%" ></td>
                    <td  width="25%" align="center" class="sectionheadline"><?php echo JText::_('JS_CURRENT_ALLOW'); ?></td>
                    <td width="25%" align="center" class="sectionheadline"><?php echo JText::_('JS_TOTAL'); ?></td>
                    <td width="25%" align="center" class="sectionheadline"><?php echo JText::_('%'); ?></td>
                </tr>
                <?php $isodd = 1 - $isodd; ?>
                <tr id="mc_field_row" class="<?php echo $tdclass[$isodd]; ?>">
                    <td><strong><?php echo JText::_('JS_COMPANIES'); ?></strong></td>
                    <td align="center"><?php if($this->companiesallow== -1) echo JText::_('JS_UNLIMITED');else echo $this->companiesallow; ?></td>
                    <td align="center"><?php echo $this->totalcompanies; ?></td>
                    <td align="center"><?php $output = '-'; if($this->companiesallow!= -1) if ($this->totalcompanies <= $this->companiesallow) if($this->companiesallow != 0) $output = round(($this->totalcompanies/$this->companiesallow)*100) .' %' ; echo $output; ?></td>
		</tr>
                <?php $isodd = 1 - $isodd; ?>
                <tr id="mc_field_row" class="<?php echo $tdclass[$isodd]; ?>">
                    <td><strong><?php echo JText::_('JS_JOBS'); ?></strong></td>
                    <td align="center"><?php if($this->jobsallow == -1) echo JText::_('JS_UNLIMITED');else echo $this->jobsallow; ?></td>
                    <td align="center"><?php echo $this->totaljobs; ?></td>
                    <td align="center"><?php $output = '-'; if($this->jobsallow!= -1) if ($this->totaljobs <= $this->jobsallow) if($this->jobsallow != 0) $output = round(($this->totaljobs/$this->jobsallow)*100) .' %' ; echo $output; ?></td>
		</tr>
                <?php $isodd = 1 - $isodd; ?>
                <tr id="mc_field_row" class="<?php echo $tdclass[$isodd]; ?>">
                    <td><strong><?php echo JText::_('JS_GOLD_COMPANIES'); ?></strong></td>
                    <td align="center"><?php if($this->goldcompaniesallow== -1) echo JText::_('JS_UNLIMITED');else echo $this->goldcompaniesallow; ?></td>
                    <td align="center"><?php echo $this->totalgoldcompanies; ?></td>
                    <td align="center"><?php $output = '-'; if($this->goldcompaniesallow!= -1) if ($this->totalgoldcompanies <= $this->goldcompaniesallow) if($this->goldcompaniesallow != 0) $output = round(($this->totalgoldcompanies/$this->goldcompaniesallow)*100) .' %' ; echo $output; ?></td>
		</tr>
                <?php $isodd = 1 - $isodd; ?>
                <tr id="mc_field_row" class="<?php echo $tdclass[$isodd]; ?>">
                    <td><strong><?php echo JText::_('JS_FEATURED_COMPANIES'); ?></strong></td>
                    <td align="center"><?php if($this->featuredcompainesallow== -1) echo JText::_('JS_UNLIMITED');else echo $this->featuredcompainesallow; ?></td>
                    <td align="center"><?php echo $this->totalfeaturedcompanies; ?></td>
                    <td align="center"><?php $output = '-'; if($this->featuredcompainesallow!= -1) if ($this->totalfeaturedcompanies <= $this->featuredcompainesallow) if($this->featuredcompainesallow != 0) $output = round(($this->totalfeaturedcompanies/$this->featuredcompainesallow)*100) .' %' ; echo $output; ?></td>
		</tr>
                <?php $isodd = 1 - $isodd; ?>
                <tr id="mc_field_row" class="<?php echo $tdclass[$isodd]; ?>">
                    <td><strong><?php echo JText::_('JS_GOLD_JOBS'); ?></strong></td>
                    <td align="center"><?php if($this->goldjobsallow== -1) echo JText::_('JS_UNLIMITED');else echo $this->goldjobsallow; ?></td>
                    <td align="center"><?php echo $this->totalgoldjobs; ?></td>
                    <td align="center"><?php $output = '-'; if($this->goldjobsallow!= -1) if ($this->totalgoldjobs <= $this->goldjobsallow) if($this->goldjobsallow != 0) $output = round(($this->totalgoldjobs/$this->goldjobsallow)*100) .' %' ; echo $output; ?></td>
		</tr>
                <?php $isodd = 1 - $isodd; ?>
                <tr id="mc_field_row" class="<?php echo $tdclass[$isodd]; ?>">
                    <td><strong><?php echo JText::_('JS_FEATURED_JOBS'); ?></strong></td>
                    <td align="center"><?php if($this->featuredjobsallow== -1) echo JText::_('JS_UNLIMITED');else echo $this->featuredjobsallow; ?></td>
                    <td align="center"><?php echo $this->totalfeaturedjobs; ?></td>
                    <td align="center"><?php $output = '-'; if($this->featuredjobsallow!= -1) if ($this->totalfeaturedjobs <= $this->featuredjobsallow) if($this->featuredjobsallow != 0) $output = round(($this->totalfeaturedjobs/$this->featuredjobsallow)*100) .' %' ; echo $output; ?></td>
		</tr>
	</table>
			

<?php
if($print == 0){
	$message = '';
	if(empty($this->packagedetail[0]->id)){
		$message = "<strong><font color='orangered'>".JText::_('JS_JOB_NO_PACKAGE')." <a href='index.php?option=com_jsjobs&view=employer&layout=packages&Itemid=$this->Itemid'>".JText::_('JS_EMPLOYER_PACKAGES')."</a></font></strong>";
	}else{
		$days = $this->packagedetail[0]->packageexpiredays - $this->packagedetail[0]->packageexpireindays;
		if($days == 1) $days = $days.' '.JText::_('JS_DAY'); else $days = $days.' '.JText::_('JS_DAYS');
		$message = "<strong><font color='red'>".JText::_('JS_YOUR_PACKAGE').' &quot;'.$this->packagedetail[0]->packagetitle.'&quot; '.JText::_('JS_HAS_EXPIRED').' '.$days.' ' .JText::_('JS_AGO')." <a href='index.php?option=com_jsjobs&view=employer&layout=packages&Itemid=$this->Itemid'>".JText::_('JS_EMPLOYER_PACKAGES')."</a></font></strong>";
	} ?>
	<?php if($message != ''){ ?>
	<div id="errormessagedown"></div>
	<div id="errormessage" class="errormessage">
		<div id="message"><?php echo $message;?></div>
	</div>
	<?php } 
}


} else{ // not allowed job posting ?>
	<div id="errormessagedown"></div>
	<div id="errormessage" class="errormessage">
		<div id="message"><b><?php echo JText::_('JS_YOU_ARE_NOT_ALLOWED_TO_VIEW');?></b></div>
	</div>
<?php

}	
}//ol
?>	
<div id="jsjobs_footer"><?php echo eval(base64_decode('aWYoJHRoaXMtPmNvbmZpZ1snZnJfY3JfdHhzaCddKSB7DQplY2hvIA0KJzx0YWJsZSB3aWR0aD0iMTAwJSIgc3R5bGU9InRhYmxlLWxheW91dDpmaXhlZDsiPg0KPHRyPjx0ZCBoZWlnaHQ9IjE1Ij48L3RkPjwvdHI+DQo8dHI+PHRkIHN0eWxlPSJ2ZXJ0aWNhbC1hbGlnbjp0b3A7IiBhbGlnbj0iY2VudGVyIj4NCjxhIGNsYXNzPSJpbWciIHRhcmdldD0iX2JsYW5rIiBocmVmPSJodHRwOi8vd3d3Lmpvb21za3kuY29tIj48aW1nIHNyYz0iaHR0cDovL3d3dy5qb29tc2t5LmNvbS9sb2dvL2pzam9ic2NybG9nby5wbmciPjwvYT4NCjxicj4NCkNvcHlyaWdodCAmY29weTsgMjAwOCAtICcuZGF0ZSgnWScpLicsDQo8c3BhbiBpZD0idGhlbWVhbmNob3IiPiA8YSBjbGFzcz0iYW5jaG9yInRhcmdldD0iX2JsYW5rIiBocmVmPSJodHRwOi8vd3d3LmJ1cnVqc29sdXRpb25zLmNvbSI+QnVydWogU29sdXRpb25zIDwvYT48L3NwYW4+PC90ZD48L3RyPg0KPC90YWJsZT4nOw0KfQ=='));?></div>
