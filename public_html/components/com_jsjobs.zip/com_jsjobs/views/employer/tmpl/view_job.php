<?php
/**
 * @Copyright Copyright (C) 2009-2011
 * @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
 + Created by:          Ahmad Bilal
 * Company:		Buruj Solutions
 + Contact:		www.burujsolutions.com , ahmad@burujsolutions.com
 * Created on:	Jan 11, 2009
 ^
 + Project: 		JS Jobs
 * File Name:	views/employer/tmpl/view_job.php
 ^ 
 * Description: template view for a job
 ^ 
 * History:		NONE
 ^ 
 */
 
 defined('_JEXEC') or die('Restricted access');
  global $mainframe;
  $document =& JFactory::getDocument();
  $document->addStyleSheet('components/com_jsjobs/themes/'.$this->config['theme']);

?>

<?php if ($this->config['offline'] == '1'){ ?>
	<div id="toppanel">
		<div id="tp_header" <?php if($this->config['topimage'] == 0) echo 'style="background:none;"';?>>
			<span id="tp_title"><?php echo $this->config['title'];?></span>
		</div>
	</div>
	<div id="errormessagedown"></div>
	<div id="errormessage" class="errormessage">
		<div id="message"><b><?php echo $this->config['offline_text']; ?></b></div>
	</div>
<?php }else{ ?>
	<div id="toppanel">
		<div id="tp_header" <?php if($this->config['topimage'] == 0) echo 'style="background:none;"';?>>
			<span id="tp_title"><?php echo $this->config['title'];?></span>
			<span id="tp_curloc">
				<?php if ($this->config['cur_location'] == 1) {
						$vj = $this->vj; 
						if ($vj == '1'){ $vm=1;//my jobs
							echo JText::_('JS_CUR_LOC'); ?> : <a href="index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=myjobs&Itemid=<?php echo $this->Itemid; ?>" class="curloclnk" ><?php echo JText::_('JS_MY_JOBS'); ?></a> > <?php echo JText::_('JS_VIEW_JOB');
						}else if ($vj == '2'){ $vm=2; $aj=1;//job cat
							echo JText::_('JS_CUR_LOC'); ?> : <a href="index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=jobcat&Itemid=<?php echo $this->Itemid; ?>" class="curloclnk" ><?php echo JText::_('JS_JOB_CATEGORIES'); ?></a> > <a href="index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=list_jobs&jobcat=<?php echo $this->job->jobcategory; ?>&Itemid=<?php echo $this->Itemid; ?>" class="curloclnk" ><?php echo JText::_('JS_JOBS_LIST_BY_CATEGORY'); ?></a> ><?php echo JText::_('JS_VIEW_JOB');
						}else if ($vj == '3'){ $vm=3; $aj=2;//job search
							echo JText::_('JS_CUR_LOC'); ?> : <a href="index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=jobsearch&Itemid=<?php echo $this->Itemid; ?>" class="curloclnk"><?php echo JText::_('JS_SEARCH_JOB'); ?></a> > <a href="index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=job_searchresults&Itemid=<?php echo $this->Itemid; ?>" class="curloclnk" ><?php echo JText::_('JS_JOB_SEARCH_RESULT'); ?></a> > <?php echo JText::_('JS_VIEW_JOB');
						}else if ($vj == '4'){ $vm=4; //my applied jobs
							echo JText::_('JS_CUR_LOC'); ?> : <a href="index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=myappliedjobs&Itemid=<?php echo $this->Itemid; ?>" class="curloclnk"><?php echo JText::_('JS_MY_APPLIED_JOBS'); ?></a> > <?php echo JText::_('JS_VIEW_JOB');
						}else if ($vj == '5'){ $vm=5; $aj=3;//newest jobs
							echo JText::_('JS_CUR_LOC'); ?> : <a href="index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=listnewestjobs&Itemid=<?php echo $this->Itemid; ?>" class="curloclnk"><?php echo JText::_('JS_NEWEST_JOBS'); ?></a> > <?php echo JText::_('JS_VIEW_JOB');
						}else if ($vj == '6'){ $vm=5; $aj=1;//company jobs jobs
							echo JText::_('JS_CUR_LOC'); ?> : <a href="index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=company_jobs&cd=<?php echo $this->job->companyid; ?>&Itemid=<?php echo $this->Itemid; ?>" class="curloclnk"><?php echo $this->job->companyname.' '.JText::_('JS_JOBS'); ?></a> > <?php echo JText::_('JS_VIEW_JOB');
						}
				} ?>
			</span>
		</div>
		<div id="tp_links">
			<?php 
			if (sizeof($this->jobseekerlinks) != 0){
				foreach($this->jobseekerlinks as $lnk)	{ ?>
					<a class="<?php if($lnk[2] == 1)echo 'first'; elseif($lnk[2] == -1)echo 'last';  ?>" href="<?php echo $lnk[0]; ?>"><?php echo $lnk[1]; ?></a>
				<?php }
			}
			if (sizeof($this->employerlinks) != 0){
				foreach($this->employerlinks as $lnk)	{?>
					<a class="<?php if($lnk[2] == 1)echo 'first'; elseif($lnk[2] == -1)echo 'last';  ?>" href="<?php echo $lnk[0]; ?>"> <?php echo $lnk[1]; ?></a>
				<?php }
			}
			?>
		</div>
		<div id="tp_heading">
			<span id="tp_headingtext">
				<span id="tp_headingtext_left"></span>
				<span id="tp_headingtext_center">
                <?php 
					if ($this->listjobconfig['lj_title'] == '1') {   
						echo '[ '.$this->job->title;
						$days = $this->config['newdays'];
						$isnew = date("Y-m-d H:i:s", strtotime("-$days days"));
						if ($this->job->created > $isnew)
							echo "<font color='red'> ".JText::_('JS_NEW')." </font>";
						echo ' ] ';
						}
						echo JText::_('JS_JOB_INFO');  ?>
				</span>
				<span id="tp_headingtext_right"></span>				
			</span>
		</div>
	</div>
<?php 
	if( isset($this->job)){//job summary table ?>
	<table cellpadding="0" cellspacing="0" border="0" width="100%" >
        <?php   $trclass = array("odd", "even");
		$i = 0;
                $j = 0; // for two column
                $k = 2;
		$isodd = 1;?>
            <tr id="mc_field_row" class="<?php echo $this->theme[$trclass[$isodd]]; ?>">
          <?php foreach($this->fieldsordering as $field){
                 switch ($field->field) {
/*                        case "jobtitle":
                         if ($this->listjobconfig['lj_title'] == '1') {   ?>
                              <td width="5%">&nbsp;</td>
                                <td width="30%"><b><?php echo JText::_('JS_TITLE'); ?></b></td>
                                        <td><?php echo $this->job->title;
                                                $days = $this->config['newdays'];
                                                $isnew = date("Y-m-d H:i:s", strtotime("-$days days"));
                                                if ($this->job->created > $isnew)
                                                        echo "<font color='red'> ".JText::_('JS_NEW')." </font>";
                                        ?></td>
                                 <?php $j++; if($j%$k == 0){ $isodd = 1 - $isodd; ?>
                                      </tr>
                                      <tr id="mc_field_row" class="<?php echo $this->theme[$trclass[$isodd]]; ?>">
                                  <?php }?>
                          <?php } ?>
                        <?php break; */
                        case "company":
                         if ($this->listjobconfig['lj_company'] == '1') {     ?>
                                <td class="ji_title"><?php echo JText::_('JS_COMPANY'); ?></td>
                                        <td class="ji_data">
                                            <?php if (isset($_GET['jobcat'])) $jobcat = $_GET['jobcat']; else $jobcat=null;
                                            $link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=view_company&vm='.$vm.'&md='.$this->job->companyid.'&jobcat='.$jobcat.'&Itemid='.$this->Itemid; ?>
                                            <span id="anchor"><a class="anchor" href="<?php echo $link?>"><strong><?php echo $this->job->companyname; ?></strong></a></span>
                                        </td>
                                 <?php $j++; if($j%$k == 0){ $isodd = 1 - $isodd; ?>
                                      </tr>
                                      <tr id="mc_field_row" class="<?php echo $this->theme[$trclass[$isodd]]; ?>">
                                  <?php }?>
                          <?php } ?>
                        <?php break;
                        case "department": ?>
                                <td class="ji_title"><?php echo JText::_('JS_DEPARTMENT'); ?></td>
                                        <td class="ji_data">
                                                <?php echo $this->job->departmentname; ?>
                                        </td>
                                 <?php $j++; if($j%$k == 0){ $isodd = 1 - $isodd; ?>
                                      </tr>
                                      <tr id="mc_field_row" class="<?php echo $this->theme[$trclass[$isodd]]; ?>">
                                  <?php }?>
                        <?php break; 
                        case "jobcategory": 
                              if ($this->listjobconfig['lj_category'] == '1') { ?>
                                        <td class="ji_title"><?php echo JText::_('JS_CATEGORY'); ?></td>
                                        <td class="ji_data"><?php echo $this->job->cat_title; ?></td>
                                 <?php $j++; if($j%$k == 0){ $isodd = 1 - $isodd; ?>
                                      </tr>
                                      <tr id="mc_field_row" class="<?php echo $this->theme[$trclass[$isodd]]; ?>">
                                  <?php }?>
                                <?php } ?>
                        <?php break;
                        case "subcategory":  ?>
                                        <td class="ji_title"><?php echo JText::_('JS_SUB_CATEGORY'); ?></td>
                                        <td class="ji_data"><?php echo $this->job->subcategory; ?></td>
                                 <?php $j++; if($j%$k == 0){ $isodd = 1 - $isodd; ?>
                                      </tr>
                                      <tr id="mc_field_row" class="<?php echo $this->theme[$trclass[$isodd]]; ?>">
                                  <?php }?>
                        <?php break;
                        case "jobtype": 
                              if ($this->listjobconfig['lj_jobtype'] == '1') { ?>
                                <td class="ji_title"><?php echo JText::_('JS_JOBTYPE'); ?></td>
								<td class="ji_data"><?php echo $this->job->jobtypetitle; ?></td>
                                 <?php $j++; if($j%$k == 0){ $isodd = 1 - $isodd; ?>
                                      </tr>
                                      <tr id="mc_field_row" class="<?php echo $this->theme[$trclass[$isodd]]; ?>">
                                  <?php }?>
                                <?php } ?>
                        <?php break;
                        case "jobstatus":
                              if ($this->listjobconfig['lj_jobstatus'] == '1') { ?>
                                <td class="ji_title"><?php echo JText::_('JS_JOBSTATUS'); ?></td>
								<td class="ji_data"><?php echo $this->job->jobstatustitle; ?></td>
                                 <?php $j++; if($j%$k == 0){ $isodd = 1 - $isodd; ?>
                                      </tr>
                                      <tr id="mc_field_row" class="<?php echo $this->theme[$trclass[$isodd]]; ?>">
                                  <?php }?>
                            <?php } ?>
                        <?php break;
                        case "jobshift": ?>
                      <?php if ( $field->published == 1 ) { ?>
                                <td class="ji_title"><?php echo JText::_('JS_SHIFT'); ?></td>
								<td class="ji_data"><?php echo $this->job->shifttitle; ?></td>
                                 <?php $j++; if($j%$k == 0){ $isodd = 1 - $isodd; ?>
                                      </tr>
                                      <tr id="mc_field_row" class="<?php echo $this->theme[$trclass[$isodd]]; ?>">
                                  <?php }?>
                          <?php } ?>
                        <?php break;
                        case "jobsalaryrange":  ?>
                      <?php if ( $field->published == 1 ) { ?>
                                <?php if ( $this->job->hidesalaryrange != 1 ) { // show salary ?>
                                <td class="ji_title"><?php echo JText::_('JS_SALARYRANGE'); ?></td>
								<td class="ji_data"><?php
                                                if ($this->job->salaryfrom) echo JText::_('JS_S_FROM') .' ' .$this->job->symbol. $this->job->salaryfrom;
                                                if ($this->job->salaryto) echo ' - ' . JText::_('JS_S_TO'). ' '.$this->job->symbol . $this->job->salaryto;
                                                if ($this->job->salarytype) echo ' ' . $this->job->salarytype;;
                                                //echo $salaryrange; ?></td>
                                 <?php $j++; if($j%$k == 0){ $isodd = 1 - $isodd; ?>
                                      </tr>
                                      <tr id="mc_field_row" class="<?php echo $this->theme[$trclass[$isodd]]; ?>">
                                  <?php }?>
                                <?php } ?>
                          <?php } ?>
                        <?php break;
                        case "heighesteducation":?>
                      <?php if ( $field->published == 1 ) { ?>
                                <?php
                                        if($this->job->iseducationminimax == 1){
                                                if($this->job->educationminimax == 1) $title = JText::_('JS_MINIMUM_EDEDUCATION');
                                                else $title = JText::_('JS_MAXIMUM_EDEDUCATION');
                                                $educationtitle = $this->job->educationtitle;
                                        }else {
                                                $title = JText::_('JS_EDEDUCATION');
                                                $educationtitle = $this->job->mineducationtitle.' - '.$this->job->maxeducationtitle;
                                        }
                                ?>
                                <td class="ji_title"><?php echo $title; ?></td>
								<td class="ji_data"><?php echo $educationtitle; ?></td>
                             <?php $j++; if($j%$k == 0){ $isodd = 1 - $isodd; ?>
                                  </tr>
                                  <tr id="mc_field_row" class="<?php echo $this->theme[$trclass[$isodd]]; ?>">
                              <?php }?>
                                <td class="ji_title"><?php echo JText::_('JS_DEGREE_TITLE'); ?></td>
								<td class="ji_data"><?php echo $this->job->degreetitle; ?></td>
                                 <?php $j++; if($j%$k == 0){ $isodd = 1 - $isodd; ?>
                                      </tr>
                                      <tr id="mc_field_row" class="<?php echo $this->theme[$trclass[$isodd]]; ?>">
                                  <?php }?>
                                <?php } ?>
                        <?php break;
                        case "noofjobs":?>
                                <td class="ji_title"><?php echo JText::_('JS_NOOFJOBS'); ?></td>
								<td class="ji_data"><?php echo $this->job->noofjobs; ?></td>
                                 <?php $j++; if($j%$k == 0){ $isodd = 1 - $isodd; ?>
                                      </tr>
                                      <tr id="mc_field_row" class="<?php echo $this->theme[$trclass[$isodd]]; ?>">
                                  <?php }?>
                        <?php break;
                        case "experience": ?>
                      <?php if ( $field->published == 1 ) { ?>
                                <?php
                                        if($this->job->isexperienceminimax == 1){
                                                if($this->job->experienceminimax == 1) $title = JText::_('JS_MINIMUM_EXPERIENCE');
                                                else $title = JText::_('JS_MAXIMUM_EXPERIENCE');
                                                $experiencetitle = $this->job->experiencetitle;
                                        }else {
                                                $title = JText::_('JS_EXPERIENCE');
                                                $experiencetitle = $this->job->minexperiencetitle.' - '.$this->job->maxexperiencetitle;
                                        }
                                        if($this->job->experiencetext) $experiencetitle .= ' ('.$this->job->experiencetext.')';
                                ?>
                                <td class="ji_title"><?php echo $title; ?></td>
								<td class="ji_data"><?php echo $experiencetitle; ?></td>
                                 <?php $j++; if($j%$k == 0){ $isodd = 1 - $isodd; ?>
                                      </tr>
                                      <tr id="mc_field_row" class="<?php echo $this->theme[$trclass[$isodd]]; ?>">
                                  <?php }?>
                          <?php } ?>
                        <?php break;
                        case "duration": ?>
                      <?php if ( $field->published == 1 ) { ?>
                                <td class="ji_title"><?php echo JText::_('JS_DURATION'); ?></td>
								<td class="ji_data"><?php echo $this->job->duration; ?></td>
                                 <?php $j++; if($j%$k == 0){ $isodd = 1 - $isodd; ?>
                                      </tr>
                                      <tr id="mc_field_row" class="<?php echo $this->theme[$trclass[$isodd]]; ?>">
                                  <?php }?>
                          <?php } ?>
                        <?php break;
                        case "startpublishing": ?>
                              <?php //if ($vj == '1'){ //my jobs ?>
                                        <td class="ji_title"><?php echo JText::_('JS_START_PUBLISHING'); ?></td>
										<td class="ji_data"><?php echo date($this->config['date_format'],strtotime($this->job->startpublishing)); ?></td>
                                 <?php $j++; if($j%$k == 0){ $isodd = 1 - $isodd; ?>
                                      </tr>
                                      <tr id="mc_field_row" class="<?php echo $this->theme[$trclass[$isodd]]; ?>">
                                  <?php }?>
                                  <?php //} ?>
                        <?php break;
                        case "stoppublishing": ?>
                              <?php //if ($vj == '1'){ //my jobs ?>
                                                <td class="ji_title"><?php echo JText::_('JS_STOP_PUBLISHING'); ?></td>
												<td class="ji_data"><?php echo  date($this->config['date_format'],strtotime($this->job->stoppublishing)); ?></td>
                                 <?php $j++; if($j%$k == 0){ $isodd = 1 - $isodd; ?>
                                      </tr>
                                      <tr id="mc_field_row" class="<?php echo $this->theme[$trclass[$isodd]]; ?>">
                                  <?php }?>
                        <?php break;
                        case "country":
                              if ($this->listjobconfig['lj_country'] == '1') { ?>
                                <td class="ji_title"><?php echo JText::_('JS_COUNTRY'); ?></td>
								<td class="ji_data"><?php echo $this->job->countryname; ?></td>
                                 <?php $j++; if($j%$k == 0){ $isodd = 1 - $isodd; ?>
                                      </tr>
                                      <tr id="mc_field_row" class="<?php echo $this->theme[$trclass[$isodd]]; ?>">
                                  <?php }?>
                              <?php } ?>
                        <?php break;
                        case "state":
                            if ($this->listjobconfig['lj_state'] == '1') { ?>
                                <td class="ji_title"><?php echo JText::_('JS_STATE'); ?></td>
								<td class="ji_data"><?php if($this->job->statename != '') echo $this->job->statename; elseif($this->job->state != '') echo $this->job->state; ?></td>
                                 <?php $j++; if($j%$k == 0){ $isodd = 1 - $isodd; ?>
                                      </tr>
                                      <tr id="mc_field_row" class="<?php echo $this->theme[$trclass[$isodd]]; ?>">
                                  <?php }?>
                            <?php } ?>
                        <?php break;
                        case "county":
                          if ($this->listjobconfig['lj_county'] == '1') { ?>
                                <td class="ji_title"><?php echo JText::_('JS_COUNTY'); ?></td>
								<td class="ji_data"><?php if($this->job->countyname != '') echo $this->job->countyname; elseif($this->job->county != '') echo $this->job->county; ?></td>
                                 <?php $j++; if($j%$k == 0){ $isodd = 1 - $isodd; ?>
                                      </tr>
                                      <tr id="mc_field_row" class="<?php echo $this->theme[$trclass[$isodd]]; ?>">
                                  <?php }?>
                            <?php } ?>
                        <?php break;
                        case "city":
                          if ($this->listjobconfig['lj_city'] == '1') { ?>
                                <td class="ji_title"><?php echo JText::_('JS_CITY'); ?></td>
								<td class="ji_data"><?php if($this->job->cityname != '') echo $this->job->cityname; elseif($this->job->city != '') echo $this->job->city;?></td>
                                 <?php $j++; if($j%$k == 0){ $isodd = 1 - $isodd; ?>
                                      </tr>
                                      <tr id="mc_field_row" class="<?php echo $this->theme[$trclass[$isodd]]; ?>">
                                  <?php }?>
                                <?php } ?>
                        <?php break;
                }?>

          <?php  }
          if($j%$k == 0){
			  echo '</tr>';
		  }else{
			  echo '<td></td><td></td></tr>';
		  }?>
          
        </table>
	<table cellpadding="0" cellspacing="0" border="0" width="100%" >
      <tr>
        <td colspan="2" height="5"></td>
      </tr>
		<?php
		$trclass = array("odd", "even");
		$i = 0;
		$isodd = 1;
		foreach($this->fieldsordering as $field){ 
			//echo '<br> uf'.$field->field;
			switch ($field->field) {
				
				case "video": $isodd = 1 - $isodd;
						if ($this->job->video) { ?>
				      <tr id="mc_field_row" class="<?php echo $this->theme[$trclass[$isodd]]; ?>">
				        <td class="ji_title2"><?php echo JText::_('JS_VIDEO'); ?></td>
						<td class="ji_data2">
						<iframe title="YouTube video player" width="480" height="390" 
                                                        src="http://www.youtube.com/embed/<?php echo $this->job->video; ?>" frameborder="0" allowfullscreen>
                                                </iframe>
                                                    <?php /*
                                                    <object width="425" height="344">
							<param name="movie" value="http://www.youtube.com/v/<?php echo $this->job->video; ?>&hl=en_US&fs=1&rel=0"></param>
							<param name="allowFullScreen" value="true"></param>
							<param name="allowscriptaccess" value="always"></param>
							<embed src="http://www.youtube.com/v/<?php echo $this->job->video; ?>&hl=en_US&fs=1&rel=0" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="425" height="344"></embed>
							</object>
                                                     *
                                                     */?>
						</td>
				      </tr>
					  <?php } ?>
				<?php  break;
                                case "map": $isodd = 1 - $isodd; ?>
                                <?php  if ($this->job->map) { ?>
				      <tr id="mc_field_row" class="<?php echo $this->theme[$trclass[$isodd]]; ?>">
				        <td class="ji_title2"><?php echo JText::_('JS_MAP'); ?></td>
						<td class="ji_data2">
							<iframe width="425" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"
								src="<?php echo $this->job->map; ?>">
							</iframe><br />
							<small><a href="<?php echo $this->job->map; ?>" target="_blank">View Larger Map</a></small>
						</td>
				      </tr>
                                <?php } ?>
				<?php break;
				case "agreement": $isodd = 1 - $isodd; ?>
				    <tr id="mc_field_row" class="<?php echo $this->theme[$trclass[$isodd]]; ?>">
				        <td class="ji_title2"><?php echo JText::_('JS_AGREEMENT'); ?></td>
						<td class="ji_data2"><?php echo $this->job->agreement; ?></td>
					</tr>
				<?php break;
				case "description": $isodd = 1 - $isodd; ?>
				    <tr id="mc_field_row" class="<?php echo $this->theme[$trclass[$isodd]]; ?>">
				        <td class="ji_title2"><?php echo JText::_('JS_DESCRIPTION'); ?></td>
						<td class="ji_data2"><?php echo $this->job->description; ?></td>
					</tr>
				<?php break;
				case "qualifications": $isodd = 1 - $isodd; ?>
				    <tr id="mc_field_row" class="<?php echo $this->theme[$trclass[$isodd]]; ?>">
				        <td class="ji_title2"><?php echo JText::_('JS_QUALIFICATIONS'); ?></td>
						<td class="ji_data2"><?php echo $this->job->qualifications; ?></td>
					</tr>
				<?php break;
				case "prefferdskills": $isodd = 1 - $isodd; ?>
				    <tr id="mc_field_row" class="<?php echo $this->theme[$trclass[$isodd]]; ?>">
				        <td class="ji_title2"><?php echo JText::_('JS_PREFFERD_SKILLS'); ?></td>
						<td class="ji_data2"><?php echo $this->job->prefferdskills; ?></td>
					</tr>
				<?php break;
				default:
					//echo '<br> default uf '.$filed->field;
					if ( $field->published == 1 ) { 
					
						foreach($this->userfields as $ufield){ 
							if($field->field == $ufield[0]->id) {
								$isodd = 1 - $isodd; 
								$userfield = $ufield[0];
								$i++;
								echo '<tr id="mc_field_row" class="'.$this->theme[$trclass[$isodd]] .'">';
								echo '<td class="ji_title2">'. $userfield->title .'</td>';
								if ($userfield->type == "checkbox"){
									if(isset($ufield[1])){ $fvalue = $ufield[1]->data; $userdataid = $ufield[1]->id;}  else {$fvalue=""; $userdataid = ""; }
									if ($fvalue == '1') $fvalue = "True"; else $fvalue = "false";
								}elseif ($userfield->type == "select"){
									if(isset($ufield[2])){ $fvalue = $ufield[2]->fieldtitle; $userdataid = $ufield[2]->id;} else {$fvalue=""; $userdataid = ""; }
								}else{
									if(isset($ufield[1])){ $fvalue = $ufield[1]->data; $userdataid = $ufield[1]->id;}  else {$fvalue=""; $userdataid = ""; }
								}
//								echo '<td>'.$fvalue.'</td>';	
								echo '<td class="ji_data2">'.$fvalue.'</td>';	
								echo '</tr>';
							}
						}	 
					}	

				?>
			<?php }
		}
		?>
		<?php $isodd = 1 - $isodd; ?>	
      <tr id="mc_field_row" class="<?php echo $this->theme[$trclass[$isodd]]; ?>">
        <td class="ji_title2"><?php echo JText::_('JS_DATEPOSTED'); ?></td>
		<td class="ji_data2"><?php echo date($this->config['date_format'].' H:i:s',strtotime($this->job->created));  ?></td>
      </tr>

      <tr>
        <td colspan="2" height="5"></td>
      </tr>
	<?php if (($vj == '2') || ($vj == '3') || ($vj == '5') || ($vj == '6')){ ?>
      <tr id="mc_field_row" class="<?php echo $this->theme[$trclass[$isodd]]; ?>"> 
        <td colspan="2" align="center">
			<div id="pkg_bn_btn">
				<?php $link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=job_apply&aj='.$aj.'&jobcat='.$this->job->jobcategory.'&bi='.$this->job->id.'&Itemid='.$this->Itemid; ?>
				<a id="button" href="<?php echo $link?>" class="button"><strong><?php echo JText::_('JS_APPLYNOW'); ?></strong></a>		   
			</div>
		</td>
      </tr>
	<?php } ?>  
  
	</table>
	<?php }else { ?>
	<div id="errormessagedown"></div>
	<div id="errormessage" class="errormessage">
		<div id="message"><b><?php echo JText::_('JS_RESULT_NOT_FOUND'); ?></b></div>
	</div>
<?php
		 
		 } ?>
<?php 
}//ol
?>
<div id="jsjobs_footer"><?php echo eval(base64_decode('aWYoJHRoaXMtPmNvbmZpZ1snZnJfY3JfdHhzaCddKSB7DQplY2hvIA0KJzx0YWJsZSB3aWR0aD0iMTAwJSIgc3R5bGU9InRhYmxlLWxheW91dDpmaXhlZDsiPg0KPHRyPjx0ZCBoZWlnaHQ9IjE1Ij48L3RkPjwvdHI+DQo8dHI+PHRkIHN0eWxlPSJ2ZXJ0aWNhbC1hbGlnbjp0b3A7IiBhbGlnbj0iY2VudGVyIj4NCjxhIGNsYXNzPSJpbWciIHRhcmdldD0iX2JsYW5rIiBocmVmPSJodHRwOi8vd3d3Lmpvb21za3kuY29tIj48aW1nIHNyYz0iaHR0cDovL3d3dy5qb29tc2t5LmNvbS9sb2dvL2pzam9ic2NybG9nby5wbmciPjwvYT4NCjxicj4NCkNvcHlyaWdodCAmY29weTsgMjAwOCAtICcuZGF0ZSgnWScpLicsDQo8c3BhbiBpZD0idGhlbWVhbmNob3IiPiA8YSBjbGFzcz0iYW5jaG9yInRhcmdldD0iX2JsYW5rIiBocmVmPSJodHRwOi8vd3d3LmJ1cnVqc29sdXRpb25zLmNvbSI+QnVydWogU29sdXRpb25zIDwvYT48L3NwYW4+PC90ZD48L3RyPg0KPC90YWJsZT4nOw0KfQ=='));?></div>
