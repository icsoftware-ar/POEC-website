<?php

/** @Copyright Copyright (C) 2011
 * @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
 + Created by:	Ahmad Bilal
 * Company:		Buruj Solutions
 + Contact:		www.burujsolutions.com , ahmad@burujsolutions.com
 * Created on:	Oct 22, 2011
 ^
 + Project:		JS Documentation 
*/
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class com_JSJobsInstallerScript
{
	/**
	 * method to install the component
	 *
	 * @return void
	 */
	function install($parent) 
	{
		// $parent is the class calling this method
		//$parent->getParent()->setRedirectURL('index.php?option=com_jsdocumentation');
	}

	/**
	 * method to uninstall the component
	 *
	 * @return void
	 */
	function uninstall($parent) 
	{
		// $parent is the class calling this method
		echo '<p>' . JText::_('JS_JSJOBS_UNINSTALL_TEXT') . '</p>';
	}

	/**
	 * method to update the component
	 *
	 * @return void
	 */
	function update($parent) {

			$db = &JFactory::getDBO();
			$query = "SELECT * FROM `#__js_job_config` WHERE configname = 'versioncode'";
			$db->setQuery($query);
			$version = $db->loadObject();
			if($version){

				$query = "SELECT COUNT(*) FROM `#__js_job_goldcompanies`";
				$db->setQuery($query);
				$goldcompanies = $db->loadResult();
				if ( $goldcompanies == 0 )	{ // no back up found

					$sql = "CREATE TABLE IF NOT EXISTS `#__js_job_goldcompanies` (`id` int(11) NOT NULL auto_increment,`uid` int(11) default NULL,`packageid` int(11) default NULL, `companyid` int(11) NOT NULL,`startdate` datetime NOT NULL,`enddate` datetime NOT NULL,`status` tinyint(4) NOT NULL,`created` datetime NOT NULL,PRIMARY KEY  (`id`),KEY `goldcompanies_uid` (`uid`),KEY `goldcompanies_packageid` (`packageid`), KEY `goldcompanies_companyid` (`companyid`) ) ENGINE=MyISAM;";
					$db->setQuery($sql); if (!$db->query()) echo "<font color='red'>Error occurred while attempting to Creating New table (Gold Companies).</font><br>";
					$sql = "CREATE TABLE IF NOT EXISTS `#__js_job_goldjobs` (`id` int(11) NOT NULL auto_increment, `uid` int(11) default NULL, `packageid` int(11) default NULL, `jobid` int(11) NOT NULL, `startdate` datetime NOT NULL, `enddate` datetime NOT NULL, `status` tinyint(4) NOT NULL, `created` datetime NOT NULL, PRIMARY KEY  (`id`), KEY `goldjobs_uid` (`uid`), KEY `goldjobs_packageid` (`packageid`), KEY `goldjobs_jobid` (`jobid`) ) ENGINE=MyISAM;";
					$db->setQuery($sql); if (!$db->query()) echo "<font color='red'>Error occurred while attempting to Creating New table (Gold Jobs).</font><br>";
					$sql = "CREATE TABLE IF NOT EXISTS `#__js_job_goldresumes` ( `id` int(11) NOT NULL auto_increment, `uid` int(11) default NULL, `packageid` int(11) default NULL, `resumeid` int(11) default NULL, `startdate` datetime NOT NULL, `enddate` datetime NOT NULL, `status` tinyint(4) NOT NULL, `created` datetime NOT NULL, PRIMARY KEY  (`id`), KEY `goldresumes_uid` (`uid`), KEY `goldresumes_packageid` (`packageid`), KEY `goldresumes_resumeid` (`resumeid`) ) ENGINE=MyISAM;";
					$db->setQuery($sql); if (!$db->query()) echo "<font color='red'>Error occurred while attempting to Creating New table (Gold Resume).</font><br>";
					$sql = "CREATE TABLE IF NOT EXISTS `#__js_job_featuredcompanies` ( `id` int(11) NOT NULL auto_increment, `uid` int(11) default NULL, `packageid` int(11) default NULL, `companyid` int(11) NOT NULL, `startdate` datetime NOT NULL, `enddate` datetime NOT NULL, `status` tinyint(4) NOT NULL, `created` datetime NOT NULL, PRIMARY KEY  (`id`), KEY `featuredcompanies_uid` (`uid`), KEY `featuredcompanies_packageid` (`packageid`), KEY `featuredcompanies_companyid` (`companyid`) ) ENGINE=MyISAM;";
					$db->setQuery($sql); if (!$db->query()) echo "<font color='red'>Error occurred while attempting to Creating New table (Featured Companies).</font><br>";
					$sql = "CREATE TABLE IF NOT EXISTS `#__js_job_featuredjobs` ( `id` int(11) NOT NULL auto_increment, `uid` int(11) default NULL, `packageid` int(11) default NULL, `jobid` int(11) NOT NULL, `startdate` datetime NOT NULL, `enddate` datetime NOT NULL, `status` tinyint(4) NOT NULL, `created` datetime NOT NULL, PRIMARY KEY  (`id`), KEY `featuredjobs_uid` (`uid`), KEY `featuredjobs_packageid` (`packageid`), KEY `featuredjobs_jobid` (`jobid`) ) ENGINE=MyISAM;";
					$db->setQuery($sql); if (!$db->query()) echo "<font color='red'>Error occurred while attempting to Creating New table (Featured Jobs).</font><br>";
					$sql = "CREATE TABLE IF NOT EXISTS `#__js_job_featuredresumes` ( `id` int(11) NOT NULL auto_increment, `uid` int(11) default NULL, `packageid` int(11) default NULL, `resumeid` int(11) default NULL, `startdate` datetime NOT NULL, `enddate` datetime NOT NULL, `status` tinyint(4) NOT NULL, `created` datetime NOT NULL, PRIMARY KEY  (`id`), KEY `featuredjobs_uid` (`uid`), KEY `featuredjobs_packageid` (`packageid`), KEY `featuredjobs_resumeid` (`resumeid`) ) ENGINE=MyISAM;";
					$db->setQuery($sql); if (!$db->query()) echo "<font color='red'>Error occurred while attempting to Creating New table (Featured Resme).</font><br>";
					$sql = "CREATE TABLE IF NOT EXISTS `#__js_job_folderresumes` ( `id` int(11) NOT NULL AUTO_INCREMENT, `uid` int(11) NOT NULL, `jobid` int(11) NOT NULL, `resumeid` int(11) NOT NULL, `folderid` int(11) NOT NULL, `created` datetime NOT NULL, PRIMARY KEY (`id`) ) ENGINE=MyISAM;";
					$db->setQuery($sql); if (!$db->query()) echo "<font color='red'>Error occurred while attempting to Creating New table (Folder Resume).</font><br>";
					$sql = "CREATE TABLE IF NOT EXISTS `#__js_job_folders` ( `id` int(11) NOT NULL AUTO_INCREMENT, `uid` int(11) NOT NULL, `global` tinyint(1) NOT NULL, `jobid` int(11) DEFAULT NULL, `packageid` int(11) NOT NULL, `paymenthistoryid` int(11) NOT NULL, `name` varchar(255) NOT NULL, `decription` text, `status` tinyint(1) NOT NULL, `created` datetime DEFAULT NULL, PRIMARY KEY (`id`) ) ENGINE=MyISAM;";
					$db->setQuery($sql); if (!$db->query()) echo "<font color='red'>Error occurred while attempting to Creating New table (Folders).</font><br>";
					$sql = "CREATE TABLE IF NOT EXISTS `#__js_job_jobalertsetting` ( `id` int(11) NOT NULL AUTO_INCREMENT, `uid` int(11) NOT NULL, `categoryid` int(11) NOT NULL, `subcategoryid` int(11) NOT NULL, `contactemail` varchar(255) NOT NULL, `country` varchar(100) NOT NULL, `state` varchar(60) DEFAULT NULL, `county` varchar(100) DEFAULT NULL, `city` varchar(100) DEFAULT NULL, `zipcode` varchar(60) DEFAULT NULL, `sendtime` datetime NOT NULL, `status` int(11) NOT NULL, `created` datetime NOT NULL, `keywords` varchar(255) DEFAULT NULL, `alerttype` tinyint(1) DEFAULT NULL, `longitude` varchar(50) DEFAULT NULL, `latitude` varchar(50) DEFAULT NULL, `coordinatesradius` int(11) NOT NULL, `lastmailsend` datetime NOT NULL, PRIMARY KEY (`id`) ) ENGINE=MyISAM;";
					$db->setQuery($sql); if (!$db->query()) echo "<font color='red'>Error occurred while attempting to Creating New table (Job Alert Settings).</font><br>";
					$sql = "CREATE TABLE IF NOT EXISTS `#__js_job_messages` ( `id` int(11) NOT NULL AUTO_INCREMENT, `employerid` int(11) NOT NULL, `jobseekerid` int(11) DEFAULT NULL, `sendby` int(11) NOT NULL, `jobid` int(11) NOT NULL, `replytoid` int(11) NOT NULL, `resumeid` int(11) NOT NULL, `subject` varchar(500) NOT NULL, `message` text NOT NULL, `isread` tinyint(1) NOT NULL, `isconflict` tinyint(1) DEFAULT NULL, `conflictvalue` varchar(500) DEFAULT NULL, `status` tinyint(1) NOT NULL, `created` datetime NOT NULL, PRIMARY KEY (`id`) ) ENGINE=MyISAM;";
					$db->setQuery($sql); if (!$db->query()) echo "<font color='red'>Error occurred while attempting to Creating New table (Messages).</font><br>";
					$sql = "CREATE TABLE IF NOT EXISTS `#__js_job_resumerating` ( `id` int(11) NOT NULL AUTO_INCREMENT, `uid` int(11) NOT NULL, `jobid` int(11) NOT NULL, `resumeid` int(11) NOT NULL, `rating` int(11) NOT NULL, `votes` float DEFAULT NULL, `meonly` tinyint(1) DEFAULT NULL, `created` datetime NOT NULL, `updated` datetime DEFAULT NULL, PRIMARY KEY (`id`) ) ENGINE=MyISAM;";
					$db->setQuery($sql); if (!$db->query()) echo "<font color='red'>Error occurred while attempting to Creating New table (Resume Rating).</font><br>";

					//if (!$result = $db->queryBatch()) echo "<font color='red'>".JText::_('Error occurred while attempting to Creating New table.</font><br>');

					if(($version->configvalue == '108') || ($version->configvalue == '1085') || ($version->configvalue == '1086') || ($version->configvalue == '1087')){
						if($version->configvalue == '108'){
							$query = "ALTER TABLE `#__js_job_jobs`
							ADD COLUMN `longitude` varchar(50) DEFAULT NULL,
							ADD COLUMN `latitude` varchar(50) DEFAULT NULL;";
							$db->setQuery($query);
							//if (!$result = $db->queryBatch()) echo "<font color='red'>".JText::_('Error occurred while attempting to Alter Dealer table.</font><br>');

							$query = "ALTER TABLE `#__js_job_resume`
							ADD COLUMN `date_of_birth` datetime DEFAULT NULL,
							ADD COLUMN `longitude` varchar(50) DEFAULT NULL,
							ADD COLUMN `latitude` varchar(50) DEFAULT NULL,
							ADD COLUMN `video` varchar(50) DEFAULT NULL;";
							$db->setQuery($query);
							//if (!$result = $db->queryBatch()) echo "<font color='red'>".JText::_('Error occurred while attempting to Alter Dealer table.</font><br>');

							$query = "ALTER TABLE `#__js_job_jobalertsetting`
							ADD COLUMN `keywords` varchar(255) DEFAULT NULL,
							ADD COLUMN `alerttype` tinyint(1) DEFAULT NULL,
							ADD COLUMN `longitude` varchar(50) DEFAULT NULL,
							ADD COLUMN `latitude` varchar(50) DEFAULT NULL,
							ADD COLUMN `coordinatesradius` int(11) NOT NULL,
							ADD COLUMN `lastmailsend` datetime NOT NULL;";
							$db->setQuery($query);
							//if (!$result = $db->queryBatch()) echo "<font color='red'>".JText::_('Error occurred while attempting to Alter Dealer table.</font><br>');

							$emailqueryupdate = "INSERT INTO ".$db->nameQuote('#__js_job_emailtemplates')." VALUES (18,0,'job-to-friend',NULL,'JS Jobs: Job To Friend','<p>Dear Mr/Miss,</p>\r\n<p>Your Friend {SENDER_NAME} will send you this mail through our site {SITE_NAME} to inform you for a job.</p>\r\n<p>Title: {JOB_TITLE}</p>\r\n<p>Job Category: {JOB_CATEGORY}</p>\r\n<p>Company Name: {COMPANY_NAME}</p>\r\n<p>{CLICK_HERE_TO_VISIT} the job detail.</p>\r\n<p>Thank you.</p>\r\n<p>{SENDER_MESSAGE}</p>',NULL,'2011-03-31 16:46:16');";
							$sql = 'UPDATE '.$db->nameQuote('#__js_job_fieldsordering').' SET ordering = ordering + 1 WHERE fieldfor = 3 AND ordering > 13;';
							$sql .= 'UPDATE '.$db->nameQuote('#__js_job_fieldsordering').' SET ordering = ordering + 1 WHERE fieldfor = 13 AND ordering > 13;';
							$sql .= "INSERT INTO  ".$db->nameQuote('#__js_job_fieldsordering')." (`field`, `fieldtitle`, `ordering`,`section`,`fieldfor`,`published`,`sys`,`cannotunpublish`,`required`) VALUES ( 'date_of_birth', 'Date of Birth', '14', '10', '3', '1', '0', '0', '0');";
							$sql .= "INSERT INTO  ".$db->nameQuote('#__js_job_fieldsordering')." (`field`, `fieldtitle`, `ordering`,`section`,`fieldfor`,`published`,`sys`,`cannotunpublish`,`required`) VALUES ( 'date_of_birth','Date of Birth', '14', '10', '13', '1', '0', '0', '0');";
							$sql .= "INSERT INTO  ".$db->nameQuote('#__js_job_fieldsordering')." (`field`, `fieldtitle`, `ordering`,`section`,`fieldfor`,`published`,`sys`,`cannotunpublish`,`required`) VALUES ( 'video','Youtube Video Id',22,'20',3,1,1,0,0);";
							$sql .= "INSERT INTO  ".$db->nameQuote('#__js_job_fieldsordering')." (`field`, `fieldtitle`, `ordering`,`section`,`fieldfor`,`published`,`sys`,`cannotunpublish`,`required`) VALUES ( 'video','Youtube Video Id',22,'20',13,1,1,0,0);";
							$sql .= "INSERT INTO  ".$db->nameQuote('#__js_job_fieldsordering')." (`field`, `fieldtitle`, `ordering`,`section`,`fieldfor`,`published`,`sys`,`cannotunpublish`,`required`) VALUES ( 'address_location','Longitude And Latitude',50,'31',3,1,1,0,0);";
							$sql .= "INSERT INTO  ".$db->nameQuote('#__js_job_fieldsordering')." (`field`, `fieldtitle`, `ordering`,`section`,`fieldfor`,`published`,`sys`,`cannotunpublish`,`required`) VALUES ( 'address_location','Longitude And Latitude',50,'31',13,1,1,0,0);";
						}

						if(($version->configvalue == '1085') || ($version->configvalue == '1086')){
							$jaquery = 'INSERT INTO '.$db->nameQuote('#__js_job_resume').' SELECT *,"","","" FROM '.$db->nameQuote('#__js_job_resume_bak').';';
							$sql = "INSERT INTO  ".$db->nameQuote('#__js_job_fieldsordering')." (`field`, `fieldtitle`, `ordering`,`section`,`fieldfor`,`published`,`sys`,`cannotunpublish`,`required`) VALUES ( 'video','Youtube Video Id',22,'20',3,1,1,0,0);";
							$sql .= "INSERT INTO  ".$db->nameQuote('#__js_job_fieldsordering')." (`field`, `fieldtitle`, `ordering`,`section`,`fieldfor`,`published`,`sys`,`cannotunpublish`,`required`) VALUES ( 'video','Youtube Video Id',22,'20',13,1,1,0,0);";
							$sql .= "INSERT INTO  ".$db->nameQuote('#__js_job_fieldsordering')." (`field`, `fieldtitle`, `ordering`,`section`,`fieldfor`,`published`,`sys`,`cannotunpublish`,`required`) VALUES ( 'address_location','Longitude And Latitude',50,'31',3,1,1,0,0);";
							$sql .= "INSERT INTO  ".$db->nameQuote('#__js_job_fieldsordering')." (`field`, `fieldtitle`, `ordering`,`section`,`fieldfor`,`published`,`sys`,`cannotunpublish`,`required`) VALUES ( 'address_location','Longitude And Latitude',50,'31',13,1,1,0,0);";
						}
					}



					
				}
				
			}
		
	}

	/**
	 * method to run before an install/update/uninstall method
	 *
	 * @return void
	 */
	function preflight($type, $parent) 
	{
	}

	/**
	 * method to run after an install/update/uninstall method
	 *
	 * @return void
	 */
	function postflight($type, $parent) 
	{
		jimport('joomla.installer.helper');
		$installer = new JInstaller();
		//$installer->_overwrite = true;

		$ext_module_path = JPATH_ADMINISTRATOR.'/components/com_jsjobs/extensions/modules/';
		
			$extensions = array( 'mod_featuredcompanies.zip'=>'Featured Companies Module',
				'mod_featuredjobs.zip'=>'Featured Jobs Module',
				'mod_featuredresumes.zip'=>'Featured Resumes Module',
				'mod_goldcompanies.zip'=>'Gold Companies Module',
				'mod_goldjobs.zip'=>'Gold Jobs Module',
				'mod_goldresumes.zip'=>'Gold Resumes Module',
				'mod_hotjsjobs.zip'=>'Hot Jobs Module',
				'mod_jsjobssearch.zip'=>'Jobs Search Module',
				'mod_jsresumesearch.zip'=>'Resume Search Module',
				'mod_jstopresume.zip'=>'Top Resume Module',
				'mod_jsjobcategories.zip'=>'Job Categories Module',
				'mod_jsjobscity.zip'=>'Jobs City Module',
				'mod_jsjobscountry.zip'=>'Jobs Country Module',
				'mod_jsjobslogin.zip'=>'JS Jobs Login Module',
				'mod_jsjobsstats.zip'=>'JS Jobs Stats Module',
				'mod_newestjsjobs.zip'=>'Newest Jobs Module',
				'mod_newestjsresume.zip'=>'Newest Resume Module',
				'mod_topjsjobs.zip'=>'Top Jobs Module'

			 );
             
			echo "<br /><br /><font color='green'><strong>Installing modules</strong></font>";
			 foreach( $extensions as $ext => $extname ){
				  $package = JInstallerHelper::unpack( $ext_module_path.$ext );
				  if( $installer->install( $package['dir'] ) ){
					echo "<br /><font color='green'>$extname successfully installed.</font>";
				  }else{
					echo "<br /><font color='red'>ERROR: Could not install the $extname. Please install manually.</font>";
				  }
				JInstallerHelper::cleanupInstall( $ext_module_path.$ext, $package['dir'] ); 
			}


			echo "<br /><br /><font color='green'><strong>Installing plugins</strong></font>";
			$ext_plugin_path = JPATH_ADMINISTRATOR.'/components/com_jsjobs/extensions/plugins3/';
			$extensions = array( 'plg_jsfeaturedcompanies.zip'=>'Featured Companies Plugin',
				'plg_jsfeaturedjobs.zip'=>'Featured Jobs Plugin',
				'plg_jsfeaturedresumes.zip'=>'Featured Resumes Plugin',
				'plg_jsgoldcompanies.zip'=>'Gold Companies Plugin',
				'plg_jsgoldjobs.zip'=>'Gold Jobs Plugin',
				'plg_jsgoldresumes.zip'=>'Gold Resumes Plugin',
				'plg_jshotjobs.zip'=>'Hot Jobs Plugin',
				'plg_jssearchjobs.zip'=>'Jobs Search Plugin',
				'plg_jssearchresumes.zip'=>'Resume Search Plugin',
				'plg_jstopresume.zip'=>'Top Resume Plugin',
				'plg_jsjobcategories.zip'=>'Job Categories Plugin',
				'plg_jsjobscity.zip'=>'Jobs City Plugin',
				'plg_jsjobscountries.zip'=>'Jobs Country Plugin',
				'plg_jsjobsregister.zip'=>'JS Jobs Register Plugin',
				'plg_jsjobsstates.zip'=>'JS Jobs Stats Plugin',
				'plg_jsnewestjobs.zip'=>'Newest Jobs Plugin',
				'plg_jsnewestresume.zip'=>'Newest Resume Plugin',
				'plg_jstopjobs.zip'=>'Top Jobs Plugin'

			 );
				 
			 foreach( $extensions as $ext => $extname ){
				  $package = JInstallerHelper::unpack( $ext_plugin_path.$ext );
				  if( $installer->install( $package['dir'] ) ){
					echo "<br /><font color='green'>$extname successfully installed.</font>";
				  }else{
					echo "<br /><font color='red'>ERROR: Could not install the $extname. Please install manually.</font>";
				  }
				JInstallerHelper::cleanupInstall( $ext_plugin_path.$ext, $package['dir'] ); 
			}
		
	}



}

