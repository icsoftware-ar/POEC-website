<?php
/**
 * @Copyright Copyright (C) 2009-2011
 * @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
 + Created by:          Ahmad Bilal
 * Company:		Buruj Solutions
 + Contact:		www.burujsolutions.com , ahmad@burujsolutions.com
 * Created on:	Jan 11, 2009
 ^
 + Project: 		JS Jobs
 * File Name:	router.php
 ^ 
 * Description: for Joomla SEF
 ^ 
 * History:		NONE
 ^ 
 */
 
 
function JSJobsBuildRoute( &$query )
{
       $segments = array();
	   
       if(isset( $query['c'] )) { $segments[] = $query['c']; unset( $query['c'] );};
       if(isset( $query['view'] )) { $segments[] = $query['view']; unset( $query['view'] ); };
       if(isset( $query['layout'] )) { $segments[] = $query['layout']; unset( $query['layout'] );};
	   // list_jobs
       if(isset( $query['jobcat'] )) { $segments[] = $query['jobcat']; unset( $query['jobcat'] );};
       if(isset( $query['cn'] )) { $segments[] = $query['cn']; unset( $query['cn'] );};
       if(isset( $query['cd'] )) { $segments[] = $query['cd']; unset( $query['cd'] );};
       if(isset( $query['cm'] )) { $segments[] = $query['cm']; unset( $query['cm'] );};
	
	   // my companies
       if(isset( $query['md'] )) { $segments[] = $query['md']; unset( $query['md'] );};
	
	   // view company
       if(isset( $query['vm'] )) { $segments[] = $query['vm']; unset( $query['vm'] );};

	   // form job
       if(isset( $query['bd'] )) { $segments[] = $query['bd']; unset( $query['bd'] );};

	   // form job visitor
       if(isset( $query['email'] )) { $segments[] = $query['email']; unset( $query['email'] );};

	   // view job
       if(isset( $query['oi'] )) { $segments[] = $query['oi']; unset( $query['oi'] );};
       if(isset( $query['vj'] )) { $segments[] = $query['vj']; unset( $query['vj'] );};

	   // view resume search
       if(isset( $query['rs'] )) { $segments[] = $query['rs']; unset( $query['rs'] );};

	   // form resume
       if(isset( $query['rd'] )) { $segments[] = $query['rd']; unset( $query['rd'] );};

	   // view cover letter
       if(isset( $query['vct'] )) { $segments[] = $query['vct']; unset( $query['vct'] );};
       if(isset( $query['cl'] )) { $segments[] = $query['cl']; unset( $query['cl'] );};

	   // view resume search
       if(isset( $query['js'] )) { $segments[] = $query['js']; unset( $query['js'] );};

	   // apply now
       if(isset( $query['bi'] )) { $segments[] = $query['bi']; unset( $query['bi'] );};
       if(isset( $query['aj'] )) { $segments[] = $query['aj']; unset( $query['aj'] );};
	   
	   // view cover letters
       if(isset( $query['vts'] )) { $segments[] = $query['vts']; unset( $query['vts'] );};
       if(isset( $query['clu'] )) { $segments[] = $query['clu']; unset( $query['clu'] );};

       //view resume 2
       if(isset( $query['ms'] )) { $segments[] = $query['ms']; unset( $query['ms'] );};

       //view package
       if(isset( $query['gd'] )) { $segments[] = $query['gd']; unset( $query['gd'] );};

       //package buy now
       if(isset( $query['pb'] )) { $segments[] = $query['pb']; unset( $query['pb'] );};

       //form department
       if(isset( $query['pd'] )) { $segments[] = $query['pd']; unset( $query['pd'] );};

       //view department
       if(isset( $query['vp'] )) { $segments[] = $query['vp']; unset( $query['vp'] );};

       //view jobs by sub category
       if(isset( $query['jobsubcat'] )) { $segments[] = $query['jobsubcat']; unset( $query['jobsubcat'] );};

        //resume pdf output
       if(isset( $query['format'] )) { $segments[] = $query['format']; unset( $query['format'] );};

        //folder
       if(isset( $query['fd'] )) { $segments[] = $query['fd']; unset( $query['fd'] );};

        //country
       if(isset( $query['country'] )) { $segments[] = $query['country']; unset( $query['country'] );};
       if(isset( $query['state'] )) { $segments[] = $query['state']; unset( $query['state'] );};
       if(isset( $query['county'] )) { $segments[] = $query['county']; unset( $query['county'] );};
       if(isset( $query['city'] )) { $segments[] = $query['city']; unset( $query['city'] );};

	//list type       
	if(isset( $query['lt'] )) { $segments[] = $query['lt']; unset( $query['lt'] );};

       if(isset( $query['sortby'] )) { $segments[] = $query['sortby']; unset( $query['sortby'] );};

       if(isset( $query['task'] )) { $segments[] = $query['task']; unset( $query['task'] );};

	   // form job visitor
       if(isset( $query['jobid'] )) { $segments[] = $query['jobid']; unset( $query['jobid'] );};

	   // form user registration
       if(isset( $query['userrole'] )) { $segments[] = $query['userrole']; unset( $query['userrole'] );};

	   //  echo '<br> item '.$query['Itemid'];
       if(isset( $query['Itemid'] )) { 
		$_SESSION['JSItemid'] = $query['Itemid'];
	   };
	   
       return $segments;
}

function JSJobsParseRoute( $segments )
{
       $vars = array();
	   $count = count($segments);
//	   echo '<br> count '.$count;
       $menu = &JMenu::getInstance('site');
//       $item = &$menu->getActive();
		$menu	= &JSite::getMenu();

		$item	= &$menu->getActive();
		if($count == 2)
			$layout = $segments[1];
		elseif($segments[1] == 'userregister')
			$layout = $segments[1];
		else 
			$layout = $segments[2];

		
			//   echo '<br> layout '.$layout;
	switch($layout)
        {
               case 'jobcat':
                       $vars['view'] = 'jobseeker';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = 'jobcat';
                       break;
               case 'list_jobs':
                       $vars['view'] = 'jobseeker';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = 'list_jobs';
                       if($count == 4)
                        $vars['jobcat'] = $segments[3];
                       break;
               case 'list_subcategoryjobs':
                       $vars['view'] = 'jobseeker';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = 'list_subcategoryjobs';
                       if(isset($segments[3]))
							$vars['jobsubcat'] = $segments[3];
                       break;
               case 'controlpanel':
                       $vars['view'] = $segments[1];
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = 'controlpanel';
                       break;
               case 'mycompanies':
                       $vars['view'] = 'employer';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = 'mycompanies';
                       break;
               case 'formcompany':
                       $vars['view'] = 'employer';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = 'formcompany';
					   if ($count == 4) $vars['md'] = $segments[3];
                       break;
               case 'view_company':
                       $vars['view'] = $segments[1];
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
					   if ($count == 4){
							$vars['md'] = $segments[3];
					   }elseif ($count == 5){
							$vars['md'] = $segments[3];
							$vars['vm'] = $segments[4];
					   }elseif ($count == 6){
						   $vars['jobcat'] = $segments[3];
							$vars['md'] = $segments[4];
							$vars['vm'] = $segments[5];
						}	
                       break;
               case 'myjobs':
                       $vars['view'] = 'employer';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
					   if ($count == 4) $vars['sortby'] = $segments[3];
                       break;
               case 'formjob':
                       $vars['view'] = 'employer';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
					   if ($count == 4) $vars['bd'] = $segments[3];
                       break;
               case 'formjob_visitor':
                       $vars['view'] = 'employer';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
					   if ($count == 4) $vars['email'] = $segments[3];
					   if ($count == 5) $vars['jobid'] = $segments[4];
                       break;
               case 'view_job':
                       $vars['view'] = 'employer';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
                           $vars['oi'] = $segments[3];
                           $vars['vj'] = $segments[4];
                       break;
               case 'alljobsappliedapplications':
                       $vars['view'] = $segments[1];
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
					   if ($count == 4) $vars['sortby'] = $segments[3];
                       break;
               case 'job_appliedapplications':
                       $vars['view'] = $segments[1];
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
					   if ($count == 4) $vars['bd'] = $segments[3];
					   if ($count == 5) {
							$vars['bd'] = $segments[3];
							$vars['sortby'] = $segments[4];
					   }
                       break;
               case 'resumesearch':
                       $vars['view'] = 'employer';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
                       break;
               case 'resume_searchresults':
                       $vars['view'] = 'employer';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
					   if ($count == 4) $vars['sortby'] = $segments[3];
                       break;
               case 'my_resumesearches':
                       $vars['view'] = 'employer';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
                       break;
               case 'viewresumesearch':
                       $vars['view'] = 'employer';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
					   $vars['rs'] = $segments[3];
                       break;
               case 'myresumes':
                       $vars['view'] = 'jobseeker';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
					   if ($count == 4) $vars['sortby'] = $segments[3];
                       break;
               case 'formresume':
                       $vars['view'] = 'jobseeker';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
					   if ($count == 4) $vars['vm'] = $segments[3];
					   if ($count == 5) $vars['rd'] = $segments[4];
                       break;
               case 'view_resume':
                       $vars['view'] = 'jobseeker';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
					   if ($count == 4) $vars['vm'] = $segments[3];
					   elseif ($count == 5){
							$vars['vm'] = $segments[3];
							$vars['rd'] = $segments[4];
					   }elseif ($count == 6){
							$vars['vm'] = $segments[3];
							if($segments[3] == 5){   // from folder
								$vars['rd'] = $segments[4];
								$vars['fd'] = $segments[5];
							}else{
								$vars['bd'] = $segments[4];
								$vars['rd'] = $segments[5];
							}
						}	
                       break;
               case 'mycoverletters':
                       $vars['view'] = 'jobseeker';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
                       break;
               case 'formcoverletter':
                       $vars['view'] = 'jobseeker';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
					   if ($count == 4) $vars['cl'] = $segments[3];
                       break;
               case 'view_coverletter':
                       $vars['view'] = 'jobseeker';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
					   $vars['vct'] = $segments[3];
					   $vars['cl'] = $segments[4];
                       break;
               case 'view_coverletters':
                       $vars['view'] = 'jobseeker';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
					   if ($count == 5){
						   $vars['vts'] = $segments[3];
						   $vars['clu'] = $segments[4];
					   }elseif ($count == 7){
						   $vars['bd'] = $segments[3];
						   $vars['rd'] = $segments[4];
						   $vars['vts'] = $segments[5];
						   $vars['clu'] = $segments[6];
						}   
                       break;
               case 'myappliedjobs':
                       $vars['view'] = 'jobseeker';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
					   if ($count == 4) $vars['sortby'] = $segments[3];
                       break;
               case 'jobsearch':
                       $vars['view'] = 'jobseeker';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
                       break;
               case 'job_searchresults':
                       $vars['view'] = 'jobseeker';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
					   if ($count == 4) $vars['sortby'] = $segments[3];
                       break;
               case 'my_jobsearches':
                       $vars['view'] = 'jobseeker';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
                       break;
               case 'viewjobsearch':
                       $vars['view'] = 'jobseeker';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
					   $vars['js'] = $segments[3];
                       break;
               case 'job_apply':
                       $vars['view'] = 'jobseeker';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
						if($count == 5){
                           $vars['bi'] = $segments[3];
                           $vars['aj'] = $segments[4];
                        }else{
                           $vars['jobcat'] = $segments[3];
                           $vars['bi'] = $segments[4];
                           $vars['aj'] = $segments[5];
						}   
                       break;
               case 'deletejobsearch':
                       $vars['task'] = 'deletejobsearch';
                       $vars['c'] = 'jsjobs';
                       $vars['js'] = $segments[1];
                       break;
               case 'deleteresumesearch':
                       $vars['task'] = 'deleteresumesearch';
                       $vars['c'] = 'jsjobs';
                       $vars['rs'] = $segments[1];
                       break;
               case 'deletejob':
                       $vars['task'] = 'deletejob';
                       $vars['c'] = 'jsjobs';
                       if($count == 3)
							$vars['bd'] = $segments[1];
						else{
							$vars['email'] = $segments[1];
							$vars['jobid'] = $segments[3];
						}	
                       break;
               case 'deletecompany':
                       $vars['task'] = 'deletecompany';
                       $vars['c'] = 'jsjobs';
                       $vars['md'] = $segments[1];
                       break;
               case 'deleteresume':
                       $vars['task'] = 'deleteresume';
                       $vars['c'] = 'jsjobs';
                       $vars['rd'] = $segments[1];
                       break;
               case 'deletecoverletter':
                       $vars['task'] = 'deletecoverletter';
                       $vars['c'] = 'jsjobs';
                       $vars['cl'] = $segments[1];
                       break;
               case 'listnewestjobs':
                       $vars['view'] = 'jobseeker';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
			if ($count == 5){
			 	$vars['country'] = $segments[3];
				$vars['lt'] = $segments[4];
			}elseif ($count == 6){
			 	$vars['country'] = $segments[3];
				$vars['state'] = $segments[4];
				$vars['lt'] = $segments[5];
			}elseif ($count == 8){
			 	$vars['country'] = $segments[3];
				$vars['state'] = $segments[4];
				$vars['county'] = $segments[5];
				$vars['city'] = $segments[6];
				$vars['lt'] = $segments[7];
			}
                       break;
               case 'addtogoldcompany':
                       $vars['task'] = 'addtogoldcompany';
                       $vars['c'] = 'jsjobs';
                       $vars['md'] = $segments[1];
                       break;
               case 'addtofeaturedcompany':
                       $vars['task'] = 'addtofeaturedcompany';
                       $vars['c'] = 'jsjobs';
                       $vars['md'] = $segments[1];
                       break;
               case 'addtogoldjobs':
                       $vars['task'] = 'addtogoldjobs';
                       $vars['c'] = 'jsjobs';
                       $vars['oi'] = $segments[1];
                       break;
               case 'addtofeaturedjobs':
                       $vars['task'] = 'addtofeaturedjobs';
                       $vars['c'] = 'jsjobs';
                       $vars['oi'] = $segments[1];
                       break;
               case 'job_shortlistcandidates':
                       $vars['view'] = 'employer';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
                       $vars['bd'] = $segments[3];
                       break;
               case 'company_jobs':
                       $vars['view'] = 'jobseeker';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
                       $vars['cd'] = $segments[3];
                       break;
               case 'addtogoldresumes':
                       $vars['task'] = 'addtogoldresumes';
                       $vars['c'] = 'jsjobs';
                       $vars['rd'] = $segments[1];
                       break;
               case 'addtofeaturedresumes':
                       $vars['task'] = 'addtofeaturedresumes';
                       $vars['c'] = 'jsjobs';
                       $vars['rd'] = $segments[1];
                       break;
               case 'packages':
                       $vars['view'] = $segments[1];
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
                       break;
               case 'purchasehistory':
                       $vars['view'] = $segments[1];
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
                       break;
               case 'package_details':
                       $vars['view'] = $segments[1];
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
                       $vars['gd'] = $segments[3];
                       break;
               case 'package_buynow':
                       $vars['view'] = $segments[1];
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
                       $vars['gd'] = $segments[3];
                       $vars['pb'] = $segments[4];
                       break;
               case 'resumepdf':
                       $vars['view'] = $segments[1];
//                      echo '<br> layout '.$segments[6];
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = $layout;
                            $vars['bd'] = $segments[3];
                            $vars['rd'] = $segments[4];
                            $vars['ms'] = $segments[5];
                            $vars['format'] = $segments[6];
                       break;
               case 'mydepartments':
                       $vars['view'] = 'employer';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = 'mydepartments';
                       break;
               case 'formdepartment':
                       $vars['view'] = 'employer';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = 'formdepartment';
                            if ($count == 4) $vars['pd'] = $segments[3];
                       break;
               case 'view_department':
                       $vars['view'] = 'employer';
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = 'view_department';
                            $vars['pd'] = $segments[3];
                            $vars['vp'] = $segments[4];
                       break;
               case 'deletedepartment':
                       $vars['task'] = 'deletedepartment';
                       $vars['c'] = 'jsjobs';
                       $vars['pd'] = $segments[1];
                       break;
               case 'my_stats':
                       $vars['view'] = $segments[1];
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = 'my_stats';
                       break;
               case 'successfullogin':
                       $vars['view'] = $segments[1];
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = 'successfullogin';
                       break;
               case 'send_message':
                       $vars['view'] = $segments[1];
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = 'send_message';
                            $vars['vm'] = $segments[3];
                            $vars['bd'] = $segments[4];
                            $vars['rd'] = $segments[5];
                       break;
               case 'myfolders':
                       $vars['view'] = $segments[1];
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = 'myfolders';
                       break;
               case 'folder_resumes':
                       $vars['view'] = $segments[1];
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = 'folder_resumes';
                            $vars['fd'] = $segments[3];
                       break;
               case 'formfolder':
                       $vars['view'] = $segments[1];
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = 'formfolder';
                            $vars['fd'] = $segments[3];
                       break;
               case 'viewfolder':
                       $vars['view'] = $segments[1];
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = 'viewfolder';
                       $vars['fd'] = $segments[3];
                       break;
               case 'deletefolder':
                       $vars['task'] = 'deletefolder';
                       $vars['c'] = 'jsjobs';
                       $vars['fd'] = $segments[1];
                       break;
               case 'jobalertsetting':
                       $vars['view'] = $segments[1];
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = 'jobalertsetting';
                       break;
               case 'empmessages':
                       $vars['view'] = $segments[1];
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = 'empmessages';
                       break;
               case 'jsmessages':
                       $vars['view'] = $segments[1];
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = 'jsmessages';
                       break;
               case 'job_messages':
                       $vars['view'] = $segments[1];
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = 'job_messages';
                            $vars['bd'] = $segments[3];
                       break;
               case 'exportresume':
                       $vars['task'] = 'exportresume';
                       $vars['c'] = 'jsjobs';
                       $vars['bd'] = $segments[1];
                       break;
               case 'business_version':
                       $vars['view'] = $segments[1];
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = 'business_version';
                       break;
               case 'rssjobs':
                       $vars['view'] = $segments[1];
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = 'rssjobs';
                       $vars['format'] = 'rss';
                       break;
               case 'rssresumes':
                       $vars['view'] = $segments[1];
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = 'rssresumes';
                       $vars['format'] = 'rss';
                       break;
               case 'resumebycategory':
                       $vars['view'] = $segments[1];
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = 'resumebycategory';
                       break;
               case 'resume_bycategory':
                       $vars['view'] = $segments[1];
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = 'resume_bycategory';
                       if(isset($segments[3]))
                       $vars['sortby'] = $segments[3];
                       break;
               case 'userregister':
                       $vars['view'] = $segments[0];
                       $vars['c'] = 'jsjobs';
                       $vars['layout'] = 'userregister';
                       if($count == 3) $vars['userrole'] = $segments[2];
                       break;
       }
       if(isset( $_SESSION['JSItemid'] )) { 
		$vars['Itemid'] = $_SESSION['JSItemid'];
		}
       return $vars;

}

